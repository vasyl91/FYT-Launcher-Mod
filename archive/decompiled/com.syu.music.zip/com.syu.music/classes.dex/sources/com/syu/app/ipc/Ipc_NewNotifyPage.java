package com.syu.app.ipc;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import com.lsec.core.frame.app.MyApplication;
import com.lsec.core.frame.app.MyUiItem;
import com.lsec.core.frame.ctrl.JButton;
import com.lsec.core.frame.ctrl.JText;
import com.lsec.core.ipc.module.main.Bt;
import com.lsec.core.ipc.module.main.Main;
import com.syu.app.App_Music;
import com.syu.media.ctrl.JPinBar;
import com.syu.media.ctrl.JRotView;
import com.syu.media.data.FinalMusicCtrl;
import com.syu.media.page.Page_BtAv;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class Ipc_NewNotifyPage {
    public void onNotify_Bt(Page_BtAv page_Av, int updateCode, int[] ints, float[] flts, String[] strs) {
        String str;
        switch (updateCode) {
            case 0:
                String title = Bt.sId3Title;
                JText text = (JText) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Txt_Title);
                if (IpcObj.isBtDisConnect()) {
                    text.setText(App_Music.getInstance().uiApp.getString("bt_disconnected"));
                } else {
                    if (text != null) {
                        text.setText(title);
                    }
                    switch (MyApplication.mIdCustomer) {
                        case 1:
                        case 43:
                        case 61:
                        case 105:
                            if (!TextUtils.isEmpty(title)) {
                                Bundle data = new Bundle();
                                data.putString("btav", title);
                                Intent intent = new Intent();
                                intent.putExtras(data);
                                intent.setAction("com.syu.widget.BtavService");
                                if (MyApplication.mIdCustomer == 43) {
                                    intent.setPackage("com.syu.widget");
                                } else if (MyApplication.mIdCustomer == 61 || MyApplication.mIdCustomer == 105 || MyApplication.mIdCustomer == 1) {
                                    intent.setPackage("com.android.launcher3");
                                }
                                MyApplication.myApp.startServiceSafely(intent);
                            }
                    }
                }
                break;
            case 1:
                String artist = Bt.sId3Artist;
                JText text2 = (JText) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Txt_Artist);
                if (text2 != null) {
                    text2.setText(artist);
                }
                switch (MyApplication.mIdCustomer) {
                    case 1:
                    case 43:
                    case 61:
                    case 105:
                        if (!TextUtils.isEmpty(artist)) {
                            Bundle data2 = new Bundle();
                            data2.putString("btav_art", artist);
                            Intent intent2 = new Intent();
                            intent2.putExtras(data2);
                            intent2.setAction("com.syu.widget.BtavService");
                            if (MyApplication.mIdCustomer == 43) {
                                intent2.setPackage("com.syu.widget");
                            } else if (MyApplication.mIdCustomer == 61 || MyApplication.mIdCustomer == 105 || MyApplication.mIdCustomer == 1) {
                                intent2.setPackage("com.android.launcher3");
                            }
                            MyApplication.myApp.startServiceSafely(intent2);
                        }
                        break;
                }
                break;
            case 9:
                if (IpcObj.isBtDisConnect()) {
                    JText text3 = (JText) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Txt_Title);
                    if (text3 != null) {
                        text3.setText("");
                    }
                    JText text4 = (JText) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Txt_Artist);
                    if (text4 != null) {
                        text4.setText("");
                    }
                    View viewId3Info = page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Id3Info);
                    if (viewId3Info != null) {
                        viewId3Info.setVisibility(8);
                    }
                    page_Av.misAvStop = false;
                }
                break;
            case 13:
                int value = Bt.DATA[updateCode];
                boolean bRun = false;
                if (!IpcObj.isBtDisConnect() && value == 1) {
                    bRun = true;
                }
                App_Music.bBtavRuuing = bRun;
                if (MyApplication.mIdCustomer == 26 && Main.mConf_PlatForm == 5) {
                    if (bRun) {
                        page_Av.startAnim();
                    } else {
                        page_Av.stopAnim();
                    }
                }
                JRotView rotCd = (JRotView) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_RotCd);
                JPinBar pinBar = (JPinBar) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_PinBar);
                JButton BtnPlayPause = (JButton) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Btn_PlayPause);
                if (rotCd != null) {
                    rotCd.updateRotateAniState(bRun);
                }
                if (pinBar != null) {
                    pinBar.setRun(bRun);
                }
                if (BtnPlayPause != null) {
                    MyUiItem item = (MyUiItem) BtnPlayPause.getTag();
                    if (item.getParaStr() != null) {
                        String str2 = null;
                        if (bRun) {
                            str2 = item.getStrDrawable();
                        } else if (item.getParaStr() != null) {
                            str2 = item.getParaStr()[0];
                        }
                        if (str2 != null && !BtnPlayPause.getStrDrawable().equalsIgnoreCase(str2)) {
                            BtnPlayPause.setStrDrawable(str2, true);
                        }
                    } else if (!App_Music.mStrCustomer.equalsIgnoreCase("LC_MUSIC1")) {
                        if (bRun) {
                            str = App_Music.getInstance().uiApp.getString("str_tip_pause");
                        } else {
                            str = App_Music.getInstance().uiApp.getString("str_tip_play");
                        }
                        if (BtnPlayPause.getText() != str) {
                            BtnPlayPause.setText(str);
                        }
                    }
                }
                boolean bId3InfoGone = false;
                if (value == 0 && page_Av.misAvStop) {
                    bId3InfoGone = true;
                }
                View viewId3Info2 = page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Id3Info);
                if (viewId3Info2 != null) {
                    viewId3Info2.setVisibility(bId3InfoGone ? 8 : 0);
                }
                break;
        }
    }
}
