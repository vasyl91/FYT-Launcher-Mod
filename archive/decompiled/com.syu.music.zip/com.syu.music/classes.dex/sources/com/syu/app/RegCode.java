package com.syu.app;

import com.lsec.core.ipc.IRegisterModuleCallBack;
import com.lsec.core.ipc.module.main.Bt;
import com.lsec.core.ipc.module.main.Main;
import com.lsec.core.ipc.module.main.Sound;
import com.lsec.core.ipc.module.sys.Sys;
import com.lsec.core.ipc786.module.Bt786;
import com.lsec.core.ipc786.module.Main786;
import com.syu.ipc.ICallback;
import com.syu.ipc.IModuleCallback;
import com.syu.ipc.IRegisterCallBack;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class RegCode {
    static final int[] CODE_Main = {50, 0, 43, 60, 1, 37, 61, 2, 118, 4};
    static final int[] CODE_Bt = {1, 0, 13, 9};
    static final int[] CODE_Sound = {10, 3, 0, 24, 2};
    static final int[] CODE_Sys = new int[1];
    static final int[] CODE_Main_786 = {3, 70, 27, 25, 0, 41, 2, 1};
    static final int[] CODE_Bt_786 = {2, 4, 19, 18, 1};
    public static IRegisterModuleCallBack mRegister_Main = new IRegisterModuleCallBack() { // from class: com.syu.app.RegCode.1
        @Override // com.lsec.core.ipc.IRegisterModuleCallBack
        public void register(IModuleCallback callback) {
            for (int updateCode : RegCode.CODE_Main) {
                Main.PROXY.register(callback, updateCode, 1);
            }
        }
    };
    public static IRegisterModuleCallBack mRegister_Sound = new IRegisterModuleCallBack() { // from class: com.syu.app.RegCode.2
        @Override // com.lsec.core.ipc.IRegisterModuleCallBack
        public void register(IModuleCallback callback) {
            for (int updateCode : RegCode.CODE_Sound) {
                Sound.PROXY.register(callback, updateCode, 1);
            }
        }
    };
    public static IRegisterModuleCallBack mRegister_Bt = new IRegisterModuleCallBack() { // from class: com.syu.app.RegCode.3
        @Override // com.lsec.core.ipc.IRegisterModuleCallBack
        public void register(IModuleCallback callback) {
            for (int updateCode : RegCode.CODE_Bt) {
                Bt.PROXY.register(callback, updateCode, 1);
            }
        }
    };
    public static IRegisterModuleCallBack mRegister_Sys = new IRegisterModuleCallBack() { // from class: com.syu.app.RegCode.4
        @Override // com.lsec.core.ipc.IRegisterModuleCallBack
        public void register(IModuleCallback callback) {
            for (int updateCode : RegCode.CODE_Sys) {
                Sys.PROXY.register(callback, updateCode, 1);
            }
        }
    };
    public static IRegisterCallBack mRegister_Main_786 = new IRegisterCallBack() { // from class: com.syu.app.RegCode.5
        @Override // com.syu.ipc.IRegisterCallBack
        public void register(ICallback callback) {
            for (int updateCode : RegCode.CODE_Main_786) {
                Main786.hInstance.registerCallback(callback, updateCode, true);
            }
        }
    };
    public static IRegisterCallBack mRegister_Bt_786 = new IRegisterCallBack() { // from class: com.syu.app.RegCode.6
        @Override // com.syu.ipc.IRegisterCallBack
        public void register(ICallback callback) {
            for (int updateCode : RegCode.CODE_Bt_786) {
                Bt786.hInstance.registerCallback(callback, updateCode, true);
            }
        }
    };
}
