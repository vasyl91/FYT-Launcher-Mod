package com.syu.app.ipc;

import android.os.SystemProperties;
import android.text.TextUtils;
import android.util.Log;
import com.lsec.core.frame.app.MyApplication;
import com.lsec.core.ipc.Conn;
import com.lsec.core.ipc.ConnSys;
import com.lsec.core.ipc.module.main.Bt;
import com.lsec.core.ipc.module.main.Main;
import com.lsec.core.ipc.module.main.Sound;
import com.lsec.core.util.IUiNotify;
import com.lsec.core.util.IpcUtil;
import com.myspec.MyClass;
import com.syu.app.App_Music;
import com.syu.broadcast.Receiver;
import com.syu.media.core.MediaInfo;
import com.syu.media.core.MyMediaPlayer;
import com.syu.media.ctrl.JVisualizer;
import com.syu.music.Interface_Music;
import com.syu.music.MediaManager;
import com.syu.util.Util;
import java.io.File;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class Ipc_New {
    public static final int[] NOTIFYCODE_Main = {0, 1, 2, 4};
    public static final int[] NOTIFYCODE_Main_Will = {43, 37, 60, 61, 50};
    public static final int[] NOTIFYCODE_Sys_Will = new int[1];
    public static final int[] NOTIFYCODE_Sound = {10, 24, 2, 3};
    public static final int[] NOTIFYCODE_BtAV = {13, 0, 1, 9};
    public Conn mConn = null;
    public ConnSys mConnSys = null;
    public Ipc_NewNotifyPage mNotify = new Ipc_NewNotifyPage();
    int volume = 0;
    IUiNotify notify_Sound = new IUiNotify() { // from class: com.syu.app.ipc.Ipc_New.1
        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) {
            switch (updateCode) {
                case 2:
                    if (ints != null && ints.length > 0) {
                        Ipc_New.this.volume = ints[0];
                        App_Music.getInstance().setSoundVolume(false, Ipc_New.this.volume);
                        break;
                    }
                    break;
                case 3:
                    if (ints != null && ints.length > 0) {
                        App_Music.getInstance().setSoundVolume(ints[0] == 1, Ipc_New.this.volume);
                        break;
                    }
                    break;
                case 10:
                    if (IpcUtil.intsOk(ints, 1)) {
                        App_Music.getInstance();
                        App_Music.mSoundMode = Sound.DATA[updateCode];
                        App_Music.getInstance().setSoundMode(Sound.DATA[updateCode]);
                    }
                    break;
                case 24:
                    if (App_Music.bEnableSpec && App_Music.getInstance().isAppTop() && Sound.DATA[updateCode] == 0) {
                        Ipc_New.this.EnableGainSpec();
                        break;
                    }
                    break;
            }
        }
    };
    IUiNotify notify_Main = new IUiNotify() { // from class: com.syu.app.ipc.Ipc_New.2
        boolean bAppIdAudioBak = false;
        boolean bAccOnBak = false;
        boolean bWakeupBak = false;
        boolean bStandByPlay = false;
        boolean bMcuOnPlay = false;

        /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) throws Throwable {
            Log.d("App_Music", "---------->>> onNotify");
            switch (updateCode) {
                case 0:
                    Log.d(App_Music.TAG, "---------->>> FinalMain.U_APP_ID:" + Main.DATA[0]);
                    if (App_Music.getInstance().getAppState() && Util.is8541() && Ipc_New.this.isAppIdAudio()) {
                        App_Music.getInstance().mIpcObj.requestAppIdNull();
                        break;
                    } else {
                        boolean bAppIdAudio = Ipc_New.this.isAppIdAudio();
                        if (bAppIdAudio != this.bAppIdAudioBak) {
                            if (bAppIdAudio) {
                                Log.d(App_Music.TAG, "---------->>> Ipc_New bAppIdAudio");
                                App_Music.requestAudioFocus();
                                MediaManager.mInstance.registerMediaButton();
                            }
                            if (!bAppIdAudio) {
                                App_Music.bisplay = App_Music.bOnKeyBack ? App_Music.bOnKeyBack : App_Music.myMediaPlayer.isPlaying();
                                Log.d(App_Music.TAG, "---------->>> Ipc_New bOnKeyBack: " + App_Music.bOnKeyBack);
                                Log.d(App_Music.TAG, "---------->>> Ipc_New isPlaying: " + App_Music.myMediaPlayer.isPlaying());
                                Log.d(App_Music.TAG, "---------->>> Ipc_New not bAppIdAudio bisplay: " + App_Music.bisplay);
                                MediaManager.mInstance.unregisterMediaButton();
                                if (!MyMediaPlayer.bNoPlay) {
                                    App_Music.bPausedByChangeAppId = true;
                                    App_Music.myMediaPlayer.end(true);
                                }
                            } else if (SystemProperties.getInt("zj.zsender.focus.video", -1) != 0) {
                                Log.d(App_Music.TAG, "---------->>> Ipc_New bPausedByChangeAppId:" + App_Music.bPausedByChangeAppId);
                                Log.d(App_Music.TAG, "---------->>> Ipc_New bNoPlay:" + MyMediaPlayer.bNoPlay);
                                Log.d(App_Music.TAG, "---------->>> Ipc_New bisplay:" + App_Music.bisplay);
                                if (App_Music.bPausedByChangeAppId) {
                                    App_Music.bPausedByChangeAppId = false;
                                    if (MyMediaPlayer.bNoPlay && App_Music.bisplay) {
                                        Log.d(App_Music.TAG, "---------->>>Ipc_New App_Music.bisplay");
                                        App_Music.myMediaPlayer.openPlayer();
                                    }
                                }
                                if (MyMediaPlayer.bReOpenAfterRightAppId) {
                                    MyMediaPlayer.bReOpenAfterRightAppId = false;
                                    Log.d(App_Music.TAG, "---------->>> Ipc_New bReOpenAfterRightAppId");
                                    App_Music.myMediaPlayer.openPlayer();
                                }
                                if (MyMediaPlayer.bReOpenAfterAccOn) {
                                    MyMediaPlayer.bReOpenAfterAccOn = false;
                                    Log.d(App_Music.TAG, "---------->>> Ipc_New MyMediaPlayer.bReOpenAfterAccOn");
                                    App_Music.myMediaPlayer.openPlayer();
                                }
                                if (MyMediaPlayer.bNoPlay && App_Music.bisplay && !TextUtils.isEmpty(App_Music.mPathResume)) {
                                    File fileResume = new File(App_Music.mPathResume);
                                    if (fileResume.exists()) {
                                        Log.d(App_Music.TAG, "---------->>> bNoPlay");
                                        App_Music.getInstance().playFile(App_Music.mPathResume, false);
                                    } else if (Util.is8541() || Util.is9863() || Util.is7862()) {
                                        App_Music.getInstance().accOnResymeLastPlay(8);
                                    }
                                }
                                App_Music.bOnKeyBack = false;
                                App_Music.bisplay = true;
                            }
                            this.bAppIdAudioBak = bAppIdAudio;
                            if (App_Music.mStrCustomer.equalsIgnoreCase("YF_MUSIC") && !bAppIdAudio) {
                                int iState = 2;
                                if (App_Music.myMediaPlayer.isPlaying()) {
                                    iState = 0;
                                }
                                Main.PROXY.cmd(23, new int[]{Ipc_New.this.getRightAppId(), 3, iState}, (float[]) null, (String[]) null);
                                break;
                            }
                        }
                    }
                    break;
                case 1:
                    if (IpcUtil.intsOk(ints, 1)) {
                        if (ints[0] == 0) {
                            if (App_Music.myMediaPlayer.isPlaying()) {
                                App_Music.getInstance().pause();
                                this.bMcuOnPlay = true;
                            }
                        } else if (this.bMcuOnPlay) {
                            this.bMcuOnPlay = false;
                            App_Music.getInstance().play();
                        }
                    }
                    break;
                case 2:
                    if (!App_Music.mStrCustomer.equals("ouhua") && !Util.isPCBA() && !App_Music.mStrCustomer.equals("jieyou") && !App_Music.mStrCustomer.equals("YF_MUSIC") && IpcUtil.intsOk(ints, 1)) {
                        if (ints[0] == 1) {
                            if (Main.DATA[0] == 3) {
                                IpcObj.BtAvPause();
                                this.bStandByPlay = true;
                                break;
                            } else if (Main.DATA[0] == 8 && App_Music.myMediaPlayer.isPlaying()) {
                                App_Music.getInstance().pause();
                                this.bStandByPlay = true;
                                break;
                            }
                        } else {
                            if (this.bStandByPlay) {
                                this.bStandByPlay = false;
                                if (Main.DATA[0] == 3) {
                                    IpcObj.BtAvPlay();
                                } else {
                                    App_Music.getInstance().play();
                                }
                            }
                            break;
                        }
                    }
                    break;
                case 4:
                    if (IpcUtil.intsOk(ints, 1)) {
                        String str = App_Music.mStrCustomer;
                        switch (str.hashCode()) {
                            case -1116944314:
                                if (!str.equals("MUSIC_NEW")) {
                                }
                                break;
                            case 358341277:
                                if (!str.equals("MUSIC_NEW_V")) {
                                }
                                break;
                            case 1626537869:
                                if (!str.equals("MUSIC_YL")) {
                                }
                                break;
                        }
                        App_Music.mColorType = ints[0];
                        App_Music.getInstance().setDayOrNight(ints[0]);
                    }
                    break;
                case 37:
                    if (IpcUtil.intsOk(ints, 2) && ints[0] == Ipc_New.this.getRightAppId()) {
                        int value = ints[1];
                        switch (value) {
                            case 0:
                                App_Music.getInstance().play();
                                break;
                            case 1:
                                App_Music.getInstance().playPause();
                                break;
                            case 2:
                                App_Music.getInstance().pause();
                                break;
                            case 4:
                                if (MediaInfo.mCycleMode == 3) {
                                    if (App_Music.mStrCustomer.equals("KANGDA")) {
                                        App_Music.getInstance().switchMedia(-1);
                                    } else {
                                        App_Music.getInstance().switchMedia(-1, 0);
                                    }
                                } else {
                                    App_Music.getInstance().switchMedia(-1);
                                }
                                break;
                            case 5:
                                if (MediaInfo.mCycleMode == 3) {
                                    if (App_Music.mStrCustomer.equals("KANGDA")) {
                                        App_Music.getInstance().switchMedia(1);
                                    } else {
                                        App_Music.getInstance().switchMedia(1, 0);
                                    }
                                } else {
                                    App_Music.getInstance().switchMedia(1);
                                }
                                break;
                            case 9:
                                if (MediaInfo.mCycleMode != 3) {
                                    App_Music.getInstance().setCycleMode(3, false);
                                } else {
                                    App_Music.getInstance().setCycleMode(0, false);
                                }
                                break;
                        }
                    }
                    break;
                case 43:
                    if (IpcUtil.intsOk(ints, 1) && Ipc_New.this.isAppIdAudio()) {
                        boolean bWakeup = ints[0] != 0;
                        if (this.bWakeupBak != bWakeup) {
                            if (!bWakeup) {
                                if (App_Music.myMediaPlayer.isPlaying()) {
                                    App_Music.bPausedBySleep = true;
                                    App_Music.getInstance().pause();
                                }
                            } else if (App_Music.bPausedBySleep) {
                                App_Music.bPausedBySleep = false;
                                if (!MyMediaPlayer.bNoPlay) {
                                    App_Music.getInstance().play();
                                }
                            }
                            this.bWakeupBak = bWakeup;
                        }
                        break;
                    }
                    break;
                case 50:
                    if (IpcUtil.intsOk(ints, 1)) {
                        boolean bAccOn = ints[0] != 0;
                        Log.d(App_Music.TAG, "U_ACC_ON bAccOn:" + bAccOn);
                        if (this.bAccOnBak != bAccOn) {
                            if (!bAccOn) {
                                App_Music.myMediaPlayer.end(true);
                                for (int iDev = 0; iDev < 26; iDev++) {
                                    MediaInfo.setEndScan(iDev, true);
                                    MediaInfo.clear(iDev);
                                }
                                App_Music.listPlay.clear();
                                App_Music.getInstance().backToList();
                                App_Music.bResumeLastPlayOnce = false;
                                App_Music.bScanFileCntOver = false;
                                Receiver.bResumeScan = true;
                            } else if (Ipc_New.this.isAppIdAudio()) {
                                if (MyMediaPlayer.bReOpenAfterAccOn) {
                                    MyMediaPlayer.bReOpenAfterAccOn = false;
                                    App_Music.myMediaPlayer.openPlayer();
                                }
                                Main.postRunnable_Ui(true, App_Music.getInstance().mRunnable_ScanFile, 2000L);
                            }
                            this.bAccOnBak = bAccOn;
                        }
                    }
                    break;
                case 60:
                    if (IpcUtil.intsOk(ints, 1) && App_Music.getInstance().isAppTop()) {
                        switch (ints[0]) {
                            case 0:
                                if (App_Music.getInstance().bEnableFocusChange) {
                                    for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                                        if (interface_Music.isTop()) {
                                            interface_Music.scrollOk();
                                            break;
                                        }
                                    }
                                } else if (App_Music.getInstance().mIpcObj.isAppIdAudio()) {
                                    App_Music.getInstance().playPause();
                                }
                                break;
                            case 1:
                                for (Interface_Music interface_Music2 : App_Music.mInterface_Musics) {
                                    if (interface_Music2.isTop()) {
                                        interface_Music2.onKeyUp();
                                        break;
                                    }
                                }
                                break;
                            case 2:
                                for (Interface_Music interface_Music3 : App_Music.mInterface_Musics) {
                                    if (interface_Music3.isTop()) {
                                        interface_Music3.onKeyDown();
                                        break;
                                    }
                                }
                                break;
                            case 3:
                                for (Interface_Music interface_Music4 : App_Music.mInterface_Musics) {
                                    if (interface_Music4.isTop()) {
                                        interface_Music4.onKeyLeft();
                                        break;
                                    }
                                }
                                break;
                            case 4:
                                for (Interface_Music interface_Music5 : App_Music.mInterface_Musics) {
                                    if (interface_Music5.isTop()) {
                                        interface_Music5.onKeyRight();
                                        break;
                                    }
                                }
                                break;
                            case 5:
                                if (App_Music.getInstance().bEnableFocusChange) {
                                    for (Interface_Music interface_Music6 : App_Music.mInterface_Musics) {
                                        if (interface_Music6.isTop()) {
                                            interface_Music6.scrollToPrev();
                                            break;
                                        }
                                    }
                                } else if (App_Music.getInstance().mIpcObj.isAppIdAudio()) {
                                    if (MediaInfo.mCycleMode == 3) {
                                        App_Music.getInstance().switchMedia(-1, 0);
                                    } else {
                                        App_Music.getInstance().switchMedia(-1);
                                    }
                                }
                                break;
                            case 6:
                                if (App_Music.getInstance().bEnableFocusChange) {
                                    for (Interface_Music interface_Music7 : App_Music.mInterface_Musics) {
                                        if (interface_Music7.isTop()) {
                                            interface_Music7.scrollToNext();
                                            break;
                                        }
                                    }
                                } else if (App_Music.getInstance().mIpcObj.isAppIdAudio()) {
                                    if (MediaInfo.mCycleMode == 3) {
                                        App_Music.getInstance().switchMedia(1, 0);
                                    } else {
                                        App_Music.getInstance().switchMedia(1);
                                    }
                                }
                                break;
                        }
                    }
                    break;
                case 61:
                    if (IpcUtil.intsOk(ints, 1) && ints[0] != -1) {
                        App_Music.myMediaPlayer.end(true);
                        break;
                    }
                    break;
                case 118:
                    if (Util.is7731()) {
                        switch (App_Music.mDev) {
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                                if (!App_Music.is7731UsbSwitch && Ipc_New.this.isAppIdAudio()) {
                                    Log.d(App_Music.TAG, "FinalMain.U_USB_INDEX");
                                    App_Music.scanFile(App_Music.mDev, App_Music.bAutoPlayWhenMount);
                                    break;
                                }
                        }
                    }
                    break;
            }
        }
    };
    private IUiNotify notify_Sys = new IUiNotify() { // from class: com.syu.app.ipc.Ipc_New.3
        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) {
            switch (updateCode) {
                case 0:
                    if (IpcUtil.strsOk(strs, 1) && MyApplication.myApp.getPackageName().equals(strs[0])) {
                        App_Music.bOnKeyBack = true;
                        App_Music.myMediaPlayer.end(true);
                        App_Music.getInstance().mIpcObj.requestAppIdNull();
                        break;
                    }
                    break;
            }
        }
    };
    private IUiNotify notify_Bt = new IUiNotify() { // from class: com.syu.app.ipc.Ipc_New.4
        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) {
            for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                interface_Music.onNotify_Bt(updateCode, ints, flts, strs);
            }
        }
    };

    public void initIpc() {
        MyApplication.mListUiNotify_Main.add(this.notify_Main);
        MyApplication.mListUiNotify_Sound.add(this.notify_Sound);
        MyApplication.mListUiNotify_Bt.add(this.notify_Bt);
        MyApplication.mListUiNotify_Sys.add(this.notify_Sys);
    }

    public boolean isMute() {
        return Sound.DATA[3] == 1 || Sound.DATA[2] == 0;
    }

    public int getVolume() {
        return Main.DATA[Sound.DATA[2]];
    }

    public static boolean isAccOn() {
        return App_Music.mUsedInMobilePhone || Main.DATA[50] != 0;
    }

    public boolean isRightAppId() {
        return App_Music.mUsedInMobilePhone || Main.DATA[0] == getRightAppId();
    }

    public boolean isAppIdAudio() {
        return App_Music.mUsedInMobilePhone || Main.DATA[0] == 8;
    }

    public int getRightAppId() {
        return App_Music.sPage_Music == 110020 ? 3 : 8;
    }

    public void requestAppIdNull() {
        if (isRightAppId()) {
            Main.requestAppId(0);
        }
    }

    public void requestAppIdRight() {
        Log.d("App_Music", "------------>>>   requestAppIdRight");
        if (App_Music.mEnableHalfScreen) {
            if (!isAppIdAudio() && App_Music.getInstance().isAppTop()) {
                Main.requestAppIdByOnTop(getRightAppId());
            }
        } else {
            Main.requestAppIdByOnTop(getRightAppId());
        }
        MyClass.getInstance().initCust();
    }

    public void requestAppIdRight_Direct() {
        Main.requestAppId(getRightAppId());
    }

    public void TransmitTitle(int iPosName) {
        String title = App_Music.myMediaPlayer.mPlayPath.substring(iPosName + 1);
        Main.PROXY.cmd(23, new int[]{getRightAppId(), 0}, (float[]) null, new String[]{title});
    }

    public void TransmitArtist() {
        Main.PROXY.cmd(23, new int[]{getRightAppId(), 1}, (float[]) null, new String[]{App_Music.mId3Info.strArtist});
    }

    public void TransmitAlbum() {
        Main.PROXY.cmd(23, new int[]{getRightAppId(), 2}, (float[]) null, new String[]{App_Music.mId3Info.strAlbum, App_Music.myMediaPlayer.mPlayPath});
    }

    public void TransmitPlayState() {
        if (isAppIdAudio()) {
            int iState = 2;
            if (App_Music.myMediaPlayer.isPlaying()) {
                iState = 0;
            }
            Main.PROXY.cmd(23, new int[]{getRightAppId(), 3, iState}, (float[]) null, (String[]) null);
        }
    }

    public void TransmitIndex(int currentPos, int TotalCount) {
        Main.PROXY.cmd(23, new int[]{getRightAppId(), 4, currentPos, TotalCount}, (float[]) null, (String[]) null);
    }

    public void TransmitPos() {
        Main.PROXY.cmd(23, new int[]{getRightAppId(), 5, App_Music.myMediaPlayer.mCurrent / 1000, App_Music.myMediaPlayer.mDuration / 1000}, (float[]) null, (String[]) null);
    }

    public void TransmitCycleMode() {
        if (isAppIdAudio()) {
            int iRandom = -1;
            int iCycle = 1;
            switch (MediaInfo.mCycleMode) {
                case 0:
                    iRandom = 0;
                    iCycle = 3;
                    break;
                case 1:
                    iRandom = 1;
                    break;
                case 2:
                    iRandom = 0;
                    iCycle = 1;
                    break;
                case 3:
                    iRandom = 0;
                    iCycle = 2;
                    break;
            }
            if (iRandom >= 0) {
                Main.PROXY.cmd(23, new int[]{getRightAppId(), 6, iCycle}, (float[]) null, (String[]) null);
                Main.PROXY.cmd(23, new int[]{getRightAppId(), 7, iRandom}, (float[]) null, (String[]) null);
            }
        }
    }

    public void TransmitFolder(int iPosName) {
        String strFolder;
        int iPosFolder;
        if (isAppIdAudio() && (iPosFolder = (strFolder = App_Music.myMediaPlayer.mPlayPath.substring(0, iPosName)).lastIndexOf("/")) >= 0) {
            String folderName = strFolder.substring(iPosFolder + 1);
            Main.PROXY.cmd(23, new int[]{getRightAppId(), 8}, (float[]) null, new String[]{folderName});
        }
    }

    public void TransmitDevType(int iDev) {
        int iDevType = 3;
        int indexSd = iDev - 1;
        if (indexSd >= 0 && indexSd < 2) {
            iDevType = 2;
        } else {
            int indexUsb = iDev - 3;
            if (indexUsb >= 0 && indexUsb < 21) {
                iDevType = 1;
            }
        }
        Main.PROXY.cmd(23, new int[]{getRightAppId(), 9, iDevType}, (float[]) null, (String[]) null);
    }

    public void TransmitMediaType() {
        Main.PROXY.cmd(23, new int[]{getRightAppId(), 10, 2}, (float[]) null, (String[]) null);
    }

    public float getElectricValue() {
        if (!App_Music.myMediaPlayer.isPlaying()) {
            return 0.0f;
        }
        int val = Sound.getSpectrumValue();
        if (val == 0) {
            return JVisualizer.mDataMax * JVisualizer.mDataMax;
        }
        return val;
    }

    public void EnableGainSpec() {
        Sound.PROXY.cmd(21, 1);
    }

    public void DisableGainSpec() {
        Sound.PROXY.cmd(21, 0);
    }

    public static boolean isDisConnect(int iState) {
        switch (iState) {
            case 0:
            case 1:
            case 6:
                return true;
            default:
                return false;
        }
    }

    public static boolean isBtDisConnect() {
        return isDisConnect(Bt.DATA[9]);
    }

    public static void SetStandBy() {
        Main.PROXY.cmd(18, 1);
    }

    public static void BtAvPrev() {
        Bt.PROXY.cmd(0);
    }

    public static void BtAvNext() {
        Bt.PROXY.cmd(1);
    }

    public static void BtAvPlayPause() {
        Bt.PROXY.cmd(2);
    }

    public static void BtAvPlay() {
        Bt.PROXY.cmd(27);
    }

    public static void BtAvPause() {
        Bt.PROXY.cmd(3);
    }

    public static void BtAvStop() {
        Bt.PROXY.cmd(4);
    }

    public void updateNotify_BtAv() {
        for (int updateCode : NOTIFYCODE_BtAV) {
            for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                interface_Music.onNotify_Bt(updateCode, null, null, null);
            }
        }
    }
}
