package com.syu.app;

import android.content.Intent;
import android.os.SystemProperties;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import com.lsec.core.frame.app.MyActivity;
import com.lsec.core.frame.app.MyApplication;
import com.lsec.core.ipc.Conn;
import com.lsec.core.ipc.ConnSys;
import com.lsec.core.ipc.module.main.Bt;
import com.lsec.core.ipc.module.main.Main;
import com.lsec.core.ipc.module.main.Sound;
import com.lsec.core.ipc.module.sys.Sys;
import com.lsec.core.ipc786.module.Bt786;
import com.lsec.core.ipc786.module.Main786;
import com.lsec.core.util.FuncUtils;
import com.lsec.core.util.IConnectedMain;
import com.lsec.core.util.IUiNotify;
import com.lsec.core.util.IUpdateAppWidget;
import com.lsec.core.util.Markup;
import com.syu.media.data.FinalMusicCtrl;
import com.syu.music.MService;
import java.io.File;
import org.jaudiotagger.tag.mp4.atom.Mp4NameBox;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class App extends MyApplication {
    public static String mStrCustomer = "";
    public static String mExtraProperty = "";
    public static String mMusicCarType = "";
    public Conn mConn = null;
    public ConnSys mConnSys = null;
    public Main786 mMainConn = null;
    public Bt786 mBtConn = null;
    public Runnable mRunnable_InitIpc = new Runnable() { // from class: com.syu.app.App.1
        @Override // java.lang.Runnable
        public void run() {
            App.this.initIpc();
        }
    };
    private IUiNotify notify_Bt_786 = new IUiNotify() { // from class: com.syu.app.App.2
        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) {
            for (IUiNotify uiNotify : App.mListUiNotify_Bt_786) {
                uiNotify.onNotify(updateCode, ints, flts, strs);
            }
        }
    };
    private IUiNotify notify_Main_786 = new IUiNotify() { // from class: com.syu.app.App.3
        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) {
            for (IUiNotify uiNotify : App.mListUiNotify_Main_786) {
                uiNotify.onNotify(updateCode, ints, flts, strs);
            }
        }
    };
    private IUiNotify notify_Bt = new IUiNotify() { // from class: com.syu.app.App.4
        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) {
            for (IUiNotify uiNotify : App.mListUiNotify_Bt) {
                uiNotify.onNotify(updateCode, ints, flts, strs);
            }
        }
    };
    private IUiNotify notify_Main = new IUiNotify() { // from class: com.syu.app.App.5
        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) {
            for (IUiNotify uiNotify : App.mListUiNotify_Main) {
                uiNotify.onNotify(updateCode, ints, flts, strs);
            }
        }
    };
    private IUiNotify notify_Sound = new IUiNotify() { // from class: com.syu.app.App.6
        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) {
            for (IUiNotify uiNotify : App.mListUiNotify_Sound) {
                uiNotify.onNotify(updateCode, ints, flts, strs);
            }
        }
    };
    private IUiNotify notify_Sys = new IUiNotify() { // from class: com.syu.app.App.7
        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) {
            for (IUiNotify uiNotify : App.mListUiNotify_Sys) {
                uiNotify.onNotify(updateCode, ints, flts, strs);
            }
        }
    };

    public static App getApp() {
        return (App) myApp;
    }

    @Override // com.lsec.core.frame.app.MyApplication, android.app.Application
    public void onCreate() throws Throwable {
        mMusicCarType = SystemProperties.get("persist.lsec.bbatype", "");
        ReadConf();
        setThemeColor();
        App_Music.mUpdateAppWidget = new IUpdateAppWidget() { // from class: com.syu.app.App.8
            @Override // com.lsec.core.util.IUpdateAppWidget
            public void onCreate() {
                App_MusicAction.onCreate();
            }

            @Override // com.lsec.core.util.IUpdateAppWidget
            public void updateAppWidget() {
                LocalBroadcastManager.getInstance(MyApplication.myApp).sendBroadcast(new Intent(MService.APP_WIDGET_UPDATE));
                App_MusicAction.updateLauncher(App_Music.mId3Info.strTitle, App_Music.mId3Info.strArtist, App_Music.mId3Info.strAlbum, App_Music.myMediaPlayer.mCurrent, App_Music.myMediaPlayer.mDuration, App_Music.myMediaPlayer.isPlaying(), App_Music.myMediaPlayer.mPlayPath);
            }
        };
        super.onCreate();
        App_Music.getInstance().onCreate(this);
        this.mRunnable_InitIpc.run();
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:10:0x0036, code lost:
    
        com.lsec.core.frame.app.MyApplication.mStrFolderAsset = com.syu.app.App.mMusicCarType;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0041, code lost:
    
        if (r0.equals("bba_bc") == false) goto L4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x004a, code lost:
    
        if (r0.equals("bba_bm") == false) goto L4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0053, code lost:
    
        if (r0.equals("bba_lh") == false) goto L4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x005c, code lost:
    
        if (r0.equals("bba_lkss") == false) goto L4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0065, code lost:
    
        if (r0.equals("bba_id8") == false) goto L4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0034, code lost:
    
        if (r0.equals("bba_ad") != false) goto L10;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void setThemeColor() {
        /*
            r3 = this;
            java.lang.String r0 = "LZP"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "type:"
            r1.<init>(r2)
            java.lang.String r2 = com.syu.app.App.mMusicCarType
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.d(r0, r1)
            java.lang.String r0 = com.syu.app.App.mMusicCarType
            int r1 = r0.hashCode()
            switch(r1) {
                case -1395821311: goto L2e;
                case -1395821281: goto L3b;
                case -1395821271: goto L44;
                case -1395820966: goto L4d;
                case -1354145411: goto L56;
                case -320779937: goto L5f;
                default: goto L1f;
            }
        L1f:
            java.lang.String r0 = com.syu.app.App.mExtraProperty
            java.lang.String r1 = "bba_bm"
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L2d
            java.lang.String r0 = com.syu.app.App.mExtraProperty
            com.lsec.core.frame.app.MyApplication.mStrFolderAsset = r0
        L2d:
            return
        L2e:
            java.lang.String r1 = "bba_ad"
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L1f
        L36:
            java.lang.String r0 = com.syu.app.App.mMusicCarType
            com.lsec.core.frame.app.MyApplication.mStrFolderAsset = r0
            goto L2d
        L3b:
            java.lang.String r1 = "bba_bc"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L36
            goto L1f
        L44:
            java.lang.String r1 = "bba_bm"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L36
            goto L1f
        L4d:
            java.lang.String r1 = "bba_lh"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L36
            goto L1f
        L56:
            java.lang.String r1 = "bba_lkss"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L36
            goto L1f
        L5f:
            java.lang.String r1 = "bba_id8"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L36
            goto L1f
        */
        throw new UnsupportedOperationException("Method not decompiled: com.syu.app.App.setThemeColor():void");
    }

    public void initIpc() {
        if (mIsOldService) {
            Main.mUiNotifyEvent.uiNotify = this.notify_Main_786;
            Bt.mUiNotifyEvent.uiNotify = this.notify_Bt_786;
            this.mMainConn = new Main786(getApp(), getApp(), RegCode.mRegister_Main_786);
            this.mBtConn = new Bt786(getApp(), getApp(), RegCode.mRegister_Bt_786);
            return;
        }
        Main.mUiNotifyEvent.uiNotify = this.notify_Main;
        Sound.mUiNotifyEvent.uiNotify = this.notify_Sound;
        Bt.mUiNotifyEvent.uiNotify = this.notify_Bt;
        Sys.mUiNotifyEvent.uiNotify = this.notify_Sys;
        this.mConn = new Conn(getApp(), getApp());
        this.mConn.addObserver(Main.getInstance(), RegCode.mRegister_Main);
        this.mConn.addObserver(Sound.getInstance(), RegCode.mRegister_Sound);
        this.mConn.addObserver(Bt.getInstance(), RegCode.mRegister_Bt);
        this.mConnSys = new ConnSys(getApp(), getApp());
        this.mConnSys.addObserver(Sys.getInstance(), RegCode.mRegister_Sys);
    }

    public void ReadConf() throws Throwable {
        String str;
        try {
            int id = getResources().getIdentifier("conf_platform", "raw", getPackageName());
            if (id >= 0) {
                String strXml = FuncUtils.readStrFromStream(getResources().openRawResource(id));
                if (!TextUtils.isEmpty(strXml)) {
                    Markup xml = new Markup();
                    xml.ReadXML(strXml);
                    if (xml.IntoItem()) {
                        do {
                            String strTemp = xml.GetAttr(Mp4NameBox.IDENTIFIER);
                            if (strTemp != null) {
                                if (strTemp.equals("platform")) {
                                    String str2 = xml.GetAttr("value");
                                    if (str2 != null) {
                                        Main.initPlatForm(str2);
                                    }
                                } else if (strTemp.equals("old_service")) {
                                    String str3 = xml.GetAttr("value");
                                    if (str3 != null && str3.equals("1")) {
                                        mIsOldService = true;
                                    }
                                } else if (strTemp.equals("customer")) {
                                    String str4 = xml.GetAttr("value");
                                    if (str4 != null) {
                                        mStrCustomer = str4;
                                    }
                                } else if (strTemp.equals("extraProperty") && (str = xml.GetAttr("value")) != null) {
                                    mExtraProperty = str;
                                }
                            }
                        } while (xml.NextItem());
                        xml.ExitItem();
                    }
                }
            }
        } catch (Exception e) {
        }
    }

    @Override // com.lsec.core.frame.app.MyApplication, com.lsec.core.util.InterfaceApp
    public void requestAppIdRight() {
        MyActivity activity = getApp().getTopActivity();
        if (activity != null) {
            activity.requestAppIdRight();
        }
    }

    @Override // com.lsec.core.frame.app.MyApplication, com.lsec.core.util.InterfaceApp
    public void onConnected_Main() {
        for (IConnectedMain connectedMain : mListConnectedMain) {
            connectedMain.onConnected_Main();
        }
    }

    @Override // com.lsec.core.frame.app.MyApplication
    public void jumpAct(String strName) {
        if ("Music".equals(strName)) {
            File file = new File(App_Music.myMediaPlayer.mPlayPath);
            if (file.exists()) {
                MyApplication.sPage_WillBe = FinalMusicCtrl.Page_Player;
            } else {
                MyApplication.sPage_WillBe = FinalMusicCtrl.Page_Grid;
            }
            startAct(Activity_All.class);
        }
    }
}
