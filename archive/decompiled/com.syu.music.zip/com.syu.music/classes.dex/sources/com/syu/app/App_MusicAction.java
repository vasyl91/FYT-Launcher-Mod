package com.syu.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import com.lsec.core.frame.app.MyApplication;
import com.syu.music.MService;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class App_MusicAction {
    static List<String> launcherNames = new ArrayList();

    public static void onCreate() {
        launcherNames = getLauncher();
        MyApplication.myApp.startServiceSafely(new Intent(MyApplication.myApp, (Class<?>) MService.class));
    }

    public static void updateLauncher(String title, String artist, String album, long current, long total, boolean state, String playpath) {
        Intent intent = new Intent(MService.INTENT_MUSIC_LAUNCHER);
        Bundle bundle = new Bundle();
        bundle.putBoolean(MService.PLAY_STATE, state);
        bundle.putString(MService.PLAY_TITLE, title);
        bundle.putString(MService.PLAY_ARTIST, artist);
        bundle.putString(MService.PLAY_ALBUM, album);
        bundle.putLong(MService.PLAY_CURRENT, current);
        bundle.putLong(MService.PLAY_TOTAL, total);
        bundle.putString(MService.PLAY_PATH, playpath);
        intent.putExtras(bundle);
        if (isExitMusicAndTimeWidget()) {
            intent.setPackage("com.syu.widget.music");
            MyApplication.myApp.startServiceSafely(intent);
        }
        String launcher = getLauncherPackageName(MyApplication.myApp);
        if (launcher != null) {
            intent.setPackage(launcher);
            MyApplication.myApp.startServiceSafely(intent);
        }
        if (isExitMusicAndWindowApp()) {
            intent.setPackage("com.syu.window");
            MyApplication.myApp.startServiceSafely(intent);
        }
        if (isExitMusicAndTimeWidget_KYD()) {
            intent.setPackage("com.ava.car");
            MyApplication.myApp.startServiceSafely(intent);
        }
        if ((App_Music.mStrCustomer.equalsIgnoreCase("TZY_MUSIC5") || App_Music.mStrCustomer.equalsIgnoreCase("TZY_MUSIC_NEW") || App_Music.mStrCustomer.equalsIgnoreCase("TZY_MUSIC4")) && isExitTzyApplication()) {
            intent.setPackage("cn.teyes.online");
            MyApplication.myApp.startServiceSafely(intent);
        }
    }

    static boolean isExitMusicAndTimeWidget() {
        PackageManager pm = MyApplication.myApp.getPackageManager();
        List<PackageInfo> pinfo = pm.getInstalledPackages(0);
        for (PackageInfo p : pinfo) {
            if ("com.syu.widget.music".equals(p.packageName)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isExitTzyApplication() {
        PackageManager pm = MyApplication.myApp.getPackageManager();
        List<PackageInfo> pinfo = pm.getInstalledPackages(0);
        for (PackageInfo p : pinfo) {
            if ("cn.teyes.online".equals(p.packageName)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isExitMusicAndTimeWidget_KYD() {
        PackageManager pm = MyApplication.myApp.getPackageManager();
        List<PackageInfo> pinfo = pm.getInstalledPackages(0);
        for (PackageInfo p : pinfo) {
            if ("com.ava.car".equals(p.packageName)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isExitMusicAndWindowApp() {
        PackageManager pm = MyApplication.myApp.getPackageManager();
        List<PackageInfo> pinfo = pm.getInstalledPackages(0);
        for (PackageInfo p : pinfo) {
            if ("com.syu.window".equals(p.packageName)) {
                return true;
            }
        }
        return false;
    }

    public static String getLauncherPackageName(Context context) {
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        ResolveInfo res = context.getPackageManager().resolveActivity(intent, 0);
        if (res == null || res.activityInfo == null || res.activityInfo.packageName.equals("android")) {
            return null;
        }
        return res.activityInfo.packageName;
    }

    static List<String> getLauncher() {
        List<String> names = new ArrayList<>();
        PackageManager pm = MyApplication.myApp.getPackageManager();
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        List<ResolveInfo> resolveInfo = pm.queryIntentActivities(intent, 65536);
        for (ResolveInfo i : resolveInfo) {
            names.add(i.activityInfo.packageName);
        }
        return names;
    }
}
