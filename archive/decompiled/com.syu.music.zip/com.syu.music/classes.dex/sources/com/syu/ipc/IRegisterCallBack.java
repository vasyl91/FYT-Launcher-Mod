package com.syu.ipc;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public interface IRegisterCallBack {
    void register(ICallback iCallback);
}
