package com.syu.app.ipc;

import com.lsec.core.frame.app.MyApplication;
import com.syu.app.App_Music;
import com.syu.media.page.Page_BtAv;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class IpcObj {
    Ipc_786 mIpc_786 = new Ipc_786();
    Ipc_New mIpc_New = new Ipc_New();

    public void initIpc() {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.initIpc();
        } else {
            this.mIpc_New.initIpc();
        }
    }

    public int getRightAppId() {
        return MyApplication.mIsOldService ? this.mIpc_786.getRightAppId() : this.mIpc_New.getRightAppId();
    }

    public static boolean isAccOn() {
        return MyApplication.mIsOldService ? Ipc_786.isAccOn() : Ipc_New.isAccOn();
    }

    public boolean isRightAppId() {
        return MyApplication.mIsOldService ? this.mIpc_786.isRightAppId() : this.mIpc_New.isRightAppId();
    }

    public boolean isAppIdAudio() {
        return MyApplication.mIsOldService ? this.mIpc_786.isAppIdAudio() : this.mIpc_New.isAppIdAudio();
    }

    public void TransmitPos() {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.TransmitPos();
        } else {
            this.mIpc_New.TransmitPos();
        }
    }

    public void TransmitIndex(int currentPos, int TotalCount) {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.TransmitIndex(currentPos, TotalCount);
        } else {
            this.mIpc_New.TransmitIndex(currentPos, TotalCount);
        }
    }

    public void TransmitArtist() {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.TransmitArtist();
        } else {
            this.mIpc_New.TransmitArtist();
        }
    }

    public void TransmitAlbum() {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.TransmitAlbum();
        } else {
            this.mIpc_New.TransmitAlbum();
        }
    }

    public void TransmitTitle(int iPosName) {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.TransmitTitle(iPosName);
        } else {
            this.mIpc_New.TransmitTitle(iPosName);
        }
    }

    public void TransmitFolder(int iPosName) {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.TransmitFolder(iPosName);
        } else {
            this.mIpc_New.TransmitFolder(iPosName);
        }
    }

    public void TransmitPlayState() {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.TransmitPlayState();
        } else {
            this.mIpc_New.TransmitPlayState();
        }
    }

    public void TransmitCycleMode() {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.TransmitCycleMode();
        } else {
            this.mIpc_New.TransmitCycleMode();
        }
    }

    public void TransmitDevType(int iDevPlay) {
        if (!MyApplication.mIsOldService) {
            this.mIpc_New.TransmitDevType(iDevPlay);
        }
    }

    public void TransmitMediaType() {
        if (!MyApplication.mIsOldService) {
            this.mIpc_New.TransmitMediaType();
        }
    }

    public void requestAppIdNull() {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.requestAppIdNull();
        } else {
            this.mIpc_New.requestAppIdNull();
        }
    }

    public void requestAppIdRight() {
        if (App_Music.bFocus) {
            if (MyApplication.mIsOldService) {
                this.mIpc_786.requestAppIdRight();
            } else {
                this.mIpc_New.requestAppIdRight();
            }
        }
    }

    public void requestAppIdRight_Direct() {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.requestAppIdRight_Direct();
        } else {
            this.mIpc_New.requestAppIdRight_Direct();
        }
    }

    public boolean isMute() {
        return MyApplication.mIsOldService ? this.mIpc_786.isMute() : this.mIpc_New.isMute();
    }

    public int getVolume() {
        return MyApplication.mIsOldService ? this.mIpc_786.getVolume() : this.mIpc_New.getVolume();
    }

    public float getElectricValue() {
        return this.mIpc_New.getElectricValue();
    }

    public void EnableGainSpec() {
        this.mIpc_New.EnableGainSpec();
    }

    public void DisableGainSpec() {
        this.mIpc_New.DisableGainSpec();
    }

    public static boolean isBtDisConnect() {
        return MyApplication.mIsOldService ? Ipc_786.isBtDisConnect() : Ipc_New.isBtDisConnect();
    }

    public static void SetStandBy() {
        if (MyApplication.mIsOldService) {
            Ipc_786.SetStandBy();
        } else {
            Ipc_New.SetStandBy();
        }
    }

    public static void BtAvPrev() {
        if (MyApplication.mIsOldService) {
            Ipc_786.BtAvPrev();
        } else {
            Ipc_New.BtAvPrev();
        }
    }

    public static void BtAvNext() {
        if (MyApplication.mIsOldService) {
            Ipc_786.BtAvNext();
        } else {
            Ipc_New.BtAvNext();
        }
    }

    public static void BtAvPlayPause() {
        if (MyApplication.mIsOldService) {
            Ipc_786.BtAvPlayPause();
        } else {
            Ipc_New.BtAvPlayPause();
        }
    }

    public static void BtAvPlay() {
        if (MyApplication.mIsOldService) {
            Ipc_786.BtAvPlay();
        } else {
            Ipc_New.BtAvPlay();
        }
    }

    public static void BtAvPause() {
        if (MyApplication.mIsOldService) {
            Ipc_786.BtAvPause();
        } else {
            Ipc_New.BtAvPause();
        }
    }

    public static void BtAvStop() {
        if (MyApplication.mIsOldService) {
            Ipc_786.BtAvStop();
        } else {
            Ipc_New.BtAvStop();
        }
    }

    public void updateNotify_BtAv() {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.updateNotify_BtAv();
        } else {
            this.mIpc_New.updateNotify_BtAv();
        }
    }

    public void onNotify_Bt(Page_BtAv page_BtAv, int updateCode, int[] ints, float[] flts, String[] strs) {
        if (MyApplication.mIsOldService) {
            this.mIpc_786.mNotify.onNotify_Bt(page_BtAv, updateCode, ints, flts, strs);
        } else {
            this.mIpc_New.mNotify.onNotify_Bt(page_BtAv, updateCode, ints, flts, strs);
        }
    }
}
