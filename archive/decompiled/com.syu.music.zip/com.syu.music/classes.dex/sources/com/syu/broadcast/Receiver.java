package com.syu.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.lsec.core.frame.app.MyApplication;
import com.lsec.core.ipc.module.main.Main;
import com.syu.app.App_Music;
import com.syu.app.ipc.IpcObj;
import com.syu.media.core.MediaInfo;
import com.syu.media.core.MyMediaPlayer;
import com.syu.music.Interface_Music;
import com.syu.util.Util;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class Receiver extends BroadcastReceiver {
    public static final String ACTION_AMAPASSIST_CMD = "AMAPASSIST_STANDARD_BROADCAST_CMD";
    public static final String ACTION_CHANGE_COLOR = "launcher3.setcolor";
    public static final String ACTION_EASYCONN_BREAK = "net.easyconn.usb.break";
    public static final String REMOVE_BROADCAST = "com.fyt.systemui.remove";
    public static final String RESUME_SCAN = "com.syu.video.scan";
    public static boolean bResumeScan = true;
    RunnableHandleAmapAssistCmd mRunnableHandleAmapAssistCmd = null;

    public void handleAmapAssistCmd(Bundle bundle) {
        if (bundle.containsKey("CMD_DESC") && bundle.containsKey("CMD_TYPE")) {
            int type = bundle.getInt("CMD_TYPE");
            if (type == 10000) {
                String strCmd = bundle.getString("CMD_DESC");
                if (strCmd.startsWith("删除当前播放音乐")) {
                    App_Music.getInstance().delCurrentFile();
                }
            }
        }
    }

    public class RunnableHandleAmapAssistCmd implements Runnable {
        boolean bRun = true;
        Bundle bundle;

        public void stopRun() {
            this.bRun = false;
        }

        public RunnableHandleAmapAssistCmd(Bundle bundle) {
            this.bundle = bundle;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.bRun) {
                Receiver.this.handleAmapAssistCmd(this.bundle);
            }
        }
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) throws Throwable {
        String action = intent.getAction();
        boolean bMount = false;
        boolean bUnMount = false;
        if (action.equals("android.intent.action.MEDIA_MOUNTED")) {
            bMount = true;
        } else if (action.equals("android.intent.action.MEDIA_REMOVED") || action.equals("android.intent.action.MEDIA_BAD_REMOVAL") || action.equals("android.intent.action.MEDIA_UNMOUNTED") || action.equals("android.intent.action.MEDIA_EJECT")) {
            Log.d(App_Music.TAG, "onReceive action: " + action);
            bUnMount = true;
        } else if (REMOVE_BROADCAST.equals(action)) {
            Bundle bundle = intent.getExtras();
            if (bundle != null && !bundle.isEmpty()) {
                handleRemoveTask(bundle);
            } else {
                return;
            }
        } else if (RESUME_SCAN.equals(action)) {
            Log.d(App_Music.TAG, "onReceive RESUME_SCAN.equals(action)");
            bResumeScan = true;
        } else if (ACTION_AMAPASSIST_CMD.equals(action)) {
            Bundle bundle2 = intent.getExtras();
            if (bundle2 != null && !bundle2.isEmpty()) {
                if (this.mRunnableHandleAmapAssistCmd != null) {
                    this.mRunnableHandleAmapAssistCmd.stopRun();
                    Main.removeRunnable_Ui(this.mRunnableHandleAmapAssistCmd);
                    this.mRunnableHandleAmapAssistCmd = null;
                }
                this.mRunnableHandleAmapAssistCmd = new RunnableHandleAmapAssistCmd(bundle2);
                Main.postRunnable_Ui(false, this.mRunnableHandleAmapAssistCmd);
            } else {
                return;
            }
        }
        if ((bMount || bUnMount) && App_Music.sPage_Music != 110020) {
            String path = intent.getData().getPath();
            Log.d(App_Music.TAG, "path:" + path);
            boolean bUsbMountOrUnMount786 = false;
            if (Main.mConf_PlatForm == 4 && path.startsWith("/mnt/usb")) {
                bUsbMountOrUnMount786 = true;
            }
            if (bUsbMountOrUnMount786 && bMount) {
                App_Music.getInstance().setUsbPath786();
            }
            int iDev = MediaInfo.getDev(path);
            Log.d(App_Music.TAG, "iDev:" + iDev + ",bMount:" + bMount);
            if (iDev >= 0 && iDev < 26) {
                MountOrUnMount(path, bUsbMountOrUnMount786, bMount, iDev);
            }
        }
    }

    private void handleRemoveTask(Bundle bundle) {
        if (!App_Music.getInstance().isAppTop() && MyApplication.myApp.getPackageName().equals(bundle.getString("pkg"))) {
            App_Music.bOnKeyBack = true;
            App_Music.myMediaPlayer.end(true);
            App_Music.getInstance().mIpcObj.requestAppIdNull();
        }
    }

    public static class RunnableMountOrUnMount implements Runnable {
        private boolean bMount;
        private boolean bUsbMountOrUnMount786;
        private int iDev;
        private String path;

        public RunnableMountOrUnMount(String path, boolean bUsbMountOrUnMount786, boolean bMount, int iDev) {
            this.path = path;
            this.bUsbMountOrUnMount786 = bUsbMountOrUnMount786;
            this.bMount = bMount;
            this.iDev = iDev;
        }

        @Override // java.lang.Runnable
        public void run() throws Throwable {
            Util.writeLogToFile("bMount:" + this.bMount);
            if (!this.bMount) {
                App_Music.getInstance().handleUnMount(this.iDev);
                for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                    interface_Music.handleUnMount(this.iDev);
                }
                if (this.bUsbMountOrUnMount786) {
                    if (this.path.equals(App_Music.Path_USB[0])) {
                        App_Music.Path_USB[0] = "/xxxx";
                    } else if (this.path.equals(App_Music.Path_USB[1])) {
                        App_Music.Path_USB[1] = "/xxxx";
                    } else if (this.path.equals(App_Music.Path_USB[2])) {
                        App_Music.Path_USB[2] = "/xxxx";
                    } else if (this.path.equals(App_Music.Path_USB[3])) {
                        App_Music.Path_USB[3] = "/xxxx";
                    }
                    App_Music.getInstance().setUsbPath786();
                }
            } else {
                for (Interface_Music interface_Music2 : App_Music.mInterface_Musics) {
                    interface_Music2.handleMountOrMount();
                }
                App_Music.is7731UsbSwitch = false;
                Log.d(App_Music.TAG, "isAppIdAudio" + App_Music.getInstance().mIpcObj.isAppIdAudio() + ",IpcObj.isAccOn()" + IpcObj.isAccOn());
                if (App_Music.getInstance().mIpcObj.isAppIdAudio() && IpcObj.isAccOn()) {
                    Log.d(App_Music.TAG, "App_Music.getInstance().mIpcObj.isAppIdAudio() && IpcObj.isAccOn()");
                    App_Music.scanFile(this.iDev, App_Music.bAutoPlayWhenMount);
                    if (MyMediaPlayer.bNoPlay && this.iDev == MediaInfo.getDev(App_Music.myMediaPlayer.mPlayPath)) {
                        Log.d(App_Music.TAG, "App_Music.myMediaPlayer.mPlayPath:" + App_Music.myMediaPlayer.mPlayPath);
                        App_Music.getInstance().playFile(App_Music.myMediaPlayer.mPlayPath, false);
                        for (Interface_Music interface_Music3 : App_Music.mInterface_Musics) {
                            interface_Music3.devSelectUpdate(this.iDev);
                        }
                        return;
                    }
                } else {
                    Receiver.bResumeScan = true;
                }
            }
            for (Interface_Music interface_Music4 : App_Music.mInterface_Musics) {
                interface_Music4.handleMountOrMount();
            }
        }
    }

    public static void MountOrUnMount(String path, boolean bUsbMountOrUnMount786, boolean bMount, int iDev) {
        if (App_Music.getInstance() != null) {
            if (bMount) {
                MediaInfo.setMountState(iDev, 1);
                if (iDev == 24) {
                    App_Music.bMountedCdRom = true;
                    App_Music.bInsertCdRom = true;
                }
            } else if (MediaInfo.getMountState(iDev) != -1) {
                boolean bCleared = false;
                if (Util.is7731()) {
                    switch (iDev) {
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                            bCleared = true;
                            clearDev(3);
                            clearDev(4);
                            clearDev(5);
                            clearDev(6);
                            break;
                    }
                }
                if (!bCleared) {
                    clearDev(iDev);
                }
            } else {
                return;
            }
            Main.postRunnable_Ui(false, new RunnableMountOrUnMount(path, bUsbMountOrUnMount786, bMount, iDev));
        }
    }

    public static void clearDev(int iDev) {
        MediaInfo.setMountState(iDev, -1);
        MediaInfo.setEndScan(iDev, true);
        MediaInfo.clear(iDev);
    }
}
