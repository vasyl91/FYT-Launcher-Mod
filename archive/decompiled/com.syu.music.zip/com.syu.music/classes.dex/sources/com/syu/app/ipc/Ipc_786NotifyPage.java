package com.syu.app.ipc;

import android.view.View;
import com.lsec.core.frame.ctrl.JText;
import com.lsec.core.ipc.module.main.Bt;
import com.syu.media.ctrl.JPinBar;
import com.syu.media.ctrl.JRotView;
import com.syu.media.data.FinalMusicCtrl;
import com.syu.media.page.Page_BtAv;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class Ipc_786NotifyPage {
    public void onNotify_Bt(Page_BtAv page_Av, int updateCode, int[] ints, float[] flts, String[] strs) {
        switch (updateCode) {
            case 1:
                if (IpcObj.isBtDisConnect()) {
                    JText text = (JText) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Txt_Title);
                    if (text != null) {
                        text.setText("");
                    }
                    JText text2 = (JText) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Txt_Artist);
                    if (text2 != null) {
                        text2.setText("");
                    }
                    View viewId3Info = page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Id3Info);
                    if (viewId3Info != null) {
                        viewId3Info.setVisibility(8);
                    }
                    page_Av.misAvStop = false;
                }
                break;
            case 4:
                int value = Bt.DATA[updateCode];
                boolean bRun = false;
                if (!IpcObj.isBtDisConnect() && value == 1) {
                    bRun = true;
                }
                JRotView rotCd = (JRotView) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_RotCd);
                JPinBar pinBar = (JPinBar) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_PinBar);
                if (rotCd != null) {
                    rotCd.updateRotateAniState(bRun);
                }
                if (pinBar != null) {
                    pinBar.setRun(bRun);
                }
                boolean bId3InfoGone = false;
                if (value == 0 && page_Av.misAvStop) {
                    bId3InfoGone = true;
                }
                View viewId3Info2 = page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Id3Info);
                if (viewId3Info2 != null) {
                    if (bId3InfoGone) {
                        viewId3Info2.setVisibility(8);
                    } else {
                        viewId3Info2.setVisibility(0);
                    }
                }
                break;
            case 18:
                String title = Bt.sId3Title;
                JText text3 = (JText) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Txt_Title);
                if (text3 != null) {
                    text3.setText(title);
                }
                break;
            case 19:
                String artist = Bt.sId3Artist;
                JText text4 = (JText) page_Av.getPage().getChildViewByid(FinalMusicCtrl.BtAv_Txt_Artist);
                if (text4 != null) {
                    text4.setText(artist);
                }
                break;
        }
    }
}
