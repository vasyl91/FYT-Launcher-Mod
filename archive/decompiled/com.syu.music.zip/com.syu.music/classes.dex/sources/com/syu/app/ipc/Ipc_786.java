package com.syu.app.ipc;

import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import com.lsec.core.frame.app.MyApplication;
import com.lsec.core.ipc.module.main.Bt;
import com.lsec.core.ipc.module.main.Main;
import com.lsec.core.ipc786.module.Bt786;
import com.lsec.core.ipc786.module.Main786;
import com.lsec.core.ipc786.module.Sound786;
import com.lsec.core.util.IUiNotify;
import com.lsec.core.util.IpcUtil;
import com.lsec.core.util.data.Ipc786_FinalMain;
import com.syu.app.App_Music;
import com.syu.media.core.MediaInfo;
import com.syu.media.core.MyMediaPlayer;
import com.syu.media.data.FinalMusicCtrl;
import com.syu.music.Interface_Music;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class Ipc_786 {
    static final int[] NOTIFYCODE_Main_786 = {3, 25};
    static final int[] NOTIFYCODE_Main_786_Will = {27, 0, 41, 70};
    public static final int[] NOTIFYCODE_BtAV = {2, 18, 19, 1};
    public Main786 mMainConn = null;
    public Sound786 mSoundConn = null;
    public Bt786 mBtConn = null;
    public Ipc_786NotifyPage mNotify = new Ipc_786NotifyPage();
    IUiNotify notify_Main_786 = new IUiNotify() { // from class: com.syu.app.ipc.Ipc_786.1
        boolean bAppIdAudioBak = false;
        boolean bAccOnBak = false;
        boolean bWakeupBak = false;

        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) {
            int index;
            SparseArray<String> map;
            switch (updateCode) {
                case 0:
                    if (IpcUtil.intsOk(ints, 1)) {
                        boolean bAccOn = ints[0] != 0;
                        if (this.bAccOnBak != bAccOn) {
                            if (!bAccOn) {
                                App_Music.myMediaPlayer.end(true);
                                for (int iDev = 0; iDev < 26; iDev++) {
                                    MediaInfo.setEndScan(iDev, true);
                                    MediaInfo.clear(iDev);
                                }
                                App_Music.listPlay.clear();
                                App_Music.getInstance().backToList();
                                App_Music.bResumeLastPlayOnce = false;
                                App_Music.bScanFileCntOver = false;
                            } else {
                                if (MyMediaPlayer.bReOpenAfterAccOn) {
                                    MyMediaPlayer.bReOpenAfterAccOn = false;
                                    App_Music.myMediaPlayer.openPlayer();
                                }
                                Main.postRunnable_Ui(true, App_Music.getInstance().mRunnable_ScanFile, 2000L);
                            }
                            this.bAccOnBak = bAccOn;
                        }
                    }
                    break;
                case 3:
                case 25:
                    boolean bAppIdAudio = Ipc_786.this.isAppIdAudio();
                    Log.d(App_Music.TAG, "bAppIdAudio: " + bAppIdAudio);
                    if (bAppIdAudio != this.bAppIdAudioBak) {
                        if (bAppIdAudio) {
                            App_Music.scanFile(26, false);
                        }
                        if (!bAppIdAudio) {
                            if (App_Music.myMediaPlayer.isPlaying()) {
                                App_Music.getInstance().pause();
                            } else {
                                App_Music.bPausedByChangeAppId = false;
                            }
                        } else if (App_Music.bPausedByChangeAppId) {
                            App_Music.bPausedByChangeAppId = false;
                            if (!MyMediaPlayer.bNoPlay) {
                                App_Music.getInstance().play();
                            }
                        }
                        if (bAppIdAudio) {
                            if (MyMediaPlayer.bReOpenAfterRightAppId) {
                                MyMediaPlayer.bReOpenAfterRightAppId = false;
                                App_Music.myMediaPlayer.openPlayer();
                            } else if (MyMediaPlayer.bReOpenAfterAccOn) {
                                MyMediaPlayer.bReOpenAfterAccOn = false;
                                App_Music.myMediaPlayer.openPlayer();
                            }
                        }
                        this.bAppIdAudioBak = bAppIdAudio;
                    }
                    break;
                case 27:
                    if (IpcUtil.intsOk(ints, 2) && App_Music.getInstance().mIpcObj.isAppIdAudio() && ints[0] == 1) {
                        int value = ints[1];
                        switch (value) {
                            case 0:
                                App_Music.getInstance().playPause();
                                break;
                            case 1:
                                App_Music.getInstance().switchMedia(-1);
                                break;
                            case 2:
                                App_Music.getInstance().switchMedia(1);
                                break;
                            case 3:
                                App_Music.getInstance().play();
                                break;
                            case 4:
                                App_Music.getInstance().pause();
                                break;
                        }
                    }
                    break;
                case 41:
                    if (IpcUtil.intsOk(ints, 1) && Ipc_786.this.isAppIdAudio()) {
                        boolean bWakeup = ints[0] != 0;
                        if (this.bWakeupBak != bWakeup) {
                            if (!bWakeup) {
                                if (App_Music.myMediaPlayer.isPlaying()) {
                                    App_Music.bPausedBySleep = true;
                                    App_Music.getInstance().pause();
                                }
                            } else if (App_Music.bPausedBySleep) {
                                App_Music.bPausedBySleep = false;
                                if (!MyMediaPlayer.bNoPlay) {
                                    App_Music.getInstance().play();
                                }
                            }
                            this.bWakeupBak = bWakeup;
                        }
                        break;
                    }
                    break;
                case 70:
                    if (IpcUtil.intsOk(ints, 2) && ints[0] == 1 && (index = ints[0]) >= 0 && index < App_Music.listPlay.size() && (map = App_Music.listPlay.get(index)) != null) {
                        String strPath = map.get(FinalMusicCtrl.GridItem_Path);
                        if (!TextUtils.isEmpty(strPath)) {
                            App_Music.getInstance().playFile(strPath, false);
                        }
                        break;
                    }
                    break;
            }
        }
    };
    IUiNotify notify_Bt = new IUiNotify() { // from class: com.syu.app.ipc.Ipc_786.2
        @Override // com.lsec.core.util.IUiNotify
        public void onNotify(int updateCode, int[] ints, float[] flts, String[] strs) {
            for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                interface_Music.onNotify_Bt(updateCode, ints, flts, strs);
            }
        }
    };

    public void initIpc() {
        MyApplication.mListUiNotify_Main_786.add(this.notify_Main_786);
        MyApplication.mListUiNotify_Bt_786.add(this.notify_Bt);
    }

    public boolean isMute() {
        return Main.DATA[1] == 1 || Main.DATA[2] == 0;
    }

    public int getVolume() {
        return Main.DATA[2];
    }

    public boolean isRightAppId() {
        if (App_Music.mUsedInMobilePhone) {
            return true;
        }
        return Main.DATA[3] == getRightAppId() && Main.DATA[25] == 1;
    }

    public boolean isAppIdAudio() {
        Log.d(App_Music.TAG, "----->>> Ipc_786 Ipc_New isAppIdAudio");
        if (App_Music.mUsedInMobilePhone) {
            Log.d(App_Music.TAG, "----->>> App_Music.mUsedInMobilePhone: true");
            return true;
        }
        if (Main.DATA[3] == 12) {
            Log.d(App_Music.TAG, "----->>> U_CHANNEL: true");
            return true;
        }
        return false;
    }

    public int getRightAppId() {
        return App_Music.sPage_Music == 110020 ? 9 : 12;
    }

    public void requestAppIdNull() {
        if (isRightAppId()) {
            Main786.requestAppId(11);
        }
    }

    public void requestAppIdRight() {
        Main786.requestAppIdByOnTop(getRightAppId());
        Main786.cmdStatic(15, new int[]{1}, null, null);
    }

    public void requestAppIdRight_Direct() {
        Main786.requestAppId(getRightAppId());
        Main786.cmdStatic(15, new int[]{1}, null, null);
    }

    public void TransmitPos() {
        int[] iArr = new int[2];
        iArr[0] = App_Music.myMediaPlayer.mCurrent < 0 ? 0 : App_Music.myMediaPlayer.mCurrent / 1000;
        iArr[1] = App_Music.myMediaPlayer.mDuration >= 0 ? App_Music.myMediaPlayer.mDuration / 1000 : 0;
        Main786.cmdStatic(31, iArr, null, null);
    }

    public void TransmitIndex(int currentPos, int TotalCount) {
        int[] iArr = new int[2];
        if (currentPos < 0) {
            currentPos = 0;
        }
        iArr[0] = currentPos;
        iArr[1] = TotalCount >= 0 ? TotalCount : 0;
        Main786.cmdStatic(30, iArr, null, null);
    }

    public void TransmitArtist() {
        Main786.cmdStatic(Ipc786_FinalMain.C_CAR_ID3_ARTIST, null, null, new String[]{App_Music.mId3Info.strArtist});
    }

    public void TransmitAlbum() {
        Main786.cmdStatic(10001, null, null, new String[]{App_Music.mId3Info.strAlbum});
    }

    public void TransmitTitle(int iPosName) {
        String title = App_Music.myMediaPlayer.mPlayPath.substring(iPosName + 1);
        Main786.cmdStatic(10000, null, null, new String[]{title});
    }

    public void TransmitFolder(int iPosName) {
        String strFolder;
        int iPosFolder;
        if (isAppIdAudio() && (iPosFolder = (strFolder = App_Music.myMediaPlayer.mPlayPath.substring(0, iPosName)).lastIndexOf("/")) >= 0) {
            String folderName = strFolder.substring(iPosFolder + 1);
            Main786.cmdStatic(Ipc786_FinalMain.C_CAR_FLODER_NAME, null, null, new String[]{folderName});
        }
    }

    public void TransmitPlayState() {
        if (isAppIdAudio()) {
            int[] iArr = new int[2];
            iArr[0] = 1;
            iArr[1] = App_Music.myMediaPlayer.isPlaying() ? 1 : 2;
            Main786.cmdStatic(45, iArr, null, null);
        }
    }

    public void TransmitCycleMode() {
        if (isAppIdAudio()) {
            int[] iArr = new int[1];
            iArr[0] = MediaInfo.mCycleMode < 0 ? 0 : MediaInfo.mCycleMode;
            Main786.cmdStatic(71, iArr, null, null);
        }
    }

    public static boolean isAccOn() {
        return Main.DATA[0] != 0;
    }

    public static boolean isDisConnect(int iState) {
        switch (iState) {
            case 0:
            case 2:
            case 3:
                return true;
            case 1:
            default:
                return false;
        }
    }

    public static boolean isBtDisConnect() {
        return isDisConnect(Bt.DATA[1]);
    }

    public static void SetStandBy() {
        Main786.cmdStatic(18, new int[]{1}, null, null);
    }

    public static void BtAvPrev() {
        Bt786.cmdBt(26, -2, null);
    }

    public static void BtAvNext() {
        Bt786.cmdBt(31, -2, null);
    }

    public static void BtAvPlayPause() {
        Bt786.cmdBt(29, -2, null);
    }

    public static void BtAvPlay() {
        Bt786.cmdBt(27, -2, null);
    }

    public static void BtAvPause() {
        Bt786.cmdBt(28, -2, null);
    }

    public static void BtAvStop() {
        Bt786.cmdBt(30, -2, null);
    }

    public void updateNotify_BtAv() {
        for (int updateCode : NOTIFYCODE_BtAV) {
            for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                interface_Music.onNotify_Bt(updateCode, null, null, null);
            }
        }
    }
}
