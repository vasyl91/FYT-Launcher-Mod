package com.syu.cover;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.support.v4.view.ViewCompat;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class BitmapUtils {
    public static Bitmap createReflectedBitmap(Bitmap srcBitmap, float reflectHeight) {
        if (srcBitmap == null) {
            return null;
        }
        int srcWidth = srcBitmap.getWidth();
        int srcHeight = srcBitmap.getHeight();
        int reflectionWidth = srcBitmap.getWidth();
        int reflectionHeight = reflectHeight == 0.0f ? srcHeight / 3 : (int) (srcHeight * reflectHeight);
        if (srcWidth == 0 || srcHeight == 0) {
            return null;
        }
        Matrix matrix = new Matrix();
        matrix.preScale(1.0f, -1.0f);
        try {
            Bitmap reflectionBitmap = Bitmap.createBitmap(srcBitmap, 0, srcHeight - reflectionHeight, reflectionWidth, reflectionHeight, matrix, false);
            if (reflectionBitmap == null) {
                return null;
            }
            Canvas canvas = new Canvas(reflectionBitmap);
            Paint paint = new Paint();
            paint.setAntiAlias(true);
            LinearGradient shader = new LinearGradient(0.0f, 0.0f, 0.0f, reflectionBitmap.getHeight(), 1895825407, ViewCompat.MEASURED_SIZE_MASK, Shader.TileMode.MIRROR);
            paint.setShader(shader);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            canvas.drawRect(0.0f, 0.0f, reflectionBitmap.getWidth(), reflectionBitmap.getHeight(), paint);
            return reflectionBitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Bitmap drawNewBitmap(Bitmap srcBitmap, String str) {
        if (srcBitmap == null) {
            return null;
        }
        int width = srcBitmap.getWidth();
        int hight = srcBitmap.getHeight();
        Bitmap icon = Bitmap.createBitmap(width, hight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(icon);
        Paint photoPaint = new Paint();
        photoPaint.setDither(true);
        photoPaint.setFilterBitmap(true);
        Rect src = new Rect(0, 0, srcBitmap.getWidth(), srcBitmap.getHeight());
        Rect dst = new Rect(0, 0, width, hight);
        canvas.drawBitmap(srcBitmap, src, dst, photoPaint);
        TextPaint textPaint = myTextPaint();
        drawText(canvas, textPaint, str, width / 10, hight / 3, width);
        canvas.save(31);
        canvas.restore();
        return icon;
    }

    public static TextPaint myTextPaint() {
        TextPaint textPaint = new TextPaint(257);
        int TEXT_SIZE = Math.round(20.0f);
        textPaint.setTextSize(TEXT_SIZE);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setColor(Color.argb(255, 255, 255, 255));
        return textPaint;
    }

    public static void drawText(Canvas canvas, TextPaint Paint, String textString, int x, int y, int width) {
        int start_x = (int) Math.round(((double) x) * 0.8d);
        int start_y = (int) Math.round(((double) y) * 0.8d);
        StaticLayout staticLayout = new StaticLayout(textString, Paint, width - (start_x * 2), Layout.Alignment.ALIGN_CENTER, 1.0f, 0.0f, false);
        canvas.translate(start_x, start_y);
        staticLayout.draw(canvas);
    }
}
