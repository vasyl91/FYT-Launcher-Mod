package com.syu.app;

import android.app.ActivityManager;
import android.app.Application;
import android.app.Instrumentation;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.media.MediaPlayer;
import android.media.audiofx.Visualizer;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemProperties;
import android.os.storage.IMountService;
import android.support.v4.os.EnvironmentCompat;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import android.view.WindowManager;
import com.lsec.core.frame.app.MyApp;
import com.lsec.core.frame.app.MyApplication;
import com.lsec.core.frame.app.MyUi;
import com.lsec.core.ipc.module.main.Main;
import com.lsec.core.util.FuncUtils;
import com.lsec.core.util.IConnectedMain;
import com.lsec.core.util.IUpdateAppWidget;
import com.lsec.core.util.Markup;
import com.lsec.core.util.MyFolder;
import com.lsec.core.util.MySharePreference2;
import com.lsec.core.util.data.FinalCustomer;
import com.syu.app.ipc.IpcObj;
import com.syu.broadcast.Receiver;
import com.syu.broadcast.Receiver_EasyConn;
import com.syu.media.core.DB;
import com.syu.media.core.DataManager;
import com.syu.media.core.ErrorStruct;
import com.syu.media.core.MediaError;
import com.syu.media.core.MediaInfo;
import com.syu.media.core.MyMediaPlayer;
import com.syu.media.core.PlayerCore;
import com.syu.media.data.FinalMusicCtrl;
import com.syu.media.data.FinalMusicType;
import com.syu.media.page.Page_Lrc;
import com.syu.music.Interface_Music;
import com.syu.music.MAudioFocus;
import com.syu.music.MediaManager;
import com.syu.sha.ipc.ITransitService;
import com.syu.sha.ipc.OnCommandListener;
import com.syu.sha.ipc.OnMusicDataListener;
import com.syu.sha.ipc.Song;
import com.syu.util.Constant;
import com.syu.util.DownloadTask;
import com.syu.util.FileHandler;
import com.syu.util.HanziToPinyin;
import com.syu.util.Id3Info;
import com.syu.util.Lrc;
import com.syu.util.MyCoverTask;
import com.syu.util.MyTask;
import com.syu.util.Util;
import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.jaudiotagger.tag.mp4.atom.Mp4NameBox;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class App_Music extends MyApp implements ServiceConnection, IConnectedMain {
    public static final int ALBUM_MAX_COUNT = 20;
    public static final int Action_GetCurrentPos = 1009;
    public static final int Action_GetDuration = 1008;
    public static final int Action_Null = 1010;
    public static final int Action_Pause = 1005;
    public static final int Action_PauseSource = 1001;
    public static final int Action_PlaySource = 1000;
    public static final int Action_ReinitMediaPlayer = 1002;
    public static final int Action_Release = 1003;
    public static final int Action_SeekTo = 1006;
    public static final int Action_Start = 1004;
    public static final int Action_UnMute = 1007;
    public static final String CYCLE_MODE = "cycle_mode";
    public static final String LOG_PATH = "/mnt/sdcard/Music/log";
    public static final String LRC_PATH = "/mnt/sdcard/Music/lrc";
    public static final String MUSIC_PATH = "/mnt/sdcard/Music";
    public static final String PLAYORPAUSE = "play_mode";
    public static String Path_CDROM = null;
    public static String Path_Native = null;
    public static String[] Path_SD = null;
    public static String[] Path_USB = null;
    public static final int SD_CNT = 2;
    public static final String Str_ThreadDownLrc = "downloadlrc";
    public static final String Str_ThreadGetThumb = "getThumbNail";
    public static final String Str_ThreadMedia = "mediaplayer";
    public static final String Str_ThreadScanFile = "scanFile";
    public static final String TAG = "MusicLib";
    public static final int USB_CNT = 21;
    public static boolean bAppMoveToBack;
    public static boolean bAutoPlayWhenMount;
    public static boolean bBtavRuuing;
    public static boolean bEnableSpec;
    public static String bExtraProperty;
    public static boolean bFocus;
    public static boolean bGetDrawableFromDB;
    public static boolean bInsertCdRom;
    public static boolean bIsSpeechList;
    public static boolean bMTU_ShowGridGroup;
    public static boolean bMTU_Style;
    public static boolean bMountedCdRom;
    public static boolean bNoListAlbum;
    public static boolean bOnKeyBack;
    public static boolean bPausedByChangeAppId;
    public static boolean bPausedBySleep;
    public static boolean bPlayNextCausedByError;
    public static boolean bResumeLastPlayOnce;
    public static boolean bSaveAlbumPicInList;
    public static boolean bScanFileCntOver;
    public static boolean bScollToTopPosition;
    public static boolean bSendPlayState;
    public static boolean bSetBtRing;
    public static boolean bShowProgDown;
    public static boolean[] bTmp;
    public static boolean bisplay;
    public static int color;
    public static DataManager dataManager;
    public static int iWorkNextNum;
    public static int iWorkNum;
    public static int iWorkPreNum;
    public static App_Music instance;
    public static boolean is7731UsbSwitch;
    public static List<SparseArray<String>> list;
    public static List<SparseArray<String>> listPlay;
    public static int mActiviteState;
    public static int mAnimeTime;
    public static int mColorType;
    public static String mConf_CDROM;
    public static String[] mConf_USB;
    public static DB mDb;
    public static int mDev;
    public static int mDevPlay;
    public static Id3Info mId3Info;
    public static ArrayList<Interface_Music> mInterface_Musics;
    public static int mListMode;
    public static int mListModePlay;
    public static Lrc mLrc;
    static IMountService mMountService;
    public static String mMusicCarType;
    public static String mPathResume;
    public static String mPathResumeSave;
    public static int mPlay1stPara;
    public static int mPosResumeSave;
    public static Runnable mRunnable_SeekTo;
    public static Runnable mRunnable_hideProgDown;
    public static long mSeekTime;
    public static int mSoundMode;
    public static String mStrCustomer;
    public static int mTDev;
    public static int mTListMode;
    public static int mToastYPlus_FullScreen;
    public static int mToastYPlus_HalfScreen;
    public static int mType;
    public static int mTypePlay;
    public static Visualizer mVisualizer;
    public static HashMap<String, byte[]> myAlbum;
    public static MAudioFocus myAudioFocus;
    public static MyListFolder myListFolder;
    public static MyListFolder myListFolderPlay;
    public static MyMediaPlayer myMediaPlayer;
    public static List<String> myPaths;
    public static int sPage_Music;
    public static int seekPosition;
    private static int seekTimes;
    public static WindowManager windowManager;
    public static List<String> workList;
    public static List<String> workNextList;
    public static List<String> workPreList;
    public Method fytGetState;
    public Method fytSetState;
    Method getExternalSd1Path;
    Method getExternalSd2Path;
    Method getUsb1Path;
    Method getUsb2Path;
    Method getUsb3Path;
    Method getUsb4Path;
    public Handler mHandlerPlay;
    public HandlerThread mHandlerThreadPlay;
    ITransitService mTools;
    public Method mediaplayer_setVolume;
    public static IUpdateAppWidget mUpdateAppWidget = null;
    public static boolean mIsTranslucent = false;
    public static boolean mEnableHalfScreen = false;
    public static boolean mUsedInMobilePhone = false;
    public static boolean mSystemUiNavigationBarTranSparent = false;
    public static int mIdRawDB = -1;
    public static FileHandler mFileHandler = new FileHandler();
    public static List<DownloadTask> mListTaskDown = new ArrayList();
    public static ArrayList<Integer> mListDev = new ArrayList<>();
    public static String[] mConf_SD = new String[2];
    public Message handThreadState = new Message();
    public IpcObj mIpcObj = new IpcObj();
    public String method_SD1 = "getExternalSd1Path";
    public String method_SD2 = "getExternalSd2Path";
    public String method_USB1 = "getUsb1Path";
    public String method_USB2 = "getUsb2Path";
    public String method_USB3 = "getUsb3Path";
    public String method_USB4 = "getUsb4Path";
    public int mediaplayer_setVolume_paranum = 1;
    private Receiver mReceiver = new Receiver();
    private Receiver_EasyConn mReceiver_EasyConn = new Receiver_EasyConn();
    public Runnable mRunnableHandleSeekPos = new Runnable() { // from class: com.syu.app.App_Music.1
        @Override // java.lang.Runnable
        public void run() {
            for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                interface_Music.handleSeekPos();
            }
            if (App_Music.mUpdateAppWidget != null) {
                App_Music.mUpdateAppWidget.updateAppWidget();
            }
        }
    };
    public Runnable mRunnableUpdateDuration = new Runnable() { // from class: com.syu.app.App_Music.2
        @Override // java.lang.Runnable
        public void run() {
            App_Music.this.updateDuration(App_Music.myMediaPlayer.mDuration);
        }
    };
    public Runnable mRunnable_ScanFile = new Runnable() { // from class: com.syu.app.App_Music.3
        @Override // java.lang.Runnable
        public void run() {
            Log.d(App_Music.TAG, "mRunnable_ScanFile");
            App_Music.scanFile(26, false);
        }
    };
    public Runnable_SeekPos mRunnable_SeekPos = null;
    Runnable_setLrcText mRunnable_setLrcText = new Runnable_setLrcText();
    public Runnable mRunnable_reset = new Runnable() { // from class: com.syu.app.App_Music.5
        @Override // java.lang.Runnable
        public void run() {
            for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                interface_Music.reset();
            }
        }
    };
    public Runnable mRunnable_updateInfo = new Runnable() { // from class: com.syu.app.App_Music.6
        @Override // java.lang.Runnable
        public void run() {
            SparseArray<String> child;
            Log.d(App_Music.TAG, "mRunnable_updateInfo:" + App_Music.mListMode);
            if (!TextUtils.isEmpty(App_Music.myMediaPlayer.mPlayPath) && App_Music.isMounted(App_Music.myMediaPlayer.mPlayPath) && FuncUtils.isFileExist(App_Music.myMediaPlayer.mPlayPath)) {
                if (App_Music.mListModePlay == 1 && !App_Music.mDb.isFavorite(App_Music.myMediaPlayer.mPlayPath)) {
                    Log.d(App_Music.TAG, "mRunnable_updateInfo mListModePlay:" + App_Music.mListModePlay);
                    App_Music.mListModePlay = 2;
                    App_Music.updatePlayList(App_Music.myMediaPlayer.mPlayPath);
                }
                App_Music.mDevPlay = MediaInfo.getDev(App_Music.myMediaPlayer.mPlayPath);
                if (App_Music.mDevPlay == 24) {
                    App_Music.myMediaPlayer.mPlayPathDvd = App_Music.myMediaPlayer.mPlayPath;
                }
                Log.d(App_Music.TAG, "mRunnable_updateInfo mDevPlay:" + App_Music.mDevPlay);
                if (MediaInfo.getListIndex(App_Music.listPlay, App_Music.myMediaPlayer.mPlayPath) < 0) {
                    String strName = "";
                    int posStart = App_Music.myMediaPlayer.mPlayPath.lastIndexOf("/");
                    if (posStart >= 0) {
                        strName = App_Music.myMediaPlayer.mPlayPath.substring(posStart + 1);
                    }
                    if (!App_Music.bNoListAlbum) {
                        Lrc lrc = new Lrc();
                        Id3Info id3info = lrc.getId3Info(App_Music.myMediaPlayer.mPlayPath, true, false);
                        child = App_Music.getMapFile(strName, App_Music.myMediaPlayer.mPlayPath, id3info.strTitle, id3info.strArtist);
                    } else {
                        child = App_Music.getMapFile(strName, App_Music.myMediaPlayer.mPlayPath, "", "");
                    }
                    App_Music.listPlay.add(child);
                    Collections.sort(App_Music.listPlay, DataManager.comparator);
                }
                int index = MediaInfo.getListIndex(App_Music.listPlay, App_Music.myMediaPlayer.mPlayPath);
                if (index >= 0) {
                    Log.d(App_Music.TAG, "mRunnable_updateInfo");
                    App_Music.this.dispFileInfo(index + 1, App_Music.listPlay.size());
                    App_Music.this.updateDuration(App_Music.myMediaPlayer.mDuration);
                }
                Log.d(App_Music.TAG, "mRunnable_updateInfo...:" + App_Music.mListMode);
            }
        }
    };
    public Runnable mRunnable_ErrorSwitchMedia = new Runnable() { // from class: com.syu.app.App_Music.8
        @Override // java.lang.Runnable
        public void run() {
            if (App_Music.bPlayNextCausedByError) {
                App_Music.this.switchMedia(1);
            }
        }
    };
    public MyMediaPlayer.playerCallback myPlayerCallback = new MyMediaPlayer.playerCallback() { // from class: com.syu.app.App_Music.9
        public Runnable mRunnable_ShowErr = new Runnable() { // from class: com.syu.app.App_Music.9.1
            @Override // java.lang.Runnable
            public void run() {
                App_Music.this.showErr(App_Music.this.uiApp.getString("media_error_unsupport"));
            }
        };
        public Runnable mRunnable_HideErr = new Runnable() { // from class: com.syu.app.App_Music.9.2
            @Override // java.lang.Runnable
            public void run() {
                App_Music.hideErr();
            }
        };
        public Runnable mRunnable_UpdateBtnPause = new Runnable() { // from class: com.syu.app.App_Music.9.3
            @Override // java.lang.Runnable
            public void run() {
                App_Music.this.updateBtnPause();
            }
        };
        public Runnable mRunnable_Completion = new Runnable() { // from class: com.syu.app.App_Music.9.4
            @Override // java.lang.Runnable
            public void run() {
                int iStateDown = App_Music.myMediaPlayer.getStateCurDownFile();
                switch (iStateDown) {
                    case 1:
                        App_Music.conitueToPlay();
                        break;
                    case 2:
                        App_Music.showProgDown();
                        break;
                    default:
                        boolean bErrorSingleMusic = false;
                        if ((App_Music.listPlay.size() <= 1 || MediaInfo.mCycleMode == 3) && App_Music.myMediaPlayer.mDuration <= 3000) {
                            bErrorSingleMusic = true;
                        }
                        DownloadTask task = App_Music.getTaskByPath(App_Music.myMediaPlayer.mPlayPath);
                        if (task != null) {
                            App_Music.mListTaskDown.remove(task);
                        }
                        if (!bErrorSingleMusic) {
                            App_Music.this.switchMedia(1);
                        } else {
                            App_Music.myMediaPlayer.end(false);
                            App_Music.this.backToList();
                        }
                        break;
                }
            }
        };
        public Runnable mRunnable_UnMute = new Runnable() { // from class: com.syu.app.App_Music.9.5
            @Override // java.lang.Runnable
            public void run() {
                App_Music.this.sendPlayCmd(1007, null, 0);
            }
        };

        @Override // com.syu.media.core.MyMediaPlayer.playerCallback
        public boolean onError(MediaPlayer mp, int framework_err, int impl_err) {
            switch (framework_err) {
                case 1:
                case 100:
                case 200:
                    boolean bUnsupport = false;
                    if (framework_err == 1) {
                        switch (impl_err) {
                            case Integer.MIN_VALUE:
                            case MediaError.ERROR_FILE_FORMAT_UNSUPPORT /* -5003 */:
                            case MediaError.ERROR_VIDEO_UNSUPPORT /* -5002 */:
                            case MediaError.ERROR_AUDIO_UNSUPPORT /* -5001 */:
                            case MediaError.ERROR_UNSUPPORTED /* -1010 */:
                            case 0:
                                bUnsupport = true;
                                break;
                        }
                    }
                    if (impl_err != 1) {
                        if (Util.is7731() && (TextUtils.isEmpty(App_Music.myMediaPlayer.mPlayPath) || !FuncUtils.isFileExist(App_Music.myMediaPlayer.mPlayPath))) {
                            bUnsupport = false;
                        }
                        if (bUnsupport) {
                            Main.postRunnable_Ui(true, this.mRunnable_ShowErr);
                        }
                        App_Music.myMediaPlayer.end(false);
                        if (framework_err == 100) {
                            App_Music.this.sendPlayCmd(1002, null, 0);
                        }
                        App_Music.bPlayNextCausedByError = true;
                        if (FuncUtils.isAppInstalled(MyApplication.myApp, "com.iflytek.amap.assist")) {
                            App_Music.this.delCurrentFile();
                            Main.postRunnable_Ui(true, this.mRunnable_HideErr);
                        }
                        if (App_Music.listPlay.size() > 1 && (MediaInfo.mCycleMode != 3 || App_Music.mStrCustomer.equals("YF_MUSIC"))) {
                            Main.postRunnable_Ui(true, App_Music.this.mRunnable_ErrorSwitchMedia, 3000L);
                        }
                        break;
                    }
                default:
                    return false;
            }
        }

        @Override // com.syu.media.core.MyMediaPlayer.playerCallback
        public void onCompletion(MediaPlayer mp) {
            Main.postRunnable_Ui(true, this.mRunnable_Completion);
        }

        @Override // com.syu.media.core.MyMediaPlayer.playerCallback
        public void onPrepared(MediaPlayer mp) {
            MyMediaPlayer.bPrepared = true;
            MyMediaPlayer.bCanSeek = true;
            Main.postRunnable_Ui(true, this.mRunnable_UpdateBtnPause);
            int delay = 0;
            if (Util.is7731() || MyApplication.mIdPlatForm == 17 || Util.is8541()) {
                delay = 100;
            }
            App_Music.this.sendPlayCmd(1004, null, 0);
            App_Music.this.sendPlayCmd(1008, null, delay);
            if (App_Music.myMediaPlayer.mPosContinueTo > 0) {
                App_Music.myMediaPlayer.seekTo(App_Music.myMediaPlayer.mPosContinueTo);
                return;
            }
            if (Constant.bRememberLast && App_Music.myMediaPlayer.mPlayPath.equals(App_Music.mPathResumeSave) && App_Music.mPosResumeSave > 0) {
                App_Music.myMediaPlayer.mCurrent = App_Music.mPosResumeSave;
                App_Music.myMediaPlayer.seekTo(App_Music.mPosResumeSave);
            }
        }

        @Override // com.syu.media.core.MyMediaPlayer.playerCallback
        public void onSeekComplete(MediaPlayer mp) {
            MyMediaPlayer.bCanSeek = true;
            Main.postRunnable_Ui(true, this.mRunnable_UnMute, 500L);
        }

        @Override // com.syu.media.core.MyMediaPlayer.playerCallback
        public boolean onInfo(MediaPlayer mp, int what, int extra) {
            return false;
        }

        @Override // com.syu.media.core.MyMediaPlayer.playerCallback
        public void onBufferingUpdate(MediaPlayer mp, int percent) {
        }

        @Override // com.syu.media.core.MyMediaPlayer.playerCallback
        public void onCloseMusic() {
        }

        @Override // com.syu.media.core.MyMediaPlayer.playerCallback
        public void onUpdateSubtitle(String sub) {
        }
    };
    public Runnable mRunnable_Play1stFile = new Runnable() { // from class: com.syu.app.App_Music.10
        @Override // java.lang.Runnable
        public void run() {
            SparseArray<String> map;
            if (!App_Music.bResumeLastPlayOnce && App_Music.this.mIpcObj.isAppIdAudio() && IpcObj.isAccOn() && App_Music.listPlay.size() > 0 && (map = App_Music.listPlay.get(0)) != null) {
                String strPlay = map.get(FinalMusicCtrl.GridItem_Path);
                if (!TextUtils.isEmpty(strPlay)) {
                    App_Music.this.playFile(strPlay, false);
                }
            }
        }
    };
    OnCommandListener mCmdListener = new OnCommandListener.Stub() { // from class: com.syu.app.App_Music.11
        @Override // com.syu.sha.ipc.OnCommandListener
        public void onCammand(String cmd) throws RemoteException {
        }
    };
    OnMusicDataListener mMusicDataListener = new OnMusicDataListener.Stub() { // from class: com.syu.app.App_Music.12
        @Override // com.syu.sha.ipc.OnMusicDataListener
        public void onMusicDatas(List<Song> songs) throws RemoteException {
            Main.postRunnable_Ui(true, App_Music.this.new Runnable_GetList(songs));
        }
    };

    public static class MyListFolder {
        public MyFolder folderCurrent;
        public List<MyFolder> list = new ArrayList();
        public int[] posGroup = new int[1];
        public int[] posChild = new int[1];
    }

    static {
        for (int i = 0; i < 2; i++) {
            mConf_SD[i] = new String();
            mConf_SD[i] = "/xxxx";
        }
        mConf_USB = new String[21];
        for (int i2 = 0; i2 < 21; i2++) {
            mConf_USB[i2] = new String();
            mConf_USB[i2] = "/xxxx";
        }
        mStrCustomer = "SYU";
        mMusicCarType = "";
        bExtraProperty = "";
        mConf_CDROM = "/xxxx";
        myMediaPlayer = new MyMediaPlayer();
        Path_Native = "/xxxx";
        Path_SD = new String[2];
        for (int i3 = 0; i3 < 2; i3++) {
            Path_SD[i3] = new String();
            Path_SD[i3] = "/xxxx";
        }
        Path_USB = new String[21];
        for (int i4 = 0; i4 < 21; i4++) {
            Path_USB[i4] = new String();
            Path_USB[i4] = "/xxxx";
        }
        Path_CDROM = "/xxxx";
        mPathResume = "";
        mPathResumeSave = "";
        mPosResumeSave = 0;
        mSoundMode = 0;
        mToastYPlus_FullScreen = 0;
        mToastYPlus_HalfScreen = 0;
        bNoListAlbum = false;
        bScanFileCntOver = false;
        bEnableSpec = false;
        bMTU_ShowGridGroup = true;
        bMTU_Style = false;
        bSaveAlbumPicInList = false;
        bAutoPlayWhenMount = false;
        bGetDrawableFromDB = false;
        bPausedByChangeAppId = false;
        bPausedBySleep = false;
        bIsSpeechList = false;
        bInsertCdRom = false;
        bShowProgDown = false;
        bSendPlayState = false;
        bBtavRuuing = false;
        bisplay = true;
        bOnKeyBack = false;
        is7731UsbSwitch = false;
        bSetBtRing = false;
        bScollToTopPosition = false;
        list = new ArrayList();
        mDev = 0;
        mType = 0;
        mListMode = 2;
        mTDev = -1;
        mTListMode = -1;
        listPlay = new ArrayList();
        mDevPlay = 0;
        mTypePlay = 0;
        mListModePlay = 2;
        sPage_Music = FinalMusicCtrl.Page_Grid;
        mColorType = -1;
        mActiviteState = -1;
        myListFolder = new MyListFolder();
        myListFolderPlay = new MyListFolder();
        mInterface_Musics = new ArrayList<>();
        bResumeLastPlayOnce = false;
        bAppMoveToBack = false;
        workList = new ArrayList();
        workPreList = new ArrayList();
        workNextList = new ArrayList();
        iWorkNum = 0;
        iWorkPreNum = 0;
        iWorkNextNum = 0;
        mPlay1stPara = 0;
        mLrc = new Lrc();
        mId3Info = new Id3Info();
        mAnimeTime = -1;
        bFocus = true;
        color = 0;
        bTmp = null;
        seekTimes = 0;
        seekPosition = 0;
        mRunnable_SeekTo = new Runnable() { // from class: com.syu.app.App_Music.4
            @Override // java.lang.Runnable
            public void run() {
                App_Music.myMediaPlayer.seekTo(App_Music.seekPosition);
                App_Music.seekTimes = 0;
            }
        };
        mRunnable_hideProgDown = new Runnable() { // from class: com.syu.app.App_Music.7
            @Override // java.lang.Runnable
            public void run() {
                App_Music.hideProgDown();
            }
        };
        myAlbum = new HashMap<>();
        myPaths = new ArrayList(20);
    }

    public static App_Music getInstance() {
        if (instance == null) {
            instance = new App_Music();
        }
        return instance;
    }

    public App_Music() {
        Log.d(TAG, "App_Music onCreate");
        this.uiApp = new MyUi(MyApplication.myApp, null, FinalMusicType.class, null);
        this.mySharePreference2 = new MySharePreference2();
        this.mySharePreference2.init(MyApplication.myApp, "music_data");
        mMusicCarType = SystemProperties.get("persist.lsec.bbatype", "");
    }

    public void sendPlayCmd(int action, String path, int delay) {
        Message msg = this.mHandlerPlay.obtainMessage(action, 1, 1, path);
        this.mHandlerPlay.sendMessageDelayed(msg, delay);
    }

    public void sendSeekCmd(int mSec) {
        Message msg = this.mHandlerPlay.obtainMessage(1006, mSec, 1, null);
        this.mHandlerPlay.sendMessage(msg);
    }

    public void startPlayThread() {
        this.mHandlerThreadPlay = new HandlerThread("play-handler-thread");
        this.mHandlerThreadPlay.start();
        this.mHandlerPlay = new Handler(this.mHandlerThreadPlay.getLooper()) { // from class: com.syu.app.App_Music.13
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what) {
                    case 1000:
                        App_Music.this.updatePlayState();
                        PlayerCore.playMedia((String) msg.obj);
                        break;
                    case 1001:
                        PlayerCore.pauseMedia((String) msg.obj);
                        break;
                    case 1002:
                        PlayerCore.ReInitMediaPlayer();
                        break;
                    case 1003:
                        PlayerCore.release();
                        break;
                    case 1004:
                        PlayerCore.checkStart();
                        break;
                    case 1005:
                        PlayerCore.Pause();
                        break;
                    case 1006:
                        PlayerCore.seekTo(msg.arg1);
                        break;
                    case 1007:
                        PlayerCore.unMute();
                        break;
                    case 1008:
                        App_Music.myMediaPlayer.mDuration = PlayerCore.getDuration();
                        Main.postRunnable_Ui(true, App_Music.this.mRunnableUpdateDuration);
                        break;
                    case 1009:
                        App_Music.myMediaPlayer.mCurrent = PlayerCore.getCurrentPosition();
                        App_Music.this.mIpcObj.TransmitPos();
                        if (App_Music.this.mIpcObj.isAppIdAudio()) {
                            Main.postRunnable_Ui(true, App_Music.this.mRunnableHandleSeekPos);
                        }
                        break;
                }
            }
        };
    }

    public void startPlayThread7731() {
        this.mHandlerPlay = new Handler(MyApplication.myApp.getMainLooper()) { // from class: com.syu.app.App_Music.14
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what) {
                    case 1000:
                        PlayerCore.playMedia((String) msg.obj);
                        break;
                    case 1001:
                        PlayerCore.pauseMedia((String) msg.obj);
                        break;
                    case 1002:
                        PlayerCore.ReInitMediaPlayer();
                        break;
                    case 1003:
                        PlayerCore.release();
                        break;
                    case 1004:
                        PlayerCore.checkStart();
                        break;
                    case 1005:
                        PlayerCore.Pause();
                        break;
                    case 1006:
                        PlayerCore.seekTo(msg.arg1);
                        break;
                    case 1007:
                        PlayerCore.unMute();
                        break;
                    case 1008:
                        App_Music.myMediaPlayer.mDuration = PlayerCore.getDuration();
                        Main.postRunnable_Ui(true, App_Music.this.mRunnableUpdateDuration);
                        break;
                    case 1009:
                        App_Music.myMediaPlayer.mCurrent = PlayerCore.getCurrentPosition();
                        App_Music.this.mIpcObj.TransmitPos();
                        if (App_Music.this.mIpcObj.isAppIdAudio()) {
                            Main.postRunnable_Ui(true, App_Music.this.mRunnableHandleSeekPos);
                        }
                        break;
                }
            }
        };
    }

    public static void requestAudioFocus() {
        if (myAudioFocus != null) {
            myAudioFocus.requestAudioFocus();
        }
    }

    public static void abandonAudioFocus() {
        if (myAudioFocus != null) {
            myAudioFocus.abandonAudioFocus();
        }
    }

    public void setUsbPath786() throws Throwable {
        if (Main.mConf_PlatForm == 4) {
            String strExternalStorage = FuncUtils.getExternalStorageDirectory();
            String[] strDev = strExternalStorage.split("\n");
            if (strDev != null) {
                for (String str : strDev) {
                    if (str.startsWith("/mnt/usb") && !str.equals(Path_USB[0]) && !str.equals(Path_USB[1]) && !str.equals(Path_USB[2]) && !str.equals(Path_USB[3])) {
                        if (Path_USB[0].equals("/xxxx")) {
                            Path_USB[0] = str;
                        } else if (Path_USB[1].equals("/xxxx")) {
                            Path_USB[1] = str;
                        } else if (Path_USB[2].equals("/xxxx")) {
                            Path_USB[2] = str;
                        } else if (Path_USB[3].equals("/xxxx")) {
                            Path_USB[3] = str;
                        }
                    }
                }
            }
        }
    }

    public void onCreate(MyApplication myApplication) throws Throwable {
        this.myApplication = myApplication;
        MyApplication.mListConnectedMain.add(this);
        myAudioFocus = new MAudioFocus(MyApplication.myApp);
        MediaManager.init(myApplication);
        this.mIpcObj.initIpc();
        requestAppIdRight();
        readSet();
        ReadConf();
        setCarTypeProp();
        getMethod();
        Path_SD[0] = getPathSD1();
        Path_SD[1] = getPathSD2();
        Path_USB[0] = getPathUSB1();
        Path_USB[1] = getPathUSB2();
        Path_USB[2] = getPathUSB3();
        Path_USB[3] = getPathUSB4();
        for (int i = 4; i < 21; i++) {
            Path_USB[i] = mConf_USB[i];
        }
        Path_CDROM = mConf_CDROM;
        setUsbPath786();
        try {
            Class.forName("android.os.storage.IMountService");
            mMountService = IMountService.Stub.asInterface(ServiceManager.getService("mount"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (Util.is7731() || MyApplication.mIdPlatForm == 17 || Util.is8541()) {
            startPlayThread7731();
        } else {
            startPlayThread();
        }
        InitBroadCast(MyApplication.myApp);
        windowManager = (WindowManager) MyApplication.myApp.getSystemService("window");
        mDb = new DB(MyApplication.myApp);
        ReadPreference();
        dataManager = new DataManager();
        MyApplication.startThread(MyApplication.mStrZipTag, "ThreadQueryFavorite", new Runnable() { // from class: com.syu.app.App_Music.15
            @Override // java.lang.Runnable
            public void run() {
                Log.d("LZP", "MyApplication.startThread");
                App_Music.scanFile(26, false, true);
                App_Music.mDb.queryFavorite();
            }
        }, false, 5);
        Intent intent = new Intent("com.syu.sha.TransitService");
        intent.setPackage("com.syu.sha");
        MyApplication.myApp.bindService(intent, this, 1);
        if (mUpdateAppWidget != null) {
            mUpdateAppWidget.onCreate();
        }
        if (mUpdateAppWidget != null) {
            mUpdateAppWidget.updateAppWidget();
        }
        boolean yl = SystemProperties.getBoolean("persist.syu.yldebug", false);
        if (mStrCustomer.equalsIgnoreCase("MUSIC_YL") && !yl) {
            Util.checkCustomerId();
        }
    }

    private void setCarTypeProp() {
        String str = mMusicCarType;
        switch (str.hashCode()) {
            case -1395821311:
                if (str.equals("bba_ad")) {
                    mStrCustomer = "zhtd_aodi";
                    return;
                }
                break;
            case -1395821281:
                if (str.equals("bba_bc")) {
                    mStrCustomer = "zhtd_benz";
                    return;
                }
                break;
            case -1395821271:
                if (str.equals("bba_bm")) {
                    mStrCustomer = "zhtd";
                    return;
                }
                break;
            case -1395820966:
                if (str.equals("bba_lh")) {
                    mStrCustomer = "NEW_MUSIC_1920";
                    return;
                }
                break;
            case -1354145411:
                if (str.equals("bba_lkss")) {
                    mStrCustomer = "zhtd_lkss";
                    return;
                }
                break;
            case -320779937:
                if (str.equals("bba_id8")) {
                    return;
                }
                break;
        }
        if (bExtraProperty.equals("bba_bm")) {
            mStrCustomer = "zhtd";
            MyApplication.mStrFolderAsset = bExtraProperty;
        }
    }

    public void ReadPreference() {
        MediaInfo.mCycleMode = this.mySharePreference2.getIntValue(CYCLE_MODE, 0);
        mDev = this.mySharePreference2.getIntValue(MediaInfo.Str_Dev, 0);
        if (mDev < 0 || mDev >= 26) {
            mDev = 0;
        }
        mType = this.mySharePreference2.getIntValue(MediaInfo.Str_Type, 0);
        if (mType < 0 || mType >= 4) {
            mType = 0;
        }
        mPathResumeSave = this.mySharePreference2.getStringValue(MediaInfo.Str_PlayPath);
        mPosResumeSave = this.mySharePreference2.getIntValue(MediaInfo.Str_PlayTime, 0);
        mPathResume = mPathResumeSave;
        if (!TextUtils.isEmpty(mPathResume)) {
            mDevPlay = MediaInfo.getDev(mPathResume);
        }
        Log.d(TAG, "ReadPreference mDevPlay:" + mDevPlay);
        mListMode = this.mySharePreference2.getIntValue(MediaInfo.Str_ListMode, 2);
        if (mListMode == 1 && mDb != null && MediaInfo.getListIndex(mDb.list_Fav, mPathResume) < 0) {
            mListMode = 2;
        }
        if (mListMode == 3) {
            mListMode = 2;
        }
        mListModePlay = mListMode;
    }

    public void InitBroadCast(Application app) {
        IntentFilter iFilter = new IntentFilter();
        iFilter.addAction(Receiver.REMOVE_BROADCAST);
        iFilter.addAction(Receiver.RESUME_SCAN);
        iFilter.addAction(Receiver.ACTION_AMAPASSIST_CMD);
        iFilter.setPriority(Integer.MAX_VALUE);
        app.registerReceiver(this.mReceiver, iFilter);
        IntentFilter iFilterFile = new IntentFilter();
        iFilterFile.addAction("android.intent.action.MEDIA_MOUNTED");
        iFilterFile.addAction("android.intent.action.MEDIA_UNMOUNTED");
        iFilterFile.addAction("android.intent.action.MEDIA_REMOVED");
        iFilterFile.addAction("android.intent.action.MEDIA_BAD_REMOVAL");
        iFilterFile.addAction("android.intent.action.MEDIA_EJECT");
        iFilterFile.addDataScheme("file");
        iFilterFile.setPriority(Integer.MAX_VALUE);
        app.registerReceiver(this.mReceiver, iFilterFile);
        IntentFilter iFilterEasyConn = new IntentFilter();
        iFilterEasyConn.addAction(Receiver.ACTION_EASYCONN_BREAK);
        iFilterEasyConn.setPriority(Integer.MAX_VALUE);
        app.registerReceiver(this.mReceiver_EasyConn, iFilterEasyConn);
        if (mStrCustomer.equalsIgnoreCase("changecolor")) {
            IntentFilter iFilterColor = new IntentFilter();
            iFilterColor.addAction(Receiver.ACTION_CHANGE_COLOR);
            iFilterColor.setPriority(Integer.MAX_VALUE);
            app.registerReceiver(this.mReceiver_EasyConn, iFilterColor);
        }
    }

    public void getMethod() throws Throwable {
        Method[] methodActivityManager = ActivityManager.class.getDeclaredMethods();
        for (Method method : methodActivityManager) {
            if (method.getName().equals("fytgetState")) {
                this.fytGetState = method;
            } else if (method.getName().equals("fytsetState")) {
                this.fytSetState = method;
            }
        }
        Method[] methodMediaPlayer = MediaPlayer.class.getDeclaredMethods();
        for (Method method2 : methodMediaPlayer) {
            if (method2.getName().equals("setVolume")) {
                this.mediaplayer_setVolume = method2;
                this.mediaplayer_setVolume_paranum = method2.getParameterTypes().length;
                break;
            }
        }
        if (Main.mConf_PlatForm == 2) {
            ReadMethod("conf_method");
            Method[] methodEnvironment = Environment.class.getDeclaredMethods();
            for (Method method3 : methodEnvironment) {
                if (method3.getName().equals(this.method_SD1)) {
                    this.getExternalSd1Path = method3;
                } else if (method3.getName().equals(this.method_SD2)) {
                    this.getExternalSd2Path = method3;
                } else if (method3.getName().equals(this.method_USB1)) {
                    this.getUsb1Path = method3;
                } else if (method3.getName().equals(this.method_USB2)) {
                    this.getUsb2Path = method3;
                } else if (method3.getName().equals(this.method_USB3)) {
                    this.getUsb3Path = method3;
                } else if (method3.getName().equals(this.method_USB4)) {
                    this.getUsb4Path = method3;
                }
            }
        }
    }

    public void ReadConf() throws Throwable {
        String str;
        try {
            String strXml = this.uiApp.getRaw("conf_platform");
            if (!TextUtils.isEmpty(strXml)) {
                Markup xml = new Markup();
                xml.ReadXML(strXml);
                if (xml.IntoItem()) {
                    do {
                        String strTemp = xml.GetAttr(Mp4NameBox.IDENTIFIER);
                        if (strTemp != null) {
                            if (strTemp.equals("Toast_YPlus")) {
                                String str2 = xml.GetAttr("value");
                                if (str2 != null) {
                                    String[] strArray = str2.split(",");
                                    int iLenArray = strArray.length;
                                    if (iLenArray >= 2) {
                                        mToastYPlus_FullScreen = FuncUtils.myParseInt(strArray[0]);
                                        mToastYPlus_HalfScreen = FuncUtils.myParseInt(strArray[1]);
                                    }
                                }
                            } else if (strTemp.equals("UsedInMobilePhone")) {
                                String str3 = xml.GetAttr("value");
                                if (str3 != null && str3.equals("1")) {
                                    mUsedInMobilePhone = true;
                                }
                            } else if (strTemp.equals("EnableHalfScreen")) {
                                String str4 = xml.GetAttr("value");
                                if (str4 != null && str4.equals("1")) {
                                    mEnableHalfScreen = true;
                                }
                            } else if (strTemp.equals("EnableFocusChange")) {
                                String str5 = xml.GetAttr("value");
                                if (str5 != null && str5.equals("1")) {
                                    this.bEnableFocusChange = true;
                                }
                            } else if (strTemp.equals("NoListAlbum")) {
                                String str6 = xml.GetAttr("value");
                                if (str6 != null && str6.equals("1")) {
                                    bNoListAlbum = true;
                                }
                            } else if (strTemp.equals("Translucent")) {
                                String str7 = xml.GetAttr("value");
                                if (str7 != null && str7.equals("1")) {
                                    mIsTranslucent = true;
                                }
                            } else if (strTemp.equals("SaveAlbumPicInList")) {
                                String str8 = xml.GetAttr("value");
                                if (str8 != null && str8.equals("1")) {
                                    bSaveAlbumPicInList = true;
                                }
                            } else if (strTemp.equals("customer")) {
                                String str9 = xml.GetAttr("value");
                                if (str9 != null) {
                                    mStrCustomer = str9;
                                    if (str9.equals("MTU") || str9.equals(FinalCustomer.VCustZhuoAoTong) || str9.equals(FinalCustomer.VCustJiaYiTian)) {
                                        bMTU_Style = true;
                                    }
                                }
                            } else if (strTemp.equals("AutoPlayWhenMount")) {
                                String str10 = xml.GetAttr("value");
                                if (str10 != null && str10.equals("1")) {
                                    bAutoPlayWhenMount = true;
                                }
                            } else if (strTemp.equals("anime_time")) {
                                String str11 = xml.GetAttr("value");
                                if (str11 != null) {
                                    mAnimeTime = Integer.parseInt(str11);
                                }
                            } else if (strTemp.equals("SystemUiNavigationBar")) {
                                String str12 = xml.GetAttr("value");
                                if (str12 != null && str12.equals("1")) {
                                    mSystemUiNavigationBarTranSparent = true;
                                }
                            } else if (strTemp.equals("ScollToTopPosition")) {
                                String str13 = xml.GetAttr("value");
                                if (str13 != null && str13.equals("1")) {
                                    bScollToTopPosition = true;
                                }
                            } else if (strTemp.equals("extraProperty") && (str = xml.GetAttr("value")) != null) {
                                bExtraProperty = str;
                            }
                        }
                    } while (xml.NextItem());
                    xml.ExitItem();
                    switch (Main.mConf_PlatForm) {
                        case 1:
                        case 6:
                        case 7:
                        case 8:
                            ReadPath("path_6025");
                            break;
                        case 2:
                            ReadPath("path_3188");
                            break;
                        case 3:
                            ReadPath("path_8700");
                            break;
                        case 4:
                            ReadPath("path_786");
                            break;
                        case 5:
                            ReadPath("path_sophia");
                            break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void ReadPath(String strRaw) throws Throwable {
        String str;
        if (!TextUtils.isEmpty(strRaw)) {
            try {
                String strXml = this.uiApp.getRaw(strRaw);
                if (!TextUtils.isEmpty(strXml)) {
                    Markup xml = new Markup();
                    xml.ReadXML(strXml);
                    if (xml.IntoItem()) {
                        do {
                            String strTemp = xml.FindToken(xml.mItemCur.mStrBuff, xml.mItemCur.mPosEnd - xml.mItemCur.mPosStart, 0, null);
                            if (strTemp.equals("path_Native")) {
                                String str2 = xml.GetAttr("value");
                                if (str2 != null) {
                                    Path_Native = str2;
                                }
                            } else if (strTemp.equals("path_SD1")) {
                                String str3 = xml.GetAttr("value");
                                if (str3 != null) {
                                    mConf_SD[0] = str3;
                                }
                            } else if (strTemp.equals("path_SD2")) {
                                String str4 = xml.GetAttr("value");
                                if (str4 != null) {
                                    mConf_SD[1] = str4;
                                }
                            } else if (strTemp.equals("path_USB1")) {
                                String str5 = xml.GetAttr("value");
                                if (str5 != null) {
                                    if (SystemProperties.getInt("ro.fyt.realplatform", 0) == 3002) {
                                        mConf_USB[4] = str5;
                                    } else {
                                        mConf_USB[0] = str5;
                                    }
                                }
                            } else if (strTemp.equals("path_USB2")) {
                                String str6 = xml.GetAttr("value");
                                if (str6 != null) {
                                    mConf_USB[1] = str6;
                                }
                            } else if (strTemp.equals("path_USB3")) {
                                String str7 = xml.GetAttr("value");
                                if (str7 != null) {
                                    mConf_USB[2] = str7;
                                }
                            } else if (strTemp.equals("path_USB4")) {
                                String str8 = xml.GetAttr("value");
                                if (str8 != null) {
                                    mConf_USB[3] = str8;
                                }
                            } else if (strTemp.equals("path_USB5")) {
                                String str9 = xml.GetAttr("value");
                                if (str9 != null) {
                                    if (SystemProperties.getInt("ro.fyt.realplatform", 0) == 3002) {
                                        mConf_USB[0] = str9;
                                    } else {
                                        mConf_USB[4] = str9;
                                    }
                                }
                            } else if (strTemp.equals("path_USB6")) {
                                String str10 = xml.GetAttr("value");
                                if (str10 != null) {
                                    mConf_USB[5] = str10;
                                }
                            } else if (strTemp.equals("path_USB7")) {
                                String str11 = xml.GetAttr("value");
                                if (str11 != null) {
                                    mConf_USB[6] = str11;
                                }
                            } else if (strTemp.equals("path_USB8")) {
                                String str12 = xml.GetAttr("value");
                                if (str12 != null) {
                                    mConf_USB[7] = str12;
                                }
                            } else if (strTemp.equals("path_USB9")) {
                                String str13 = xml.GetAttr("value");
                                if (str13 != null) {
                                    mConf_USB[8] = str13;
                                }
                            } else if (strTemp.equals("path_USB10")) {
                                String str14 = xml.GetAttr("value");
                                if (str14 != null) {
                                    mConf_USB[9] = str14;
                                }
                            } else if (strTemp.equals("path_USB11")) {
                                String str15 = xml.GetAttr("value");
                                if (str15 != null) {
                                    mConf_USB[10] = str15;
                                }
                            } else if (strTemp.equals("path_USB12")) {
                                String str16 = xml.GetAttr("value");
                                if (str16 != null) {
                                    mConf_USB[11] = str16;
                                }
                            } else if (strTemp.equals("path_USB13")) {
                                String str17 = xml.GetAttr("value");
                                if (str17 != null) {
                                    mConf_USB[12] = str17;
                                }
                            } else if (strTemp.equals("path_USB14")) {
                                String str18 = xml.GetAttr("value");
                                if (str18 != null) {
                                    mConf_USB[13] = str18;
                                }
                            } else if (strTemp.equals("path_USB15")) {
                                String str19 = xml.GetAttr("value");
                                if (str19 != null) {
                                    mConf_USB[14] = str19;
                                }
                            } else if (strTemp.equals("path_USB16")) {
                                String str20 = xml.GetAttr("value");
                                if (str20 != null) {
                                    mConf_USB[15] = str20;
                                }
                            } else if (strTemp.equals("path_USB17")) {
                                String str21 = xml.GetAttr("value");
                                if (str21 != null) {
                                    mConf_USB[16] = str21;
                                }
                            } else if (strTemp.equals("path_USB18")) {
                                String str22 = xml.GetAttr("value");
                                if (str22 != null) {
                                    mConf_USB[17] = str22;
                                }
                            } else if (strTemp.equals("path_USB19")) {
                                String str23 = xml.GetAttr("value");
                                if (str23 != null) {
                                    mConf_USB[18] = str23;
                                }
                            } else if (strTemp.equals("path_USB20")) {
                                String str24 = xml.GetAttr("value");
                                if (str24 != null) {
                                    mConf_USB[19] = str24;
                                }
                            } else if (strTemp.equals("path_USB21")) {
                                String str25 = xml.GetAttr("value");
                                if (str25 != null) {
                                    mConf_USB[20] = str25;
                                }
                            } else if (strTemp.equals("path_CDROM") && (str = xml.GetAttr("value")) != null) {
                                mConf_CDROM = str;
                            }
                        } while (xml.NextItem());
                        xml.ExitItem();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void ReadMethod(String strRaw) throws Throwable {
        String str;
        if (!TextUtils.isEmpty(strRaw)) {
            try {
                String strXml = this.uiApp.getRaw(strRaw);
                if (!TextUtils.isEmpty(strXml)) {
                    Markup xml = new Markup();
                    xml.ReadXML(strXml);
                    if (xml.IntoItem()) {
                        do {
                            String strTemp = xml.FindToken(xml.mItemCur.mStrBuff, xml.mItemCur.mPosEnd - xml.mItemCur.mPosStart, 0, null);
                            if (strTemp.equals("method_SD1")) {
                                String str2 = xml.GetAttr("value");
                                if (str2 != null) {
                                    this.method_SD1 = str2;
                                }
                            } else if (strTemp.equals("method_SD2")) {
                                String str3 = xml.GetAttr("value");
                                if (str3 != null) {
                                    this.method_SD2 = str3;
                                }
                            } else if (strTemp.equals("method_USB1")) {
                                String str4 = xml.GetAttr("value");
                                if (str4 != null) {
                                    this.method_USB1 = str4;
                                }
                            } else if (strTemp.equals("method_USB2")) {
                                String str5 = xml.GetAttr("value");
                                if (str5 != null) {
                                    this.method_USB2 = str5;
                                }
                            } else if (strTemp.equals("method_USB3")) {
                                String str6 = xml.GetAttr("value");
                                if (str6 != null) {
                                    this.method_USB3 = str6;
                                }
                            } else if (strTemp.equals("method_USB4") && (str = xml.GetAttr("value")) != null) {
                                this.method_USB4 = str;
                            }
                        } while (xml.NextItem());
                        xml.ExitItem();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public String getPathSD1() {
        if (Main.mConf_PlatForm == 2 && this.getExternalSd1Path != null) {
            try {
                return (String) this.getExternalSd1Path.invoke(null, new Object[0]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return mConf_SD[0];
    }

    public String getPathSD2() {
        if (Main.mConf_PlatForm == 2 && this.getExternalSd2Path != null) {
            try {
                return (String) this.getExternalSd2Path.invoke(null, new Object[0]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return mConf_SD[1];
    }

    public String getPathUSB1() {
        if (Main.mConf_PlatForm == 2 && this.getUsb1Path != null) {
            try {
                return (String) this.getUsb1Path.invoke(null, new Object[0]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return mConf_USB[0];
    }

    public String getPathUSB2() {
        if (Main.mConf_PlatForm == 2 && this.getUsb2Path != null) {
            try {
                return (String) this.getUsb2Path.invoke(null, new Object[0]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return mConf_USB[1];
    }

    public String getPathUSB3() {
        if (Main.mConf_PlatForm == 2 && this.getUsb3Path != null) {
            try {
                return (String) this.getUsb3Path.invoke(null, new Object[0]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return mConf_USB[2];
    }

    public String getPathUSB4() {
        if (Main.mConf_PlatForm == 2 && this.getUsb4Path != null) {
            try {
                return (String) this.getUsb4Path.invoke(null, new Object[0]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return mConf_USB[3];
    }

    public static void initUsbHdPort() {
        if (bTmp == null) {
            bTmp = new boolean[4];
            String strUsbPort = SystemProperties.get("ro.lsec7731.UsbHdPort", "0,1,2,3");
            String[] strUsbArray = strUsbPort.split(",");
            if (strUsbArray != null && strUsbArray.length > 0) {
                for (String str : strUsbArray) {
                    if (str.equals("0")) {
                        bTmp[0] = true;
                    } else if (str.equals("1")) {
                        bTmp[1] = true;
                    } else if (str.equals("2")) {
                        bTmp[2] = true;
                    } else if (str.equals("3")) {
                        bTmp[3] = true;
                    }
                }
            }
        }
    }

    public static boolean isMounted(String path) {
        int iDev = MediaInfo.getDev(path);
        if (Util.is7731()) {
            initUsbHdPort();
            int iIndexUsb = iDev - 3;
            if (iIndexUsb >= 0 && iIndexUsb < 4) {
                return bTmp[iIndexUsb];
            }
        }
        if (iDev == 0) {
            return true;
        }
        if (MediaInfo.getMountState(iDev) == -1) {
            return false;
        }
        String path2 = MediaInfo.getPath(iDev);
        File file = new File(path2);
        if (!file.exists()) {
            return false;
        }
        String[] fileArray = file.list();
        Log.d(TAG, "isMounted fileArray..:" + fileArray.length);
        if (fileArray != null && fileArray.length > 0) {
            return true;
        }
        try {
            if (mMountService != null) {
                String state = mMountService.getVolumeState(path2);
                return "mounted".equals(state);
            }
        } catch (Exception e) {
        }
        return false;
    }

    public static void getData_Grid(int dev) {
        Log.d(TAG, "-------------->>>>  getData_Grid");
        if (checkUpdateGird(dev)) {
            MediaInfo.copyList2Dst(list, dev, mListMode);
            for (Interface_Music interface_Music : mInterface_Musics) {
                interface_Music.handleGetData();
            }
        }
    }

    public void getData_Play(int dev) {
        if (checkUpdatePlay(dev)) {
            Log.d(TAG, "getData_Play playPath:" + myMediaPlayer.mPlayPath);
            updatePlayList(myMediaPlayer.mPlayPath);
            Main.removeRunnable_Ui(this.mRunnable_updateInfo);
            Main.postRunnable_Ui(true, this.mRunnable_updateInfo, 0);
        }
    }

    public void getData(int dev) {
        Log.d(TAG, "---------->>> getData");
        getData_Grid(dev);
        getData_Play(dev);
    }

    public static void scanFile(int iDev, boolean bAutoPlayWhenMount2) {
        scanFile(iDev, bAutoPlayWhenMount2, false);
    }

    public static void scanFile(int iDev, boolean bAutoPlayWhenMount2, boolean ignoreAcc) {
        Log.d(TAG, "---->>> scanFile isAccOn: " + IpcObj.isAccOn());
        if (IpcObj.isAccOn() || ignoreAcc) {
            Log.d(TAG, "---->>> scanFile iDev: " + iDev + ",MediaInfo.Dev_Cnt: 26");
            Log.d(TAG, "bScanFileCntOver:" + bScanFileCntOver);
            if ((iDev != 26 || !bScanFileCntOver) && dataManager != null && iDev >= 0 && iDev <= 26) {
                if (iDev == 26) {
                    dataManager.startScan(0, false);
                    for (int i = 0; i < 2; i++) {
                        dataManager.startScan(i + 1, false);
                    }
                    for (int i2 = 0; i2 < 21; i2++) {
                        dataManager.startScan(i2 + 3, false);
                    }
                    dataManager.startScan(24, false);
                    return;
                }
                dataManager.startScan(iDev, bAutoPlayWhenMount2);
            }
        }
    }

    public class Runnable_SeekPos implements Runnable {
        public boolean bRunning = true;

        public Runnable_SeekPos() {
        }

        public void stopRun() {
            this.bRunning = false;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.bRunning) {
                if (Math.abs(System.currentTimeMillis() - App_Music.mSeekTime) >= 1500) {
                    boolean bTransmit = false;
                    if (App_Music.myMediaPlayer.isPlaying()) {
                        App_Music.bSendPlayState = true;
                        bTransmit = true;
                    } else if (App_Music.bSendPlayState) {
                        App_Music.bSendPlayState = false;
                        bTransmit = true;
                    }
                    if (bTransmit) {
                        App_Music.this.sendPlayCmd(1009, null, 0);
                    }
                }
                Main.postRunnable_Ui(true, this, 1000L);
            }
        }
    }

    public void enableSeekPos() {
        disableSeekPos();
        this.mRunnable_SeekPos = new Runnable_SeekPos();
        Main.postRunnable_Ui(true, this.mRunnable_SeekPos);
    }

    public void disableSeekPos() {
        if (this.mRunnable_SeekPos != null) {
            Main.removeRunnable_Ui(this.mRunnable_SeekPos);
            this.mRunnable_SeekPos.stopRun();
            this.mRunnable_SeekPos = null;
        }
    }

    public void seekTo(int progress) {
        mSeekTime = System.currentTimeMillis();
        seekPosition = progress;
        myMediaPlayer.mCurrent = seekPosition;
        int i = seekTimes + 1;
        seekTimes = i;
        if (i == 1) {
            Main.postRunnable_Ui(true, mRunnable_SeekTo);
        } else {
            Main.postRunnable_Ui(true, mRunnable_SeekTo, 1000L);
        }
    }

    public void backToList() {
        try {
            for (Interface_Music interface_Music : mInterface_Musics) {
                if (!interface_Music.isHalf() || mStrCustomer.equals("hy_gbsp")) {
                    interface_Music.jumpList();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void conitueToPlay() {
        if (!TextUtils.isEmpty(myMediaPlayer.mPlayPath)) {
            myMediaPlayer.conitueToPlay(myMediaPlayer.mCurrent);
        }
    }

    public void dispFileInfo(int currentPos, int TotalCount) {
        int iPosName;
        if (FuncUtils.isFileExist(myMediaPlayer.mPlayPath)) {
            workList.add(String.valueOf(iWorkNum));
            MyTask task = new MyTask();
            task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, String.valueOf(myMediaPlayer.mPlayPath) + "#" + iWorkNum + "/" + currentPos + "/" + TotalCount);
            iWorkNum++;
            if (mStrCustomer.equalsIgnoreCase("TZY_MUSIC_PORT") || mStrCustomer.equalsIgnoreCase("TZY_MUSIC") || mStrCustomer.equalsIgnoreCase("TZY_MUSIC4") || mStrCustomer.equalsIgnoreCase("TZY_MUSIC5")) {
                workPreList.add(String.valueOf(iWorkPreNum));
                MyCoverTask task2 = new MyCoverTask();
                task2.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, String.valueOf(iWorkPreNum) + "/" + currentPos + "/" + TotalCount);
                iWorkPreNum++;
            }
            for (Interface_Music interface_Music : mInterface_Musics) {
                interface_Music.scrollToCurPos();
            }
            if (mUpdateAppWidget != null) {
                mUpdateAppWidget.updateAppWidget();
            }
            updateDuration(myMediaPlayer.mDuration);
            this.mIpcObj.TransmitIndex(currentPos - 1, TotalCount);
            this.mIpcObj.TransmitArtist();
            this.mIpcObj.TransmitAlbum();
            this.mIpcObj.TransmitDevType(mDevPlay);
            this.mIpcObj.TransmitMediaType();
            if (!TextUtils.isEmpty(myMediaPlayer.mPlayPath) && (iPosName = myMediaPlayer.mPlayPath.lastIndexOf("/")) >= 0) {
                this.mIpcObj.TransmitTitle(iPosName);
                this.mIpcObj.TransmitFolder(iPosName);
            }
        }
    }

    public void getLyric(boolean bTipErrorDown) {
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.getLyric(bTipErrorDown);
        }
    }

    public void clearLyric() {
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.clearLyric();
        }
    }

    class Runnable_setLrcText implements Runnable {
        String strRes;

        Runnable_setLrcText() {
        }

        public void setRes(String strRes) {
            this.strRes = strRes;
        }

        @Override // java.lang.Runnable
        public void run() {
            for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                interface_Music.setLrcText(this.strRes);
            }
        }
    }

    public void setLrcText(String strRes) {
        Page_Lrc.strResLyricView = strRes;
        if (this.mRunnable_setLrcText != null) {
            if (mStrCustomer.equals("KANGDA")) {
                strRes = "";
            }
            this.mRunnable_setLrcText.setRes(strRes);
            Main.postRunnable_Ui(true, this.mRunnable_setLrcText);
        }
    }

    public static String getLrcPath() {
        boolean bMkDir = true;
        File dir = new File(MUSIC_PATH);
        if (dir.exists() && dir.isDirectory()) {
            bMkDir = false;
        }
        if (bMkDir) {
            dir.mkdirs();
        }
        boolean bMkDir2 = true;
        File dir2 = new File(LRC_PATH);
        if (dir2.exists() && dir2.isDirectory()) {
            bMkDir2 = false;
        }
        if (bMkDir2) {
            dir2.mkdirs();
        }
        boolean bMkDir3 = true;
        File dir3 = new File(LOG_PATH);
        if (dir3.exists() && dir3.isDirectory()) {
            bMkDir3 = false;
        }
        if (bMkDir3) {
            dir3.mkdirs();
            return LRC_PATH;
        }
        return LRC_PATH;
    }

    public void reset() {
        Main.postRunnable_Ui(true, this.mRunnable_reset);
    }

    public static boolean getIndex(int para) {
        return getIndex(para, MediaInfo.mCycleMode);
    }

    public void setDayOrNight(int value) {
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.setDayOrNight(value);
        }
    }

    public static boolean getIndex(int para, int iCycleMode) {
        Log.d("LZP", "getIndex listPlay:" + (listPlay == null));
        if (listPlay == null) {
            return false;
        }
        Log.d("LZP", "getIndex listPlay size:" + listPlay.size());
        if (listPlay.size() <= 0) {
            return false;
        }
        switch (iCycleMode) {
            case 0:
                int index = MediaInfo.getListIndex(listPlay, myMediaPlayer.mPlayPath);
                if (index < 0) {
                    index = 0;
                }
                int index2 = index + para;
                if (index2 <= -1) {
                    index2 = listPlay.size() - 1;
                } else if (index2 >= listPlay.size()) {
                    index2 = 0;
                }
                SparseArray<String> map = listPlay.get(index2);
                if (map != null) {
                    myMediaPlayer.setPlayPath(map.get(FinalMusicCtrl.GridItem_Path));
                }
                return true;
            case 1:
                SparseArray<String> map2 = listPlay.get((int) (((double) listPlay.size()) * Math.random()));
                if (map2 != null) {
                    myMediaPlayer.setPlayPath(map2.get(FinalMusicCtrl.GridItem_Path));
                }
                return true;
            case 2:
                int index3 = MediaInfo.getListIndex(listPlay, myMediaPlayer.mPlayPath);
                if (index3 < 0) {
                    index3 = 0;
                }
                int index4 = index3 + para;
                if (index4 <= -1 || index4 >= listPlay.size()) {
                    return false;
                }
                SparseArray<String> map3 = listPlay.get(index4);
                if (map3 != null) {
                    myMediaPlayer.setPlayPath(map3.get(FinalMusicCtrl.GridItem_Path));
                }
                return true;
            case 3:
                int index5 = MediaInfo.getListIndex(listPlay, myMediaPlayer.mPlayPath);
                if (index5 < 0) {
                    index5 = 0;
                }
                SparseArray<String> map4 = listPlay.get(index5);
                if (map4 != null) {
                    myMediaPlayer.setPlayPath(map4.get(FinalMusicCtrl.GridItem_Path));
                }
                return true;
            default:
                return false;
        }
    }

    public void switchMedia(int para) {
        Log.d(TAG, "switchMedia");
        myMediaPlayer.end(false);
        if (para != 0 && !getIndex(para)) {
            backToList();
        }
    }

    public void switchMedia(int para, int iCycleMode) {
        myMediaPlayer.end(false);
        if (para != 0 && !getIndex(para, iCycleMode)) {
            backToList();
        }
    }

    public void updateBtnPause() {
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.updateBtnPause();
        }
        this.mIpcObj.TransmitPlayState();
        if (mUpdateAppWidget != null) {
            mUpdateAppWidget.updateAppWidget();
        }
    }

    public void playPause() {
        Log.d(TAG, "------------>>>  playPause");
        if (MyMediaPlayer.bNoPlay) {
            if (!TextUtils.isEmpty(myMediaPlayer.mPlayPath)) {
                File file = new File(myMediaPlayer.mPlayPath);
                if (file.exists()) {
                    updatePlayState();
                    playFile(myMediaPlayer.mPlayPath, false);
                    return;
                }
                return;
            }
            return;
        }
        if (MyMediaPlayer.bPrepared) {
            if (myMediaPlayer.isPlaying()) {
                myMediaPlayer.pause();
            } else {
                updatePlayState();
                myMediaPlayer.start();
            }
            updateBtnPause();
        }
    }

    public static void updatePlayList(String strPath) {
        Log.d(TAG, "updatePlayList IpcObj.isAccOn():" + IpcObj.isAccOn());
        if (!bIsSpeechList) {
            Log.d(TAG, "updatePlayList listPlay size:" + listPlay.size());
            Log.d(TAG, "updatePlayList mDevPlay:" + mDevPlay + ",mTypePlay:" + mTypePlay);
            Log.d(TAG, "updatePlayList mListModePlay:" + mListModePlay);
            listPlay.clear();
            int iDev = MediaInfo.getDev(strPath);
            if (IpcObj.isAccOn() && MediaInfo.getMountState(iDev) != -1) {
                if (mStrCustomer.equals("otolux")) {
                    if (mTypePlay == 0) {
                        MediaInfo.copyList2Dst(listPlay, mDevPlay, mListModePlay);
                    } else {
                        getCurrentFolder(true, strPath, mTypePlay, mDevPlay, mListModePlay);
                        if (myListFolderPlay != null && myListFolderPlay.list != null && myListFolderPlay.list.size() > 0) {
                            for (MyFolder folder : myListFolderPlay.list) {
                                listPlay.addAll(folder.array);
                            }
                        }
                    }
                } else if (mTypePlay == 0) {
                    MediaInfo.copyList2Dst(listPlay, mDevPlay, mListModePlay);
                } else {
                    getCurrentFolder(true, strPath, mTypePlay, mDevPlay, mListModePlay);
                    if (myListFolderPlay.folderCurrent != null) {
                        listPlay.addAll(myListFolderPlay.folderCurrent.array);
                    }
                }
            }
            Log.d(TAG, "listPlay size:" + listPlay.size() + ",mTypePlay:" + mTypePlay);
            if (mListMode == 3) {
                for (Interface_Music interface_Music : mInterface_Musics) {
                    interface_Music.handleGetData();
                }
                return;
            }
            for (Interface_Music interface_Music2 : mInterface_Musics) {
                interface_Music2.handleGetDataPlayer();
            }
        }
    }

    public static void updatePlayList(String strPath, int iType, int iDev, int iListMode) {
        Log.d(TAG, "updatePlayList IpcObj.isAccOn():" + IpcObj.isAccOn());
        Log.d(TAG, "updatePlayList listPlay size:" + listPlay.size());
        Log.d(TAG, "updatePlayList mDevPlay:" + mDevPlay + ",mTypePlay:" + mTypePlay);
        Log.d(TAG, "updatePlayList mListModePlay:" + mListModePlay);
        listPlay.clear();
        if ((getInstance().isAppTop() || IpcObj.isAccOn()) && MediaInfo.getMountState(iDev) != -1) {
            if (mTypePlay == 0) {
                MediaInfo.copyList2Dst(listPlay, iDev, iListMode);
            } else {
                getCurrentFolder(true, strPath, iType, iDev, iListMode);
                if (myListFolderPlay.folderCurrent != null) {
                    listPlay.addAll(myListFolderPlay.folderCurrent.array);
                }
            }
        }
        Log.d(TAG, "listPlay size:" + listPlay.size() + ",mTypePlay:" + mTypePlay);
    }

    public void requestAudioFocusPlay() {
        if (MyMediaPlayer.bPrepared && !myMediaPlayer.isPlaying()) {
            Log.d(TAG, "App_Music requestAudioFocusPlay");
            myMediaPlayer.start();
            updateBtnPause();
        }
    }

    public void play() {
        if (MyMediaPlayer.bNoPlay) {
            if (!TextUtils.isEmpty(myMediaPlayer.mPlayPath)) {
                File file = new File(myMediaPlayer.mPlayPath);
                if (file.exists()) {
                    playFile(myMediaPlayer.mPlayPath, false);
                    return;
                }
                return;
            }
            return;
        }
        if (MyMediaPlayer.bPrepared && !myMediaPlayer.isPlaying()) {
            Log.d("LZP", "....!myMediaPlayer.isPlaying():" + MyMediaPlayer.bNoPlay);
            updatePlayState();
            myMediaPlayer.start();
            updateBtnPause();
        }
    }

    public void pause() {
        if (!MyMediaPlayer.bNoPlay && MyMediaPlayer.bPrepared && myMediaPlayer.isPlaying()) {
            myMediaPlayer.pause();
            updateBtnPause();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updatePlayState() {
    }

    public ErrorStruct processErrorUnknown(MediaPlayer mp, int what, int extra) {
        ErrorStruct retStruct = new ErrorStruct();
        switch (extra) {
            case MediaError.ERROR_AUDIO_UNSUPPORT /* -5001 */:
                retStruct.showStateWithError = false;
            case MediaError.ERROR_FILE_FORMAT_UNSUPPORT /* -5003 */:
            case MediaError.ERROR_VIDEO_UNSUPPORT /* -5002 */:
            case MediaError.ERROR_DRM_NO_LICENSE /* -2001 */:
            case MediaError.ERROR_UNSUPPORTED /* -1010 */:
            case MediaError.ERROR_MALFORMED /* -1007 */:
            case MediaError.ERROR_IO /* -1004 */:
            case MediaError.ERROR_NOT_CONNECTED /* -1001 */:
            default:
                return retStruct;
        }
    }

    public void updateDuration(int duration) {
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.updateDuration(duration);
        }
        if (mUpdateAppWidget != null) {
            mUpdateAppWidget.updateAppWidget();
        }
    }

    public static void showProgDown() {
        bShowProgDown = true;
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.showProgDown();
        }
    }

    public static void hideProgDown() {
        bShowProgDown = false;
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.hideProgDown();
        }
    }

    public void delCurrentFile() {
        String strPath = myMediaPlayer.mPlayPath;
        switchMedia(1, 0);
        mDb.getWritableDatabase().execSQL("delete from Table_Favorite where Path = ?", new String[]{strPath});
        int iDev = MediaInfo.getDev(strPath);
        if (iDev >= 0 && iDev < 26) {
            File file = new File(strPath);
            if (file.delete()) {
                MediaInfo.delFromList(strPath);
                getData_Play(iDev);
            }
        }
    }

    public void showErr(String str) {
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.showErr(str);
        }
    }

    public static void hideErr() {
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.hideErr();
        }
    }

    public static void getCurrentFolder(boolean bPlayList, String strPath, int iType, int iDev, int iListMode) {
        MyListFolder listFolder;
        if (bPlayList) {
            listFolder = myListFolderPlay;
        } else {
            listFolder = myListFolder;
        }
        if (listFolder != null) {
            MediaInfo.copyListFolder2Dst(listFolder.list, iDev, iType, iListMode);
            listFolder.folderCurrent = MediaInfo.getFolder(bPlayList, strPath, listFolder.posGroup, listFolder.posChild, iType);
            Log.d(TAG, "listFolder size:" + listFolder.list.size());
        }
    }

    public boolean isScanning() {
        return !MediaInfo.isScanOver();
    }

    public static boolean checkUpdateGird(int iDev) {
        if (iDev == mDev) {
            return true;
        }
        switch (mListMode) {
            case 1:
            case 2:
                return true;
            default:
                return false;
        }
    }

    public static boolean checkUpdatePlay(int iDev) {
        if (iDev == mDevPlay) {
            return true;
        }
        switch (mListModePlay) {
            case 1:
            case 2:
                if (mTypePlay != 0) {
                    return false;
                }
                return true;
            default:
                return false;
        }
    }

    public void handleUnMount(int iDev) {
        Log.d(TAG, "handleUnMount");
        MediaInfo.clear(iDev);
        getData(iDev);
        Integer integer_Dev = Integer.valueOf(iDev);
        mListDev.remove(integer_Dev);
        boolean bPlayFile = false;
        if (iDev == mDevPlay) {
            listPlay.clear();
            for (Interface_Music interface_Music : mInterface_Musics) {
                interface_Music.resetListData();
            }
            if (this.mIpcObj.isAppIdAudio() && bAutoPlayWhenMount) {
                int iSize = mListDev.size();
                for (int index = iSize - 1; index >= 0; index--) {
                    int devTmp = mListDev.get(index).intValue();
                    if (MediaInfo.myList[devTmp].array.size() > 0) {
                        SparseArray<String> map = MediaInfo.myList[devTmp].array.get(0);
                        playFile(map.get(FinalMusicCtrl.GridItem_Path), true);
                        bPlayFile = true;
                        break;
                    }
                }
            }
        } else {
            bPlayFile = true;
        }
        if (!bPlayFile) {
            mId3Info.strTitle = this.uiApp.getString(EnvironmentCompat.MEDIA_UNKNOWN);
            mId3Info.strArtist = this.uiApp.getString(EnvironmentCompat.MEDIA_UNKNOWN);
            mId3Info.strAlbum = this.uiApp.getString(EnvironmentCompat.MEDIA_UNKNOWN);
        }
    }

    public void refreshListTip() {
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.refreshListTip();
        }
    }

    public void resumeLastPlay(int iDev) {
        if (IpcObj.isAccOn() && MediaInfo.getMountState(iDev) != -1 && Constant.bRememberLast && MyMediaPlayer.bNoPlay && !TextUtils.isEmpty(mPathResume) && iDev == MediaInfo.getDev(mPathResume)) {
            File fileResume = new File(mPathResume);
            if (fileResume.exists()) {
                playFile(mPathResume, false);
            }
        }
    }

    public void updateScanList(int iDev) {
        Log.d(TAG, "----->>> updateScanList");
        Log.d(TAG, "----->>> AccOn:" + IpcObj.isAccOn());
        Log.d(TAG, "----->>> MediaInfo.getMountState(iDev) != -1:" + (MediaInfo.getMountState(iDev) != -1));
        Log.d(TAG, "----->>> mIpcObj.isAppIdAudio():" + this.mIpcObj.isAppIdAudio());
        if ((IpcObj.isAccOn() || getInstance().isAppTop()) && MediaInfo.getMountState(iDev) != -1) {
            getData(iDev);
            resumeLastPlay(iDev);
        }
    }

    public void handleScanFinish(int iDev, boolean bAutoPlay) {
        int iDev1stIncludeFile;
        Log.d(TAG, "-------->>> handleScanFinish.... isAppIdAudio:" + this.mIpcObj.isAppIdAudio());
        MediaInfo.setScan(iDev, 0);
        if (IpcObj.isAccOn() && MediaInfo.getMountState(iDev) != -1) {
            if (bAutoPlay && (!this.mIpcObj.isAppIdAudio() || !MyApplication.myApp.isAppTop())) {
                mListMode = 0;
                mDev = iDev;
                mListModePlay = 0;
                mDevPlay = iDev;
                Log.d(TAG, "handleScanFinish mDevPlay:" + mDevPlay);
                MyApplication.myApp.jumpAct("Music");
            }
            if (this.mIpcObj.isAppIdAudio() || bAutoPlay) {
                Log.d(TAG, "-------->>> MediaInfo.myList[iDev].array.size():" + MediaInfo.myList[iDev].array.size());
                if (MediaInfo.myList[iDev].array.size() > 0) {
                    getData(iDev);
                    resumeLastPlay(iDev);
                    if (bAutoPlay) {
                        for (Interface_Music interface_Music : mInterface_Musics) {
                            interface_Music.updateDeviceSelected(iDev, 0, true);
                            interface_Music.jumpPlayer();
                        }
                        if (MediaInfo.myList[iDev].array.size() > 0) {
                            SparseArray<String> map = MediaInfo.myList[iDev].array.get(0);
                            playFile(map.get(FinalMusicCtrl.GridItem_Path), true);
                        } else {
                            myMediaPlayer.end(true);
                            backToList();
                        }
                    }
                }
            }
            if (this.mIpcObj.isAppIdAudio()) {
                if (iDev == 24 && bInsertCdRom) {
                    bInsertCdRom = false;
                    if (!TextUtils.isEmpty(myMediaPlayer.mPlayPathDvd)) {
                        File file = new File(myMediaPlayer.mPlayPathDvd);
                        if (file.exists()) {
                            playFile(myMediaPlayer.mPlayPathDvd, false);
                        }
                    }
                }
                if (MediaInfo.isScanOver() && !bResumeLastPlayOnce) {
                    boolean bPlay1st = false;
                    if (Constant.bAutoPlayWhenStart && (iDev1stIncludeFile = MediaInfo.get1stDevIncludeFile()) >= 0) {
                        Log.d(TAG, "-------->>>   MediaInfo.isScanOver");
                        mDevPlay = iDev1stIncludeFile;
                        getData(mDevPlay);
                        bPlay1st = Constant.bAutoPlayWhenStart;
                    }
                    if (bPlay1st) {
                        int delay = 5000;
                        if (Util.is8541()) {
                            delay = 6000;
                        }
                        Util.writeLogToFile("mRunnable_Play1stFile");
                        Main.postRunnable_Ui(true, this.mRunnable_Play1stFile, delay);
                    }
                }
            }
        }
        if (MediaInfo.isScanOver()) {
            if (IpcObj.isAccOn()) {
                bScanFileCntOver = true;
            }
            Iterator<Interface_Music> it = mInterface_Musics.iterator();
            while (it.hasNext()) {
                it.next().hideScanTip();
            }
        }
    }

    public void accOnResymeLastPlay(int delay) {
        bResumeLastPlayOnce = true;
        Main.postRunnable_Ui(false, new mRunnable_AccOnResymeLastPlay(delay));
    }

    public class mRunnable_AccOnResymeLastPlay implements Runnable {
        int delayNum;

        public mRunnable_AccOnResymeLastPlay(int delayNum) {
            this.delayNum = delayNum;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.delayNum > 0) {
                this.delayNum--;
                File fileResume = new File(App_Music.mPathResume);
                if (fileResume.exists()) {
                    this.delayNum = 0;
                    App_Music.this.playFile(App_Music.mPathResume, false);
                    for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                        interface_Music.devSelectUpdate(MediaInfo.getDev(App_Music.mPathResume));
                    }
                    return;
                }
                Util.writeLogToFile("unmount");
                Main.postRunnable_Ui(false, this, 1000L);
                return;
            }
            Util.writeLogToFile("mRunnable_Play1stFile copy" + Util.is8541());
            Main.postRunnable_Ui(true, App_Music.this.mRunnable_Play1stFile, 0L);
        }
    }

    public void playFromOtherApp(String path) {
        Log.d(TAG, "------>>> playFromOtherApp");
        bIsSpeechList = false;
        MediaInfo.mSrcType = 0;
        mDevPlay = MediaInfo.getDev(path);
        mListModePlay = 0;
        if (mDevPlay == 24) {
            mTypePlay = 0;
        } else {
            mTypePlay = 0;
        }
        Log.d(TAG, "playFromOtherApp mDevPlay:" + mDevPlay);
        myMediaPlayer.setPlayPath(path);
        getData(mDevPlay);
        Log.d(TAG, "playFromOtherApp");
        if (listPlay.size() == 0) {
            scanFile(mDevPlay, false);
        }
    }

    public String setCycleMode(int mode, boolean flag) throws Throwable {
        String strRes;
        MediaInfo.mCycleMode = mode;
        switch (mode) {
            case 0:
                strRes = "str_repeat_all";
                break;
            case 1:
                strRes = "str_repeat_random";
                break;
            case 2:
                strRes = "str_repeat_list";
                break;
            case 3:
                strRes = "str_repeat_track";
                break;
            default:
                strRes = "str_repeat_all";
                break;
        }
        String str = this.uiApp.getString(strRes);
        if (mUpdateAppWidget != null) {
            mUpdateAppWidget.updateAppWidget();
        }
        this.mIpcObj.TransmitCycleMode();
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.updateCycleMode(mode, flag, str);
        }
        return str;
    }

    public void setSoundMode(int mode) {
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.updateSoundMode(mode);
        }
    }

    public void setSoundVolume(boolean isMute, int volume) {
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.updateSoundVolume(isMute, volume);
        }
    }

    public static boolean isLossFocus() {
        if (myAudioFocus != null) {
            return myAudioFocus.isLossFocus();
        }
        return true;
    }

    public void playFile(String strPath, boolean bSetListModePlay) {
        Log.d(TAG, "---------------->>> playFile:" + strPath);
        boolean resetMediaPlayer = false;
        if (!TextUtils.isEmpty(strPath)) {
            if (TextUtils.isEmpty(myMediaPlayer.mPlayPath) || !myMediaPlayer.mPlayPath.equals(strPath)) {
                resetMediaPlayer = true;
            }
            if (resetMediaPlayer) {
                reset();
            }
            if (mDev == 25) {
                MediaInfo.mSrcType = 1;
            } else {
                MediaInfo.mSrcType = 0;
            }
            myMediaPlayer.setPlayPath(strPath);
            mTypePlay = mType;
            mDevPlay = MediaInfo.getDev(strPath);
            Log.d(TAG, "playFile mDevPlay:" + mDevPlay);
            if (bSetListModePlay && mListMode != 3) {
                mListModePlay = mListMode;
                updatePlayList(strPath);
            }
        }
    }

    public String getId3Title() throws Throwable {
        if (TextUtils.isEmpty(mId3Info.strTitle) || mId3Info.strTitle.equals(this.uiApp.getString(EnvironmentCompat.MEDIA_UNKNOWN))) {
            String videoName = "";
            if (!TextUtils.isEmpty(myMediaPlayer.mPlayPath)) {
                int posStart = myMediaPlayer.mPlayPath.lastIndexOf("/");
                int posEnd = myMediaPlayer.mPlayPath.lastIndexOf(".");
                if (posStart >= 0 && posEnd >= 0) {
                    videoName = myMediaPlayer.mPlayPath.substring(posStart + 1, posEnd);
                }
            }
            if (!TextUtils.isEmpty(videoName)) {
                String strTitle = videoName;
                return strTitle;
            }
            String strTitle2 = this.uiApp.getString(EnvironmentCompat.MEDIA_UNKNOWN);
            return strTitle2;
        }
        String strTitle3 = mId3Info.strTitle;
        return strTitle3;
    }

    public void jumpPlayer() {
        if (mInterface_Musics.size() == 0) {
            MyApplication.myApp.jumpAct("Music");
            return;
        }
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.jumpPlayer();
        }
    }

    public static DownloadTask getTaskByPath(String strPath) {
        int iSize = mListTaskDown.size();
        for (int i = 0; i < iSize; i++) {
            DownloadTask task = mListTaskDown.get(i);
            if (task != null && task.strFilePath.equals(strPath)) {
                return task;
            }
        }
        return null;
    }

    public void saveSet() throws Throwable {
        this.mySharePreference2.saveIntValue(CYCLE_MODE, MediaInfo.mCycleMode);
        myMediaPlayer.savePos();
    }

    public void readSet() {
    }

    private class Runnable_GetList implements Runnable {
        private List<Song> songs;

        public Runnable_GetList(List<Song> songs) {
            this.songs = songs;
        }

        @Override // java.lang.Runnable
        public void run() {
            SparseArray<String> child;
            Log.d(App_Music.TAG, "Runnable_GetList");
            if (this.songs != null && this.songs.size() > 0) {
                App_Music.bIsSpeechList = true;
                App_Music.listPlay.clear();
                for (Song song : this.songs) {
                    String path = song.getPath();
                    File sdDir = Environment.getExternalStorageDirectory();
                    if (sdDir != null) {
                        String strNativeHead = sdDir.toString();
                        if (path.startsWith(strNativeHead)) {
                            path = path.replace(strNativeHead, App_Music.Path_Native);
                        }
                    }
                    Lrc lrc = new Lrc();
                    if (!App_Music.bNoListAlbum) {
                        Id3Info id3info = lrc.getId3Info(song.getPath(), true, false);
                        child = App_Music.getMapFile(song.getTitle(), path, id3info.strTitle, id3info.strArtist);
                    } else {
                        child = App_Music.getMapFile(song.getPath(), path, "", "");
                    }
                    App_Music.listPlay.add(child);
                }
                for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                    interface_Music.handleGetData();
                }
                if (App_Music.listPlay.size() > 0) {
                    SparseArray<String> map = App_Music.listPlay.get(0);
                    App_Music.this.playFile(map.get(FinalMusicCtrl.GridItem_Path), false);
                }
            }
        }
    }

    @Override // android.content.ServiceConnection
    public void onServiceConnected(ComponentName name, IBinder service) {
        if (service != null) {
            this.mTools = ITransitService.Stub.asInterface(service);
            if (this.mTools != null) {
                try {
                    this.mTools.addOnCommandListener(this.mCmdListener);
                    this.mTools.addOnMusicDataListener(this.mMusicDataListener);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override // android.content.ServiceConnection
    public void onServiceDisconnected(ComponentName arg0) {
        this.mTools = null;
        Intent intent = new Intent("com.syu.sha.TransitService");
        intent.setPackage("com.syu.sha");
        MyApplication.myApp.bindService(intent, this, 1);
    }

    @Override // com.lsec.core.frame.app.MyApp
    public void requestAppIdRight() {
        this.mIpcObj.requestAppIdRight();
    }

    @Override // com.lsec.core.util.IConnectedMain
    public void onConnected_Main() {
        this.mIpcObj.TransmitCycleMode();
    }

    public void EnableGainSpec() {
        bEnableSpec = true;
        this.mIpcObj.EnableGainSpec();
    }

    public void DisableGainSpec() {
        bEnableSpec = false;
        this.mIpcObj.DisableGainSpec();
    }

    public boolean isHalfScreenAble() {
        ActivityManager am;
        int iScreenMode = 0;
        if (this.fytGetState != null && (am = (ActivityManager) MyApplication.myApp.getSystemService("activity")) != null) {
            try {
                iScreenMode = ((Integer) this.fytGetState.invoke(am, new Object[0])).intValue();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return (iScreenMode & 32) != 0;
    }

    public int getFullScreenMode() {
        ActivityManager am;
        int iScreenMode = -1;
        if (this.fytGetState != null && (am = (ActivityManager) MyApplication.myApp.getSystemService("activity")) != null) {
            try {
                iScreenMode = ((Integer) this.fytGetState.invoke(am, new Object[0])).intValue();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return iScreenMode & 15;
    }

    public void setFullScreenMode(int iScreenMode) {
        ActivityManager am;
        if (this.fytSetState != null && (am = (ActivityManager) MyApplication.myApp.getSystemService("activity")) != null) {
            boolean bNeedSet = true;
            if (iScreenMode == 16) {
                try {
                    int iCurScreenMode = ((Integer) this.fytGetState.invoke(am, new Object[0])).intValue();
                    if ((iCurScreenMode & 16) != 0) {
                        bNeedSet = false;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (bNeedSet) {
                try {
                    this.fytSetState.invoke(am, Integer.valueOf(iScreenMode));
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        }
    }

    public static SparseArray<String> getMapFileFav(String strName, String strPath, String strFolder, String strArtist, String strAlbum) {
        SparseArray<String> map_Fav = new SparseArray<>();
        map_Fav.put(FinalMusicCtrl.GridItem_Name, strName);
        map_Fav.put(FinalMusicCtrl.GridItem_Index, "");
        map_Fav.put(FinalMusicCtrl.GridItem_NameCompare, HanziToPinyin.getPinYin(strName.trim(), true));
        map_Fav.put(FinalMusicCtrl.GridItem_NamePyHead, HanziToPinyin.getHeadPinyin(strName.trim()));
        map_Fav.put(FinalMusicCtrl.GridItem_Path, strPath);
        map_Fav.put(FinalMusicCtrl.GridItem_Fav_Folder, strFolder);
        map_Fav.put(FinalMusicCtrl.GridItem_Fav_Artist, strArtist);
        map_Fav.put(FinalMusicCtrl.GridItem_Fav_Album, strAlbum);
        return map_Fav;
    }

    public static SparseArray<String> getMapFile(String strName, String strPath, String strTitle, String strArtist) {
        SparseArray<String> child = new SparseArray<>();
        child.put(FinalMusicCtrl.GridItem_Name, strName);
        child.put(FinalMusicCtrl.GridItem_Index, "");
        child.put(FinalMusicCtrl.GridItem_NameCompare, HanziToPinyin.getPinYin(strName.trim(), true));
        child.put(FinalMusicCtrl.GridItem_NamePyHead, HanziToPinyin.getHeadPinyin(strName.trim()));
        child.put(FinalMusicCtrl.GridItem_Path, strPath);
        child.put(FinalMusicCtrl.GridItem_Title, strTitle);
        child.put(FinalMusicCtrl.GridItem_Artist, strArtist);
        return child;
    }

    public static SparseArray<String> getMapFileNormal(String strName, String strPath) {
        SparseArray<String> child = new SparseArray<>();
        child.put(FinalMusicCtrl.GridItem_Name, strName);
        child.put(FinalMusicCtrl.GridItem_Index, "");
        child.put(FinalMusicCtrl.GridItem_NameCompare, HanziToPinyin.getPinYin(strName.trim(), true));
        child.put(FinalMusicCtrl.GridItem_NamePyHead, HanziToPinyin.getHeadPinyin(strName.trim()));
        child.put(FinalMusicCtrl.GridItem_Path, strPath);
        return child;
    }

    public static MyFolder getFolder(String strFolder) {
        MyFolder folder = new MyFolder();
        folder.map.put(FinalMusicCtrl.GridItem_Name, strFolder);
        folder.map.put(FinalMusicCtrl.GridItem_Index, "");
        folder.map.put(FinalMusicCtrl.GridItem_NameCompare, HanziToPinyin.getPinYin(strFolder.trim(), true));
        folder.map.put(FinalMusicCtrl.GridItem_NamePyHead, HanziToPinyin.getHeadPinyin(strFolder.trim()));
        return folder;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [com.syu.app.App_Music$16] */
    public void simulateKey(final int keyCode) {
        new Thread() { // from class: com.syu.app.App_Music.16
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                try {
                    Instrumentation inst = new Instrumentation();
                    inst.sendKeyDownUpSync(keyCode);
                } catch (Exception e) {
                }
            }
        }.start();
    }

    public static boolean includePage(int idPage) {
        return idPage >= 110001 && idPage < 120001;
    }

    public boolean isAppTop() {
        if (MyApplication.myApp.isAppTop()) {
            return includePage(MyApplication.sPage_Current);
        }
        return false;
    }

    public synchronized void setAppState(boolean flag) {
        bAppMoveToBack = flag;
    }

    public synchronized boolean getAppState() {
        return bAppMoveToBack;
    }

    public static void invilatePlayList(HashMap<String, byte[]> data) {
        myAlbum.clear();
        myAlbum.putAll(data);
        for (Interface_Music interface_Music : mInterface_Musics) {
            interface_Music.invilatePlayList();
        }
    }
}
