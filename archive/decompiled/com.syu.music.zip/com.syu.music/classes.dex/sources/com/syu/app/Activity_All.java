package com.syu.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import com.lsec.core.frame.app.MyAct;
import com.lsec.core.frame.app.MyActivity;
import com.lsec.core.frame.app.MyApp;
import com.lsec.core.frame.app.MyApplication;
import com.lsec.core.frame.app.MyUi;
import com.lsec.core.frame.ctrl.JPage;
import com.syu.media.data.FinalMusicCtrl;
import com.syu.music.Act_Music;
import java.util.ArrayList;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class Activity_All extends MyActivity {
    ArrayList<MyAct> mListMyActs = new ArrayList<>();
    Act_Music mActMusic = new Act_Music();

    @Override // com.lsec.core.frame.app.MyActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        this.mListMyActs.add(this.mActMusic);
        initSystemUiTranSparent();
        super.onCreate(savedInstanceState);
    }

    @SuppressLint({"NewApi"})
    public void initSystemUiTranSparent() {
        Window window = getWindow();
        window.requestFeature(1);
        window.clearFlags(1024);
        String str = App.mMusicCarType;
        switch (str.hashCode()) {
            case -1395821281:
                if (str.equals("bba_bc")) {
                    return;
                }
                break;
            case -1395821271:
                if (str.equals("bba_bm")) {
                    return;
                }
                break;
        }
        if (!App.mStrCustomer.equals("YF_MUSIC") && !App.mStrCustomer.equals("zhtd_benz") && !App.mStrCustomer.equals("MUSIC") && Build.VERSION.SDK_INT >= 21) {
            window.clearFlags(201326592);
            window.getDecorView().setSystemUiVisibility(1792);
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(0);
            window.setNavigationBarColor(0);
        }
    }

    @Override // com.lsec.core.frame.app.MyActivity, android.app.Activity
    protected void onDestroy() {
        for (MyAct myAct : this.mListMyActs) {
            myAct.onDestroy();
        }
        super.onDestroy();
    }

    @Override // com.lsec.core.frame.app.MyActivity
    public void handleIntent(Intent intent) {
        for (MyAct myAct : this.mListMyActs) {
            myAct.onNewIntent(intent, this);
        }
    }

    @Override // com.lsec.core.frame.app.MyActivity
    public void doActionResume() {
        super.doActionResume();
        if (!App_Music.includePage(MyApplication.sPage_WillBe)) {
            MyApplication.sPage_WillBe = FinalMusicCtrl.Page_Player;
        }
        MyAct myAct = getFixAct(MyApplication.sPage_WillBe);
        if (myAct != null && myAct.myActivity == null) {
            myAct.onCreate(this);
        }
        goPage(MyApplication.sPage_WillBe);
        if (myAct != null) {
            myAct.onResume();
        }
    }

    @Override // com.lsec.core.frame.app.MyActivity
    public void doActionPause() {
        super.doActionPause();
        MyAct myAct = getFixAct(MyApplication.sPage_Current);
        if (myAct != null) {
            myAct.onPause();
        }
        if (this.mPageCurrent != null) {
            this.mPageCurrent.pause();
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        MyAct myAct = getFixAct(MyApplication.sPage_Current);
        if (myAct == null || !myAct.onKeyDown(keyCode, event)) {
            return super.onKeyDown(keyCode, event);
        }
        return true;
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        MyAct myAct = getFixAct(MyApplication.sPage_Current);
        if (myAct == null || !myAct.onKeyUp(keyCode, event)) {
            return super.onKeyUp(keyCode, event);
        }
        return true;
    }

    @Override // android.app.Activity
    public boolean onTouchEvent(MotionEvent event) {
        MyAct myAct = getFixAct(MyApplication.sPage_Current);
        if (myAct != null) {
            myAct.onTouchEvent(event);
        }
        return super.onTouchEvent(event);
    }

    @Override // com.lsec.core.frame.app.MyActivity
    public void requestAppIdRight() {
        MyApp myApp = getFixApp(MyApplication.sPage_Current);
        if (myApp != null) {
            myApp.requestAppIdRight();
        }
    }

    public MyAct getFixAct(int idPage) {
        for (MyAct myAct : this.mListMyActs) {
            if (myAct.includePage(idPage)) {
                return myAct;
            }
        }
        return null;
    }

    public MyApp getFixApp(int idPage) {
        for (MyAct myAct : this.mListMyActs) {
            if (myAct.includePage(idPage)) {
                return myAct.getMyApp();
            }
        }
        return null;
    }

    public MyUi getFixUi(int idPage) {
        MyAct myAct = getFixAct(idPage);
        if (myAct != null) {
            return myAct.ui;
        }
        return null;
    }

    @Override // com.lsec.core.frame.app.MyActivity
    public void handleSizeChanged() {
        super.handleSizeChanged();
        if (MyApplication.sPage_Current != 110009) {
            goPage(FinalMusicCtrl.Page_Player);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (this.mActMusic != null) {
            this.mActMusic.windowFocusChanged(hasFocus);
        }
    }

    @Override // com.lsec.core.frame.app.MyActivity
    public void goPage(int idPageTo) {
        MyAct myAct = getFixAct(idPageTo);
        if (myAct != null) {
            if (myAct.myActivity == null) {
                myAct.onCreate(this);
            }
            this.mPageMain.setBackground(myAct.getBackground());
            myAct.addChild2Parent(this.mPageMain);
            idPageTo = myAct.getRightPage(idPageTo);
        }
        MyUi uiTo = getFixUi(idPageTo);
        if (uiTo != null) {
            JPage pageFrom = this.mPageCurrent;
            if (pageFrom != null) {
                int idPageFrom = pageFrom.getId();
                if (idPageFrom == idPageTo && !pageFrom.isNeedReload()) {
                    pageFrom.resume();
                    return;
                }
            }
            JPage pageTo = uiTo.loadPage(true, idPageTo);
            if (pageTo != null) {
                MyApplication.sPage_Current = idPageTo;
                MyApplication.sPage_WillBe = MyApplication.sPage_Current;
                MyApp myApp = getFixApp(idPageTo);
                if (myApp != null) {
                    myApp.sPage = idPageTo;
                }
                if (this.mPageMain.indexOfChild(pageTo) < 0) {
                    this.mPageMain.addView(pageTo);
                }
                this.mPageCurrent = pageTo;
                if (pageFrom != null) {
                    pageFrom.pause();
                    ViewParent viewParent = pageFrom.getParent();
                    if (viewParent instanceof ViewGroup) {
                        ((ViewGroup) viewParent).removeView(pageFrom);
                    }
                }
                pageTo.resume();
                for (MyAct myActTmp : this.mListMyActs) {
                    myActTmp.doActionWhenGoPage(idPageTo);
                    if (!myActTmp.includePage(idPageTo)) {
                        myActTmp.removeChildFromParent(this.mPageMain);
                    }
                }
            }
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();
        int action = event.getAction();
        if (action == 1 && this.mActMusic != null) {
            this.mActMusic.dispatchMyKeyEvent(keyCode);
        }
        return super.dispatchKeyEvent(event);
    }
}
