package com.syu.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.syu.app.App_Music;
import com.syu.media.core.MediaInfo;
import com.syu.music.Interface_Music;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class Receiver_EasyConn extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action.equals(Receiver.ACTION_EASYCONN_BREAK)) {
            MediaInfo.clear(25);
            for (Interface_Music interface_Music : App_Music.mInterface_Musics) {
                interface_Music.handleEasyBreak();
            }
            return;
        }
        if (action.equals(Receiver.ACTION_CHANGE_COLOR)) {
            for (Interface_Music interface_Music2 : App_Music.mInterface_Musics) {
                interface_Music2.resetColor();
            }
        }
    }
}
