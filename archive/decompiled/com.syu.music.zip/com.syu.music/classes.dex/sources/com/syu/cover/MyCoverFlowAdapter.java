package com.syu.cover;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import com.syu.app.App_Music;
import com.syu.media.data.FinalMusicCtrl;
import com.syu.util.Id3Info;
import com.syu.util.Lrc;
import com.syu.util.Util;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class MyCoverFlowAdapter extends CoverFlowAdapter {
    public Context context;
    Bitmap defalutBitmap;
    public static int bmpWidth = 182;
    public static int bmpHeight = 182;
    public List<SparseArray<String>> listPlay = new ArrayList();
    Bitmap album = null;
    HashMap<String, Drawable> mapDrawables = new HashMap<>();

    public MyCoverFlowAdapter(Context context) {
        BitmapDrawable bitmapDrawable;
        this.defalutBitmap = null;
        this.context = context;
        switch (App_Music.mColorType) {
            case 0:
                if (Util.getWindowManeger()[0] == 1024 || Util.getWindowManeger()[1] == 600) {
                    Log.d(App_Music.TAG, "pink_music_id3pic_default_1024");
                    bitmapDrawable = (BitmapDrawable) App_Music.getInstance().uiApp.getDrawableFromPath("pink_music_id3pic_default_1024", this.mapDrawables, null);
                } else {
                    bitmapDrawable = (BitmapDrawable) App_Music.getInstance().uiApp.getDrawableFromPath("pink_music_id3pic_default", this.mapDrawables, null);
                }
                break;
            case 1:
                bitmapDrawable = (BitmapDrawable) App_Music.getInstance().uiApp.getDrawableFromPath("red_music_id3pic_default", this.mapDrawables, null);
                break;
            case 2:
            default:
                if (Util.getWindowManeger()[0] == 1280 || Util.getWindowManeger()[1] == 720) {
                    Log.d(App_Music.TAG, "music_id3pic_default-1280x720");
                    bitmapDrawable = (BitmapDrawable) App_Music.getInstance().uiApp.getDrawableFromPath("music_id3pic_default_1280", this.mapDrawables, null);
                } else if (Util.getWindowManeger()[0] == 1024 || Util.getWindowManeger()[1] == 600) {
                    bitmapDrawable = (BitmapDrawable) App_Music.getInstance().uiApp.getDrawableFromPath("music_id3pic_default_1024", this.mapDrawables, null);
                } else if (Util.getWindowManeger()[0] == 800 || Util.getWindowManeger()[1] == 480) {
                    Log.d(App_Music.TAG, "music_id3pic_default-800x480");
                    bitmapDrawable = (BitmapDrawable) App_Music.getInstance().uiApp.getDrawableFromPath("music_id3pic_default_800", this.mapDrawables, null);
                } else {
                    bitmapDrawable = (BitmapDrawable) App_Music.getInstance().uiApp.getDrawableFromPath("music_id3pic_default", this.mapDrawables, null);
                }
                break;
            case 3:
                bitmapDrawable = (BitmapDrawable) App_Music.getInstance().uiApp.getDrawableFromPath("blue_music_id3pic_default", this.mapDrawables, null);
                break;
            case 4:
                bitmapDrawable = (BitmapDrawable) App_Music.getInstance().uiApp.getDrawableFromPath("purple_music_id3pic_default", this.mapDrawables, null);
                break;
        }
        if (bitmapDrawable != null) {
            this.defalutBitmap = bitmapDrawable.getBitmap();
        }
    }

    public void resetList(List<SparseArray<String>> list) {
        if (this.listPlay != null && list != null) {
            boolean bNeedNotify = true;
            int iSize = this.listPlay.size();
            int iSizeList = list.size();
            if (iSize == iSizeList) {
                if (iSize == 0) {
                    bNeedNotify = false;
                } else if (iSize > 0 && this.listPlay.containsAll(list)) {
                    bNeedNotify = false;
                }
            }
            if (bNeedNotify) {
                this.listPlay.clear();
                this.listPlay.addAll(list);
                notifyDataSetChanged();
            }
        }
    }

    public void setBmpSize(int width, int height) {
        bmpWidth = width;
        bmpHeight = height;
    }

    @Override // com.syu.cover.CoverFlowAdapter
    public int getCount() {
        return this.listPlay.size();
    }

    @Override // com.syu.cover.CoverFlowAdapter
    public Bitmap getImage(int position, boolean bGetAPIC) {
        if (position >= this.listPlay.size() || position < 0) {
            return null;
        }
        if (bGetAPIC) {
            SparseArray<String> info = this.listPlay.get(position);
            String strPath = info.get(FinalMusicCtrl.GridItem_Path);
            Lrc lrc = new Lrc();
            Id3Info id3info = lrc.getId3Info(strPath, false, true);
            byte[] b = id3info.dataPic;
            if (b == null) {
                this.album = this.defalutBitmap;
                return this.album;
            }
            this.album = BitmapFactory.decodeByteArray(b, 0, b.length);
            if (this.album != null) {
                this.album = Bitmap.createScaledBitmap(this.album, bmpWidth, bmpHeight, true);
            }
            if (this.album == null) {
                this.album = this.defalutBitmap;
            }
        } else {
            this.album = this.defalutBitmap;
        }
        return this.album.copy(Bitmap.Config.RGB_565, true);
    }

    @Override // com.syu.cover.CoverFlowAdapter
    public String getTitle(int position) {
        if (position > this.listPlay.size() || position < 0) {
            return null;
        }
        SparseArray<String> info = this.listPlay.get(position);
        if (!TextUtils.isEmpty(info.get(FinalMusicCtrl.GridItem_Title))) {
            return info.get(FinalMusicCtrl.GridItem_Title);
        }
        return info.get(FinalMusicCtrl.GridItem_Name);
    }
}
