package com.lsec.core.util;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public interface InterfacePreviewFrame3 {
    void onPreviewFrame(MyCamera2Data myCamera2Data);
}
