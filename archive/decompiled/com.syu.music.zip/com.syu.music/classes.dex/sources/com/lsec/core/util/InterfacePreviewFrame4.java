package com.lsec.core.util;

import android.media.Image;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public interface InterfacePreviewFrame4 {
    void onPreviewFrame(Image image);
}
