package com.lsec.core.frame.camera;

import android.graphics.SurfaceTexture;
import android.os.SystemProperties;
import android.text.TextUtils;
import com.lsec.core.ipc.module.main.Main;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class Runnable_setPreviewSurfTexture implements Runnable {
    public boolean bRunning = true;
    SurfaceTexture surface;

    Runnable_setPreviewSurfTexture(SurfaceTexture surface) {
        if (surface == null) {
            this.surface = new SurfaceTexture(36197);
        } else {
            this.surface = surface;
        }
    }

    public void stopRun() {
        this.bRunning = false;
    }

    @Override // java.lang.Runnable
    public void run() {
        if (!MyCamera.getInstance().bShutDown) {
            MyCamera.getInstance().open(MyCameraUtil.getCameraId());
            if (MyCamera.getInstance().mCamera == null) {
                if (this.bRunning) {
                    Main.postRunnable_Ui(true, this, 1000L);
                    return;
                }
                return;
            }
            boolean bNeedSetDisplayOrientation = MyCameraUtil.iDegree != 0;
            if (!bNeedSetDisplayOrientation) {
                String plat = SystemProperties.get("sys.fyt.platform", "");
                if (TextUtils.isEmpty(plat)) {
                    plat = SystemProperties.get("ro.fyt.platform", "");
                }
                if ("6315".equals(plat) || "6316".equals(plat)) {
                    bNeedSetDisplayOrientation = true;
                }
            }
            if (bNeedSetDisplayOrientation) {
                MyCamera.getInstance().mCamera.setDisplayOrientation(MyCameraUtil.iDegree);
            }
            try {
                MyCamera.getInstance().mCamera.setPreviewTexture(this.surface);
            } catch (Exception e) {
                e.printStackTrace();
            }
            boolean bStartPreview = false;
            boolean bInitCamera = MyCamera.getInstance().initCamera(MyCameraUtil.getCameraId());
            if (bInitCamera) {
                bStartPreview = MyCamera.getInstance().startPreView();
            }
            if (!bInitCamera || !bStartPreview) {
                Main.postRunnable_Ui(false, new Runnable() { // from class: com.lsec.core.frame.camera.Runnable_setPreviewSurfTexture.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (!MyCamera.getInstance().bShutDown) {
                            MyCamera.getInstance().setPreview(Runnable_setPreviewSurfTexture.this.surface, MyCameraUtil.idVideo, MyCameraUtil.iDegree);
                        }
                    }
                }, 500L);
            }
        }
    }
}
