package com.lsec.core.util.data;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class FinalMediaServer {
    public static final int C_CYCLE_MODE = 2;
    public static final int C_LIST_MP3 = 1;
    public static final int MODULE_CODE_MEDIASERVER = 0;
    public static final int U_BEGIN = 1;
    public static final int U_CNT_MAX = 10;
}
