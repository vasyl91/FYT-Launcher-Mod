package com.lsec.core.util;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public interface IUiNotify {
    void onNotify(int i, int[] iArr, float[] fArr, String[] strArr);
}
