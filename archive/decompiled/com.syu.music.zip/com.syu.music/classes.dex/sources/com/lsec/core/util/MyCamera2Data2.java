package com.lsec.core.util;

import java.nio.ByteBuffer;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class MyCamera2Data2 {
    public ByteBuffer mBuffer;
    public long mTicks;
}
