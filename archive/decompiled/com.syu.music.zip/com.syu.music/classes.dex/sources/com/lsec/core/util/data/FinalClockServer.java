package com.lsec.core.util.data;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class FinalClockServer {
    public static final int MODULE_CODE_CLOCKSERVER = 0;
    public static final int U_BEGIN = 1;
    public static final int U_CNT_MAX = 2;
}
