package com.lsec.core.util;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public interface InterfaceDvdConn {
    String updateOsdInfo_Dvd(int[] iArr);
}
