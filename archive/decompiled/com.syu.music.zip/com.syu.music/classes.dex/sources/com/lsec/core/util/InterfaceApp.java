package com.lsec.core.util;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public interface InterfaceApp {
    boolean isAppTop();

    boolean isFixVideoId(int i);

    void onConnected_Main();

    void requestAppIdRight();
}
