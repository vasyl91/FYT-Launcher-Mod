package com.lsec.core.util;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public class MySize {
    public int height;
    public int width;

    public MySize(int w, int h) {
        this.width = w;
        this.height = h;
    }
}
