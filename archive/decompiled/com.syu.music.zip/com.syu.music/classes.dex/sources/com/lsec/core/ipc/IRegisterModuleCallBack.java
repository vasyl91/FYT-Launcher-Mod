package com.lsec.core.ipc;

import com.syu.ipc.IModuleCallback;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public interface IRegisterModuleCallBack {
    void register(IModuleCallback iModuleCallback);
}
