package android.support.v4.internal.view;

import android.support.annotation.RestrictTo;
import android.view.SubMenu;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public interface SupportSubMenu extends SupportMenu, SubMenu {
}
