package android.support.v4.content.pm;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public final class ActivityInfoCompat {
    public static final int CONFIG_UI_MODE = 512;

    private ActivityInfoCompat() {
    }
}
