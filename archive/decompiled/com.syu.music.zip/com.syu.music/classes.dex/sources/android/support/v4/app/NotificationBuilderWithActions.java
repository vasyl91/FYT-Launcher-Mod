package android.support.v4.app;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
interface NotificationBuilderWithActions {
    void addAction(NotificationCompatBase.Action action);
}
