package android.support.v4.view;

import android.view.View;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\MusicPlayer.apk\dexFile\classes.dex */
public interface ViewPropertyAnimatorUpdateListener {
    void onAnimationUpdate(View view);
}
