package com.syu.carinfo.dongjian.wc2.ds5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.syu.canbus.BaseActivity;
import com.syu.canbus.R;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\com.syu.canbus_1.0.apk\dexFile\classes.dex */
public class DS5IndexAct extends BaseActivity implements View.OnClickListener {
    @Override // com.syu.canbus.BaseActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_302_dongjian_wc2_ds5_index);
        init();
        setUI();
    }

    public void setUI() {
        findViewById(R.id.dongjian_wc2_ds5_car_set_check).setOnClickListener(this);
        findViewById(R.id.dongjian_wc2_ds5_car_set_page1_check).setOnClickListener(this);
        findViewById(R.id.dongjian_wc2_ds5_car_set_page2_check).setOnClickListener(this);
        findViewById(R.id.dongjian_wc2_ds5_car_set_page3_check).setOnClickListener(this);
        findViewById(R.id.dongjian_wc2_ds5_car_system_set_check).setOnClickListener(this);
        findViewById(R.id.dongjian_wc2_ds5_unit_set_index_check).setOnClickListener(this);
        findViewById(R.id.dongjian_wc2_ds5_time_set_index_check).setOnClickListener(this);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.dongjian_wc2_ds5_car_set_check /* 2131429259 */:
                try {
                    Intent intent = new Intent(this, (Class<?>) DS5CarLogAct.class);
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
                break;
            case R.id.dongjian_wc2_ds5_car_set_page1_check /* 2131429260 */:
                try {
                    Intent intent2 = new Intent(this, (Class<?>) DS5CarLog1Act.class);
                    startActivity(intent2);
                } catch (Exception e2) {
                    e2.printStackTrace();
                    return;
                }
                break;
            case R.id.dongjian_wc2_ds5_car_set_page2_check /* 2131429261 */:
                try {
                    Intent intent3 = new Intent(this, (Class<?>) DS5CarLog2Act.class);
                    startActivity(intent3);
                } catch (Exception e3) {
                    e3.printStackTrace();
                    return;
                }
                break;
            case R.id.dongjian_wc2_ds5_car_set_page3_check /* 2131429262 */:
                try {
                    Intent intent4 = new Intent(this, (Class<?>) DS5CarLog3Act.class);
                    startActivity(intent4);
                } catch (Exception e4) {
                    e4.printStackTrace();
                    return;
                }
                break;
            case R.id.dongjian_wc2_ds5_car_system_set_check /* 2131429263 */:
                try {
                    Intent intent5 = new Intent(this, (Class<?>) DS5CarSetInfoAct.class);
                    startActivity(intent5);
                } catch (Exception e5) {
                    e5.printStackTrace();
                    return;
                }
                break;
            case R.id.dongjian_wc2_ds5_unit_set_index_check /* 2131429264 */:
                try {
                    Intent intent6 = new Intent(this, (Class<?>) DS5CarUnitSetAct.class);
                    startActivity(intent6);
                } catch (Exception e6) {
                    e6.printStackTrace();
                    return;
                }
                break;
            case R.id.dongjian_wc2_ds5_time_set_index_check /* 2131429265 */:
                try {
                    Intent intent7 = new Intent(this, (Class<?>) DS5CarTimeSetAct.class);
                    startActivity(intent7);
                } catch (Exception e7) {
                    e7.printStackTrace();
                    return;
                }
                break;
        }
    }
}
