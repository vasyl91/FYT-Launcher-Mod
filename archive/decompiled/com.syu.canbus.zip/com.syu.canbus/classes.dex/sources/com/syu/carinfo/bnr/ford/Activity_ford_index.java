package com.syu.carinfo.bnr.ford;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import com.syu.canbus.BaseActivity;
import com.syu.canbus.R;
import com.syu.carinfo.focus.FocusSyncBtActi;
import com.syu.module.canbus.DataCanbus;
import java.util.ArrayList;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\com.syu.canbus_1.0.apk\dexFile\classes.dex */
public class Activity_ford_index extends BaseActivity implements View.OnClickListener {
    private ArrayList<String> mFragmentlist;

    @Override // com.syu.canbus.BaseActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_0403_bnr_ford_index);
        init();
    }

    @Override // com.syu.canbus.BaseActivity
    public void init() {
        View carset = findViewById(R.id.id_carset);
        View sync = findViewById(R.id.ctv_ylfocus_sync);
        View seatset = findViewById(R.id.id_seatset);
        setSelfClick(carset, this);
        setSelfClick(sync, this);
        setSelfClick(seatset, this);
        setSelfClick(findViewById(R.id.ctv_checkedtext1), this);
        setSelfClick(findViewById(R.id.ctv_checkedtext2), this);
        if (197011 != DataCanbus.DATA[1000]) {
            findViewById(R.id.layout_view1).setVisibility(8);
            findViewById(R.id.layout_view2).setVisibility(8);
        }
        this.mFragmentlist = new ArrayList<>();
        this.mFragmentlist.add(fragment_ford_carset.class.getCanonicalName());
        this.mFragmentlist.add(fragment_ford_seatset.class.getCanonicalName());
    }

    @Override // com.syu.canbus.BaseActivity, android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            FragmentTransaction beginTransaction = getFragmentManager().beginTransaction();
            for (String str : this.mFragmentlist) {
                Fragment findFragmentByTag = getFragmentManager().findFragmentByTag(str);
                if (findFragmentByTag != null && findFragmentByTag.isAdded()) {
                    beginTransaction.remove(findFragmentByTag).commitAllowingStateLoss();
                    return true;
                }
            }
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ctv_checkedtext1 /* 2131427478 */:
                try {
                    Intent intent = new Intent(this, (Class<?>) KXMDOCarTire.class);
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
                break;
            case R.id.ctv_checkedtext2 /* 2131427531 */:
                try {
                    Intent intent2 = new Intent(this, (Class<?>) KXMDOEQSetAct.class);
                    startActivity(intent2);
                } catch (Exception e2) {
                    e2.printStackTrace();
                    return;
                }
                break;
            case R.id.id_carset /* 2131428045 */:
                FragmentTransaction beginTransaction = getFragmentManager().beginTransaction();
                beginTransaction.replace(R.id.container, new fragment_ford_carset(), this.mFragmentlist.get(0)).commitAllowingStateLoss();
                break;
            case R.id.ctv_ylfocus_sync /* 2131428047 */:
                try {
                    Intent intent3 = new Intent(this, (Class<?>) FocusSyncBtActi.class);
                    startActivity(intent3);
                } catch (Exception e3) {
                    e3.printStackTrace();
                    return;
                }
                break;
            case R.id.id_seatset /* 2131428048 */:
                FragmentTransaction beginTransaction2 = getFragmentManager().beginTransaction();
                beginTransaction2.replace(R.id.container, new fragment_ford_seatset(), this.mFragmentlist.get(1)).commitAllowingStateLoss();
                break;
        }
    }
}
