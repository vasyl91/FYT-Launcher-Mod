package com.android.server.am;

import android.os.Build;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
class ActivityManagerDebugConfig {
    static final boolean APPEND_CATEGORY_NAME = false;
    static boolean DEBUG_ALL = false;
    static boolean DEBUG_ANR = true;
    static boolean DEBUG_BACKGROUND_CHECK = false;
    static boolean DEBUG_BACKUP = false;
    static boolean DEBUG_BROADCAST = false;
    static boolean DEBUG_BROADCAST_BACKGROUND = false;
    static boolean DEBUG_BROADCAST_DEFERRAL = false;
    static boolean DEBUG_BROADCAST_LIGHT = false;
    static boolean DEBUG_BROADCAST_SPRD = false;
    static boolean DEBUG_BROADCAST_SPRD_TORTUOUS = false;
    static boolean DEBUG_COMPACTION = false;
    static boolean DEBUG_FOREGROUND_SERVICE = false;
    static boolean DEBUG_LRU = false;
    static boolean DEBUG_MU = false;
    static boolean DEBUG_NETWORK = false;
    static boolean DEBUG_OOM_ADJ = false;
    static boolean DEBUG_OOM_ADJ_REASON = false;
    static boolean DEBUG_PERMISSIONS_REVIEW = false;
    static boolean DEBUG_POWER = false;
    static boolean DEBUG_POWER_QUICK = false;
    static boolean DEBUG_PROCESSES = false;
    static boolean DEBUG_PROCESS_OBSERVERS = false;
    static boolean DEBUG_PROVIDER = false;
    static boolean DEBUG_PSS = false;
    static boolean DEBUG_SERVICE = false;
    static boolean DEBUG_SERVICE_EXECUTING = false;
    static boolean DEBUG_UID_OBSERVERS = false;
    static boolean DEBUG_USAGE_STATS = false;
    static boolean DEBUG_WHITELISTS = false;
    static final String POSTFIX_BACKUP = "";
    static final String POSTFIX_BROADCAST = "";
    static final String POSTFIX_CLEANUP = "";
    static final String POSTFIX_LRU = "";
    static final String POSTFIX_MU = "_MU";
    static final String POSTFIX_NETWORK = "_Network";
    static final String POSTFIX_OOM_ADJ = "";
    static final String POSTFIX_POWER = "";
    static final String POSTFIX_PROCESSES = "";
    static final String POSTFIX_PROCESS_OBSERVERS = "";
    static final String POSTFIX_PROVIDER = "";
    static final String POSTFIX_PSS = "";
    static final String POSTFIX_SERVICE = "";
    static final String POSTFIX_SERVICE_EXECUTING = "";
    static final String POSTFIX_UID_OBSERVERS = "";
    static final String TAG_AM = "ActivityManager";
    static final boolean TAG_WITH_CLASS_NAME = false;

    ActivityManagerDebugConfig() {
    }

    static {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        boolean z6;
        boolean z7;
        boolean z8;
        boolean z9;
        boolean z10;
        boolean z11;
        boolean z12;
        boolean z13;
        boolean z14;
        boolean z15;
        boolean z16;
        boolean z17;
        boolean z18;
        boolean z19;
        boolean z20;
        boolean z21;
        boolean z22;
        boolean z23;
        boolean z24;
        boolean z25;
        boolean z26;
        boolean z27 = false;
        if (!DEBUG_ALL) {
            z = false;
        } else {
            z = true;
        }
        DEBUG_BACKGROUND_CHECK = z;
        if (!DEBUG_ALL) {
            z2 = false;
        } else {
            z2 = true;
        }
        DEBUG_BACKUP = z2;
        if (!DEBUG_ALL) {
            z3 = false;
        } else {
            z3 = true;
        }
        DEBUG_BROADCAST = z3;
        if (!DEBUG_BROADCAST) {
            z4 = false;
        } else {
            z4 = true;
        }
        DEBUG_BROADCAST_BACKGROUND = z4;
        if (!DEBUG_BROADCAST) {
            z5 = false;
        } else {
            z5 = true;
        }
        DEBUG_BROADCAST_LIGHT = z5;
        if (!DEBUG_BROADCAST) {
            z6 = false;
        } else {
            z6 = true;
        }
        DEBUG_BROADCAST_DEFERRAL = z6;
        if (!DEBUG_BROADCAST && Build.IS_USER) {
            z7 = false;
        } else {
            z7 = true;
        }
        DEBUG_BROADCAST_SPRD = z7;
        if (!DEBUG_BROADCAST) {
            z8 = false;
        } else {
            z8 = true;
        }
        DEBUG_BROADCAST_SPRD_TORTUOUS = z8;
        if (!DEBUG_ALL) {
            z9 = false;
        } else {
            z9 = true;
        }
        DEBUG_COMPACTION = z9;
        if (!DEBUG_ALL) {
            z10 = false;
        } else {
            z10 = true;
        }
        DEBUG_LRU = z10;
        if (!DEBUG_ALL) {
            z11 = false;
        } else {
            z11 = true;
        }
        DEBUG_MU = z11;
        if (!DEBUG_ALL) {
            z12 = false;
        } else {
            z12 = true;
        }
        DEBUG_NETWORK = z12;
        if (!DEBUG_ALL) {
            z13 = false;
        } else {
            z13 = true;
        }
        DEBUG_OOM_ADJ = z13;
        if (!DEBUG_ALL) {
            z14 = false;
        } else {
            z14 = true;
        }
        DEBUG_OOM_ADJ_REASON = z14;
        if (!DEBUG_ALL) {
            z15 = false;
        } else {
            z15 = true;
        }
        DEBUG_POWER = z15;
        if (!DEBUG_POWER) {
            z16 = false;
        } else {
            z16 = true;
        }
        DEBUG_POWER_QUICK = z16;
        if (!DEBUG_ALL) {
            z17 = false;
        } else {
            z17 = true;
        }
        DEBUG_PROCESS_OBSERVERS = z17;
        if (!DEBUG_ALL) {
            z18 = false;
        } else {
            z18 = true;
        }
        DEBUG_PROCESSES = z18;
        if (!DEBUG_ALL) {
            z19 = false;
        } else {
            z19 = true;
        }
        DEBUG_PROVIDER = z19;
        if (!DEBUG_ALL) {
            z20 = false;
        } else {
            z20 = true;
        }
        DEBUG_PSS = z20;
        if (!DEBUG_ALL) {
            z21 = false;
        } else {
            z21 = true;
        }
        DEBUG_SERVICE = z21;
        if (!DEBUG_ALL) {
            z22 = false;
        } else {
            z22 = true;
        }
        DEBUG_FOREGROUND_SERVICE = z22;
        if (!DEBUG_ALL) {
            z23 = false;
        } else {
            z23 = true;
        }
        DEBUG_SERVICE_EXECUTING = z23;
        if (!DEBUG_ALL) {
            z24 = false;
        } else {
            z24 = true;
        }
        DEBUG_UID_OBSERVERS = z24;
        if (!DEBUG_ALL) {
            z25 = false;
        } else {
            z25 = true;
        }
        DEBUG_USAGE_STATS = z25;
        if (!DEBUG_ALL) {
            z26 = false;
        } else {
            z26 = true;
        }
        DEBUG_PERMISSIONS_REVIEW = z26;
        if (DEBUG_ALL) {
            z27 = true;
        }
        DEBUG_WHITELISTS = z27;
    }
}
