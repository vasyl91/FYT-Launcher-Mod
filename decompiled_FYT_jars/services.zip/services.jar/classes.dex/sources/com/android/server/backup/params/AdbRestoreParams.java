package com.android.server.backup.params;

import android.os.ParcelFileDescriptor;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class AdbRestoreParams extends AdbParams {
    public AdbRestoreParams(ParcelFileDescriptor input) {
        this.fd = input;
    }
}
