package com.android.server.appop;

import android.app.AppOpsManager;
import android.content.ContentResolver;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.os.Environment;
import android.os.Message;
import android.os.Parcelable;
import android.os.RemoteCallback;
import android.os.UserHandle;
import android.provider.Settings;
import android.util.ArraySet;
import android.util.LongSparseArray;
import android.util.Slog;
import android.util.TimeUtils;
import android.util.Xml;
import com.android.internal.annotations.GuardedBy;
import com.android.internal.os.AtomicDirectory;
import com.android.internal.os.BackgroundThread;
import com.android.internal.util.ArrayUtils;
import com.android.internal.util.XmlUtils;
import com.android.internal.util.function.pooled.PooledLambda;
import com.android.server.FgThread;
import com.android.server.job.controllers.JobStatus;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
final class HistoricalRegistry {
    private static final boolean DEBUG = false;
    private static final long DEFAULT_COMPRESSION_STEP = 10;
    private static final int DEFAULT_MODE = 1;
    private static final String HISTORY_FILE_SUFFIX = ".xml";
    private static final int MSG_WRITE_PENDING_HISTORY = 1;
    private static final String PARAMETER_ASSIGNMENT = "=";
    private static final String PARAMETER_DELIMITER = ",";

    @GuardedBy({"mInMemoryLock"})
    private AppOpsManager.HistoricalOps mCurrentHistoricalOps;
    private final Object mInMemoryLock;

    @GuardedBy({"mInMemoryLock"})
    private long mNextPersistDueTimeMillis;

    @GuardedBy({"mInMemoryLock"})
    private long mPendingHistoryOffsetMillis;

    @GuardedBy({"mOnDiskLock"})
    private Persistence mPersistence;
    private static final boolean KEEP_WTF_LOG = Build.IS_DEBUGGABLE;
    private static final String LOG_TAG = HistoricalRegistry.class.getSimpleName();
    private static final long DEFAULT_SNAPSHOT_INTERVAL_MILLIS = TimeUnit.MINUTES.toMillis(15);

    @GuardedBy({"mLock"})
    private LinkedList<AppOpsManager.HistoricalOps> mPendingWrites = new LinkedList<>();
    private final Object mOnDiskLock = new Object();

    @GuardedBy({"mInMemoryLock"})
    private final int mMode = 0;

    @GuardedBy({"mInMemoryLock"})
    private long mBaseSnapshotInterval = DEFAULT_SNAPSHOT_INTERVAL_MILLIS;

    @GuardedBy({"mInMemoryLock"})
    private long mIntervalCompressionMultiplier = DEFAULT_COMPRESSION_STEP;

    HistoricalRegistry(Object lock) {
        this.mInMemoryLock = lock;
    }

    void systemReady(final ContentResolver resolver) {
        Uri uri = Settings.Global.getUriFor("appop_history_parameters");
        resolver.registerContentObserver(uri, false, new ContentObserver(FgThread.getHandler()) { // from class: com.android.server.appop.HistoricalRegistry.1
            @Override // android.database.ContentObserver
            public void onChange(boolean selfChange) {
                HistoricalRegistry.this.updateParametersFromSetting(resolver);
            }
        });
        updateParametersFromSetting(resolver);
        synchronized (this.mOnDiskLock) {
            synchronized (this.mInMemoryLock) {
            }
        }
    }

    private boolean isPersistenceInitializedMLocked() {
        return this.mPersistence != null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateParametersFromSetting(ContentResolver resolver) {
        String setting = Settings.Global.getString(resolver, "appop_history_parameters");
        if (setting == null) {
            return;
        }
        String[] parameters = setting.split(PARAMETER_DELIMITER);
        int length = parameters.length;
        char c = 0;
        String intervalMultiplierValue = null;
        String baseSnapshotIntervalValue = null;
        String modeValue = null;
        int i = 0;
        while (i < length) {
            String parameter = parameters[i];
            String[] parts = parameter.split(PARAMETER_ASSIGNMENT);
            if (parts.length == 2) {
                String key = parts[c].trim();
                byte b = -1;
                int iHashCode = key.hashCode();
                if (iHashCode != -190198682) {
                    if (iHashCode != 3357091) {
                        if (iHashCode == 245634204 && key.equals("baseIntervalMillis")) {
                            b = 1;
                        }
                    } else if (key.equals("mode")) {
                        b = 0;
                    }
                } else if (key.equals("intervalMultiplier")) {
                    b = 2;
                }
                if (b == 0) {
                    modeValue = parts[1].trim();
                } else if (b == 1) {
                    String intervalMultiplierValue2 = parts[1];
                    baseSnapshotIntervalValue = intervalMultiplierValue2.trim();
                } else if (b == 2) {
                    String intervalMultiplierValue3 = parts[1].trim();
                    intervalMultiplierValue = intervalMultiplierValue3;
                } else {
                    Slog.w(LOG_TAG, "Unknown parameter: " + parameter);
                }
            }
            i++;
            c = 0;
        }
        if (modeValue != null && baseSnapshotIntervalValue != null && intervalMultiplierValue != null) {
            try {
                int mode = AppOpsManager.parseHistoricalMode(modeValue);
                long baseSnapshotInterval = Long.parseLong(baseSnapshotIntervalValue);
                int intervalCompressionMultiplier = Integer.parseInt(intervalMultiplierValue);
                setHistoryParameters(mode, baseSnapshotInterval, intervalCompressionMultiplier);
                return;
            } catch (NumberFormatException e) {
            }
        }
        Slog.w(LOG_TAG, "Bad value forappop_history_parameters=" + setting + " resetting!");
    }

    void dump(String prefix, PrintWriter pw, int filterUid, String filterPackage, int filterOp) {
        synchronized (this.mOnDiskLock) {
            synchronized (this.mInMemoryLock) {
                pw.println();
                pw.print(prefix);
                pw.print("History:");
                pw.print("  mode=");
                pw.println(AppOpsManager.historicalModeToString(0));
                StringDumpVisitor visitor = new StringDumpVisitor(prefix + "  ", pw, filterUid, filterPackage, filterOp);
                long nowMillis = System.currentTimeMillis();
                AppOpsManager.HistoricalOps currentOps = getUpdatedPendingHistoricalOpsMLocked(nowMillis);
                makeRelativeToEpochStart(currentOps, nowMillis);
                currentOps.accept(visitor);
                if (isPersistenceInitializedMLocked()) {
                    Slog.e(LOG_TAG, "Interaction before persistence initialized");
                    return;
                }
                List<AppOpsManager.HistoricalOps> ops = this.mPersistence.readHistoryDLocked();
                if (ops != null) {
                    long remainingToFillBatchMillis = (this.mNextPersistDueTimeMillis - nowMillis) - this.mBaseSnapshotInterval;
                    int opCount = ops.size();
                    for (int i = 0; i < opCount; i++) {
                        AppOpsManager.HistoricalOps op = ops.get(i);
                        op.offsetBeginAndEndTime(remainingToFillBatchMillis);
                        makeRelativeToEpochStart(op, nowMillis);
                        op.accept(visitor);
                    }
                } else {
                    pw.println("  Empty");
                }
            }
        }
    }

    int getMode() {
        synchronized (this.mInMemoryLock) {
        }
        return 0;
    }

    void getHistoricalOpsFromDiskRaw(int uid, String packageName, String[] opNames, long beginTimeMillis, long endTimeMillis, int flags, RemoteCallback callback) {
        synchronized (this.mOnDiskLock) {
            synchronized (this.mInMemoryLock) {
                if (!isPersistenceInitializedMLocked()) {
                    Slog.e(LOG_TAG, "Interaction before persistence initialized");
                    callback.sendResult(new Bundle());
                    return;
                }
                Parcelable historicalOps = new AppOpsManager.HistoricalOps(beginTimeMillis, endTimeMillis);
                this.mPersistence.collectHistoricalOpsDLocked(historicalOps, uid, packageName, opNames, beginTimeMillis, endTimeMillis, flags);
                Bundle payload = new Bundle();
                payload.putParcelable("historical_ops", historicalOps);
                callback.sendResult(payload);
            }
        }
    }

    void getHistoricalOps(int uid, String packageName, String[] opNames, long beginTimeMillis, long endTimeMillis, int flags, RemoteCallback callback) throws Throwable {
        long inMemoryAdjEndTimeMillis;
        AppOpsManager.HistoricalOps result;
        long currentTimeMillis = System.currentTimeMillis();
        long endTimeMillis2 = endTimeMillis == JobStatus.NO_LATEST_RUNTIME ? currentTimeMillis : endTimeMillis;
        long inMemoryAdjBeginTimeMillis = Math.max(currentTimeMillis - endTimeMillis2, 0L);
        long inMemoryAdjEndTimeMillis2 = Math.max(currentTimeMillis - beginTimeMillis, 0L);
        AppOpsManager.HistoricalOps result2 = new AppOpsManager.HistoricalOps(inMemoryAdjBeginTimeMillis, inMemoryAdjEndTimeMillis2);
        synchronized (this.mOnDiskLock) {
            try {
                try {
                    synchronized (this.mInMemoryLock) {
                        try {
                            if (isPersistenceInitializedMLocked()) {
                                try {
                                    AppOpsManager.HistoricalOps currentOps = getUpdatedPendingHistoricalOpsMLocked(currentTimeMillis);
                                    if (inMemoryAdjBeginTimeMillis < currentOps.getEndTimeMillis()) {
                                        try {
                                            if (inMemoryAdjEndTimeMillis2 > currentOps.getBeginTimeMillis()) {
                                                AppOpsManager.HistoricalOps currentOpsCopy = new AppOpsManager.HistoricalOps(currentOps);
                                                result = result2;
                                                inMemoryAdjEndTimeMillis = inMemoryAdjEndTimeMillis2;
                                                try {
                                                    currentOpsCopy.filter(uid, packageName, opNames, inMemoryAdjBeginTimeMillis, inMemoryAdjEndTimeMillis);
                                                    result.merge(currentOpsCopy);
                                                } catch (Throwable th) {
                                                    th = th;
                                                    while (true) {
                                                        throw th;
                                                    }
                                                }
                                            } else {
                                                inMemoryAdjEndTimeMillis = inMemoryAdjEndTimeMillis2;
                                                result = result2;
                                            }
                                        } catch (Throwable th2) {
                                            th = th2;
                                        }
                                    } else {
                                        inMemoryAdjEndTimeMillis = inMemoryAdjEndTimeMillis2;
                                        result = result2;
                                    }
                                    try {
                                        List<AppOpsManager.HistoricalOps> pendingWrites = new ArrayList<>(this.mPendingWrites);
                                        this.mPendingWrites.clear();
                                        boolean collectOpsFromDisk = inMemoryAdjEndTimeMillis > currentOps.getEndTimeMillis();
                                        if (collectOpsFromDisk) {
                                            try {
                                                persistPendingHistory(pendingWrites);
                                                try {
                                                    long onDiskAndInMemoryOffsetMillis = (currentTimeMillis - this.mNextPersistDueTimeMillis) + this.mBaseSnapshotInterval;
                                                    try {
                                                        long onDiskAdjBeginTimeMillis = Math.max(inMemoryAdjBeginTimeMillis - onDiskAndInMemoryOffsetMillis, 0L);
                                                        long onDiskAdjEndTimeMillis = Math.max(inMemoryAdjEndTimeMillis - onDiskAndInMemoryOffsetMillis, 0L);
                                                        this.mPersistence.collectHistoricalOpsDLocked(result, uid, packageName, opNames, onDiskAdjBeginTimeMillis, onDiskAdjEndTimeMillis, flags);
                                                    } catch (Throwable th3) {
                                                        th = th3;
                                                        throw th;
                                                    }
                                                } catch (Throwable th4) {
                                                    th = th4;
                                                }
                                            } catch (Throwable th5) {
                                                th = th5;
                                            }
                                        }
                                        try {
                                            result.setBeginAndEndTime(beginTimeMillis, endTimeMillis2);
                                            Bundle payload = new Bundle();
                                            payload.putParcelable("historical_ops", result);
                                            callback.sendResult(payload);
                                        } catch (Throwable th6) {
                                            th = th6;
                                            throw th;
                                        }
                                    } catch (Throwable th7) {
                                        th = th7;
                                        while (true) {
                                            throw th;
                                        }
                                    }
                                } catch (Throwable th8) {
                                    th = th8;
                                }
                            } else {
                                try {
                                    try {
                                        Slog.e(LOG_TAG, "Interaction before persistence initialized");
                                        callback.sendResult(new Bundle());
                                        try {
                                        } catch (Throwable th9) {
                                            th = th9;
                                            throw th;
                                        }
                                    } catch (Throwable th10) {
                                        th = th10;
                                        while (true) {
                                            try {
                                                throw th;
                                            } catch (Throwable th11) {
                                                th = th11;
                                            }
                                        }
                                    }
                                } catch (Throwable th12) {
                                    th = th12;
                                }
                            }
                        } catch (Throwable th13) {
                            th = th13;
                        }
                    }
                } catch (Throwable th14) {
                    th = th14;
                }
            } catch (Throwable th15) {
                th = th15;
            }
        }
    }

    void incrementOpAccessedCount(int op, int uid, String packageName, int uidState, int flags) {
        synchronized (this.mInMemoryLock) {
        }
    }

    void incrementOpRejected(int op, int uid, String packageName, int uidState, int flags) {
        synchronized (this.mInMemoryLock) {
        }
    }

    void increaseOpAccessDuration(int op, int uid, String packageName, int uidState, int flags, long increment) {
        synchronized (this.mInMemoryLock) {
        }
    }

    void setHistoryParameters(int mode, long baseSnapshotInterval, long intervalCompressionMultiplier) {
    }

    void offsetHistory(long offsetMillis) {
        synchronized (this.mOnDiskLock) {
            synchronized (this.mInMemoryLock) {
                if (!isPersistenceInitializedMLocked()) {
                    Slog.e(LOG_TAG, "Interaction before persistence initialized");
                    return;
                }
                List<AppOpsManager.HistoricalOps> history = this.mPersistence.readHistoryDLocked();
                clearHistory();
                if (history != null) {
                    int historySize = history.size();
                    for (int i = 0; i < historySize; i++) {
                        AppOpsManager.HistoricalOps ops = history.get(i);
                        ops.offsetBeginAndEndTime(offsetMillis);
                    }
                    if (offsetMillis < 0) {
                        pruneFutureOps(history);
                    }
                    this.mPersistence.persistHistoricalOpsDLocked(history);
                }
            }
        }
    }

    void addHistoricalOps(AppOpsManager.HistoricalOps ops) {
        synchronized (this.mInMemoryLock) {
            if (!isPersistenceInitializedMLocked()) {
                Slog.e(LOG_TAG, "Interaction before persistence initialized");
                return;
            }
            ops.offsetBeginAndEndTime(this.mBaseSnapshotInterval);
            this.mPendingWrites.offerFirst(ops);
            List<AppOpsManager.HistoricalOps> pendingWrites = new ArrayList<>(this.mPendingWrites);
            this.mPendingWrites.clear();
            persistPendingHistory(pendingWrites);
        }
    }

    private void resampleHistoryOnDiskInMemoryDMLocked(long offsetMillis) {
        this.mPersistence = new Persistence(this.mBaseSnapshotInterval, this.mIntervalCompressionMultiplier);
        offsetHistory(offsetMillis);
    }

    void resetHistoryParameters() {
        if (!isPersistenceInitializedMLocked()) {
            Slog.e(LOG_TAG, "Interaction before persistence initialized");
        } else {
            setHistoryParameters(1, DEFAULT_SNAPSHOT_INTERVAL_MILLIS, DEFAULT_COMPRESSION_STEP);
        }
    }

    void clearHistory(int uid, String packageName) {
        synchronized (this.mOnDiskLock) {
            synchronized (this.mInMemoryLock) {
                if (isPersistenceInitializedMLocked()) {
                    return;
                }
                Slog.e(LOG_TAG, "Interaction before persistence initialized");
            }
        }
    }

    void clearHistory() {
        synchronized (this.mOnDiskLock) {
            synchronized (this.mInMemoryLock) {
                if (!isPersistenceInitializedMLocked()) {
                    Slog.e(LOG_TAG, "Interaction before persistence initialized");
                } else {
                    clearHistoryOnDiskDLocked();
                }
            }
        }
    }

    private void clearHistoryOnDiskDLocked() {
        BackgroundThread.getHandler().removeMessages(1);
        synchronized (this.mInMemoryLock) {
            this.mCurrentHistoricalOps = null;
            this.mNextPersistDueTimeMillis = System.currentTimeMillis();
            this.mPendingWrites.clear();
        }
        Persistence.clearHistoryDLocked();
    }

    private AppOpsManager.HistoricalOps getUpdatedPendingHistoricalOpsMLocked(long now) {
        if (this.mCurrentHistoricalOps != null) {
            long remainingTimeMillis = this.mNextPersistDueTimeMillis - now;
            long j = this.mBaseSnapshotInterval;
            if (remainingTimeMillis > j) {
                this.mPendingHistoryOffsetMillis = remainingTimeMillis - j;
            }
            long elapsedTimeMillis = this.mBaseSnapshotInterval - remainingTimeMillis;
            this.mCurrentHistoricalOps.setEndTime(elapsedTimeMillis);
            if (remainingTimeMillis > 0) {
                return this.mCurrentHistoricalOps;
            }
            if (this.mCurrentHistoricalOps.isEmpty()) {
                this.mCurrentHistoricalOps.setBeginAndEndTime(0L, 0L);
                this.mNextPersistDueTimeMillis = this.mBaseSnapshotInterval + now;
                return this.mCurrentHistoricalOps;
            }
            this.mCurrentHistoricalOps.offsetBeginAndEndTime(this.mBaseSnapshotInterval);
            AppOpsManager.HistoricalOps historicalOps = this.mCurrentHistoricalOps;
            historicalOps.setBeginTime(historicalOps.getEndTimeMillis() - this.mBaseSnapshotInterval);
            long overdueTimeMillis = Math.abs(remainingTimeMillis);
            this.mCurrentHistoricalOps.offsetBeginAndEndTime(overdueTimeMillis);
            schedulePersistHistoricalOpsMLocked(this.mCurrentHistoricalOps);
        }
        this.mCurrentHistoricalOps = new AppOpsManager.HistoricalOps(0L, 0L);
        this.mNextPersistDueTimeMillis = this.mBaseSnapshotInterval + now;
        return this.mCurrentHistoricalOps;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void persistPendingHistory() {
        List<AppOpsManager.HistoricalOps> pendingWrites;
        synchronized (this.mOnDiskLock) {
            synchronized (this.mInMemoryLock) {
                pendingWrites = new ArrayList<>(this.mPendingWrites);
                this.mPendingWrites.clear();
                if (this.mPendingHistoryOffsetMillis != 0) {
                    resampleHistoryOnDiskInMemoryDMLocked(this.mPendingHistoryOffsetMillis);
                    this.mPendingHistoryOffsetMillis = 0L;
                }
            }
            persistPendingHistory(pendingWrites);
        }
    }

    private void persistPendingHistory(List<AppOpsManager.HistoricalOps> pendingWrites) {
        synchronized (this.mOnDiskLock) {
            BackgroundThread.getHandler().removeMessages(1);
            if (pendingWrites.isEmpty()) {
                return;
            }
            int opCount = pendingWrites.size();
            for (int i = 0; i < opCount; i++) {
                AppOpsManager.HistoricalOps current = pendingWrites.get(i);
                if (i > 0) {
                    AppOpsManager.HistoricalOps previous = pendingWrites.get(i - 1);
                    current.offsetBeginAndEndTime(previous.getBeginTimeMillis());
                }
            }
            this.mPersistence.persistHistoricalOpsDLocked(pendingWrites);
        }
    }

    private void schedulePersistHistoricalOpsMLocked(AppOpsManager.HistoricalOps ops) {
        Message message = PooledLambda.obtainMessage(new Consumer() { // from class: com.android.server.appop.-$$Lambda$HistoricalRegistry$dJrtb4M71TzV6sx9vPEImQG_akU
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                ((HistoricalRegistry) obj).persistPendingHistory();
            }
        }, this);
        message.what = 1;
        BackgroundThread.getHandler().sendMessage(message);
        this.mPendingWrites.offerFirst(ops);
    }

    private static void makeRelativeToEpochStart(AppOpsManager.HistoricalOps ops, long nowMillis) {
        ops.setBeginAndEndTime(nowMillis - ops.getEndTimeMillis(), nowMillis - ops.getBeginTimeMillis());
    }

    private void pruneFutureOps(List<AppOpsManager.HistoricalOps> ops) {
        int opCount = ops.size();
        for (int i = opCount - 1; i >= 0; i--) {
            AppOpsManager.HistoricalOps op = ops.get(i);
            if (op.getEndTimeMillis() <= this.mBaseSnapshotInterval) {
                ops.remove(i);
            } else if (op.getBeginTimeMillis() < this.mBaseSnapshotInterval) {
                double filterScale = (op.getEndTimeMillis() - this.mBaseSnapshotInterval) / op.getDurationMillis();
                Persistence.spliceFromBeginning(op, filterScale);
            }
        }
    }

    private static final class Persistence {
        private static final String ATTR_ACCESS_COUNT = "ac";
        private static final String ATTR_ACCESS_DURATION = "du";
        private static final String ATTR_BEGIN_TIME = "beg";
        private static final String ATTR_END_TIME = "end";
        private static final String ATTR_NAME = "na";
        private static final String ATTR_OVERFLOW = "ov";
        private static final String ATTR_REJECT_COUNT = "rc";
        private static final String ATTR_VERSION = "ver";
        private static final int CURRENT_VERSION = 2;
        private static final boolean DEBUG = false;
        private static final String TAG_OP = "op";
        private static final String TAG_OPS = "ops";
        private static final String TAG_PACKAGE = "pkg";
        private static final String TAG_STATE = "st";
        private static final String TAG_UID = "uid";
        private final long mBaseSnapshotInterval;
        private final long mIntervalCompressionMultiplier;
        private static final String LOG_TAG = Persistence.class.getSimpleName();
        private static final String TAG_HISTORY = "history";
        private static final AtomicDirectory sHistoricalAppOpsDir = new AtomicDirectory(new File(new File(Environment.getDataSystemDirectory(), "appops"), TAG_HISTORY));

        Persistence(long baseSnapshotInterval, long intervalCompressionMultiplier) {
            this.mBaseSnapshotInterval = baseSnapshotInterval;
            this.mIntervalCompressionMultiplier = intervalCompressionMultiplier;
        }

        private File generateFile(File baseDir, int depth) {
            long globalBeginMillis = computeGlobalIntervalBeginMillis(depth);
            return new File(baseDir, Long.toString(globalBeginMillis) + ".xml");
        }

        void clearHistoryDLocked(int uid, String packageName) {
            List<AppOpsManager.HistoricalOps> historicalOps = readHistoryDLocked();
            if (historicalOps == null) {
                return;
            }
            for (int index = 0; index < historicalOps.size(); index++) {
                historicalOps.get(index).clearHistory(uid, packageName);
            }
            clearHistoryDLocked();
            persistHistoricalOpsDLocked(historicalOps);
        }

        static void clearHistoryDLocked() {
            sHistoricalAppOpsDir.delete();
        }

        void persistHistoricalOpsDLocked(List<AppOpsManager.HistoricalOps> ops) {
            try {
                File newBaseDir = sHistoricalAppOpsDir.startWrite();
                File oldBaseDir = sHistoricalAppOpsDir.getBackupDirectory();
                Set<String> oldFileNames = getHistoricalFileNames(oldBaseDir);
                handlePersistHistoricalOpsRecursiveDLocked(newBaseDir, oldBaseDir, ops, oldFileNames, 0);
                sHistoricalAppOpsDir.finishWrite();
            } catch (Throwable t) {
                HistoricalRegistry.wtf("Failed to write historical app ops, restoring backup", t, null);
                sHistoricalAppOpsDir.failWrite();
            }
        }

        List<AppOpsManager.HistoricalOps> readHistoryRawDLocked() {
            return collectHistoricalOpsBaseDLocked(-1, null, null, 0L, JobStatus.NO_LATEST_RUNTIME, 31);
        }

        List<AppOpsManager.HistoricalOps> readHistoryDLocked() {
            List<AppOpsManager.HistoricalOps> result = readHistoryRawDLocked();
            if (result != null) {
                int opCount = result.size();
                for (int i = 0; i < opCount; i++) {
                    result.get(i).offsetBeginAndEndTime(this.mBaseSnapshotInterval);
                }
            }
            return result;
        }

        long getLastPersistTimeMillisDLocked() {
            try {
                File baseDir = sHistoricalAppOpsDir.startRead();
                File[] files = baseDir.listFiles();
                if (files != null && files.length > 0) {
                    File shortestFile = null;
                    for (File candidate : files) {
                        String candidateName = candidate.getName();
                        if (candidateName.endsWith(".xml")) {
                            if (shortestFile == null) {
                                shortestFile = candidate;
                            } else if (candidateName.length() < shortestFile.getName().length()) {
                                shortestFile = candidate;
                            }
                        }
                    }
                    if (shortestFile == null) {
                        return 0L;
                    }
                    String shortestNameNoExtension = shortestFile.getName().replace(".xml", "");
                    try {
                        return Long.parseLong(shortestNameNoExtension);
                    } catch (NumberFormatException e) {
                        return 0L;
                    }
                }
                sHistoricalAppOpsDir.finishRead();
                return 0L;
            } catch (Throwable e2) {
                HistoricalRegistry.wtf("Error reading historical app ops. Deleting history.", e2, null);
                sHistoricalAppOpsDir.delete();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void collectHistoricalOpsDLocked(AppOpsManager.HistoricalOps currentOps, int filterUid, String filterPackageName, String[] filterOpNames, long filterBeingMillis, long filterEndMillis, int filterFlags) {
            List<AppOpsManager.HistoricalOps> readOps = collectHistoricalOpsBaseDLocked(filterUid, filterPackageName, filterOpNames, filterBeingMillis, filterEndMillis, filterFlags);
            if (readOps != null) {
                int readCount = readOps.size();
                for (int i = 0; i < readCount; i++) {
                    AppOpsManager.HistoricalOps readOp = readOps.get(i);
                    currentOps.merge(readOp);
                }
            }
        }

        private LinkedList<AppOpsManager.HistoricalOps> collectHistoricalOpsBaseDLocked(int filterUid, String filterPackageName, String[] filterOpNames, long filterBeginTimeMillis, long filterEndTimeMillis, int filterFlags) {
            File baseDir;
            try {
                baseDir = sHistoricalAppOpsDir.startRead();
                try {
                    Set<String> historyFiles = getHistoricalFileNames(baseDir);
                    long[] globalContentOffsetMillis = {0};
                    LinkedList<AppOpsManager.HistoricalOps> ops = collectHistoricalOpsRecursiveDLocked(baseDir, filterUid, filterPackageName, filterOpNames, filterBeginTimeMillis, filterEndTimeMillis, filterFlags, globalContentOffsetMillis, null, 0, historyFiles);
                    sHistoricalAppOpsDir.finishRead();
                    return ops;
                } catch (Throwable th) {
                    t = th;
                    HistoricalRegistry.wtf("Error reading historical app ops. Deleting history.", t, baseDir);
                    sHistoricalAppOpsDir.delete();
                    return null;
                }
            } catch (Throwable th2) {
                t = th2;
                baseDir = null;
            }
        }

        private LinkedList<AppOpsManager.HistoricalOps> collectHistoricalOpsRecursiveDLocked(File baseDir, int filterUid, String filterPackageName, String[] filterOpNames, long filterBeginTimeMillis, long filterEndTimeMillis, int filterFlags, long[] globalContentOffsetMillis, LinkedList<AppOpsManager.HistoricalOps> outOps, int depth, Set<String> historyFiles) throws XmlPullParserException, IOException {
            long previousIntervalEndMillis = ((long) Math.pow(this.mIntervalCompressionMultiplier, depth)) * this.mBaseSnapshotInterval;
            long currentIntervalEndMillis = this.mBaseSnapshotInterval * ((long) Math.pow(this.mIntervalCompressionMultiplier, depth + 1));
            long filterBeginTimeMillis2 = Math.max(filterBeginTimeMillis - previousIntervalEndMillis, 0L);
            long filterEndTimeMillis2 = filterEndTimeMillis - previousIntervalEndMillis;
            List<AppOpsManager.HistoricalOps> readOps = readHistoricalOpsLocked(baseDir, previousIntervalEndMillis, currentIntervalEndMillis, filterUid, filterPackageName, filterOpNames, filterBeginTimeMillis2, filterEndTimeMillis2, filterFlags, globalContentOffsetMillis, depth, historyFiles);
            if (readOps != null && readOps.isEmpty()) {
                return outOps;
            }
            LinkedList<AppOpsManager.HistoricalOps> outOps2 = collectHistoricalOpsRecursiveDLocked(baseDir, filterUid, filterPackageName, filterOpNames, filterBeginTimeMillis2, filterEndTimeMillis2, filterFlags, globalContentOffsetMillis, outOps, depth + 1, historyFiles);
            if (outOps2 != null) {
                int opCount = outOps2.size();
                for (int i = 0; i < opCount; i++) {
                    AppOpsManager.HistoricalOps collectedOp = outOps2.get(i);
                    collectedOp.offsetBeginAndEndTime(currentIntervalEndMillis);
                }
            }
            if (readOps != null) {
                if (outOps2 == null) {
                    outOps2 = new LinkedList<>();
                }
                int opCount2 = readOps.size();
                for (int i2 = opCount2 - 1; i2 >= 0; i2--) {
                    outOps2.offerFirst(readOps.get(i2));
                }
            }
            return outOps2;
        }

        private void handlePersistHistoricalOpsRecursiveDLocked(File newBaseDir, File oldBaseDir, List<AppOpsManager.HistoricalOps> passedOps, Set<String> oldFileNames, int depth) throws XmlPullParserException, IOException {
            List<AppOpsManager.HistoricalOps> list;
            AppOpsManager.HistoricalOps persistedOp;
            AppOpsManager.HistoricalOps overflowedOp;
            int existingOpCount;
            long previousIntervalEndMillis = ((long) Math.pow(this.mIntervalCompressionMultiplier, depth)) * this.mBaseSnapshotInterval;
            long currentIntervalEndMillis = ((long) Math.pow(this.mIntervalCompressionMultiplier, depth + 1)) * this.mBaseSnapshotInterval;
            if (passedOps == null || passedOps.isEmpty()) {
                if (!oldFileNames.isEmpty()) {
                    File oldFile = generateFile(oldBaseDir, 
                    /*  JADX ERROR: Method code generation error
                        jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x015a: INVOKE (r11v0 'oldFile' java.io.File) = 
                          (r15v0 'this' ?? I:??[OBJECT, ARRAY] A[IMMUTABLE_TYPE, THIS])
                          (r28v0 'oldBaseDir' java.io.File A[D('oldBaseDir' java.io.File)])
                          (r3v0 int)
                         DIRECT call: com.android.server.appop.HistoricalRegistry.Persistence.generateFile(java.io.File, int):java.io.File A[DECLARE_VAR, MD:(java.io.File, int):java.io.File (m)] (LINE:941) in method: com.android.server.appop.HistoricalRegistry.Persistence.handlePersistHistoricalOpsRecursiveDLocked(java.io.File, java.io.File, java.util.List<android.app.AppOpsManager$HistoricalOps>, java.util.Set<java.lang.String>, int):void, file: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex
                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:310)
                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:273)
                        	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:94)
                        	at jadx.core.dex.nodes.IBlock.generate(IBlock.java:15)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.dex.regions.Region.generate(Region.java:35)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                        	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                        	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.dex.regions.Region.generate(Region.java:35)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.dex.regions.Region.generate(Region.java:35)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                        	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                        	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.dex.regions.Region.generate(Region.java:35)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.dex.regions.Region.generate(Region.java:35)
                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                        	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:291)
                        	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:270)
                        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:420)
                        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:345)
                        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:299)
                        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
                        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
                        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
                        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
                        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
                        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
                        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
                        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
                        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
                        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
                        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:295)
                        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:284)
                        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:268)
                        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:160)
                        	at jadx.core.codegen.ClassGen.addInnerClass(ClassGen.java:320)
                        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:297)
                        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
                        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
                        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
                        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
                        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
                        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
                        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
                        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
                        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
                        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
                        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:295)
                        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:284)
                        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:268)
                        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:160)
                        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:104)
                        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
                        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
                        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
                        	at jadx.core.ProcessClass.process(ProcessClass.java:89)
                        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
                        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
                        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
                        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
                        Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r3v0 int
                        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
                        */
                    /*
                        Method dump skipped, instruction units count: 394
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.android.server.appop.HistoricalRegistry.Persistence.handlePersistHistoricalOpsRecursiveDLocked(java.io.File, java.io.File, java.util.List, java.util.Set, int):void");
                }

                private List<AppOpsManager.HistoricalOps> readHistoricalOpsLocked(File baseDir, long intervalBeginMillis, long intervalEndMillis, int filterUid, String filterPackageName, String[] filterOpNames, long filterBeginTimeMillis, long filterEndTimeMillis, int filterFlags, long[] cumulativeOverflowMillis, int depth, Set<String> historyFiles) throws XmlPullParserException, IOException {
                    File file = generateFile(baseDir, depth);
                    if (historyFiles != null) {
                        historyFiles.remove(file.getName());
                    }
                    if (filterBeginTimeMillis >= filterEndTimeMillis || filterEndTimeMillis < intervalBeginMillis) {
                        return Collections.emptyList();
                    }
                    if (filterBeginTimeMillis >= intervalEndMillis + ((intervalEndMillis - intervalBeginMillis) / this.mIntervalCompressionMultiplier) + (cumulativeOverflowMillis != null ? cumulativeOverflowMillis[0] : 0L) || !file.exists()) {
                        if (historyFiles == null || historyFiles.isEmpty()) {
                            return Collections.emptyList();
                        }
                        return null;
                    }
                    return readHistoricalOpsLocked(file, filterUid, filterPackageName, filterOpNames, filterBeginTimeMillis, filterEndTimeMillis, filterFlags, cumulativeOverflowMillis);
                }

                private List<AppOpsManager.HistoricalOps> readHistoricalOpsLocked(File file, int filterUid, String filterPackageName, String[] filterOpNames, long filterBeginTimeMillis, long filterEndTimeMillis, int filterFlags, long[] cumulativeOverflowMillis) throws XmlPullParserException, IOException {
                    Throwable th;
                    int depth;
                    try {
                        FileInputStream stream = new FileInputStream(file);
                        try {
                            try {
                                XmlPullParser parser = Xml.newPullParser();
                                parser.setInput(stream, StandardCharsets.UTF_8.name());
                                XmlUtils.beginDocument(parser, TAG_HISTORY);
                                int version = XmlUtils.readIntAttribute(parser, ATTR_VERSION);
                                if (version < 2) {
                                    throw new IllegalStateException("Dropping unsupported history version 1 for file:" + file);
                                }
                                long overflowMillis = XmlUtils.readLongAttribute(parser, ATTR_OVERFLOW, 0L);
                                int depth2 = parser.getDepth();
                                List<AppOpsManager.HistoricalOps> allOps = null;
                                while (XmlUtils.nextElementWithin(parser, depth2)) {
                                    try {
                                        if (TAG_OPS.equals(parser.getName())) {
                                            depth = depth2;
                                            AppOpsManager.HistoricalOps ops = readeHistoricalOpsDLocked(parser, filterUid, filterPackageName, filterOpNames, filterBeginTimeMillis, filterEndTimeMillis, filterFlags, cumulativeOverflowMillis);
                                            if (ops != null) {
                                                if (ops.isEmpty()) {
                                                    XmlUtils.skipCurrentTag(parser);
                                                } else {
                                                    List<AppOpsManager.HistoricalOps> allOps2 = allOps == null ? new ArrayList<>() : allOps;
                                                    try {
                                                        allOps2.add(ops);
                                                        allOps = allOps2;
                                                        depth2 = depth;
                                                    } catch (Throwable th2) {
                                                        th = th2;
                                                        try {
                                                            throw th;
                                                        } catch (Throwable th3) {
                                                            try {
                                                                stream.close();
                                                                throw th3;
                                                            } catch (Throwable th4) {
                                                                th.addSuppressed(th4);
                                                                throw th3;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } else {
                                            depth = depth2;
                                        }
                                        depth2 = depth;
                                    } catch (Throwable th5) {
                                        th = th5;
                                    }
                                }
                                if (cumulativeOverflowMillis != null) {
                                    cumulativeOverflowMillis[0] = cumulativeOverflowMillis[0] + overflowMillis;
                                }
                                stream.close();
                                return allOps;
                            } catch (Throwable th6) {
                                th = th6;
                            }
                        } catch (FileNotFoundException e) {
                            Slog.i(LOG_TAG, "No history file: " + file.getName());
                            return Collections.emptyList();
                        }
                    } catch (FileNotFoundException e2) {
                    }
                }

                private AppOpsManager.HistoricalOps readeHistoricalOpsDLocked(XmlPullParser parser, int filterUid, String filterPackageName, String[] filterOpNames, long filterBeginTimeMillis, long filterEndTimeMillis, int filterFlags, long[] cumulativeOverflowMillis) throws XmlPullParserException, IOException {
                    parser = parser;
                    long beginTimeMillis = XmlUtils.readLongAttribute(parser, ATTR_BEGIN_TIME, 0L) + (cumulativeOverflowMillis != null ? cumulativeOverflowMillis[0] : 0L);
                    long endTimeMillis = XmlUtils.readLongAttribute(parser, ATTR_END_TIME, 0L) + (cumulativeOverflowMillis != null ? cumulativeOverflowMillis[0] : 0L);
                    if (filterEndTimeMillis < beginTimeMillis) {
                        return null;
                    }
                    if (filterBeginTimeMillis > endTimeMillis) {
                        return new AppOpsManager.HistoricalOps(0L, 0L);
                    }
                    long filteredBeginTimeMillis = Math.max(beginTimeMillis, filterBeginTimeMillis);
                    long filteredEndTimeMillis = Math.min(endTimeMillis, filterEndTimeMillis);
                    long filteredEndTimeMillis2 = filteredEndTimeMillis;
                    double filterScale = (filteredEndTimeMillis - filteredBeginTimeMillis) / (endTimeMillis - beginTimeMillis);
                    int depth = parser.getDepth();
                    AppOpsManager.HistoricalOps ops = null;
                    while (XmlUtils.nextElementWithin(parser, depth)) {
                        if ("uid".equals(parser.getName())) {
                            AppOpsManager.HistoricalOps ops2 = ops;
                            long filteredEndTimeMillis3 = filteredEndTimeMillis2;
                            int depth2 = depth;
                            long filteredBeginTimeMillis2 = filteredBeginTimeMillis;
                            long endTimeMillis2 = endTimeMillis;
                            AppOpsManager.HistoricalOps returnedOps = readHistoricalUidOpsDLocked(ops, parser, filterUid, filterPackageName, filterOpNames, filterFlags, filterScale);
                            if (ops2 != null) {
                                ops = ops2;
                            } else {
                                ops = returnedOps;
                            }
                            filteredBeginTimeMillis = filteredBeginTimeMillis2;
                            depth = depth2;
                            endTimeMillis = endTimeMillis2;
                            filteredEndTimeMillis2 = filteredEndTimeMillis3;
                        } else {
                            filteredEndTimeMillis2 = filteredEndTimeMillis2;
                        }
                    }
                    AppOpsManager.HistoricalOps ops3 = ops;
                    long filteredBeginTimeMillis3 = filteredBeginTimeMillis;
                    long filteredEndTimeMillis4 = filteredEndTimeMillis2;
                    if (ops3 != null) {
                        ops3.setBeginAndEndTime(filteredBeginTimeMillis3, filteredEndTimeMillis4);
                    }
                    return ops3;
                }

                private AppOpsManager.HistoricalOps readHistoricalUidOpsDLocked(AppOpsManager.HistoricalOps ops, XmlPullParser parser, int filterUid, String filterPackageName, String[] filterOpNames, int filterFlags, double filterScale) throws XmlPullParserException, IOException {
                    int uid = XmlUtils.readIntAttribute(parser, ATTR_NAME);
                    if (filterUid != -1 && filterUid != uid) {
                        XmlUtils.skipCurrentTag(parser);
                        return null;
                    }
                    int depth = parser.getDepth();
                    AppOpsManager.HistoricalOps ops2 = ops;
                    while (XmlUtils.nextElementWithin(parser, depth)) {
                        if (TAG_PACKAGE.equals(parser.getName())) {
                            AppOpsManager.HistoricalOps returnedOps = readHistoricalPackageOpsDLocked(ops2, uid, parser, filterPackageName, filterOpNames, filterFlags, filterScale);
                            if (ops2 == null) {
                                ops2 = returnedOps;
                            }
                        }
                    }
                    return ops2;
                }

                private AppOpsManager.HistoricalOps readHistoricalPackageOpsDLocked(AppOpsManager.HistoricalOps ops, int uid, XmlPullParser parser, String filterPackageName, String[] filterOpNames, int filterFlags, double filterScale) throws XmlPullParserException, IOException {
                    String packageName = XmlUtils.readStringAttribute(parser, ATTR_NAME);
                    if (filterPackageName != null && !filterPackageName.equals(packageName)) {
                        XmlUtils.skipCurrentTag(parser);
                        return null;
                    }
                    int depth = parser.getDepth();
                    AppOpsManager.HistoricalOps ops2 = ops;
                    while (XmlUtils.nextElementWithin(parser, depth)) {
                        if (TAG_OP.equals(parser.getName())) {
                            AppOpsManager.HistoricalOps returnedOps = readHistoricalOpDLocked(ops2, uid, packageName, parser, filterOpNames, filterFlags, filterScale);
                            if (ops2 == null) {
                                ops2 = returnedOps;
                            }
                        }
                    }
                    return ops2;
                }

                private AppOpsManager.HistoricalOps readHistoricalOpDLocked(AppOpsManager.HistoricalOps ops, int uid, String packageName, XmlPullParser parser, String[] filterOpNames, int filterFlags, double filterScale) throws XmlPullParserException, IOException {
                    int op = XmlUtils.readIntAttribute(parser, ATTR_NAME);
                    if (filterOpNames != null && !ArrayUtils.contains(filterOpNames, AppOpsManager.opToPublicName(op))) {
                        XmlUtils.skipCurrentTag(parser);
                        return null;
                    }
                    int depth = parser.getDepth();
                    AppOpsManager.HistoricalOps ops2 = ops;
                    while (XmlUtils.nextElementWithin(parser, depth)) {
                        if (TAG_STATE.equals(parser.getName())) {
                            AppOpsManager.HistoricalOps returnedOps = readStateDLocked(ops2, uid, packageName, op, parser, filterFlags, filterScale);
                            if (ops2 == null) {
                                ops2 = returnedOps;
                            }
                        }
                    }
                    return ops2;
                }

                private AppOpsManager.HistoricalOps readStateDLocked(AppOpsManager.HistoricalOps ops, int uid, String packageName, int op, XmlPullParser parser, int filterFlags, double filterScale) throws IOException {
                    AppOpsManager.HistoricalOps ops2;
                    long accessDuration;
                    long rejectCount;
                    long accessCount;
                    long key = XmlUtils.readLongAttribute(parser, ATTR_NAME);
                    int flags = AppOpsManager.extractFlagsFromKey(key) & filterFlags;
                    if (flags == 0) {
                        return null;
                    }
                    int uidState = AppOpsManager.extractUidStateFromKey(key);
                    long accessCount2 = XmlUtils.readLongAttribute(parser, ATTR_ACCESS_COUNT, 0L);
                    if (accessCount2 <= 0) {
                        ops2 = ops;
                    } else {
                        if (Double.isNaN(filterScale)) {
                            accessCount = accessCount2;
                        } else {
                            accessCount = (long) AppOpsManager.HistoricalOps.round(accessCount2 * filterScale);
                        }
                        if (ops != null) {
                            ops2 = ops;
                        } else {
                            ops2 = new AppOpsManager.HistoricalOps(0L, 0L);
                        }
                        ops2.increaseAccessCount(op, uid, packageName, uidState, flags, accessCount);
                    }
                    long rejectCount2 = XmlUtils.readLongAttribute(parser, ATTR_REJECT_COUNT, 0L);
                    if (rejectCount2 > 0) {
                        if (Double.isNaN(filterScale)) {
                            rejectCount = rejectCount2;
                        } else {
                            rejectCount = (long) AppOpsManager.HistoricalOps.round(rejectCount2 * filterScale);
                        }
                        if (ops2 == null) {
                            ops2 = new AppOpsManager.HistoricalOps(0L, 0L);
                        }
                        ops2.increaseRejectCount(op, uid, packageName, uidState, flags, rejectCount);
                    }
                    long accessDuration2 = XmlUtils.readLongAttribute(parser, ATTR_ACCESS_DURATION, 0L);
                    if (accessDuration2 > 0) {
                        if (Double.isNaN(filterScale)) {
                            accessDuration = accessDuration2;
                        } else {
                            accessDuration = (long) AppOpsManager.HistoricalOps.round(accessDuration2 * filterScale);
                        }
                        if (ops2 == null) {
                            ops2 = new AppOpsManager.HistoricalOps(0L, 0L);
                        }
                        ops2.increaseAccessDuration(op, uid, packageName, uidState, flags, accessDuration);
                    }
                    return ops2;
                }

                private void writeHistoricalOpsDLocked(List<AppOpsManager.HistoricalOps> allOps, long intervalOverflowMillis, File file) throws IOException {
                    FileOutputStream output = sHistoricalAppOpsDir.openWrite(file);
                    try {
                        XmlSerializer serializer = Xml.newSerializer();
                        serializer.setOutput(output, StandardCharsets.UTF_8.name());
                        serializer.setFeature("http://xmlpull.org/v1/doc/features.html#indent-output", true);
                        serializer.startDocument(null, true);
                        serializer.startTag(null, TAG_HISTORY);
                        serializer.attribute(null, ATTR_VERSION, String.valueOf(2));
                        if (intervalOverflowMillis != 0) {
                            serializer.attribute(null, ATTR_OVERFLOW, Long.toString(intervalOverflowMillis));
                        }
                        if (allOps != null) {
                            int opsCount = allOps.size();
                            for (int i = 0; i < opsCount; i++) {
                                AppOpsManager.HistoricalOps ops = allOps.get(i);
                                writeHistoricalOpDLocked(ops, serializer);
                            }
                        }
                        serializer.endTag(null, TAG_HISTORY);
                        serializer.endDocument();
                        sHistoricalAppOpsDir.closeWrite(output);
                    } catch (IOException e) {
                        sHistoricalAppOpsDir.failWrite(output);
                        throw e;
                    }
                }

                private void writeHistoricalOpDLocked(AppOpsManager.HistoricalOps ops, XmlSerializer serializer) throws IOException {
                    serializer.startTag(null, TAG_OPS);
                    serializer.attribute(null, ATTR_BEGIN_TIME, Long.toString(ops.getBeginTimeMillis()));
                    serializer.attribute(null, ATTR_END_TIME, Long.toString(ops.getEndTimeMillis()));
                    int uidCount = ops.getUidCount();
                    for (int i = 0; i < uidCount; i++) {
                        AppOpsManager.HistoricalUidOps uidOp = ops.getUidOpsAt(i);
                        writeHistoricalUidOpsDLocked(uidOp, serializer);
                    }
                    serializer.endTag(null, TAG_OPS);
                }

                private void writeHistoricalUidOpsDLocked(AppOpsManager.HistoricalUidOps uidOps, XmlSerializer serializer) throws IOException {
                    serializer.startTag(null, "uid");
                    serializer.attribute(null, ATTR_NAME, Integer.toString(uidOps.getUid()));
                    int packageCount = uidOps.getPackageCount();
                    for (int i = 0; i < packageCount; i++) {
                        AppOpsManager.HistoricalPackageOps packageOps = uidOps.getPackageOpsAt(i);
                        writeHistoricalPackageOpsDLocked(packageOps, serializer);
                    }
                    serializer.endTag(null, "uid");
                }

                private void writeHistoricalPackageOpsDLocked(AppOpsManager.HistoricalPackageOps packageOps, XmlSerializer serializer) throws IOException {
                    serializer.startTag(null, TAG_PACKAGE);
                    serializer.attribute(null, ATTR_NAME, packageOps.getPackageName());
                    int opCount = packageOps.getOpCount();
                    for (int i = 0; i < opCount; i++) {
                        AppOpsManager.HistoricalOp op = packageOps.getOpAt(i);
                        writeHistoricalOpDLocked(op, serializer);
                    }
                    serializer.endTag(null, TAG_PACKAGE);
                }

                private void writeHistoricalOpDLocked(AppOpsManager.HistoricalOp op, XmlSerializer serializer) throws IOException {
                    LongSparseArray keys = op.collectKeys();
                    if (keys == null || keys.size() <= 0) {
                        return;
                    }
                    serializer.startTag(null, TAG_OP);
                    serializer.attribute(null, ATTR_NAME, Integer.toString(op.getOpCode()));
                    int keyCount = keys.size();
                    for (int i = 0; i < keyCount; i++) {
                        writeStateOnLocked(op, keys.keyAt(i), serializer);
                    }
                    serializer.endTag(null, TAG_OP);
                }

                private void writeStateOnLocked(AppOpsManager.HistoricalOp op, long key, XmlSerializer serializer) throws IOException {
                    int uidState = AppOpsManager.extractUidStateFromKey(key);
                    int flags = AppOpsManager.extractFlagsFromKey(key);
                    long accessCount = op.getAccessCount(uidState, uidState, flags);
                    long rejectCount = op.getRejectCount(uidState, uidState, flags);
                    long accessDuration = op.getAccessDuration(uidState, uidState, flags);
                    if (accessCount <= 0 && rejectCount <= 0 && accessDuration <= 0) {
                        return;
                    }
                    serializer.startTag(null, TAG_STATE);
                    serializer.attribute(null, ATTR_NAME, Long.toString(key));
                    if (accessCount > 0) {
                        serializer.attribute(null, ATTR_ACCESS_COUNT, Long.toString(accessCount));
                    }
                    if (rejectCount > 0) {
                        serializer.attribute(null, ATTR_REJECT_COUNT, Long.toString(rejectCount));
                    }
                    if (accessDuration > 0) {
                        serializer.attribute(null, ATTR_ACCESS_DURATION, Long.toString(accessDuration));
                    }
                    serializer.endTag(null, TAG_STATE);
                }

                private static void enforceOpsWellFormed(List<AppOpsManager.HistoricalOps> ops) {
                    if (ops == null) {
                        return;
                    }
                    AppOpsManager.HistoricalOps current = null;
                    int opsCount = ops.size();
                    for (int i = 0; i < opsCount; i++) {
                        AppOpsManager.HistoricalOps previous = current;
                        AppOpsManager.HistoricalOps current2 = ops.get(i);
                        current = current2;
                        if (current.isEmpty()) {
                            throw new IllegalStateException("Empty ops:\n" + opsToDebugString(ops));
                        }
                        if (current.getEndTimeMillis() < current.getBeginTimeMillis()) {
                            throw new IllegalStateException("Begin after end:\n" + opsToDebugString(ops));
                        }
                        if (previous != null) {
                            if (previous.getEndTimeMillis() > current.getBeginTimeMillis()) {
                                throw new IllegalStateException("Intersecting ops:\n" + opsToDebugString(ops));
                            }
                            if (previous.getBeginTimeMillis() > current.getBeginTimeMillis()) {
                                throw new IllegalStateException("Non increasing ops:\n" + opsToDebugString(ops));
                            }
                        }
                    }
                }

                private long computeGlobalIntervalBeginMillis(int depth) {
                    long beginTimeMillis = 0;
                    for (int i = 0; i < depth + 1; i++) {
                        beginTimeMillis = (long) (beginTimeMillis + Math.pow(this.mIntervalCompressionMultiplier, i));
                    }
                    return this.mBaseSnapshotInterval * beginTimeMillis;
                }

                private static AppOpsManager.HistoricalOps spliceFromEnd(AppOpsManager.HistoricalOps ops, double spliceRatio) {
                    AppOpsManager.HistoricalOps splice = ops.spliceFromEnd(spliceRatio);
                    return splice;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static AppOpsManager.HistoricalOps spliceFromBeginning(AppOpsManager.HistoricalOps ops, double spliceRatio) {
                    AppOpsManager.HistoricalOps splice = ops.spliceFromBeginning(spliceRatio);
                    return splice;
                }

                private static void normalizeSnapshotForSlotDuration(List<AppOpsManager.HistoricalOps> ops, long slotDurationMillis) {
                    int opCount = ops.size();
                    int processedIdx = opCount - 1;
                    while (processedIdx >= 0) {
                        AppOpsManager.HistoricalOps processedOp = ops.get(processedIdx);
                        long slotBeginTimeMillis = Math.max(processedOp.getEndTimeMillis() - slotDurationMillis, 0L);
                        for (int candidateIdx = processedIdx - 1; candidateIdx >= 0; candidateIdx--) {
                            AppOpsManager.HistoricalOps candidateOp = ops.get(candidateIdx);
                            long candidateSlotIntersectionMillis = candidateOp.getEndTimeMillis() - Math.min(slotBeginTimeMillis, processedOp.getBeginTimeMillis());
                            if (candidateSlotIntersectionMillis <= 0) {
                                break;
                            }
                            float candidateSplitRatio = candidateSlotIntersectionMillis / candidateOp.getDurationMillis();
                            if (Float.compare(candidateSplitRatio, 1.0f) >= 0) {
                                ops.remove(candidateIdx);
                                processedIdx--;
                                processedOp.merge(candidateOp);
                            } else {
                                AppOpsManager.HistoricalOps endSplice = spliceFromEnd(candidateOp, candidateSplitRatio);
                                if (endSplice != null) {
                                    processedOp.merge(endSplice);
                                }
                                if (candidateOp.isEmpty()) {
                                    ops.remove(candidateIdx);
                                    processedIdx--;
                                }
                            }
                        }
                        processedIdx--;
                    }
                }

                private static String opsToDebugString(List<AppOpsManager.HistoricalOps> ops) {
                    StringBuilder builder = new StringBuilder();
                    int opCount = ops.size();
                    for (int i = 0; i < opCount; i++) {
                        builder.append("  ");
                        builder.append(ops.get(i));
                        if (i < opCount - 1) {
                            builder.append('\n');
                        }
                    }
                    return builder.toString();
                }

                private static Set<String> getHistoricalFileNames(File historyDir) {
                    File[] files = historyDir.listFiles();
                    if (files == null) {
                        return Collections.emptySet();
                    }
                    ArraySet<String> fileNames = new ArraySet<>(files.length);
                    for (File file : files) {
                        fileNames.add(file.getName());
                    }
                    return fileNames;
                }
            }

            private static class HistoricalFilesInvariant {
                private final List<File> mBeginFiles = new ArrayList();

                private HistoricalFilesInvariant() {
                }

                public void startTracking(File folder) {
                    File[] files = folder.listFiles();
                    if (files != null) {
                        Collections.addAll(this.mBeginFiles, files);
                    }
                }

                public void stopTracking(File folder) {
                    List<File> endFiles = new ArrayList<>();
                    File[] files = folder.listFiles();
                    if (files != null) {
                        Collections.addAll(endFiles, files);
                    }
                    long beginOldestFileOffsetMillis = getOldestFileOffsetMillis(this.mBeginFiles);
                    long endOldestFileOffsetMillis = getOldestFileOffsetMillis(endFiles);
                    if (endOldestFileOffsetMillis < beginOldestFileOffsetMillis) {
                        String message = "History loss detected!\nold files: " + this.mBeginFiles;
                        HistoricalRegistry.wtf(message, null, folder);
                        throw new IllegalStateException(message);
                    }
                }

                private static long getOldestFileOffsetMillis(List<File> files) {
                    if (files.isEmpty()) {
                        return 0L;
                    }
                    String longestName = files.get(0).getName();
                    int fileCount = files.size();
                    for (int i = 1; i < fileCount; i++) {
                        File file = files.get(i);
                        if (file.getName().length() > longestName.length()) {
                            longestName = file.getName();
                        }
                    }
                    return Long.parseLong(longestName.replace(".xml", ""));
                }
            }

            private final class StringDumpVisitor implements AppOpsManager.HistoricalOpsVisitor {
                private final String mEntryPrefix;
                private final int mFilterOp;
                private final String mFilterPackage;
                private final int mFilterUid;
                private final String mOpsPrefix;
                private final String mPackagePrefix;
                private final String mUidPrefix;
                private final String mUidStatePrefix;
                private final PrintWriter mWriter;
                private final long mNow = System.currentTimeMillis();
                private final SimpleDateFormat mDateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                private final Date mDate = new Date();

                StringDumpVisitor(String prefix, PrintWriter writer, int filterUid, String filterPackage, int filterOp) {
                    this.mOpsPrefix = prefix + "  ";
                    this.mUidPrefix = this.mOpsPrefix + "  ";
                    this.mPackagePrefix = this.mUidPrefix + "  ";
                    this.mEntryPrefix = this.mPackagePrefix + "  ";
                    this.mUidStatePrefix = this.mEntryPrefix + "  ";
                    this.mWriter = writer;
                    this.mFilterUid = filterUid;
                    this.mFilterPackage = filterPackage;
                    this.mFilterOp = filterOp;
                }

                public void visitHistoricalOps(AppOpsManager.HistoricalOps ops) {
                    this.mWriter.println();
                    this.mWriter.print(this.mOpsPrefix);
                    this.mWriter.println("snapshot:");
                    this.mWriter.print(this.mUidPrefix);
                    this.mWriter.print("begin = ");
                    this.mDate.setTime(ops.getBeginTimeMillis());
                    this.mWriter.print(this.mDateFormatter.format(this.mDate));
                    this.mWriter.print("  (");
                    TimeUtils.formatDuration(ops.getBeginTimeMillis() - this.mNow, this.mWriter);
                    this.mWriter.println(")");
                    this.mWriter.print(this.mUidPrefix);
                    this.mWriter.print("end = ");
                    this.mDate.setTime(ops.getEndTimeMillis());
                    this.mWriter.print(this.mDateFormatter.format(this.mDate));
                    this.mWriter.print("  (");
                    TimeUtils.formatDuration(ops.getEndTimeMillis() - this.mNow, this.mWriter);
                    this.mWriter.println(")");
                }

                public void visitHistoricalUidOps(AppOpsManager.HistoricalUidOps ops) {
                    int i = this.mFilterUid;
                    if (i != -1 && i != ops.getUid()) {
                        return;
                    }
                    this.mWriter.println();
                    this.mWriter.print(this.mUidPrefix);
                    this.mWriter.print("Uid ");
                    UserHandle.formatUid(this.mWriter, ops.getUid());
                    this.mWriter.println(":");
                }

                public void visitHistoricalPackageOps(AppOpsManager.HistoricalPackageOps ops) {
                    String str = this.mFilterPackage;
                    if (str != null && !str.equals(ops.getPackageName())) {
                        return;
                    }
                    this.mWriter.print(this.mPackagePrefix);
                    this.mWriter.print("Package ");
                    this.mWriter.print(ops.getPackageName());
                    this.mWriter.println(":");
                }

                public void visitHistoricalOp(AppOpsManager.HistoricalOp ops) {
                    int i = this.mFilterOp;
                    if (i == -1 || i == ops.getOpCode()) {
                        this.mWriter.print(this.mEntryPrefix);
                        this.mWriter.print(AppOpsManager.opToName(ops.getOpCode()));
                        this.mWriter.println(":");
                        LongSparseArray keys = ops.collectKeys();
                        int keyCount = keys.size();
                        int i2 = 0;
                        while (i2 < keyCount) {
                            long key = keys.keyAt(i2);
                            int uidState = AppOpsManager.extractUidStateFromKey(key);
                            int flags = AppOpsManager.extractFlagsFromKey(key);
                            boolean printedUidState = false;
                            long accessCount = ops.getAccessCount(uidState, uidState, flags);
                            if (accessCount > 0) {
                                if (0 == 0) {
                                    this.mWriter.print(this.mUidStatePrefix);
                                    this.mWriter.print(AppOpsManager.keyToString(key));
                                    this.mWriter.print(" = ");
                                    printedUidState = true;
                                }
                                this.mWriter.print("access=");
                                this.mWriter.print(accessCount);
                            }
                            long rejectCount = ops.getRejectCount(uidState, uidState, flags);
                            LongSparseArray keys2 = keys;
                            if (rejectCount <= 0) {
                                keyCount = keyCount;
                            } else {
                                if (!printedUidState) {
                                    this.mWriter.print(this.mUidStatePrefix);
                                    this.mWriter.print(AppOpsManager.keyToString(key));
                                    this.mWriter.print(" = ");
                                    printedUidState = true;
                                } else {
                                    this.mWriter.print(", ");
                                }
                                this.mWriter.print("reject=");
                                this.mWriter.print(rejectCount);
                            }
                            long accessDuration = ops.getAccessDuration(uidState, uidState, flags);
                            if (accessDuration > 0) {
                                if (!printedUidState) {
                                    this.mWriter.print(this.mUidStatePrefix);
                                    this.mWriter.print(AppOpsManager.keyToString(key));
                                    this.mWriter.print(" = ");
                                    printedUidState = true;
                                } else {
                                    this.mWriter.print(", ");
                                }
                                this.mWriter.print("duration=");
                                TimeUtils.formatDuration(accessDuration, this.mWriter);
                            }
                            if (printedUidState) {
                                this.mWriter.println("");
                            }
                            i2++;
                            keys = keys2;
                            keyCount = keyCount;
                        }
                    }
                }
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static void wtf(String message, Throwable t, File storage) {
                Slog.wtf(LOG_TAG, message, t);
                if (KEEP_WTF_LOG) {
                    try {
                        File file = new File(new File(Environment.getDataSystemDirectory(), "appops"), "wtf" + TimeUtils.formatForLogging(System.currentTimeMillis()));
                        if (file.createNewFile()) {
                            PrintWriter writer = new PrintWriter(file);
                            if (t != null) {
                                try {
                                    writer.append('\n').append((CharSequence) t.toString());
                                } catch (Throwable th) {
                                    try {
                                        throw th;
                                    } catch (Throwable th2) {
                                        try {
                                            writer.close();
                                        } catch (Throwable th3) {
                                            th.addSuppressed(th3);
                                        }
                                        throw th2;
                                    }
                                }
                            }
                            writer.append('\n').append((CharSequence) Debug.getCallers(10));
                            if (storage != null) {
                                writer.append((CharSequence) ("\nfiles: " + Arrays.toString(storage.listFiles())));
                            } else {
                                writer.append((CharSequence) "\nfiles: none");
                            }
                            writer.close();
                        }
                    } catch (IOException e) {
                    }
                }
            }
        }
