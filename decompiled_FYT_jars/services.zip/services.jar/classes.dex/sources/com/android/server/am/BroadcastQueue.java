package com.android.server.am;

import android.app.ActivityManager;
import android.app.AppGlobals;
import android.app.AppOpsManager;
import android.app.BroadcastOptions;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.IIntentReceiver;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageManager;
import android.content.pm.PermissionInfo;
import android.content.pm.ResolveInfo;
import android.net.INetd;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.os.SystemClock;
import android.os.Trace;
import android.os.UserHandle;
import android.util.EventLog;
import android.util.Slog;
import android.util.SparseIntArray;
import android.util.StatsLog;
import android.util.TimeUtils;
import android.util.proto.ProtoOutputStream;
import com.android.internal.app.BroadcastTimeoutListener;
import com.android.server.display.color.DisplayTransformManager;
import com.android.server.pm.DumpState;
import com.android.server.pm.PackageManagerService;
import com.android.server.slice.SliceClientPermissions;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public final class BroadcastQueue {
    static final int BROADCAST_INTENT_MSG = 200;
    static final int BROADCAST_TIMEOUT_MSG = 201;
    static final int MAX_BROADCAST_HISTORY;
    static final int MAX_BROADCAST_SUMMARY_HISTORY;
    private static final String TAG = "BroadcastQueue";
    private static final String TAG_BROADCAST = "BroadcastQueue";
    private static final String TAG_MU = "BroadcastQueue_MU";
    final Intent[] mBroadcastSummaryHistory;
    boolean mBroadcastsScheduled;
    final BroadcastConstants mConstants;
    final boolean mDelayBehindServices;
    final BroadcastDispatcher mDispatcher;
    final BroadcastHandler mHandler;
    boolean mLogLatencyMetrics;
    BroadcastRecord mPendingBroadcast;
    int mPendingBroadcastRecvIndex;
    boolean mPendingBroadcastTimeoutMessage;
    final String mQueueName;
    final ActivityManagerService mService;
    final long[] mSummaryHistoryDispatchTime;
    final long[] mSummaryHistoryEnqueueTime;
    final long[] mSummaryHistoryFinishTime;
    int mSummaryHistoryNext;
    final ArrayList<BroadcastRecord> mParallelBroadcasts = new ArrayList<>();
    final SparseIntArray mSplitRefcounts = new SparseIntArray();
    private int mNextToken = 0;
    final BroadcastRecord[] mBroadcastHistory = new BroadcastRecord[MAX_BROADCAST_HISTORY];
    int mHistoryNext = 0;

    static {
        MAX_BROADCAST_HISTORY = ActivityManager.isLowRamDeviceStatic() ? 10 : 50;
        MAX_BROADCAST_SUMMARY_HISTORY = ActivityManager.isLowRamDeviceStatic() ? 25 : DisplayTransformManager.LEVEL_COLOR_MATRIX_INVERT_COLOR;
    }

    private final class BroadcastHandler extends Handler {
        public BroadcastHandler(Looper looper) {
            super(looper, null, true);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            int i = msg.what;
            if (i == 200) {
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                    Slog.v("BroadcastQueue", "Received BROADCAST_INTENT_MSG [" + BroadcastQueue.this.mQueueName + "]");
                }
                BroadcastQueue.this.processNextBroadcast(true);
                return;
            }
            if (i == BroadcastQueue.BROADCAST_TIMEOUT_MSG) {
                synchronized (BroadcastQueue.this.mService) {
                    try {
                        ActivityManagerService.boostPriorityForLockedSection();
                        BroadcastQueue.this.broadcastTimeoutLocked(true);
                    } finally {
                        ActivityManagerService.resetPriorityAfterLockedSection();
                    }
                }
            }
        }
    }

    private final class AppNotResponding implements Runnable {
        private final String mAnnotation;
        private final ProcessRecord mApp;

        public AppNotResponding(ProcessRecord app, String annotation) {
            this.mApp = app;
            this.mAnnotation = annotation;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.mApp.appNotResponding(null, null, null, null, false, this.mAnnotation);
        }
    }

    BroadcastQueue(ActivityManagerService service, Handler handler, String name, BroadcastConstants constants, boolean allowDelayBehindServices) {
        int i = MAX_BROADCAST_SUMMARY_HISTORY;
        this.mBroadcastSummaryHistory = new Intent[i];
        this.mSummaryHistoryNext = 0;
        this.mSummaryHistoryEnqueueTime = new long[i];
        this.mSummaryHistoryDispatchTime = new long[i];
        this.mSummaryHistoryFinishTime = new long[i];
        this.mBroadcastsScheduled = false;
        this.mPendingBroadcast = null;
        this.mLogLatencyMetrics = true;
        this.mService = service;
        this.mHandler = new BroadcastHandler(handler.getLooper());
        this.mQueueName = name;
        this.mDelayBehindServices = allowDelayBehindServices;
        this.mConstants = constants;
        this.mDispatcher = new BroadcastDispatcher(this, this.mConstants, this.mHandler, this.mService);
    }

    void start(ContentResolver resolver) {
        this.mDispatcher.start();
        this.mConstants.startObserving(this.mHandler, resolver);
    }

    public String toString() {
        return this.mQueueName;
    }

    public boolean isPendingBroadcastProcessLocked(int pid) {
        BroadcastRecord broadcastRecord = this.mPendingBroadcast;
        return broadcastRecord != null && broadcastRecord.curApp.pid == pid;
    }

    public void enqueueParallelBroadcastLocked(BroadcastRecord r) {
        this.mParallelBroadcasts.add(r);
        enqueueBroadcastHelper(r);
        if (ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD) {
            StringBuilder sb = new StringBuilder();
            sb.append("Add broadcast <");
            sb.append(r);
            sb.append("> into [parallel | ");
            sb.append(this.mQueueName);
            sb.append("], pending size ");
            sb.append(this.mParallelBroadcasts.size() - 1);
            Slog.d("BroadcastQueue", sb.toString());
        }
    }

    public void enqueueOrderedBroadcastLocked(BroadcastRecord r) {
        this.mDispatcher.enqueueOrderedBroadcastLocked(r);
        enqueueBroadcastHelper(r);
        if (ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD) {
            StringBuilder sb = new StringBuilder();
            sb.append("Add broadcast <");
            sb.append(r);
            sb.append("> into [ordered | ");
            sb.append(this.mQueueName);
            sb.append("], pending size ");
            sb.append(this.mDispatcher.getOrderedBroadcasts().size() - 1);
            sb.append("\nHeader is ");
            sb.append(this.mDispatcher.getOrderedBroadcasts().get(0));
            sb.append(" now");
            Slog.d("BroadcastQueue", sb.toString());
        }
    }

    private void enqueueBroadcastHelper(BroadcastRecord r) {
        r.enqueueClockTime = System.currentTimeMillis();
        if (Trace.isTagEnabled(64L)) {
            Trace.asyncTraceBegin(64L, createBroadcastTraceTitle(r, 0), System.identityHashCode(r));
        }
    }

    public final BroadcastRecord replaceParallelBroadcastLocked(BroadcastRecord r) {
        return replaceBroadcastLocked(this.mParallelBroadcasts, r, "PARALLEL");
    }

    public final BroadcastRecord replaceOrderedBroadcastLocked(BroadcastRecord r) {
        return this.mDispatcher.replaceBroadcastLocked(r, "ORDERED");
    }

    private BroadcastRecord replaceBroadcastLocked(ArrayList<BroadcastRecord> queue, BroadcastRecord r, String typeForLogging) {
        Intent intent = r.intent;
        for (int i = queue.size() - 1; i > 0; i--) {
            BroadcastRecord old = queue.get(i);
            if (old.userId == r.userId && intent.filterEquals(old.intent)) {
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                    Slog.v("BroadcastQueue", "***** DROPPING " + typeForLogging + " [" + this.mQueueName + "]: " + intent);
                }
                queue.set(i, r);
                return old;
            }
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void processCurBroadcastLocked(BroadcastRecord broadcastRecord, ProcessRecord processRecord, boolean z) throws RemoteException {
        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
            Slog.v("BroadcastQueue", "Process cur broadcast " + broadcastRecord + " for app " + processRecord);
        }
        if (processRecord.thread == null) {
            throw new RemoteException();
        }
        if (processRecord.inFullBackup) {
            skipReceiverLocked(broadcastRecord);
            return;
        }
        if (!processRecord.isBelongToCurrentUser()) {
            Slog.i("BroadcastQueue", "Skipping deliver " + broadcastRecord + " to " + processRecord + " , if not process may be crash by handle it in the locked user state.");
            skipReceiverLocked(broadcastRecord);
            return;
        }
        broadcastRecord.receiver = processRecord.thread.asBinder();
        broadcastRecord.curApp = processRecord;
        processRecord.curReceivers.add(broadcastRecord);
        processRecord.forceProcessStateUpTo(12);
        this.mService.mProcessList.updateLruProcessLocked(processRecord, false, null);
        if (!z) {
            this.mService.updateOomAdjLocked("updateOomAdj_meh");
        }
        broadcastRecord.intent.setComponent(broadcastRecord.curComponent);
        boolean z2 = false;
        try {
            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                Slog.v("BroadcastQueue", "Delivering to component " + broadcastRecord.curComponent + ": " + broadcastRecord);
            }
            this.mService.notifyPackageUse(broadcastRecord.intent.getComponent().getPackageName(), 3);
            processRecord.thread.scheduleReceiver(new Intent(broadcastRecord.intent), broadcastRecord.curReceiver, this.mService.compatibilityInfoForPackage(broadcastRecord.curReceiver.applicationInfo), broadcastRecord.resultCode, broadcastRecord.resultData, broadcastRecord.resultExtras, broadcastRecord.ordered, broadcastRecord.userId, processRecord.getReportedProcState());
            if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                Slog.v("BroadcastQueue", "Process cur broadcast " + broadcastRecord + " DELIVERED for app " + processRecord);
            }
            boolean z3 = true;
        } finally {
            if (!z2) {
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                    Slog.v("BroadcastQueue", "Process cur broadcast " + broadcastRecord + ": NOT STARTED!");
                }
                broadcastRecord.receiver = null;
                broadcastRecord.curApp = 0 == true ? 1 : 0;
                processRecord.curReceivers.remove(broadcastRecord);
            }
        }
    }

    public boolean sendPendingBroadcastsLocked(ProcessRecord app) {
        BroadcastRecord br = this.mPendingBroadcast;
        if (br == null || br.curApp.pid <= 0 || br.curApp.pid != app.pid) {
            return false;
        }
        if (br.curApp != app) {
            Slog.e("BroadcastQueue", "App mismatch when sending pending broadcast to " + app.processName + ", intended target is " + br.curApp.processName);
            return false;
        }
        try {
            this.mPendingBroadcast = null;
            processCurBroadcastLocked(br, app, false);
            return true;
        } catch (Exception e) {
            Slog.w("BroadcastQueue", "Exception in new application when starting receiver " + br.curComponent.flattenToShortString(), e);
            logBroadcastReceiverDiscardLocked(br);
            finishReceiverLocked(br, br.resultCode, br.resultData, br.resultExtras, br.resultAbort, false);
            scheduleBroadcastsLocked();
            br.state = 0;
            throw new RuntimeException(e.getMessage());
        }
    }

    public void skipPendingBroadcastLocked(int pid) {
        BroadcastRecord br = this.mPendingBroadcast;
        if (br != null && br.curApp.pid == pid) {
            br.state = 0;
            br.nextReceiver = this.mPendingBroadcastRecvIndex;
            this.mPendingBroadcast = null;
            scheduleBroadcastsLocked();
        }
    }

    public void skipCurrentReceiverLocked(ProcessRecord app) {
        BroadcastRecord broadcastRecord;
        BroadcastRecord r = null;
        BroadcastRecord curActive = this.mDispatcher.getActiveBroadcastLocked();
        if (curActive != null && curActive.curApp == app) {
            r = curActive;
        }
        if (r == null && (broadcastRecord = this.mPendingBroadcast) != null && broadcastRecord.curApp == app) {
            if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                Slog.v("BroadcastQueue", "[" + this.mQueueName + "] skip & discard pending app " + r);
            }
            r = this.mPendingBroadcast;
        }
        if (r != null) {
            skipReceiverLocked(r);
        }
    }

    private void skipReceiverLocked(BroadcastRecord r) {
        logBroadcastReceiverDiscardLocked(r);
        finishReceiverLocked(r, r.resultCode, r.resultData, r.resultExtras, r.resultAbort, false);
        scheduleBroadcastsLocked();
    }

    public void scheduleBroadcastsLocked() {
        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
            Slog.v("BroadcastQueue", "Schedule broadcasts [" + this.mQueueName + "]: current=" + this.mBroadcastsScheduled);
        }
        if (this.mBroadcastsScheduled) {
            return;
        }
        BroadcastHandler broadcastHandler = this.mHandler;
        broadcastHandler.sendMessage(broadcastHandler.obtainMessage(200, this));
        this.mBroadcastsScheduled = true;
    }

    public BroadcastRecord getMatchingOrderedReceiver(IBinder receiver) {
        BroadcastRecord br = this.mDispatcher.getActiveBroadcastLocked();
        if (br != null && br.receiver == receiver) {
            return br;
        }
        return null;
    }

    private int nextSplitTokenLocked() {
        int next = this.mNextToken + 1;
        if (next <= 0) {
            next = 1;
        }
        this.mNextToken = next;
        return next;
    }

    private void postActivityStartTokenRemoval(final ProcessRecord app, final BroadcastRecord r) {
        String msgToken = (app.toShortString() + r.toString()).intern();
        this.mHandler.removeCallbacksAndMessages(msgToken);
        this.mHandler.postAtTime(new Runnable() { // from class: com.android.server.am.-$$Lambda$BroadcastQueue$u5X4lnAPSSN1Kjb_BebqIicVqK4
            @Override // java.lang.Runnable
            public final void run() {
                app.removeAllowBackgroundActivityStartsToken(r);
            }
        }, msgToken, r.receiverTime + this.mConstants.ALLOW_BG_ACTIVITY_START_TIMEOUT);
    }

    public boolean finishReceiverLocked(BroadcastRecord r, int resultCode, String resultData, Bundle resultExtras, boolean resultAbort, boolean waitForServices) {
        ActivityInfo nextReceiver;
        int state = r.state;
        ActivityInfo receiver = r.curReceiver;
        long finishTime = SystemClock.uptimeMillis();
        long elapsed = finishTime - r.receiverTime;
        boolean z = false;
        r.state = 0;
        if (state == 0) {
            Slog.w("BroadcastQueue", "finishReceiver [" + this.mQueueName + "] called but state is IDLE");
        }
        if (r.allowBackgroundActivityStarts && r.curApp != null) {
            if (elapsed <= this.mConstants.ALLOW_BG_ACTIVITY_START_TIMEOUT) {
                postActivityStartTokenRemoval(r.curApp, r);
            } else {
                r.curApp.removeAllowBackgroundActivityStartsToken(r);
            }
        }
        if (r.nextReceiver > 0) {
            r.duration[r.nextReceiver - 1] = elapsed;
        }
        if (r.timeoutExempt) {
            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                Slog.i("BroadcastQueue", "Finished broadcast " + r.intent.getAction() + " is exempt from deferral policy");
            }
        } else if (this.mConstants.SLOW_TIME > 0 && elapsed > this.mConstants.SLOW_TIME) {
            if (!UserHandle.isCore(r.curApp.uid)) {
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                    Slog.i("BroadcastQueue", "Broadcast receiver " + (r.nextReceiver - 1) + " was slow: " + receiver + " br=" + r);
                }
                if (r.curApp != null) {
                    this.mDispatcher.startDeferring(r.curApp.uid);
                } else {
                    Slog.d("BroadcastQueue", "finish receiver curApp is null? " + r);
                }
            } else if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                Slog.i("BroadcastQueue", "Core uid " + r.curApp.uid + " receiver was slow but not deferring: " + receiver + " br=" + r);
            }
        }
        r.receiver = null;
        r.intent.setComponent(null);
        if (r.curApp != null && r.curApp.curReceivers.contains(r)) {
            r.curApp.curReceivers.remove(r);
        }
        if (r.curFilter != null) {
            r.curFilter.receiverList.curBroadcast = null;
        }
        r.curFilter = null;
        r.curReceiver = null;
        r.curApp = null;
        this.mPendingBroadcast = null;
        r.resultCode = resultCode;
        r.resultData = resultData;
        r.resultExtras = resultExtras;
        if (resultAbort && (r.intent.getFlags() & 134217728) == 0) {
            r.resultAbort = resultAbort;
        } else {
            r.resultAbort = false;
        }
        if (waitForServices && r.curComponent != null && r.queue.mDelayBehindServices && r.queue.mDispatcher.getActiveBroadcastLocked() == r) {
            if (r.nextReceiver < r.receivers.size()) {
                Object obj = r.receivers.get(r.nextReceiver);
                nextReceiver = obj instanceof ActivityInfo ? (ActivityInfo) obj : null;
            } else {
                nextReceiver = null;
            }
            if ((receiver != null && nextReceiver != null && receiver.applicationInfo.uid == nextReceiver.applicationInfo.uid && receiver.processName.equals(nextReceiver.processName)) || !this.mService.mServices.hasBackgroundServicesLocked(r.userId)) {
                z = false;
            } else {
                Slog.i("BroadcastQueue", "Delay finish: " + r.curComponent.flattenToShortString());
                r.state = 4;
                return false;
            }
        }
        r.curComponent = null;
        if (state == 1 || state == 3) {
            return true;
        }
        return z;
    }

    public void backgroundServicesFinishedLocked(int userId) {
        BroadcastRecord br = this.mDispatcher.getActiveBroadcastLocked();
        if (br != null && br.userId == userId && br.state == 4) {
            Slog.i("BroadcastQueue", "Resuming delayed broadcast");
            br.curComponent = null;
            br.state = 0;
            processNextBroadcast(false);
        }
    }

    void performReceiveLocked(ProcessRecord app, IIntentReceiver receiver, Intent intent, int resultCode, String data, Bundle extras, boolean ordered, boolean sticky, int sendingUser) throws RemoteException {
        if (app != null) {
            if (app.thread != null) {
                try {
                    app.thread.scheduleRegisteredReceiver(receiver, intent, resultCode, data, extras, ordered, sticky, sendingUser, app.getReportedProcState());
                    return;
                } catch (RemoteException ex) {
                    synchronized (this.mService) {
                        try {
                            ActivityManagerService.boostPriorityForLockedSection();
                            Slog.w("BroadcastQueue", "Can't deliver broadcast to " + app.processName + " (pid " + app.pid + "). Crashing it.");
                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                this.mService.dumpHeapIfNeededLocked(app);
                            }
                            app.scheduleCrash("can't deliver broadcast");
                            throw ex;
                        } finally {
                            ActivityManagerService.resetPriorityAfterLockedSection();
                        }
                    }
                }
            }
            throw new RemoteException("app.thread must not be null");
        }
        receiver.performReceive(intent, resultCode, data, extras, ordered, sticky, sendingUser);
    }

    /* JADX WARN: Code duplicated, block: B:101:0x04b0  */
    /* JADX WARN: Code duplicated, block: B:103:0x04c8  */
    /* JADX WARN: Code duplicated, block: B:106:0x04e6 A[Catch: RemoteException -> 0x0558, TryCatch #0 {RemoteException -> 0x0558, blocks: (B:104:0x04e2, B:106:0x04e6, B:107:0x0502, B:109:0x0508, B:112:0x0512, B:119:0x0554, B:113:0x0516, B:115:0x0547, B:117:0x054b), top: B:130:0x04e2 }] */
    /* JADX WARN: Code duplicated, block: B:109:0x0508 A[Catch: RemoteException -> 0x0558, TryCatch #0 {RemoteException -> 0x0558, blocks: (B:104:0x04e2, B:106:0x04e6, B:107:0x0502, B:109:0x0508, B:112:0x0512, B:119:0x0554, B:113:0x0516, B:115:0x0547, B:117:0x054b), top: B:130:0x04e2 }] */
    /* JADX WARN: Code duplicated, block: B:113:0x0516 A[Catch: RemoteException -> 0x0558, TryCatch #0 {RemoteException -> 0x0558, blocks: (B:104:0x04e2, B:106:0x04e6, B:107:0x0502, B:109:0x0508, B:112:0x0512, B:119:0x0554, B:113:0x0516, B:115:0x0547, B:117:0x054b), top: B:130:0x04e2 }] */
    /* JADX WARN: Code duplicated, block: B:115:0x0547 A[Catch: RemoteException -> 0x0558, TryCatch #0 {RemoteException -> 0x0558, blocks: (B:104:0x04e2, B:106:0x04e6, B:107:0x0502, B:109:0x0508, B:112:0x0512, B:119:0x0554, B:113:0x0516, B:115:0x0547, B:117:0x054b), top: B:130:0x04e2 }] */
    /* JADX WARN: Code duplicated, block: B:119:0x0554 A[Catch: RemoteException -> 0x0558, TRY_LEAVE, TryCatch #0 {RemoteException -> 0x0558, blocks: (B:104:0x04e2, B:106:0x04e6, B:107:0x0502, B:109:0x0508, B:112:0x0512, B:119:0x0554, B:113:0x0516, B:115:0x0547, B:117:0x054b), top: B:130:0x04e2 }] */
    /* JADX WARN: Code duplicated, block: B:139:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:57:0x0309  */
    /* JADX WARN: Code duplicated, block: B:63:0x037a  */
    /* JADX WARN: Code duplicated, block: B:72:0x03c9  */
    /* JADX WARN: Code duplicated, block: B:73:0x03cb  */
    /* JADX WARN: Code duplicated, block: B:76:0x03cf A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:83:0x042f  */
    /* JADX WARN: Code duplicated, block: B:90:0x0490  */
    /* JADX WARN: Code duplicated, block: B:93:0x0495  */
    /* JADX WARN: Code duplicated, block: B:95:0x049a  */
    /* JADX WARN: Code duplicated, block: B:97:0x04a4  */
    /* JADX WARN: Code duplicated, block: B:99:0x04a9  */
    /* JADX WARN: Instruction removed from duplicated block: B:106:0x04e6, please report this as an issue */
    private void deliverToRegisteredReceiverLocked(BroadcastRecord r, BroadcastFilter filter, boolean ordered, int index) {
        boolean skip;
        boolean skip2;
        boolean skip3;
        boolean z;
        boolean skip4;
        boolean skip5 = false;
        if (!this.mService.validateAssociationAllowedLocked(r.callerPackage, r.callingUid, filter.packageName, filter.owningUid)) {
            Slog.w("BroadcastQueue", "Association not allowed: broadcasting " + r.intent.toString() + " from " + r.callerPackage + " (pid=" + r.callingPid + ", uid=" + r.callingUid + ") to " + filter.packageName + " through " + filter);
            skip5 = true;
        }
        if (!skip5 && !this.mService.mIntentFirewall.checkBroadcast(r.intent, r.callingUid, r.callingPid, r.resolvedType, filter.receiverList.uid)) {
            Slog.w("BroadcastQueue", "Firewall blocked: broadcasting " + r.intent.toString() + " from " + r.callerPackage + " (pid=" + r.callingPid + ", uid=" + r.callingUid + ") to " + filter.packageName + " through " + filter);
            skip5 = true;
        }
        boolean z2 = true;
        if (filter.requiredPermission != null) {
            ActivityManagerService activityManagerService = this.mService;
            int perm = ActivityManagerService.checkComponentPermission(filter.requiredPermission, r.callingPid, r.callingUid, -1, true);
            if (perm != 0) {
                Slog.w("BroadcastQueue", "Permission Denial: broadcasting " + r.intent.toString() + " from " + r.callerPackage + " (pid=" + r.callingPid + ", uid=" + r.callingUid + ") requires " + filter.requiredPermission + " due to registered receiver " + filter);
                skip5 = true;
            } else {
                int opCode = AppOpsManager.permissionToOpCode(filter.requiredPermission);
                if (opCode != -1 && this.mService.mAppOpsService.noteOperation(opCode, r.callingUid, r.callerPackage) != 0) {
                    Slog.w("BroadcastQueue", "Appop Denial: broadcasting " + r.intent.toString() + " from " + r.callerPackage + " (pid=" + r.callingPid + ", uid=" + r.callingUid + ") requires appop " + AppOpsManager.permissionToOp(filter.requiredPermission) + " due to registered receiver " + filter);
                    skip5 = true;
                }
            }
        }
        if (skip5 || r.requiredPermissions == null || r.requiredPermissions.length <= 0) {
            skip = skip5;
        } else {
            int i = 0;
            while (true) {
                if (i < r.requiredPermissions.length) {
                    String requiredPermission = r.requiredPermissions[i];
                    ActivityManagerService activityManagerService2 = this.mService;
                    boolean skip6 = skip5;
                    int i2 = i;
                    int perm2 = ActivityManagerService.checkComponentPermission(requiredPermission, filter.receiverList.pid, filter.receiverList.uid, -1, z2);
                    if (perm2 != 0) {
                        Slog.w("BroadcastQueue", "Permission Denial: receiving " + r.intent.toString() + " to " + filter.receiverList.app + " (pid=" + filter.receiverList.pid + ", uid=" + filter.receiverList.uid + ") requires " + requiredPermission + " due to sender " + r.callerPackage + " (uid " + r.callingUid + ")");
                        skip2 = true;
                        break;
                    }
                    int appOp = AppOpsManager.permissionToOpCode(requiredPermission);
                    if (appOp != -1 && appOp != r.appOp) {
                        if (this.mService.mAppOpsService.noteOperation(appOp, filter.receiverList.uid, filter.packageName) != 0) {
                            Slog.w("BroadcastQueue", "Appop Denial: receiving " + r.intent.toString() + " to " + filter.receiverList.app + " (pid=" + filter.receiverList.pid + ", uid=" + filter.receiverList.uid + ") requires appop " + AppOpsManager.permissionToOp(requiredPermission) + " due to sender " + r.callerPackage + " (uid " + r.callingUid + ")");
                            skip2 = true;
                            break;
                        }
                    }
                    i = i2 + 1;
                    skip5 = skip6;
                    z2 = true;
                } else {
                    skip = skip5;
                }
            }
            if (skip2 && (r.requiredPermissions == null || r.requiredPermissions.length == 0)) {
                ActivityManagerService activityManagerService3 = this.mService;
                int perm3 = ActivityManagerService.checkComponentPermission(null, filter.receiverList.pid, filter.receiverList.uid, -1, true);
                if (perm3 != 0) {
                    Slog.w("BroadcastQueue", "Permission Denial: security check failed when receiving " + r.intent.toString() + " to " + filter.receiverList.app + " (pid=" + filter.receiverList.pid + ", uid=" + filter.receiverList.uid + ") due to sender " + r.callerPackage + " (uid " + r.callingUid + ")");
                    skip3 = true;
                }
                if (!skip3 && r.appOp != -1 && this.mService.mAppOpsService.noteOperation(r.appOp, filter.receiverList.uid, filter.packageName) != 0) {
                    Slog.w("BroadcastQueue", "Appop Denial: receiving " + r.intent.toString() + " to " + filter.receiverList.app + " (pid=" + filter.receiverList.pid + ", uid=" + filter.receiverList.uid + ") requires appop " + AppOpsManager.opToName(r.appOp) + " due to sender " + r.callerPackage + " (uid " + r.callingUid + ")");
                    skip3 = true;
                }
                if (!skip3 && (filter.receiverList.app == null || filter.receiverList.app.killed || filter.receiverList.app.isCrashing())) {
                    Slog.w("BroadcastQueue", "Skipping deliver [" + this.mQueueName + "] " + r + " to " + filter.receiverList + ": process gone or crashing");
                    skip3 = true;
                }
                if ((r.intent.getFlags() & DumpState.DUMP_COMPILER_STATS) != 0) {
                    z = true;
                } else {
                    z = false;
                }
                boolean visibleToInstantApps = z;
                if (!skip3 && !visibleToInstantApps && filter.instantApp && filter.receiverList.uid != r.callingUid) {
                    Slog.w("BroadcastQueue", "Instant App Denial: receiving " + r.intent.toString() + " to " + filter.receiverList.app + " (pid=" + filter.receiverList.pid + ", uid=" + filter.receiverList.uid + ") due to sender " + r.callerPackage + " (uid " + r.callingUid + ") not specifying FLAG_RECEIVER_VISIBLE_TO_INSTANT_APPS");
                    skip3 = true;
                }
                if (skip3 && !filter.visibleToInstantApp && r.callerInstantApp && filter.receiverList.uid != r.callingUid) {
                    Slog.w("BroadcastQueue", "Instant App Denial: receiving " + r.intent.toString() + " to " + filter.receiverList.app + " (pid=" + filter.receiverList.pid + ", uid=" + filter.receiverList.uid + ") requires receiver be visible to instant apps due to sender " + r.callerPackage + " (uid " + r.callingUid + ")");
                    skip4 = true;
                } else {
                    skip4 = skip3;
                }
                if (!skip4) {
                    if (!requestStartTargetPermissionsReviewIfNeededLocked(r, filter.packageName, filter.owningUserId)) {
                        r.delivery[index] = 2;
                        return;
                    }
                    r.delivery[index] = 1;
                    if (ordered) {
                        r.receiver = filter.receiverList.receiver.asBinder();
                        r.curFilter = filter;
                        filter.receiverList.curBroadcast = r;
                        r.state = 2;
                        if (filter.receiverList.app != null) {
                            r.curApp = filter.receiverList.app;
                            filter.receiverList.app.curReceivers.add(r);
                            this.mService.updateOomAdjLocked(r.curApp, true, "updateOomAdj_startReceiver");
                        }
                    }
                    try {
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                            Slog.i("BroadcastQueue", "Delivering to " + filter + " : " + r);
                        }
                        if (filter.receiverList.app == null && filter.receiverList.app.inFullBackup) {
                            if (ordered) {
                                skipReceiverLocked(r);
                            }
                        } else {
                            r.receiverTime = SystemClock.uptimeMillis();
                            maybeAddAllowBackgroundActivityStartsToken(filter.receiverList.app, r);
                            performReceiveLocked(filter.receiverList.app, filter.receiverList.receiver, new Intent(r.intent), r.resultCode, r.resultData, r.resultExtras, r.ordered, r.initialSticky, r.userId);
                            if (r.allowBackgroundActivityStarts && !r.ordered) {
                                postActivityStartTokenRemoval(filter.receiverList.app, r);
                            }
                        }
                        if (ordered) {
                            r.state = 3;
                            return;
                        }
                        return;
                    } catch (RemoteException e) {
                        Slog.w("BroadcastQueue", "Failure sending broadcast " + r.intent, e);
                        if (filter.receiverList.app != null) {
                            filter.receiverList.app.removeAllowBackgroundActivityStartsToken(r);
                            if (ordered) {
                                filter.receiverList.app.curReceivers.remove(r);
                            }
                        }
                        if (ordered) {
                            r.receiver = null;
                            r.curFilter = null;
                            filter.receiverList.curBroadcast = null;
                            return;
                        }
                        return;
                    }
                }
                r.delivery[index] = 2;
            }
            skip3 = skip2;
            if (!skip3) {
                Slog.w("BroadcastQueue", "Appop Denial: receiving " + r.intent.toString() + " to " + filter.receiverList.app + " (pid=" + filter.receiverList.pid + ", uid=" + filter.receiverList.uid + ") requires appop " + AppOpsManager.opToName(r.appOp) + " due to sender " + r.callerPackage + " (uid " + r.callingUid + ")");
                skip3 = true;
            }
            if (!skip3) {
                Slog.w("BroadcastQueue", "Skipping deliver [" + this.mQueueName + "] " + r + " to " + filter.receiverList + ": process gone or crashing");
                skip3 = true;
            }
            if ((r.intent.getFlags() & DumpState.DUMP_COMPILER_STATS) != 0) {
                z = true;
            } else {
                z = false;
            }
            boolean visibleToInstantApps2 = z;
            if (!skip3) {
                Slog.w("BroadcastQueue", "Instant App Denial: receiving " + r.intent.toString() + " to " + filter.receiverList.app + " (pid=" + filter.receiverList.pid + ", uid=" + filter.receiverList.uid + ") due to sender " + r.callerPackage + " (uid " + r.callingUid + ") not specifying FLAG_RECEIVER_VISIBLE_TO_INSTANT_APPS");
                skip3 = true;
            }
            if (skip3) {
                skip4 = skip3;
            } else {
                skip4 = skip3;
            }
            if (!skip4) {
                if (!requestStartTargetPermissionsReviewIfNeededLocked(r, filter.packageName, filter.owningUserId)) {
                    r.delivery[index] = 2;
                    return;
                }
                r.delivery[index] = 1;
                if (ordered) {
                    r.receiver = filter.receiverList.receiver.asBinder();
                    r.curFilter = filter;
                    filter.receiverList.curBroadcast = r;
                    r.state = 2;
                    if (filter.receiverList.app != null) {
                        r.curApp = filter.receiverList.app;
                        filter.receiverList.app.curReceivers.add(r);
                        this.mService.updateOomAdjLocked(r.curApp, true, "updateOomAdj_startReceiver");
                    }
                }
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                    Slog.i("BroadcastQueue", "Delivering to " + filter + " : " + r);
                }
                if (filter.receiverList.app == null) {
                    r.receiverTime = SystemClock.uptimeMillis();
                    maybeAddAllowBackgroundActivityStartsToken(filter.receiverList.app, r);
                    performReceiveLocked(filter.receiverList.app, filter.receiverList.receiver, new Intent(r.intent), r.resultCode, r.resultData, r.resultExtras, r.ordered, r.initialSticky, r.userId);
                    if (r.allowBackgroundActivityStarts) {
                        postActivityStartTokenRemoval(filter.receiverList.app, r);
                    }
                } else {
                    r.receiverTime = SystemClock.uptimeMillis();
                    maybeAddAllowBackgroundActivityStartsToken(filter.receiverList.app, r);
                    performReceiveLocked(filter.receiverList.app, filter.receiverList.receiver, new Intent(r.intent), r.resultCode, r.resultData, r.resultExtras, r.ordered, r.initialSticky, r.userId);
                    if (r.allowBackgroundActivityStarts) {
                        postActivityStartTokenRemoval(filter.receiverList.app, r);
                    }
                }
                if (ordered) {
                    r.state = 3;
                    return;
                }
                return;
            }
            r.delivery[index] = 2;
        }
        skip2 = skip;
        if (skip2) {
        }
        skip3 = skip2;
        if (!skip3) {
            Slog.w("BroadcastQueue", "Appop Denial: receiving " + r.intent.toString() + " to " + filter.receiverList.app + " (pid=" + filter.receiverList.pid + ", uid=" + filter.receiverList.uid + ") requires appop " + AppOpsManager.opToName(r.appOp) + " due to sender " + r.callerPackage + " (uid " + r.callingUid + ")");
            skip3 = true;
        }
        if (!skip3) {
            Slog.w("BroadcastQueue", "Skipping deliver [" + this.mQueueName + "] " + r + " to " + filter.receiverList + ": process gone or crashing");
            skip3 = true;
        }
        if ((r.intent.getFlags() & DumpState.DUMP_COMPILER_STATS) != 0) {
            z = true;
        } else {
            z = false;
        }
        boolean visibleToInstantApps3 = z;
        if (!skip3) {
            Slog.w("BroadcastQueue", "Instant App Denial: receiving " + r.intent.toString() + " to " + filter.receiverList.app + " (pid=" + filter.receiverList.pid + ", uid=" + filter.receiverList.uid + ") due to sender " + r.callerPackage + " (uid " + r.callingUid + ") not specifying FLAG_RECEIVER_VISIBLE_TO_INSTANT_APPS");
            skip3 = true;
        }
        if (skip3) {
            skip4 = skip3;
        } else {
            skip4 = skip3;
        }
        if (!skip4) {
            if (!requestStartTargetPermissionsReviewIfNeededLocked(r, filter.packageName, filter.owningUserId)) {
                r.delivery[index] = 2;
                return;
            }
            r.delivery[index] = 1;
            if (ordered) {
                r.receiver = filter.receiverList.receiver.asBinder();
                r.curFilter = filter;
                filter.receiverList.curBroadcast = r;
                r.state = 2;
                if (filter.receiverList.app != null) {
                    r.curApp = filter.receiverList.app;
                    filter.receiverList.app.curReceivers.add(r);
                    this.mService.updateOomAdjLocked(r.curApp, true, "updateOomAdj_startReceiver");
                }
            }
            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                Slog.i("BroadcastQueue", "Delivering to " + filter + " : " + r);
            }
            if (filter.receiverList.app == null) {
                r.receiverTime = SystemClock.uptimeMillis();
                maybeAddAllowBackgroundActivityStartsToken(filter.receiverList.app, r);
                performReceiveLocked(filter.receiverList.app, filter.receiverList.receiver, new Intent(r.intent), r.resultCode, r.resultData, r.resultExtras, r.ordered, r.initialSticky, r.userId);
                if (r.allowBackgroundActivityStarts) {
                    postActivityStartTokenRemoval(filter.receiverList.app, r);
                }
            } else {
                r.receiverTime = SystemClock.uptimeMillis();
                maybeAddAllowBackgroundActivityStartsToken(filter.receiverList.app, r);
                performReceiveLocked(filter.receiverList.app, filter.receiverList.receiver, new Intent(r.intent), r.resultCode, r.resultData, r.resultExtras, r.ordered, r.initialSticky, r.userId);
                if (r.allowBackgroundActivityStarts) {
                    postActivityStartTokenRemoval(filter.receiverList.app, r);
                }
            }
            if (ordered) {
                r.state = 3;
                return;
            }
            return;
        }
        r.delivery[index] = 2;
    }

    private boolean requestStartTargetPermissionsReviewIfNeededLocked(BroadcastRecord receiverRecord, String receivingPackageName, final int receivingUserId) throws Throwable {
        if (!this.mService.getPackageManagerInternalLocked().isPermissionsReviewRequired(receivingPackageName, receivingUserId)) {
            return true;
        }
        boolean callerForeground = receiverRecord.callerApp == null || receiverRecord.callerApp.setSchedGroup != 0;
        if (callerForeground && receiverRecord.intent.getComponent() != null) {
            PendingIntentRecord intentSender = this.mService.mPendingIntentController.getIntentSender(1, receiverRecord.callerPackage, receiverRecord.callingUid, receiverRecord.userId, null, null, 0, new Intent[]{receiverRecord.intent}, new String[]{receiverRecord.intent.resolveType(this.mService.mContext.getContentResolver())}, 1409286144, null);
            final Intent intent = new Intent("android.intent.action.REVIEW_PERMISSIONS");
            intent.addFlags(411041792);
            intent.putExtra("android.intent.extra.PACKAGE_NAME", receivingPackageName);
            intent.putExtra("android.intent.extra.INTENT", new IntentSender(intentSender));
            if (ActivityManagerDebugConfig.DEBUG_PERMISSIONS_REVIEW) {
                Slog.i("BroadcastQueue", "u" + receivingUserId + " Launching permission review for package " + receivingPackageName);
            }
            this.mHandler.post(new Runnable() { // from class: com.android.server.am.BroadcastQueue.1
                @Override // java.lang.Runnable
                public void run() {
                    BroadcastQueue.this.mService.mContext.startActivityAsUser(intent, new UserHandle(receivingUserId));
                }
            });
        } else {
            Slog.w("BroadcastQueue", "u" + receivingUserId + " Receiving a broadcast in package" + receivingPackageName + " requires a permissions review");
        }
        return false;
    }

    final void scheduleTempWhitelistLocked(int uid, long duration, BroadcastRecord r) {
        if (duration > 2147483647L) {
            duration = 2147483647L;
        }
        StringBuilder b = new StringBuilder();
        b.append("broadcast:");
        UserHandle.formatUid(b, r.callingUid);
        b.append(":");
        if (r.intent.getAction() != null) {
            b.append(r.intent.getAction());
        } else if (r.intent.getComponent() != null) {
            r.intent.getComponent().appendShortString(b);
        } else if (r.intent.getData() != null) {
            b.append(r.intent.getData());
        }
        this.mService.tempWhitelistUidLocked(uid, duration, b.toString());
    }

    final boolean isSignaturePerm(String[] perms) {
        if (perms == null) {
            return false;
        }
        IPackageManager pm = AppGlobals.getPackageManager();
        for (int i = perms.length - 1; i >= 0; i--) {
            try {
                PermissionInfo pi = pm.getPermissionInfo(perms[i], PackageManagerService.PLATFORM_PACKAGE_NAME, 0);
                if (pi == null || (pi.protectionLevel & 31) != 2) {
                    return false;
                }
            } catch (RemoteException e) {
                return false;
            }
        }
        return true;
    }

    final void processNextBroadcast(boolean fromMsg) {
        synchronized (this.mService) {
            try {
                ActivityManagerService.boostPriorityForLockedSection();
                processNextBroadcastLocked(fromMsg, false);
            } finally {
                ActivityManagerService.resetPriorityAfterLockedSection();
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:101:0x02ff  */
    /* JADX WARN: Code duplicated, block: B:147:0x0486  */
    /* JADX WARN: Code duplicated, block: B:148:0x048c  */
    /* JADX WARN: Code duplicated, block: B:150:0x0490  */
    /* JADX WARN: Code duplicated, block: B:152:0x0495  */
    /* JADX WARN: Code duplicated, block: B:154:0x04a0  */
    /* JADX WARN: Code duplicated, block: B:156:0x04a4  */
    /* JADX WARN: Code duplicated, block: B:158:0x04d2  */
    /* JADX WARN: Code duplicated, block: B:160:0x04d6  */
    /* JADX WARN: Code duplicated, block: B:162:0x0514  */
    /* JADX WARN: Code duplicated, block: B:179:0x05ba  */
    /* JADX WARN: Code duplicated, block: B:180:0x05c3  */
    /* JADX WARN: Code duplicated, block: B:183:0x05cf  */
    /* JADX WARN: Code duplicated, block: B:186:0x05e5  */
    /* JADX WARN: Code duplicated, block: B:187:0x05ec  */
    /* JADX WARN: Code duplicated, block: B:190:0x05f4  */
    /* JADX WARN: Code duplicated, block: B:192:0x05f8  */
    /* JADX WARN: Code duplicated, block: B:195:0x0648  */
    /* JADX WARN: Code duplicated, block: B:201:0x067f A[ADDED_TO_REGION, REMOVE] */
    /* JADX WARN: Code duplicated, block: B:206:0x069c  */
    /* JADX WARN: Code duplicated, block: B:208:0x06aa  */
    /* JADX WARN: Code duplicated, block: B:211:0x06bb  */
    /* JADX WARN: Code duplicated, block: B:214:0x06da  */
    /* JADX WARN: Code duplicated, block: B:217:0x06fe  */
    /* JADX WARN: Code duplicated, block: B:219:0x0709  */
    /* JADX WARN: Code duplicated, block: B:223:0x0740  */
    /* JADX WARN: Code duplicated, block: B:225:0x0747  */
    /* JADX WARN: Code duplicated, block: B:228:0x0778  */
    /* JADX WARN: Code duplicated, block: B:240:0x07a0  */
    /* JADX WARN: Code duplicated, block: B:243:0x07d3  */
    /* JADX WARN: Code duplicated, block: B:245:0x07e9  */
    /* JADX WARN: Code duplicated, block: B:251:0x0805  */
    /* JADX WARN: Code duplicated, block: B:254:0x0823  */
    /* JADX WARN: Code duplicated, block: B:258:0x0882  */
    /* JADX WARN: Code duplicated, block: B:260:0x08a9  */
    /* JADX WARN: Code duplicated, block: B:262:0x08f1  */
    /* JADX WARN: Code duplicated, block: B:266:0x091d  */
    /* JADX WARN: Code duplicated, block: B:270:0x093a A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:276:0x09ed A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:277:0x09ef  */
    /* JADX WARN: Code duplicated, block: B:284:0x0a66  */
    /* JADX WARN: Code duplicated, block: B:287:0x0a6b  */
    /* JADX WARN: Code duplicated, block: B:312:0x0b64  */
    /* JADX WARN: Code duplicated, block: B:314:0x0b67  */
    /* JADX WARN: Code duplicated, block: B:326:0x0bfe  */
    /* JADX WARN: Code duplicated, block: B:330:0x0c33  */
    /* JADX WARN: Code duplicated, block: B:336:0x0c87  */
    /* JADX WARN: Code duplicated, block: B:345:0x0ce0  */
    /* JADX WARN: Code duplicated, block: B:349:0x0d1a  */
    /* JADX WARN: Code duplicated, block: B:355:0x0d50  */
    /* JADX WARN: Code duplicated, block: B:357:0x0d54  */
    /* JADX WARN: Code duplicated, block: B:359:0x0d58  */
    /* JADX WARN: Code duplicated, block: B:362:0x0d88  */
    /* JADX WARN: Code duplicated, block: B:367:0x0da9 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:373:0x0dd3  */
    /* JADX WARN: Code duplicated, block: B:375:0x0dfd  */
    /* JADX WARN: Code duplicated, block: B:377:0x0e00  */
    /* JADX WARN: Code duplicated, block: B:378:0x0e26  */
    /* JADX WARN: Code duplicated, block: B:380:0x0e31  */
    /* JADX WARN: Code duplicated, block: B:389:0x0e89  */
    /* JADX WARN: Code duplicated, block: B:392:0x0e8f  */
    /* JADX WARN: Code duplicated, block: B:397:0x0ee3  */
    /* JADX WARN: Code duplicated, block: B:399:0x0ee7  */
    /* JADX WARN: Code duplicated, block: B:401:0x0eeb  */
    /* JADX WARN: Code duplicated, block: B:403:0x0eef  */
    /* JADX WARN: Code duplicated, block: B:406:0x0f2b  */
    /* JADX WARN: Code duplicated, block: B:408:0x0f41  */
    /* JADX WARN: Code duplicated, block: B:412:0x0f74  */
    /* JADX WARN: Code duplicated, block: B:422:0x0fbf  */
    /* JADX WARN: Code duplicated, block: B:445:0x106d  */
    /* JADX WARN: Code duplicated, block: B:448:0x107a  */
    /* JADX WARN: Code duplicated, block: B:449:0x10a5  */
    /* JADX WARN: Code duplicated, block: B:452:0x10cb  */
    /* JADX WARN: Code duplicated, block: B:453:0x10ce  */
    /* JADX WARN: Code duplicated, block: B:456:0x10e4  */
    /* JADX WARN: Code duplicated, block: B:458:0x1133  */
    /* JADX WARN: Code duplicated, block: B:460:0x113d A[LOOP:2: B:67:0x0201->B:460:0x113d, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:473:0x051c A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:475:0x0518 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:492:0x02d2 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:493:0x068d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:504:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:99:0x02d6  */
    /* JADX WARN: Instruction removed from duplicated block: B:156:0x04a4, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:160:0x04d6, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:192:0x05f8, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:214:0x06da, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:219:0x0709, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:225:0x0747, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:240:0x07a0, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:251:0x0805, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:260:0x08a9, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:359:0x0d58, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:377:0x0e00, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:403:0x0eef, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:456:0x10e4, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:99:0x02d6, please report this as an issue */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v294 */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r4v0 */
    final void processNextBroadcastLocked(boolean z, boolean z2) {
        int i;
        int i2;
        boolean z3;
        int i3;
        BroadcastRecord broadcastRecord;
        IIntentReceiver iIntentReceiver;
        long j;
        long jUptimeMillis;
        String strValueOf;
        BroadcastRecord broadcastRecord2;
        boolean z4;
        boolean z5;
        int i4;
        int i5;
        BroadcastOptions broadcastOptions;
        Object obj;
        ResolveInfo resolveInfo;
        ComponentName componentName;
        boolean z6;
        boolean z7;
        int iPermissionToOpCode;
        boolean zIsSingleton;
        int i6;
        String str;
        ProcessRecord processRecordLocked;
        boolean z8;
        boolean z9;
        boolean z10;
        String str2;
        boolean z11;
        ProcessRecord processRecordStartProcessLocked;
        int appStartModeLocked;
        boolean zIsPackageAvailable;
        boolean z12;
        boolean z13;
        BroadcastFilter broadcastFilter;
        long j2;
        BroadcastRecord broadcastRecordSplitRecipientsLocked;
        boolean z14;
        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
            Slog.v("BroadcastQueue", "processNextBroadcast [" + this.mQueueName + "]: " + this.mParallelBroadcasts.size() + " parallel broadcasts; " + this.mDispatcher.describeStateLocked());
        }
        this.mService.updateCpuStats();
        boolean z15 = false;
        if (z) {
            this.mBroadcastsScheduled = false;
        }
        int size = this.mParallelBroadcasts.size();
        String string = this.mParallelBroadcasts.toString();
        while (true) {
            i = 1;
            if (this.mParallelBroadcasts.size() <= 0) {
                break;
            }
            BroadcastRecord broadcastRecordRemove = this.mParallelBroadcasts.remove(0);
            broadcastRecordRemove.dispatchTime = SystemClock.uptimeMillis();
            broadcastRecordRemove.dispatchClockTime = System.currentTimeMillis();
            if (Trace.isTagEnabled(64L)) {
                Trace.asyncTraceEnd(64L, createBroadcastTraceTitle(broadcastRecordRemove, 0), System.identityHashCode(broadcastRecordRemove));
                Trace.asyncTraceBegin(64L, createBroadcastTraceTitle(broadcastRecordRemove, 1), System.identityHashCode(broadcastRecordRemove));
            }
            int size2 = broadcastRecordRemove.receivers.size();
            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                Slog.v("BroadcastQueue", "Processing parallel broadcast [" + this.mQueueName + "] " + broadcastRecordRemove);
            }
            for (int i7 = 0; i7 < size2; i7++) {
                Object obj2 = broadcastRecordRemove.receivers.get(i7);
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                    Slog.v("BroadcastQueue", "Delivering non-ordered on [" + this.mQueueName + "] to registered " + obj2 + ": " + broadcastRecordRemove);
                }
                deliverToRegisteredReceiverLocked(broadcastRecordRemove, (BroadcastFilter) obj2, false, i7);
            }
            addBroadcastToHistoryLocked(broadcastRecordRemove);
            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                Slog.v("BroadcastQueue", "Done with parallel broadcast [" + this.mQueueName + "] " + broadcastRecordRemove);
            }
        }
        if ((ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT || ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD) && size != 0) {
            Slog.d("BroadcastQueue", "Done with parallel broadcast [" + this.mQueueName + "] " + string);
        }
        if (this.mPendingBroadcast != null) {
            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                Slog.v("BroadcastQueue", "processNextBroadcast [" + this.mQueueName + "]: waiting for " + this.mPendingBroadcast.curApp);
            }
            if (this.mPendingBroadcast.curApp.pid <= 0) {
                ProcessRecord processRecord = (ProcessRecord) this.mService.mProcessList.mProcessNames.get(this.mPendingBroadcast.curApp.processName, this.mPendingBroadcast.curApp.uid);
                z14 = processRecord == null || !processRecord.pendingStart;
            } else {
                synchronized (this.mService.mPidsSelfLocked) {
                    ProcessRecord processRecord2 = this.mService.mPidsSelfLocked.get(this.mPendingBroadcast.curApp.pid);
                    z14 = processRecord2 == null || processRecord2.isCrashing();
                }
            }
            if (!z14) {
                return;
            }
            Slog.w("BroadcastQueue", "pending app  [" + this.mQueueName + "]" + this.mPendingBroadcast.curApp + " died before responding to broadcast");
            BroadcastRecord broadcastRecord3 = this.mPendingBroadcast;
            broadcastRecord3.state = 0;
            broadcastRecord3.nextReceiver = this.mPendingBroadcastRecvIndex;
            this.mPendingBroadcast = null;
        }
        boolean z16 = false;
        while (true) {
            long jUptimeMillis2 = SystemClock.uptimeMillis();
            BroadcastRecord nextBroadcastLocked = this.mDispatcher.getNextBroadcastLocked(jUptimeMillis2);
            if (nextBroadcastLocked == null) {
                this.mDispatcher.scheduleDeferralCheckLocked(z15);
                this.mService.scheduleAppGcsLocked();
                if (z16) {
                    this.mService.updateOomAdjLocked("updateOomAdj_startReceiver");
                }
                if (this.mService.mUserController.mBootCompleted && this.mLogLatencyMetrics) {
                    this.mLogLatencyMetrics = z15;
                    return;
                }
                return;
            }
            ?? size3 = nextBroadcastLocked.receivers != null ? nextBroadcastLocked.receivers.size() : z15;
            if (!this.mService.mProcessesReady || nextBroadcastLocked.timeoutExempt || nextBroadcastLocked.dispatchTime <= 0 || size3 <= 0) {
                i2 = size;
            } else {
                i2 = size;
                if (jUptimeMillis2 > nextBroadcastLocked.dispatchTime + (this.mConstants.TIMEOUT * 2 * (size3 == true ? 1L : 0L))) {
                    Slog.w("BroadcastQueue", "Hung broadcast [" + this.mQueueName + "] discarded after timeout failure: now=" + jUptimeMillis2 + " dispatchTime=" + nextBroadcastLocked.dispatchTime + " startTime=" + nextBroadcastLocked.receiverTime + " intent=" + nextBroadcastLocked.intent + " numReceivers=" + (size3 == true ? 1 : 0) + " nextReceiver=" + nextBroadcastLocked.nextReceiver + " state=" + nextBroadcastLocked.state);
                    broadcastTimeoutLocked(false);
                    nextBroadcastLocked.state = 0;
                    z3 = true;
                }
                if (nextBroadcastLocked.state != 0) {
                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                        Slog.d("BroadcastQueue", "processNextBroadcast(" + this.mQueueName + ") called when not idle (state=" + nextBroadcastLocked.state + ")");
                        return;
                    }
                    return;
                }
                if (nextBroadcastLocked.receivers != null || nextBroadcastLocked.nextReceiver >= size3 || nextBroadcastLocked.resultAbort || z3) {
                    if (nextBroadcastLocked.resultTo == null) {
                        i3 = size3 == true ? 1 : 0;
                        broadcastRecord = nextBroadcastLocked;
                        iIntentReceiver = null;
                        j = 64;
                    } else {
                        if (nextBroadcastLocked.splitToken != 0) {
                            i4 = this.mSplitRefcounts.get(nextBroadcastLocked.splitToken) - i;
                            if (i4 == 0) {
                                if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                                    Slog.i("BroadcastQueue", "Sending broadcast completion for split token " + nextBroadcastLocked.splitToken + " : " + nextBroadcastLocked.intent.getAction());
                                }
                                this.mSplitRefcounts.delete(nextBroadcastLocked.splitToken);
                                z5 = true;
                            } else {
                                if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                                    Slog.i("BroadcastQueue", "Result refcount now " + i4 + " for split token " + nextBroadcastLocked.splitToken + " : " + nextBroadcastLocked.intent.getAction() + " - not sending completion yet");
                                }
                                this.mSplitRefcounts.put(nextBroadcastLocked.splitToken, i4);
                                z5 = false;
                            }
                        } else {
                            z5 = true;
                        }
                        if (!z5) {
                            i3 = size3 == true ? 1 : 0;
                            broadcastRecord = nextBroadcastLocked;
                            iIntentReceiver = null;
                            j = 64;
                        } else {
                            try {
                                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                    try {
                                        Slog.i("BroadcastQueue", "Finishing broadcast [" + this.mQueueName + "] " + nextBroadcastLocked.intent.getAction() + " app=" + nextBroadcastLocked.callerApp);
                                    } catch (RemoteException e) {
                                        e = e;
                                        i3 = size3 == true ? 1 : 0;
                                        broadcastRecord = nextBroadcastLocked;
                                        iIntentReceiver = null;
                                        j = 64;
                                        broadcastRecord.resultTo = iIntentReceiver;
                                        Slog.w("BroadcastQueue", "Failure [" + this.mQueueName + "] sending broadcast result of " + broadcastRecord.intent, e);
                                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                            Slog.v("BroadcastQueue", "Cancelling BROADCAST_TIMEOUT_MSG");
                                        }
                                        cancelBroadcastTimeoutLocked();
                                        jUptimeMillis = SystemClock.uptimeMillis() - broadcastRecord.dispatchTime;
                                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD_TORTUOUS) {
                                            strValueOf = String.valueOf(broadcastRecord.receivers);
                                        } else {
                                            strValueOf = String.valueOf(i3);
                                        }
                                        if (!ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                                            Slog.d("BroadcastQueue", "Finished with ordered broadcast " + broadcastRecord + " receivers:(" + strValueOf + ") take " + jUptimeMillis + "ms in [" + this.mQueueName + "], remains " + (this.mDispatcher.getOrderedBroadcasts().size() - 1));
                                        } else {
                                            Slog.d("BroadcastQueue", "Finished with ordered broadcast " + broadcastRecord + " receivers:(" + strValueOf + ") take " + jUptimeMillis + "ms in [" + this.mQueueName + "], remains " + (this.mDispatcher.getOrderedBroadcasts().size() - 1));
                                        }
                                        addBroadcastToHistoryLocked(broadcastRecord);
                                        if (broadcastRecord.intent.getComponent() != null) {
                                        }
                                        this.mDispatcher.retireBroadcastLocked(broadcastRecord);
                                        broadcastRecord2 = null;
                                        z4 = true;
                                        if (broadcastRecord2 != null) {
                                            i5 = broadcastRecord2.nextReceiver;
                                            broadcastRecord2.nextReceiver = i5 + 1;
                                            broadcastRecord2.receiverTime = SystemClock.uptimeMillis();
                                            if (i5 == 0) {
                                                broadcastRecord2.dispatchTime = broadcastRecord2.receiverTime;
                                                broadcastRecord2.dispatchClockTime = System.currentTimeMillis();
                                                if (this.mLogLatencyMetrics) {
                                                    StatsLog.write(142, broadcastRecord2.dispatchClockTime - broadcastRecord2.enqueueClockTime);
                                                }
                                                if (Trace.isTagEnabled(j)) {
                                                    long j3 = j;
                                                    Trace.asyncTraceEnd(j3, createBroadcastTraceTitle(broadcastRecord2, 0), System.identityHashCode(broadcastRecord2));
                                                    Trace.asyncTraceBegin(j3, createBroadcastTraceTitle(broadcastRecord2, 1), System.identityHashCode(broadcastRecord2));
                                                }
                                                if (ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                                                    Slog.v("BroadcastQueue", "Processing ordered broadcast [" + this.mQueueName + "] " + broadcastRecord2);
                                                }
                                            }
                                            if (!this.mPendingBroadcastTimeoutMessage) {
                                                j2 = broadcastRecord2.receiverTime + this.mConstants.TIMEOUT;
                                                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                                    Slog.v("BroadcastQueue", "Submitting BROADCAST_TIMEOUT_MSG [" + this.mQueueName + "] for " + broadcastRecord2 + " at " + j2);
                                                }
                                                setBroadcastTimeoutLocked(j2);
                                            }
                                            broadcastOptions = broadcastRecord2.options;
                                            obj = broadcastRecord2.receivers.get(i5);
                                            if (obj instanceof BroadcastFilter) {
                                                broadcastFilter = (BroadcastFilter) obj;
                                                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                                    Slog.v("BroadcastQueue", "Delivering ordered [" + this.mQueueName + "] to registered " + broadcastFilter + ": " + broadcastRecord2);
                                                }
                                                deliverToRegisteredReceiverLocked(broadcastRecord2, broadcastFilter, broadcastRecord2.ordered, i5);
                                                if (broadcastRecord2.receiver != null) {
                                                }
                                                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                                    Slog.v("BroadcastQueue", "Quick finishing [" + this.mQueueName + "]: ordered=" + broadcastRecord2.ordered + " receiver=" + broadcastRecord2.receiver);
                                                }
                                                broadcastRecord2.state = 0;
                                                scheduleBroadcastsLocked();
                                                return;
                                            }
                                            resolveInfo = (ResolveInfo) obj;
                                            componentName = new ComponentName(resolveInfo.activityInfo.applicationInfo.packageName, resolveInfo.activityInfo.name);
                                            z6 = false;
                                            if (broadcastOptions != null) {
                                                if (ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD) {
                                                    Slog.d("BroadcastQueue", "SdkVersion is not ok : (" + componentName + ") skip");
                                                }
                                                z6 = true;
                                            }
                                            if (!z6) {
                                                Slog.w("BroadcastQueue", "Association not allowed: broadcasting " + broadcastRecord2.intent.toString() + " from " + broadcastRecord2.callerPackage + " (pid=" + broadcastRecord2.callingPid + ", uid=" + broadcastRecord2.callingUid + ") to " + componentName.flattenToShortString());
                                                z6 = true;
                                            }
                                            if (!z6) {
                                                z12 = !this.mService.mIntentFirewall.checkBroadcast(broadcastRecord2.intent, broadcastRecord2.callingUid, broadcastRecord2.callingPid, broadcastRecord2.resolvedType, resolveInfo.activityInfo.applicationInfo.uid);
                                                if (z12) {
                                                    Slog.w("BroadcastQueue", "Firewall blocked: broadcasting " + broadcastRecord2.intent.toString() + " from " + broadcastRecord2.callerPackage + " (pid=" + broadcastRecord2.callingPid + ", uid=" + broadcastRecord2.callingUid + ") to " + componentName.flattenToShortString());
                                                }
                                                if (z12) {
                                                    z13 = true;
                                                } else {
                                                    z13 = true;
                                                }
                                                z6 = z13;
                                            }
                                            ActivityManagerService activityManagerService = this.mService;
                                            int iCheckComponentPermission = ActivityManagerService.checkComponentPermission(resolveInfo.activityInfo.permission, broadcastRecord2.callingPid, broadcastRecord2.callingUid, resolveInfo.activityInfo.applicationInfo.uid, resolveInfo.activityInfo.exported);
                                            int i8 = -1;
                                            if (z6) {
                                                if (z6) {
                                                    z7 = z6;
                                                } else {
                                                    z7 = z6;
                                                }
                                            } else if (z6) {
                                                z7 = z6;
                                            } else {
                                                z7 = z6;
                                            }
                                            if (z7) {
                                            }
                                            if (!z7) {
                                                Slog.w("BroadcastQueue", "Appop Denial: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString() + " requires appop " + AppOpsManager.opToName(broadcastRecord2.appOp) + " due to sender " + broadcastRecord2.callerPackage + " (uid " + broadcastRecord2.callingUid + ")");
                                                z7 = true;
                                            }
                                            try {
                                                zIsSingleton = this.mService.isSingleton(resolveInfo.activityInfo.processName, resolveInfo.activityInfo.applicationInfo, resolveInfo.activityInfo.name, resolveInfo.activityInfo.flags);
                                            } catch (SecurityException e2) {
                                                Slog.w("BroadcastQueue", e2.getMessage());
                                                z7 = true;
                                                zIsSingleton = false;
                                            }
                                            if ((resolveInfo.activityInfo.flags & 1073741824) != 0) {
                                                Slog.w("BroadcastQueue", "Permission Denial: Receiver " + componentName.flattenToShortString() + " requests FLAG_SINGLE_USER, but app does not hold android.permission.INTERACT_ACROSS_USERS");
                                                z7 = true;
                                            }
                                            if (!z7) {
                                                Slog.w("BroadcastQueue", "Instant App Denial: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString() + " due to sender " + broadcastRecord2.callerPackage + " (uid " + broadcastRecord2.callingUid + ") Instant Apps do not support manifest receivers");
                                                z7 = true;
                                            }
                                            if (!z7) {
                                                Slog.w("BroadcastQueue", "Instant App Denial: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString() + " requires receiver have visibleToInstantApps set due to sender " + broadcastRecord2.callerPackage + " (uid " + broadcastRecord2.callingUid + ")");
                                                z7 = true;
                                            }
                                            if (broadcastRecord2.curApp != null) {
                                                Slog.w("BroadcastQueue", "Skipping deliver ordered [" + this.mQueueName + "] " + broadcastRecord2 + " to " + broadcastRecord2.curApp + ": process crashing");
                                                z7 = true;
                                            }
                                            if (!z7) {
                                                zIsPackageAvailable = false;
                                                try {
                                                    zIsPackageAvailable = AppGlobals.getPackageManager().isPackageAvailable(resolveInfo.activityInfo.packageName, UserHandle.getUserId(resolveInfo.activityInfo.applicationInfo.uid));
                                                } catch (Exception e3) {
                                                    Slog.w("BroadcastQueue", "Exception getting recipient info for " + resolveInfo.activityInfo.packageName, e3);
                                                }
                                                if (!zIsPackageAvailable) {
                                                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                                        Slog.d("BroadcastQueue", "Skipping delivery to " + resolveInfo.activityInfo.packageName + " / " + resolveInfo.activityInfo.applicationInfo.uid + " : package no longer available");
                                                    } else {
                                                        Slog.d("BroadcastQueue", "Skipping delivery to " + resolveInfo.activityInfo.packageName + " / " + resolveInfo.activityInfo.applicationInfo.uid + " : package no longer available");
                                                    }
                                                    z7 = true;
                                                }
                                            }
                                            if (!z7) {
                                                z7 = true;
                                            }
                                            i6 = resolveInfo.activityInfo.applicationInfo.uid;
                                            if (broadcastRecord2.callingUid != 1000) {
                                                resolveInfo.activityInfo = this.mService.getActivityInfoForUser(resolveInfo.activityInfo, 0);
                                            }
                                            str = resolveInfo.activityInfo.processName;
                                            processRecordLocked = this.mService.getProcessRecordLocked(str, resolveInfo.activityInfo.applicationInfo.uid, false);
                                            if (z7) {
                                                z8 = z7;
                                            } else {
                                                z8 = z7;
                                                appStartModeLocked = this.mService.getAppStartModeLocked(resolveInfo.activityInfo.applicationInfo.uid, resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.applicationInfo.targetSdkVersion, -1, true, false, false);
                                                if (appStartModeLocked != 0) {
                                                    if (appStartModeLocked == 3) {
                                                        Slog.w("BroadcastQueue", "Background execution disabled: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString());
                                                        z9 = true;
                                                    } else {
                                                        if ((broadcastRecord2.intent.getFlags() & DumpState.DUMP_VOLUMES) == 0) {
                                                        }
                                                        this.mService.addBackgroundCheckViolationLocked(broadcastRecord2.intent.getAction(), componentName.getPackageName());
                                                        Slog.w("BroadcastQueue", "Background execution not allowed: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString());
                                                        z9 = true;
                                                    }
                                                }
                                                if (z9) {
                                                    z10 = z9;
                                                } else {
                                                    z10 = z9;
                                                }
                                                if (z10) {
                                                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                                        Slog.d("BroadcastQueue", "Skipping delivery of ordered [" + this.mQueueName + "] " + broadcastRecord2 + " for reason described above");
                                                    } else {
                                                        Slog.d("BroadcastQueue", "Skipping delivery of ordered [" + this.mQueueName + "] " + broadcastRecord2 + " for reason described above");
                                                    }
                                                    broadcastRecord2.delivery[i5] = 2;
                                                    broadcastRecord2.receiver = null;
                                                    broadcastRecord2.curFilter = null;
                                                    broadcastRecord2.state = 0;
                                                    broadcastRecord2.manifestSkipCount++;
                                                    scheduleBroadcastsLocked();
                                                    return;
                                                }
                                                broadcastRecord2.manifestCount++;
                                                broadcastRecord2.delivery[i5] = 1;
                                                broadcastRecord2.state = 1;
                                                broadcastRecord2.curComponent = componentName;
                                                broadcastRecord2.curReceiver = resolveInfo.activityInfo;
                                                if (ActivityManagerDebugConfig.DEBUG_MU) {
                                                    Slog.v(TAG_MU, "Updated broadcast record activity info for secondary user, " + resolveInfo.activityInfo + ", callingUid = " + broadcastRecord2.callingUid + ", uid = " + i6);
                                                }
                                                if (broadcastOptions != null) {
                                                    scheduleTempWhitelistLocked(i6, broadcastOptions.getTemporaryAppWhitelistDuration(), broadcastRecord2);
                                                }
                                                try {
                                                    AppGlobals.getPackageManager().setPackageStoppedState(broadcastRecord2.curComponent.getPackageName(), false, broadcastRecord2.userId);
                                                } catch (RemoteException e4) {
                                                } catch (IllegalArgumentException e5) {
                                                    Slog.w("BroadcastQueue", "Failed trying to unstop package " + broadcastRecord2.curComponent.getPackageName() + ": " + e5);
                                                }
                                                if (processRecordLocked != null) {
                                                    str = str;
                                                    i6 = i6;
                                                } else {
                                                    str = str;
                                                    i6 = i6;
                                                }
                                                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                                    StringBuilder sb = new StringBuilder();
                                                    sb.append("Need to start app [");
                                                    sb.append(this.mQueueName);
                                                    sb.append("] ");
                                                    str2 = str;
                                                    sb.append(str2);
                                                    sb.append(" for broadcast ");
                                                    sb.append(broadcastRecord2);
                                                    Slog.v("BroadcastQueue", sb.toString());
                                                } else {
                                                    str2 = str;
                                                }
                                                ActivityManagerService activityManagerService2 = this.mService;
                                                ApplicationInfo applicationInfo = resolveInfo.activityInfo.applicationInfo;
                                                int flags = broadcastRecord2.intent.getFlags() | 4;
                                                HostingRecord hostingRecord = new HostingRecord(INetd.IF_FLAG_BROADCAST, broadcastRecord2.curComponent);
                                                if ((broadcastRecord2.intent.getFlags() & DumpState.DUMP_APEX) != 0) {
                                                    z11 = true;
                                                } else {
                                                    z11 = false;
                                                }
                                                processRecordStartProcessLocked = activityManagerService2.startProcessLocked(str2, applicationInfo, true, flags, hostingRecord, z11, false, false);
                                                broadcastRecord2.curApp = processRecordStartProcessLocked;
                                                if (processRecordStartProcessLocked != null) {
                                                    maybeAddAllowBackgroundActivityStartsToken(broadcastRecord2.curApp, broadcastRecord2);
                                                    this.mPendingBroadcast = broadcastRecord2;
                                                    this.mPendingBroadcastRecvIndex = i5;
                                                    return;
                                                }
                                                Slog.w("BroadcastQueue", "Unable to launch app " + resolveInfo.activityInfo.applicationInfo.packageName + SliceClientPermissions.SliceAuthority.DELIMITER + i6 + " for broadcast " + broadcastRecord2.intent + ": process is bad");
                                                logBroadcastReceiverDiscardLocked(broadcastRecord2);
                                                finishReceiverLocked(broadcastRecord2, broadcastRecord2.resultCode, broadcastRecord2.resultData, broadcastRecord2.resultExtras, broadcastRecord2.resultAbort, false);
                                                scheduleBroadcastsLocked();
                                                broadcastRecord2.state = 0;
                                                return;
                                            }
                                            z9 = z8;
                                            if (z9) {
                                                z10 = z9;
                                            } else {
                                                z10 = z9;
                                            }
                                            if (z10) {
                                                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                                    Slog.d("BroadcastQueue", "Skipping delivery of ordered [" + this.mQueueName + "] " + broadcastRecord2 + " for reason described above");
                                                } else {
                                                    Slog.d("BroadcastQueue", "Skipping delivery of ordered [" + this.mQueueName + "] " + broadcastRecord2 + " for reason described above");
                                                }
                                                broadcastRecord2.delivery[i5] = 2;
                                                broadcastRecord2.receiver = null;
                                                broadcastRecord2.curFilter = null;
                                                broadcastRecord2.state = 0;
                                                broadcastRecord2.manifestSkipCount++;
                                                scheduleBroadcastsLocked();
                                                return;
                                            }
                                            broadcastRecord2.manifestCount++;
                                            broadcastRecord2.delivery[i5] = 1;
                                            broadcastRecord2.state = 1;
                                            broadcastRecord2.curComponent = componentName;
                                            broadcastRecord2.curReceiver = resolveInfo.activityInfo;
                                            if (ActivityManagerDebugConfig.DEBUG_MU) {
                                                Slog.v(TAG_MU, "Updated broadcast record activity info for secondary user, " + resolveInfo.activityInfo + ", callingUid = " + broadcastRecord2.callingUid + ", uid = " + i6);
                                            }
                                            if (broadcastOptions != null) {
                                                scheduleTempWhitelistLocked(i6, broadcastOptions.getTemporaryAppWhitelistDuration(), broadcastRecord2);
                                            }
                                            AppGlobals.getPackageManager().setPackageStoppedState(broadcastRecord2.curComponent.getPackageName(), false, broadcastRecord2.userId);
                                            if (processRecordLocked != null) {
                                                str = str;
                                                i6 = i6;
                                            } else {
                                                str = str;
                                                i6 = i6;
                                            }
                                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                                StringBuilder sb2 = new StringBuilder();
                                                sb2.append("Need to start app [");
                                                sb2.append(this.mQueueName);
                                                sb2.append("] ");
                                                str2 = str;
                                                sb2.append(str2);
                                                sb2.append(" for broadcast ");
                                                sb2.append(broadcastRecord2);
                                                Slog.v("BroadcastQueue", sb2.toString());
                                            } else {
                                                str2 = str;
                                            }
                                            ActivityManagerService activityManagerService3 = this.mService;
                                            ApplicationInfo applicationInfo2 = resolveInfo.activityInfo.applicationInfo;
                                            int flags2 = broadcastRecord2.intent.getFlags() | 4;
                                            HostingRecord hostingRecord2 = new HostingRecord(INetd.IF_FLAG_BROADCAST, broadcastRecord2.curComponent);
                                            if ((broadcastRecord2.intent.getFlags() & DumpState.DUMP_APEX) != 0) {
                                                z11 = true;
                                            } else {
                                                z11 = false;
                                            }
                                            processRecordStartProcessLocked = activityManagerService3.startProcessLocked(str2, applicationInfo2, true, flags2, hostingRecord2, z11, false, false);
                                            broadcastRecord2.curApp = processRecordStartProcessLocked;
                                            if (processRecordStartProcessLocked != null) {
                                                maybeAddAllowBackgroundActivityStartsToken(broadcastRecord2.curApp, broadcastRecord2);
                                                this.mPendingBroadcast = broadcastRecord2;
                                                this.mPendingBroadcastRecvIndex = i5;
                                                return;
                                            }
                                            Slog.w("BroadcastQueue", "Unable to launch app " + resolveInfo.activityInfo.applicationInfo.packageName + SliceClientPermissions.SliceAuthority.DELIMITER + i6 + " for broadcast " + broadcastRecord2.intent + ": process is bad");
                                            logBroadcastReceiverDiscardLocked(broadcastRecord2);
                                            finishReceiverLocked(broadcastRecord2, broadcastRecord2.resultCode, broadcastRecord2.resultData, broadcastRecord2.resultExtras, broadcastRecord2.resultAbort, false);
                                            scheduleBroadcastsLocked();
                                            broadcastRecord2.state = 0;
                                            return;
                                        }
                                        z15 = false;
                                        i = 1;
                                        size = i2;
                                        z16 = z4;
                                    }
                                }
                                ProcessRecord processRecord3 = nextBroadcastLocked.callerApp;
                                IIntentReceiver iIntentReceiver2 = nextBroadcastLocked.resultTo;
                                Intent intent = new Intent(nextBroadcastLocked.intent);
                                int i9 = nextBroadcastLocked.resultCode;
                                String str3 = nextBroadcastLocked.resultData;
                                Bundle bundle = nextBroadcastLocked.resultExtras;
                                int i10 = nextBroadcastLocked.userId;
                                i3 = size3 == true ? 1 : 0;
                                broadcastRecord = nextBroadcastLocked;
                                iIntentReceiver = null;
                                j = 64;
                                try {
                                    performReceiveLocked(processRecord3, iIntentReceiver2, intent, i9, str3, bundle, false, false, i10);
                                    broadcastRecord.resultTo = null;
                                } catch (RemoteException e6) {
                                    e = e6;
                                    broadcastRecord.resultTo = iIntentReceiver;
                                    Slog.w("BroadcastQueue", "Failure [" + this.mQueueName + "] sending broadcast result of " + broadcastRecord.intent, e);
                                }
                            } catch (RemoteException e7) {
                                e = e7;
                                i3 = size3 == true ? 1 : 0;
                                broadcastRecord = nextBroadcastLocked;
                                iIntentReceiver = null;
                                j = 64;
                            }
                        }
                    }
                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                        Slog.v("BroadcastQueue", "Cancelling BROADCAST_TIMEOUT_MSG");
                    }
                    cancelBroadcastTimeoutLocked();
                    jUptimeMillis = SystemClock.uptimeMillis() - broadcastRecord.dispatchTime;
                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD_TORTUOUS) {
                        strValueOf = String.valueOf(broadcastRecord.receivers);
                    } else {
                        strValueOf = String.valueOf(i3);
                    }
                    if (!ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT || ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD) {
                        Slog.d("BroadcastQueue", "Finished with ordered broadcast " + broadcastRecord + " receivers:(" + strValueOf + ") take " + jUptimeMillis + "ms in [" + this.mQueueName + "], remains " + (this.mDispatcher.getOrderedBroadcasts().size() - 1));
                    }
                    addBroadcastToHistoryLocked(broadcastRecord);
                    if (broadcastRecord.intent.getComponent() != null && broadcastRecord.intent.getPackage() == null && (broadcastRecord.intent.getFlags() & 1073741824) == 0) {
                        this.mService.addBroadcastStatLocked(broadcastRecord.intent.getAction(), broadcastRecord.callerPackage, broadcastRecord.manifestCount, broadcastRecord.manifestSkipCount, broadcastRecord.finishTime - broadcastRecord.dispatchTime);
                    }
                    this.mDispatcher.retireBroadcastLocked(broadcastRecord);
                    broadcastRecord2 = null;
                    z4 = true;
                } else if (!nextBroadcastLocked.deferred) {
                    int receiverUid = nextBroadcastLocked.getReceiverUid(nextBroadcastLocked.receivers.get(nextBroadcastLocked.nextReceiver));
                    if (this.mDispatcher.isDeferringLocked(receiverUid)) {
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                            Slog.i("BroadcastQueue", "Next receiver in " + nextBroadcastLocked + " uid " + receiverUid + " at " + nextBroadcastLocked.nextReceiver + " is under deferral");
                        }
                        if (nextBroadcastLocked.nextReceiver + i == size3) {
                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                                Slog.i("BroadcastQueue", "Sole receiver of " + nextBroadcastLocked + " is under deferral; setting aside and proceeding");
                            }
                            broadcastRecordSplitRecipientsLocked = nextBroadcastLocked;
                            this.mDispatcher.retireBroadcastLocked(nextBroadcastLocked);
                        } else {
                            broadcastRecordSplitRecipientsLocked = nextBroadcastLocked.splitRecipientsLocked(receiverUid, nextBroadcastLocked.nextReceiver);
                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                                Slog.i("BroadcastQueue", "Post split:");
                                Slog.i("BroadcastQueue", "Original broadcast receivers:");
                                for (int i11 = 0; i11 < nextBroadcastLocked.receivers.size(); i11++) {
                                    Slog.i("BroadcastQueue", "  " + nextBroadcastLocked.receivers.get(i11));
                                }
                                Slog.i("BroadcastQueue", "Split receivers:");
                                for (int i12 = 0; i12 < broadcastRecordSplitRecipientsLocked.receivers.size(); i12++) {
                                    Slog.i("BroadcastQueue", "  " + broadcastRecordSplitRecipientsLocked.receivers.get(i12));
                                }
                            }
                            if (nextBroadcastLocked.resultTo != null) {
                                int i13 = nextBroadcastLocked.splitToken;
                                if (i13 == 0) {
                                    int iNextSplitTokenLocked = nextSplitTokenLocked();
                                    broadcastRecordSplitRecipientsLocked.splitToken = iNextSplitTokenLocked;
                                    nextBroadcastLocked.splitToken = iNextSplitTokenLocked;
                                    this.mSplitRefcounts.put(nextBroadcastLocked.splitToken, 2);
                                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                                        Slog.i("BroadcastQueue", "Broadcast needs split refcount; using new token " + nextBroadcastLocked.splitToken);
                                    }
                                } else {
                                    int i14 = this.mSplitRefcounts.get(i13);
                                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL && i14 == 0) {
                                        Slog.wtf("BroadcastQueue", "Split refcount is zero with token for " + nextBroadcastLocked);
                                    }
                                    this.mSplitRefcounts.put(i13, i14 + 1);
                                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                                        Slog.i("BroadcastQueue", "New split count for token " + i13 + " is " + (i14 + 1));
                                    }
                                }
                            }
                        }
                        this.mDispatcher.addDeferredBroadcast(receiverUid, broadcastRecordSplitRecipientsLocked);
                        broadcastRecord2 = null;
                        z4 = true;
                        iIntentReceiver = null;
                        j = 64;
                    } else {
                        broadcastRecord2 = nextBroadcastLocked;
                        iIntentReceiver = null;
                        j = 64;
                        z4 = z16;
                    }
                } else {
                    broadcastRecord2 = nextBroadcastLocked;
                    iIntentReceiver = null;
                    j = 64;
                    z4 = z16;
                }
                if (broadcastRecord2 != null) {
                    i5 = broadcastRecord2.nextReceiver;
                    broadcastRecord2.nextReceiver = i5 + 1;
                    broadcastRecord2.receiverTime = SystemClock.uptimeMillis();
                    if (i5 == 0) {
                        broadcastRecord2.dispatchTime = broadcastRecord2.receiverTime;
                        broadcastRecord2.dispatchClockTime = System.currentTimeMillis();
                        if (this.mLogLatencyMetrics) {
                            StatsLog.write(142, broadcastRecord2.dispatchClockTime - broadcastRecord2.enqueueClockTime);
                        }
                        if (Trace.isTagEnabled(j)) {
                            long j4 = j;
                            Trace.asyncTraceEnd(j4, createBroadcastTraceTitle(broadcastRecord2, 0), System.identityHashCode(broadcastRecord2));
                            Trace.asyncTraceBegin(j4, createBroadcastTraceTitle(broadcastRecord2, 1), System.identityHashCode(broadcastRecord2));
                        }
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                            Slog.v("BroadcastQueue", "Processing ordered broadcast [" + this.mQueueName + "] " + broadcastRecord2);
                        }
                    }
                    if (!this.mPendingBroadcastTimeoutMessage) {
                        j2 = broadcastRecord2.receiverTime + this.mConstants.TIMEOUT;
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                            Slog.v("BroadcastQueue", "Submitting BROADCAST_TIMEOUT_MSG [" + this.mQueueName + "] for " + broadcastRecord2 + " at " + j2);
                        }
                        setBroadcastTimeoutLocked(j2);
                    }
                    broadcastOptions = broadcastRecord2.options;
                    obj = broadcastRecord2.receivers.get(i5);
                    if (obj instanceof BroadcastFilter) {
                        broadcastFilter = (BroadcastFilter) obj;
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                            Slog.v("BroadcastQueue", "Delivering ordered [" + this.mQueueName + "] to registered " + broadcastFilter + ": " + broadcastRecord2);
                        }
                        deliverToRegisteredReceiverLocked(broadcastRecord2, broadcastFilter, broadcastRecord2.ordered, i5);
                        if (broadcastRecord2.receiver != null || !broadcastRecord2.ordered) {
                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                Slog.v("BroadcastQueue", "Quick finishing [" + this.mQueueName + "]: ordered=" + broadcastRecord2.ordered + " receiver=" + broadcastRecord2.receiver);
                            }
                            broadcastRecord2.state = 0;
                            scheduleBroadcastsLocked();
                            return;
                        }
                        if (broadcastFilter.receiverList != null) {
                            maybeAddAllowBackgroundActivityStartsToken(broadcastFilter.receiverList.app, broadcastRecord2);
                        }
                        if (broadcastOptions != null && broadcastOptions.getTemporaryAppWhitelistDuration() > 0) {
                            scheduleTempWhitelistLocked(broadcastFilter.owningUid, broadcastOptions.getTemporaryAppWhitelistDuration(), broadcastRecord2);
                            return;
                        }
                        return;
                    }
                    resolveInfo = (ResolveInfo) obj;
                    componentName = new ComponentName(resolveInfo.activityInfo.applicationInfo.packageName, resolveInfo.activityInfo.name);
                    z6 = false;
                    if (broadcastOptions != null && (resolveInfo.activityInfo.applicationInfo.targetSdkVersion < broadcastOptions.getMinManifestReceiverApiLevel() || resolveInfo.activityInfo.applicationInfo.targetSdkVersion > broadcastOptions.getMaxManifestReceiverApiLevel())) {
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD) {
                            Slog.d("BroadcastQueue", "SdkVersion is not ok : (" + componentName + ") skip");
                        }
                        z6 = true;
                    }
                    if (!z6 && !this.mService.validateAssociationAllowedLocked(broadcastRecord2.callerPackage, broadcastRecord2.callingUid, componentName.getPackageName(), resolveInfo.activityInfo.applicationInfo.uid)) {
                        Slog.w("BroadcastQueue", "Association not allowed: broadcasting " + broadcastRecord2.intent.toString() + " from " + broadcastRecord2.callerPackage + " (pid=" + broadcastRecord2.callingPid + ", uid=" + broadcastRecord2.callingUid + ") to " + componentName.flattenToShortString());
                        z6 = true;
                    }
                    if (!z6) {
                        z12 = !this.mService.mIntentFirewall.checkBroadcast(broadcastRecord2.intent, broadcastRecord2.callingUid, broadcastRecord2.callingPid, broadcastRecord2.resolvedType, resolveInfo.activityInfo.applicationInfo.uid);
                        if (z12) {
                            Slog.w("BroadcastQueue", "Firewall blocked: broadcasting " + broadcastRecord2.intent.toString() + " from " + broadcastRecord2.callerPackage + " (pid=" + broadcastRecord2.callingPid + ", uid=" + broadcastRecord2.callingUid + ") to " + componentName.flattenToShortString());
                        }
                        if (z12 || !this.mService.judgeStartAllowLocked(broadcastRecord2.intent, resolveInfo.activityInfo.applicationInfo.packageName, resolveInfo.activityInfo.applicationInfo.uid, broadcastRecord2.callingUid, broadcastRecord2.callerPackage, "send-broadcast")) {
                            z13 = true;
                        } else {
                            z13 = false;
                        }
                        z6 = z13;
                    }
                    ActivityManagerService activityManagerService4 = this.mService;
                    int iCheckComponentPermission2 = ActivityManagerService.checkComponentPermission(resolveInfo.activityInfo.permission, broadcastRecord2.callingPid, broadcastRecord2.callingUid, resolveInfo.activityInfo.applicationInfo.uid, resolveInfo.activityInfo.exported);
                    int i15 = -1;
                    if (z6 && iCheckComponentPermission2 != 0) {
                        if (!resolveInfo.activityInfo.exported) {
                            Slog.w("BroadcastQueue", "Permission Denial: broadcasting " + broadcastRecord2.intent.toString() + " from " + broadcastRecord2.callerPackage + " (pid=" + broadcastRecord2.callingPid + ", uid=" + broadcastRecord2.callingUid + ") is not exported from uid " + resolveInfo.activityInfo.applicationInfo.uid + " due to receiver " + componentName.flattenToShortString());
                        } else {
                            Slog.w("BroadcastQueue", "Permission Denial: broadcasting " + broadcastRecord2.intent.toString() + " from " + broadcastRecord2.callerPackage + " (pid=" + broadcastRecord2.callingPid + ", uid=" + broadcastRecord2.callingUid + ") requires " + resolveInfo.activityInfo.permission + " due to receiver " + componentName.flattenToShortString());
                        }
                        z7 = true;
                    } else if (z6 && resolveInfo.activityInfo.permission != null && (iPermissionToOpCode = AppOpsManager.permissionToOpCode(resolveInfo.activityInfo.permission)) != -1 && this.mService.mAppOpsService.noteOperation(iPermissionToOpCode, broadcastRecord2.callingUid, broadcastRecord2.callerPackage) != 0) {
                        Slog.w("BroadcastQueue", "Appop Denial: broadcasting " + broadcastRecord2.intent.toString() + " from " + broadcastRecord2.callerPackage + " (pid=" + broadcastRecord2.callingPid + ", uid=" + broadcastRecord2.callingUid + ") requires appop " + AppOpsManager.permissionToOp(resolveInfo.activityInfo.permission) + " due to registered receiver " + componentName.flattenToShortString());
                        z7 = true;
                    } else {
                        z7 = z6;
                    }
                    if (z7 && resolveInfo.activityInfo.applicationInfo.uid != 1000 && broadcastRecord2.requiredPermissions != null && broadcastRecord2.requiredPermissions.length > 0) {
                        int iCheckPermission = iCheckComponentPermission2;
                        int i16 = 0;
                        while (i16 < broadcastRecord2.requiredPermissions.length) {
                            String str4 = broadcastRecord2.requiredPermissions[i16];
                            try {
                                iCheckPermission = AppGlobals.getPackageManager().checkPermission(str4, resolveInfo.activityInfo.applicationInfo.packageName, UserHandle.getUserId(resolveInfo.activityInfo.applicationInfo.uid));
                            } catch (RemoteException e8) {
                                iCheckPermission = -1;
                            }
                            if (iCheckPermission != 0) {
                                Slog.w("BroadcastQueue", "Permission Denial: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString() + " requires " + str4 + " due to sender " + broadcastRecord2.callerPackage + " (uid " + broadcastRecord2.callingUid + ")");
                                z7 = true;
                                break;
                            }
                            int iPermissionToOpCode2 = AppOpsManager.permissionToOpCode(str4);
                            if (iPermissionToOpCode2 == i15 || iPermissionToOpCode2 == broadcastRecord2.appOp || this.mService.mAppOpsService.noteOperation(iPermissionToOpCode2, resolveInfo.activityInfo.applicationInfo.uid, resolveInfo.activityInfo.packageName) == 0) {
                                i16++;
                                i15 = -1;
                            } else {
                                Slog.w("BroadcastQueue", "Appop Denial: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString() + " requires appop " + AppOpsManager.permissionToOp(str4) + " due to sender " + broadcastRecord2.callerPackage + " (uid " + broadcastRecord2.callingUid + ")");
                                z7 = true;
                                break;
                            }
                        }
                    }
                    if (!z7 && broadcastRecord2.appOp != -1 && this.mService.mAppOpsService.noteOperation(broadcastRecord2.appOp, resolveInfo.activityInfo.applicationInfo.uid, resolveInfo.activityInfo.packageName) != 0) {
                        Slog.w("BroadcastQueue", "Appop Denial: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString() + " requires appop " + AppOpsManager.opToName(broadcastRecord2.appOp) + " due to sender " + broadcastRecord2.callerPackage + " (uid " + broadcastRecord2.callingUid + ")");
                        z7 = true;
                    }
                    zIsSingleton = this.mService.isSingleton(resolveInfo.activityInfo.processName, resolveInfo.activityInfo.applicationInfo, resolveInfo.activityInfo.name, resolveInfo.activityInfo.flags);
                    if ((resolveInfo.activityInfo.flags & 1073741824) != 0 && ActivityManager.checkUidPermission("android.permission.INTERACT_ACROSS_USERS", resolveInfo.activityInfo.applicationInfo.uid) != 0) {
                        Slog.w("BroadcastQueue", "Permission Denial: Receiver " + componentName.flattenToShortString() + " requests FLAG_SINGLE_USER, but app does not hold android.permission.INTERACT_ACROSS_USERS");
                        z7 = true;
                    }
                    if (!z7 && resolveInfo.activityInfo.applicationInfo.isInstantApp() && broadcastRecord2.callingUid != resolveInfo.activityInfo.applicationInfo.uid) {
                        Slog.w("BroadcastQueue", "Instant App Denial: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString() + " due to sender " + broadcastRecord2.callerPackage + " (uid " + broadcastRecord2.callingUid + ") Instant Apps do not support manifest receivers");
                        z7 = true;
                    }
                    if (!z7 && broadcastRecord2.callerInstantApp && (resolveInfo.activityInfo.flags & DumpState.DUMP_DEXOPT) == 0 && broadcastRecord2.callingUid != resolveInfo.activityInfo.applicationInfo.uid) {
                        Slog.w("BroadcastQueue", "Instant App Denial: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString() + " requires receiver have visibleToInstantApps set due to sender " + broadcastRecord2.callerPackage + " (uid " + broadcastRecord2.callingUid + ")");
                        z7 = true;
                    }
                    if (broadcastRecord2.curApp != null && broadcastRecord2.curApp.isCrashing()) {
                        Slog.w("BroadcastQueue", "Skipping deliver ordered [" + this.mQueueName + "] " + broadcastRecord2 + " to " + broadcastRecord2.curApp + ": process crashing");
                        z7 = true;
                    }
                    if (!z7) {
                        zIsPackageAvailable = false;
                        zIsPackageAvailable = AppGlobals.getPackageManager().isPackageAvailable(resolveInfo.activityInfo.packageName, UserHandle.getUserId(resolveInfo.activityInfo.applicationInfo.uid));
                        if (!zIsPackageAvailable) {
                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST || ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD) {
                                Slog.d("BroadcastQueue", "Skipping delivery to " + resolveInfo.activityInfo.packageName + " / " + resolveInfo.activityInfo.applicationInfo.uid + " : package no longer available");
                            }
                            z7 = true;
                        }
                    }
                    if (!z7 && !requestStartTargetPermissionsReviewIfNeededLocked(broadcastRecord2, resolveInfo.activityInfo.packageName, UserHandle.getUserId(resolveInfo.activityInfo.applicationInfo.uid))) {
                        z7 = true;
                    }
                    i6 = resolveInfo.activityInfo.applicationInfo.uid;
                    if (broadcastRecord2.callingUid != 1000 && zIsSingleton && this.mService.isValidSingletonCall(broadcastRecord2.callingUid, i6)) {
                        resolveInfo.activityInfo = this.mService.getActivityInfoForUser(resolveInfo.activityInfo, 0);
                    }
                    str = resolveInfo.activityInfo.processName;
                    processRecordLocked = this.mService.getProcessRecordLocked(str, resolveInfo.activityInfo.applicationInfo.uid, false);
                    if (z7) {
                        z8 = z7;
                    } else {
                        z8 = z7;
                        appStartModeLocked = this.mService.getAppStartModeLocked(resolveInfo.activityInfo.applicationInfo.uid, resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.applicationInfo.targetSdkVersion, -1, true, false, false);
                        if (appStartModeLocked != 0) {
                            if (appStartModeLocked == 3) {
                                Slog.w("BroadcastQueue", "Background execution disabled: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString());
                                z9 = true;
                            } else if ((broadcastRecord2.intent.getFlags() & DumpState.DUMP_VOLUMES) == 0 || (broadcastRecord2.intent.getComponent() == null && broadcastRecord2.intent.getPackage() == null && (broadcastRecord2.intent.getFlags() & DumpState.DUMP_SERVICE_PERMISSIONS) == 0 && !isSignaturePerm(broadcastRecord2.requiredPermissions))) {
                                this.mService.addBackgroundCheckViolationLocked(broadcastRecord2.intent.getAction(), componentName.getPackageName());
                                Slog.w("BroadcastQueue", "Background execution not allowed: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString());
                                z9 = true;
                            }
                        }
                        if (z9 && !"android.intent.action.ACTION_SHUTDOWN".equals(broadcastRecord2.intent.getAction()) && !this.mService.mUserController.isUserRunning(UserHandle.getUserId(resolveInfo.activityInfo.applicationInfo.uid), 0)) {
                            Slog.w("BroadcastQueue", "Skipping delivery to " + resolveInfo.activityInfo.packageName + " / " + resolveInfo.activityInfo.applicationInfo.uid + " : user is not running");
                            z10 = true;
                        } else {
                            z10 = z9;
                        }
                        if (z10) {
                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST || ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD) {
                                Slog.d("BroadcastQueue", "Skipping delivery of ordered [" + this.mQueueName + "] " + broadcastRecord2 + " for reason described above");
                            }
                            broadcastRecord2.delivery[i5] = 2;
                            broadcastRecord2.receiver = null;
                            broadcastRecord2.curFilter = null;
                            broadcastRecord2.state = 0;
                            broadcastRecord2.manifestSkipCount++;
                            scheduleBroadcastsLocked();
                            return;
                        }
                        broadcastRecord2.manifestCount++;
                        broadcastRecord2.delivery[i5] = 1;
                        broadcastRecord2.state = 1;
                        broadcastRecord2.curComponent = componentName;
                        broadcastRecord2.curReceiver = resolveInfo.activityInfo;
                        if (ActivityManagerDebugConfig.DEBUG_MU && broadcastRecord2.callingUid > 100000) {
                            Slog.v(TAG_MU, "Updated broadcast record activity info for secondary user, " + resolveInfo.activityInfo + ", callingUid = " + broadcastRecord2.callingUid + ", uid = " + i6);
                        }
                        if (broadcastOptions != null && broadcastOptions.getTemporaryAppWhitelistDuration() > 0) {
                            scheduleTempWhitelistLocked(i6, broadcastOptions.getTemporaryAppWhitelistDuration(), broadcastRecord2);
                        }
                        AppGlobals.getPackageManager().setPackageStoppedState(broadcastRecord2.curComponent.getPackageName(), false, broadcastRecord2.userId);
                        if (processRecordLocked != null || processRecordLocked.thread == null || processRecordLocked.killed) {
                            str = str;
                            i6 = i6;
                        } else {
                            try {
                                try {
                                    try {
                                        processRecordLocked.addPackage(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.applicationInfo.longVersionCode, this.mService.mProcessStats);
                                        maybeAddAllowBackgroundActivityStartsToken(processRecordLocked, broadcastRecord2);
                                        try {
                                            processCurBroadcastLocked(broadcastRecord2, processRecordLocked, z2);
                                            return;
                                        } catch (RemoteException e9) {
                                            e = e9;
                                            Slog.w("BroadcastQueue", "Exception when sending broadcast to " + broadcastRecord2.curComponent, e);
                                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                                                StringBuilder sb3 = new StringBuilder();
                                                sb3.append("Need to start app [");
                                                sb3.append(this.mQueueName);
                                                sb3.append("] ");
                                                str2 = str;
                                                sb3.append(str2);
                                                sb3.append(" for broadcast ");
                                                sb3.append(broadcastRecord2);
                                                Slog.v("BroadcastQueue", sb3.toString());
                                            } else {
                                                str2 = str;
                                            }
                                            ActivityManagerService activityManagerService5 = this.mService;
                                            ApplicationInfo applicationInfo3 = resolveInfo.activityInfo.applicationInfo;
                                            int flags3 = broadcastRecord2.intent.getFlags() | 4;
                                            HostingRecord hostingRecord3 = new HostingRecord(INetd.IF_FLAG_BROADCAST, broadcastRecord2.curComponent);
                                            if ((broadcastRecord2.intent.getFlags() & DumpState.DUMP_APEX) != 0) {
                                                z11 = true;
                                            } else {
                                                z11 = false;
                                            }
                                            processRecordStartProcessLocked = activityManagerService5.startProcessLocked(str2, applicationInfo3, true, flags3, hostingRecord3, z11, false, false);
                                            broadcastRecord2.curApp = processRecordStartProcessLocked;
                                            if (processRecordStartProcessLocked != null) {
                                                maybeAddAllowBackgroundActivityStartsToken(broadcastRecord2.curApp, broadcastRecord2);
                                                this.mPendingBroadcast = broadcastRecord2;
                                                this.mPendingBroadcastRecvIndex = i5;
                                                return;
                                            }
                                            Slog.w("BroadcastQueue", "Unable to launch app " + resolveInfo.activityInfo.applicationInfo.packageName + SliceClientPermissions.SliceAuthority.DELIMITER + i6 + " for broadcast " + broadcastRecord2.intent + ": process is bad");
                                            logBroadcastReceiverDiscardLocked(broadcastRecord2);
                                            finishReceiverLocked(broadcastRecord2, broadcastRecord2.resultCode, broadcastRecord2.resultData, broadcastRecord2.resultExtras, broadcastRecord2.resultAbort, false);
                                            scheduleBroadcastsLocked();
                                            broadcastRecord2.state = 0;
                                            return;
                                        } catch (RuntimeException e10) {
                                            e = e10;
                                            Slog.wtf("BroadcastQueue", "Failed sending broadcast to " + broadcastRecord2.curComponent + " with " + broadcastRecord2.intent, e);
                                            logBroadcastReceiverDiscardLocked(broadcastRecord2);
                                            finishReceiverLocked(broadcastRecord2, broadcastRecord2.resultCode, broadcastRecord2.resultData, broadcastRecord2.resultExtras, broadcastRecord2.resultAbort, false);
                                            scheduleBroadcastsLocked();
                                            broadcastRecord2.state = 0;
                                            return;
                                        }
                                    } catch (RemoteException e11) {
                                        e = e11;
                                    }
                                } catch (RuntimeException e12) {
                                    e = e12;
                                }
                            } catch (RemoteException e13) {
                                e = e13;
                            }
                        }
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                            StringBuilder sb4 = new StringBuilder();
                            sb4.append("Need to start app [");
                            sb4.append(this.mQueueName);
                            sb4.append("] ");
                            str2 = str;
                            sb4.append(str2);
                            sb4.append(" for broadcast ");
                            sb4.append(broadcastRecord2);
                            Slog.v("BroadcastQueue", sb4.toString());
                        } else {
                            str2 = str;
                        }
                        ActivityManagerService activityManagerService6 = this.mService;
                        ApplicationInfo applicationInfo4 = resolveInfo.activityInfo.applicationInfo;
                        int flags4 = broadcastRecord2.intent.getFlags() | 4;
                        HostingRecord hostingRecord4 = new HostingRecord(INetd.IF_FLAG_BROADCAST, broadcastRecord2.curComponent);
                        if ((broadcastRecord2.intent.getFlags() & DumpState.DUMP_APEX) != 0) {
                            z11 = true;
                        } else {
                            z11 = false;
                        }
                        processRecordStartProcessLocked = activityManagerService6.startProcessLocked(str2, applicationInfo4, true, flags4, hostingRecord4, z11, false, false);
                        broadcastRecord2.curApp = processRecordStartProcessLocked;
                        if (processRecordStartProcessLocked != null) {
                            maybeAddAllowBackgroundActivityStartsToken(broadcastRecord2.curApp, broadcastRecord2);
                            this.mPendingBroadcast = broadcastRecord2;
                            this.mPendingBroadcastRecvIndex = i5;
                            return;
                        }
                        Slog.w("BroadcastQueue", "Unable to launch app " + resolveInfo.activityInfo.applicationInfo.packageName + SliceClientPermissions.SliceAuthority.DELIMITER + i6 + " for broadcast " + broadcastRecord2.intent + ": process is bad");
                        logBroadcastReceiverDiscardLocked(broadcastRecord2);
                        finishReceiverLocked(broadcastRecord2, broadcastRecord2.resultCode, broadcastRecord2.resultData, broadcastRecord2.resultExtras, broadcastRecord2.resultAbort, false);
                        scheduleBroadcastsLocked();
                        broadcastRecord2.state = 0;
                        return;
                    }
                    z9 = z8;
                    if (z9) {
                        z10 = z9;
                    } else {
                        z10 = z9;
                    }
                    if (z10) {
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                            Slog.d("BroadcastQueue", "Skipping delivery of ordered [" + this.mQueueName + "] " + broadcastRecord2 + " for reason described above");
                        } else {
                            Slog.d("BroadcastQueue", "Skipping delivery of ordered [" + this.mQueueName + "] " + broadcastRecord2 + " for reason described above");
                        }
                        broadcastRecord2.delivery[i5] = 2;
                        broadcastRecord2.receiver = null;
                        broadcastRecord2.curFilter = null;
                        broadcastRecord2.state = 0;
                        broadcastRecord2.manifestSkipCount++;
                        scheduleBroadcastsLocked();
                        return;
                    }
                    broadcastRecord2.manifestCount++;
                    broadcastRecord2.delivery[i5] = 1;
                    broadcastRecord2.state = 1;
                    broadcastRecord2.curComponent = componentName;
                    broadcastRecord2.curReceiver = resolveInfo.activityInfo;
                    if (ActivityManagerDebugConfig.DEBUG_MU) {
                        Slog.v(TAG_MU, "Updated broadcast record activity info for secondary user, " + resolveInfo.activityInfo + ", callingUid = " + broadcastRecord2.callingUid + ", uid = " + i6);
                    }
                    if (broadcastOptions != null) {
                        scheduleTempWhitelistLocked(i6, broadcastOptions.getTemporaryAppWhitelistDuration(), broadcastRecord2);
                    }
                    AppGlobals.getPackageManager().setPackageStoppedState(broadcastRecord2.curComponent.getPackageName(), false, broadcastRecord2.userId);
                    if (processRecordLocked != null) {
                        str = str;
                        i6 = i6;
                    } else {
                        str = str;
                        i6 = i6;
                    }
                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                        StringBuilder sb5 = new StringBuilder();
                        sb5.append("Need to start app [");
                        sb5.append(this.mQueueName);
                        sb5.append("] ");
                        str2 = str;
                        sb5.append(str2);
                        sb5.append(" for broadcast ");
                        sb5.append(broadcastRecord2);
                        Slog.v("BroadcastQueue", sb5.toString());
                    } else {
                        str2 = str;
                    }
                    ActivityManagerService activityManagerService7 = this.mService;
                    ApplicationInfo applicationInfo5 = resolveInfo.activityInfo.applicationInfo;
                    int flags5 = broadcastRecord2.intent.getFlags() | 4;
                    HostingRecord hostingRecord5 = new HostingRecord(INetd.IF_FLAG_BROADCAST, broadcastRecord2.curComponent);
                    if ((broadcastRecord2.intent.getFlags() & DumpState.DUMP_APEX) != 0) {
                        z11 = true;
                    } else {
                        z11 = false;
                    }
                    processRecordStartProcessLocked = activityManagerService7.startProcessLocked(str2, applicationInfo5, true, flags5, hostingRecord5, z11, false, false);
                    broadcastRecord2.curApp = processRecordStartProcessLocked;
                    if (processRecordStartProcessLocked != null) {
                        maybeAddAllowBackgroundActivityStartsToken(broadcastRecord2.curApp, broadcastRecord2);
                        this.mPendingBroadcast = broadcastRecord2;
                        this.mPendingBroadcastRecvIndex = i5;
                        return;
                    }
                    Slog.w("BroadcastQueue", "Unable to launch app " + resolveInfo.activityInfo.applicationInfo.packageName + SliceClientPermissions.SliceAuthority.DELIMITER + i6 + " for broadcast " + broadcastRecord2.intent + ": process is bad");
                    logBroadcastReceiverDiscardLocked(broadcastRecord2);
                    finishReceiverLocked(broadcastRecord2, broadcastRecord2.resultCode, broadcastRecord2.resultData, broadcastRecord2.resultExtras, broadcastRecord2.resultAbort, false);
                    scheduleBroadcastsLocked();
                    broadcastRecord2.state = 0;
                    return;
                }
                z15 = false;
                i = 1;
                size = i2;
                z16 = z4;
            }
            z3 = false;
            if (nextBroadcastLocked.state != 0) {
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                    Slog.d("BroadcastQueue", "processNextBroadcast(" + this.mQueueName + ") called when not idle (state=" + nextBroadcastLocked.state + ")");
                    return;
                }
                return;
            }
            if (nextBroadcastLocked.receivers != null) {
                if (nextBroadcastLocked.resultTo == null) {
                    i3 = size3 == true ? 1 : 0;
                    broadcastRecord = nextBroadcastLocked;
                    iIntentReceiver = null;
                    j = 64;
                } else {
                    if (nextBroadcastLocked.splitToken != 0) {
                        i4 = this.mSplitRefcounts.get(nextBroadcastLocked.splitToken) - i;
                        if (i4 == 0) {
                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                                Slog.i("BroadcastQueue", "Sending broadcast completion for split token " + nextBroadcastLocked.splitToken + " : " + nextBroadcastLocked.intent.getAction());
                            }
                            this.mSplitRefcounts.delete(nextBroadcastLocked.splitToken);
                            z5 = true;
                        } else {
                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                                Slog.i("BroadcastQueue", "Result refcount now " + i4 + " for split token " + nextBroadcastLocked.splitToken + " : " + nextBroadcastLocked.intent.getAction() + " - not sending completion yet");
                            }
                            this.mSplitRefcounts.put(nextBroadcastLocked.splitToken, i4);
                            z5 = false;
                        }
                    } else {
                        z5 = true;
                    }
                    if (!z5) {
                        i3 = size3 == true ? 1 : 0;
                        broadcastRecord = nextBroadcastLocked;
                        iIntentReceiver = null;
                        j = 64;
                    } else {
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                            Slog.i("BroadcastQueue", "Finishing broadcast [" + this.mQueueName + "] " + nextBroadcastLocked.intent.getAction() + " app=" + nextBroadcastLocked.callerApp);
                        }
                        ProcessRecord processRecord4 = nextBroadcastLocked.callerApp;
                        IIntentReceiver iIntentReceiver3 = nextBroadcastLocked.resultTo;
                        Intent intent2 = new Intent(nextBroadcastLocked.intent);
                        int i17 = nextBroadcastLocked.resultCode;
                        String str5 = nextBroadcastLocked.resultData;
                        Bundle bundle2 = nextBroadcastLocked.resultExtras;
                        int i18 = nextBroadcastLocked.userId;
                        i3 = size3 == true ? 1 : 0;
                        broadcastRecord = nextBroadcastLocked;
                        iIntentReceiver = null;
                        j = 64;
                        performReceiveLocked(processRecord4, iIntentReceiver3, intent2, i17, str5, bundle2, false, false, i18);
                        broadcastRecord.resultTo = null;
                    }
                }
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                    Slog.v("BroadcastQueue", "Cancelling BROADCAST_TIMEOUT_MSG");
                }
                cancelBroadcastTimeoutLocked();
                jUptimeMillis = SystemClock.uptimeMillis() - broadcastRecord.dispatchTime;
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD_TORTUOUS) {
                    strValueOf = String.valueOf(broadcastRecord.receivers);
                } else {
                    strValueOf = String.valueOf(i3);
                }
                if (!ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                    Slog.d("BroadcastQueue", "Finished with ordered broadcast " + broadcastRecord + " receivers:(" + strValueOf + ") take " + jUptimeMillis + "ms in [" + this.mQueueName + "], remains " + (this.mDispatcher.getOrderedBroadcasts().size() - 1));
                } else {
                    Slog.d("BroadcastQueue", "Finished with ordered broadcast " + broadcastRecord + " receivers:(" + strValueOf + ") take " + jUptimeMillis + "ms in [" + this.mQueueName + "], remains " + (this.mDispatcher.getOrderedBroadcasts().size() - 1));
                }
                addBroadcastToHistoryLocked(broadcastRecord);
                if (broadcastRecord.intent.getComponent() != null) {
                }
                this.mDispatcher.retireBroadcastLocked(broadcastRecord);
                broadcastRecord2 = null;
                z4 = true;
            } else {
                if (nextBroadcastLocked.resultTo == null) {
                    i3 = size3 == true ? 1 : 0;
                    broadcastRecord = nextBroadcastLocked;
                    iIntentReceiver = null;
                    j = 64;
                } else {
                    if (nextBroadcastLocked.splitToken != 0) {
                        i4 = this.mSplitRefcounts.get(nextBroadcastLocked.splitToken) - i;
                        if (i4 == 0) {
                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                                Slog.i("BroadcastQueue", "Sending broadcast completion for split token " + nextBroadcastLocked.splitToken + " : " + nextBroadcastLocked.intent.getAction());
                            }
                            this.mSplitRefcounts.delete(nextBroadcastLocked.splitToken);
                            z5 = true;
                        } else {
                            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_DEFERRAL) {
                                Slog.i("BroadcastQueue", "Result refcount now " + i4 + " for split token " + nextBroadcastLocked.splitToken + " : " + nextBroadcastLocked.intent.getAction() + " - not sending completion yet");
                            }
                            this.mSplitRefcounts.put(nextBroadcastLocked.splitToken, i4);
                            z5 = false;
                        }
                    } else {
                        z5 = true;
                    }
                    if (!z5) {
                        i3 = size3 == true ? 1 : 0;
                        broadcastRecord = nextBroadcastLocked;
                        iIntentReceiver = null;
                        j = 64;
                    } else {
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                            Slog.i("BroadcastQueue", "Finishing broadcast [" + this.mQueueName + "] " + nextBroadcastLocked.intent.getAction() + " app=" + nextBroadcastLocked.callerApp);
                        }
                        ProcessRecord processRecord5 = nextBroadcastLocked.callerApp;
                        IIntentReceiver iIntentReceiver4 = nextBroadcastLocked.resultTo;
                        Intent intent3 = new Intent(nextBroadcastLocked.intent);
                        int i19 = nextBroadcastLocked.resultCode;
                        String str6 = nextBroadcastLocked.resultData;
                        Bundle bundle3 = nextBroadcastLocked.resultExtras;
                        int i110 = nextBroadcastLocked.userId;
                        i3 = size3 == true ? 1 : 0;
                        broadcastRecord = nextBroadcastLocked;
                        iIntentReceiver = null;
                        j = 64;
                        performReceiveLocked(processRecord5, iIntentReceiver4, intent3, i19, str6, bundle3, false, false, i110);
                        broadcastRecord.resultTo = null;
                    }
                }
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                    Slog.v("BroadcastQueue", "Cancelling BROADCAST_TIMEOUT_MSG");
                }
                cancelBroadcastTimeoutLocked();
                jUptimeMillis = SystemClock.uptimeMillis() - broadcastRecord.dispatchTime;
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD_TORTUOUS) {
                    strValueOf = String.valueOf(broadcastRecord.receivers);
                } else {
                    strValueOf = String.valueOf(i3);
                }
                if (!ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                    Slog.d("BroadcastQueue", "Finished with ordered broadcast " + broadcastRecord + " receivers:(" + strValueOf + ") take " + jUptimeMillis + "ms in [" + this.mQueueName + "], remains " + (this.mDispatcher.getOrderedBroadcasts().size() - 1));
                } else {
                    Slog.d("BroadcastQueue", "Finished with ordered broadcast " + broadcastRecord + " receivers:(" + strValueOf + ") take " + jUptimeMillis + "ms in [" + this.mQueueName + "], remains " + (this.mDispatcher.getOrderedBroadcasts().size() - 1));
                }
                addBroadcastToHistoryLocked(broadcastRecord);
                if (broadcastRecord.intent.getComponent() != null) {
                }
                this.mDispatcher.retireBroadcastLocked(broadcastRecord);
                broadcastRecord2 = null;
                z4 = true;
            }
            if (broadcastRecord2 != null) {
                i5 = broadcastRecord2.nextReceiver;
                broadcastRecord2.nextReceiver = i5 + 1;
                broadcastRecord2.receiverTime = SystemClock.uptimeMillis();
                if (i5 == 0) {
                    broadcastRecord2.dispatchTime = broadcastRecord2.receiverTime;
                    broadcastRecord2.dispatchClockTime = System.currentTimeMillis();
                    if (this.mLogLatencyMetrics) {
                        StatsLog.write(142, broadcastRecord2.dispatchClockTime - broadcastRecord2.enqueueClockTime);
                    }
                    if (Trace.isTagEnabled(j)) {
                        long j5 = j;
                        Trace.asyncTraceEnd(j5, createBroadcastTraceTitle(broadcastRecord2, 0), System.identityHashCode(broadcastRecord2));
                        Trace.asyncTraceBegin(j5, createBroadcastTraceTitle(broadcastRecord2, 1), System.identityHashCode(broadcastRecord2));
                    }
                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST_LIGHT) {
                        Slog.v("BroadcastQueue", "Processing ordered broadcast [" + this.mQueueName + "] " + broadcastRecord2);
                    }
                }
                if (!this.mPendingBroadcastTimeoutMessage) {
                    j2 = broadcastRecord2.receiverTime + this.mConstants.TIMEOUT;
                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                        Slog.v("BroadcastQueue", "Submitting BROADCAST_TIMEOUT_MSG [" + this.mQueueName + "] for " + broadcastRecord2 + " at " + j2);
                    }
                    setBroadcastTimeoutLocked(j2);
                }
                broadcastOptions = broadcastRecord2.options;
                obj = broadcastRecord2.receivers.get(i5);
                if (obj instanceof BroadcastFilter) {
                    broadcastFilter = (BroadcastFilter) obj;
                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                        Slog.v("BroadcastQueue", "Delivering ordered [" + this.mQueueName + "] to registered " + broadcastFilter + ": " + broadcastRecord2);
                    }
                    deliverToRegisteredReceiverLocked(broadcastRecord2, broadcastFilter, broadcastRecord2.ordered, i5);
                    if (broadcastRecord2.receiver != null) {
                    }
                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                        Slog.v("BroadcastQueue", "Quick finishing [" + this.mQueueName + "]: ordered=" + broadcastRecord2.ordered + " receiver=" + broadcastRecord2.receiver);
                    }
                    broadcastRecord2.state = 0;
                    scheduleBroadcastsLocked();
                    return;
                }
                resolveInfo = (ResolveInfo) obj;
                componentName = new ComponentName(resolveInfo.activityInfo.applicationInfo.packageName, resolveInfo.activityInfo.name);
                z6 = false;
                if (broadcastOptions != null) {
                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST_SPRD) {
                        Slog.d("BroadcastQueue", "SdkVersion is not ok : (" + componentName + ") skip");
                    }
                    z6 = true;
                }
                if (!z6) {
                    Slog.w("BroadcastQueue", "Association not allowed: broadcasting " + broadcastRecord2.intent.toString() + " from " + broadcastRecord2.callerPackage + " (pid=" + broadcastRecord2.callingPid + ", uid=" + broadcastRecord2.callingUid + ") to " + componentName.flattenToShortString());
                    z6 = true;
                }
                if (!z6) {
                    z12 = !this.mService.mIntentFirewall.checkBroadcast(broadcastRecord2.intent, broadcastRecord2.callingUid, broadcastRecord2.callingPid, broadcastRecord2.resolvedType, resolveInfo.activityInfo.applicationInfo.uid);
                    if (z12) {
                        Slog.w("BroadcastQueue", "Firewall blocked: broadcasting " + broadcastRecord2.intent.toString() + " from " + broadcastRecord2.callerPackage + " (pid=" + broadcastRecord2.callingPid + ", uid=" + broadcastRecord2.callingUid + ") to " + componentName.flattenToShortString());
                    }
                    if (z12) {
                        z13 = true;
                    } else {
                        z13 = true;
                    }
                    z6 = z13;
                }
                ActivityManagerService activityManagerService8 = this.mService;
                int iCheckComponentPermission3 = ActivityManagerService.checkComponentPermission(resolveInfo.activityInfo.permission, broadcastRecord2.callingPid, broadcastRecord2.callingUid, resolveInfo.activityInfo.applicationInfo.uid, resolveInfo.activityInfo.exported);
                int i111 = -1;
                if (z6) {
                    if (z6) {
                        z7 = z6;
                    } else {
                        z7 = z6;
                    }
                } else if (z6) {
                    z7 = z6;
                } else {
                    z7 = z6;
                }
                if (z7) {
                }
                if (!z7) {
                    Slog.w("BroadcastQueue", "Appop Denial: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString() + " requires appop " + AppOpsManager.opToName(broadcastRecord2.appOp) + " due to sender " + broadcastRecord2.callerPackage + " (uid " + broadcastRecord2.callingUid + ")");
                    z7 = true;
                }
                zIsSingleton = this.mService.isSingleton(resolveInfo.activityInfo.processName, resolveInfo.activityInfo.applicationInfo, resolveInfo.activityInfo.name, resolveInfo.activityInfo.flags);
                if ((resolveInfo.activityInfo.flags & 1073741824) != 0) {
                    Slog.w("BroadcastQueue", "Permission Denial: Receiver " + componentName.flattenToShortString() + " requests FLAG_SINGLE_USER, but app does not hold android.permission.INTERACT_ACROSS_USERS");
                    z7 = true;
                }
                if (!z7) {
                    Slog.w("BroadcastQueue", "Instant App Denial: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString() + " due to sender " + broadcastRecord2.callerPackage + " (uid " + broadcastRecord2.callingUid + ") Instant Apps do not support manifest receivers");
                    z7 = true;
                }
                if (!z7) {
                    Slog.w("BroadcastQueue", "Instant App Denial: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString() + " requires receiver have visibleToInstantApps set due to sender " + broadcastRecord2.callerPackage + " (uid " + broadcastRecord2.callingUid + ")");
                    z7 = true;
                }
                if (broadcastRecord2.curApp != null) {
                    Slog.w("BroadcastQueue", "Skipping deliver ordered [" + this.mQueueName + "] " + broadcastRecord2 + " to " + broadcastRecord2.curApp + ": process crashing");
                    z7 = true;
                }
                if (!z7) {
                    zIsPackageAvailable = false;
                    zIsPackageAvailable = AppGlobals.getPackageManager().isPackageAvailable(resolveInfo.activityInfo.packageName, UserHandle.getUserId(resolveInfo.activityInfo.applicationInfo.uid));
                    if (!zIsPackageAvailable) {
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                            Slog.d("BroadcastQueue", "Skipping delivery to " + resolveInfo.activityInfo.packageName + " / " + resolveInfo.activityInfo.applicationInfo.uid + " : package no longer available");
                        } else {
                            Slog.d("BroadcastQueue", "Skipping delivery to " + resolveInfo.activityInfo.packageName + " / " + resolveInfo.activityInfo.applicationInfo.uid + " : package no longer available");
                        }
                        z7 = true;
                    }
                }
                if (!z7) {
                    z7 = true;
                }
                i6 = resolveInfo.activityInfo.applicationInfo.uid;
                if (broadcastRecord2.callingUid != 1000) {
                    resolveInfo.activityInfo = this.mService.getActivityInfoForUser(resolveInfo.activityInfo, 0);
                }
                str = resolveInfo.activityInfo.processName;
                processRecordLocked = this.mService.getProcessRecordLocked(str, resolveInfo.activityInfo.applicationInfo.uid, false);
                if (z7) {
                    z8 = z7;
                } else {
                    z8 = z7;
                    appStartModeLocked = this.mService.getAppStartModeLocked(resolveInfo.activityInfo.applicationInfo.uid, resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.applicationInfo.targetSdkVersion, -1, true, false, false);
                    if (appStartModeLocked != 0) {
                        if (appStartModeLocked == 3) {
                            Slog.w("BroadcastQueue", "Background execution disabled: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString());
                            z9 = true;
                        } else {
                            if ((broadcastRecord2.intent.getFlags() & DumpState.DUMP_VOLUMES) == 0) {
                            }
                            this.mService.addBackgroundCheckViolationLocked(broadcastRecord2.intent.getAction(), componentName.getPackageName());
                            Slog.w("BroadcastQueue", "Background execution not allowed: receiving " + broadcastRecord2.intent + " to " + componentName.flattenToShortString());
                            z9 = true;
                        }
                    }
                    if (z9) {
                        z10 = z9;
                    } else {
                        z10 = z9;
                    }
                    if (z10) {
                        if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                            Slog.d("BroadcastQueue", "Skipping delivery of ordered [" + this.mQueueName + "] " + broadcastRecord2 + " for reason described above");
                        } else {
                            Slog.d("BroadcastQueue", "Skipping delivery of ordered [" + this.mQueueName + "] " + broadcastRecord2 + " for reason described above");
                        }
                        broadcastRecord2.delivery[i5] = 2;
                        broadcastRecord2.receiver = null;
                        broadcastRecord2.curFilter = null;
                        broadcastRecord2.state = 0;
                        broadcastRecord2.manifestSkipCount++;
                        scheduleBroadcastsLocked();
                        return;
                    }
                    broadcastRecord2.manifestCount++;
                    broadcastRecord2.delivery[i5] = 1;
                    broadcastRecord2.state = 1;
                    broadcastRecord2.curComponent = componentName;
                    broadcastRecord2.curReceiver = resolveInfo.activityInfo;
                    if (ActivityManagerDebugConfig.DEBUG_MU) {
                        Slog.v(TAG_MU, "Updated broadcast record activity info for secondary user, " + resolveInfo.activityInfo + ", callingUid = " + broadcastRecord2.callingUid + ", uid = " + i6);
                    }
                    if (broadcastOptions != null) {
                        scheduleTempWhitelistLocked(i6, broadcastOptions.getTemporaryAppWhitelistDuration(), broadcastRecord2);
                    }
                    AppGlobals.getPackageManager().setPackageStoppedState(broadcastRecord2.curComponent.getPackageName(), false, broadcastRecord2.userId);
                    if (processRecordLocked != null) {
                        str = str;
                        i6 = i6;
                    } else {
                        str = str;
                        i6 = i6;
                    }
                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                        StringBuilder sb6 = new StringBuilder();
                        sb6.append("Need to start app [");
                        sb6.append(this.mQueueName);
                        sb6.append("] ");
                        str2 = str;
                        sb6.append(str2);
                        sb6.append(" for broadcast ");
                        sb6.append(broadcastRecord2);
                        Slog.v("BroadcastQueue", sb6.toString());
                    } else {
                        str2 = str;
                    }
                    ActivityManagerService activityManagerService9 = this.mService;
                    ApplicationInfo applicationInfo6 = resolveInfo.activityInfo.applicationInfo;
                    int flags6 = broadcastRecord2.intent.getFlags() | 4;
                    HostingRecord hostingRecord6 = new HostingRecord(INetd.IF_FLAG_BROADCAST, broadcastRecord2.curComponent);
                    if ((broadcastRecord2.intent.getFlags() & DumpState.DUMP_APEX) != 0) {
                        z11 = true;
                    } else {
                        z11 = false;
                    }
                    processRecordStartProcessLocked = activityManagerService9.startProcessLocked(str2, applicationInfo6, true, flags6, hostingRecord6, z11, false, false);
                    broadcastRecord2.curApp = processRecordStartProcessLocked;
                    if (processRecordStartProcessLocked != null) {
                        maybeAddAllowBackgroundActivityStartsToken(broadcastRecord2.curApp, broadcastRecord2);
                        this.mPendingBroadcast = broadcastRecord2;
                        this.mPendingBroadcastRecvIndex = i5;
                        return;
                    }
                    Slog.w("BroadcastQueue", "Unable to launch app " + resolveInfo.activityInfo.applicationInfo.packageName + SliceClientPermissions.SliceAuthority.DELIMITER + i6 + " for broadcast " + broadcastRecord2.intent + ": process is bad");
                    logBroadcastReceiverDiscardLocked(broadcastRecord2);
                    finishReceiverLocked(broadcastRecord2, broadcastRecord2.resultCode, broadcastRecord2.resultData, broadcastRecord2.resultExtras, broadcastRecord2.resultAbort, false);
                    scheduleBroadcastsLocked();
                    broadcastRecord2.state = 0;
                    return;
                }
                z9 = z8;
                if (z9) {
                    z10 = z9;
                } else {
                    z10 = z9;
                }
                if (z10) {
                    if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                        Slog.d("BroadcastQueue", "Skipping delivery of ordered [" + this.mQueueName + "] " + broadcastRecord2 + " for reason described above");
                    } else {
                        Slog.d("BroadcastQueue", "Skipping delivery of ordered [" + this.mQueueName + "] " + broadcastRecord2 + " for reason described above");
                    }
                    broadcastRecord2.delivery[i5] = 2;
                    broadcastRecord2.receiver = null;
                    broadcastRecord2.curFilter = null;
                    broadcastRecord2.state = 0;
                    broadcastRecord2.manifestSkipCount++;
                    scheduleBroadcastsLocked();
                    return;
                }
                broadcastRecord2.manifestCount++;
                broadcastRecord2.delivery[i5] = 1;
                broadcastRecord2.state = 1;
                broadcastRecord2.curComponent = componentName;
                broadcastRecord2.curReceiver = resolveInfo.activityInfo;
                if (ActivityManagerDebugConfig.DEBUG_MU) {
                    Slog.v(TAG_MU, "Updated broadcast record activity info for secondary user, " + resolveInfo.activityInfo + ", callingUid = " + broadcastRecord2.callingUid + ", uid = " + i6);
                }
                if (broadcastOptions != null) {
                    scheduleTempWhitelistLocked(i6, broadcastOptions.getTemporaryAppWhitelistDuration(), broadcastRecord2);
                }
                AppGlobals.getPackageManager().setPackageStoppedState(broadcastRecord2.curComponent.getPackageName(), false, broadcastRecord2.userId);
                if (processRecordLocked != null) {
                    str = str;
                    i6 = i6;
                } else {
                    str = str;
                    i6 = i6;
                }
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                    StringBuilder sb7 = new StringBuilder();
                    sb7.append("Need to start app [");
                    sb7.append(this.mQueueName);
                    sb7.append("] ");
                    str2 = str;
                    sb7.append(str2);
                    sb7.append(" for broadcast ");
                    sb7.append(broadcastRecord2);
                    Slog.v("BroadcastQueue", sb7.toString());
                } else {
                    str2 = str;
                }
                ActivityManagerService activityManagerService10 = this.mService;
                ApplicationInfo applicationInfo7 = resolveInfo.activityInfo.applicationInfo;
                int flags7 = broadcastRecord2.intent.getFlags() | 4;
                HostingRecord hostingRecord7 = new HostingRecord(INetd.IF_FLAG_BROADCAST, broadcastRecord2.curComponent);
                if ((broadcastRecord2.intent.getFlags() & DumpState.DUMP_APEX) != 0) {
                    z11 = true;
                } else {
                    z11 = false;
                }
                processRecordStartProcessLocked = activityManagerService10.startProcessLocked(str2, applicationInfo7, true, flags7, hostingRecord7, z11, false, false);
                broadcastRecord2.curApp = processRecordStartProcessLocked;
                if (processRecordStartProcessLocked != null) {
                    maybeAddAllowBackgroundActivityStartsToken(broadcastRecord2.curApp, broadcastRecord2);
                    this.mPendingBroadcast = broadcastRecord2;
                    this.mPendingBroadcastRecvIndex = i5;
                    return;
                }
                Slog.w("BroadcastQueue", "Unable to launch app " + resolveInfo.activityInfo.applicationInfo.packageName + SliceClientPermissions.SliceAuthority.DELIMITER + i6 + " for broadcast " + broadcastRecord2.intent + ": process is bad");
                logBroadcastReceiverDiscardLocked(broadcastRecord2);
                finishReceiverLocked(broadcastRecord2, broadcastRecord2.resultCode, broadcastRecord2.resultData, broadcastRecord2.resultExtras, broadcastRecord2.resultAbort, false);
                scheduleBroadcastsLocked();
                broadcastRecord2.state = 0;
                return;
            }
            z15 = false;
            i = 1;
            size = i2;
            z16 = z4;
        }
    }

    private void maybeAddAllowBackgroundActivityStartsToken(ProcessRecord proc, BroadcastRecord r) {
        if (r == null || proc == null || !r.allowBackgroundActivityStarts) {
            return;
        }
        String msgToken = (proc.toShortString() + r.toString()).intern();
        this.mHandler.removeCallbacksAndMessages(msgToken);
        proc.addAllowBackgroundActivityStartsToken(r);
    }

    final void setBroadcastTimeoutLocked(long timeoutTime) {
        if (!this.mPendingBroadcastTimeoutMessage) {
            Message msg = this.mHandler.obtainMessage(BROADCAST_TIMEOUT_MSG, this);
            this.mHandler.sendMessageAtTime(msg, timeoutTime);
            this.mPendingBroadcastTimeoutMessage = true;
        }
    }

    final void cancelBroadcastTimeoutLocked() {
        if (this.mPendingBroadcastTimeoutMessage) {
            this.mHandler.removeMessages(BROADCAST_TIMEOUT_MSG, this);
            this.mPendingBroadcastTimeoutMessage = false;
        }
    }

    final void broadcastTimeoutLocked(boolean fromMsg) {
        Object curReceiver;
        ProcessRecord app;
        String anrMessage;
        boolean debugging = false;
        if (fromMsg) {
            this.mPendingBroadcastTimeoutMessage = false;
        }
        if (this.mDispatcher.isEmpty() || this.mDispatcher.getActiveBroadcastLocked() == null) {
            return;
        }
        long now = SystemClock.uptimeMillis();
        BroadcastRecord r = this.mDispatcher.getActiveBroadcastLocked();
        if (fromMsg) {
            if (!this.mService.mProcessesReady) {
                return;
            }
            if (r.timeoutExempt) {
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                    Slog.i("BroadcastQueue", "Broadcast timeout but it's exempt: " + r.intent.getAction());
                    return;
                }
                return;
            }
            long timeoutTime = r.receiverTime + this.mConstants.TIMEOUT;
            if (timeoutTime > now) {
                if (ActivityManagerDebugConfig.DEBUG_BROADCAST) {
                    Slog.v("BroadcastQueue", "Premature timeout [" + this.mQueueName + "] @ " + now + ": resetting BROADCAST_TIMEOUT_MSG for " + timeoutTime);
                }
                setBroadcastTimeoutLocked(timeoutTime);
                return;
            }
        }
        if (r.state == 4) {
            StringBuilder sb = new StringBuilder();
            sb.append("Waited long enough for: ");
            sb.append(r.curComponent != null ? r.curComponent.flattenToShortString() : "(null)");
            Slog.i("BroadcastQueue", sb.toString());
            r.curComponent = null;
            r.state = 0;
            processNextBroadcast(false);
            return;
        }
        if (r.curApp != null && r.curApp.isDebugging()) {
            debugging = true;
        }
        Slog.w("BroadcastQueue", "Timeout of broadcast " + r + " - receiver=" + r.receiver + ", started " + (now - r.receiverTime) + "ms ago");
        if (r.receiver instanceof BroadcastTimeoutListener) {
            BroadcastTimeoutListener timeoutListener = r.receiver;
            timeoutListener.onBroadcastTimeout(r.intent);
        }
        r.receiverTime = now;
        if (!debugging) {
            r.anrCount++;
        }
        ProcessRecord app2 = null;
        if (r.nextReceiver > 0) {
            Object curReceiver2 = r.receivers.get(r.nextReceiver - 1);
            r.delivery[r.nextReceiver - 1] = 3;
            curReceiver = curReceiver2;
        } else {
            Object curReceiver3 = r.curReceiver;
            curReceiver = curReceiver3;
        }
        Slog.w("BroadcastQueue", "Receiver during timeout of " + r + " : " + curReceiver);
        logBroadcastReceiverDiscardLocked(r);
        if (curReceiver != null && (curReceiver instanceof BroadcastFilter)) {
            BroadcastFilter bf = (BroadcastFilter) curReceiver;
            if (bf.receiverList.pid != 0 && bf.receiverList.pid != ActivityManagerService.MY_PID) {
                synchronized (this.mService.mPidsSelfLocked) {
                    app2 = this.mService.mPidsSelfLocked.get(bf.receiverList.pid);
                }
            }
            app = app2;
        } else {
            app = r.curApp;
        }
        if (app == null) {
            anrMessage = null;
        } else {
            String anrMessage2 = "Broadcast of " + r.intent.toString();
            anrMessage = anrMessage2;
        }
        if (this.mPendingBroadcast == r) {
            this.mPendingBroadcast = null;
        }
        finishReceiverLocked(r, r.resultCode, r.resultData, r.resultExtras, r.resultAbort, false);
        scheduleBroadcastsLocked();
        if (!debugging && anrMessage != null) {
            this.mHandler.post(new AppNotResponding(app, anrMessage));
        }
    }

    private final int ringAdvance(int x, int increment, int ringSize) {
        int x2 = x + increment;
        if (x2 < 0) {
            return ringSize - 1;
        }
        if (x2 >= ringSize) {
            return 0;
        }
        return x2;
    }

    private final void addBroadcastToHistoryLocked(BroadcastRecord original) {
        if (original.callingUid < 0) {
            return;
        }
        original.finishTime = SystemClock.uptimeMillis();
        if (Trace.isTagEnabled(64L)) {
            Trace.asyncTraceEnd(64L, createBroadcastTraceTitle(original, 1), System.identityHashCode(original));
        }
        BroadcastRecord historyRecord = original.maybeStripForHistory();
        BroadcastRecord[] broadcastRecordArr = this.mBroadcastHistory;
        int i = this.mHistoryNext;
        broadcastRecordArr[i] = historyRecord;
        this.mHistoryNext = ringAdvance(i, 1, MAX_BROADCAST_HISTORY);
        this.mBroadcastSummaryHistory[this.mSummaryHistoryNext] = historyRecord.intent;
        this.mSummaryHistoryEnqueueTime[this.mSummaryHistoryNext] = historyRecord.enqueueClockTime;
        this.mSummaryHistoryDispatchTime[this.mSummaryHistoryNext] = historyRecord.dispatchClockTime;
        this.mSummaryHistoryFinishTime[this.mSummaryHistoryNext] = System.currentTimeMillis();
        this.mSummaryHistoryNext = ringAdvance(this.mSummaryHistoryNext, 1, MAX_BROADCAST_SUMMARY_HISTORY);
    }

    boolean cleanupDisabledPackageReceiversLocked(String packageName, Set<String> filterByClasses, int userId, boolean doit) {
        boolean didSomething = false;
        for (int i = this.mParallelBroadcasts.size() - 1; i >= 0; i--) {
            didSomething |= this.mParallelBroadcasts.get(i).cleanupDisabledPackageReceiversLocked(packageName, filterByClasses, userId, doit);
            if (!doit && didSomething) {
                return true;
            }
        }
        return didSomething | this.mDispatcher.cleanupDisabledPackageReceiversLocked(packageName, filterByClasses, userId, doit);
    }

    final void logBroadcastReceiverDiscardLocked(BroadcastRecord r) {
        int logIndex = r.nextReceiver - 1;
        if (logIndex >= 0 && logIndex < r.receivers.size()) {
            Object curReceiver = r.receivers.get(logIndex);
            if (curReceiver instanceof BroadcastFilter) {
                BroadcastFilter bf = (BroadcastFilter) curReceiver;
                EventLog.writeEvent(EventLogTags.AM_BROADCAST_DISCARD_FILTER, Integer.valueOf(bf.owningUserId), Integer.valueOf(System.identityHashCode(r)), r.intent.getAction(), Integer.valueOf(logIndex), Integer.valueOf(System.identityHashCode(bf)));
                return;
            } else {
                ResolveInfo ri = (ResolveInfo) curReceiver;
                EventLog.writeEvent(EventLogTags.AM_BROADCAST_DISCARD_APP, Integer.valueOf(UserHandle.getUserId(ri.activityInfo.applicationInfo.uid)), Integer.valueOf(System.identityHashCode(r)), r.intent.getAction(), Integer.valueOf(logIndex), ri.toString());
                return;
            }
        }
        if (logIndex < 0) {
            Slog.w("BroadcastQueue", "Discarding broadcast before first receiver is invoked: " + r);
        }
        EventLog.writeEvent(EventLogTags.AM_BROADCAST_DISCARD_APP, -1, Integer.valueOf(System.identityHashCode(r)), r.intent.getAction(), Integer.valueOf(r.nextReceiver), "NONE");
    }

    private String createBroadcastTraceTitle(BroadcastRecord record, int state) {
        Object[] objArr = new Object[4];
        objArr[0] = state == 0 ? "in queue" : "dispatched";
        objArr[1] = record.callerPackage == null ? "" : record.callerPackage;
        objArr[2] = record.callerApp == null ? "process unknown" : record.callerApp.toShortString();
        objArr[3] = record.intent != null ? record.intent.getAction() : "";
        return String.format("Broadcast %s from %s (%s) %s", objArr);
    }

    boolean isIdle() {
        return this.mParallelBroadcasts.isEmpty() && this.mDispatcher.isEmpty() && this.mPendingBroadcast == null;
    }

    void cancelDeferrals() {
        synchronized (this.mService) {
            try {
                ActivityManagerService.boostPriorityForLockedSection();
                this.mDispatcher.cancelDeferralsLocked();
                scheduleBroadcastsLocked();
            } finally {
                ActivityManagerService.resetPriorityAfterLockedSection();
            }
        }
    }

    String describeState() {
        String str;
        synchronized (this.mService) {
            try {
                ActivityManagerService.boostPriorityForLockedSection();
                str = this.mParallelBroadcasts.size() + " parallel; " + this.mDispatcher.describeStateLocked();
            } finally {
                ActivityManagerService.resetPriorityAfterLockedSection();
            }
        }
        return str;
    }

    void writeToProto(ProtoOutputStream proto, long fieldId) {
        int i;
        long token = proto.start(fieldId);
        proto.write(1138166333441L, this.mQueueName);
        int N = this.mParallelBroadcasts.size();
        for (int i2 = N - 1; i2 >= 0; i2--) {
            this.mParallelBroadcasts.get(i2).writeToProto(proto, 2246267895810L);
        }
        this.mDispatcher.writeToProto(proto, 2246267895811L);
        BroadcastRecord broadcastRecord = this.mPendingBroadcast;
        if (broadcastRecord != null) {
            broadcastRecord.writeToProto(proto, 1146756268036L);
        }
        int lastIndex = this.mHistoryNext;
        int ringIndex = lastIndex;
        do {
            i = -1;
            ringIndex = ringAdvance(ringIndex, -1, MAX_BROADCAST_HISTORY);
            BroadcastRecord r = this.mBroadcastHistory[ringIndex];
            if (r != null) {
                r.writeToProto(proto, 2246267895813L);
            }
        } while (ringIndex != lastIndex);
        int i3 = this.mSummaryHistoryNext;
        int ringIndex2 = i3;
        int lastIndex2 = i3;
        while (true) {
            int ringIndex3 = ringAdvance(ringIndex2, i, MAX_BROADCAST_SUMMARY_HISTORY);
            Intent intent = this.mBroadcastSummaryHistory[ringIndex3];
            if (intent != null) {
                long summaryToken = proto.start(2246267895814L);
                intent.writeToProto(proto, 1146756268033L, false, true, true, false);
                proto.write(1112396529666L, this.mSummaryHistoryEnqueueTime[ringIndex3]);
                proto.write(1112396529667L, this.mSummaryHistoryDispatchTime[ringIndex3]);
                proto.write(1112396529668L, this.mSummaryHistoryFinishTime[ringIndex3]);
                proto.end(summaryToken);
            }
            int lastIndex3 = lastIndex2;
            if (ringIndex3 != lastIndex3) {
                lastIndex2 = lastIndex3;
                ringIndex2 = ringIndex3;
                i = -1;
            } else {
                proto.end(token);
                return;
            }
        }
    }

    final boolean dumpLocked(FileDescriptor fd, PrintWriter pw, String[] args, int opti, boolean dumpAll, String dumpPackage, boolean needSep) {
        boolean needSep2;
        BroadcastRecord broadcastRecord;
        boolean printed;
        String str;
        String str2 = dumpPackage;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String str3 = ":";
        if (this.mParallelBroadcasts.isEmpty() && this.mDispatcher.isEmpty() && this.mPendingBroadcast == null) {
            needSep2 = needSep;
        } else {
            boolean printed2 = false;
            boolean needSep3 = needSep;
            for (int i = this.mParallelBroadcasts.size() - 1; i >= 0; i--) {
                BroadcastRecord br = this.mParallelBroadcasts.get(i);
                if (str2 == null || str2.equals(br.callerPackage)) {
                    if (!printed2) {
                        if (needSep3) {
                            pw.println();
                        }
                        needSep3 = true;
                        printed2 = true;
                        pw.println("  Active broadcasts [" + this.mQueueName + "]:");
                    }
                    pw.println("  Active Broadcast " + this.mQueueName + " #" + i + ":");
                    br.dump(pw, "    ", sdf);
                }
            }
            this.mDispatcher.dumpLocked(pw, str2, this.mQueueName, sdf);
            if (str2 == null || ((broadcastRecord = this.mPendingBroadcast) != null && str2.equals(broadcastRecord.callerPackage))) {
                pw.println();
                pw.println("  Pending broadcast [" + this.mQueueName + "]:");
                BroadcastRecord broadcastRecord2 = this.mPendingBroadcast;
                if (broadcastRecord2 != null) {
                    broadcastRecord2.dump(pw, "    ", sdf);
                } else {
                    pw.println("    (null)");
                }
                needSep2 = true;
            } else {
                needSep2 = needSep3;
            }
        }
        this.mConstants.dump(pw);
        boolean printed3 = false;
        int i2 = -1;
        int lastIndex = this.mHistoryNext;
        int ringIndex = lastIndex;
        while (true) {
            int ringIndex2 = ringAdvance(ringIndex, -1, MAX_BROADCAST_HISTORY);
            BroadcastRecord r = this.mBroadcastHistory[ringIndex2];
            int lastIndex2 = lastIndex;
            if (r == null) {
                str = str3;
            } else {
                i2++;
                if (str2 != null && !str2.equals(r.callerPackage)) {
                    str = str3;
                } else {
                    if (printed3) {
                        printed = printed3;
                    } else {
                        if (needSep2) {
                            pw.println();
                        }
                        needSep2 = true;
                        pw.println("  Historical broadcasts [" + this.mQueueName + "]:");
                        printed = true;
                    }
                    if (dumpAll) {
                        pw.print("  Historical Broadcast " + this.mQueueName + " #");
                        pw.print(i2);
                        pw.println(str3);
                        r.dump(pw, "    ", sdf);
                        str = str3;
                    } else {
                        pw.print("  #");
                        pw.print(i2);
                        pw.print(": ");
                        pw.println(r);
                        pw.print("    ");
                        str = str3;
                        pw.println(r.intent.toShortString(false, true, true, false));
                        if (r.targetComp != null && r.targetComp != r.intent.getComponent()) {
                            pw.print("    targetComp: ");
                            pw.println(r.targetComp.toShortString());
                        }
                        Bundle bundle = r.intent.getExtras();
                        if (bundle != null) {
                            pw.print("    extras: ");
                            pw.println(bundle.toString());
                        }
                    }
                    printed3 = printed;
                }
            }
            ringIndex = ringIndex2;
            if (ringIndex == lastIndex2) {
                break;
            }
            str2 = dumpPackage;
            lastIndex = lastIndex2;
            str3 = str;
        }
        if (str2 == null) {
            int lastIndex3 = this.mSummaryHistoryNext;
            int ringIndex3 = lastIndex3;
            if (dumpAll) {
                printed3 = false;
                i2 = -1;
            } else {
                int j = i2;
                while (j > 0 && ringIndex3 != lastIndex3) {
                    ringIndex3 = ringAdvance(ringIndex3, -1, MAX_BROADCAST_SUMMARY_HISTORY);
                    if (this.mBroadcastHistory[ringIndex3] != null) {
                        j--;
                    }
                }
            }
            while (true) {
                ringIndex3 = ringAdvance(ringIndex3, -1, MAX_BROADCAST_SUMMARY_HISTORY);
                Intent intent = this.mBroadcastSummaryHistory[ringIndex3];
                if (intent != null) {
                    if (!printed3) {
                        if (needSep2) {
                            pw.println();
                        }
                        pw.println("  Historical broadcasts summary [" + this.mQueueName + "]:");
                        printed3 = true;
                        needSep2 = true;
                    }
                    if (!dumpAll && i2 >= 50) {
                        pw.println("  ...");
                        break;
                    }
                    i2++;
                    pw.print("  #");
                    pw.print(i2);
                    pw.print(": ");
                    boolean printed4 = printed3;
                    pw.println(intent.toShortString(false, true, true, false));
                    pw.print("    ");
                    TimeUtils.formatDuration(this.mSummaryHistoryDispatchTime[ringIndex3] - this.mSummaryHistoryEnqueueTime[ringIndex3], pw);
                    pw.print(" dispatch ");
                    TimeUtils.formatDuration(this.mSummaryHistoryFinishTime[ringIndex3] - this.mSummaryHistoryDispatchTime[ringIndex3], pw);
                    pw.println(" finish");
                    pw.print("    enq=");
                    pw.print(sdf.format(new Date(this.mSummaryHistoryEnqueueTime[ringIndex3])));
                    pw.print(" disp=");
                    pw.print(sdf.format(new Date(this.mSummaryHistoryDispatchTime[ringIndex3])));
                    pw.print(" fin=");
                    pw.println(sdf.format(new Date(this.mSummaryHistoryFinishTime[ringIndex3])));
                    Bundle bundle2 = intent.getExtras();
                    if (bundle2 != null) {
                        pw.print("    extras: ");
                        pw.println(bundle2.toString());
                    }
                    printed3 = printed4;
                }
                int lastIndex4 = lastIndex3;
                if (ringIndex3 == lastIndex4) {
                    break;
                }
                lastIndex3 = lastIndex4;
            }
        }
        return needSep2;
    }
}
