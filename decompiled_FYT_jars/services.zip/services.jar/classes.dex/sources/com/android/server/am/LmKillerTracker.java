package com.android.server.am;

import android.R;
import android.app.ActivityManager;
import android.content.res.Resources;
import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.os.IBinder;
import android.os.Process;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.UserHandle;
import android.text.TextUtils;
import android.util.Slog;
import android.view.inputmethod.InputMethodInfo;
import com.android.internal.view.IInputMethodManager;
import com.android.server.wm.ActivityTaskManagerService;
import com.android.server.wm.WindowProcessController;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class LmKillerTracker extends Thread {
    private static final String LMK_TRACKER_SOCKET = "lmfs";
    private static final String TAG = "LmKillerTracker";
    private boolean mConnected;
    private List<String> mLmKillerBypassPackages;
    private ActivityManagerServiceEx mService = ActivityManager.getService();
    private ActivityTaskManagerService mAtm = this.mService.mActivityTaskManager;

    public LmKillerTracker() {
        this.mLmKillerBypassPackages = new ArrayList();
        String[] lmKillerTrackerWhitelist = Resources.getSystem().getStringArray(R.array.config_keep_warming_services);
        this.mLmKillerBypassPackages = Arrays.asList(lmKillerTrackerWhitelist);
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        Process.setThreadPriority(-2);
        int retryCount = 0;
        this.mConnected = false;
        while (true) {
            LocalSocket s = null;
            try {
                try {
                    s = new LocalSocket();
                    LocalSocketAddress lSAddr = new LocalSocketAddress(LMK_TRACKER_SOCKET, LocalSocketAddress.Namespace.RESERVED);
                    s.connect(lSAddr);
                    retryCount = 0;
                    Slog.i(TAG, "connected to lmkiller");
                    this.mConnected = true;
                    try {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(s.getInputStream()));
                        while (true) {
                            String line = bufferedReader.readLine();
                            try {
                                int pid = Integer.parseInt(line);
                                doLmkForceStop(pid);
                            } catch (Exception e) {
                                Slog.e(TAG, "doLmkForceStop encounter exception, read line " + line, e);
                            }
                        }
                    } catch (Exception e2) {
                        Slog.e(TAG, "caugth exception, closing lmk tracker", e2);
                        try {
                            s.close();
                        } catch (IOException e3) {
                        }
                    }
                } catch (IOException e4) {
                    this.mConnected = false;
                    if (s != null) {
                        try {
                            s.close();
                        } catch (Exception e5) {
                        }
                    }
                    if (retryCount == 8) {
                        Slog.e(TAG, "can't find lmkiller socket after " + retryCount + " retry, abort LmkTracker");
                        return;
                    }
                    if (retryCount >= 0 && retryCount < 8) {
                        Slog.d(TAG, "retrying " + retryCount);
                    }
                    try {
                        Thread.sleep(500L);
                    } catch (InterruptedException e6) {
                    }
                    retryCount++;
                }
            } catch (Exception e7) {
                return;
            }
        }
    }

    public void doLmkForceStop(int pid) {
        Slog.d(TAG, "doLmkForceStop pid=" + pid);
        if (pid <= 0) {
            return;
        }
        String pkgName = null;
        ProcessRecord pr = null;
        ProcessRecord parent = null;
        try {
            synchronized (this.mService.mPidsSelfLocked) {
                pr = this.mService.mPidsSelfLocked.get(pid);
            }
            if (pr == null) {
                return;
            }
            if (pr.info != null) {
                if (TextUtils.isEmpty(pr.processName)) {
                    return;
                }
                if (pr.processName.indexOf(":") > 0) {
                    synchronized (this.mService) {
                        parent = this.mService.getProcessRecordLocked(pr.info.packageName, pr.uid, true);
                    }
                }
                pkgName = pr.info.packageName;
            }
        } catch (Exception e) {
            Slog.w(TAG, "get process record from ams failed", e);
        }
        if (pkgName == null) {
            return;
        }
        if (pr == null && parent == null) {
            return;
        }
        if (pr == null || shouldForceStop(pr)) {
            boolean main = pkgName.equals(pr.processName);
            if (main) {
                Slog.i(TAG, pr.processName + "die, see childs:");
                ArrayList<ProcessRecord> list = getRelatedProcesses(pkgName);
                boolean shallStop = true;
                for (ProcessRecord process : list) {
                    if (!shouldForceStop(process)) {
                        shallStop = false;
                        break;
                    }
                }
                if (!shallStop) {
                    return;
                }
            } else if (parent != null) {
                return;
            }
            this.mService.forceStopPackage(pkgName, -2);
            Slog.i(TAG, "force stop pkg:" + pkgName + ", pid:" + pid + " (adj " + pr.setAdj + ") has done.");
        }
    }

    public boolean isConnected() {
        return this.mConnected;
    }

    private ArrayList<ProcessRecord> getRelatedProcesses(String pkgName) {
        ArrayList<ProcessRecord> list = new ArrayList<>();
        synchronized (this.mService.mPidsSelfLocked) {
            int size = this.mService.mPidsSelfLocked.size();
            for (int i = 0; i < size; i++) {
                this.mService.mPidsSelfLocked.keyAt(i);
                ProcessRecord process = this.mService.mPidsSelfLocked.valueAt(i);
                if (process != null && process.info != null && pkgName.equals(process.info.packageName) && !process.processName.equals(pkgName)) {
                    Slog.i(TAG, "get related " + process.processName + ",adj:" + process.setAdj + "for package" + pkgName);
                    list.add(process);
                }
            }
        }
        return list;
    }

    private boolean isSystemApp(ProcessRecord pr) {
        if (pr.info.isPrivilegedApp() || pr.info.isSystemApp() || pr.info.isUpdatedSystemApp()) {
            return true;
        }
        return false;
    }

    private boolean isEnabledInputMethod(String pkgName) {
        if (pkgName == null) {
            return false;
        }
        IBinder b = ServiceManager.getService("input_method");
        IInputMethodManager service = IInputMethodManager.Stub.asInterface(b);
        try {
            List<InputMethodInfo> inputMethods = service.getEnabledInputMethodList(UserHandle.myUserId());
            if (inputMethods == null || inputMethods.size() == 0) {
                return false;
            }
            for (InputMethodInfo info : inputMethods) {
                if (info != null && info.getPackageName() != null && info.getPackageName().equals(pkgName)) {
                    return true;
                }
            }
            return false;
        } catch (RemoteException e) {
            return false;
        }
    }

    private boolean isInstrumentedApp(ProcessRecord pr) {
        return pr.getActiveInstrumentation() != null;
    }

    private boolean isInWhitelist(ProcessRecord pr) {
        String pkgName = pr.info.packageName;
        for (String token : this.mLmKillerBypassPackages) {
            if (pkgName.startsWith(token)) {
                return true;
            }
        }
        return false;
    }

    private boolean shouldForceStop(ProcessRecord pr) {
        String pkgName = pr.info.packageName;
        WindowProcessController windowProcessController = pr.getWindowProcessController();
        int pid = pr.pid;
        if (this.mAtm.hasActivityInTopTask(windowProcessController)) {
            Slog.i(TAG, "Skipped process pkgName:" + pkgName + ", pid:" + pid + ", has activity in top task !");
            return false;
        }
        if (this.mAtm.hasRelativeToptaskPackageInProcess(windowProcessController)) {
            Slog.i(TAG, "Skipped process pkgName:" + pkgName + ", pid:" + pid + ", has relative top task package !");
            return false;
        }
        if (isSystemApp(pr)) {
            Slog.i(TAG, "Skipped process pkgName:" + pkgName + ", pid:" + pid + ", is system app !");
            return false;
        }
        if (isInstrumentedApp(pr)) {
            Slog.i(TAG, "Skipped process pkgName:" + pkgName + ", pid:" + pid + ", the application being instrumented !");
            return false;
        }
        if (isEnabledInputMethod(pkgName)) {
            Slog.i(TAG, "Skipped process pkgName:" + pkgName + ", pid:" + pid + ", the application is EnabledInputMethod !");
            return false;
        }
        if (isInWhitelist(pr)) {
            Slog.i(TAG, "Skipped process pkgName:" + pkgName + ", pid:" + pid + ", the application is in whitelist !");
            return false;
        }
        if (this.mService.isProcessHeldWakeLock(pr)) {
            Slog.i(TAG, "Skipped process pkgName:" + pkgName + ", pid:" + pid + ", the application is held wake lock !");
            return false;
        }
        return true;
    }
}
