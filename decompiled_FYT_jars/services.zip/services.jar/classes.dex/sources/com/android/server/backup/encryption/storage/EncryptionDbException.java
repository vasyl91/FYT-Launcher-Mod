package com.android.server.backup.encryption.storage;

import java.io.IOException;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class EncryptionDbException extends IOException {
    public EncryptionDbException(Throwable cause) {
        super(cause);
    }
}
