package com.android.server.am;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.os.ShellCommand;
import android.util.Log;
import android.util.Slog;
import com.android.server.usb.descriptors.UsbACInterface;
import com.android.server.usb.descriptors.UsbDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
class ActivityManagerShellCommandEx extends ActivityManagerShellCommand {
    private static final String TAG = "ActivityManager.Shell";
    ContentResolver mContentResolver;

    ActivityManagerShellCommandEx(ActivityManagerService service, boolean dumping) {
        super(service, dumping);
        this.mContentResolver = service.mContext.getContentResolver();
    }

    int runLmkForceStop(PrintWriter pw) {
        if (this.mInternal != null && (this.mInternal instanceof ActivityManagerServiceEx)) {
            ActivityManagerServiceEx service = (ActivityManagerServiceEx) this.mInternal;
            if (service.mLmkTracker != null) {
                String opt = getNextArgRequired();
                if (opt != null) {
                    try {
                        int pid = Integer.parseInt(opt);
                        if (pid > 0) {
                            service.mLmkTracker.doLmkForceStop(pid);
                            return 0;
                        }
                    } catch (Exception e) {
                        return -1;
                    }
                }
            } else {
                Slog.e(TAG, "lmk-force-stop failed, lmk tracker is null");
            }
        } else {
            Slog.e(TAG, "lmk-force-stop failed, AmsEx not inherited");
        }
        return -1;
    }

    int runLogSwitch(PrintWriter pw) {
        String firstInput = getNextArgRequired();
        if (firstInput != null) {
            switch (firstInput) {
                case "enable":
                    String secondInput = getNextArgRequired();
                    ActivityManagerDebugConfigDynamics.setSwitchEnabled(secondInput, true, pw);
                    break;
                case "disable":
                    String secondInput2 = getNextArgRequired();
                    ActivityManagerDebugConfigDynamics.setSwitchEnabled(secondInput2, false, pw);
                    break;
                case "pkg-enable":
                    String pkg = getNextArgRequired();
                    String logSwitch = getNextArgRequired();
                    ActivityManagerDebugConfigDynamics.setPackageSwitchEnabled(pkg, logSwitch, true, pw);
                    break;
                case "pkg-disable":
                    String pkg2 = getNextArgRequired();
                    String logSwitch2 = getNextArgRequired();
                    ActivityManagerDebugConfigDynamics.setPackageSwitchEnabled(pkg2, logSwitch2, false, pw);
                    break;
                case "pkg-bundle":
                    String pkg3 = getNextArgRequired();
                    ActivityManagerDebugConfigDynamics.setPackageBundle(pkg3, parseCommandArgsToBundle(this), pw);
                    break;
                case "list":
                    String secondInput3 = getNextArg();
                    String pkg4 = getNextArg();
                    ActivityManagerDebugConfigDynamics.listSwitchState(secondInput3, pkg4, pw);
                    break;
                case "reset":
                    ActivityManagerDebugConfigDynamics.resetAllSwitchState(pw);
                    break;
                case "save_state":
                    ActivityManagerDebugConfigDynamics.saveDebugSwtichStates(this.mContentResolver, pw);
                    break;
                case "--help":
                    ActivityManagerDebugConfigDynamics.showLogSwitchHelp(pw);
                    break;
                default:
                    pw.println("\nplease input the effective command!And use '--help' to acquire the help information\n");
                    return -1;
            }
        }
        return 0;
    }

    /* JADX WARN: Code duplicated, block: B:10:0x001b  */
    @Override // com.android.server.am.ActivityManagerShellCommand
    public int onCommand(String cmd) {
        byte b;
        if (cmd == null) {
            return handleDefaultCommands(cmd);
        }
        PrintWriter pw = getOutPrintWriter();
        try {
            int iHashCode = cmd.hashCode();
            if (iHashCode != -1867735921) {
                b = (iHashCode == 1075189831 && cmd.equals("lmk-force-stop")) ? (byte) 0 : (byte) -1;
            } else if (cmd.equals("log_switch")) {
                b = 1;
            }
            if (b == 0) {
                return runLmkForceStop(pw);
            }
            if (b == 1) {
                return runLogSwitch(pw);
            }
            return super.onCommand(cmd);
        } catch (Exception e) {
            pw.println("Exception: " + e);
            pw.println(Log.getStackTraceString(e));
            return -1;
        }
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private static Bundle parseCommandArgsToBundle(ShellCommand cmd) {
        Bundle extras = new Bundle();
        while (true) {
            String opt = cmd.getNextOption();
            if (opt != null) {
                byte b = -1;
                boolean arg = false;
                switch (opt.hashCode()) {
                    case 1496:
                        if (opt.equals("-e")) {
                            b = 0;
                        }
                        break;
                    case 1387073:
                        if (opt.equals("--ef")) {
                            b = 11;
                        }
                        break;
                    case 1387076:
                        if (opt.equals("--ei")) {
                            b = 3;
                        }
                        break;
                    case 1387079:
                        if (opt.equals("--el")) {
                            b = 8;
                        }
                        break;
                    case 1387086:
                        if (opt.equals("--es")) {
                            b = 1;
                        }
                        break;
                    case 1387088:
                        if (opt.equals("--eu")) {
                            b = 4;
                        }
                        break;
                    case 1387093:
                        if (opt.equals("--ez")) {
                            b = UsbDescriptor.DESCRIPTORTYPE_CAPABILITY;
                        }
                        break;
                    case 42999280:
                        if (opt.equals("--ecn")) {
                            b = 5;
                        }
                        break;
                    case 42999360:
                        if (opt.equals("--efa")) {
                            b = 12;
                        }
                        break;
                    case 42999453:
                        if (opt.equals("--eia")) {
                            b = 6;
                        }
                        break;
                    case 42999546:
                        if (opt.equals("--ela")) {
                            b = 9;
                        }
                        break;
                    case 42999763:
                        if (opt.equals("--esa")) {
                            b = 14;
                        }
                        break;
                    case 42999776:
                        if (opt.equals("--esn")) {
                            b = 2;
                        }
                        break;
                    case 1332980268:
                        if (opt.equals("--efal")) {
                            b = UsbACInterface.ACI_SAMPLE_RATE_CONVERTER;
                        }
                        break;
                    case 1332983151:
                        if (opt.equals("--eial")) {
                            b = 7;
                        }
                        break;
                    case 1332986034:
                        if (opt.equals("--elal")) {
                            b = 10;
                        }
                        break;
                    case 1332992761:
                        if (opt.equals("--esal")) {
                            b = UsbDescriptor.DESCRIPTORTYPE_BOS;
                        }
                        break;
                }
                switch (b) {
                    case 0:
                    case 1:
                        String key = cmd.getNextArgRequired();
                        String value = cmd.getNextArgRequired();
                        extras.putString(key, value);
                        break;
                    case 2:
                        String key2 = cmd.getNextArgRequired();
                        extras.putString(key2, (String) null);
                        break;
                    case 3:
                        String key3 = cmd.getNextArgRequired();
                        String value2 = cmd.getNextArgRequired();
                        extras.putInt(key3, Integer.decode(value2).intValue());
                        break;
                    case 4:
                        String key4 = cmd.getNextArgRequired();
                        String value3 = cmd.getNextArgRequired();
                        extras.putParcelable(key4, Uri.parse(value3));
                        break;
                    case 5:
                        String key5 = cmd.getNextArgRequired();
                        String value4 = cmd.getNextArgRequired();
                        ComponentName cn = ComponentName.unflattenFromString(value4);
                        if (cn == null) {
                            throw new IllegalArgumentException("Bad component name: " + value4);
                        }
                        extras.putParcelable(key5, cn);
                        break;
                        break;
                    case 6:
                        String key6 = cmd.getNextArgRequired();
                        String value5 = cmd.getNextArgRequired();
                        String[] strings = value5.split(",");
                        int[] list = new int[strings.length];
                        for (int i = 0; i < strings.length; i++) {
                            list[i] = Integer.decode(strings[i]).intValue();
                        }
                        extras.putIntArray(key6, list);
                        break;
                    case 7:
                        String key7 = cmd.getNextArgRequired();
                        String value6 = cmd.getNextArgRequired();
                        String[] strings2 = value6.split(",");
                        ArrayList<Integer> list2 = new ArrayList<>(strings2.length);
                        for (String str : strings2) {
                            list2.add(Integer.decode(str));
                        }
                        extras.putIntegerArrayList(key7, list2);
                        break;
                    case 8:
                        String key8 = cmd.getNextArgRequired();
                        String value7 = cmd.getNextArgRequired();
                        extras.putLong(key8, Long.valueOf(value7).longValue());
                        break;
                    case 9:
                        String key9 = cmd.getNextArgRequired();
                        String value8 = cmd.getNextArgRequired();
                        String[] strings3 = value8.split(",");
                        long[] list3 = new long[strings3.length];
                        for (int i2 = 0; i2 < strings3.length; i2++) {
                            list3[i2] = Long.valueOf(strings3[i2]).longValue();
                        }
                        extras.putLongArray(key9, list3);
                        break;
                    case 10:
                        String key10 = cmd.getNextArgRequired();
                        String value9 = cmd.getNextArgRequired();
                        String[] strings4 = value9.split(",");
                        ArrayList<Long> list4 = new ArrayList<>(strings4.length);
                        for (String str2 : strings4) {
                            list4.add(Long.valueOf(str2));
                        }
                        extras.putSerializable(key10, list4);
                        break;
                    case 11:
                        String key11 = cmd.getNextArgRequired();
                        String value10 = cmd.getNextArgRequired();
                        extras.putFloat(key11, Float.valueOf(value10).floatValue());
                        break;
                    case 12:
                        String key12 = cmd.getNextArgRequired();
                        String value11 = cmd.getNextArgRequired();
                        String[] strings5 = value11.split(",");
                        float[] list5 = new float[strings5.length];
                        for (int i3 = 0; i3 < strings5.length; i3++) {
                            list5[i3] = Float.valueOf(strings5[i3]).floatValue();
                        }
                        extras.putFloatArray(key12, list5);
                        break;
                    case 13:
                        String key13 = cmd.getNextArgRequired();
                        String value12 = cmd.getNextArgRequired();
                        String[] strings6 = value12.split(",");
                        ArrayList<Float> list6 = new ArrayList<>(strings6.length);
                        for (String str3 : strings6) {
                            list6.add(Float.valueOf(str3));
                        }
                        extras.putSerializable(key13, list6);
                        break;
                    case 14:
                        String key14 = cmd.getNextArgRequired();
                        String value13 = cmd.getNextArgRequired();
                        extras.putStringArray(key14, value13.split("(?<!\\\\),"));
                        break;
                    case 15:
                        String key15 = cmd.getNextArgRequired();
                        String value14 = cmd.getNextArgRequired();
                        String[] strings7 = value14.split("(?<!\\\\),");
                        ArrayList<String> list7 = new ArrayList<>(strings7.length);
                        for (String str4 : strings7) {
                            list7.add(str4);
                        }
                        extras.putStringArrayList(key15, list7);
                        break;
                    case 16:
                        String key16 = cmd.getNextArgRequired();
                        String value15 = cmd.getNextArgRequired().toLowerCase();
                        if ("true".equals(value15) || "t".equals(value15)) {
                            arg = true;
                        } else if ("false".equals(value15) || "f".equals(value15)) {
                            arg = false;
                        } else {
                            try {
                                if (Integer.decode(value15).intValue() != 0) {
                                    arg = true;
                                }
                            } catch (NumberFormatException e) {
                                throw new IllegalArgumentException("Invalid boolean value: " + value15);
                            }
                        }
                        extras.putBoolean(key16, arg);
                        break;
                }
            } else {
                return extras;
            }
        }
    }
}
