package com.android.server.backup.encryption.chunking;

import com.android.internal.util.Preconditions;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
final class ByteRange {
    private final long mEnd;
    private final long mStart;

    ByteRange(long start, long end) {
        Preconditions.checkArgument(start >= 0);
        Preconditions.checkArgument(end >= start);
        this.mStart = start;
        this.mEnd = end;
    }

    long getStart() {
        return this.mStart;
    }

    long getEnd() {
        return this.mEnd;
    }

    int getLength() {
        return (int) ((this.mEnd - this.mStart) + 1);
    }

    ByteRange extend(long length) {
        Preconditions.checkArgument(length > 0);
        return new ByteRange(this.mStart, this.mEnd + length);
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ByteRange)) {
            return false;
        }
        ByteRange byteRange = (ByteRange) o;
        return this.mEnd == byteRange.mEnd && this.mStart == byteRange.mStart;
    }

    public int hashCode() {
        long j = this.mStart;
        int result = (17 * 31) + ((int) (j ^ (j >>> 32)));
        long j2 = this.mEnd;
        return (result * 31) + ((int) (j2 ^ (j2 >>> 32)));
    }

    public String toString() {
        return String.format("ByteRange{mStart=%d, mEnd=%d}", Long.valueOf(this.mStart), Long.valueOf(this.mEnd));
    }
}
