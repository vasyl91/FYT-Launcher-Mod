package com.android.server.am;

import android.app.ActivityManager;
import android.app.ProcessInfo;
import android.content.ComponentName;
import android.content.Intent;
import android.hardware.biometrics.face.V1_0.FaceAcquiredInfo;
import android.media.AudioManagerInternal;
import android.net.INetd;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManagerInternal;
import android.os.Process;
import android.os.RemoteException;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.Trace;
import android.os.UserHandle;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.ArraySet;
import android.util.Slog;
import android.util.proto.ProtoOutputStream;
import com.android.internal.annotations.GuardedBy;
import com.android.internal.annotations.VisibleForTesting;
import com.android.server.BatteryService;
import com.android.server.LocalServices;
import com.android.server.ServiceThread;
import com.android.server.SystemService;
import com.android.server.connectivity.NetworkAgentInfo;
import com.android.server.performance.policy.oomadj.OomAdjConstants;
import com.android.server.pm.DumpState;
import com.android.server.usage.AppStandbyController;
import com.android.server.wm.ActivityServiceConnectionsHolder;
import com.android.server.wm.ActivityTaskManagerDebugConfig;
import com.android.server.wm.WindowProcessController;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class OomAdjuster {
    static final String OOM_ADJ_REASON_ACTIVITY = "updateOomAdj_activityChange";
    static final String OOM_ADJ_REASON_BIND_SERVICE = "updateOomAdj_bindService";
    static final String OOM_ADJ_REASON_FINISH_RECEIVER = "updateOomAdj_finishReceiver";
    static final String OOM_ADJ_REASON_GET_PROVIDER = "updateOomAdj_getProvider";
    static final String OOM_ADJ_REASON_METHOD = "updateOomAdj";
    static final String OOM_ADJ_REASON_NONE = "updateOomAdj_meh";
    static final String OOM_ADJ_REASON_PROCESS_BEGIN = "updateOomAdj_processBegin";
    static final String OOM_ADJ_REASON_PROCESS_END = "updateOomAdj_processEnd";
    static final String OOM_ADJ_REASON_REMOVE_PROVIDER = "updateOomAdj_removeProvider";
    static final String OOM_ADJ_REASON_START_RECEIVER = "updateOomAdj_startReceiver";
    static final String OOM_ADJ_REASON_START_SERVICE = "updateOomAdj_startService";
    static final String OOM_ADJ_REASON_UI_VISIBILITY = "updateOomAdj_uiVisibility";
    static final String OOM_ADJ_REASON_UNBIND_SERVICE = "updateOomAdj_unbindService";
    static final String OOM_ADJ_REASON_WHITELIST = "updateOomAdj_whitelistChange";
    private static final String TAG = "OomAdjuster";
    ActiveUids mActiveUids;
    AppCompactor mAppCompact;
    ActivityManagerConstants mConstants;
    private final Handler mProcessGroupHandler;
    private final ProcessList mProcessList;
    private final ActivityManagerService mService;
    final long[] mTmpLong = new long[3];
    int mAdjSeq = 0;
    int mNumServiceProcs = 0;
    int mNewNumAServiceProcs = 0;
    int mNewNumServiceProcs = 0;
    int mNumNonCachedProcs = 0;
    int mNumCachedHiddenProcs = 0;
    private final ArraySet<BroadcastQueue> mTmpBroadcastQueue = new ArraySet<>();
    private final ComputeOomAdjWindowCallback mTmpComputeOomAdjWindowCallback = new ComputeOomAdjWindowCallback();
    private Map<String, Integer> packageList = null;
    private Object pkgLock = new Object();
    PowerManagerInternal mLocalPowerManager = (PowerManagerInternal) LocalServices.getService(PowerManagerInternal.class);

    OomAdjuster(ActivityManagerService service, ProcessList processList, ActiveUids activeUids) {
        this.mService = service;
        this.mProcessList = processList;
        this.mActiveUids = activeUids;
        this.mConstants = this.mService.mConstants;
        this.mAppCompact = new AppCompactor(this.mService);
        ServiceThread adjusterThread = new ServiceThread(TAG, -10, false);
        adjusterThread.start();
        Process.setThreadGroupAndCpuset(adjusterThread.getThreadId(), 5);
        this.mProcessGroupHandler = new Handler(adjusterThread.getLooper(), new Handler.Callback() { // from class: com.android.server.am.-$$Lambda$OomAdjuster$OVkqAAacT5-taN3pgDzyZj3Ymvk
            @Override // android.os.Handler.Callback
            public final boolean handleMessage(Message message) {
                return OomAdjuster.lambda$new$0(message);
            }
        });
    }

    static /* synthetic */ boolean lambda$new$0(Message msg) {
        Trace.traceBegin(64L, "setProcessGroup");
        int pid = msg.arg1;
        int group = msg.arg2;
        try {
            try {
                Process.setProcessGroup(pid, group);
            } catch (Exception e) {
                if (ActivityManagerDebugConfig.DEBUG_ALL) {
                    Slog.w(TAG, "Failed setting process group of " + pid + " to " + group, e);
                }
            }
            return true;
        } finally {
            Trace.traceEnd(64L);
        }
    }

    void initSettings() {
        this.mAppCompact.init();
    }

    @GuardedBy({"mService"})
    boolean updateOomAdjLocked(ProcessRecord app, boolean oomAdjAll, String oomAdjReason) {
        ProcessRecord TOP_APP = this.mService.getTopAppLocked();
        boolean wasCached = app.cached;
        this.mAdjSeq++;
        int cachedAdj = app.getCurRawAdj() >= 900 ? app.getCurRawAdj() : 1001;
        boolean success = updateOomAdjLocked(app, cachedAdj, TOP_APP, false, SystemClock.uptimeMillis());
        if (oomAdjAll && (wasCached != app.cached || app.getCurRawAdj() == 1001)) {
            updateOomAdjLocked(oomAdjReason);
        }
        return success;
    }

    @GuardedBy({"mService"})
    private final boolean updateOomAdjLocked(ProcessRecord app, int cachedAdj, ProcessRecord TOP_APP, boolean doingAll, long now) {
        if (app.thread == null) {
            return false;
        }
        computeOomAdjLocked(app, cachedAdj, TOP_APP, doingAll, now, false);
        ProcessInfo info = this.mService.createProcessInfo(app);
        long elapsed = SystemClock.elapsedRealtime();
        ActivityManagerService activityManagerService = this.mService;
        int tunningResult = activityManagerService.processLmkAdjTunningIfneeded(info, activityManagerService.mLastMemoryLevel, now, elapsed);
        if (tunningResult != 2) {
            return true;
        }
        return applyOomAdjLocked(app, doingAll, now, elapsed);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v1 */
    /* JADX WARN: Type inference failed for: r11v11 */
    /* JADX WARN: Type inference failed for: r11v12 */
    /* JADX WARN: Type inference failed for: r11v2 */
    /* JADX WARN: Type inference failed for: r11v4 */
    /* JADX WARN: Type inference failed for: r11v5 */
    /* JADX WARN: Type inference failed for: r11v8 */
    /* JADX WARN: Type inference failed for: r2v23 */
    /* JADX WARN: Type inference failed for: r2v5 */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r3v21 */
    /* JADX WARN: Type inference failed for: r3v22 */
    /* JADX WARN: Type inference failed for: r3v28 */
    /* JADX WARN: Type inference failed for: r3v29 */
    /* JADX WARN: Type inference failed for: r3v32 */
    /* JADX WARN: Type inference failed for: r3v46 */
    /* JADX WARN: Type inference failed for: r3v70 */
    /* JADX WARN: Type inference failed for: r3v71 */
    /* JADX WARN: Type inference failed for: r4v27 */
    /* JADX WARN: Type inference failed for: r4v28 */
    /* JADX WARN: Type inference failed for: r4v30 */
    /* JADX WARN: Type inference failed for: r4v31 */
    /* JADX WARN: Type inference failed for: r4v33 */
    /* JADX WARN: Type inference failed for: r4v37 */
    /* JADX WARN: Type inference failed for: r4v40 */
    /* JADX WARN: Type inference failed for: r4v74 */
    /* JADX WARN: Type inference failed for: r4v75 */
    /* JADX WARN: Type inference failed for: r4v8 */
    /* JADX WARN: Type inference failed for: r4v9 */
    /* JADX WARN: Type inference failed for: r9v11 */
    /* JADX WARN: Type inference failed for: r9v14 */
    /* JADX WARN: Type inference failed for: r9v15 */
    /* JADX WARN: Type inference failed for: r9v7 */
    /* JADX WARN: Type inference failed for: r9v8 */
    /* JADX WARN: Type inference failed for: r9v9 */
    @GuardedBy({"mService"})
    void updateOomAdjLocked(String str) {
        int i;
        int i2;
        boolean z;
        int i3;
        int i4;
        int i5;
        ProcessRecord processRecord;
        int i6;
        int i7;
        ?? r9;
        int i8;
        ?? r4;
        ProcessRecord processRecord2;
        ?? r5;
        ?? r3;
        int i9;
        ?? r11;
        ?? r6;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        boolean z2;
        int i17;
        int i18;
        int i19;
        int i20;
        long j;
        int i21;
        int i22;
        boolean z3;
        int i23;
        int i24;
        int i25;
        int i26;
        int i27;
        int i28;
        boolean z4;
        int i29;
        int i30;
        Trace.traceBegin(64L, str);
        this.mService.mOomAdjProfiler.oomAdjStarted();
        ProcessRecord topAppLocked = this.mService.getTopAppLocked();
        long jUptimeMillis = SystemClock.uptimeMillis();
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        long j2 = jUptimeMillis - 1800000;
        int lruSizeLocked = this.mProcessList.getLruSizeLocked();
        for (int size = this.mActiveUids.size() - 1; size >= 0; size--) {
            this.mActiveUids.valueAt(size).reset();
        }
        if (this.mService.mAtmInternal != null) {
            this.mService.mAtmInternal.rankTaskLayersIfNeeded();
        }
        this.mAdjSeq++;
        boolean z5 = false;
        this.mNewNumServiceProcs = 0;
        this.mNewNumAServiceProcs = 0;
        int i31 = this.mConstants.CUR_MAX_EMPTY_PROCESSES;
        int i32 = this.mConstants.CUR_MAX_CACHED_PROCESSES - i31;
        int i33 = (lruSizeLocked - this.mNumNonCachedProcs) - this.mNumCachedHiddenProcs;
        if (i33 <= i32) {
            i = i33;
        } else {
            i = i32;
        }
        int i34 = ((i + 10) - 1) / 10;
        if (i34 < 1) {
            i34 = 1;
        }
        int i35 = this.mNumCachedHiddenProcs;
        int i36 = (i35 > 0 ? (i35 + 10) - 1 : 1) / 10;
        if (i36 < 1) {
            i36 = 1;
        }
        int i37 = -1;
        int i38 = -1;
        int i39 = 0;
        this.mNumNonCachedProcs = 0;
        this.mNumCachedHiddenProcs = 0;
        int i40 = 900 + 10;
        int i41 = 0;
        int i42 = 905 + 10;
        boolean z6 = false;
        int i43 = lruSizeLocked - 1;
        while (true) {
            i2 = i31;
            if (i43 < 0) {
                break;
            }
            ProcessRecord processRecord3 = this.mProcessList.mLruProcesses.get(i43);
            processRecord3.containsCycle = false;
            processRecord3.setCurRawProcState(20);
            processRecord3.setCurRawAdj(NetworkAgentInfo.EVENT_NETWORK_LINGER_COMPLETE);
            i43--;
            i31 = i2;
        }
        int i44 = lruSizeLocked - 1;
        int i45 = 0;
        int i46 = 0;
        int i47 = 0;
        int i48 = 900;
        int i49 = i40;
        int i50 = 905;
        int i51 = i42;
        while (i44 >= 0) {
            ProcessRecord processRecord4 = this.mProcessList.mLruProcesses.get(i44);
            if (processRecord4.killedByAm || processRecord4.thread == null) {
                i20 = i32;
                j = jElapsedRealtime;
                i21 = i;
                i22 = i2;
                z3 = false;
                i23 = lruSizeLocked;
                i24 = i34;
                i51 = i51;
                i49 = i49;
                i48 = i48;
                i45 = i45;
                i47 = i47;
                i46 = i46;
                i50 = i50;
            } else {
                processRecord4.procStateChanged = false;
                int i52 = i34;
                i20 = i32;
                i22 = i2;
                z3 = false;
                int i53 = i50;
                j = jElapsedRealtime;
                i21 = i;
                i23 = lruSizeLocked;
                computeOomAdjLocked(processRecord4, NetworkAgentInfo.EVENT_NETWORK_LINGER_COMPLETE, topAppLocked, true, jUptimeMillis, false);
                boolean z7 = z6 | processRecord4.containsCycle;
                if (processRecord4.curAdj < 1001) {
                    i24 = i52;
                    z6 = z7;
                    i50 = i53;
                } else {
                    switch (processRecord4.getCurProcState()) {
                        case 17:
                        case 18:
                        case FaceAcquiredInfo.FACE_OBSCURED /* 19 */:
                            boolean z8 = false;
                            if (processRecord4.connectionGroup == 0) {
                                i25 = i47;
                                i26 = i45;
                                i27 = i46;
                                i48 = i48;
                                i49 = i49;
                            } else {
                                int i54 = i47;
                                if (i54 == processRecord4.uid && (i26 = i45) == processRecord4.connectionGroup) {
                                    i25 = i54;
                                    int i55 = i46;
                                    if (processRecord4.connectionImportance <= i55) {
                                        i48 = i48;
                                        i49 = i49;
                                        i28 = i55;
                                    } else {
                                        int i56 = processRecord4.connectionImportance;
                                        int i57 = i48;
                                        i49 = i49;
                                        if (i57 < i49 && i57 < 999) {
                                            i41++;
                                            i28 = i56;
                                            i48 = i57;
                                        } else {
                                            i28 = i56;
                                            i48 = i57;
                                        }
                                    }
                                    z8 = true;
                                    i27 = i28;
                                } else {
                                    int i58 = processRecord4.uid;
                                    i26 = processRecord4.connectionGroup;
                                    i27 = processRecord4.connectionImportance;
                                    i25 = i58;
                                }
                            }
                            if (!z8 && i48 != i49) {
                                int i59 = i37 + 1;
                                i41 = 0;
                                if (i59 < i36) {
                                    i37 = i59;
                                    i48 = i48;
                                } else {
                                    i37 = 0;
                                    i48 = i49;
                                    int i60 = i49 + 10;
                                    if (i60 <= 999) {
                                        i49 = i60;
                                    } else {
                                        i49 = 999;
                                    }
                                }
                            } else {
                                i48 = i48;
                            }
                            processRecord4.setCurRawAdj(i48 + i41);
                            processRecord4.curAdj = processRecord4.modifyRawOomAdj(i48 + i41);
                            boolean z9 = ActivityManagerDebugConfig.DEBUG_LRU;
                            z6 = z7;
                            i49 = i49;
                            i45 = i26;
                            i46 = i27;
                            i47 = i25;
                            i24 = i52;
                            i50 = i53;
                            break;
                        default:
                            int i61 = i47;
                            int i62 = i45;
                            int i63 = i46;
                            int i64 = i48;
                            int i65 = i49;
                            int i66 = i51;
                            if (i53 == i66) {
                                z4 = z7;
                                i29 = i63;
                                i24 = i52;
                                i30 = i53;
                            } else {
                                z4 = z7;
                                int i67 = i38 + 1;
                                i29 = i63;
                                i24 = i52;
                                if (i67 < i24) {
                                    i38 = i67;
                                    i30 = i53;
                                } else {
                                    i38 = 0;
                                    i30 = i66;
                                    i66 += 10;
                                    if (i66 > 999) {
                                        i66 = 999;
                                    }
                                }
                            }
                            processRecord4.setCurRawAdj(i30);
                            processRecord4.curAdj = processRecord4.modifyRawOomAdj(i30);
                            boolean z10 = ActivityManagerDebugConfig.DEBUG_LRU;
                            i51 = i66;
                            i49 = i65;
                            i48 = i64;
                            i45 = i62;
                            i47 = i61;
                            z6 = z4;
                            i46 = i29;
                            i50 = i30;
                            break;
                    }
                }
            }
            i44--;
            i34 = i24;
            lruSizeLocked = i23;
            i = i21;
            z5 = z3;
            jElapsedRealtime = j;
            i32 = i20;
            i2 = i22;
        }
        int i68 = i32;
        boolean z11 = z5;
        int i69 = i50;
        long j3 = jElapsedRealtime;
        int i70 = i2;
        int i71 = i51;
        int i72 = i47;
        int i73 = i45;
        int i74 = i46;
        int i75 = i48;
        int i76 = i49;
        int i77 = lruSizeLocked;
        int i78 = i34;
        int i79 = 0;
        while (z6 && i79 < 10) {
            int i80 = i79 + 1;
            boolean z12 = false;
            int i81 = 0;
            while (i81 < i77) {
                boolean z13 = z12;
                ProcessRecord processRecord5 = this.mProcessList.mLruProcesses.get(i81);
                int i82 = i71;
                if (processRecord5.killedByAm || processRecord5.thread == null) {
                    i19 = i78;
                } else {
                    i19 = i78;
                    if (processRecord5.containsCycle) {
                        processRecord5.adjSeq--;
                        processRecord5.completedAdjSeq--;
                    }
                }
                i81++;
                z12 = z13;
                i71 = i82;
                i78 = i19;
            }
            int i83 = i71;
            int i84 = i78;
            boolean z14 = true;
            int i85 = 0;
            z6 = z12;
            while (i85 < i77) {
                ProcessRecord processRecord6 = this.mProcessList.mLruProcesses.get(i85);
                if (processRecord6.killedByAm || processRecord6.thread == null || processRecord6.containsCycle != z14) {
                    i10 = i85;
                    i11 = i69;
                    i12 = i76;
                    i13 = i75;
                    i14 = i73;
                    i15 = i80;
                    i16 = i74;
                    z2 = z14;
                    i17 = i72;
                    i18 = i84;
                } else {
                    i10 = i85;
                    i11 = i69;
                    i12 = i76;
                    i13 = i75;
                    i14 = i73;
                    i15 = i80;
                    i16 = i74;
                    z2 = z14;
                    i17 = i72;
                    i18 = i84;
                    if (computeOomAdjLocked(processRecord6, processRecord6.getCurRawAdj(), topAppLocked, true, jUptimeMillis, true)) {
                        z6 = true;
                    }
                }
                i85 = i10 + 1;
                z14 = z2;
                i84 = i18;
                i69 = i11;
                i72 = i17;
                i80 = i15;
                i73 = i14;
                i74 = i16;
                i75 = i13;
                i76 = i12;
            }
            i78 = i84;
            i71 = i83;
            i72 = i72;
            i79 = i80;
            i74 = i74;
        }
        int i86 = i77 - 1;
        ?? r2 = z11;
        ?? r7 = z11;
        int i87 = 0;
        int i88 = 0;
        int i89 = 0;
        while (i86 >= 0) {
            ProcessRecord processRecord7 = this.mProcessList.mLruProcesses.get(i86);
            if (processRecord7.killedByAm || processRecord7.thread == null) {
                i4 = i89;
                i5 = i77;
                processRecord = topAppLocked;
                i6 = i36;
                i7 = i68;
                r9 = r2;
                i8 = i70;
                r4 = r7 == true ? 1 : 0;
                i87 = i87;
                i88 = i88;
            } else {
                ProcessInfo processInfoCreateProcessInfo = this.mService.createProcessInfo(processRecord7);
                ActivityManagerService activityManagerService = this.mService;
                i5 = i77;
                ?? r10 = r2;
                i4 = i89;
                ?? r12 = r7;
                processRecord = topAppLocked;
                i6 = i36;
                int i90 = i87;
                int i91 = i88;
                if (activityManagerService.processLmkAdjTunningIfneeded(processInfoCreateProcessInfo, activityManagerService.mLastMemoryLevel, jUptimeMillis, j3) == 2) {
                    applyOomAdjLocked(processRecord7, true, jUptimeMillis, j3);
                }
                int curProcState = processRecord7.getCurProcState();
                if (curProcState == 17 || curProcState == 18) {
                    processRecord2 = processRecord7;
                    i8 = i70;
                    this.mNumCachedHiddenProcs++;
                    int i92 = i90 + 1;
                    if (processRecord2.connectionGroup != 0) {
                        if (r10 == processRecord2.info.uid && r12 == processRecord2.connectionGroup) {
                            i39++;
                            r3 = r10 == true ? 1 : 0;
                            r5 = r12 == true ? 1 : 0;
                        } else {
                            r3 = processRecord2.info.uid;
                            r5 = processRecord2.connectionGroup;
                        }
                    } else {
                        r5 = z11;
                        r3 = z11;
                    }
                    i9 = i68;
                    if (i92 - i39 > i9) {
                        processRecord2.kill("cached #" + i92, true);
                    }
                    r11 = r5;
                    i90 = i92;
                    r6 = r3;
                } else {
                    if (curProcState != 20) {
                        this.mNumNonCachedProcs++;
                        processRecord2 = processRecord7;
                    } else {
                        if (i91 <= this.mConstants.CUR_TRIM_EMPTY_PROCESSES) {
                            processRecord2 = processRecord7;
                        } else {
                            processRecord2 = processRecord7;
                            if (processRecord2.lastActivityTime < j2 && processRecord2.info != null && !this.mService.keepImpAppAlive(processRecord2.info.packageName)) {
                                processRecord2.kill("empty for " + (((j2 + 1800000) - processRecord2.lastActivityTime) / 1000) + "s", true);
                            }
                        }
                        int i93 = i91 + 1;
                        i8 = i70;
                        if (i93 > i8 && processRecord2.info != null && !this.mService.keepImpAppAlive(processRecord2.info.packageName)) {
                            processRecord2.kill("empty #" + i93, true);
                        }
                        i91 = i93;
                        r6 = r10 == true ? 1 : 0;
                        i9 = i68;
                        r11 = r12;
                    }
                    r6 = r10 == true ? 1 : 0;
                    i9 = i68;
                    i8 = i70;
                    r11 = r12;
                }
                if (processRecord2.isolated && processRecord2.services.size() <= 0 && processRecord2.isolatedEntryPoint == null) {
                    processRecord2.kill("isolated not needed", true);
                } else {
                    UidRecord uidRecord = processRecord2.uidRecord;
                    if (uidRecord != null) {
                        uidRecord.ephemeral = processRecord2.info.isInstantApp();
                        if (uidRecord.getCurProcState() > processRecord2.getCurProcState()) {
                            uidRecord.setCurProcState(processRecord2.getCurProcState());
                        }
                        if (processRecord2.hasForegroundServices()) {
                            uidRecord.foregroundServices = true;
                        }
                    }
                }
                if (processRecord2.getCurProcState() < 15 || processRecord2.killedByAm) {
                    r4 = r11;
                    i87 = i90;
                    i88 = i91;
                    int i94 = i9;
                    r9 = r6;
                    i7 = i94;
                } else {
                    i4++;
                    r4 = r11;
                    i87 = i90;
                    i88 = i91;
                    int i95 = i9;
                    r9 = r6;
                    i7 = i95;
                }
            }
            i86--;
            i70 = i8;
            i68 = i7;
            r2 = r9;
            i89 = i4;
            i77 = i5;
            topAppLocked = processRecord;
            i36 = i6;
            r7 = r4;
        }
        int i96 = i89;
        int i97 = i68;
        int i98 = i70;
        this.mService.incrementProcStateSeqAndNotifyAppsLocked();
        this.mNumServiceProcs = this.mNewNumServiceProcs;
        boolean zUpdateLowMemStateLocked = this.mService.updateLowMemStateLocked(i87, i88, i96);
        if (this.mService.mAlwaysFinishActivities) {
            this.mService.mAtmInternal.scheduleDestroyAllActivities("always-finish");
        }
        if (zUpdateLowMemStateLocked) {
            ActivityManagerService activityManagerService2 = this.mService;
            activityManagerService2.requestPssAllProcsLocked(jUptimeMillis, z11, activityManagerService2.mProcessStats.isMemFactorLowered());
        }
        ArrayList<UidRecord> arrayList = null;
        PowerManagerInternal powerManagerInternal = this.mLocalPowerManager;
        if (powerManagerInternal != null) {
            powerManagerInternal.startUidChanges();
        }
        int size2 = this.mActiveUids.size() - 1;
        while (size2 >= 0) {
            UidRecord uidRecordValueAt = this.mActiveUids.valueAt(size2);
            int i99 = 0;
            boolean z15 = zUpdateLowMemStateLocked;
            if (uidRecordValueAt.getCurProcState() == 21) {
                i98 = i98;
                i97 = i97;
            } else if (uidRecordValueAt.setProcState == uidRecordValueAt.getCurProcState() && uidRecordValueAt.setWhitelist == uidRecordValueAt.curWhitelist) {
                i98 = i98;
                i97 = i97;
            } else {
                if (ActivityManagerDebugConfig.DEBUG_UID_OBSERVERS) {
                    Slog.i("ActivityManager", "Changes in " + uidRecordValueAt + ": proc state from " + uidRecordValueAt.setProcState + " to " + uidRecordValueAt.getCurProcState() + ", whitelist from " + uidRecordValueAt.setWhitelist + " to " + uidRecordValueAt.curWhitelist);
                }
                if (!ActivityManager.isProcStateBackground(uidRecordValueAt.getCurProcState()) || uidRecordValueAt.curWhitelist) {
                    i97 = i97;
                    if (!uidRecordValueAt.idle) {
                        z = false;
                    } else {
                        i99 = 4;
                        EventLogTags.writeAmUidActive(uidRecordValueAt.uid);
                        z = false;
                        uidRecordValueAt.idle = false;
                    }
                    uidRecordValueAt.lastBackgroundTime = 0L;
                } else {
                    if (!ActivityManager.isProcStateBackground(uidRecordValueAt.setProcState) || uidRecordValueAt.setWhitelist) {
                        long j4 = j3;
                        uidRecordValueAt.lastBackgroundTime = j4;
                        if (this.mService.mHandler.hasMessages(58)) {
                            j3 = j4;
                        } else {
                            j3 = j4;
                            this.mService.mHandler.sendEmptyMessageDelayed(58, this.mConstants.BACKGROUND_SETTLE_TIME);
                        }
                    }
                    if (uidRecordValueAt.idle && !uidRecordValueAt.setIdle) {
                        i99 = 2;
                        if (arrayList == null) {
                            arrayList = new ArrayList<>();
                        }
                        arrayList.add(uidRecordValueAt);
                        z = false;
                    } else {
                        z = false;
                    }
                }
                boolean z16 = uidRecordValueAt.setProcState > 12 ? true : z;
                boolean z17 = uidRecordValueAt.getCurProcState() > 12 ? true : z;
                if (z16 != z17 || uidRecordValueAt.setProcState == 21) {
                    i3 = i99 | (z17 ? 8 : 16);
                } else {
                    i3 = i99;
                }
                uidRecordValueAt.setProcState = uidRecordValueAt.getCurProcState();
                uidRecordValueAt.setWhitelist = uidRecordValueAt.curWhitelist;
                uidRecordValueAt.setIdle = uidRecordValueAt.idle;
                ArrayList<UidRecord> arrayList2 = arrayList;
                this.mService.mAtmInternal.onUidProcStateChanged(uidRecordValueAt.uid, uidRecordValueAt.setProcState);
                this.mService.enqueueUidChangeLocked(uidRecordValueAt, -1, i3);
                this.mService.noteUidProcessState(uidRecordValueAt.uid, uidRecordValueAt.getCurProcState());
                if (uidRecordValueAt.foregroundServices) {
                    this.mService.mServices.foregroundServiceProcStateChangedLocked(uidRecordValueAt);
                }
                arrayList = arrayList2;
            }
            size2--;
            zUpdateLowMemStateLocked = z15;
            i97 = i97;
            i98 = i98;
        }
        PowerManagerInternal powerManagerInternal2 = this.mLocalPowerManager;
        if (powerManagerInternal2 != null) {
            powerManagerInternal2.finishUidChanges();
        }
        if (arrayList != null) {
            for (int size3 = arrayList.size() - 1; size3 >= 0; size3--) {
                this.mService.mServices.stopInBackgroundLocked(arrayList.get(size3).uid);
            }
        }
        if (this.mService.mProcessStats.shouldWriteNowLocked(jUptimeMillis)) {
            ActivityManagerService.MainHandler mainHandler = this.mService.mHandler;
            ActivityManagerService activityManagerService3 = this.mService;
            mainHandler.post(new ActivityManagerService.ProcStatsRunnable(activityManagerService3, activityManagerService3.mProcessStats));
        }
        this.mService.mProcessStats.updateTrackingAssociationsLocked(this.mAdjSeq, jUptimeMillis);
        if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ) {
            Slog.d("ActivityManager", "Did OOM ADJ in " + (SystemClock.uptimeMillis() - jUptimeMillis) + "ms");
        }
        this.mService.mOomAdjProfiler.oomAdjEnded();
        Trace.traceEnd(64L);
    }

    private final class ComputeOomAdjWindowCallback implements WindowProcessController.ComputeOomAdjCallback {
        int adj;
        ProcessRecord app;
        int appUid;
        boolean foregroundActivities;
        int logUid;
        int procState;
        int processStateCurTop;
        int schedGroup;

        private ComputeOomAdjWindowCallback() {
        }

        void initialize(ProcessRecord app, int adj, boolean foregroundActivities, int procState, int schedGroup, int appUid, int logUid, int processStateCurTop) {
            this.app = app;
            this.adj = adj;
            this.foregroundActivities = foregroundActivities;
            this.procState = procState;
            this.schedGroup = schedGroup;
            this.appUid = appUid;
            this.logUid = logUid;
            this.processStateCurTop = processStateCurTop;
        }

        public void onVisibleActivity() {
            if (this.adj > 100) {
                this.adj = 100;
                this.app.adjType = "vis-activity";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || this.logUid == this.appUid) {
                    OomAdjuster.this.reportOomAdjMessageLocked("ActivityManager", "Raise adj to vis-activity: " + this.app);
                }
            }
            int i = this.procState;
            int i2 = this.processStateCurTop;
            if (i > i2) {
                this.procState = i2;
                this.app.adjType = "vis-activity";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || this.logUid == this.appUid) {
                    OomAdjuster.this.reportOomAdjMessageLocked("ActivityManager", "Raise procstate to vis-activity (top): " + this.app);
                }
            }
            if (this.schedGroup < 2) {
                this.schedGroup = 2;
            }
            ProcessRecord processRecord = this.app;
            processRecord.cached = false;
            processRecord.empty = false;
            this.foregroundActivities = true;
        }

        public void onPausedActivity() {
            if (this.adj > 200) {
                this.adj = 200;
                this.app.adjType = "pause-activity";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || this.logUid == this.appUid) {
                    OomAdjuster.this.reportOomAdjMessageLocked("ActivityManager", "Raise adj to pause-activity: " + this.app);
                }
            }
            int i = this.procState;
            int i2 = this.processStateCurTop;
            if (i > i2) {
                this.procState = i2;
                this.app.adjType = "pause-activity";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || this.logUid == this.appUid) {
                    OomAdjuster.this.reportOomAdjMessageLocked("ActivityManager", "Raise procstate to pause-activity (top): " + this.app);
                }
            }
            if (this.schedGroup < 2) {
                this.schedGroup = 2;
            }
            ProcessRecord processRecord = this.app;
            processRecord.cached = false;
            processRecord.empty = false;
            this.foregroundActivities = true;
        }

        public void onStoppingActivity(boolean finishing) {
            if (this.adj > 200) {
                this.adj = 200;
                this.app.adjType = "stop-activity";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || this.logUid == this.appUid) {
                    OomAdjuster.this.reportOomAdjMessageLocked("ActivityManager", "Raise adj to stop-activity: " + this.app);
                }
            }
            if (!finishing && this.procState > 16) {
                this.procState = 16;
                this.app.adjType = "stop-activity";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || this.logUid == this.appUid) {
                    OomAdjuster.this.reportOomAdjMessageLocked("ActivityManager", "Raise procstate to stop-activity: " + this.app);
                }
            }
            ProcessRecord processRecord = this.app;
            processRecord.cached = false;
            processRecord.empty = false;
            this.foregroundActivities = true;
        }

        public void onOtherActivity() {
            if (this.procState > 17) {
                this.procState = 17;
                this.app.adjType = "cch-act";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || this.logUid == this.appUid) {
                    OomAdjuster.this.reportOomAdjMessageLocked("ActivityManager", "Raise procstate to cached activity: " + this.app);
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:336:0x078e  */
    /* JADX WARN: Code duplicated, block: B:346:0x07b0  */
    /* JADX WARN: Code duplicated, block: B:348:0x07b6  */
    /* JADX WARN: Code duplicated, block: B:350:0x07ba  */
    /* JADX WARN: Code duplicated, block: B:351:0x07be  */
    /* JADX WARN: Code duplicated, block: B:352:0x07cd  */
    /* JADX WARN: Code duplicated, block: B:354:0x07d3  */
    /* JADX WARN: Code duplicated, block: B:359:0x07e0  */
    /* JADX WARN: Code duplicated, block: B:361:0x07e7  */
    /* JADX WARN: Code duplicated, block: B:363:0x07eb A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:365:0x07f3  */
    /* JADX WARN: Code duplicated, block: B:367:0x07f7  */
    /* JADX WARN: Code duplicated, block: B:368:0x07fb  */
    /* JADX WARN: Code duplicated, block: B:370:0x07ff  */
    /* JADX WARN: Code duplicated, block: B:371:0x0804  */
    /* JADX WARN: Code duplicated, block: B:374:0x080d  */
    /* JADX WARN: Code duplicated, block: B:376:0x0812  */
    /* JADX WARN: Code duplicated, block: B:377:0x081d  */
    /* JADX WARN: Code duplicated, block: B:378:0x0820  */
    /* JADX WARN: Code duplicated, block: B:382:0x082f  */
    /* JADX WARN: Code duplicated, block: B:384:0x0835  */
    /* JADX WARN: Code duplicated, block: B:386:0x083d  */
    /* JADX WARN: Code duplicated, block: B:387:0x083f  */
    /* JADX WARN: Code duplicated, block: B:388:0x0841  */
    /* JADX WARN: Code duplicated, block: B:391:0x0848  */
    /* JADX WARN: Code duplicated, block: B:393:0x0850  */
    /* JADX WARN: Code duplicated, block: B:394:0x0852  */
    /* JADX WARN: Code duplicated, block: B:397:0x085e  */
    /* JADX WARN: Code duplicated, block: B:398:0x0863  */
    /* JADX WARN: Code duplicated, block: B:400:0x086c  */
    /* JADX WARN: Code duplicated, block: B:403:0x0876  */
    /* JADX WARN: Code duplicated, block: B:405:0x0878  */
    /* JADX WARN: Code duplicated, block: B:407:0x0880  */
    /* JADX WARN: Code duplicated, block: B:409:0x0888  */
    /* JADX WARN: Code duplicated, block: B:410:0x088b  */
    /* JADX WARN: Code duplicated, block: B:412:0x0890  */
    /* JADX WARN: Code duplicated, block: B:416:0x089e  */
    /* JADX WARN: Code duplicated, block: B:418:0x08aa  */
    /* JADX WARN: Code duplicated, block: B:420:0x08ae  */
    /* JADX WARN: Code duplicated, block: B:421:0x08b4  */
    /* JADX WARN: Code duplicated, block: B:423:0x08ba  */
    /* JADX WARN: Code duplicated, block: B:424:0x08c0  */
    /* JADX WARN: Code duplicated, block: B:427:0x08c6  */
    /* JADX WARN: Code duplicated, block: B:430:0x08d2  */
    /* JADX WARN: Code duplicated, block: B:432:0x08d6  */
    /* JADX WARN: Code duplicated, block: B:434:0x08dd  */
    /* JADX WARN: Code duplicated, block: B:436:0x08e3  */
    /* JADX WARN: Code duplicated, block: B:437:0x08e9  */
    /* JADX WARN: Code duplicated, block: B:438:0x08ec  */
    /* JADX WARN: Code duplicated, block: B:441:0x08f2  */
    /* JADX WARN: Code duplicated, block: B:445:0x0900  */
    /* JADX WARN: Code duplicated, block: B:447:0x0915 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:450:0x091b  */
    /* JADX WARN: Code duplicated, block: B:451:0x0956  */
    /* JADX WARN: Instruction removed from duplicated block: B:450:0x091b, please report this as an issue */
    boolean computeOomAdjLocked(ProcessRecord app, int cachedAdj, ProcessRecord TOP_APP, boolean doingAll, long now, boolean cycleReEval) {
        int adj;
        int schedGroup;
        int adj2;
        boolean foregroundActivities;
        int schedGroup2;
        int procState;
        String str;
        int prevProcState;
        int prevAppAdj;
        int logUid;
        boolean foregroundActivities2;
        int adj3;
        int logUid2;
        int logUid3;
        long j;
        boolean z;
        int schedGroup3;
        boolean z2;
        int logUid4;
        long j2;
        String str2;
        int procState2;
        String str3;
        int schedGroup4;
        int adj4;
        int appUid;
        ContentProviderRecord cpr;
        long j3;
        int i;
        String str4;
        int logUid5;
        int appUid2;
        ContentProviderRecord cpr2;
        int logUid6;
        String str5;
        int appUid3;
        int i2;
        ArrayList<ConnectionRecord> clist;
        int conni;
        boolean foregroundActivities3;
        int is;
        ArrayMap<IBinder, ArrayList<ConnectionRecord>> serviceConnections;
        int appUid4;
        ConnectionRecord cr;
        ProcessRecord processRecord;
        String str6;
        ServiceRecord s;
        int adj5;
        ServiceRecord s2;
        String str7;
        int clientProcState;
        String adjType;
        long j4;
        int clientProcState2;
        int clientAdj;
        int schedGroup5;
        int schedGroup6;
        int clientProcState3;
        int clientProcState4;
        String adjType2;
        int curSchedGroup;
        int bestState;
        int schedGroup7;
        int newAdj;
        int newAdj2;
        int i3;
        int newAdj3;
        ProcessRecord processRecord2 = app;
        if (this.mAdjSeq == processRecord2.adjSeq) {
            if (processRecord2.adjSeq == processRecord2.completedAdjSeq) {
                return false;
            }
            processRecord2.containsCycle = true;
            return false;
        }
        if (processRecord2.thread == null) {
            processRecord2.adjSeq = this.mAdjSeq;
            processRecord2.setCurrentSchedulingGroup(0);
            processRecord2.setCurProcState(20);
            processRecord2.curAdj = 999;
            processRecord2.setCurRawAdj(999);
            processRecord2.completedAdjSeq = processRecord2.adjSeq;
            return false;
        }
        processRecord2.adjTypeCode = 0;
        processRecord2.adjSource = null;
        processRecord2.adjTarget = null;
        processRecord2.empty = false;
        processRecord2.cached = false;
        WindowProcessController wpc = app.getWindowProcessController();
        int appUid5 = processRecord2.info.uid;
        int logUid7 = this.mService.mCurOomAdjUid;
        int prevAppAdj2 = processRecord2.curAdj;
        int prevProcState2 = app.getCurProcState();
        if (processRecord2.maxAdj <= 0) {
            if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid7 == appUid5) {
                this.mService.reportOomAdjMessageLocked("ActivityManager", "Making fixed: " + processRecord2);
            }
            processRecord2.adjType = "fixed";
            processRecord2.adjSeq = this.mAdjSeq;
            processRecord2.setCurRawAdj(processRecord2.maxAdj);
            processRecord2.setHasForegroundActivities(false);
            processRecord2.setCurrentSchedulingGroup(2);
            processRecord2.setCurProcState(0);
            processRecord2.systemNoUi = true;
            if (processRecord2 == TOP_APP) {
                processRecord2.systemNoUi = false;
                processRecord2.setCurrentSchedulingGroup(3);
                processRecord2.adjType = "pers-top-activity";
            } else if (app.hasTopUi()) {
                processRecord2.systemNoUi = false;
                processRecord2.adjType = "pers-top-ui";
            } else if (wpc.hasVisibleActivities()) {
                processRecord2.systemNoUi = false;
            }
            if (!processRecord2.systemNoUi) {
                if (this.mService.mWakefulness == 1) {
                    processRecord2.setCurProcState(1);
                    processRecord2.setCurrentSchedulingGroup(3);
                } else {
                    processRecord2.setCurProcState(6);
                    processRecord2.setCurrentSchedulingGroup(1);
                }
            }
            processRecord2.setCurRawProcState(app.getCurProcState());
            processRecord2.curAdj = processRecord2.maxAdj;
            processRecord2.completedAdjSeq = processRecord2.adjSeq;
            return processRecord2.curAdj < prevAppAdj2 || app.getCurProcState() < prevProcState2;
        }
        processRecord2.systemNoUi = false;
        int PROCESS_STATE_CUR_TOP = this.mService.mAtmInternal.getTopProcessState();
        this.mTmpBroadcastQueue.clear();
        if (PROCESS_STATE_CUR_TOP == 2 && processRecord2 == TOP_APP) {
            processRecord2.adjType = "top-activity";
            if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid7 == appUid5) {
                reportOomAdjMessageLocked("ActivityManager", "Making top: " + processRecord2);
            }
            foregroundActivities = true;
            adj2 = 3;
            schedGroup = 0;
            adj = PROCESS_STATE_CUR_TOP;
        } else {
            if (processRecord2.runningRemoteAnimation) {
                schedGroup2 = 3;
                processRecord2.adjType = "running-remote-anim";
                procState = PROCESS_STATE_CUR_TOP;
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid7 == appUid5) {
                    StringBuilder sb = new StringBuilder();
                    schedGroup = 100;
                    sb.append("Making running remote anim: ");
                    sb.append(processRecord2);
                    reportOomAdjMessageLocked("ActivityManager", sb.toString());
                } else {
                    schedGroup = 100;
                }
            } else if (app.getActiveInstrumentation() != null) {
                schedGroup2 = 2;
                processRecord2.adjType = "instrumentation";
                procState = 5;
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid7 == appUid5) {
                    StringBuilder sb2 = new StringBuilder();
                    schedGroup = 0;
                    sb2.append("Making instrumentation: ");
                    sb2.append(processRecord2);
                    reportOomAdjMessageLocked("ActivityManager", sb2.toString());
                } else {
                    schedGroup = 0;
                }
            } else if (this.mService.isReceivingBroadcastLocked(processRecord2, this.mTmpBroadcastQueue)) {
                schedGroup2 = (this.mTmpBroadcastQueue.contains(this.mService.mFgBroadcastQueue) || this.mTmpBroadcastQueue.contains(this.mService.mCtsFgBroadcastQueue)) ? 2 : 0;
                processRecord2.adjType = INetd.IF_FLAG_BROADCAST;
                procState = 12;
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid7 == appUid5) {
                    StringBuilder sb3 = new StringBuilder();
                    schedGroup = 0;
                    sb3.append("Making broadcast: ");
                    sb3.append(processRecord2);
                    reportOomAdjMessageLocked("ActivityManager", sb3.toString());
                } else {
                    schedGroup = 0;
                }
            } else if (processRecord2.executingServices.size() > 0) {
                schedGroup2 = processRecord2.execServicesFg ? 2 : 0;
                processRecord2.adjType = "exec-service";
                procState = 11;
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid7 == appUid5) {
                    StringBuilder sb4 = new StringBuilder();
                    schedGroup = 0;
                    sb4.append("Making exec-service: ");
                    sb4.append(processRecord2);
                    reportOomAdjMessageLocked("ActivityManager", sb4.toString());
                } else {
                    schedGroup = 0;
                }
            } else if (processRecord2 == TOP_APP) {
                schedGroup = 0;
                processRecord2.adjType = "top-sleeping";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid7 == appUid5) {
                    reportOomAdjMessageLocked("ActivityManager", "Making top (sleeping): " + processRecord2);
                }
                adj2 = 0;
                foregroundActivities = true;
                adj = PROCESS_STATE_CUR_TOP;
            } else {
                adj = 20;
                processRecord2.cached = true;
                processRecord2.empty = true;
                processRecord2.adjType = "cch-empty";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid7 == appUid5) {
                    reportOomAdjMessageLocked("ActivityManager", "Making empty: " + processRecord2);
                }
                schedGroup = cachedAdj;
                adj2 = 0;
                foregroundActivities = false;
            }
            adj2 = schedGroup2;
            adj = procState;
            foregroundActivities = false;
        }
        if (foregroundActivities || !wpc.hasActivities()) {
            str = "ActivityManager";
            prevProcState = prevProcState2;
            prevAppAdj = prevAppAdj2;
            logUid = logUid7;
            foregroundActivities2 = foregroundActivities;
            adj3 = schedGroup;
        } else {
            str = "ActivityManager";
            prevProcState = prevProcState2;
            prevAppAdj = prevAppAdj2;
            logUid = logUid7;
            this.mTmpComputeOomAdjWindowCallback.initialize(app, schedGroup, foregroundActivities, adj, adj2, appUid5, logUid, PROCESS_STATE_CUR_TOP);
            int minLayer = wpc.computeOomAdjFromActivities(99, this.mTmpComputeOomAdjWindowCallback);
            adj3 = this.mTmpComputeOomAdjWindowCallback.adj;
            boolean foregroundActivities4 = this.mTmpComputeOomAdjWindowCallback.foregroundActivities;
            adj = this.mTmpComputeOomAdjWindowCallback.procState;
            adj2 = this.mTmpComputeOomAdjWindowCallback.schedGroup;
            if (adj3 == 100) {
                int i4 = adj3 + minLayer;
                foregroundActivities2 = foregroundActivities4;
                adj3 = i4;
            } else {
                foregroundActivities2 = foregroundActivities4;
            }
        }
        if (adj <= 19 || !app.hasRecentTasks()) {
            logUid2 = logUid;
        } else {
            adj = 19;
            processRecord2.adjType = "cch-rec";
            if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON) {
                logUid2 = logUid;
            } else {
                logUid2 = logUid;
                if (logUid2 == appUid5) {
                }
            }
            reportOomAdjMessageLocked(str, "Raise procstate to cached recent: " + processRecord2);
        }
        String str8 = ": ";
        String str9 = "Raise to ";
        if (adj3 > 200 || adj > 3) {
            if (app.hasForegroundServices()) {
                adj3 = 200;
                if (app.hasLocationForegroundServices()) {
                    processRecord2.adjType = "fg-service-location";
                    adj = 3;
                } else {
                    processRecord2.adjType = "fg-service";
                    adj = 5;
                }
                processRecord2.cached = false;
                adj2 = 2;
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise to " + processRecord2.adjType + ": " + processRecord2 + " ");
                }
            } else if (app.hasOverlayUi()) {
                adj3 = 200;
                adj = 7;
                processRecord2.cached = false;
                processRecord2.adjType = "has-overlay-ui";
                adj2 = 2;
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise to overlay ui: " + processRecord2);
                }
            }
        }
        if (app.hasForegroundServices() && adj3 > 50) {
            if (processRecord2.lastTopTime + this.mConstants.TOP_TO_FGS_GRACE_DURATION > now || processRecord2.setProcState <= 2) {
                adj3 = 50;
                processRecord2.adjType = "fg-service-act";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise to recent fg: " + processRecord2);
                }
            }
        }
        if ((adj3 > 200 || adj > 9) && processRecord2.forcingToImportant != null) {
            adj3 = 200;
            adj = 9;
            processRecord2.cached = false;
            processRecord2.adjType = "force-imp";
            processRecord2.adjSource = processRecord2.forcingToImportant;
            adj2 = 2;
            if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                reportOomAdjMessageLocked(str, "Raise to force imp: " + processRecord2);
            }
        }
        if (this.mService.mAtmInternal.isHeavyWeightProcess(app.getWindowProcessController())) {
            if (adj3 > 400) {
                adj3 = 400;
                adj2 = 0;
                processRecord2.cached = false;
                processRecord2.adjType = "heavy";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise adj to heavy: " + processRecord2);
                }
            }
            if (adj > 14) {
                adj = 14;
                processRecord2.adjType = "heavy";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise procstate to heavy: " + processRecord2);
                }
            }
        }
        if (wpc.isHomeProcess()) {
            if (adj3 > 600) {
                adj3 = SystemService.PHASE_THIRD_PARTY_APPS_CAN_START;
                adj2 = 0;
                processRecord2.cached = false;
                processRecord2.adjType = "home";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise adj to home: " + processRecord2);
                }
            }
            if (adj > 15) {
                adj = 15;
                processRecord2.adjType = "home";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise procstate to home: " + processRecord2);
                }
            }
        }
        if (wpc.isPreviousProcess() && app.hasActivities()) {
            if (adj3 > 700) {
                adj3 = 700;
                adj2 = 0;
                processRecord2.cached = false;
                processRecord2.adjType = "previous";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise adj to prev: " + processRecord2);
                }
            }
            if (adj > 16) {
                adj = 16;
                processRecord2.adjType = "previous";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise procstate to prev: " + processRecord2);
                }
            }
        }
        processRecord2.setCurRawAdj(!cycleReEval ? adj3 : Math.min(adj3, app.getCurRawAdj()));
        processRecord2.setCurRawProcState(!cycleReEval ? adj : Math.min(adj, app.getCurRawProcState()));
        processRecord2.hasStartedServices = false;
        processRecord2.adjSeq = this.mAdjSeq;
        BackupRecord backupTarget = this.mService.mBackupTargets.get(processRecord2.userId);
        if (backupTarget != null && processRecord2 == backupTarget.app) {
            if (adj3 > 300) {
                if (ActivityManagerDebugConfig.DEBUG_BACKUP) {
                    Slog.v(str, "oom BACKUP_APP_ADJ for " + processRecord2);
                }
                if (adj > 9) {
                    adj = 9;
                }
                processRecord2.adjType = BatteryService.HealthServiceWrapper.INSTANCE_HEALTHD;
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise adj to backup: " + processRecord2);
                }
                processRecord2.cached = false;
                adj3 = 300;
            }
            if (adj > 10) {
                adj = 10;
                processRecord2.adjType = BatteryService.HealthServiceWrapper.INSTANCE_HEALTHD;
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise procstate to backup: " + processRecord2);
                }
            }
        }
        int i5 = adj3;
        int is2 = processRecord2.services.size() - 1;
        int adj6 = i5;
        while (is2 >= 0 && (adj6 > 0 || adj2 == 0 || adj > 2)) {
            ServiceRecord s3 = processRecord2.services.valueAt(is2);
            if (s3.startRequested) {
                processRecord2.hasStartedServices = true;
                if (adj > 11) {
                    adj = 11;
                    processRecord2.adjType = "started-services";
                    if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                        reportOomAdjMessageLocked(str, "Raise procstate to started service: " + processRecord2);
                    }
                }
                if (!processRecord2.hasShownUi || wpc.isHomeProcess()) {
                    int procState3 = adj;
                    if (now < s3.lastActivity + this.mConstants.MAX_SERVICE_INACTIVITY && adj6 > 500) {
                        processRecord2.adjType = "started-services";
                        if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid5) {
                            reportOomAdjMessageLocked(str, "Raise adj to started service: " + processRecord2);
                        }
                        processRecord2.cached = false;
                        adj6 = 500;
                    }
                    if (adj6 > 500) {
                        processRecord2.adjType = "cch-started-services";
                    }
                    adj = procState3;
                } else if (adj6 > 500) {
                    processRecord2.adjType = "cch-started-ui-services";
                }
            } else {
                adj2 = adj2;
            }
            ArrayMap<IBinder, ArrayList<ConnectionRecord>> serviceConnections2 = s3.getConnections();
            int i6 = adj;
            int conni2 = serviceConnections2.size() - 1;
            int procState4 = i6;
            while (conni2 >= 0 && (adj6 > 0 || adj2 == 0 || procState4 > 2)) {
                ArrayList<ConnectionRecord> clist2 = serviceConnections2.valueAt(conni2);
                int procState5 = procState4;
                int procState6 = adj6;
                int adj7 = 0;
                while (true) {
                    appUid3 = appUid5;
                    if (adj7 >= clist2.size() || (procState6 <= 0 && adj2 != 0 && procState5 <= 2)) {
                        break;
                        break;
                    }
                    ConnectionRecord cr2 = clist2.get(adj7);
                    int adj8 = procState6;
                    if (cr2.binding.client == processRecord2) {
                        i2 = adj7;
                        s2 = s3;
                        str7 = str;
                        clist = clist2;
                        conni = conni2;
                        foregroundActivities3 = foregroundActivities2;
                        is = is2;
                        serviceConnections = serviceConnections2;
                        appUid4 = appUid3;
                        processRecord = processRecord2;
                    } else {
                        boolean trackedProcState = false;
                        if ((cr2.flags & 32) == 0) {
                            ProcessRecord client = cr2.binding.client;
                            foregroundActivities3 = foregroundActivities2;
                            serviceConnections = serviceConnections2;
                            appUid4 = appUid3;
                            cr = cr2;
                            ProcessRecord client2 = client;
                            i2 = adj7;
                            is = is2;
                            s2 = s3;
                            str7 = str;
                            clist = clist2;
                            conni = conni2;
                            processRecord = processRecord2;
                            computeOomAdjLocked(client, cachedAdj, TOP_APP, doingAll, now, cycleReEval);
                            if (!shouldSkipDueToCycle(app, client2, procState5, adj8, cycleReEval)) {
                                int clientAdj2 = client2.getCurRawAdj();
                                int clientProcState5 = client2.getCurRawProcState();
                                if (clientProcState5 >= 17) {
                                    clientProcState5 = 20;
                                }
                                if ((cr.flags & 16) != 0) {
                                    if (!processRecord.hasShownUi || wpc.isHomeProcess()) {
                                        adj5 = adj8;
                                        s = s2;
                                        clientProcState = clientProcState5;
                                        adjType = null;
                                        j4 = now;
                                        if (j4 >= s.lastActivity + this.mConstants.MAX_SERVICE_INACTIVITY) {
                                            if (adj5 > clientAdj2) {
                                                adjType = "cch-bound-services";
                                            }
                                            clientAdj2 = adj5;
                                            clientProcState2 = clientProcState;
                                        }
                                    } else {
                                        adj5 = adj8;
                                        String adjType3 = adj5 > clientAdj2 ? "cch-bound-ui-services" : null;
                                        processRecord.cached = false;
                                        clientAdj2 = adj5;
                                        clientProcState2 = procState5;
                                        adjType = adjType3;
                                        s = s2;
                                        j4 = now;
                                    }
                                    if (adj5 <= clientAdj2) {
                                        if (processRecord.hasShownUi || wpc.isHomeProcess() || clientAdj2 <= 200) {
                                            if ((cr.flags & 72) == 0) {
                                                newAdj = cr.flags;
                                                if ((newAdj & 256) != 0 || clientAdj2 >= 200 || adj5 <= 250) {
                                                    newAdj2 = cr.flags;
                                                    if ((newAdj2 & 1073741824) != 0) {
                                                        i3 = 200;
                                                        if (clientAdj2 >= 200 && adj5 > 200) {
                                                            newAdj3 = 200;
                                                        }
                                                    } else {
                                                        i3 = 200;
                                                    }
                                                    if (clientAdj2 >= i3) {
                                                        newAdj3 = clientAdj2;
                                                    } else if (adj5 > 100) {
                                                        newAdj3 = Math.max(clientAdj2, 100);
                                                    } else {
                                                        newAdj3 = adj5;
                                                    }
                                                } else {
                                                    newAdj3 = 250;
                                                }
                                            } else if (clientAdj2 >= -700) {
                                                newAdj3 = clientAdj2;
                                            } else {
                                                newAdj3 = -700;
                                                adj2 = 2;
                                                procState5 = 0;
                                                cr.trackProcState(0, this.mAdjSeq, j4);
                                                trackedProcState = true;
                                            }
                                            client2 = client2;
                                            if (!client2.cached) {
                                                processRecord.cached = false;
                                            }
                                            if (adj5 > newAdj3) {
                                                int adj9 = newAdj3;
                                                processRecord.setCurRawAdj(adj9);
                                                adjType = OomAdjConstants.OOM_ADJ_SERVICE;
                                                adj5 = adj9;
                                                clientAdj = adj2;
                                            } else {
                                                clientAdj = adj2;
                                            }
                                        } else if (adj5 >= 900) {
                                            adjType = "cch-bound-ui-services";
                                            client2 = client2;
                                            clientAdj = adj2;
                                        }
                                        if ((cr.flags & 8388612) == 0) {
                                            curSchedGroup = client2.getCurrentSchedulingGroup();
                                            if (curSchedGroup > clientAdj) {
                                                schedGroup7 = cr.flags;
                                                if ((schedGroup7 & 64) != 0) {
                                                    clientAdj = curSchedGroup;
                                                } else {
                                                    clientAdj = 2;
                                                }
                                            }
                                            int schedGroup8 = clientAdj;
                                            if (clientProcState2 < 2) {
                                                if (cr.hasFlag(4096)) {
                                                    bestState = 3;
                                                } else {
                                                    bestState = 6;
                                                }
                                                if ((cr.flags & 67108864) != 0) {
                                                    clientProcState2 = bestState;
                                                } else if (this.mService.mWakefulness == 1 || (cr.flags & DumpState.DUMP_APEX) == 0) {
                                                    clientProcState2 = 7;
                                                } else {
                                                    clientProcState2 = bestState;
                                                }
                                            } else if (clientProcState2 == 2) {
                                                if (cr.notHasFlag(4096)) {
                                                    clientProcState2 = 4;
                                                }
                                            } else if (clientProcState2 <= 5 && cr.notHasFlag(4096)) {
                                                clientProcState2 = 5;
                                            }
                                            clientProcState3 = clientProcState2;
                                            clientProcState4 = schedGroup8;
                                        } else {
                                            schedGroup5 = clientAdj;
                                            schedGroup6 = cr.flags;
                                            if ((schedGroup6 & DumpState.DUMP_VOLUMES) == 0) {
                                                if (clientProcState2 < 9) {
                                                    clientProcState3 = 9;
                                                    clientProcState4 = schedGroup5;
                                                } else {
                                                    clientProcState3 = clientProcState2;
                                                    clientProcState4 = schedGroup5;
                                                }
                                            } else if (clientProcState2 < 8) {
                                                clientProcState3 = 8;
                                                clientProcState4 = schedGroup5;
                                            } else {
                                                clientProcState3 = clientProcState2;
                                                clientProcState4 = schedGroup5;
                                            }
                                        }
                                        if (clientProcState4 < 3 || (cr.flags & DumpState.DUMP_FROZEN) == 0) {
                                            adj2 = clientProcState4;
                                        } else {
                                            adj2 = 3;
                                        }
                                        if (!trackedProcState) {
                                            cr.trackProcState(clientProcState3, this.mAdjSeq, j4);
                                        }
                                        if (procState5 > clientProcState3) {
                                            procState5 = clientProcState3;
                                            processRecord.setCurRawProcState(procState5);
                                            if (adjType == null) {
                                                adjType2 = OomAdjConstants.OOM_ADJ_SERVICE;
                                            } else {
                                                adjType2 = adjType;
                                            }
                                        } else {
                                            adjType2 = adjType;
                                        }
                                        if (procState5 < 8 && (cr.flags & 536870912) != 0) {
                                            processRecord.setPendingUiClean(true);
                                        }
                                        if (adjType2 != null) {
                                            processRecord.adjType = adjType2;
                                            processRecord.adjTypeCode = 2;
                                            processRecord.adjSource = cr.binding.client;
                                            processRecord.adjSourceProcState = clientProcState3;
                                            processRecord.adjTarget = s.instanceName;
                                            if (!ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid4) {
                                                str6 = str7;
                                                reportOomAdjMessageLocked(str6, "Raise to " + adjType2 + ": " + processRecord + ", due to " + cr.binding.client + " adj=" + adj5 + " procState=" + ProcessList.makeProcStateString(procState5));
                                            } else {
                                                str6 = str7;
                                            }
                                        } else {
                                            str6 = str7;
                                        }
                                    }
                                    clientAdj = adj2;
                                    if ((cr.flags & 8388612) == 0) {
                                        curSchedGroup = client2.getCurrentSchedulingGroup();
                                        if (curSchedGroup > clientAdj) {
                                            schedGroup7 = cr.flags;
                                            if ((schedGroup7 & 64) != 0) {
                                                clientAdj = curSchedGroup;
                                            } else {
                                                clientAdj = 2;
                                            }
                                        }
                                        int schedGroup9 = clientAdj;
                                        if (clientProcState2 < 2) {
                                            if (cr.hasFlag(4096)) {
                                                bestState = 3;
                                            } else {
                                                bestState = 6;
                                            }
                                            if ((cr.flags & 67108864) != 0) {
                                                clientProcState2 = bestState;
                                            } else if (this.mService.mWakefulness == 1) {
                                                clientProcState2 = 7;
                                            } else {
                                                clientProcState2 = 7;
                                            }
                                        } else if (clientProcState2 == 2) {
                                            if (cr.notHasFlag(4096)) {
                                                clientProcState2 = 4;
                                            }
                                        } else if (clientProcState2 <= 5) {
                                            clientProcState2 = 5;
                                        }
                                        clientProcState3 = clientProcState2;
                                        clientProcState4 = schedGroup9;
                                    } else {
                                        schedGroup5 = clientAdj;
                                        schedGroup6 = cr.flags;
                                        if ((schedGroup6 & DumpState.DUMP_VOLUMES) == 0) {
                                            if (clientProcState2 < 9) {
                                                clientProcState3 = 9;
                                                clientProcState4 = schedGroup5;
                                            } else {
                                                clientProcState3 = clientProcState2;
                                                clientProcState4 = schedGroup5;
                                            }
                                        } else if (clientProcState2 < 8) {
                                            clientProcState3 = 8;
                                            clientProcState4 = schedGroup5;
                                        } else {
                                            clientProcState3 = clientProcState2;
                                            clientProcState4 = schedGroup5;
                                        }
                                    }
                                    if (clientProcState4 < 3) {
                                        adj2 = clientProcState4;
                                    } else {
                                        adj2 = clientProcState4;
                                    }
                                    if (!trackedProcState) {
                                        cr.trackProcState(clientProcState3, this.mAdjSeq, j4);
                                    }
                                    if (procState5 > clientProcState3) {
                                        procState5 = clientProcState3;
                                        processRecord.setCurRawProcState(procState5);
                                        if (adjType == null) {
                                            adjType2 = OomAdjConstants.OOM_ADJ_SERVICE;
                                        } else {
                                            adjType2 = adjType;
                                        }
                                    } else {
                                        adjType2 = adjType;
                                    }
                                    if (procState5 < 8) {
                                        processRecord.setPendingUiClean(true);
                                    }
                                    if (adjType2 != null) {
                                        processRecord.adjType = adjType2;
                                        processRecord.adjTypeCode = 2;
                                        processRecord.adjSource = cr.binding.client;
                                        processRecord.adjSourceProcState = clientProcState3;
                                        processRecord.adjTarget = s.instanceName;
                                        if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON) {
                                            str6 = str7;
                                            reportOomAdjMessageLocked(str6, "Raise to " + adjType2 + ": " + processRecord + ", due to " + cr.binding.client + " adj=" + adj5 + " procState=" + ProcessList.makeProcStateString(procState5));
                                        } else {
                                            str6 = str7;
                                            reportOomAdjMessageLocked(str6, "Raise to " + adjType2 + ": " + processRecord + ", due to " + cr.binding.client + " adj=" + adj5 + " procState=" + ProcessList.makeProcStateString(procState5));
                                        }
                                    } else {
                                        str6 = str7;
                                    }
                                } else {
                                    adj5 = adj8;
                                    s = s2;
                                    clientProcState = clientProcState5;
                                    adjType = null;
                                    j4 = now;
                                }
                                clientProcState2 = clientProcState;
                                if (adj5 <= clientAdj2) {
                                    if (processRecord.hasShownUi) {
                                        if ((cr.flags & 72) == 0) {
                                            newAdj = cr.flags;
                                            if ((newAdj & 256) != 0) {
                                                newAdj2 = cr.flags;
                                                if ((newAdj2 & 1073741824) != 0) {
                                                    i3 = 200;
                                                    if (clientAdj2 >= 200) {
                                                    }
                                                } else {
                                                    i3 = 200;
                                                }
                                                if (clientAdj2 >= i3) {
                                                    newAdj3 = clientAdj2;
                                                } else if (adj5 > 100) {
                                                    newAdj3 = Math.max(clientAdj2, 100);
                                                } else {
                                                    newAdj3 = adj5;
                                                }
                                            } else {
                                                newAdj2 = cr.flags;
                                                if ((newAdj2 & 1073741824) != 0) {
                                                    i3 = 200;
                                                    if (clientAdj2 >= 200) {
                                                    }
                                                } else {
                                                    i3 = 200;
                                                }
                                                if (clientAdj2 >= i3) {
                                                    newAdj3 = clientAdj2;
                                                } else if (adj5 > 100) {
                                                    newAdj3 = Math.max(clientAdj2, 100);
                                                } else {
                                                    newAdj3 = adj5;
                                                }
                                            }
                                        } else if (clientAdj2 >= -700) {
                                            newAdj3 = clientAdj2;
                                        } else {
                                            newAdj3 = -700;
                                            adj2 = 2;
                                            procState5 = 0;
                                            cr.trackProcState(0, this.mAdjSeq, j4);
                                            trackedProcState = true;
                                        }
                                        client2 = client2;
                                        if (!client2.cached) {
                                            processRecord.cached = false;
                                        }
                                        if (adj5 > newAdj3) {
                                            int adj10 = newAdj3;
                                            processRecord.setCurRawAdj(adj10);
                                            adjType = OomAdjConstants.OOM_ADJ_SERVICE;
                                            adj5 = adj10;
                                            clientAdj = adj2;
                                        } else {
                                            clientAdj = adj2;
                                        }
                                    } else {
                                        if ((cr.flags & 72) == 0) {
                                            newAdj = cr.flags;
                                            if ((newAdj & 256) != 0) {
                                                newAdj2 = cr.flags;
                                                if ((newAdj2 & 1073741824) != 0) {
                                                    i3 = 200;
                                                    if (clientAdj2 >= 200) {
                                                    }
                                                } else {
                                                    i3 = 200;
                                                }
                                                if (clientAdj2 >= i3) {
                                                    newAdj3 = clientAdj2;
                                                } else if (adj5 > 100) {
                                                    newAdj3 = Math.max(clientAdj2, 100);
                                                } else {
                                                    newAdj3 = adj5;
                                                }
                                            } else {
                                                newAdj2 = cr.flags;
                                                if ((newAdj2 & 1073741824) != 0) {
                                                    i3 = 200;
                                                    if (clientAdj2 >= 200) {
                                                    }
                                                } else {
                                                    i3 = 200;
                                                }
                                                if (clientAdj2 >= i3) {
                                                    newAdj3 = clientAdj2;
                                                } else if (adj5 > 100) {
                                                    newAdj3 = Math.max(clientAdj2, 100);
                                                } else {
                                                    newAdj3 = adj5;
                                                }
                                            }
                                        } else if (clientAdj2 >= -700) {
                                            newAdj3 = clientAdj2;
                                        } else {
                                            newAdj3 = -700;
                                            adj2 = 2;
                                            procState5 = 0;
                                            cr.trackProcState(0, this.mAdjSeq, j4);
                                            trackedProcState = true;
                                        }
                                        client2 = client2;
                                        if (!client2.cached) {
                                            processRecord.cached = false;
                                        }
                                        if (adj5 > newAdj3) {
                                            int adj11 = newAdj3;
                                            processRecord.setCurRawAdj(adj11);
                                            adjType = OomAdjConstants.OOM_ADJ_SERVICE;
                                            adj5 = adj11;
                                            clientAdj = adj2;
                                        } else {
                                            clientAdj = adj2;
                                        }
                                    }
                                    if ((cr.flags & 8388612) == 0) {
                                        curSchedGroup = client2.getCurrentSchedulingGroup();
                                        if (curSchedGroup > clientAdj) {
                                            schedGroup7 = cr.flags;
                                            if ((schedGroup7 & 64) != 0) {
                                                clientAdj = curSchedGroup;
                                            } else {
                                                clientAdj = 2;
                                            }
                                        }
                                        int schedGroup10 = clientAdj;
                                        if (clientProcState2 < 2) {
                                            if (cr.hasFlag(4096)) {
                                                bestState = 3;
                                            } else {
                                                bestState = 6;
                                            }
                                            if ((cr.flags & 67108864) != 0) {
                                                clientProcState2 = bestState;
                                            } else if (this.mService.mWakefulness == 1) {
                                                clientProcState2 = 7;
                                            } else {
                                                clientProcState2 = 7;
                                            }
                                        } else if (clientProcState2 == 2) {
                                            if (cr.notHasFlag(4096)) {
                                                clientProcState2 = 4;
                                            }
                                        } else if (clientProcState2 <= 5) {
                                            clientProcState2 = 5;
                                        }
                                        clientProcState3 = clientProcState2;
                                        clientProcState4 = schedGroup10;
                                    } else {
                                        schedGroup5 = clientAdj;
                                        schedGroup6 = cr.flags;
                                        if ((schedGroup6 & DumpState.DUMP_VOLUMES) == 0) {
                                            if (clientProcState2 < 9) {
                                                clientProcState3 = 9;
                                                clientProcState4 = schedGroup5;
                                            } else {
                                                clientProcState3 = clientProcState2;
                                                clientProcState4 = schedGroup5;
                                            }
                                        } else if (clientProcState2 < 8) {
                                            clientProcState3 = 8;
                                            clientProcState4 = schedGroup5;
                                        } else {
                                            clientProcState3 = clientProcState2;
                                            clientProcState4 = schedGroup5;
                                        }
                                    }
                                    if (clientProcState4 < 3) {
                                        adj2 = clientProcState4;
                                    } else {
                                        adj2 = clientProcState4;
                                    }
                                    if (!trackedProcState) {
                                        cr.trackProcState(clientProcState3, this.mAdjSeq, j4);
                                    }
                                    if (procState5 > clientProcState3) {
                                        procState5 = clientProcState3;
                                        processRecord.setCurRawProcState(procState5);
                                        if (adjType == null) {
                                            adjType2 = OomAdjConstants.OOM_ADJ_SERVICE;
                                        } else {
                                            adjType2 = adjType;
                                        }
                                    } else {
                                        adjType2 = adjType;
                                    }
                                    if (procState5 < 8) {
                                        processRecord.setPendingUiClean(true);
                                    }
                                    if (adjType2 != null) {
                                        processRecord.adjType = adjType2;
                                        processRecord.adjTypeCode = 2;
                                        processRecord.adjSource = cr.binding.client;
                                        processRecord.adjSourceProcState = clientProcState3;
                                        processRecord.adjTarget = s.instanceName;
                                        if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON) {
                                            str6 = str7;
                                            reportOomAdjMessageLocked(str6, "Raise to " + adjType2 + ": " + processRecord + ", due to " + cr.binding.client + " adj=" + adj5 + " procState=" + ProcessList.makeProcStateString(procState5));
                                        } else {
                                            str6 = str7;
                                            reportOomAdjMessageLocked(str6, "Raise to " + adjType2 + ": " + processRecord + ", due to " + cr.binding.client + " adj=" + adj5 + " procState=" + ProcessList.makeProcStateString(procState5));
                                        }
                                    } else {
                                        str6 = str7;
                                    }
                                }
                                clientAdj = adj2;
                                if ((cr.flags & 8388612) == 0) {
                                    curSchedGroup = client2.getCurrentSchedulingGroup();
                                    if (curSchedGroup > clientAdj) {
                                        schedGroup7 = cr.flags;
                                        if ((schedGroup7 & 64) != 0) {
                                            clientAdj = curSchedGroup;
                                        } else {
                                            clientAdj = 2;
                                        }
                                    }
                                    int schedGroup11 = clientAdj;
                                    if (clientProcState2 < 2) {
                                        if (cr.hasFlag(4096)) {
                                            bestState = 3;
                                        } else {
                                            bestState = 6;
                                        }
                                        if ((cr.flags & 67108864) != 0) {
                                            clientProcState2 = bestState;
                                        } else if (this.mService.mWakefulness == 1) {
                                            clientProcState2 = 7;
                                        } else {
                                            clientProcState2 = 7;
                                        }
                                    } else if (clientProcState2 == 2) {
                                        if (cr.notHasFlag(4096)) {
                                            clientProcState2 = 4;
                                        }
                                    } else if (clientProcState2 <= 5) {
                                        clientProcState2 = 5;
                                    }
                                    clientProcState3 = clientProcState2;
                                    clientProcState4 = schedGroup11;
                                } else {
                                    schedGroup5 = clientAdj;
                                    schedGroup6 = cr.flags;
                                    if ((schedGroup6 & DumpState.DUMP_VOLUMES) == 0) {
                                        if (clientProcState2 < 9) {
                                            clientProcState3 = 9;
                                            clientProcState4 = schedGroup5;
                                        } else {
                                            clientProcState3 = clientProcState2;
                                            clientProcState4 = schedGroup5;
                                        }
                                    } else if (clientProcState2 < 8) {
                                        clientProcState3 = 8;
                                        clientProcState4 = schedGroup5;
                                    } else {
                                        clientProcState3 = clientProcState2;
                                        clientProcState4 = schedGroup5;
                                    }
                                }
                                if (clientProcState4 < 3) {
                                    adj2 = clientProcState4;
                                } else {
                                    adj2 = clientProcState4;
                                }
                                if (!trackedProcState) {
                                    cr.trackProcState(clientProcState3, this.mAdjSeq, j4);
                                }
                                if (procState5 > clientProcState3) {
                                    procState5 = clientProcState3;
                                    processRecord.setCurRawProcState(procState5);
                                    if (adjType == null) {
                                        adjType2 = OomAdjConstants.OOM_ADJ_SERVICE;
                                    } else {
                                        adjType2 = adjType;
                                    }
                                } else {
                                    adjType2 = adjType;
                                }
                                if (procState5 < 8) {
                                    processRecord.setPendingUiClean(true);
                                }
                                if (adjType2 != null) {
                                    processRecord.adjType = adjType2;
                                    processRecord.adjTypeCode = 2;
                                    processRecord.adjSource = cr.binding.client;
                                    processRecord.adjSourceProcState = clientProcState3;
                                    processRecord.adjTarget = s.instanceName;
                                    if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON) {
                                        str6 = str7;
                                        reportOomAdjMessageLocked(str6, "Raise to " + adjType2 + ": " + processRecord + ", due to " + cr.binding.client + " adj=" + adj5 + " procState=" + ProcessList.makeProcStateString(procState5));
                                    } else {
                                        str6 = str7;
                                        reportOomAdjMessageLocked(str6, "Raise to " + adjType2 + ": " + processRecord + ", due to " + cr.binding.client + " adj=" + adj5 + " procState=" + ProcessList.makeProcStateString(procState5));
                                    }
                                } else {
                                    str6 = str7;
                                }
                            }
                            adj7 = i2 + 1;
                            procState6 = adj5;
                            s3 = s;
                            str = str6;
                            processRecord2 = processRecord;
                            appUid5 = appUid4;
                            conni2 = conni;
                            clist2 = clist;
                            serviceConnections2 = serviceConnections;
                            foregroundActivities2 = foregroundActivities3;
                            is2 = is;
                        } else {
                            i2 = adj7;
                            clist = clist2;
                            conni = conni2;
                            foregroundActivities3 = foregroundActivities2;
                            is = is2;
                            serviceConnections = serviceConnections2;
                            appUid4 = appUid3;
                            cr = cr2;
                            processRecord = processRecord2;
                            str6 = str;
                            s = s3;
                            adj5 = adj8;
                        }
                        if ((cr.flags & 134217728) != 0) {
                            processRecord.treatLikeActivity = true;
                        }
                        ActivityServiceConnectionsHolder<ConnectionRecord> activityServiceConnectionsHolder = cr.activity;
                        if ((cr.flags & 128) != 0 && activityServiceConnectionsHolder != null && adj5 > 0 && activityServiceConnectionsHolder.isActivityVisible()) {
                            adj5 = 0;
                            processRecord.setCurRawAdj(0);
                            if ((cr.flags & 4) == 0) {
                                adj2 = (cr.flags & 64) != 0 ? 4 : 2;
                            }
                            processRecord.cached = false;
                            processRecord.adjType = OomAdjConstants.OOM_ADJ_SERVICE;
                            processRecord.adjTypeCode = 2;
                            processRecord.adjSource = activityServiceConnectionsHolder;
                            processRecord.adjSourceProcState = procState5;
                            processRecord.adjTarget = s.instanceName;
                            if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid2 == appUid4) {
                                reportOomAdjMessageLocked(str6, "Raise to service w/activity: " + processRecord);
                            }
                        }
                        adj7 = i2 + 1;
                        procState6 = adj5;
                        s3 = s;
                        str = str6;
                        processRecord2 = processRecord;
                        appUid5 = appUid4;
                        conni2 = conni;
                        clist2 = clist;
                        serviceConnections2 = serviceConnections;
                        foregroundActivities2 = foregroundActivities3;
                        is2 = is;
                    }
                    adj5 = adj8;
                    s = s2;
                    str6 = str7;
                    adj7 = i2 + 1;
                    procState6 = adj5;
                    s3 = s;
                    str = str6;
                    processRecord2 = processRecord;
                    appUid5 = appUid4;
                    conni2 = conni;
                    clist2 = clist;
                    serviceConnections2 = serviceConnections;
                    foregroundActivities2 = foregroundActivities3;
                    is2 = is;
                }
                int is3 = is2;
                ProcessRecord processRecord3 = processRecord2;
                String str10 = str;
                ServiceRecord s4 = s3;
                int adj12 = procState6;
                conni2--;
                adj6 = adj12;
                s3 = s4;
                str = str10;
                processRecord2 = processRecord3;
                appUid5 = appUid3;
                procState4 = procState5;
                serviceConnections2 = serviceConnections2;
                foregroundActivities2 = foregroundActivities2;
                is2 = is3;
            }
            adj = procState4;
            str = str;
            processRecord2 = processRecord2;
            adj2 = adj2;
            wpc = wpc;
            backupTarget = backupTarget;
            foregroundActivities2 = foregroundActivities2;
            is2--;
            appUid5 = appUid5;
        }
        int provi = processRecord2.pubProviders.size() - 1;
        while (true) {
            if (provi < 0) {
                logUid3 = logUid2;
                j = now;
                break;
            }
            if (adj6 <= 0 && adj2 != 0 && adj <= 2) {
                logUid3 = logUid2;
                j = now;
                break;
            }
            ContentProviderRecord cpr3 = processRecord2.pubProviders.valueAt(provi);
            int i7 = 1;
            int adj13 = adj6;
            adj = adj;
            int schedGroup12 = adj2;
            int procState7 = cpr3.connections.size() - 1;
            while (true) {
                if (procState7 < 0) {
                    logUid4 = logUid2;
                    j2 = now;
                    break;
                }
                if (adj13 <= 0 && schedGroup12 != 0 && adj <= 2) {
                    logUid4 = logUid2;
                    j2 = now;
                    break;
                }
                ContentProviderConnection conn = cpr3.connections.get(procState7);
                int provi2 = provi;
                ProcessRecord client3 = conn.client;
                if (client3 == processRecord2) {
                    procState2 = adj;
                    adj4 = adj13;
                    i = procState7;
                    str4 = str;
                    logUid5 = logUid2;
                    str2 = str8;
                    str3 = str9;
                    appUid = appUid5;
                    cpr = cpr3;
                    schedGroup4 = schedGroup12;
                    j3 = now;
                } else {
                    str2 = str8;
                    procState2 = adj;
                    str3 = str9;
                    schedGroup4 = schedGroup12;
                    adj4 = adj13;
                    appUid = appUid5;
                    cpr = cpr3;
                    j3 = now;
                    i = procState7;
                    str4 = str;
                    logUid5 = logUid2;
                    int logUid8 = i7;
                    computeOomAdjLocked(client3, cachedAdj, TOP_APP, doingAll, now, cycleReEval);
                    if (!shouldSkipDueToCycle(app, client3, procState2, adj4, cycleReEval)) {
                        int clientAdj3 = client3.getCurRawAdj();
                        int clientProcState6 = client3.getCurRawProcState();
                        if (clientProcState6 >= 17) {
                            clientProcState6 = 20;
                        }
                        String adjType4 = null;
                        adj13 = adj4;
                        if (adj13 > clientAdj3) {
                            if (processRecord2.hasShownUi && !wpc.isHomeProcess()) {
                                adjType4 = clientAdj3 > 200 ? "cch-ui-provider" : "provider";
                                processRecord2.cached &= client3.cached;
                            }
                            adj13 = clientAdj3 > 0 ? clientAdj3 : 0;
                            processRecord2.setCurRawAdj(adj13);
                            processRecord2.cached &= client3.cached;
                        }
                        if (clientProcState6 <= 5) {
                            if (adjType4 == null) {
                                adjType4 = "provider";
                            }
                            clientProcState6 = clientProcState6 == 2 ? 4 : 6;
                        }
                        conn.trackProcState(clientProcState6, this.mAdjSeq, j3);
                        int procState8 = procState2;
                        if (procState8 > clientProcState6) {
                            procState8 = clientProcState6;
                            processRecord2.setCurRawProcState(procState8);
                        }
                        if (client3.getCurrentSchedulingGroup() > schedGroup4) {
                            schedGroup4 = 2;
                        }
                        if (adjType4 != null) {
                            processRecord2.adjType = adjType4;
                            processRecord2.adjTypeCode = logUid8;
                            processRecord2.adjSource = client3;
                            processRecord2.adjSourceProcState = clientProcState6;
                            cpr2 = cpr;
                            processRecord2.adjTarget = cpr2.name;
                            if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON) {
                                appUid2 = appUid;
                                logUid6 = logUid5;
                            } else {
                                appUid2 = appUid;
                                logUid6 = logUid5;
                                if (logUid6 != appUid2) {
                                    str5 = str4;
                                }
                            }
                            str5 = str4;
                            reportOomAdjMessageLocked(str5, str3 + adjType4 + str2 + processRecord2 + ", due to " + client3 + " adj=" + adj13 + " procState=" + ProcessList.makeProcStateString(procState8));
                        } else {
                            appUid2 = appUid;
                            cpr2 = cpr;
                            logUid6 = logUid5;
                            str5 = str4;
                        }
                        adj = procState8;
                        schedGroup12 = schedGroup4;
                    }
                    procState7 = i - 1;
                    provi = provi2;
                    str8 = str2;
                    str9 = str3;
                    i7 = 1;
                    long j5 = j3;
                    appUid5 = appUid2;
                    cpr3 = cpr2;
                    str = str5;
                    logUid2 = logUid6;
                    now = j5;
                }
                schedGroup12 = schedGroup4;
                adj = procState2;
                adj13 = adj4;
                appUid2 = appUid;
                cpr2 = cpr;
                logUid6 = logUid5;
                str5 = str4;
                procState7 = i - 1;
                provi = provi2;
                str8 = str2;
                str9 = str3;
                i7 = 1;
                long j6 = j3;
                appUid5 = appUid2;
                cpr3 = cpr2;
                str = str5;
                logUid2 = logUid6;
                now = j6;
            }
            if (cpr3.hasExternalProcessHandles()) {
                if (adj13 > 0) {
                    adj13 = 0;
                    processRecord2.setCurRawAdj(0);
                    processRecord2.cached = false;
                    processRecord2.adjType = "ext-provider";
                    processRecord2.adjTarget = cpr3.name;
                    if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid4 == appUid5) {
                        reportOomAdjMessageLocked(str, "Raise adj to external provider: " + processRecord2);
                    }
                    schedGroup12 = 2;
                }
                if (adj > 7) {
                    processRecord2.setCurRawProcState(7);
                    if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid4 == appUid5) {
                        reportOomAdjMessageLocked(str, "Raise procstate to external provider: " + processRecord2);
                    }
                    adj = 7;
                }
            }
            adj6 = adj13;
            adj2 = schedGroup12;
            provi--;
            str = str;
            str8 = str8;
            str9 = str9;
            logUid2 = logUid4;
            long j7 = j2;
            appUid5 = appUid5;
            now = j7;
        }
        if (processRecord2.lastProviderTime > 0 && processRecord2.lastProviderTime + this.mConstants.CONTENT_PROVIDER_RETAIN_TIME > j) {
            if (adj6 > 700) {
                adj6 = 700;
                adj2 = 0;
                processRecord2.cached = false;
                processRecord2.adjType = "recent-provider";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid3 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise adj to recent provider: " + processRecord2);
                }
            }
            if (adj > 16) {
                adj = 16;
                processRecord2.adjType = "recent-provider";
                if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ_REASON || logUid3 == appUid5) {
                    reportOomAdjMessageLocked(str, "Raise procstate to recent provider: " + processRecord2);
                }
            }
        }
        if (adj >= 20) {
            if (app.hasClientActivities()) {
                adj = 18;
                processRecord2.adjType = "cch-client-act";
            } else if (processRecord2.treatLikeActivity) {
                adj = 17;
                processRecord2.adjType = "cch-as-act";
            }
        }
        if (adj6 == 500) {
            if (doingAll) {
                processRecord2.serviceb = this.mNewNumAServiceProcs > this.mNumServiceProcs / 3;
                this.mNewNumServiceProcs++;
                if (processRecord2.serviceb) {
                    z = false;
                    processRecord2.serviceHighRam = false;
                } else if (this.mService.mLastMemoryLevel <= 0 || processRecord2.lastPss < this.mProcessList.getCachedRestoreThresholdKb()) {
                    int i8 = 1;
                    this.mNewNumAServiceProcs += i8;
                    z = false;
                } else {
                    processRecord2.serviceHighRam = true;
                    processRecord2.serviceb = true;
                    z = false;
                }
            } else {
                z = false;
            }
            if (processRecord2.serviceb) {
                adj6 = 800;
            }
        } else {
            z = false;
        }
        processRecord2.setCurRawAdj(adj6);
        if (adj6 > processRecord2.maxAdj) {
            adj6 = processRecord2.maxAdj;
            schedGroup3 = processRecord2.maxAdj <= 250 ? 2 : adj2;
        } else {
            schedGroup3 = adj2;
        }
        if (adj >= 6) {
            z2 = true;
            if (this.mService.mWakefulness != 1 && schedGroup3 > 1) {
                schedGroup3 = 1;
            }
        } else {
            z2 = true;
        }
        processRecord2.curAdj = processRecord2.modifyRawOomAdj(adj6);
        processRecord2.setCurrentSchedulingGroup(schedGroup3);
        processRecord2.setCurProcState(adj);
        processRecord2.setCurRawProcState(adj);
        processRecord2.setHasForegroundActivities(foregroundActivities2);
        processRecord2.completedAdjSeq = this.mAdjSeq;
        if (processRecord2.curAdj >= prevAppAdj && app.getCurProcState() >= prevProcState) {
            return z;
        }
        return z2;
    }

    private boolean shouldSkipDueToCycle(ProcessRecord app, ProcessRecord client, int procState, int adj, boolean cycleReEval) {
        if (client.containsCycle) {
            app.containsCycle = true;
            if (client.completedAdjSeq < this.mAdjSeq) {
                if (!cycleReEval) {
                    return true;
                }
                if (client.getCurRawProcState() >= procState && client.getCurRawAdj() >= adj) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return false;
    }

    @GuardedBy({"mService"})
    void reportOomAdjMessageLocked(String tag, String msg) {
        Slog.d(tag, msg);
        if (this.mService.mCurOomAdjObserver != null) {
            this.mService.mUiHandler.obtainMessage(70, msg).sendToTarget();
        }
    }

    void lsecLoadskipkill() {
        String[] apk;
        synchronized (this.pkgLock) {
            if (this.packageList == null) {
                this.packageList = new HashMap();
                File file = new File("/oem/app/skipkillapp.prop");
                if (file.exists()) {
                    try {
                        FileInputStream fis = new FileInputStream(file);
                        BufferedReader buffreader = new BufferedReader(new InputStreamReader(fis));
                        while (true) {
                            try {
                                String line = buffreader.readLine();
                                if (line == null) {
                                    break;
                                }
                                String trim = line.trim();
                                if (!trim.isEmpty() && !trim.startsWith("#") && (apk = trim.split("=")) != null && apk.length >= 1) {
                                    apk[0] = apk[0].trim();
                                    if (!apk[0].isEmpty()) {
                                        Integer v = -800;
                                        if (apk.length >= 2) {
                                            apk[1] = apk[1].trim();
                                            if (!apk[1].isEmpty()) {
                                                try {
                                                    v = Integer.valueOf(apk[1]);
                                                } catch (NumberFormatException e) {
                                                    v = -800;
                                                }
                                            }
                                        }
                                        this.packageList.put(apk[0], v);
                                    }
                                }
                                Slog.i(TAG, "levilin line=<" + line + ">,trim=<" + trim + ">");
                            } catch (IOException e2) {
                                e2.printStackTrace();
                            }
                        }
                    } catch (FileNotFoundException e3) {
                        Slog.w(TAG, "levilin cann't found /oem/app/skipkillapp.prop");
                    }
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:130:0x0264  */
    /* JADX WARN: Code duplicated, block: B:132:0x0267  */
    /* JADX WARN: Code duplicated, block: B:134:0x026a  */
    /* JADX WARN: Code duplicated, block: B:135:0x026c  */
    /* JADX WARN: Code duplicated, block: B:138:0x0271  */
    /* JADX WARN: Code duplicated, block: B:139:0x0273  */
    /* JADX WARN: Code duplicated, block: B:140:0x0275  */
    /* JADX WARN: Code duplicated, block: B:143:0x028c A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:150:0x02c2 A[Catch: Exception -> 0x03ad, TryCatch #1 {Exception -> 0x03ad, blocks: (B:148:0x029e, B:150:0x02c2, B:152:0x02d6, B:154:0x02e2, B:156:0x0305, B:158:0x030b, B:159:0x0313, B:161:0x0320, B:173:0x0344, B:175:0x0351, B:177:0x0362, B:183:0x039d, B:185:0x03a7, B:180:0x0370, B:182:0x0387), top: B:276:0x028a, inners: #3, #6 }] */
    /* JADX WARN: Code duplicated, block: B:152:0x02d6 A[Catch: Exception -> 0x03ad, TryCatch #1 {Exception -> 0x03ad, blocks: (B:148:0x029e, B:150:0x02c2, B:152:0x02d6, B:154:0x02e2, B:156:0x0305, B:158:0x030b, B:159:0x0313, B:161:0x0320, B:173:0x0344, B:175:0x0351, B:177:0x0362, B:183:0x039d, B:185:0x03a7, B:180:0x0370, B:182:0x0387), top: B:276:0x028a, inners: #3, #6 }] */
    /* JADX WARN: Code duplicated, block: B:154:0x02e2 A[Catch: Exception -> 0x03ad, TryCatch #1 {Exception -> 0x03ad, blocks: (B:148:0x029e, B:150:0x02c2, B:152:0x02d6, B:154:0x02e2, B:156:0x0305, B:158:0x030b, B:159:0x0313, B:161:0x0320, B:173:0x0344, B:175:0x0351, B:177:0x0362, B:183:0x039d, B:185:0x03a7, B:180:0x0370, B:182:0x0387), top: B:276:0x028a, inners: #3, #6 }] */
    /* JADX WARN: Code duplicated, block: B:155:0x0302  */
    /* JADX WARN: Code duplicated, block: B:156:0x0305 A[Catch: Exception -> 0x03ad, TryCatch #1 {Exception -> 0x03ad, blocks: (B:148:0x029e, B:150:0x02c2, B:152:0x02d6, B:154:0x02e2, B:156:0x0305, B:158:0x030b, B:159:0x0313, B:161:0x0320, B:173:0x0344, B:175:0x0351, B:177:0x0362, B:183:0x039d, B:185:0x03a7, B:180:0x0370, B:182:0x0387), top: B:276:0x028a, inners: #3, #6 }] */
    /* JADX WARN: Code duplicated, block: B:158:0x030b A[Catch: Exception -> 0x03ad, TryCatch #1 {Exception -> 0x03ad, blocks: (B:148:0x029e, B:150:0x02c2, B:152:0x02d6, B:154:0x02e2, B:156:0x0305, B:158:0x030b, B:159:0x0313, B:161:0x0320, B:173:0x0344, B:175:0x0351, B:177:0x0362, B:183:0x039d, B:185:0x03a7, B:180:0x0370, B:182:0x0387), top: B:276:0x028a, inners: #3, #6 }] */
    /* JADX WARN: Code duplicated, block: B:159:0x0313 A[Catch: Exception -> 0x03ad, TRY_LEAVE, TryCatch #1 {Exception -> 0x03ad, blocks: (B:148:0x029e, B:150:0x02c2, B:152:0x02d6, B:154:0x02e2, B:156:0x0305, B:158:0x030b, B:159:0x0313, B:161:0x0320, B:173:0x0344, B:175:0x0351, B:177:0x0362, B:183:0x039d, B:185:0x03a7, B:180:0x0370, B:182:0x0387), top: B:276:0x028a, inners: #3, #6 }] */
    /* JADX WARN: Code duplicated, block: B:169:0x0335  */
    /* JADX WARN: Code duplicated, block: B:170:0x033b  */
    /* JADX WARN: Code duplicated, block: B:172:0x0342 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:177:0x0362 A[Catch: SecurityException -> 0x036f, IllegalArgumentException -> 0x0386, Exception -> 0x03ad, TRY_LEAVE, TryCatch #3 {IllegalArgumentException -> 0x0386, blocks: (B:175:0x0351, B:177:0x0362), top: B:280:0x0351, outer: #1 }] */
    /* JADX WARN: Code duplicated, block: B:183:0x039d A[Catch: Exception -> 0x03ad, TryCatch #1 {Exception -> 0x03ad, blocks: (B:148:0x029e, B:150:0x02c2, B:152:0x02d6, B:154:0x02e2, B:156:0x0305, B:158:0x030b, B:159:0x0313, B:161:0x0320, B:173:0x0344, B:175:0x0351, B:177:0x0362, B:183:0x039d, B:185:0x03a7, B:180:0x0370, B:182:0x0387), top: B:276:0x028a, inners: #3, #6 }] */
    /* JADX WARN: Code duplicated, block: B:185:0x03a7 A[Catch: Exception -> 0x03ad, TRY_LEAVE, TryCatch #1 {Exception -> 0x03ad, blocks: (B:148:0x029e, B:150:0x02c2, B:152:0x02d6, B:154:0x02e2, B:156:0x0305, B:158:0x030b, B:159:0x0313, B:161:0x0320, B:173:0x0344, B:175:0x0351, B:177:0x0362, B:183:0x039d, B:185:0x03a7, B:180:0x0370, B:182:0x0387), top: B:276:0x028a, inners: #3, #6 }] */
    /* JADX WARN: Code duplicated, block: B:273:0x028e A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:280:0x0351 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:282:0x0320 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Instruction removed from duplicated block: B:154:0x02e2, please report this as an issue */
    @GuardedBy({"mService"})
    final boolean applyOomAdjLocked(ProcessRecord app, boolean doingAll, long now, long nowElapsed) {
        String navi_package;
        boolean find_navi;
        boolean success;
        String str;
        String str2;
        String str3;
        int changes;
        int changes2;
        String msg;
        int processGroup;
        Map<String, Integer> map;
        lsecLoadskipkill();
        String navi_package2 = SystemProperties.get("sys.navi.packagename");
        if (!TextUtils.isEmpty(navi_package2)) {
            navi_package = navi_package2;
        } else {
            navi_package = SystemProperties.get("persist.sys.navi.packagename");
        }
        boolean find_navi2 = false;
        if (TextUtils.isEmpty(navi_package)) {
            find_navi = false;
        } else {
            if (navi_package.length() > app.processName.length()) {
                if (navi_package.startsWith(app.processName)) {
                    find_navi2 = true;
                }
            } else if (app.processName.startsWith(navi_package)) {
                find_navi2 = true;
            }
            if (find_navi2) {
                app.setCurRawAdj(-700);
                app.curAdj = -700;
            }
            find_navi = find_navi2;
        }
        if (!find_navi && (map = this.packageList) != null && !map.isEmpty() && app.processName != null) {
            for (Map.Entry<String, Integer> entry : this.packageList.entrySet()) {
                boolean setAdj = false;
                String line = entry.getKey();
                Integer v = entry.getValue();
                if (line.length() > app.processName.length()) {
                    if (line.startsWith(app.processName)) {
                        setAdj = true;
                    }
                } else if (app.processName.startsWith(line)) {
                    setAdj = true;
                }
                if (setAdj) {
                    if (app.getCurRawAdj() > v.intValue()) {
                        app.setCurRawAdj(v.intValue() < 0 ? -700 : 200);
                    }
                    if (app.curAdj <= v.intValue()) {
                        break;
                    }
                    app.curAdj = v.intValue() < 0 ? -700 : 200;
                    break;
                }
            }
        }
        AudioManagerInternal ami = (AudioManagerInternal) LocalServices.getService(AudioManagerInternal.class);
        if (app.getCurRawAdj() > 200 && app.processName.startsWith("com.syu") && ami.hasFocusRequested(app.processName)) {
            app.setCurRawAdj(100);
            app.curAdj = 100;
            if (app.getCurProcState() >= 17) {
                app.setCurProcState(11);
            }
        }
        if (app.getCurRawAdj() != app.setRawAdj) {
            app.setRawAdj = app.getCurRawAdj();
        }
        if (this.mAppCompact.useCompaction() && this.mService.mBooted) {
            if (app.curAdj != app.setAdj) {
                if (app.setAdj <= 200 && (app.curAdj == 700 || app.curAdj == 600)) {
                    this.mAppCompact.compactAppSome(app);
                } else if ((app.setAdj < 900 || app.setAdj > 999) && app.curAdj >= 900 && app.curAdj <= 999) {
                    this.mAppCompact.compactAppFull(app);
                }
            } else if (this.mService.mWakefulness != 1 && app.setAdj < 0 && this.mAppCompact.shouldCompactPersistent(app, now)) {
                this.mAppCompact.compactAppPersistent(app);
            } else if (this.mService.mWakefulness != 1 && app.getCurProcState() == 6 && this.mAppCompact.shouldCompactBFGS(app, now)) {
                this.mAppCompact.compactAppBfgs(app);
            }
        }
        if (app.curAdj != app.setAdj) {
            ProcessList.setOomAdj(app.pid, app.uid, app.curAdj);
            if (ActivityTaskManagerDebugConfig.DEBUG_SWITCH || ActivityManagerDebugConfig.DEBUG_OOM_ADJ || this.mService.mCurOomAdjUid == app.info.uid) {
                String msg2 = "Set " + app.pid + " " + app.processName + " adj " + app.curAdj + ": " + app.adjType;
                reportOomAdjMessageLocked("ActivityManager", msg2);
            }
            app.setAdj = app.curAdj;
            app.verifiedAdj = -10000;
        }
        int curSchedGroup = app.getCurrentSchedulingGroup();
        if (app.setSchedGroup == curSchedGroup) {
            success = true;
            str = " to ";
            str2 = " ";
            str3 = ": ";
        } else {
            int oldSchedGroup = app.setSchedGroup;
            app.setSchedGroup = curSchedGroup;
            if (ActivityTaskManagerDebugConfig.DEBUG_SWITCH || ActivityManagerDebugConfig.DEBUG_OOM_ADJ) {
                success = true;
            } else {
                success = true;
                if (this.mService.mCurOomAdjUid == app.uid) {
                }
                msg = app.waitingToKill;
                if (msg == null && app.curReceivers.isEmpty() && app.setSchedGroup == 0) {
                    app.kill(app.waitingToKill, true);
                    success = false;
                    str = " to ";
                    str2 = " ";
                    str3 = ": ";
                } else {
                    if (curSchedGroup == 0) {
                        processGroup = 0;
                    } else if (curSchedGroup != 1) {
                        if (curSchedGroup != 3 || curSchedGroup == 4) {
                            processGroup = 5;
                        } else {
                            processGroup = -1;
                        }
                    } else {
                        processGroup = 7;
                    }
                    Handler handler = this.mProcessGroupHandler;
                    str = " to ";
                    str2 = " ";
                    handler.sendMessage(handler.obtainMessage(0, app.pid, processGroup));
                    try {
                        if (curSchedGroup != 3) {
                            str3 = ": ";
                            if (oldSchedGroup == 3 && curSchedGroup != 3) {
                                app.getWindowProcessController().onTopProcChanged();
                                if (this.mService.mUseFifoUiScheduling) {
                                    try {
                                        try {
                                            Process.setThreadScheduler(app.pid, 0, 0);
                                            Process.setThreadPriority(app.pid, app.savedPriority);
                                            if (app.renderThreadTid != 0) {
                                                Process.setThreadScheduler(app.renderThreadTid, 0, 0);
                                                Process.setThreadPriority(app.renderThreadTid, -4);
                                            }
                                        } catch (IllegalArgumentException e) {
                                            Slog.w(TAG, "Failed to set scheduling policy, thread does not exist:\n" + e);
                                        }
                                    } catch (SecurityException e2) {
                                        Slog.w(TAG, "Failed to set scheduling policy, not allowed:\n" + e2);
                                    }
                                } else {
                                    Process.setThreadPriority(app.pid, 0);
                                    if (app.renderThreadTid != 0) {
                                        Process.setThreadPriority(app.renderThreadTid, 0);
                                    }
                                }
                            }
                        } else if (oldSchedGroup != 3) {
                            try {
                                Bundle b = new Bundle();
                                try {
                                    str3 = ": ";
                                    ComponentName cn = new ComponentName(app.info.packageName, "");
                                    Intent i = new Intent();
                                    i.setComponent(cn);
                                    this.mService.notifyActivityStateChange(i, 7, b);
                                    app.getWindowProcessController().onTopProcChanged();
                                    if (this.mService.mUseFifoUiScheduling) {
                                        app.savedPriority = Process.getThreadPriority(app.pid);
                                        ActivityManagerService activityManagerService = this.mService;
                                        ActivityManagerService.scheduleAsFifoPriority(app.pid, true);
                                        if (app.renderThreadTid != 0) {
                                            ActivityManagerService activityManagerService2 = this.mService;
                                            ActivityManagerService.scheduleAsFifoPriority(app.renderThreadTid, true);
                                            if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ) {
                                                Slog.d("UI_FIFO", "Set RenderThread (TID " + app.renderThreadTid + ") to FIFO");
                                            }
                                        } else if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ) {
                                            Slog.d("UI_FIFO", "Not setting RenderThread TID");
                                        }
                                    } else {
                                        Process.setThreadPriority(app.pid, -10);
                                        if (app.renderThreadTid != 0) {
                                            try {
                                                Process.setThreadPriority(app.renderThreadTid, -10);
                                            } catch (IllegalArgumentException e3) {
                                            }
                                        }
                                    }
                                } catch (Exception e4) {
                                    e = e4;
                                    str3 = ": ";
                                    if (ActivityManagerDebugConfig.DEBUG_ALL) {
                                        Slog.w(TAG, "Failed setting thread priority of " + app.pid, e);
                                    }
                                }
                            } catch (Exception e5) {
                                e = e5;
                                str3 = ": ";
                            }
                        } else {
                            str3 = ": ";
                        }
                    } catch (Exception e6) {
                        e = e6;
                    }
                }
            }
            String msg3 = "Setting sched group of " + app.processName + " to " + curSchedGroup + ": " + app.adjType;
            reportOomAdjMessageLocked("ActivityManager", msg3);
            msg = app.waitingToKill;
            if (msg == null) {
                if (curSchedGroup == 0) {
                    processGroup = 0;
                } else if (curSchedGroup != 1) {
                    if (curSchedGroup != 3) {
                        processGroup = 5;
                    } else {
                        processGroup = 5;
                    }
                } else {
                    processGroup = 7;
                }
                Handler handler2 = this.mProcessGroupHandler;
                str = " to ";
                str2 = " ";
                handler2.sendMessage(handler2.obtainMessage(0, app.pid, processGroup));
                if (curSchedGroup != 3) {
                    str3 = ": ";
                    if (oldSchedGroup == 3) {
                        app.getWindowProcessController().onTopProcChanged();
                        if (this.mService.mUseFifoUiScheduling) {
                            Process.setThreadScheduler(app.pid, 0, 0);
                            Process.setThreadPriority(app.pid, app.savedPriority);
                            if (app.renderThreadTid != 0) {
                                Process.setThreadScheduler(app.renderThreadTid, 0, 0);
                                Process.setThreadPriority(app.renderThreadTid, -4);
                            }
                        } else {
                            Process.setThreadPriority(app.pid, 0);
                            if (app.renderThreadTid != 0) {
                                Process.setThreadPriority(app.renderThreadTid, 0);
                            }
                        }
                    }
                } else if (oldSchedGroup != 3) {
                    Bundle b2 = new Bundle();
                    str3 = ": ";
                    ComponentName cn2 = new ComponentName(app.info.packageName, "");
                    Intent i2 = new Intent();
                    i2.setComponent(cn2);
                    this.mService.notifyActivityStateChange(i2, 7, b2);
                    app.getWindowProcessController().onTopProcChanged();
                    if (this.mService.mUseFifoUiScheduling) {
                        app.savedPriority = Process.getThreadPriority(app.pid);
                        ActivityManagerService activityManagerService3 = this.mService;
                        ActivityManagerService.scheduleAsFifoPriority(app.pid, true);
                        if (app.renderThreadTid != 0) {
                            ActivityManagerService activityManagerService4 = this.mService;
                            ActivityManagerService.scheduleAsFifoPriority(app.renderThreadTid, true);
                            if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ) {
                                Slog.d("UI_FIFO", "Set RenderThread (TID " + app.renderThreadTid + ") to FIFO");
                            }
                        } else if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ) {
                            Slog.d("UI_FIFO", "Not setting RenderThread TID");
                        }
                    } else {
                        Process.setThreadPriority(app.pid, -10);
                        if (app.renderThreadTid != 0) {
                            Process.setThreadPriority(app.renderThreadTid, -10);
                        }
                    }
                } else {
                    str3 = ": ";
                }
            } else {
                if (curSchedGroup == 0) {
                    processGroup = 0;
                } else if (curSchedGroup != 1) {
                    if (curSchedGroup != 3) {
                        processGroup = 5;
                    } else {
                        processGroup = 5;
                    }
                } else {
                    processGroup = 7;
                }
                Handler handler3 = this.mProcessGroupHandler;
                str = " to ";
                str2 = " ";
                handler3.sendMessage(handler3.obtainMessage(0, app.pid, processGroup));
                if (curSchedGroup != 3) {
                    str3 = ": ";
                    if (oldSchedGroup == 3) {
                        app.getWindowProcessController().onTopProcChanged();
                        if (this.mService.mUseFifoUiScheduling) {
                            Process.setThreadScheduler(app.pid, 0, 0);
                            Process.setThreadPriority(app.pid, app.savedPriority);
                            if (app.renderThreadTid != 0) {
                                Process.setThreadScheduler(app.renderThreadTid, 0, 0);
                                Process.setThreadPriority(app.renderThreadTid, -4);
                            }
                        } else {
                            Process.setThreadPriority(app.pid, 0);
                            if (app.renderThreadTid != 0) {
                                Process.setThreadPriority(app.renderThreadTid, 0);
                            }
                        }
                    }
                } else if (oldSchedGroup != 3) {
                    Bundle b3 = new Bundle();
                    str3 = ": ";
                    ComponentName cn3 = new ComponentName(app.info.packageName, "");
                    Intent i3 = new Intent();
                    i3.setComponent(cn3);
                    this.mService.notifyActivityStateChange(i3, 7, b3);
                    app.getWindowProcessController().onTopProcChanged();
                    if (this.mService.mUseFifoUiScheduling) {
                        app.savedPriority = Process.getThreadPriority(app.pid);
                        ActivityManagerService activityManagerService5 = this.mService;
                        ActivityManagerService.scheduleAsFifoPriority(app.pid, true);
                        if (app.renderThreadTid != 0) {
                            ActivityManagerService activityManagerService6 = this.mService;
                            ActivityManagerService.scheduleAsFifoPriority(app.renderThreadTid, true);
                            if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ) {
                                Slog.d("UI_FIFO", "Set RenderThread (TID " + app.renderThreadTid + ") to FIFO");
                            }
                        } else if (ActivityManagerDebugConfig.DEBUG_OOM_ADJ) {
                            Slog.d("UI_FIFO", "Not setting RenderThread TID");
                        }
                    } else {
                        Process.setThreadPriority(app.pid, -10);
                        if (app.renderThreadTid != 0) {
                            Process.setThreadPriority(app.renderThreadTid, -10);
                        }
                    }
                } else {
                    str3 = ": ";
                }
            }
        }
        if (app.repForegroundActivities == app.hasForegroundActivities()) {
            changes = 0;
        } else {
            app.repForegroundActivities = app.hasForegroundActivities();
            int changes3 = 0 | 1;
            changes = changes3;
        }
        if (app.getReportedProcState() != app.getCurProcState()) {
            app.setReportedProcState(app.getCurProcState());
            if (app.thread != null) {
                try {
                    app.thread.setProcessState(app.getReportedProcState());
                } catch (RemoteException e7) {
                }
            }
        }
        if (app.setProcState == 21 || ProcessList.procStatesDifferForMem(app.getCurProcState(), app.setProcState)) {
            app.lastStateTime = now;
            app.nextPssTime = ProcessList.computeNextPssTime(app.getCurProcState(), app.procStateMemTracker, this.mService.mTestPssMode, this.mService.mAtmInternal.isSleeping(), now);
            if (ActivityManagerDebugConfig.DEBUG_PSS) {
                Slog.d("ActivityManager", "Process state change from " + ProcessList.makeProcStateString(app.setProcState) + str + ProcessList.makeProcStateString(app.getCurProcState()) + " next pss in " + (app.nextPssTime - now) + str3 + app);
            }
        } else if ((now > app.nextPssTime || (now > app.lastPssTime + AppStandbyController.SettingsObserver.DEFAULT_STRONG_USAGE_TIMEOUT && now > app.lastStateTime + ProcessList.minTimeFromStateChange(this.mService.mTestPssMode))) && this.mService.requestPssLocked(app, app.setProcState)) {
            str = str;
            str2 = str2;
            changes = changes;
            str3 = str3;
            app.nextPssTime = ProcessList.computeNextPssTime(app.getCurProcState(), app.procStateMemTracker, this.mService.mTestPssMode, this.mService.mAtmInternal.isSleeping(), now);
        } else {
            changes = changes;
            str = str;
            str2 = str2;
            str3 = str3;
        }
        if (app.setProcState != app.getCurProcState()) {
            if (ActivityTaskManagerDebugConfig.DEBUG_SWITCH || ActivityManagerDebugConfig.DEBUG_OOM_ADJ || this.mService.mCurOomAdjUid == app.uid) {
                String msg4 = "Proc state change of " + app.processName + str + ProcessList.makeProcStateString(app.getCurProcState()) + " (" + app.getCurProcState() + "): " + app.adjType;
                reportOomAdjMessageLocked("ActivityManager", msg4);
            }
            boolean setImportant = app.setProcState < 11;
            boolean curImportant = app.getCurProcState() < 11;
            if (setImportant && !curImportant) {
                app.setWhenUnimportant(now);
                app.lastCpuTime = 0L;
            }
            maybeUpdateUsageStatsLocked(app, nowElapsed);
            maybeUpdateLastTopTime(app, now);
            app.setProcState = app.getCurProcState();
            if (app.setProcState >= 15) {
                app.notCachedSinceIdle = false;
            }
            if (!doingAll) {
                ActivityManagerService activityManagerService7 = this.mService;
                activityManagerService7.setProcessTrackerStateLocked(app, activityManagerService7.mProcessStats.getMemFactorLocked(), now);
            } else {
                app.procStateChanged = true;
            }
        } else if (app.reportedInteraction && nowElapsed - app.getInteractionEventTime() > this.mConstants.USAGE_STATS_INTERACTION_INTERVAL) {
            maybeUpdateUsageStatsLocked(app, nowElapsed);
        } else if (!app.reportedInteraction && nowElapsed - app.getFgInteractionTime() > this.mConstants.SERVICE_USAGE_INTERACTION_TIME) {
            maybeUpdateUsageStatsLocked(app, nowElapsed);
        }
        if (changes != 0) {
            if (ActivityManagerDebugConfig.DEBUG_PROCESS_OBSERVERS) {
                StringBuilder sb = new StringBuilder();
                sb.append("Changes in ");
                sb.append(app);
                sb.append(str3);
                changes2 = changes;
                sb.append(changes2);
                Slog.i("ActivityManager", sb.toString());
            } else {
                changes2 = changes;
            }
            ActivityManagerService.ProcessChangeItem item = this.mService.enqueueProcessChangeItemLocked(app.pid, app.info.uid);
            item.changes = changes2;
            item.foregroundActivities = app.repForegroundActivities;
            if (ActivityManagerDebugConfig.DEBUG_PROCESS_OBSERVERS) {
                Slog.i("ActivityManager", "Item " + Integer.toHexString(System.identityHashCode(item)) + str2 + app.toShortString() + ": changes=" + item.changes + " foreground=" + item.foregroundActivities + " type=" + app.adjType + " source=" + app.adjSource + " target=" + app.adjTarget);
            }
        }
        return success;
    }

    @VisibleForTesting
    void maybeUpdateUsageStats(ProcessRecord app, long nowElapsed) {
        synchronized (this.mService) {
            try {
                ActivityManagerService.boostPriorityForLockedSection();
                maybeUpdateUsageStatsLocked(app, nowElapsed);
            } finally {
                ActivityManagerService.resetPriorityAfterLockedSection();
            }
        }
    }

    @GuardedBy({"mService"})
    private void maybeUpdateUsageStatsLocked(ProcessRecord app, long nowElapsed) {
        boolean isInteraction;
        if (ActivityManagerDebugConfig.DEBUG_USAGE_STATS) {
            Slog.d(TAG, "Checking proc [" + Arrays.toString(app.getPackageList()) + "] state changes: old = " + app.setProcState + ", new = " + app.getCurProcState());
        }
        if (this.mService.mUsageStatsService == null) {
            return;
        }
        if (app.getCurProcState() <= 2 || app.getCurProcState() == 4) {
            isInteraction = true;
            app.setFgInteractionTime(0L);
        } else if (app.getCurProcState() > 5) {
            isInteraction = app.getCurProcState() <= 7;
            app.setFgInteractionTime(0L);
        } else if (app.getFgInteractionTime() == 0) {
            app.setFgInteractionTime(nowElapsed);
            isInteraction = false;
        } else {
            isInteraction = nowElapsed > app.getFgInteractionTime() + this.mConstants.SERVICE_USAGE_INTERACTION_TIME;
        }
        if (isInteraction && (!app.reportedInteraction || nowElapsed - app.getInteractionEventTime() > this.mConstants.USAGE_STATS_INTERACTION_INTERVAL)) {
            app.setInteractionEventTime(nowElapsed);
            String[] packages = app.getPackageList();
            if (packages != null) {
                for (String str : packages) {
                    this.mService.mUsageStatsService.reportEvent(str, app.userId, 6);
                }
            }
        }
        app.reportedInteraction = isInteraction;
        if (!isInteraction) {
            app.setInteractionEventTime(0L);
        }
    }

    private void maybeUpdateLastTopTime(ProcessRecord app, long nowUptime) {
        if (app.setProcState <= 2 && app.getCurProcState() > 2) {
            app.lastTopTime = nowUptime;
        }
    }

    @GuardedBy({"mService"})
    void idleUidsLocked() {
        int N = this.mActiveUids.size();
        if (N <= 0) {
            return;
        }
        long nowElapsed = SystemClock.elapsedRealtime();
        long maxBgTime = nowElapsed - this.mConstants.BACKGROUND_SETTLE_TIME;
        long nextTime = 0;
        PowerManagerInternal powerManagerInternal = this.mLocalPowerManager;
        if (powerManagerInternal != null) {
            powerManagerInternal.startUidChanges();
        }
        for (int i = N - 1; i >= 0; i--) {
            UidRecord uidRec = this.mActiveUids.valueAt(i);
            long bgTime = uidRec.lastBackgroundTime;
            if (bgTime > 0 && !uidRec.idle) {
                if (bgTime <= maxBgTime) {
                    EventLogTags.writeAmUidIdle(uidRec.uid);
                    uidRec.idle = true;
                    uidRec.setIdle = true;
                    this.mService.doStopUidLocked(uidRec.uid, uidRec);
                } else if (nextTime == 0 || nextTime > bgTime) {
                    nextTime = bgTime;
                }
            }
        }
        PowerManagerInternal powerManagerInternal2 = this.mLocalPowerManager;
        if (powerManagerInternal2 != null) {
            powerManagerInternal2.finishUidChanges();
        }
        if (nextTime > 0) {
            this.mService.mHandler.removeMessages(58);
            this.mService.mHandler.sendEmptyMessageDelayed(58, (this.mConstants.BACKGROUND_SETTLE_TIME + nextTime) - nowElapsed);
        }
    }

    @GuardedBy({"mService"})
    final void setAppIdTempWhitelistStateLocked(int appId, boolean onWhitelist) {
        boolean changed = false;
        for (int i = this.mActiveUids.size() - 1; i >= 0; i--) {
            UidRecord uidRec = this.mActiveUids.valueAt(i);
            if (UserHandle.getAppId(uidRec.uid) == appId && uidRec.curWhitelist != onWhitelist) {
                uidRec.curWhitelist = onWhitelist;
                changed = true;
            }
        }
        if (changed) {
            updateOomAdjLocked(OOM_ADJ_REASON_WHITELIST);
        }
    }

    @GuardedBy({"mService"})
    final void setUidTempWhitelistStateLocked(int uid, boolean onWhitelist) {
        UidRecord uidRec = this.mActiveUids.get(uid);
        if (uidRec != null && uidRec.curWhitelist != onWhitelist) {
            uidRec.curWhitelist = onWhitelist;
            updateOomAdjLocked(OOM_ADJ_REASON_WHITELIST);
        }
    }

    @GuardedBy({"mService"})
    void dumpProcessListVariablesLocked(ProtoOutputStream proto) {
        proto.write(1120986464305L, this.mAdjSeq);
        proto.write(1120986464306L, this.mProcessList.mLruSeq);
        proto.write(1120986464307L, this.mNumNonCachedProcs);
        proto.write(1120986464309L, this.mNumServiceProcs);
        proto.write(1120986464310L, this.mNewNumServiceProcs);
    }

    @GuardedBy({"mService"})
    void dumpSequenceNumbersLocked(PrintWriter pw) {
        pw.println("  mAdjSeq=" + this.mAdjSeq + " mLruSeq=" + this.mProcessList.mLruSeq);
    }

    @GuardedBy({"mService"})
    void dumpProcCountsLocked(PrintWriter pw) {
        pw.println("  mNumNonCachedProcs=" + this.mNumNonCachedProcs + " (" + this.mProcessList.getLruSizeLocked() + " total) mNumCachedHiddenProcs=" + this.mNumCachedHiddenProcs + " mNumServiceProcs=" + this.mNumServiceProcs + " mNewNumServiceProcs=" + this.mNewNumServiceProcs);
    }

    @GuardedBy({"mService"})
    void dumpAppCompactorSettings(PrintWriter pw) {
        this.mAppCompact.dump(pw);
    }
}
