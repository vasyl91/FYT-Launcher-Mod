package com.android.server.am;

import android.content.IIntentReceiver;
import android.content.IIntentSender;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteCallbackList;
import android.util.ArrayMap;
import android.util.ArraySet;
import android.util.TimeUtils;
import com.android.internal.os.IResultReceiver;
import com.android.internal.util.function.pooled.PooledLambda;
import com.android.server.wm.SafeActivityOptions;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.Objects;
import java.util.function.Consumer;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public final class PendingIntentRecord extends IIntentSender.Stub {
    public static final int FLAG_ACTIVITY_SENDER = 1;
    public static final int FLAG_BROADCAST_SENDER = 2;
    public static final int FLAG_SERVICE_SENDER = 4;
    private static final String TAG = "ActivityManager";
    final PendingIntentController controller;
    final Key key;
    String lastTag;
    String lastTagPrefix;
    private RemoteCallbackList<IResultReceiver> mCancelCallbacks;
    String stringName;
    final int uid;
    private ArrayMap<IBinder, Long> whitelistDuration;
    boolean sent = false;
    boolean canceled = false;
    private ArraySet<IBinder> mAllowBgActivityStartsForActivitySender = new ArraySet<>();
    private ArraySet<IBinder> mAllowBgActivityStartsForBroadcastSender = new ArraySet<>();
    private ArraySet<IBinder> mAllowBgActivityStartsForServiceSender = new ArraySet<>();
    public final WeakReference<PendingIntentRecord> ref = new WeakReference<>(this);

    static final class Key {
        private static final int ODD_PRIME_NUMBER = 37;
        final IBinder activity;
        Intent[] allIntents;
        String[] allResolvedTypes;
        final int flags;
        final int hashCode;
        final SafeActivityOptions options;
        final String packageName;
        final int requestCode;
        final Intent requestIntent;
        final String requestResolvedType;
        final int type;
        final int userId;
        final String who;

        Key(int _t, String _p, IBinder _a, String _w, int _r, Intent[] _i, String[] _it, int _f, SafeActivityOptions _o, int _userId) {
            this.type = _t;
            this.packageName = _p;
            this.activity = _a;
            this.who = _w;
            this.requestCode = _r;
            this.requestIntent = _i != null ? _i[_i.length - 1] : null;
            this.requestResolvedType = _it != null ? _it[_it.length - 1] : null;
            this.allIntents = _i;
            this.allResolvedTypes = _it;
            this.flags = _f;
            this.options = _o;
            this.userId = _userId;
            int hash = (((((23 * 37) + _f) * 37) + _r) * 37) + _userId;
            hash = _w != null ? (hash * 37) + _w.hashCode() : hash;
            hash = _a != null ? (hash * 37) + _a.hashCode() : hash;
            Intent intent = this.requestIntent;
            hash = intent != null ? (hash * 37) + intent.filterHashCode() : hash;
            String str = this.requestResolvedType;
            this.hashCode = ((((str != null ? (hash * 37) + str.hashCode() : hash) * 37) + (_p != null ? _p.hashCode() : 0)) * 37) + _t;
        }

        public boolean equals(Object otherObj) {
            if (otherObj == null) {
                return false;
            }
            try {
                Key other = (Key) otherObj;
                if (this.type != other.type || this.userId != other.userId || !Objects.equals(this.packageName, other.packageName) || this.activity != other.activity || !Objects.equals(this.who, other.who) || this.requestCode != other.requestCode) {
                    return false;
                }
                Intent intent = this.requestIntent;
                Intent intent2 = other.requestIntent;
                if (intent != intent2) {
                    if (this.requestIntent != null) {
                        if (!this.requestIntent.filterEquals(intent2)) {
                            return false;
                        }
                    } else if (intent2 != null) {
                        return false;
                    }
                }
                if (!Objects.equals(this.requestResolvedType, other.requestResolvedType) || this.flags != other.flags) {
                    return false;
                }
                return true;
            } catch (ClassCastException e) {
                return false;
            }
        }

        public int hashCode() {
            return this.hashCode;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Key{");
            sb.append(typeName());
            sb.append(" pkg=");
            sb.append(this.packageName);
            sb.append(" intent=");
            Intent intent = this.requestIntent;
            sb.append(intent != null ? intent.toShortString(false, true, false, false) : "<null>");
            sb.append(" flags=0x");
            sb.append(Integer.toHexString(this.flags));
            sb.append(" u=");
            sb.append(this.userId);
            sb.append("}");
            return sb.toString();
        }

        String typeName() {
            int i = this.type;
            if (i == 1) {
                return "broadcastIntent";
            }
            if (i == 2) {
                return "startActivity";
            }
            if (i == 3) {
                return "activityResult";
            }
            if (i == 4) {
                return "startService";
            }
            if (i == 5) {
                return "startForegroundService";
            }
            return Integer.toString(i);
        }
    }

    PendingIntentRecord(PendingIntentController _controller, Key _k, int _u) {
        this.controller = _controller;
        this.key = _k;
        this.uid = _u;
    }

    void setWhitelistDurationLocked(IBinder whitelistToken, long duration) {
        if (duration > 0) {
            if (this.whitelistDuration == null) {
                this.whitelistDuration = new ArrayMap<>();
            }
            this.whitelistDuration.put(whitelistToken, Long.valueOf(duration));
        } else {
            ArrayMap<IBinder, Long> arrayMap = this.whitelistDuration;
            if (arrayMap != null) {
                arrayMap.remove(whitelistToken);
                if (this.whitelistDuration.size() <= 0) {
                    this.whitelistDuration = null;
                }
            }
        }
        this.stringName = null;
    }

    void setAllowBgActivityStarts(IBinder token, int flags) {
        if (token == null) {
            return;
        }
        if ((flags & 1) != 0) {
            this.mAllowBgActivityStartsForActivitySender.add(token);
        }
        if ((flags & 2) != 0) {
            this.mAllowBgActivityStartsForBroadcastSender.add(token);
        }
        if ((flags & 4) != 0) {
            this.mAllowBgActivityStartsForServiceSender.add(token);
        }
    }

    void clearAllowBgActivityStarts(IBinder token) {
        if (token == null) {
            return;
        }
        this.mAllowBgActivityStartsForActivitySender.remove(token);
        this.mAllowBgActivityStartsForBroadcastSender.remove(token);
        this.mAllowBgActivityStartsForServiceSender.remove(token);
    }

    public void registerCancelListenerLocked(IResultReceiver receiver) {
        if (this.mCancelCallbacks == null) {
            this.mCancelCallbacks = new RemoteCallbackList<>();
        }
        this.mCancelCallbacks.register(receiver);
    }

    public void unregisterCancelListenerLocked(IResultReceiver receiver) {
        RemoteCallbackList<IResultReceiver> remoteCallbackList = this.mCancelCallbacks;
        if (remoteCallbackList == null) {
            return;
        }
        remoteCallbackList.unregister(receiver);
        if (this.mCancelCallbacks.getRegisteredCallbackCount() <= 0) {
            this.mCancelCallbacks = null;
        }
    }

    public RemoteCallbackList<IResultReceiver> detachCancelListenersLocked() {
        RemoteCallbackList<IResultReceiver> listeners = this.mCancelCallbacks;
        this.mCancelCallbacks = null;
        return listeners;
    }

    public void send(int code, Intent intent, String resolvedType, IBinder whitelistToken, IIntentReceiver finishedReceiver, String requiredPermission, Bundle options) throws Throwable {
        sendInner(code, intent, resolvedType, whitelistToken, finishedReceiver, requiredPermission, null, null, 0, 0, 0, options);
    }

    public int sendWithResult(int code, Intent intent, String resolvedType, IBinder whitelistToken, IIntentReceiver finishedReceiver, String requiredPermission, Bundle options) {
        return sendInner(code, intent, resolvedType, whitelistToken, finishedReceiver, requiredPermission, null, null, 0, 0, 0, options);
    }

    /* JADX WARN: Bottom block not found for handler: all -> 0x044e */
    /* JADX WARN: Code duplicated, block: B:100:0x01b4 A[Catch: all -> 0x01f8, TryCatch #15 {all -> 0x01f8, blocks: (B:90:0x016f, B:92:0x017d, B:94:0x0198, B:101:0x01bf, B:95:0x01a0, B:97:0x01a6, B:98:0x01ae, B:100:0x01b4, B:102:0x01d9, B:113:0x020c, B:118:0x021e, B:132:0x0244, B:136:0x0255, B:142:0x0269, B:147:0x028a, B:148:0x0297), top: B:265:0x016f, inners: #30 }] */
    /* JADX WARN: Code duplicated, block: B:102:0x01d9 A[Catch: all -> 0x01f8, TRY_LEAVE, TryCatch #15 {all -> 0x01f8, blocks: (B:90:0x016f, B:92:0x017d, B:94:0x0198, B:101:0x01bf, B:95:0x01a0, B:97:0x01a6, B:98:0x01ae, B:100:0x01b4, B:102:0x01d9, B:113:0x020c, B:118:0x021e, B:132:0x0244, B:136:0x0255, B:142:0x0269, B:147:0x028a, B:148:0x0297), top: B:265:0x016f, inners: #30 }] */
    /* JADX WARN: Code duplicated, block: B:107:0x0200  */
    /* JADX WARN: Code duplicated, block: B:108:0x0202  */
    /* JADX WARN: Code duplicated, block: B:113:0x020c A[Catch: all -> 0x01f8, TRY_ENTER, TRY_LEAVE, TryCatch #15 {all -> 0x01f8, blocks: (B:90:0x016f, B:92:0x017d, B:94:0x0198, B:101:0x01bf, B:95:0x01a0, B:97:0x01a6, B:98:0x01ae, B:100:0x01b4, B:102:0x01d9, B:113:0x020c, B:118:0x021e, B:132:0x0244, B:136:0x0255, B:142:0x0269, B:147:0x028a, B:148:0x0297), top: B:265:0x016f, inners: #30 }] */
    /* JADX WARN: Code duplicated, block: B:115:0x0218  */
    /* JADX WARN: Code duplicated, block: B:118:0x021e A[Catch: all -> 0x01f8, TRY_ENTER, TRY_LEAVE, TryCatch #15 {all -> 0x01f8, blocks: (B:90:0x016f, B:92:0x017d, B:94:0x0198, B:101:0x01bf, B:95:0x01a0, B:97:0x01a6, B:98:0x01ae, B:100:0x01b4, B:102:0x01d9, B:113:0x020c, B:118:0x021e, B:132:0x0244, B:136:0x0255, B:142:0x0269, B:147:0x028a, B:148:0x0297), top: B:265:0x016f, inners: #30 }] */
    /* JADX WARN: Code duplicated, block: B:121:0x022a  */
    /* JADX WARN: Code duplicated, block: B:125:0x0233 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:126:0x0235  */
    /* JADX WARN: Code duplicated, block: B:128:0x0238  */
    /* JADX WARN: Code duplicated, block: B:130:0x023c A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:134:0x0250  */
    /* JADX WARN: Code duplicated, block: B:135:0x0253  */
    /* JADX WARN: Code duplicated, block: B:138:0x0261 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:141:0x0267  */
    /* JADX WARN: Code duplicated, block: B:148:0x0297 A[Catch: all -> 0x01f8, TRY_LEAVE, TryCatch #15 {all -> 0x01f8, blocks: (B:90:0x016f, B:92:0x017d, B:94:0x0198, B:101:0x01bf, B:95:0x01a0, B:97:0x01a6, B:98:0x01ae, B:100:0x01b4, B:102:0x01d9, B:113:0x020c, B:118:0x021e, B:132:0x0244, B:136:0x0255, B:142:0x0269, B:147:0x028a, B:148:0x0297), top: B:265:0x016f, inners: #30 }] */
    /* JADX WARN: Code duplicated, block: B:154:0x02cb A[Catch: all -> 0x02fe, RuntimeException -> 0x0304, TRY_LEAVE, TryCatch #29 {RuntimeException -> 0x0304, all -> 0x02fe, blocks: (B:152:0x02c4, B:154:0x02cb), top: B:300:0x02c4 }] */
    /* JADX WARN: Code duplicated, block: B:164:0x030b  */
    /* JADX WARN: Code duplicated, block: B:177:0x0361  */
    /* JADX WARN: Code duplicated, block: B:180:0x0375  */
    /* JADX WARN: Code duplicated, block: B:181:0x0377  */
    /* JADX WARN: Code duplicated, block: B:184:0x0384 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:187:0x038a  */
    /* JADX WARN: Code duplicated, block: B:190:0x03a6  */
    /* JADX WARN: Code duplicated, block: B:199:0x03bf  */
    /* JADX WARN: Code duplicated, block: B:220:0x03f7  */
    /* JADX WARN: Code duplicated, block: B:265:0x016f A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:270:0x00f3 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:284:0x010d A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:286:0x00cd A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:290:0x02be A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:298:0x0244 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:300:0x02c4 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:61:0x00e1 A[Catch: all -> 0x00d5, TRY_ENTER, TRY_LEAVE, TryCatch #28 {all -> 0x00d5, blocks: (B:54:0x00cd, B:61:0x00e1), top: B:286:0x00cd }] */
    /* JADX WARN: Code duplicated, block: B:63:0x00ea A[Catch: all -> 0x0428, TRY_ENTER, TRY_LEAVE, TryCatch #5 {, blocks: (B:52:0x00c7, B:58:0x00da, B:63:0x00ea), top: B:254:0x00c7 }] */
    /* JADX WARN: Code duplicated, block: B:71:0x0104  */
    /* JADX WARN: Code duplicated, block: B:77:0x0113 A[Catch: all -> 0x0155, TryCatch #27 {all -> 0x0155, blocks: (B:75:0x010d, B:77:0x0113, B:79:0x011a, B:81:0x013c, B:82:0x0148), top: B:284:0x010d }] */
    /* JADX WARN: Code duplicated, block: B:86:0x015a  */
    /* JADX WARN: Code duplicated, block: B:92:0x017d A[Catch: all -> 0x01f8, TryCatch #15 {all -> 0x01f8, blocks: (B:90:0x016f, B:92:0x017d, B:94:0x0198, B:101:0x01bf, B:95:0x01a0, B:97:0x01a6, B:98:0x01ae, B:100:0x01b4, B:102:0x01d9, B:113:0x020c, B:118:0x021e, B:132:0x0244, B:136:0x0255, B:142:0x0269, B:147:0x028a, B:148:0x0297), top: B:265:0x016f, inners: #30 }] */
    /* JADX WARN: Code duplicated, block: B:94:0x0198 A[Catch: all -> 0x01f8, TryCatch #15 {all -> 0x01f8, blocks: (B:90:0x016f, B:92:0x017d, B:94:0x0198, B:101:0x01bf, B:95:0x01a0, B:97:0x01a6, B:98:0x01ae, B:100:0x01b4, B:102:0x01d9, B:113:0x020c, B:118:0x021e, B:132:0x0244, B:136:0x0255, B:142:0x0269, B:147:0x028a, B:148:0x0297), top: B:265:0x016f, inners: #30 }] */
    /* JADX WARN: Code duplicated, block: B:95:0x01a0 A[Catch: all -> 0x01f8, TryCatch #15 {all -> 0x01f8, blocks: (B:90:0x016f, B:92:0x017d, B:94:0x0198, B:101:0x01bf, B:95:0x01a0, B:97:0x01a6, B:98:0x01ae, B:100:0x01b4, B:102:0x01d9, B:113:0x020c, B:118:0x021e, B:132:0x0244, B:136:0x0255, B:142:0x0269, B:147:0x028a, B:148:0x0297), top: B:265:0x016f, inners: #30 }] */
    /* JADX WARN: Code duplicated, block: B:97:0x01a6 A[Catch: all -> 0x01f8, TryCatch #15 {all -> 0x01f8, blocks: (B:90:0x016f, B:92:0x017d, B:94:0x0198, B:101:0x01bf, B:95:0x01a0, B:97:0x01a6, B:98:0x01ae, B:100:0x01b4, B:102:0x01d9, B:113:0x020c, B:118:0x021e, B:132:0x0244, B:136:0x0255, B:142:0x0269, B:147:0x028a, B:148:0x0297), top: B:265:0x016f, inners: #30 }] */
    /* JADX WARN: Code duplicated, block: B:98:0x01ae A[Catch: all -> 0x01f8, TryCatch #15 {all -> 0x01f8, blocks: (B:90:0x016f, B:92:0x017d, B:94:0x0198, B:101:0x01bf, B:95:0x01a0, B:97:0x01a6, B:98:0x01ae, B:100:0x01b4, B:102:0x01d9, B:113:0x020c, B:118:0x021e, B:132:0x0244, B:136:0x0255, B:142:0x0269, B:147:0x028a, B:148:0x0297), top: B:265:0x016f, inners: #30 }] */
    /* JADX WARN: Instruction removed from duplicated block: B:102:0x01d9, please report this as an issue */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v1 */
    /* JADX WARN: Type inference failed for: r10v4 */
    /* JADX WARN: Type inference failed for: r10v5 */
    /* JADX WARN: Type inference failed for: r10v6 */
    /* JADX WARN: Type inference failed for: r10v7, types: [android.content.Intent] */
    /* JADX WARN: Type inference failed for: r19v0, types: [int] */
    /* JADX WARN: Type inference failed for: r19v11 */
    /* JADX WARN: Type inference failed for: r19v14 */
    /* JADX WARN: Type inference failed for: r19v15 */
    /* JADX WARN: Type inference failed for: r19v16 */
    /* JADX WARN: Type inference failed for: r19v18 */
    /* JADX WARN: Type inference failed for: r19v19 */
    /* JADX WARN: Type inference failed for: r19v2 */
    /* JADX WARN: Type inference failed for: r19v20 */
    /* JADX WARN: Type inference failed for: r19v21 */
    /* JADX WARN: Type inference failed for: r19v22 */
    /* JADX WARN: Type inference failed for: r19v23 */
    /* JADX WARN: Type inference failed for: r19v24 */
    /* JADX WARN: Type inference failed for: r19v25 */
    /* JADX WARN: Type inference failed for: r19v26 */
    /* JADX WARN: Type inference failed for: r19v27 */
    /* JADX WARN: Type inference failed for: r19v28 */
    /* JADX WARN: Type inference failed for: r19v4 */
    /* JADX WARN: Type inference failed for: r19v5 */
    /* JADX WARN: Type inference failed for: r19v6 */
    /* JADX WARN: Type inference failed for: r19v7 */
    /* JADX WARN: Type inference failed for: r19v8 */
    /* JADX WARN: Type inference failed for: r19v9 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public int sendInner(int r39, android.content.Intent r40, java.lang.String r41, android.os.IBinder r42, android.content.IIntentReceiver r43, java.lang.String r44, android.os.IBinder r45, java.lang.String r46, int r47, int r48, int r49, android.os.Bundle r50) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1104
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.server.am.PendingIntentRecord.sendInner(int, android.content.Intent, java.lang.String, android.os.IBinder, android.content.IIntentReceiver, java.lang.String, android.os.IBinder, java.lang.String, int, int, int, android.os.Bundle):int");
    }

    protected void finalize() throws Throwable {
        try {
            if (!this.canceled) {
                this.controller.mH.sendMessage(PooledLambda.obtainMessage(new Consumer() { // from class: com.android.server.am.-$$Lambda$PendingIntentRecord$hlEHdgdG_SS5n3v7IRr7e6QZgLQ
                    @Override // java.util.function.Consumer
                    public final void accept(Object obj) {
                        ((PendingIntentRecord) obj).completeFinalize();
                    }
                }, this));
            }
        } finally {
            super/*java.lang.Object*/.finalize();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void completeFinalize() {
        synchronized (this.controller.mLock) {
            WeakReference<PendingIntentRecord> current = this.controller.mIntentSenderRecords.get(this.key);
            if (current == this.ref) {
                this.controller.mIntentSenderRecords.remove(this.key);
            }
        }
    }

    public void dump(PrintWriter pw, String prefix) {
        pw.print(prefix);
        pw.print("uid=");
        pw.print(this.uid);
        pw.print(" packageName=");
        pw.print(this.key.packageName);
        pw.print(" type=");
        pw.print(this.key.typeName());
        pw.print(" flags=0x");
        pw.println(Integer.toHexString(this.key.flags));
        if (this.key.activity != null || this.key.who != null) {
            pw.print(prefix);
            pw.print("activity=");
            pw.print(this.key.activity);
            pw.print(" who=");
            pw.println(this.key.who);
        }
        if (this.key.requestCode != 0 || this.key.requestResolvedType != null) {
            pw.print(prefix);
            pw.print("requestCode=");
            pw.print(this.key.requestCode);
            pw.print(" requestResolvedType=");
            pw.println(this.key.requestResolvedType);
        }
        if (this.key.requestIntent != null) {
            pw.print(prefix);
            pw.print("requestIntent=");
            pw.println(this.key.requestIntent.toShortString(false, true, true, true));
        }
        if (this.sent || this.canceled) {
            pw.print(prefix);
            pw.print("sent=");
            pw.print(this.sent);
            pw.print(" canceled=");
            pw.println(this.canceled);
        }
        if (this.whitelistDuration != null) {
            pw.print(prefix);
            pw.print("whitelistDuration=");
            for (int i = 0; i < this.whitelistDuration.size(); i++) {
                if (i != 0) {
                    pw.print(", ");
                }
                pw.print(Integer.toHexString(System.identityHashCode(this.whitelistDuration.keyAt(i))));
                pw.print(":");
                TimeUtils.formatDuration(this.whitelistDuration.valueAt(i).longValue(), pw);
            }
            pw.println();
        }
        if (this.mCancelCallbacks != null) {
            pw.print(prefix);
            pw.println("mCancelCallbacks:");
            for (int i2 = 0; i2 < this.mCancelCallbacks.getRegisteredCallbackCount(); i2++) {
                pw.print(prefix);
                pw.print("  #");
                pw.print(i2);
                pw.print(": ");
                pw.println(this.mCancelCallbacks.getRegisteredCallbackItem(i2));
            }
        }
    }

    public String toString() {
        String str = this.stringName;
        if (str != null) {
            return str;
        }
        StringBuilder sb = new StringBuilder(128);
        sb.append("PendingIntentRecord{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(' ');
        sb.append(this.key.packageName);
        sb.append(' ');
        sb.append(this.key.typeName());
        if (this.whitelistDuration != null) {
            sb.append(" (whitelist: ");
            for (int i = 0; i < this.whitelistDuration.size(); i++) {
                if (i != 0) {
                    sb.append(",");
                }
                sb.append(Integer.toHexString(System.identityHashCode(this.whitelistDuration.keyAt(i))));
                sb.append(":");
                TimeUtils.formatDuration(this.whitelistDuration.valueAt(i).longValue(), sb);
            }
            sb.append(")");
        }
        sb.append('}');
        String string = sb.toString();
        this.stringName = string;
        return string;
    }
}
