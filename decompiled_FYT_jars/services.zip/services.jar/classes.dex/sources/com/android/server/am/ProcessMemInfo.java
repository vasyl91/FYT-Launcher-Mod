package com.android.server.am;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class ProcessMemInfo {
    final String adjReason;
    final String adjType;
    long memtrack;
    final String name;
    final int oomAdj;
    final int pid;
    final int procState;
    long pss;
    long swapPss;

    public ProcessMemInfo(String _name, int _pid, int _oomAdj, int _procState, String _adjType, String _adjReason) {
        this.name = _name;
        this.pid = _pid;
        this.oomAdj = _oomAdj;
        this.procState = _procState;
        this.adjType = _adjType;
        this.adjReason = _adjReason;
    }
}
