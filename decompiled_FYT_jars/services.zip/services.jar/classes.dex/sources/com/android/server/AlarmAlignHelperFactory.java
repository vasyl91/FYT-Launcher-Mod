package com.android.server;

import android.content.Context;
import android.util.Log;
import java.lang.reflect.Constructor;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class AlarmAlignHelperFactory {
    private static final String TAG = "AlarmAlignHelperFactory";
    private static AlarmAlignHelper sInstance;

    public static synchronized AlarmAlignHelper getInstance(Context context) throws ClassNotFoundException {
        if (sInstance != null) {
            return sInstance;
        }
        Class<?> cls = null;
        try {
            cls = Class.forName("com.android.server.AlarmAlignHelperEx");
        } catch (Throwable th) {
            Log.d(TAG, "Can't find specific AlarmAlignHelperEx");
        }
        if (cls != null) {
            try {
                Constructor<?> constructor = cls.getConstructor(Context.class);
                if (constructor != null) {
                    sInstance = (AlarmAlignHelper) constructor.newInstance(context);
                }
            } catch (Throwable th2) {
                Log.e(TAG, "Can't create specific ObjectFactory");
            }
        }
        if (sInstance == null) {
            sInstance = new AlarmAlignHelper(context);
        }
        return sInstance;
    }
}
