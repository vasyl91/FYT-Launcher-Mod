package com.android.server.backup.encryption.chunking;

import java.io.IOException;
import java.io.OutputStream;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
interface DiffScriptWriter {

    public interface Factory {
        DiffScriptWriter create(OutputStream outputStream);
    }

    void flush() throws IOException;

    void writeByte(byte b) throws IOException;

    void writeChunk(long j, int i) throws IOException;
}
