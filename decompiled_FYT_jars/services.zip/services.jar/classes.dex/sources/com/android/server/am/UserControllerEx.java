package com.android.server.am;

import android.content.ComponentName;
import android.content.Intent;
import android.util.Slog;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
final class UserControllerEx extends UserController {
    private static final String TAG = "UserControllerEx";
    private final ActivityManagerService mAm;

    UserControllerEx(ActivityManagerService service) {
        super(service);
        this.mAm = service;
    }

    private final void start3rdPartyPersistentService(int userId) {
        String[] thirdPartyPersistSvcCompnts = ((ActivityManagerServiceEx) this.mAm).m3rdPartyPersistentSvcCompnts;
        for (String str : thirdPartyPersistSvcCompnts) {
            ComponentName compName = ComponentName.unflattenFromString(str);
            if (compName != null) {
                int pkgUid = this.mAm.getPackageManagerInternalLocked().getPackageUid(compName.getPackageName(), 0, userId);
                if (pkgUid != -1) {
                    this.mAm.backgroundWhitelistUid(pkgUid);
                    Intent intent = new Intent();
                    intent.setComponent(compName);
                    Slog.i(TAG, "Starting 3rd party persisitent service: " + intent);
                    this.mAm.mContext.startService(intent);
                } else {
                    Slog.i(TAG, "start3rdPartyPersistentService, can not find the package uid for " + compName);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // com.android.server.am.UserController
    /* JADX INFO: renamed from: finishUserUnlockedCompleted */
    public void lambda$finishUserUnlocked$2$UserController(UserState uss) throws Throwable {
        super.lambda$finishUserUnlocked$2$UserController(uss);
        start3rdPartyPersistentService(uss.mHandle.getIdentifier());
    }
}
