package com.android.server.backup;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class DataChangedJournal {
    private static final int BUFFER_SIZE_BYTES = 8192;
    private static final String FILE_NAME_PREFIX = "journal";
    private final File mFile;

    DataChangedJournal(File file) {
        this.mFile = file;
    }

    public void addPackage(String packageName) throws Exception {
        RandomAccessFile out = new RandomAccessFile(this.mFile, "rws");
        try {
            out.seek(out.length());
            out.writeUTF(packageName);
            $closeResource(null, out);
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                $closeResource(th, out);
                throw th2;
            }
        }
    }

    private static /* synthetic */ void $closeResource(Throwable x0, AutoCloseable x1) throws Exception {
        if (x0 == null) {
            x1.close();
            return;
        }
        try {
            x1.close();
        } catch (Throwable th) {
            x0.addSuppressed(th);
        }
    }

    public void forEach(Consumer<String> consumer) throws Exception {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(this.mFile), 8192);
        try {
            DataInputStream dataInputStream = new DataInputStream(bufferedInputStream);
            while (dataInputStream.available() > 0) {
                try {
                    String packageName = dataInputStream.readUTF();
                    consumer.accept(packageName);
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        $closeResource(th, dataInputStream);
                        throw th2;
                    }
                }
            }
            $closeResource(null, dataInputStream);
            $closeResource(null, bufferedInputStream);
        } catch (Throwable th3) {
            try {
                throw th3;
            } catch (Throwable th4) {
                $closeResource(th3, bufferedInputStream);
                throw th4;
            }
        }
    }

    public List<String> getPackages() throws Exception {
        final List<String> packages = new ArrayList<>();
        Objects.requireNonNull(packages);
        forEach(new Consumer() { // from class: com.android.server.backup.-$$Lambda$NsJlXDEZZRYyD6JsbnCsdcb4L4A
            @Override // java.util.function.Consumer
            public final void accept(Object obj) {
                packages.add((String) obj);
            }
        });
        return packages;
    }

    public boolean delete() {
        return this.mFile.delete();
    }

    public boolean equals(Object object) {
        if (!(object instanceof DataChangedJournal)) {
            return false;
        }
        DataChangedJournal that = (DataChangedJournal) object;
        try {
            return this.mFile.getCanonicalPath().equals(that.mFile.getCanonicalPath());
        } catch (IOException e) {
            return false;
        }
    }

    public String toString() {
        return this.mFile.toString();
    }

    static DataChangedJournal newJournal(File journalDirectory) throws IOException {
        return new DataChangedJournal(File.createTempFile(FILE_NAME_PREFIX, null, journalDirectory));
    }

    static ArrayList<DataChangedJournal> listJournals(File journalDirectory) {
        ArrayList<DataChangedJournal> journals = new ArrayList<>();
        for (File file : journalDirectory.listFiles()) {
            journals.add(new DataChangedJournal(file));
        }
        return journals;
    }
}
