package com.android.server.adb;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.debug.AdbManagerInternal;
import android.debug.IAdbManager;
import android.debug.IAdbTransport;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.os.SystemProperties;
import android.provider.Settings;
import android.sysprop.AdbProperties;
import android.util.ArrayMap;
import android.util.ArraySet;
import android.util.Slog;
import android.util.proto.ProtoOutputStream;
import com.android.internal.util.DumpUtils;
import com.android.internal.util.IndentingPrintWriter;
import com.android.internal.util.dump.DualDumpOutputStream;
import com.android.server.FgThread;
import com.android.server.LocalServices;
import com.android.server.SystemService;
import com.android.server.utils.PriorityDump;
import java.io.File;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Collections;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class AdbService extends IAdbManager.Stub {
    private static final boolean DEBUG = false;
    private static final int MSG_BOOT_COMPLETED = 2;
    private static final int MSG_ENABLE_ADB = 1;
    private static final String TAG = "AdbService";
    private static final String USB_PERSISTENT_CONFIG_PROPERTY = "persist.sys.usb.config";
    private boolean mAdbEnabled;
    private final ContentResolver mContentResolver;
    private final Context mContext;
    private AdbDebuggingManager mDebuggingManager;
    private final AdbHandler mHandler;
    private final ArrayMap<IBinder, IAdbTransport> mTransports;

    public static class Lifecycle extends SystemService {
        private AdbService mAdbService;

        public Lifecycle(Context context) {
            super(context);
        }

        @Override // com.android.server.SystemService
        public void onStart() {
            this.mAdbService = new AdbService(getContext());
            publishBinderService("adb", this.mAdbService);
        }

        @Override // com.android.server.SystemService
        public void onBootPhase(int phase) {
            if (phase == 550) {
                this.mAdbService.systemReady();
            } else if (phase == 1000) {
                this.mAdbService.bootCompleted();
            }
        }
    }

    private class AdbManagerInternalImpl extends AdbManagerInternal {
        private AdbManagerInternalImpl() {
        }

        public void registerTransport(IAdbTransport transport) {
            AdbService.this.mTransports.put(transport.asBinder(), transport);
        }

        public void unregisterTransport(IAdbTransport transport) {
            AdbService.this.mTransports.remove(transport.asBinder());
        }

        public boolean isAdbEnabled() {
            return AdbService.this.mAdbEnabled;
        }

        public File getAdbKeysFile() {
            return AdbService.this.mDebuggingManager.getUserKeyFile();
        }

        public File getAdbTempKeysFile() {
            return AdbService.this.mDebuggingManager.getAdbTempKeysFile();
        }
    }

    private final class AdbHandler extends Handler {
        AdbHandler(Looper looper) {
            super(looper);
            try {
                AdbService.this.mAdbEnabled = containsFunction(SystemProperties.get(AdbService.USB_PERSISTENT_CONFIG_PROPERTY, ""), "adb");
                AdbService.this.mContentResolver.registerContentObserver(Settings.Global.getUriFor("adb_enabled"), false, AdbService.this.new AdbSettingsObserver());
            } catch (Exception e) {
                Slog.e(AdbService.TAG, "Error initializing AdbHandler", e);
            }
        }

        private boolean containsFunction(String functions, String function) {
            int index = functions.indexOf(function);
            if (index < 0) {
                return false;
            }
            if (index > 0 && functions.charAt(index - 1) != ',') {
                return false;
            }
            int charAfter = function.length() + index;
            if (charAfter < functions.length() && functions.charAt(charAfter) != ',') {
                return false;
            }
            return true;
        }

        public void sendMessage(int i, boolean z) {
            removeMessages(i);
            Message messageObtain = Message.obtain(this, i);
            messageObtain.arg1 = z ? 1 : 0;
            sendMessage(messageObtain);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            int i = msg.what;
            if (i != 1) {
                if (i == 2 && AdbService.this.mDebuggingManager != null) {
                    AdbService.this.mDebuggingManager.setAdbEnabled(AdbService.this.mAdbEnabled);
                    return;
                }
                return;
            }
            AdbService.this.setAdbEnabled(msg.arg1 == 1);
        }
    }

    private class AdbSettingsObserver extends ContentObserver {
        AdbSettingsObserver() {
            super(null);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange) {
            boolean enable = Settings.Global.getInt(AdbService.this.mContentResolver, "adb_enabled", 0) > 0;
            AdbService.this.mHandler.sendMessage(1, enable);
        }
    }

    private AdbService(Context context) {
        this.mTransports = new ArrayMap<>();
        this.mContext = context;
        this.mContentResolver = context.getContentResolver();
        boolean secureAdbEnabled = ((Boolean) AdbProperties.secure().orElse(false)).booleanValue();
        boolean dataEncrypted = "1".equals(SystemProperties.get("vold.decrypt"));
        if (secureAdbEnabled && !dataEncrypted) {
            this.mDebuggingManager = new AdbDebuggingManager(context);
        }
        this.mHandler = new AdbHandler(FgThread.get().getLooper());
        LocalServices.addService(AdbManagerInternal.class, new AdbManagerInternalImpl());
    }

    public void systemReady() {
        try {
            Settings.Global.putInt(this.mContentResolver, "adb_enabled", this.mAdbEnabled ? 1 : 0);
        } catch (SecurityException e) {
            Slog.d(TAG, "ADB_ENABLED is restricted.");
        }
    }

    public void bootCompleted() {
        this.mHandler.sendEmptyMessage(2);
    }

    public void allowDebugging(boolean alwaysAllow, String publicKey) {
        this.mContext.enforceCallingOrSelfPermission("android.permission.MANAGE_DEBUGGING", null);
        AdbDebuggingManager adbDebuggingManager = this.mDebuggingManager;
        if (adbDebuggingManager != null) {
            adbDebuggingManager.allowDebugging(alwaysAllow, publicKey);
        }
    }

    public void denyDebugging() {
        this.mContext.enforceCallingOrSelfPermission("android.permission.MANAGE_DEBUGGING", null);
        AdbDebuggingManager adbDebuggingManager = this.mDebuggingManager;
        if (adbDebuggingManager != null) {
            adbDebuggingManager.denyDebugging();
        }
    }

    public void clearDebuggingKeys() {
        this.mContext.enforceCallingOrSelfPermission("android.permission.MANAGE_DEBUGGING", null);
        AdbDebuggingManager adbDebuggingManager = this.mDebuggingManager;
        if (adbDebuggingManager != null) {
            adbDebuggingManager.clearDebuggingKeys();
            return;
        }
        throw new RuntimeException("Cannot clear ADB debugging keys, AdbDebuggingManager not enabled");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setAdbEnabled(boolean enable) {
        if (enable == this.mAdbEnabled) {
            return;
        }
        this.mAdbEnabled = enable;
        for (IAdbTransport transport : this.mTransports.values()) {
            try {
                transport.onAdbEnabled(enable);
            } catch (RemoteException e) {
                Slog.w(TAG, "Unable to send onAdbEnabled to transport " + transport.toString());
            }
        }
        AdbDebuggingManager adbDebuggingManager = this.mDebuggingManager;
        if (adbDebuggingManager != null) {
            adbDebuggingManager.setAdbEnabled(enable);
        }
    }

    public void dump(FileDescriptor fd, PrintWriter writer, String[] args) {
        DualDumpOutputStream dump;
        if (DumpUtils.checkDumpPermission(this.mContext, TAG, writer)) {
            IndentingPrintWriter pw = new IndentingPrintWriter(writer, "  ");
            long ident = Binder.clearCallingIdentity();
            try {
                ArraySet<String> argsSet = new ArraySet<>();
                Collections.addAll(argsSet, args);
                boolean dumpAsProto = false;
                if (argsSet.contains(PriorityDump.PROTO_ARG)) {
                    dumpAsProto = true;
                }
                if (argsSet.size() == 0 || argsSet.contains("-a") || dumpAsProto) {
                    if (dumpAsProto) {
                        dump = new DualDumpOutputStream(new ProtoOutputStream(fd));
                    } else {
                        pw.println("ADB MANAGER STATE (dumpsys adb):");
                        dump = new DualDumpOutputStream(new IndentingPrintWriter(pw, "  "));
                    }
                    if (this.mDebuggingManager != null) {
                        this.mDebuggingManager.dump(dump, "debugging_manager", 1146756268033L);
                    }
                    dump.flush();
                } else {
                    pw.println("Dump current ADB state");
                    pw.println("  No commands available");
                }
            } finally {
                Binder.restoreCallingIdentity(ident);
            }
        }
    }
}
