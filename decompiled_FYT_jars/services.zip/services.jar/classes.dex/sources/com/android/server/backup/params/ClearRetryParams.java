package com.android.server.backup.params;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class ClearRetryParams {
    public String packageName;
    public String transportName;

    public ClearRetryParams(String transportName, String packageName) {
        this.transportName = transportName;
        this.packageName = packageName;
    }
}
