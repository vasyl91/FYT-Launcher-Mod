package com.android.server.backup;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class JobIdManager {
    public static int getJobIdForUserId(int minJobId, int maxJobId, int userId) {
        if (minJobId + userId > maxJobId) {
            throw new RuntimeException("No job IDs available in the given range");
        }
        return minJobId + userId;
    }
}
