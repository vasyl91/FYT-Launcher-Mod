package com.android.server.backup;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public interface BackupRestoreTask {
    void execute();

    void handleCancel(boolean z);

    void operationComplete(long j);
}
