package com.android.server.am;

import android.app.ActivityManager;
import android.app.ApplicationErrorReport;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.VersionedPackage;
import android.os.Binder;
import android.os.Message;
import android.os.Process;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.UserHandle;
import android.provider.Settings;
import android.util.ArrayMap;
import android.util.ArraySet;
import android.util.EventLog;
import android.util.Slog;
import android.util.SparseArray;
import android.util.TimeUtils;
import android.util.proto.ProtoOutputStream;
import com.android.internal.app.ProcessMap;
import com.android.internal.logging.MetricsLogger;
import com.android.server.PackageWatchdog;
import com.android.server.wm.WindowProcessController;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
class AppErrors {
    private static final String TAG = "ActivityManager";
    private ArraySet<String> mAppsNotReportingCrashes;
    private final Context mContext;
    private final PackageWatchdog mPackageWatchdog;
    private final ActivityManagerService mService;
    private final ProcessMap<Long> mProcessCrashTimes = new ProcessMap<>();
    private final ProcessMap<Long> mProcessCrashTimesPersistent = new ProcessMap<>();
    private final ProcessMap<BadProcessInfo> mBadProcesses = new ProcessMap<>();
    final ArrayMap<String, Long> fytCrash = new ArrayMap<>();

    AppErrors(Context context, ActivityManagerService service, PackageWatchdog watchdog) {
        context.assertRuntimeOverlayThemable();
        this.mService = service;
        this.mContext = context;
        this.mPackageWatchdog = watchdog;
    }

    void writeToProto(ProtoOutputStream proto, long fieldId, String dumpPackage) {
        long token;
        int uidCount;
        String str = dumpPackage;
        if (this.mProcessCrashTimes.getMap().isEmpty() && this.mBadProcesses.getMap().isEmpty()) {
            return;
        }
        long token2 = proto.start(fieldId);
        long now = SystemClock.uptimeMillis();
        proto.write(1112396529665L, now);
        long j = 1138166333441L;
        long j2 = 2246267895810L;
        if (this.mProcessCrashTimes.getMap().isEmpty()) {
            token = token2;
        } else {
            ArrayMap<String, SparseArray<Long>> pmap = this.mProcessCrashTimes.getMap();
            int procCount = pmap.size();
            int ip = 0;
            while (ip < procCount) {
                long ctoken = proto.start(j2);
                String pname = pmap.keyAt(ip);
                SparseArray<Long> uids = pmap.valueAt(ip);
                long now2 = now;
                int uidCount2 = uids.size();
                proto.write(j, pname);
                int i = 0;
                while (i < uidCount2) {
                    int puid = uids.keyAt(i);
                    ProcessRecord r = (ProcessRecord) this.mService.getProcessNames().get(pname, puid);
                    if (str != null) {
                        if (r != null) {
                            uidCount = uidCount2;
                            if (!r.pkgList.containsKey(str)) {
                            }
                        } else {
                            uidCount = uidCount2;
                        }
                        i++;
                        pmap = pmap;
                        uidCount2 = uidCount;
                        procCount = procCount;
                        pname = pname;
                        token2 = token2;
                    } else {
                        uidCount = uidCount2;
                    }
                    long etoken = proto.start(2246267895810L);
                    proto.write(1120986464257L, puid);
                    proto.write(1112396529666L, uids.valueAt(i).longValue());
                    proto.end(etoken);
                    i++;
                    pmap = pmap;
                    uidCount2 = uidCount;
                    procCount = procCount;
                    pname = pname;
                    token2 = token2;
                }
                proto.end(ctoken);
                ip++;
                now = now2;
                j = 1138166333441L;
                j2 = 2246267895810L;
            }
            token = token2;
        }
        if (!this.mBadProcesses.getMap().isEmpty()) {
            ArrayMap<String, SparseArray<BadProcessInfo>> pmap2 = this.mBadProcesses.getMap();
            int processCount = pmap2.size();
            int ip2 = 0;
            while (ip2 < processCount) {
                long btoken = proto.start(2246267895811L);
                String pname2 = pmap2.keyAt(ip2);
                SparseArray<BadProcessInfo> uids2 = pmap2.valueAt(ip2);
                int uidCount3 = uids2.size();
                proto.write(1138166333441L, pname2);
                int i2 = 0;
                while (i2 < uidCount3) {
                    int puid2 = uids2.keyAt(i2);
                    ProcessRecord r2 = (ProcessRecord) this.mService.getProcessNames().get(pname2, puid2);
                    if (str == null || (r2 != null && r2.pkgList.containsKey(str))) {
                        BadProcessInfo info = uids2.valueAt(i2);
                        long etoken2 = proto.start(2246267895810L);
                        proto.write(1120986464257L, puid2);
                        proto.write(1112396529666L, info.time);
                        proto.write(1138166333443L, info.shortMsg);
                        proto.write(1138166333444L, info.longMsg);
                        proto.write(1138166333445L, info.stack);
                        proto.end(etoken2);
                    }
                    i2++;
                    str = dumpPackage;
                    pmap2 = pmap2;
                    pname2 = pname2;
                    uids2 = uids2;
                }
                proto.end(btoken);
                ip2++;
                str = dumpPackage;
            }
        }
        proto.end(token);
    }

    boolean dumpLocked(FileDescriptor fd, PrintWriter pw, boolean needSep, String dumpPackage) {
        boolean needSep2;
        String str;
        ArrayMap<String, SparseArray<BadProcessInfo>> pmap;
        int processCount;
        AppErrors appErrors = this;
        String str2 = dumpPackage;
        String str3 = " uid ";
        if (appErrors.mProcessCrashTimes.getMap().isEmpty()) {
            needSep2 = needSep;
        } else {
            boolean printed = false;
            long now = SystemClock.uptimeMillis();
            ArrayMap<String, SparseArray<Long>> pmap2 = appErrors.mProcessCrashTimes.getMap();
            int processCount2 = pmap2.size();
            needSep2 = needSep;
            for (int ip = 0; ip < processCount2; ip++) {
                String pname = pmap2.keyAt(ip);
                SparseArray<Long> uids = pmap2.valueAt(ip);
                int uidCount = uids.size();
                int i = 0;
                while (i < uidCount) {
                    int puid = uids.keyAt(i);
                    ArrayMap<String, SparseArray<Long>> pmap3 = pmap2;
                    ProcessRecord r = (ProcessRecord) appErrors.mService.getProcessNames().get(pname, puid);
                    if (str2 != null) {
                        if (r == null) {
                            processCount = processCount2;
                        } else {
                            processCount = processCount2;
                            if (!r.pkgList.containsKey(str2)) {
                            }
                        }
                        i++;
                        pmap2 = pmap3;
                        processCount2 = processCount;
                    } else {
                        processCount = processCount2;
                    }
                    if (!printed) {
                        if (needSep2) {
                            pw.println();
                        }
                        needSep2 = true;
                        pw.println("  Time since processes crashed:");
                        printed = true;
                    }
                    pw.print("    Process ");
                    pw.print(pname);
                    pw.print(" uid ");
                    pw.print(puid);
                    pw.print(": last crashed ");
                    TimeUtils.formatDuration(now - uids.valueAt(i).longValue(), pw);
                    pw.println(" ago");
                    i++;
                    pmap2 = pmap3;
                    processCount2 = processCount;
                }
            }
        }
        if (!appErrors.mBadProcesses.getMap().isEmpty()) {
            boolean printed2 = false;
            ArrayMap<String, SparseArray<BadProcessInfo>> pmap4 = appErrors.mBadProcesses.getMap();
            int processCount3 = pmap4.size();
            int ip2 = 0;
            while (ip2 < processCount3) {
                String pname2 = pmap4.keyAt(ip2);
                SparseArray<BadProcessInfo> uids2 = pmap4.valueAt(ip2);
                int uidCount2 = uids2.size();
                int i2 = 0;
                while (i2 < uidCount2) {
                    int puid2 = uids2.keyAt(i2);
                    ProcessRecord r2 = (ProcessRecord) appErrors.mService.getProcessNames().get(pname2, puid2);
                    if (str2 != null && (r2 == null || !r2.pkgList.containsKey(str2))) {
                        str = str3;
                        pmap = pmap4;
                    } else {
                        if (!printed2) {
                            if (needSep2) {
                                pw.println();
                            }
                            needSep2 = true;
                            pw.println("  Bad processes:");
                            printed2 = true;
                        }
                        BadProcessInfo info = uids2.valueAt(i2);
                        pw.print("    Bad process ");
                        pw.print(pname2);
                        pw.print(str3);
                        pw.print(puid2);
                        pw.print(": crashed at time ");
                        boolean printed3 = printed2;
                        pw.println(info.time);
                        if (info.shortMsg != null) {
                            pw.print("      Short msg: ");
                            pw.println(info.shortMsg);
                        }
                        if (info.longMsg != null) {
                            pw.print("      Long msg: ");
                            pw.println(info.longMsg);
                        }
                        if (info.stack == null) {
                            str = str3;
                            pmap = pmap4;
                        } else {
                            pw.println("      Stack:");
                            int lastPos = 0;
                            int pos = 0;
                            while (true) {
                                str = str3;
                                if (pos >= info.stack.length()) {
                                    break;
                                }
                                ArrayMap<String, SparseArray<BadProcessInfo>> pmap5 = pmap4;
                                if (info.stack.charAt(pos) == '\n') {
                                    pw.print("        ");
                                    pw.write(info.stack, lastPos, pos - lastPos);
                                    pw.println();
                                    lastPos = pos + 1;
                                }
                                pos++;
                                str3 = str;
                                pmap4 = pmap5;
                            }
                            pmap = pmap4;
                            if (lastPos < info.stack.length()) {
                                pw.print("        ");
                                pw.write(info.stack, lastPos, info.stack.length() - lastPos);
                                pw.println();
                            }
                        }
                        printed2 = printed3;
                    }
                    i2++;
                    appErrors = this;
                    str2 = dumpPackage;
                    str3 = str;
                    pmap4 = pmap;
                }
                ip2++;
                appErrors = this;
                str2 = dumpPackage;
            }
        }
        return needSep2;
    }

    boolean isBadProcessLocked(ApplicationInfo info) {
        return this.mBadProcesses.get(info.processName, info.uid) != null;
    }

    void clearBadProcessLocked(ApplicationInfo info) {
        this.mBadProcesses.remove(info.processName, info.uid);
    }

    void resetProcessCrashTimeLocked(ApplicationInfo info) {
        this.mProcessCrashTimes.remove(info.processName, info.uid);
    }

    void resetProcessCrashTimeLocked(boolean resetEntireUser, int appId, int userId) {
        ArrayMap<String, SparseArray<Long>> pmap = this.mProcessCrashTimes.getMap();
        for (int ip = pmap.size() - 1; ip >= 0; ip--) {
            SparseArray<Long> ba = pmap.valueAt(ip);
            for (int i = ba.size() - 1; i >= 0; i--) {
                boolean remove = false;
                int entUid = ba.keyAt(i);
                if (!resetEntireUser) {
                    if (userId == -1) {
                        if (UserHandle.getAppId(entUid) == appId) {
                            remove = true;
                        }
                    } else if (entUid == UserHandle.getUid(userId, appId)) {
                        remove = true;
                    }
                } else if (UserHandle.getUserId(entUid) == userId) {
                    remove = true;
                }
                if (remove) {
                    ba.removeAt(i);
                }
            }
            int i2 = ba.size();
            if (i2 == 0) {
                pmap.removeAt(ip);
            }
        }
    }

    void loadAppsNotReportingCrashesFromConfigLocked(String appsNotReportingCrashesConfig) {
        if (appsNotReportingCrashesConfig != null) {
            String[] split = appsNotReportingCrashesConfig.split(",");
            if (split.length > 0) {
                this.mAppsNotReportingCrashes = new ArraySet<>();
                Collections.addAll(this.mAppsNotReportingCrashes, split);
            }
        }
    }

    void killAppAtUserRequestLocked(ProcessRecord app, Dialog fromDialog) {
        app.setCrashing(false);
        app.crashingReport = null;
        app.setNotResponding(false);
        app.notRespondingReport = null;
        if (app.anrDialog == fromDialog) {
            app.anrDialog = null;
        }
        if (app.waitDialog == fromDialog) {
            app.waitDialog = null;
        }
        if (app.pid > 0 && app.pid != ActivityManagerService.MY_PID) {
            handleAppCrashLocked(app, "user-terminated", null, null, null, null);
            app.kill("user request after error", true);
        }
    }

    void scheduleAppCrashLocked(int uid, int initialPid, String packageName, int userId, String message) {
        ProcessRecord proc = null;
        synchronized (this.mService.mPidsSelfLocked) {
            for (int i = 0; i < this.mService.mPidsSelfLocked.size(); i++) {
                ProcessRecord p = this.mService.mPidsSelfLocked.valueAt(i);
                if (uid < 0 || p.uid == uid) {
                    if (p.pid == initialPid) {
                        proc = p;
                        break;
                    } else if (p.pkgList.containsKey(packageName) && (userId < 0 || p.userId == userId)) {
                        proc = p;
                    }
                }
            }
        }
        if (proc == null) {
            Slog.w(TAG, "crashApplication: nothing for uid=" + uid + " initialPid=" + initialPid + " packageName=" + packageName + " userId=" + userId);
            return;
        }
        proc.scheduleCrash(message);
    }

    void crashApplication(ProcessRecord r, ApplicationErrorReport.CrashInfo crashInfo) {
        int callingPid = Binder.getCallingPid();
        int callingUid = Binder.getCallingUid();
        long origId = Binder.clearCallingIdentity();
        try {
            crashApplicationInner(r, crashInfo, callingPid, callingUid);
        } finally {
            Binder.restoreCallingIdentity(origId);
        }
    }

    public boolean saveCrashInfo(ProcessRecord app, String stackTrace) {
        if (app == null || !app.info.isSystemApp()) {
            return false;
        }
        long now = System.currentTimeMillis();
        Long lastTime = this.fytCrash.get(app.info.processName);
        long fytcrashtime = lastTime != null ? lastTime.longValue() : 0L;
        this.fytCrash.put(app.info.processName, Long.valueOf(now));
        if (fytcrashtime != 0) {
            return true;
        }
        Slog.i(TAG, "crashing............." + app.info.processName);
        return true;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't find top splitter block for handler:B:145:0x025e
        	at jadx.core.utils.BlockUtils.getTopSplitterForHandler(BlockUtils.java:1478)
        	at jadx.core.dex.visitors.regions.maker.ExcHandlersRegionMaker.collectHandlerRegions(ExcHandlersRegionMaker.java:53)
        	at jadx.core.dex.visitors.regions.maker.ExcHandlersRegionMaker.process(ExcHandlersRegionMaker.java:38)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:27)
        */
    void crashApplicationInner(com.android.server.am.ProcessRecord r22, android.app.ApplicationErrorReport.CrashInfo r23, int r24, int r25) {
        /*
            Method dump skipped, instruction units count: 608
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.server.am.AppErrors.crashApplicationInner(com.android.server.am.ProcessRecord, android.app.ApplicationErrorReport$CrashInfo, int, int):void");
    }

    private boolean handleAppCrashInActivityController(final ProcessRecord r, final ApplicationErrorReport.CrashInfo crashInfo, final String shortMsg, final String longMsg, final String stackTrace, long timeMillis, int callingPid, int callingUid) {
        final String name = r != null ? r.processName : null;
        final int pid = r != null ? r.pid : callingPid;
        final int uid = r != null ? r.info.uid : callingUid;
        return this.mService.mAtmInternal.handleAppCrashInActivityController(name, pid, shortMsg, longMsg, timeMillis, crashInfo.stackTrace, new Runnable() { // from class: com.android.server.am.-$$Lambda$AppErrors$s1CeKlTYP9O4xRqISFOqsuWxcno
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$handleAppCrashInActivityController$0$AppErrors(crashInfo, name, pid, r, shortMsg, longMsg, stackTrace, uid);
            }
        });
    }

    public /* synthetic */ void lambda$handleAppCrashInActivityController$0$AppErrors(ApplicationErrorReport.CrashInfo crashInfo, String name, int pid, ProcessRecord r, String shortMsg, String longMsg, String stackTrace, int uid) {
        if ("1".equals(SystemProperties.get("ro.debuggable", "0")) && "Native crash".equals(crashInfo.exceptionClassName)) {
            Slog.w(TAG, "Skip killing native crashed app " + name + "(" + pid + ") during testing");
            return;
        }
        Slog.w(TAG, "Force-killing crashed app " + name + " at watcher's request");
        if (r != null) {
            if (!makeAppCrashingLocked(r, shortMsg, longMsg, stackTrace, null)) {
                r.kill("crash", true);
            }
        } else {
            Process.killProcess(pid);
            ProcessList.killProcessGroup(uid, pid);
        }
    }

    private boolean makeAppCrashingLocked(ProcessRecord app, String shortMsg, String longMsg, String stackTrace, AppErrorDialog.Data data) {
        app.setCrashing(true);
        app.crashingReport = generateProcessError(app, 1, null, shortMsg, longMsg, stackTrace);
        app.startAppProblemLocked();
        app.getWindowProcessController().stopFreezingActivities();
        return handleAppCrashLocked(app, "force-crash", shortMsg, longMsg, stackTrace, data);
    }

    ActivityManager.ProcessErrorStateInfo generateProcessError(ProcessRecord app, int condition, String activity, String shortMsg, String longMsg, String stackTrace) {
        ActivityManager.ProcessErrorStateInfo report = new ActivityManager.ProcessErrorStateInfo();
        report.condition = condition;
        report.processName = app.processName;
        report.pid = app.pid;
        report.uid = app.info.uid;
        report.tag = activity;
        report.shortMsg = shortMsg;
        report.longMsg = longMsg;
        report.stackTrace = stackTrace;
        return report;
    }

    Intent createAppErrorIntentLocked(ProcessRecord r, long timeMillis, ApplicationErrorReport.CrashInfo crashInfo) {
        ApplicationErrorReport report = createAppErrorReportLocked(r, timeMillis, crashInfo);
        if (report == null) {
            return null;
        }
        Intent result = new Intent("android.intent.action.APP_ERROR");
        result.setComponent(r.errorReportReceiver);
        result.putExtra("android.intent.extra.BUG_REPORT", report);
        result.addFlags(268435456);
        return result;
    }

    private ApplicationErrorReport createAppErrorReportLocked(ProcessRecord r, long timeMillis, ApplicationErrorReport.CrashInfo crashInfo) {
        if (r.errorReportReceiver == null) {
            return null;
        }
        if (!r.isCrashing() && !r.isNotResponding() && !r.forceCrashReport) {
            return null;
        }
        ApplicationErrorReport report = new ApplicationErrorReport();
        report.packageName = r.info.packageName;
        report.installerPackageName = r.errorReportReceiver.getPackageName();
        report.processName = r.processName;
        report.time = timeMillis;
        report.systemApp = (r.info.flags & 1) != 0;
        if (r.isCrashing() || r.forceCrashReport) {
            report.type = 1;
            report.crashInfo = crashInfo;
        } else if (r.isNotResponding()) {
            report.type = 2;
            report.anrInfo = new ApplicationErrorReport.AnrInfo();
            report.anrInfo.activity = r.notRespondingReport.tag;
            report.anrInfo.cause = r.notRespondingReport.shortMsg;
            report.anrInfo.info = r.notRespondingReport.longMsg;
        }
        return report;
    }

    boolean handleAppCrashLocked(ProcessRecord app, String reason, String shortMsg, String longMsg, String stackTrace, AppErrorDialog.Data data) {
        Long crashTime;
        Long crashTimePersistent;
        boolean z;
        long now = SystemClock.uptimeMillis();
        boolean showBackground = Settings.Secure.getInt(this.mContext.getContentResolver(), "anr_show_background", 0) != 0;
        boolean procIsBoundForeground = app.getCurProcState() == 6;
        if (!app.isolated) {
            Long crashTime2 = (Long) this.mProcessCrashTimes.get(app.info.processName, app.uid);
            crashTime = crashTime2;
            crashTimePersistent = (Long) this.mProcessCrashTimesPersistent.get(app.info.processName, app.uid);
        } else {
            crashTime = null;
            crashTimePersistent = null;
        }
        boolean tryAgain = false;
        for (int i = app.services.size() - 1; i >= 0; i--) {
            ServiceRecord sr = app.services.valueAt(i);
            if (now > sr.restartTime + 60000) {
                sr.crashCount = 1;
            } else {
                sr.crashCount++;
            }
            if (sr.crashCount < this.mService.mConstants.BOUND_SERVICE_MAX_CRASH_RETRY && (sr.isForeground || procIsBoundForeground)) {
                tryAgain = true;
            }
        }
        if (crashTime == null || now >= crashTime.longValue() + 60000) {
            now = now;
            tryAgain = tryAgain;
            int affectedTaskId = this.mService.mAtmInternal.finishTopCrashedActivities(app.getWindowProcessController(), reason);
            if (data != null) {
                data.taskId = affectedTaskId;
            }
            if (data != null && crashTimePersistent != null && now < crashTimePersistent.longValue() + 60000) {
                data.repeating = true;
            }
        } else {
            Slog.w(TAG, "Process " + app.info.processName + " has crashed too many times: killing!");
            EventLog.writeEvent(EventLogTags.AM_PROCESS_CRASHED_TOO_MUCH, Integer.valueOf(app.userId), app.info.processName, Integer.valueOf(app.uid));
            this.mService.mAtmInternal.onHandleAppCrash(app.getWindowProcessController());
            if (app.isPersistent()) {
                now = now;
                z = false;
                tryAgain = tryAgain;
            } else {
                EventLog.writeEvent(EventLogTags.AM_PROC_BAD, Integer.valueOf(app.userId), Integer.valueOf(app.uid), app.info.processName);
                if (!app.isolated) {
                    this.mBadProcesses.put(app.info.processName, app.uid, new BadProcessInfo(now, shortMsg, longMsg, stackTrace));
                    this.mProcessCrashTimes.remove(app.info.processName, app.uid);
                }
                app.bad = true;
                app.removed = true;
                z = false;
                this.mService.mProcessList.removeProcessLocked(app, false, tryAgain, "crash");
                this.mService.mAtmInternal.resumeTopActivities(false);
                if (!showBackground) {
                    return false;
                }
            }
            this.mService.mAtmInternal.resumeTopActivities(z);
        }
        if (data != null && tryAgain) {
            data.isRestartableForService = true;
        }
        WindowProcessController proc = app.getWindowProcessController();
        WindowProcessController homeProc = this.mService.mAtmInternal.getHomeProcess();
        if (proc == homeProc && proc.hasActivities() && (((ProcessRecord) homeProc.mOwner).info.flags & 1) == 0) {
            proc.clearPackagePreferredForHomeActivities();
        }
        if (!app.isolated) {
            this.mProcessCrashTimes.put(app.info.processName, app.uid, Long.valueOf(now));
            this.mProcessCrashTimesPersistent.put(app.info.processName, app.uid, Long.valueOf(now));
        }
        if (app.crashHandler != null) {
            this.mService.mHandler.post(app.crashHandler);
            return true;
        }
        return true;
    }

    void handleShowAppErrorUi(Message msg) {
        AppErrorDialog.Data data = (AppErrorDialog.Data) msg.obj;
        boolean showBackground = Settings.Secure.getInt(this.mContext.getContentResolver(), "anr_show_background", 0) != 0;
        AppErrorDialog dialogToShow = null;
        synchronized (this.mService) {
            try {
                ActivityManagerService.boostPriorityForLockedSection();
                ProcessRecord proc = data.proc;
                AppErrorResult res = data.result;
                if (proc == null) {
                    Slog.e(TAG, "handleShowAppErrorUi: proc is null");
                    ActivityManagerService.resetPriorityAfterLockedSection();
                    return;
                }
                String packageName = proc.info.packageName;
                int userId = proc.userId;
                if (proc.crashDialog != null) {
                    Slog.e(TAG, "App already has crash dialog: " + proc);
                    if (res != null) {
                        res.set(AppErrorDialog.ALREADY_SHOWING);
                    }
                    ActivityManagerService.resetPriorityAfterLockedSection();
                    return;
                }
                boolean isBackground = UserHandle.getAppId(proc.uid) >= 10000 && proc.pid != ActivityManagerService.MY_PID;
                int[] currentProfileIds = this.mService.mUserController.getCurrentProfileIds();
                int length = currentProfileIds.length;
                boolean isBackground2 = isBackground;
                for (int i = 0; i < length; i++) {
                    int profileId = currentProfileIds[i];
                    isBackground2 &= userId != profileId;
                }
                if (isBackground2 && !showBackground) {
                    Slog.w(TAG, "Skipping crash dialog of " + proc + ": background");
                    if (res != null) {
                        res.set(AppErrorDialog.BACKGROUND_USER);
                    }
                    ActivityManagerService.resetPriorityAfterLockedSection();
                    return;
                }
                boolean showFirstCrash = Settings.Global.getInt(this.mContext.getContentResolver(), "show_first_crash_dialog", 0) != 0;
                boolean showFirstCrashDevOption = Settings.Secure.getIntForUser(this.mContext.getContentResolver(), "show_first_crash_dialog_dev_option", 0, this.mService.mUserController.getCurrentUserId()) != 0;
                boolean crashSilenced = this.mAppsNotReportingCrashes != null && this.mAppsNotReportingCrashes.contains(proc.info.packageName);
                if ((this.mService.mAtmInternal.canShowErrorDialogs() || showBackground) && !crashSilenced && (showFirstCrash || showFirstCrashDevOption || data.repeating)) {
                    AppErrorDialog appErrorDialog = new AppErrorDialog(this.mContext, this.mService, data);
                    dialogToShow = appErrorDialog;
                    proc.crashDialog = appErrorDialog;
                } else if (res != null) {
                    res.set(AppErrorDialog.CANT_SHOW);
                }
                ActivityManagerService.resetPriorityAfterLockedSection();
                if (dialogToShow != null) {
                    Slog.i(TAG, "Showing crash dialog for package " + packageName + " u" + userId);
                    dialogToShow.show();
                }
            } catch (Throwable th) {
                ActivityManagerService.resetPriorityAfterLockedSection();
                throw th;
            }
        }
    }

    private void stopReportingCrashesLocked(ProcessRecord proc) {
        if (this.mAppsNotReportingCrashes == null) {
            this.mAppsNotReportingCrashes = new ArraySet<>();
        }
        this.mAppsNotReportingCrashes.add(proc.info.packageName);
    }

    void handleShowAnrUi(Message msg) {
        Dialog dialogToShow = null;
        List<VersionedPackage> packageList = null;
        synchronized (this.mService) {
            try {
                ActivityManagerService.boostPriorityForLockedSection();
                AppNotRespondingDialog.Data data = (AppNotRespondingDialog.Data) msg.obj;
                ProcessRecord proc = data.proc;
                if (proc == null) {
                    Slog.e(TAG, "handleShowAnrUi: proc is null");
                    ActivityManagerService.resetPriorityAfterLockedSection();
                    return;
                }
                if (!proc.isPersistent()) {
                    packageList = proc.getPackageListWithVersionCode();
                }
                if (proc.anrDialog != null) {
                    Slog.e(TAG, "App already has anr dialog: " + proc);
                    MetricsLogger.action(this.mContext, 317, -2);
                    ActivityManagerService.resetPriorityAfterLockedSection();
                    return;
                }
                boolean showBackground = Settings.Secure.getInt(this.mContext.getContentResolver(), "anr_show_background", 0) != 0;
                if (this.mService.mAtmInternal.canShowErrorDialogs() || showBackground) {
                    dialogToShow = new AppNotRespondingDialog(this.mService, this.mContext, data);
                    proc.anrDialog = dialogToShow;
                } else {
                    MetricsLogger.action(this.mContext, 317, -1);
                    this.mService.killAppAtUsersRequest(proc, null);
                }
                ActivityManagerService.resetPriorityAfterLockedSection();
                if (dialogToShow != null) {
                    dialogToShow.show();
                }
                if (packageList != null) {
                    this.mPackageWatchdog.onPackageFailure(packageList);
                }
            } catch (Throwable th) {
                ActivityManagerService.resetPriorityAfterLockedSection();
                throw th;
            }
        }
    }

    static final class BadProcessInfo {
        final String longMsg;
        final String shortMsg;
        final String stack;
        final long time;

        BadProcessInfo(long time, String shortMsg, String longMsg, String stack) {
            this.time = time;
            this.shortMsg = shortMsg;
            this.longMsg = longMsg;
            this.stack = stack;
        }
    }
}
