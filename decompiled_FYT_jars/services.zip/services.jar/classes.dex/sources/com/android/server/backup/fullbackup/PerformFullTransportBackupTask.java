package com.android.server.backup.fullbackup;

import android.app.IBackupAgent;
import android.app.backup.BackupProgress;
import android.app.backup.IBackupCallback;
import android.app.backup.IBackupManagerMonitor;
import android.app.backup.IBackupObserver;
import android.app.backup.IFullBackupRestoreObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import android.util.EventLog;
import android.util.Log;
import android.util.Slog;
import com.android.internal.backup.IBackupTransport;
import com.android.internal.util.Preconditions;
import com.android.server.EventLogTags;
import com.android.server.backup.BackupAgentTimeoutParameters;
import com.android.server.backup.BackupRestoreTask;
import com.android.server.backup.FullBackupJob;
import com.android.server.backup.TransportManager;
import com.android.server.backup.UserBackupManagerService;
import com.android.server.backup.internal.OnTaskFinishedListener;
import com.android.server.backup.internal.Operation;
import com.android.server.backup.remote.RemoteCall;
import com.android.server.backup.remote.RemoteCallable;
import com.android.server.backup.transport.TransportClient;
import com.android.server.backup.transport.TransportNotAvailableException;
import com.android.server.backup.utils.AppBackupUtils;
import com.android.server.backup.utils.BackupManagerMonitorUtils;
import com.android.server.backup.utils.BackupObserverUtils;
import com.android.server.job.JobSchedulerShellCommand;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class PerformFullTransportBackupTask extends FullBackupTask implements BackupRestoreTask {
    private static final String TAG = "PFTBT";
    private UserBackupManagerService backupManagerService;
    private final BackupAgentTimeoutParameters mAgentTimeoutParameters;
    IBackupObserver mBackupObserver;
    SinglePackageBackupRunner mBackupRunner;
    private final int mBackupRunnerOpToken;
    private volatile boolean mCancelAll;
    private final Object mCancelLock;
    private final int mCurrentOpToken;
    PackageInfo mCurrentPackage;
    private volatile boolean mIsDoingBackup;
    FullBackupJob mJob;
    CountDownLatch mLatch;
    private final OnTaskFinishedListener mListener;
    private IBackupManagerMonitor mMonitor;
    ArrayList<PackageInfo> mPackages;
    private final TransportClient mTransportClient;
    boolean mUpdateSchedule;
    private final int mUserId;
    boolean mUserInitiated;

    public static PerformFullTransportBackupTask newWithCurrentTransport(UserBackupManagerService backupManagerService, IFullBackupRestoreObserver observer, String[] whichPackages, boolean updateSchedule, FullBackupJob runningJob, CountDownLatch latch, IBackupObserver backupObserver, IBackupManagerMonitor monitor, boolean userInitiated, String caller) {
        final TransportManager transportManager = backupManagerService.getTransportManager();
        final TransportClient transportClient = transportManager.getCurrentTransportClient(caller);
        OnTaskFinishedListener listener = new OnTaskFinishedListener() { // from class: com.android.server.backup.fullbackup.-$$Lambda$PerformFullTransportBackupTask$ymLoQLrsEpmGaMrcudrdAgsU1Zk
            @Override // com.android.server.backup.internal.OnTaskFinishedListener
            public final void onFinished(String str) {
                transportManager.disposeOfTransportClient(transportClient, str);
            }
        };
        return new PerformFullTransportBackupTask(backupManagerService, transportClient, observer, whichPackages, updateSchedule, runningJob, latch, backupObserver, monitor, listener, userInitiated);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public PerformFullTransportBackupTask(UserBackupManagerService backupManagerService, TransportClient transportClient, IFullBackupRestoreObserver observer, String[] whichPackages, boolean updateSchedule, FullBackupJob runningJob, CountDownLatch latch, IBackupObserver backupObserver, IBackupManagerMonitor monitor, OnTaskFinishedListener listener, boolean userInitiated) {
        super(observer);
        String[] strArr = whichPackages;
        this.mCancelLock = new Object();
        this.backupManagerService = backupManagerService;
        this.mTransportClient = transportClient;
        this.mUpdateSchedule = updateSchedule;
        this.mLatch = latch;
        this.mJob = runningJob;
        this.mPackages = new ArrayList<>(strArr.length);
        this.mBackupObserver = backupObserver;
        this.mMonitor = monitor;
        this.mListener = listener != null ? listener : OnTaskFinishedListener.NOP;
        this.mUserInitiated = userInitiated;
        this.mCurrentOpToken = backupManagerService.generateRandomIntegerToken();
        this.mBackupRunnerOpToken = backupManagerService.generateRandomIntegerToken();
        this.mAgentTimeoutParameters = (BackupAgentTimeoutParameters) Preconditions.checkNotNull(backupManagerService.getAgentTimeoutParameters(), "Timeout parameters cannot be null");
        this.mUserId = backupManagerService.getUserId();
        if (backupManagerService.isBackupOperationInProgress()) {
            Slog.d(TAG, "Skipping full backup. A backup is already in progress.");
            this.mCancelAll = true;
            return;
        }
        registerTask();
        int length = strArr.length;
        int i = 0;
        while (i < length) {
            String pkg = strArr[i];
            try {
                PackageManager pm = backupManagerService.getPackageManager();
                PackageInfo info = pm.getPackageInfoAsUser(pkg, 134217728, this.mUserId);
                this.mCurrentPackage = info;
                if (!AppBackupUtils.appIsEligibleForBackup(info.applicationInfo, this.mUserId)) {
                    this.mMonitor = BackupManagerMonitorUtils.monitorEvent(this.mMonitor, 9, this.mCurrentPackage, 3, null);
                    BackupObserverUtils.sendBackupOnPackageResult(this.mBackupObserver, pkg, -2001);
                } else if (!AppBackupUtils.appGetsFullBackup(info)) {
                    this.mMonitor = BackupManagerMonitorUtils.monitorEvent(this.mMonitor, 10, this.mCurrentPackage, 3, null);
                    BackupObserverUtils.sendBackupOnPackageResult(this.mBackupObserver, pkg, -2001);
                } else if (AppBackupUtils.appIsStopped(info.applicationInfo)) {
                    this.mMonitor = BackupManagerMonitorUtils.monitorEvent(this.mMonitor, 11, this.mCurrentPackage, 3, null);
                    BackupObserverUtils.sendBackupOnPackageResult(this.mBackupObserver, pkg, -2001);
                } else {
                    this.mPackages.add(info);
                }
            } catch (PackageManager.NameNotFoundException e) {
                Slog.i(TAG, "Requested package " + pkg + " not found; ignoring");
                this.mMonitor = BackupManagerMonitorUtils.monitorEvent(this.mMonitor, 12, this.mCurrentPackage, 3, null);
            }
            i++;
            strArr = whichPackages;
        }
    }

    private void registerTask() {
        synchronized (this.backupManagerService.getCurrentOpLock()) {
            Slog.d(TAG, "backupmanager pftbt token=" + Integer.toHexString(this.mCurrentOpToken));
            this.backupManagerService.getCurrentOperations().put(this.mCurrentOpToken, new Operation(0, this, 2));
        }
    }

    public void unregisterTask() {
        this.backupManagerService.removeOperation(this.mCurrentOpToken);
    }

    @Override // com.android.server.backup.BackupRestoreTask
    public void execute() {
    }

    /* JADX WARN: Code duplicated, block: B:11:0x0019 A[Catch: all -> 0x004c, TryCatch #1 {, blocks: (B:5:0x0005, B:6:0x000c, B:8:0x0010, B:9:0x0017, B:11:0x0019, B:13:0x0020, B:14:0x0027, B:17:0x0034, B:18:0x004a), top: B:25:0x0005, inners: #0 }] */
    /* JADX WARN: Code duplicated, block: B:13:0x0020 A[Catch: all -> 0x004c, TRY_LEAVE, TryCatch #1 {, blocks: (B:5:0x0005, B:6:0x000c, B:8:0x0010, B:9:0x0017, B:11:0x0019, B:13:0x0020, B:14:0x0027, B:17:0x0034, B:18:0x004a), top: B:25:0x0005, inners: #0 }] */
    /* JADX WARN: Code duplicated, block: B:8:0x0010 A[Catch: all -> 0x004c, TryCatch #1 {, blocks: (B:5:0x0005, B:6:0x000c, B:8:0x0010, B:9:0x0017, B:11:0x0019, B:13:0x0020, B:14:0x0027, B:17:0x0034, B:18:0x004a), top: B:25:0x0005, inners: #0 }] */
    @Override // com.android.server.backup.BackupRestoreTask
    public void handleCancel(boolean cancelAll) {
        synchronized (this.mCancelLock) {
            if (!cancelAll) {
                Slog.wtf(TAG, "Expected cancelAll to be true.");
                if (this.mCancelAll) {
                    Slog.d(TAG, "Ignoring duplicate cancel call.");
                    return;
                }
                this.mCancelAll = true;
                if (this.mIsDoingBackup) {
                    this.backupManagerService.handleCancel(this.mBackupRunnerOpToken, cancelAll);
                    try {
                        IBackupTransport transport = this.mTransportClient.getConnectedTransport("PFTBT.handleCancel()");
                        transport.cancelFullBackup();
                    } catch (RemoteException | TransportNotAvailableException e) {
                        Slog.w(TAG, "Error calling cancelFullBackup() on transport: " + e);
                    }
                }
                return;
            }
            if (this.mCancelAll) {
                Slog.d(TAG, "Ignoring duplicate cancel call.");
                return;
            }
            this.mCancelAll = true;
            if (this.mIsDoingBackup) {
                this.backupManagerService.handleCancel(this.mBackupRunnerOpToken, cancelAll);
                IBackupTransport transport2 = this.mTransportClient.getConnectedTransport("PFTBT.handleCancel()");
                transport2.cancelFullBackup();
            }
            return;
            throw th;
        }
    }

    @Override // com.android.server.backup.BackupRestoreTask
    public void operationComplete(long result) {
    }

    @Override // java.lang.Runnable
    public void run() throws Throwable {
        ParcelFileDescriptor[] enginePipes;
        ParcelFileDescriptor[] transportPipes;
        long backoff;
        Throwable th;
        Exception e;
        long backoff2;
        long backoff3;
        Object obj;
        Throwable th2;
        long backoff4;
        PackageInfo currentPackage;
        String packageName;
        char c;
        String packageName2;
        int backupPackageStatus;
        PackageInfo currentPackage2;
        Throwable th3;
        int backupPackageStatus2;
        int backupPackageStatus3;
        long totalRead;
        Throwable th4;
        ParcelFileDescriptor[] enginePipes2 = null;
        ParcelFileDescriptor[] transportPipes2 = null;
        long backoff5 = 0;
        int backupRunStatus = 0;
        SinglePackageBackupRunner singlePackageBackupRunner = null;
        try {
            if (this.backupManagerService.isEnabled() && this.backupManagerService.isSetupComplete()) {
                IBackupTransport transport = this.mTransportClient.connect("PFTBT.run()");
                if (transport != null) {
                    int N = this.mPackages.size();
                    byte[] buffer = new byte[8192];
                    int i = 0;
                    long backoff6 = 0;
                    while (true) {
                        if (i >= N) {
                            transportPipes = transportPipes2;
                            break;
                        }
                        try {
                            this.mBackupRunner = singlePackageBackupRunner;
                            PackageInfo currentPackage3 = this.mPackages.get(i);
                            String packageName3 = currentPackage3.packageName;
                            Slog.i(TAG, "Initiating full-data transport backup of " + packageName3 + " token: " + this.mCurrentOpToken);
                            EventLog.writeEvent(EventLogTags.FULL_BACKUP_PACKAGE, packageName3);
                            transportPipes = ParcelFileDescriptor.createPipe();
                            try {
                                int flags = this.mUserInitiated ? 1 : 0;
                                Object obj2 = this.mCancelLock;
                                synchronized (obj2) {
                                    try {
                                        if (this.mCancelAll) {
                                            try {
                                            } catch (Throwable th5) {
                                                backoff3 = backoff6;
                                                obj = obj2;
                                                backupRunStatus = backupRunStatus;
                                                enginePipes = enginePipes2;
                                                th2 = th5;
                                            }
                                        } else {
                                            int i2 = i;
                                            try {
                                                int backupPackageStatus4 = transport.performFullBackup(currentPackage3, transportPipes[0], flags);
                                                if (backupPackageStatus4 == 0) {
                                                    try {
                                                        backoff3 = backoff6;
                                                        backoff4 = transport.getBackupQuota(currentPackage3.packageName, true);
                                                        try {
                                                            ParcelFileDescriptor[] enginePipes3 = ParcelFileDescriptor.createPipe();
                                                            try {
                                                                currentPackage = currentPackage3;
                                                                backupRunStatus = backupRunStatus;
                                                                packageName = packageName3;
                                                                c = 1;
                                                                obj = obj2;
                                                                try {
                                                                    this.mBackupRunner = new SinglePackageBackupRunner(enginePipes3[1], currentPackage, this.mTransportClient, backoff4, this.mBackupRunnerOpToken, transport.getTransportFlags());
                                                                    enginePipes3[1].close();
                                                                    enginePipes3[1] = null;
                                                                    this.mIsDoingBackup = true;
                                                                    enginePipes2 = enginePipes3;
                                                                } catch (Throwable th6) {
                                                                    th2 = th6;
                                                                    enginePipes = enginePipes3;
                                                                }
                                                            } catch (Throwable th7) {
                                                                obj = obj2;
                                                                backupRunStatus = backupRunStatus;
                                                                th2 = th7;
                                                                enginePipes = enginePipes3;
                                                            }
                                                        } catch (Throwable th8) {
                                                            obj = obj2;
                                                            backupRunStatus = backupRunStatus;
                                                            enginePipes = enginePipes2;
                                                            th2 = th8;
                                                        }
                                                    } catch (Throwable th9) {
                                                        backoff3 = backoff6;
                                                        obj = obj2;
                                                        backupRunStatus = backupRunStatus;
                                                        enginePipes = enginePipes2;
                                                        th2 = th9;
                                                    }
                                                } else {
                                                    currentPackage = currentPackage3;
                                                    backoff3 = backoff6;
                                                    obj = obj2;
                                                    backupRunStatus = backupRunStatus;
                                                    packageName = packageName3;
                                                    c = 1;
                                                    backoff4 = Long.MAX_VALUE;
                                                }
                                                try {
                                                    if (backupPackageStatus4 == 0) {
                                                        try {
                                                            transportPipes[0].close();
                                                            transportPipes[0] = null;
                                                            new Thread(this.mBackupRunner, "package-backup-bridge").start();
                                                            FileInputStream in = new FileInputStream(enginePipes2[0].getFileDescriptor());
                                                            FileOutputStream out = new FileOutputStream(transportPipes[c].getFileDescriptor());
                                                            long preflightResult = this.mBackupRunner.getPreflightResultBlocking();
                                                            transportPipes = transportPipes;
                                                            if (preflightResult < 0) {
                                                                try {
                                                                    enginePipes = enginePipes2;
                                                                    try {
                                                                        this.mMonitor = BackupManagerMonitorUtils.monitorEvent(this.mMonitor, 16, this.mCurrentPackage, 3, BackupManagerMonitorUtils.putMonitoringExtra((Bundle) null, "android.app.backup.extra.LOG_PREFLIGHT_ERROR", preflightResult));
                                                                        backupPackageStatus2 = (int) preflightResult;
                                                                        packageName2 = packageName;
                                                                    } catch (Exception e2) {
                                                                        e = e2;
                                                                        transportPipes2 = transportPipes;
                                                                        backoff5 = backoff3;
                                                                        enginePipes = enginePipes;
                                                                    } catch (Throwable th10) {
                                                                        th = th10;
                                                                        backoff = backoff3;
                                                                        enginePipes = enginePipes;
                                                                    }
                                                                } catch (Exception e3) {
                                                                    ParcelFileDescriptor[] parcelFileDescriptorArr = enginePipes2;
                                                                    e = e3;
                                                                    transportPipes2 = transportPipes;
                                                                    backoff5 = backoff3;
                                                                    enginePipes = parcelFileDescriptorArr;
                                                                } catch (Throwable th11) {
                                                                    ParcelFileDescriptor[] parcelFileDescriptorArr2 = enginePipes2;
                                                                    th = th11;
                                                                    backoff = backoff3;
                                                                    enginePipes = parcelFileDescriptorArr2;
                                                                }
                                                            } else {
                                                                enginePipes = enginePipes2;
                                                                long totalRead2 = 0;
                                                                int backupPackageStatus5 = 0;
                                                                while (true) {
                                                                    int nRead = in.read(buffer);
                                                                    if (nRead > 0) {
                                                                        out.write(buffer, backupPackageStatus5, nRead);
                                                                        synchronized (this.mCancelLock) {
                                                                            try {
                                                                                if (!this.mCancelAll) {
                                                                                    try {
                                                                                        backupPackageStatus4 = transport.sendBackupData(nRead);
                                                                                    } catch (Throwable th12) {
                                                                                        th4 = th12;
                                                                                        while (true) {
                                                                                            try {
                                                                                                throw th4;
                                                                                            } catch (Throwable th13) {
                                                                                                th4 = th13;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                                totalRead = totalRead2 + ((long) nRead);
                                                                                if (this.mBackupObserver == null || preflightResult <= 0) {
                                                                                    packageName2 = packageName;
                                                                                } else {
                                                                                    packageName2 = packageName;
                                                                                    BackupObserverUtils.sendBackupOnUpdate(this.mBackupObserver, packageName2, new BackupProgress(preflightResult, totalRead));
                                                                                }
                                                                                backupPackageStatus3 = backupPackageStatus4;
                                                                            } catch (Throwable th14) {
                                                                                th4 = th14;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        in = in;
                                                                        packageName2 = packageName;
                                                                        backupPackageStatus3 = backupPackageStatus4;
                                                                        totalRead = totalRead2;
                                                                    }
                                                                    if (nRead <= 0 || backupPackageStatus3 != 0) {
                                                                        break;
                                                                        break;
                                                                    }
                                                                    backupPackageStatus4 = backupPackageStatus3;
                                                                    packageName = packageName2;
                                                                    totalRead2 = totalRead;
                                                                    in = in;
                                                                    backupPackageStatus5 = 0;
                                                                }
                                                                if (backupPackageStatus3 == -1005) {
                                                                    Slog.w(TAG, "Package hit quota limit in-flight " + packageName2 + ": " + totalRead + " of " + backoff4);
                                                                    this.mMonitor = BackupManagerMonitorUtils.monitorEvent(this.mMonitor, 18, this.mCurrentPackage, 1, null);
                                                                    this.mBackupRunner.sendQuotaExceeded(totalRead, backoff4);
                                                                }
                                                                backupPackageStatus2 = backupPackageStatus3;
                                                            }
                                                            int backupRunnerResult = this.mBackupRunner.getBackupResultBlocking();
                                                            synchronized (this.mCancelLock) {
                                                                try {
                                                                    this.mIsDoingBackup = false;
                                                                    if (!this.mCancelAll) {
                                                                        if (backupRunnerResult == 0) {
                                                                            int finishResult = transport.finishBackup();
                                                                            if (backupPackageStatus2 == 0) {
                                                                                backupPackageStatus2 = finishResult;
                                                                            }
                                                                        } else {
                                                                            transport.cancelFullBackup();
                                                                        }
                                                                    }
                                                                } catch (Throwable th15) {
                                                                    th = th15;
                                                                    while (true) {
                                                                        throw th;
                                                                    }
                                                                }
                                                            }
                                                            if (backupPackageStatus2 == 0 && backupRunnerResult != 0) {
                                                                backupPackageStatus2 = backupRunnerResult;
                                                            }
                                                            if (backupPackageStatus2 != 0) {
                                                                Slog.e(TAG, "Error " + backupPackageStatus2 + " backing up " + packageName2);
                                                            }
                                                            backoff = transport.requestFullBackupTime();
                                                            try {
                                                                StringBuilder sb = new StringBuilder();
                                                                int backupPackageStatus6 = backupPackageStatus2;
                                                                sb.append("Transport suggested backoff=");
                                                                sb.append(backoff);
                                                                Slog.i(TAG, sb.toString());
                                                                backupPackageStatus = backupPackageStatus6;
                                                            } catch (Exception e4) {
                                                                e = e4;
                                                                transportPipes2 = transportPipes;
                                                                backoff5 = backoff;
                                                                enginePipes = enginePipes;
                                                            } catch (Throwable th16) {
                                                                th = th16;
                                                                enginePipes = enginePipes;
                                                            }
                                                        } catch (Exception e5) {
                                                            ParcelFileDescriptor[] parcelFileDescriptorArr3 = enginePipes2;
                                                            e = e5;
                                                            transportPipes2 = transportPipes;
                                                            backoff5 = backoff3;
                                                            enginePipes = parcelFileDescriptorArr3;
                                                        } catch (Throwable th17) {
                                                            ParcelFileDescriptor[] parcelFileDescriptorArr4 = enginePipes2;
                                                            transportPipes = transportPipes;
                                                            th = th17;
                                                            backoff = backoff3;
                                                            enginePipes = parcelFileDescriptorArr4;
                                                        }
                                                    } else {
                                                        enginePipes = enginePipes2;
                                                        transportPipes = transportPipes;
                                                        packageName2 = packageName;
                                                        backupPackageStatus = backupPackageStatus4;
                                                        backoff = backoff3;
                                                    }
                                                    try {
                                                        if (this.mUpdateSchedule) {
                                                            this.backupManagerService.enqueueFullBackup(packageName2, System.currentTimeMillis());
                                                        }
                                                        if (backupPackageStatus == -1002) {
                                                            BackupObserverUtils.sendBackupOnPackageResult(this.mBackupObserver, packageName2, JobSchedulerShellCommand.CMD_ERR_CONSTRAINTS);
                                                            Slog.i(TAG, "Transport rejected backup of " + packageName2 + ", skipping");
                                                            EventLog.writeEvent(EventLogTags.FULL_BACKUP_AGENT_FAILURE, packageName2, "transport rejected");
                                                            if (this.mBackupRunner != null) {
                                                                currentPackage2 = currentPackage;
                                                                this.backupManagerService.tearDownAgentAndKill(currentPackage2.applicationInfo);
                                                            } else {
                                                                currentPackage2 = currentPackage;
                                                            }
                                                        } else {
                                                            currentPackage2 = currentPackage;
                                                            if (backupPackageStatus == -1005) {
                                                                BackupObserverUtils.sendBackupOnPackageResult(this.mBackupObserver, packageName2, -1005);
                                                                Slog.i(TAG, "Transport quota exceeded for package: " + packageName2);
                                                                EventLog.writeEvent(EventLogTags.FULL_BACKUP_QUOTA_EXCEEDED, packageName2);
                                                                this.backupManagerService.tearDownAgentAndKill(currentPackage2.applicationInfo);
                                                            } else if (backupPackageStatus == -1003) {
                                                                BackupObserverUtils.sendBackupOnPackageResult(this.mBackupObserver, packageName2, -1003);
                                                                Slog.w(TAG, "Application failure for package: " + packageName2);
                                                                EventLog.writeEvent(EventLogTags.BACKUP_AGENT_FAILURE, packageName2);
                                                                this.backupManagerService.tearDownAgentAndKill(currentPackage2.applicationInfo);
                                                            } else if (backupPackageStatus == -2003) {
                                                                BackupObserverUtils.sendBackupOnPackageResult(this.mBackupObserver, packageName2, -2003);
                                                                Slog.w(TAG, "Backup cancelled. package=" + packageName2 + ", cancelAll=" + this.mCancelAll);
                                                                EventLog.writeEvent(EventLogTags.FULL_BACKUP_CANCELLED, packageName2);
                                                                this.backupManagerService.tearDownAgentAndKill(currentPackage2.applicationInfo);
                                                            } else if (backupPackageStatus != 0) {
                                                                BackupObserverUtils.sendBackupOnPackageResult(this.mBackupObserver, packageName2, JobSchedulerShellCommand.CMD_ERR_NO_PACKAGE);
                                                                Slog.w(TAG, "Transport failed; aborting backup: " + backupPackageStatus);
                                                                EventLog.writeEvent(EventLogTags.FULL_BACKUP_TRANSPORT_FAILURE, new Object[0]);
                                                                try {
                                                                    this.backupManagerService.tearDownAgentAndKill(currentPackage2.applicationInfo);
                                                                    int backupRunStatus2 = this.mCancelAll ? -2003 : -1000;
                                                                    Slog.i(TAG, "Full backup completed with status: " + backupRunStatus2);
                                                                    BackupObserverUtils.sendBackupFinished(this.mBackupObserver, backupRunStatus2);
                                                                    cleanUpPipes(transportPipes);
                                                                    cleanUpPipes(enginePipes);
                                                                    unregisterTask();
                                                                    FullBackupJob fullBackupJob = this.mJob;
                                                                    if (fullBackupJob != null) {
                                                                        fullBackupJob.finishBackupPass(this.mUserId);
                                                                    }
                                                                    synchronized (this.backupManagerService.getQueueLock()) {
                                                                        try {
                                                                            try {
                                                                                this.backupManagerService.setRunningFullBackupTask(null);
                                                                                this.mListener.onFinished("PFTBT.run()");
                                                                                this.mLatch.countDown();
                                                                                if (this.mUpdateSchedule) {
                                                                                    this.backupManagerService.scheduleNextFullBackupJob(backoff);
                                                                                }
                                                                                Slog.i(TAG, "Full data backup pass finished.");
                                                                                this.backupManagerService.getWakelock().release();
                                                                                return;
                                                                            } catch (Throwable th18) {
                                                                                th3 = th18;
                                                                                throw th3;
                                                                            }
                                                                        } catch (Throwable th19) {
                                                                            th3 = th19;
                                                                            throw th3;
                                                                        }
                                                                    }
                                                                } catch (Exception e6) {
                                                                    enginePipes = enginePipes;
                                                                    e = e6;
                                                                    transportPipes2 = transportPipes;
                                                                    backoff5 = backoff;
                                                                } catch (Throwable th20) {
                                                                    enginePipes = enginePipes;
                                                                    th = th20;
                                                                    backupRunStatus = -1000;
                                                                }
                                                            } else {
                                                                BackupObserverUtils.sendBackupOnPackageResult(this.mBackupObserver, packageName2, 0);
                                                                EventLog.writeEvent(EventLogTags.FULL_BACKUP_SUCCESS, packageName2);
                                                                this.backupManagerService.logBackupComplete(packageName2);
                                                            }
                                                        }
                                                        try {
                                                            cleanUpPipes(transportPipes);
                                                            cleanUpPipes(enginePipes);
                                                            if (currentPackage2.applicationInfo != null) {
                                                                Slog.i(TAG, "Unbinding agent in " + packageName2);
                                                                try {
                                                                    this.backupManagerService.getActivityManager().unbindBackupAgent(currentPackage2.applicationInfo);
                                                                } catch (RemoteException e7) {
                                                                }
                                                            }
                                                            i = i2 + 1;
                                                            transportPipes2 = transportPipes;
                                                            enginePipes2 = enginePipes;
                                                            backoff6 = backoff;
                                                            buffer = buffer;
                                                            N = N;
                                                            backupRunStatus = backupRunStatus;
                                                            singlePackageBackupRunner = null;
                                                        } catch (Exception e8) {
                                                            e = e8;
                                                            transportPipes2 = transportPipes;
                                                            backoff5 = backoff;
                                                        } catch (Throwable th21) {
                                                            th = th21;
                                                        }
                                                    } catch (Exception e9) {
                                                        enginePipes = enginePipes;
                                                        e = e9;
                                                        transportPipes2 = transportPipes;
                                                        backoff5 = backoff;
                                                    } catch (Throwable th22) {
                                                        enginePipes = enginePipes;
                                                        th = th22;
                                                    }
                                                } catch (Throwable th23) {
                                                    enginePipes = enginePipes2;
                                                    th2 = th23;
                                                    while (true) {
                                                        try {
                                                            try {
                                                                break;
                                                            } catch (Exception e10) {
                                                                e = e10;
                                                                transportPipes2 = transportPipes;
                                                                backoff5 = backoff3;
                                                            } catch (Throwable th24) {
                                                                th = th24;
                                                                backoff = backoff3;
                                                            }
                                                        } catch (Throwable th25) {
                                                            th2 = th25;
                                                        }
                                                    }
                                                    throw th2;
                                                }
                                            } catch (Throwable th26) {
                                                backoff3 = backoff6;
                                                obj = obj2;
                                                backupRunStatus = backupRunStatus;
                                                enginePipes = enginePipes2;
                                                th2 = th26;
                                            }
                                        }
                                    } catch (Throwable th27) {
                                        backoff3 = backoff6;
                                        obj = obj2;
                                        backupRunStatus = backupRunStatus;
                                        enginePipes = enginePipes2;
                                        th2 = th27;
                                    }
                                    while (true) {
                                        break;
                                        break;
                                    }
                                    throw th2;
                                }
                                break;
                            } catch (Exception e11) {
                                enginePipes = enginePipes2;
                                transportPipes2 = transportPipes;
                                backoff5 = backoff6;
                                e = e11;
                            } catch (Throwable th28) {
                                backupRunStatus = backupRunStatus;
                                transportPipes = transportPipes;
                                enginePipes = enginePipes2;
                                backoff = backoff6;
                                th = th28;
                            }
                        } catch (Exception e12) {
                            enginePipes = enginePipes2;
                            backoff5 = backoff6;
                            e = e12;
                        } catch (Throwable th29) {
                            backupRunStatus = backupRunStatus;
                            enginePipes = enginePipes2;
                            transportPipes = transportPipes2;
                            backoff = backoff6;
                            th = th29;
                        }
                    }
                    int backupRunStatus3 = this.mCancelAll ? -2003 : backupRunStatus;
                    Slog.i(TAG, "Full backup completed with status: " + backupRunStatus3);
                    BackupObserverUtils.sendBackupFinished(this.mBackupObserver, backupRunStatus3);
                    cleanUpPipes(transportPipes);
                    cleanUpPipes(enginePipes2);
                    unregisterTask();
                    FullBackupJob fullBackupJob2 = this.mJob;
                    if (fullBackupJob2 != null) {
                        fullBackupJob2.finishBackupPass(this.mUserId);
                    }
                    synchronized (this.backupManagerService.getQueueLock()) {
                        try {
                            this.backupManagerService.setRunningFullBackupTask(null);
                        } catch (Throwable th30) {
                            th = th30;
                            while (true) {
                                throw th;
                            }
                        }
                    }
                    this.mListener.onFinished("PFTBT.run()");
                    this.mLatch.countDown();
                    if (this.mUpdateSchedule) {
                        backoff2 = backoff6;
                        this.backupManagerService.scheduleNextFullBackupJob(backoff2);
                    } else {
                        backoff2 = backoff6;
                    }
                    Slog.i(TAG, "Full data backup pass finished.");
                    this.backupManagerService.getWakelock().release();
                    return;
                }
                try {
                    Slog.w(TAG, "Transport not present; full data backup not performed");
                    backupRunStatus = JobSchedulerShellCommand.CMD_ERR_NO_PACKAGE;
                    this.mMonitor = BackupManagerMonitorUtils.monitorEvent(this.mMonitor, 15, this.mCurrentPackage, 1, null);
                    int backupRunStatus4 = this.mCancelAll ? -2003 : -1000;
                    Slog.i(TAG, "Full backup completed with status: " + backupRunStatus4);
                    BackupObserverUtils.sendBackupFinished(this.mBackupObserver, backupRunStatus4);
                    cleanUpPipes(null);
                    cleanUpPipes(null);
                    unregisterTask();
                    FullBackupJob fullBackupJob3 = this.mJob;
                    if (fullBackupJob3 != null) {
                        fullBackupJob3.finishBackupPass(this.mUserId);
                    }
                    synchronized (this.backupManagerService.getQueueLock()) {
                        this.backupManagerService.setRunningFullBackupTask(null);
                    }
                    this.mListener.onFinished("PFTBT.run()");
                    this.mLatch.countDown();
                    if (this.mUpdateSchedule) {
                        this.backupManagerService.scheduleNextFullBackupJob(0L);
                    }
                    Slog.i(TAG, "Full data backup pass finished.");
                    this.backupManagerService.getWakelock().release();
                    return;
                } catch (Exception e13) {
                    enginePipes = null;
                    e = e13;
                } catch (Throwable th31) {
                    enginePipes = null;
                    transportPipes = null;
                    backoff = 0;
                    backupRunStatus = backupRunStatus;
                    th = th31;
                }
                int backupRunStatus5 = this.mCancelAll ? -2003 : backupRunStatus;
                Slog.i(TAG, "Full backup completed with status: " + backupRunStatus5);
                BackupObserverUtils.sendBackupFinished(this.mBackupObserver, backupRunStatus5);
                cleanUpPipes(transportPipes);
                cleanUpPipes(enginePipes);
                unregisterTask();
                FullBackupJob fullBackupJob4 = this.mJob;
                if (fullBackupJob4 != null) {
                    fullBackupJob4.finishBackupPass(this.mUserId);
                }
                synchronized (this.backupManagerService.getQueueLock()) {
                    this.backupManagerService.setRunningFullBackupTask(null);
                }
                this.mListener.onFinished("PFTBT.run()");
                this.mLatch.countDown();
                if (this.mUpdateSchedule) {
                    this.backupManagerService.scheduleNextFullBackupJob(backoff);
                }
                Slog.i(TAG, "Full data backup pass finished.");
                this.backupManagerService.getWakelock().release();
                throw th;
            }
            try {
                Slog.i(TAG, "full backup requested but enabled=" + this.backupManagerService.isEnabled() + " setupComplete=" + this.backupManagerService.isSetupComplete() + "; ignoring");
                int monitoringEvent = this.backupManagerService.isSetupComplete() ? 13 : 14;
                this.mMonitor = BackupManagerMonitorUtils.monitorEvent(this.mMonitor, monitoringEvent, null, 3, null);
                this.mUpdateSchedule = false;
                int backupRunStatus6 = this.mCancelAll ? -2003 : -2001;
                Slog.i(TAG, "Full backup completed with status: " + backupRunStatus6);
                BackupObserverUtils.sendBackupFinished(this.mBackupObserver, backupRunStatus6);
                cleanUpPipes(null);
                cleanUpPipes(null);
                unregisterTask();
                FullBackupJob fullBackupJob5 = this.mJob;
                if (fullBackupJob5 != null) {
                    fullBackupJob5.finishBackupPass(this.mUserId);
                }
                synchronized (this.backupManagerService.getQueueLock()) {
                    this.backupManagerService.setRunningFullBackupTask(null);
                }
                this.mListener.onFinished("PFTBT.run()");
                this.mLatch.countDown();
                if (this.mUpdateSchedule) {
                    this.backupManagerService.scheduleNextFullBackupJob(0L);
                }
                Slog.i(TAG, "Full data backup pass finished.");
                this.backupManagerService.getWakelock().release();
                return;
            } catch (Exception e14) {
                enginePipes = null;
                e = e14;
            } catch (Throwable th32) {
                enginePipes = null;
                transportPipes = null;
                backoff = 0;
                th = th32;
            }
        } catch (Exception e15) {
            enginePipes = null;
            e = e15;
        } catch (Throwable th33) {
            backupRunStatus = 0;
            enginePipes = null;
            transportPipes = null;
            backoff = 0;
            th = th33;
        }
        try {
            Slog.w(TAG, "Exception trying full transport backup", e);
            this.mMonitor = BackupManagerMonitorUtils.monitorEvent(this.mMonitor, 19, this.mCurrentPackage, 3, BackupManagerMonitorUtils.putMonitoringExtra((Bundle) null, "android.app.backup.extra.LOG_EXCEPTION_FULL_BACKUP", Log.getStackTraceString(e)));
            int backupRunStatus7 = this.mCancelAll ? -2003 : -1000;
            Slog.i(TAG, "Full backup completed with status: " + backupRunStatus7);
            BackupObserverUtils.sendBackupFinished(this.mBackupObserver, backupRunStatus7);
            cleanUpPipes(transportPipes2);
            cleanUpPipes(enginePipes);
            unregisterTask();
            FullBackupJob fullBackupJob6 = this.mJob;
            if (fullBackupJob6 != null) {
                fullBackupJob6.finishBackupPass(this.mUserId);
            }
            synchronized (this.backupManagerService.getQueueLock()) {
                this.backupManagerService.setRunningFullBackupTask(null);
            }
            this.mListener.onFinished("PFTBT.run()");
            this.mLatch.countDown();
            if (this.mUpdateSchedule) {
                this.backupManagerService.scheduleNextFullBackupJob(backoff5);
            }
            Slog.i(TAG, "Full data backup pass finished.");
            this.backupManagerService.getWakelock().release();
        } catch (Throwable th34) {
            th = th34;
            transportPipes = transportPipes2;
            backoff = backoff5;
            backupRunStatus = -1000;
        }
    }

    void cleanUpPipes(ParcelFileDescriptor[] pipes) {
        if (pipes != null) {
            if (pipes[0] != null) {
                ParcelFileDescriptor fd = pipes[0];
                pipes[0] = null;
                try {
                    fd.close();
                } catch (IOException e) {
                    Slog.w(TAG, "Unable to close pipe!");
                }
            }
            if (pipes[1] != null) {
                ParcelFileDescriptor fd2 = pipes[1];
                pipes[1] = null;
                try {
                    fd2.close();
                } catch (IOException e2) {
                    Slog.w(TAG, "Unable to close pipe!");
                }
            }
        }
    }

    class SinglePackageBackupPreflight implements BackupRestoreTask, FullBackupPreflight {
        private final int mCurrentOpToken;
        final long mQuota;
        final TransportClient mTransportClient;
        private final int mTransportFlags;
        final AtomicLong mResult = new AtomicLong(-1003);
        final CountDownLatch mLatch = new CountDownLatch(1);

        SinglePackageBackupPreflight(TransportClient transportClient, long quota, int currentOpToken, int transportFlags) {
            this.mTransportClient = transportClient;
            this.mQuota = quota;
            this.mCurrentOpToken = currentOpToken;
            this.mTransportFlags = transportFlags;
        }

        @Override // com.android.server.backup.fullbackup.FullBackupPreflight
        public int preflightFullBackup(PackageInfo pkg, final IBackupAgent agent) {
            long fullBackupAgentTimeoutMillis = PerformFullTransportBackupTask.this.mAgentTimeoutParameters.getFullBackupAgentTimeoutMillis();
            try {
                PerformFullTransportBackupTask.this.backupManagerService.prepareOperationTimeout(this.mCurrentOpToken, fullBackupAgentTimeoutMillis, this, 0);
                agent.doMeasureFullBackup(this.mQuota, this.mCurrentOpToken, PerformFullTransportBackupTask.this.backupManagerService.getBackupManagerBinder(), this.mTransportFlags);
                this.mLatch.await(fullBackupAgentTimeoutMillis, TimeUnit.MILLISECONDS);
                final long totalSize = this.mResult.get();
                if (totalSize < 0) {
                    return (int) totalSize;
                }
                IBackupTransport transport = this.mTransportClient.connectOrThrow("PFTBT$SPBP.preflightFullBackup()");
                int result = transport.checkFullBackupSize(totalSize);
                if (result == -1005) {
                    try {
                        RemoteCall.execute(new RemoteCallable() { // from class: com.android.server.backup.fullbackup.-$$Lambda$PerformFullTransportBackupTask$SinglePackageBackupPreflight$hWbC3_rWMPrteAdbbM5aSW2SKD0
                            @Override // com.android.server.backup.remote.RemoteCallable
                            public final void call(Object obj) throws RemoteException {
                                this.f$0.lambda$preflightFullBackup$0$PerformFullTransportBackupTask$SinglePackageBackupPreflight(agent, totalSize, (IBackupCallback) obj);
                            }
                        }, PerformFullTransportBackupTask.this.mAgentTimeoutParameters.getQuotaExceededTimeoutMillis());
                    } catch (Exception e) {
                        e = e;
                        Slog.w(PerformFullTransportBackupTask.TAG, "Exception preflighting " + pkg.packageName + ": " + e.getMessage());
                        return -1003;
                    }
                }
                return result;
            } catch (Exception e2) {
                e = e2;
            }
        }

        public /* synthetic */ void lambda$preflightFullBackup$0$PerformFullTransportBackupTask$SinglePackageBackupPreflight(IBackupAgent agent, long totalSize, IBackupCallback callback) throws RemoteException {
            agent.doQuotaExceeded(totalSize, this.mQuota, callback);
        }

        @Override // com.android.server.backup.BackupRestoreTask
        public void execute() {
        }

        @Override // com.android.server.backup.BackupRestoreTask
        public void operationComplete(long result) {
            this.mResult.set(result);
            this.mLatch.countDown();
            PerformFullTransportBackupTask.this.backupManagerService.removeOperation(this.mCurrentOpToken);
        }

        @Override // com.android.server.backup.BackupRestoreTask
        public void handleCancel(boolean cancelAll) {
            this.mResult.set(-1003L);
            this.mLatch.countDown();
            PerformFullTransportBackupTask.this.backupManagerService.removeOperation(this.mCurrentOpToken);
        }

        @Override // com.android.server.backup.fullbackup.FullBackupPreflight
        public long getExpectedSizeOrErrorCode() {
            long fullBackupAgentTimeoutMillis = PerformFullTransportBackupTask.this.mAgentTimeoutParameters.getFullBackupAgentTimeoutMillis();
            try {
                this.mLatch.await(fullBackupAgentTimeoutMillis, TimeUnit.MILLISECONDS);
                return this.mResult.get();
            } catch (InterruptedException e) {
                return -1L;
            }
        }
    }

    class SinglePackageBackupRunner implements Runnable, BackupRestoreTask {
        private final int mCurrentOpToken;
        private FullBackupEngine mEngine;
        private final int mEphemeralToken;
        private volatile boolean mIsCancelled;
        final ParcelFileDescriptor mOutput;
        final SinglePackageBackupPreflight mPreflight;
        private final long mQuota;
        final PackageInfo mTarget;
        private final int mTransportFlags;
        final CountDownLatch mPreflightLatch = new CountDownLatch(1);
        final CountDownLatch mBackupLatch = new CountDownLatch(1);
        private volatile int mPreflightResult = -1003;
        private volatile int mBackupResult = -1003;

        SinglePackageBackupRunner(ParcelFileDescriptor output, PackageInfo target, TransportClient transportClient, long quota, int currentOpToken, int transportFlags) throws IOException {
            this.mOutput = ParcelFileDescriptor.dup(output.getFileDescriptor());
            this.mTarget = target;
            this.mCurrentOpToken = currentOpToken;
            this.mEphemeralToken = PerformFullTransportBackupTask.this.backupManagerService.generateRandomIntegerToken();
            this.mPreflight = PerformFullTransportBackupTask.this.new SinglePackageBackupPreflight(transportClient, quota, this.mEphemeralToken, transportFlags);
            this.mQuota = quota;
            this.mTransportFlags = transportFlags;
            registerTask();
        }

        void registerTask() {
            synchronized (PerformFullTransportBackupTask.this.backupManagerService.getCurrentOpLock()) {
                PerformFullTransportBackupTask.this.backupManagerService.getCurrentOperations().put(this.mCurrentOpToken, new Operation(0, this, 0));
            }
        }

        void unregisterTask() {
            synchronized (PerformFullTransportBackupTask.this.backupManagerService.getCurrentOpLock()) {
                PerformFullTransportBackupTask.this.backupManagerService.getCurrentOperations().remove(this.mCurrentOpToken);
            }
        }

        @Override // java.lang.Runnable
        public void run() {
            FileOutputStream out = new FileOutputStream(this.mOutput.getFileDescriptor());
            this.mEngine = new FullBackupEngine(PerformFullTransportBackupTask.this.backupManagerService, out, this.mPreflight, this.mTarget, false, this, this.mQuota, this.mCurrentOpToken, this.mTransportFlags);
            try {
                try {
                    try {
                        try {
                            if (!this.mIsCancelled) {
                                this.mPreflightResult = this.mEngine.preflightCheck();
                            }
                            this.mPreflightLatch.countDown();
                            if (this.mPreflightResult == 0 && !this.mIsCancelled) {
                                this.mBackupResult = this.mEngine.backupOnePackage();
                            }
                            unregisterTask();
                            this.mBackupLatch.countDown();
                            this.mOutput.close();
                        } catch (IOException e) {
                            Slog.w(PerformFullTransportBackupTask.TAG, "Error closing transport pipe in runner");
                        }
                    } catch (Exception e2) {
                        Slog.e(PerformFullTransportBackupTask.TAG, "Exception during full package backup of " + this.mTarget.packageName);
                        unregisterTask();
                        this.mBackupLatch.countDown();
                        this.mOutput.close();
                    }
                } catch (Throwable th) {
                    this.mPreflightLatch.countDown();
                    throw th;
                }
            } catch (Throwable th2) {
                unregisterTask();
                this.mBackupLatch.countDown();
                try {
                    this.mOutput.close();
                } catch (IOException e3) {
                    Slog.w(PerformFullTransportBackupTask.TAG, "Error closing transport pipe in runner");
                }
                throw th2;
            }
        }

        public void sendQuotaExceeded(long backupDataBytes, long quotaBytes) {
            this.mEngine.sendQuotaExceeded(backupDataBytes, quotaBytes);
        }

        long getPreflightResultBlocking() {
            long fullBackupAgentTimeoutMillis = PerformFullTransportBackupTask.this.mAgentTimeoutParameters.getFullBackupAgentTimeoutMillis();
            try {
                this.mPreflightLatch.await(fullBackupAgentTimeoutMillis, TimeUnit.MILLISECONDS);
                if (this.mIsCancelled) {
                    return -2003L;
                }
                if (this.mPreflightResult == 0) {
                    return this.mPreflight.getExpectedSizeOrErrorCode();
                }
                return this.mPreflightResult;
            } catch (InterruptedException e) {
                return -1003L;
            }
        }

        int getBackupResultBlocking() {
            long fullBackupAgentTimeoutMillis = PerformFullTransportBackupTask.this.mAgentTimeoutParameters.getFullBackupAgentTimeoutMillis();
            try {
                this.mBackupLatch.await(fullBackupAgentTimeoutMillis, TimeUnit.MILLISECONDS);
                if (this.mIsCancelled) {
                    return -2003;
                }
                return this.mBackupResult;
            } catch (InterruptedException e) {
                return -1003;
            }
        }

        @Override // com.android.server.backup.BackupRestoreTask
        public void execute() {
        }

        @Override // com.android.server.backup.BackupRestoreTask
        public void operationComplete(long result) {
        }

        @Override // com.android.server.backup.BackupRestoreTask
        public void handleCancel(boolean cancelAll) {
            Slog.w(PerformFullTransportBackupTask.TAG, "Full backup cancel of " + this.mTarget.packageName);
            PerformFullTransportBackupTask performFullTransportBackupTask = PerformFullTransportBackupTask.this;
            performFullTransportBackupTask.mMonitor = BackupManagerMonitorUtils.monitorEvent(performFullTransportBackupTask.mMonitor, 4, PerformFullTransportBackupTask.this.mCurrentPackage, 2, null);
            this.mIsCancelled = true;
            PerformFullTransportBackupTask.this.backupManagerService.handleCancel(this.mEphemeralToken, cancelAll);
            PerformFullTransportBackupTask.this.backupManagerService.tearDownAgentAndKill(this.mTarget.applicationInfo);
            this.mPreflightLatch.countDown();
            this.mBackupLatch.countDown();
            PerformFullTransportBackupTask.this.backupManagerService.removeOperation(this.mCurrentOpToken);
        }
    }
}
