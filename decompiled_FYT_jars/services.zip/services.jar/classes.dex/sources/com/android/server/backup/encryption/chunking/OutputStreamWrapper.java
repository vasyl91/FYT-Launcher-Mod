package com.android.server.backup.encryption.chunking;

import java.io.OutputStream;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public interface OutputStreamWrapper {
    OutputStream wrap(OutputStream outputStream);
}
