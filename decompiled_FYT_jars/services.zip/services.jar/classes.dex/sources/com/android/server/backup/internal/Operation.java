package com.android.server.backup.internal;

import com.android.server.backup.BackupRestoreTask;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class Operation {
    public final BackupRestoreTask callback;
    public int state;
    public final int type;

    public Operation(int initialState, BackupRestoreTask callbackObj, int type) {
        this.state = initialState;
        this.callback = callbackObj;
        this.type = type;
    }
}
