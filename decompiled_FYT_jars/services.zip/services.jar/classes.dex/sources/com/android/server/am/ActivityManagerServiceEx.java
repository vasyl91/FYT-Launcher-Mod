package com.android.server.am;

import android.R;
import android.app.ActivityDebugConfigs;
import android.app.ActivityManager;
import android.app.IApplicationThread;
import android.app.PreForkArgs;
import android.app.ProcessInfo;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.InstrumentationInfo;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.ShellCallback;
import android.os.SystemProperties;
import android.util.Slog;
import android.util.SparseIntArray;
import android.util.TimingsTraceLog;
import com.android.server.performance.PerformanceManagerService;
import com.android.server.wm.ActivityTaskManagerService;
import java.io.FileDescriptor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class ActivityManagerServiceEx extends ActivityManagerService {
    public static final boolean KILL_FRONT_APP;
    static final int KILL_STOP_TIMEOUT = 80;
    static final int KILL_STOP_TIMEOUT_DELAY = 7000;
    static final int KILL_STOP_TIMEOUT_DELAY_SHORT = 4000;
    private static final String TAG = "ActivityManagerEx";
    static HashSet<String> sHasAlarmList = null;
    static HashSet<String> sNeedCleanPackages = null;
    static HashMap<String, ProtectArea> sPreProtectAreaList = null;
    static SparseIntArray sProcProtectConfig = null;
    private static final boolean sSupportCompatibityBroadcast = true;
    final String[] m3rdPartyPersistentSvcCompnts;
    final String[] m3rdPartyPersistentSvcProcs;
    private List<String> mCacheProtectList;
    final ExHandler mExHandler;
    private final String[] mForceFgBroadcasts;
    private List<String> mHidePackages;
    private boolean mIsKillStop;
    final String[] mKillTopSystemAppBlacklist;
    LmKillerTracker mLmkTracker;
    private PerformanceManagerService mPerformanceManagerService;
    private final String[] mSpecialBroadcastQueueBlacklist;
    private final String[] mSpecialBroadcasts;
    private int mStopingPid;
    private static final boolean IS_USER_BUILD = Build.IS_USER;
    static final boolean DEBUG_AMSEX = false;
    static final boolean DEBUG_PROCESS_PROTECT = !IS_USER_BUILD;

    static {
        KILL_FRONT_APP = SystemProperties.getBoolean("sys.kill.frontapp", false) || ActivityManager.isLowRamDeviceStatic();
        sPreProtectAreaList = new HashMap<>();
        sHasAlarmList = new HashSet<>();
        sNeedCleanPackages = new HashSet<>();
        sProcProtectConfig = new SparseIntArray();
        sProcProtectConfig.put(1, 0);
        sProcProtectConfig.put(2, 200);
        sProcProtectConfig.put(3, -800);
        sProcProtectConfig.put(11, 0);
        sProcProtectConfig.put(12, 200);
        sProcProtectConfig.put(13, 400);
    }

    public ActivityManagerServiceEx(Context systemContext, ActivityTaskManagerService sAtm) {
        super(systemContext, sAtm);
        this.mStopingPid = -1;
        this.mIsKillStop = false;
        this.mExHandler = new ExHandler(this.mHandler.getLooper());
        this.mKillTopSystemAppBlacklist = this.mContext.getResources().getStringArray(R.array.config_integrityRuleProviderPackages);
        this.m3rdPartyPersistentSvcProcs = this.mContext.getResources().getStringArray(R.array.config_nonPreemptibleInputMethods);
        this.m3rdPartyPersistentSvcCompnts = this.mContext.getResources().getStringArray(R.array.config_nightDisplayColorTemperatureCoefficientsNative);
        BroadcastConstants foreConstants = new BroadcastConstants("bcast_fg_constants");
        foreConstants.TIMEOUT = 28000L;
        BroadcastQueue broadcastQueue = new BroadcastQueue(this, this.mHandler, "foreground-comp", foreConstants, false);
        this.mCtsFgBroadcastQueue = broadcastQueue;
        BroadcastConstants backConstants = new BroadcastConstants("bcast_bg_constants");
        backConstants.TIMEOUT = 90000L;
        BroadcastQueue broadcastQueue2 = new BroadcastQueue(this, this.mHandler, "background-comp", backConstants, false);
        this.mCtsBgBroadcastQueue = broadcastQueue2;
        BroadcastQueue[] broadcastQueues = {this.mBroadcastQueues[0], this.mBroadcastQueues[1], broadcastQueue, broadcastQueue2};
        this.mBroadcastQueues = broadcastQueues;
        this.mForceFgBroadcasts = this.mContext.getResources().getStringArray(R.array.config_hideWhenDisabled_packageNames);
        this.mSpecialBroadcastQueueBlacklist = this.mContext.getResources().getStringArray(R.array.config_mobile_tcp_buffers);
        this.mSpecialBroadcasts = this.mContext.getResources().getStringArray(R.array.config_networkNotifySwitches);
        String[] hidePackagesArray = this.mContext.getResources().getStringArray(R.array.config_highAmbientBrightnessThresholdsOfFixedRefreshRate);
        this.mHidePackages = Arrays.asList(hidePackagesArray);
    }

    @Override // com.android.server.am.ActivityManagerService
    public void systemReady(Runnable goingCallback, TimingsTraceLog traceLog) throws Throwable {
        if (this.mLmkTracker == null) {
            this.mLmkTracker = new LmKillerTracker();
            this.mLmkTracker.start();
        }
        String[] protectProcesses = this.mContext.getResources().getStringArray(R.array.config_optionalIpSecAlgorithms);
        if (protectProcesses != null && protectProcesses.length > 0) {
            this.mCacheProtectList = Arrays.asList(protectProcesses);
        }
        PerformanceManagerService performanceManagerService = this.mPerformanceManagerService;
        if (performanceManagerService != null) {
            performanceManagerService.systemReady();
        }
        super.systemReady(goingCallback, traceLog);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.android.server.am.ActivityManagerService
    public void onShellCommand(FileDescriptor in, FileDescriptor out, FileDescriptor err, String[] args, ShellCallback callback, ResultReceiver resultReceiver) {
        new ActivityManagerShellCommandEx(this, false).exec(this, in, out, err, args, callback, resultReceiver);
    }

    private boolean checkProcessProtectPermisson() {
        int perm = checkPermission("sprd.permission.PROTECT_PROCESS", Binder.getCallingPid(), Binder.getCallingUid());
        return perm == 0;
    }

    @Override // com.android.server.am.ActivityManagerService
    public void setProcessProtectStatusByPid(int pid, int status) {
        ProcessRecord app;
        if (!checkProcessProtectPermisson()) {
            if (DEBUG_PROCESS_PROTECT) {
                Slog.w(TAG, "Permission Denial: pid " + Binder.getCallingPid() + " who want to setProcessProtectStatusByPid requires sprd.permission.PROTECT_PROCESS");
                return;
            }
            return;
        }
        synchronized (this.mPidsSelfLocked) {
            app = this.mPidsSelfLocked.get(pid);
        }
        if (app != null) {
            if (DEBUG_PROCESS_PROTECT) {
                Slog.d(TAG, "setProcessProtectStatusByPid, app: " + app + " status: " + status + " preStatus: " + app.protectStatus);
            }
            synchronized (this) {
                app.protectStatus = status;
            }
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    public void setProcessProtectStatusByProcName(String appName, int status) {
        if (!checkProcessProtectPermisson()) {
            if (DEBUG_PROCESS_PROTECT) {
                Slog.w(TAG, "Permission Denial: pid " + Binder.getCallingPid() + " who want to setProcessProtectStatusByAppName requires sprd.permission.PROTECT_PROCESS");
                return;
            }
            return;
        }
        if (appName == null) {
            return;
        }
        if (DEBUG_PROCESS_PROTECT) {
            Slog.d(TAG, "setProcessProtectStatusByAppName :" + appName + " status:" + status);
        }
        for (int i = this.mProcessList.mLruProcesses.size() - 1; i >= 0; i--) {
            ProcessRecord rec = this.mProcessList.mLruProcesses.get(i);
            if (rec != null && appName.equals(rec.processName)) {
                rec.protectStatus = status;
                if (DEBUG_PROCESS_PROTECT) {
                    Slog.d(TAG, "setProcessProtectStatusByAppName find app:" + rec);
                    return;
                }
                return;
            }
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    public void setProcessProtectArea(String appName, int minAdj, int maxAdj, int protectLevel) {
        if (!checkProcessProtectPermisson()) {
            if (DEBUG_PROCESS_PROTECT) {
                Slog.w(TAG, "Permission Denial: pid " + Binder.getCallingPid() + " who want to setProcessProtectArea requires sprd.permission.PROTECT_PROCESS");
                return;
            }
            return;
        }
        if (DEBUG_PROCESS_PROTECT) {
            Slog.d(TAG, "setProcessProtectStatus :" + appName + " minAdj:" + minAdj + " maxAdj:" + maxAdj + " protectLevel:" + protectLevel);
        }
        if (appName == null) {
            return;
        }
        synchronized (this.mPidsSelfLocked) {
            for (int i = this.mProcessList.mLruProcesses.size() - 1; i >= 0; i--) {
                ProcessRecord rec = this.mPidsSelfLocked.valueAt(i);
                if (rec != null && appName.equals(rec.processName)) {
                    rec.protectStatus = protectLevel;
                    rec.protectMinAdj = minAdj;
                    rec.protectMaxAdj = maxAdj;
                    if (!DEBUG_PROCESS_PROTECT) {
                        break;
                    }
                    Slog.d(TAG, "setProcessProtectArea find app:" + rec);
                    break;
                }
            }
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    void updateLruProcessLocked(ProcessRecord app, boolean activityChange, ProcessRecord client) {
        super.updateLruProcessLocked(app, activityChange, client);
        List<String> list = this.mCacheProtectList;
        if (list == null || list.size() <= 0 || !app.empty || !app.cached) {
            return;
        }
        int index = this.mProcessList.mLruProcesses.lastIndexOf(app);
        for (int i = index - 1; i >= 0; i--) {
            ProcessRecord cacheProc = this.mProcessList.mLruProcesses.get(i);
            if (this.mCacheProtectList.contains(cacheProc.processName)) {
                this.mProcessList.mLruProcesses.remove(i);
                this.mProcessList.mLruProcesses.add(index, cacheProc);
                index--;
            }
        }
    }

    public static class ProtectArea {
        int mLevel;
        int mMaxAdj;
        int mMinAdj;

        public ProtectArea(int minAdj, int maxAdj, int protectLevel) {
            this.mMinAdj = minAdj;
            this.mMaxAdj = maxAdj;
            this.mLevel = protectLevel;
        }

        public String toString() {
            return "ProtectArea [mMinAdj=" + this.mMinAdj + ", mMaxAdj=" + this.mMaxAdj + ", mLevel=" + this.mLevel + "]";
        }
    }

    public void addProtectArea(final String processName, final ProtectArea area) {
        if (processName == null || area == null) {
            return;
        }
        if (DEBUG_AMSEX) {
            Slog.d(TAG, "addProtectArea, processName: " + processName + " ProtectArea: " + area);
        }
        this.mHandler.post(new Runnable() { // from class: com.android.server.am.ActivityManagerServiceEx.1
            @Override // java.lang.Runnable
            public void run() {
                synchronized (ActivityManagerServiceEx.this) {
                    ActivityManagerServiceEx.sPreProtectAreaList.put(processName, area);
                    ActivityManagerServiceEx.this.updateOomAdjLocked("updateOomAdj_meh");
                }
            }
        });
    }

    public void removeProtectArea(final String processName) {
        if (processName == null) {
            return;
        }
        sPreProtectAreaList.remove(processName);
        this.mHandler.post(new Runnable() { // from class: com.android.server.am.ActivityManagerServiceEx.2
            @Override // java.lang.Runnable
            public void run() {
                synchronized (ActivityManagerServiceEx.this) {
                    ProcessRecord app = null;
                    for (int i = ActivityManagerServiceEx.this.mProcessList.mLruProcesses.size() - 1; i >= 0; i--) {
                        if (processName.equals(ActivityManagerServiceEx.this.mProcessList.mLruProcesses.get(i).processName)) {
                            app = ActivityManagerServiceEx.this.mProcessList.mLruProcesses.get(i);
                            break;
                        }
                    }
                    if (ActivityManagerServiceEx.DEBUG_AMSEX) {
                        Slog.d(ActivityManagerServiceEx.TAG, "removeProtectArea, processName: " + processName + " app: " + app);
                    }
                    if (app != null) {
                        ActivityManagerServiceEx.this.updateOomAdjLocked(app, false, "updateOomAdj_meh");
                    }
                }
            }
        });
    }

    @Override // com.android.server.am.ActivityManagerService
    void preBringUpPhoneLocked() {
        try {
            Slog.i(TAG, "pre start phone process");
            ApplicationInfo phoneInfo = this.mContext.getPackageManager().getApplicationInfo("com.android.phone", 0);
            addAppLocked(phoneInfo, null, false, null);
        } catch (Exception e) {
            Slog.e(TAG, "pre bring up phone process failed !", e);
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    public void startHomePre() {
        if (!KILL_FRONT_APP) {
            return;
        }
        synchronized (this) {
            if (this.mActivityTaskManager.isHomeAlreadyStart(-1)) {
                return;
            }
            if (this.mActivityTaskManager.getAtmInternal().getHomeProcess() == null && -1 > 0) {
                Slog.w(TAG, "kill front app pid=-1");
                long origId = Binder.clearCallingIdentity();
                Process.killProcessQuiet(-1);
                handleAppDiedLocked(this.mPidsSelfLocked.get(-1), false, false);
                Binder.restoreCallingIdentity(origId);
            }
        }
    }

    final class ExHandler extends Handler {
        public ExHandler(Looper looper) {
            super(looper, null, true);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            if (msg.what == 80) {
                Slog.w(ActivityManagerServiceEx.TAG, "The kill front app delay time is expired, it's time to kill the front app Pid:" + ActivityManagerServiceEx.this.mStopingPid);
                if (ActivityManagerServiceEx.this.mStopingPid > 0) {
                    Process.sendSignal(ActivityManagerServiceEx.this.mStopingPid, 9);
                    ActivityManagerServiceEx.this.mStopingPid = -1;
                    ActivityManagerServiceEx.this.mIsKillStop = false;
                }
            }
        }
    }

    private boolean isInKillTopSystemAppBlacklist(ApplicationInfo info) {
        int i = 0;
        while (true) {
            String[] strArr = this.mKillTopSystemAppBlacklist;
            if (i < strArr.length) {
                if (strArr[i] == null || !strArr[i].equals(info.packageName)) {
                    i++;
                } else {
                    return true;
                }
            } else {
                return false;
            }
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    public void killStopFrontApp(int func) {
        if (!KILL_FRONT_APP) {
            Slog.w(TAG, "kill stop front app feature is only enabled in low ram device.");
            return;
        }
        if (this.mIsKillStop && func == 1) {
            Slog.w(TAG, "killStopFrontApp is already called by someone else, wait for the kill action to be done.");
            return;
        }
        synchronized (this) {
            int callingPid = Binder.getCallingPid();
            if (func == 1) {
                int pid = this.mActivityTaskManager.getKillableForegroundAppPid(callingPid);
                if (pid > 0) {
                    this.mIsKillStop = true;
                    if (KILL_FRONT_APP && this.mActivityTaskManager.getAtmInternal().getHomeProcess() == null) {
                        this.mStopingPid = pid;
                        if (!this.mExHandler.hasMessages(80)) {
                            Slog.w(TAG, "Home process is not active, kill the front app after 4000ms, front app pid: " + this.mStopingPid);
                            Message msg = this.mExHandler.obtainMessage(80);
                            this.mExHandler.sendMessageDelayed(msg, 4000L);
                        }
                        return;
                    }
                    this.mStopingPid = pid;
                    if (!this.mExHandler.hasMessages(80)) {
                        Slog.w(TAG, "kill the front app after 7000ms, front app pid: " + this.mStopingPid);
                        Message msg2 = this.mExHandler.obtainMessage(80);
                        this.mExHandler.sendMessageDelayed(msg2, 7000L);
                    }
                }
            } else if (func == 0) {
                this.mIsKillStop = false;
                if (this.mStopingPid > 0) {
                    Slog.w(TAG, "Caller[" + callingPid + "] is request to cancel to kill the front app, pid: " + this.mStopingPid);
                    this.mExHandler.removeMessages(80);
                    this.mStopingPid = -1;
                }
            } else if (func == 2) {
                Slog.w(TAG, "Caller[" + callingPid + "] is request to cancel to kil front app, pid: " + this.mStopingPid);
                this.mExHandler.removeMessages(80);
            } else {
                Slog.w(TAG, "The top activity is home Activity or is from light weight system app, will not kill it.");
            }
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    public List<ActivityManager.RunningAppProcessInfo> getRunningAppProcesses() {
        List<String> list;
        List<ActivityManager.RunningAppProcessInfo> runningAppList = super.getRunningAppProcesses();
        if (runningAppList == null || runningAppList.size() <= 0 || (list = this.mHidePackages) == null || list.size() <= 0) {
            return runningAppList;
        }
        List<ActivityManager.RunningAppProcessInfo> loopList = new ArrayList<>(runningAppList);
        for (ActivityManager.RunningAppProcessInfo appInfo : loopList) {
            if (appInfo.pkgList != null && appInfo.pkgList.length > 0) {
                for (String pkg : appInfo.pkgList) {
                    if (this.mHidePackages.contains(pkg)) {
                        Slog.d(TAG, "mHidePackages contains " + pkg + ", remove it");
                        runningAppList.remove(appInfo);
                    }
                }
            }
        }
        remove3rdPartyPersistSvcProcs(runningAppList);
        return runningAppList;
    }

    private void remove3rdPartyPersistSvcProcs(List<ActivityManager.RunningAppProcessInfo> runningAppList) {
        List<ActivityManager.RunningAppProcessInfo> runlistCopy = new ArrayList<>(runningAppList);
        int callingUid = Binder.getCallingUid();
        for (ActivityManager.RunningAppProcessInfo rpi : runlistCopy) {
            if (rpi != null && rpi.processName != null && callingUid > 10000) {
                for (int i = 0; i < this.m3rdPartyPersistentSvcProcs.length; i++) {
                    if (rpi.processName.equals(this.m3rdPartyPersistentSvcProcs[i])) {
                        Slog.i(TAG, "getRunningAppProcesses: Removing rpi:" + rpi.processName + " from result for caller[uid]:" + callingUid);
                        runningAppList.remove(rpi);
                    }
                }
            }
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    public final void attachApplication(IApplicationThread thread, long startSeq) {
        ProcessRecord app;
        synchronized (this) {
            super.attachApplication(thread, startSeq);
            int callingPid = Binder.getCallingPid();
            if (callingPid != MY_PID && callingPid >= 0) {
                synchronized (this.mPidsSelfLocked) {
                    app = this.mPidsSelfLocked.get(callingPid);
                }
            } else {
                app = null;
            }
            if (app != null) {
                for (int i = 0; i < this.m3rdPartyPersistentSvcProcs.length; i++) {
                    if (app.processName != null && app.processName.equals(this.m3rdPartyPersistentSvcProcs[i])) {
                        app.setPersistent(true);
                        app.info.flags |= 8;
                        if (!uidOnBackgroundWhitelist(app.uid)) {
                            backgroundWhitelistUid(app.uid);
                        }
                        Slog.i(TAG, "attachApplicationLocked: set persistent:" + app.isPersistent() + " for app:" + app);
                    }
                }
            }
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    BroadcastQueue broadcastQueueForIntent(String callerPackage, Intent intent) {
        String str;
        if (isOnOffloadQueue(intent.getFlags())) {
            if (ActivityManagerDebugConfig.DEBUG_BROADCAST_BACKGROUND) {
                Slog.i(TAG, "Broadcast intent " + intent + " on offload queue");
            }
            return this.mOffloadBroadcastQueue;
        }
        boolean isSpecialBroadcast = isInSpecialBroadcastGroup(this.mSpecialBroadcasts, callerPackage, intent) && !isInSpecialBroadcastGroup(this.mSpecialBroadcastQueueBlacklist, callerPackage, intent);
        boolean isFg = isInSpecialBroadcastGroup(this.mForceFgBroadcasts, callerPackage, intent) || (intent.getFlags() & 268435456) != 0;
        if (ActivityManagerDebugConfig.DEBUG_BROADCAST_BACKGROUND && isSpecialBroadcast) {
            StringBuilder sb = new StringBuilder();
            sb.append("Check broadcast intent ");
            sb.append(intent);
            sb.append(" on ");
            if (isFg) {
                str = isSpecialBroadcast ? "foreground-comp" : "foreground";
            } else {
                str = isSpecialBroadcast ? "background-comp" : "background";
            }
            sb.append(str);
            sb.append(" queue");
            Slog.i(TAG, sb.toString());
        }
        if (isFg && !isSpecialBroadcast) {
            return this.mBroadcastQueues[0];
        }
        if (!isFg && !isSpecialBroadcast) {
            return this.mBroadcastQueues[1];
        }
        if (isFg && isSpecialBroadcast) {
            return this.mBroadcastQueues[2];
        }
        return this.mBroadcastQueues[3];
    }

    private boolean isInSpecialBroadcastGroup(String[] specialGroup, String callerPackage, Intent intent) {
        boolean isSpecialCaller = false;
        boolean isSpecialBroadcastAction = false;
        String action = null;
        if (intent != null && intent.getAction() != null) {
            action = intent.getAction();
        }
        if (action == null && callerPackage == null) {
            return false;
        }
        if (specialGroup != null && specialGroup.length > 0) {
            for (int i = 0; i < specialGroup.length; i++) {
                try {
                    Pattern pattern = Pattern.compile(specialGroup[i]);
                    if (callerPackage != null && pattern != null && pattern.matcher(callerPackage).find()) {
                        isSpecialCaller = true;
                        break;
                    }
                    if (action != null && pattern != null && pattern.matcher(action).find()) {
                        isSpecialBroadcastAction = true;
                        break;
                    }
                } catch (PatternSyntaxException e) {
                    Slog.w(TAG, "isInSpecialBroadcastGroup check for sender:" + callerPackage + " of " + intent + " encounter invalid pattern string:" + specialGroup[i], e);
                }
            }
        }
        return isSpecialCaller || isSpecialBroadcastAction;
    }

    @Override // com.android.server.am.ActivityManagerService
    boolean isPendingBroadcastProcessLocked(int pid) {
        return super.isPendingBroadcastProcessLocked(pid) || this.mCtsFgBroadcastQueue.isPendingBroadcastProcessLocked(pid) || this.mCtsBgBroadcastQueue.isPendingBroadcastProcessLocked(pid);
    }

    @Override // com.android.server.am.ActivityManagerService
    BroadcastQueue[] getFgOrBgQueues(int flags) {
        boolean foreground = (268435456 & flags) != 0;
        if (foreground) {
            return new BroadcastQueue[]{this.mFgBroadcastQueue, this.mCtsFgBroadcastQueue};
        }
        return new BroadcastQueue[]{this.mBgBroadcastQueue, this.mCtsBgBroadcastQueue};
    }

    @Override // com.android.server.am.ActivityManagerService
    void applyPackageDebugConfigs(ProcessRecord app, IApplicationThread thread, ActivityDebugConfigs config) {
        if (config == null) {
            return;
        }
        if (app == null) {
            Slog.w(TAG, "Failed to applyPackageDebugConfigs, app is null");
            return;
        }
        if (thread == null) {
            thread = app.thread;
        }
        if (thread == null) {
            Slog.w(TAG, "Failed to apply debug config for invalid process, package:" + app);
            return;
        }
        try {
            Slog.v(TAG, "Apply debug config to process: " + app + " with config " + config);
            thread.applyActivityDebugConfigs(config);
        } catch (RemoteException e) {
            Slog.d(TAG, "Failed to call applyActivityDebugConfigs to package " + config.packageName, e);
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    void applyPackageDebugConfigs(ActivityDebugConfigs config) {
        if (config == null || config.packageName == null) {
            Slog.w(TAG, "Failed to applyPackageDebugConfigs, config or package name is null");
            return;
        }
        synchronized (this.mPidsSelfLocked) {
            int N = this.mPidsSelfLocked.size();
            boolean applyToAll = "all".equals(config.packageName);
            for (int i = 0; i < N; i++) {
                ProcessRecord app = this.mPidsSelfLocked.valueAt(i);
                if (app != null) {
                    if (app.thread == null) {
                        Slog.w(TAG, "Skip searching invalid process: " + app);
                    } else if (applyToAll || app.pkgList.containsKey(config.packageName)) {
                        applyPackageDebugConfigs(app, config);
                    }
                }
            }
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    void notifyActivityStateChange(Intent intent, int state, Bundle bundle) {
        try {
            if (this.mPerformanceManagerService != null) {
                if (bundle == null) {
                    bundle = new Bundle();
                }
                bundle.putInt("activity_state", state);
                this.mPerformanceManagerService.notifyActivityStateChange(intent, bundle);
            }
        } catch (Exception e) {
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    int processLmkAdjTunningIfneeded(ProcessInfo app, int memLvl, long now, long nowElapsed) {
        try {
            if (this.mPerformanceManagerService == null) {
                return 2;
            }
            int ret = this.mPerformanceManagerService.processLmkAdjTunningIfneeded(app, memLvl, now, nowElapsed);
            return ret;
        } catch (Exception e) {
            return 2;
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    public void setPerformanceManager(PerformanceManagerService performanceManager) {
        this.mPerformanceManagerService = performanceManager;
        this.mActivityTaskManager.setPerformanceManager(performanceManager);
    }

    public void applyOomAdjByProcessInfo(ProcessInfo info, long now, long nowElapsed) {
        synchronized (this) {
            applyOomAdjByProcessInfoLocked(info, now, nowElapsed);
        }
    }

    public void applyOomAdjByProcessInfoLocked(ProcessInfo info, long now, long nowElapsed) {
        ProcessRecord app = null;
        for (int i = this.mProcessList.mLruProcesses.size() - 1; i >= 0; i--) {
            if (info.processName.equals(this.mProcessList.mLruProcesses.get(i).processName) && info.pid == this.mProcessList.mLruProcesses.get(i).pid) {
                ProcessRecord app2 = this.mProcessList.mLruProcesses.get(i);
                app = app2;
                break;
            }
        }
        if (app != null) {
            app.curAdj = info.tunnedAdj;
            app.adjType = info.tunnedAdjType;
            app.mCurProcState = info.tunnedProcState;
            app.mCurSchedGroup = info.tunnedSchedGroup;
            this.mOomAdjuster.applyOomAdjLocked(app, true, now, nowElapsed);
        }
    }

    @Override // com.android.server.am.ActivityManagerService
    public ArrayList<ProcessInfo> getRunningProcessesInfo() {
        ArrayList<ProcessInfo> list = new ArrayList<>();
        synchronized (this) {
            for (int i = this.mProcessList.mLruProcesses.size() - 1; i >= 0; i--) {
                ProcessRecord app = this.mProcessList.mLruProcesses.get(i);
                if (app != null && app.info != null) {
                    ProcessInfo info = createProcessInfo(app);
                    list.add(info);
                }
            }
        }
        return list;
    }

    @Override // com.android.server.am.ActivityManagerService
    boolean keepImpAppAlive(String pkgName) {
        PerformanceManagerService performanceManagerService = this.mPerformanceManagerService;
        return performanceManagerService != null && performanceManagerService.keepImpAppAlive(pkgName, this.mLastMemoryLevel);
    }

    @Override // com.android.server.am.ActivityManagerService
    boolean keepImpAppAliveForce(String pkgName) {
        PerformanceManagerService performanceManagerService = this.mPerformanceManagerService;
        return performanceManagerService != null && performanceManagerService.keepImpAppAliveForce(pkgName);
    }

    boolean isProcessHeldWakeLock(ProcessRecord p) {
        PerformanceManagerService performanceManagerService = this.mPerformanceManagerService;
        if (performanceManagerService != null) {
            return performanceManagerService.isProcessHeldWakeLock(p.uid);
        }
        return false;
    }

    @Override // com.android.server.am.ActivityManagerService
    void notifyInstrumentationStatus(boolean start, ProcessRecord app, InstrumentationInfo ii) {
        PerformanceManagerService performanceManagerService = this.mPerformanceManagerService;
        if (performanceManagerService != null) {
            performanceManagerService.notifyInstrumentationStatus(start, createProcessInfo(app), ii);
        }
    }

    public String getTopActivityCallingPkg() {
        return this.mActivityTaskManager.getTopActivityCallingPkg();
    }

    @Override // com.android.server.am.ActivityManagerService
    protected Process.ProcessStartResult handlePreForkStartProcess(PreForkArgs preforkArgs) {
        PerformanceManagerService performanceManagerService = this.mPerformanceManagerService;
        if (performanceManagerService != null) {
            return performanceManagerService.handlePreForkStartProcess(preforkArgs);
        }
        return null;
    }

    @Override // com.android.server.am.ActivityManagerService
    protected void preforkStart(PreForkArgs preforkArgs) {
        PerformanceManagerService performanceManagerService = this.mPerformanceManagerService;
        if (performanceManagerService != null) {
            performanceManagerService.preforkStart(preforkArgs);
        }
    }

    public boolean isUserAMonkeyTotallyNoCheck() {
        return this.mUserIsMonkey || this.mActivityTaskManager.isControllerAMonkeyNoCheck();
    }
}
