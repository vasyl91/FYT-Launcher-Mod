package com.android.server.appop;

import android.app.ActivityManager;
import android.app.ActivityThread;
import android.app.AppGlobals;
import android.app.AppOpsManager;
import android.app.AppOpsManagerInternal;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageManager;
import android.content.pm.PackageManager;
import android.content.pm.PackageManagerInternal;
import android.content.pm.UserInfo;
import android.database.ContentObserver;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Process;
import android.os.RemoteCallback;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.ServiceManager;
import android.os.ShellCallback;
import android.os.ShellCommand;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.UserHandle;
import android.os.UserManager;
import android.os.storage.StorageManager;
import android.os.storage.StorageManagerInternal;
import android.provider.Settings;
import android.util.ArrayMap;
import android.util.ArraySet;
import android.util.AtomicFile;
import android.util.KeyValueListParser;
import android.util.LongSparseArray;
import android.util.LongSparseLongArray;
import android.util.Slog;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.util.SparseIntArray;
import android.util.TimeUtils;
import android.util.Xml;
import com.android.internal.annotations.GuardedBy;
import com.android.internal.annotations.VisibleForTesting;
import com.android.internal.app.IAppOpsActiveCallback;
import com.android.internal.app.IAppOpsCallback;
import com.android.internal.app.IAppOpsNotedCallback;
import com.android.internal.app.IAppOpsService;
import com.android.internal.util.ArrayUtils;
import com.android.internal.util.DumpUtils;
import com.android.internal.util.Preconditions;
import com.android.internal.util.XmlUtils;
import com.android.internal.util.function.HexConsumer;
import com.android.internal.util.function.QuadFunction;
import com.android.internal.util.function.QuintConsumer;
import com.android.internal.util.function.TriFunction;
import com.android.internal.util.function.pooled.PooledLambda;
import com.android.server.LocalServices;
import com.android.server.LockGuard;
import com.android.server.SystemService;
import com.android.server.display.color.DisplayTransformManager;
import com.android.server.job.controllers.JobStatus;
import com.android.server.net.watchlist.WatchlistLoggingHandler;
import com.android.server.notification.NotificationShellCmd;
import com.android.server.pm.PackageManagerService;
import com.android.server.slice.SliceClientPermissions;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import libcore.util.EmptyArray;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class AppOpsService extends IAppOpsService.Stub {
    private static final int CURRENT_VERSION = 1;
    static final boolean DEBUG = false;
    private static final int NO_VERSION = -1;
    static final String TAG = "AppOps";
    private static final int UID_ANY = -2;
    static final long WRITE_DELAY = 1800000;

    @GuardedBy({"this"})
    private AppOpsManagerInternal.CheckOpsDelegate mCheckOpsDelegate;

    @VisibleForTesting
    final Constants mConstants;
    Context mContext;
    boolean mFastWriteScheduled;
    final AtomicFile mFile;
    final Handler mHandler;
    long mLastRealtime;
    SparseIntArray mProfileOwners;
    boolean mWriteScheduled;
    private static final int[] PROCESS_STATE_TO_UID_STATE = {100, 100, 200, DisplayTransformManager.LEVEL_COLOR_MATRIX_INVERT_COLOR, 500, 400, 500, 500, SystemService.PHASE_THIRD_PARTY_APPS_CAN_START, SystemService.PHASE_THIRD_PARTY_APPS_CAN_START, SystemService.PHASE_THIRD_PARTY_APPS_CAN_START, SystemService.PHASE_THIRD_PARTY_APPS_CAN_START, SystemService.PHASE_THIRD_PARTY_APPS_CAN_START, 700, 700, 700, 700, 700, 700, 700, 700, 700};
    private static final int[] OPS_RESTRICTED_ON_SUSPEND = {28, 27, 26};
    private final AppOpsManagerInternalImpl mAppOpsManagerInternal = new AppOpsManagerInternalImpl();
    final Runnable mWriteRunner = new Runnable() { // from class: com.android.server.appop.AppOpsService.1
        @Override // java.lang.Runnable
        public void run() {
            synchronized (AppOpsService.this) {
                AppOpsService.this.mWriteScheduled = false;
                AppOpsService.this.mFastWriteScheduled = false;
                AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>() { // from class: com.android.server.appop.AppOpsService.1.1
                    /* JADX INFO: Access modifiers changed from: protected */
                    @Override // android.os.AsyncTask
                    public Void doInBackground(Void... params) {
                        AppOpsService.this.writeState();
                        return null;
                    }
                };
                task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void[]) null);
            }
        }
    };

    @VisibleForTesting
    final SparseArray<UidState> mUidStates = new SparseArray<>();
    final HistoricalRegistry mHistoricalRegistry = new HistoricalRegistry(this);
    private final ArrayMap<IBinder, ClientRestrictionState> mOpUserRestrictions = new ArrayMap<>();
    final SparseArray<ArraySet<ModeCallback>> mOpModeWatchers = new SparseArray<>();
    final ArrayMap<String, ArraySet<ModeCallback>> mPackageModeWatchers = new ArrayMap<>();
    final ArrayMap<IBinder, ModeCallback> mModeWatchers = new ArrayMap<>();
    final ArrayMap<IBinder, SparseArray<ActiveCallback>> mActiveWatchers = new ArrayMap<>();
    final ArrayMap<IBinder, SparseArray<NotedCallback>> mNotedWatchers = new ArrayMap<>();
    final SparseArray<SparseArray<Restriction>> mAudioRestrictions = new SparseArray<>();
    final ArrayMap<IBinder, ClientState> mClients = new ArrayMap<>();

    @VisibleForTesting
    final class Constants extends ContentObserver {
        private static final String KEY_BG_STATE_SETTLE_TIME = "bg_state_settle_time";
        private static final String KEY_FG_SERVICE_STATE_SETTLE_TIME = "fg_service_state_settle_time";
        private static final String KEY_TOP_STATE_SETTLE_TIME = "top_state_settle_time";
        public long BG_STATE_SETTLE_TIME;
        public long FG_SERVICE_STATE_SETTLE_TIME;
        public long TOP_STATE_SETTLE_TIME;
        private final KeyValueListParser mParser;
        private ContentResolver mResolver;

        public Constants(Handler handler) {
            super(handler);
            this.mParser = new KeyValueListParser(',');
            updateConstants();
        }

        public void startMonitoring(ContentResolver resolver) {
            this.mResolver = resolver;
            this.mResolver.registerContentObserver(Settings.Global.getUriFor("app_ops_constants"), false, this);
            updateConstants();
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange, Uri uri) {
            updateConstants();
        }

        private void updateConstants() {
            ContentResolver contentResolver = this.mResolver;
            String value = contentResolver != null ? Settings.Global.getString(contentResolver, "app_ops_constants") : "";
            synchronized (AppOpsService.this) {
                try {
                    this.mParser.setString(value);
                } catch (IllegalArgumentException e) {
                    Slog.e(AppOpsService.TAG, "Bad app ops settings", e);
                }
                this.TOP_STATE_SETTLE_TIME = this.mParser.getDurationMillis(KEY_TOP_STATE_SETTLE_TIME, 30000L);
                this.FG_SERVICE_STATE_SETTLE_TIME = this.mParser.getDurationMillis(KEY_FG_SERVICE_STATE_SETTLE_TIME, JobStatus.DEFAULT_TRIGGER_UPDATE_DELAY);
                this.BG_STATE_SETTLE_TIME = this.mParser.getDurationMillis(KEY_BG_STATE_SETTLE_TIME, 1000L);
            }
        }

        void dump(PrintWriter pw) {
            pw.println("  Settings:");
            pw.print("    ");
            pw.print(KEY_TOP_STATE_SETTLE_TIME);
            pw.print("=");
            TimeUtils.formatDuration(this.TOP_STATE_SETTLE_TIME, pw);
            pw.println();
            pw.print("    ");
            pw.print(KEY_FG_SERVICE_STATE_SETTLE_TIME);
            pw.print("=");
            TimeUtils.formatDuration(this.FG_SERVICE_STATE_SETTLE_TIME, pw);
            pw.println();
            pw.print("    ");
            pw.print(KEY_BG_STATE_SETTLE_TIME);
            pw.print("=");
            TimeUtils.formatDuration(this.BG_STATE_SETTLE_TIME, pw);
            pw.println();
        }
    }

    @VisibleForTesting
    static final class UidState {
        public SparseBooleanArray foregroundOps;
        public boolean hasForegroundWatchers;
        public SparseIntArray opModes;
        public long pendingStateCommitTime;
        public ArrayMap<String, Ops> pkgOps;
        public int startNesting;
        public final int uid;
        public int state = 700;
        public int pendingState = 700;

        public UidState(int uid) {
            this.uid = uid;
        }

        public void clear() {
            this.pkgOps = null;
            this.opModes = null;
        }

        public boolean isDefault() {
            SparseIntArray sparseIntArray;
            ArrayMap<String, Ops> arrayMap = this.pkgOps;
            return (arrayMap == null || arrayMap.isEmpty()) && ((sparseIntArray = this.opModes) == null || sparseIntArray.size() <= 0) && this.state == 700 && this.pendingState == 700;
        }

        int evalMode(int op, int mode) {
            if (mode == 4) {
                return this.state <= AppOpsManager.resolveFirstUnrestrictedUidState(op) ? 0 : 1;
            }
            return mode;
        }

        private void evalForegroundWatchers(int op, SparseArray<ArraySet<ModeCallback>> watchers, SparseBooleanArray which) {
            boolean curValue = which.get(op, false);
            ArraySet<ModeCallback> callbacks = watchers.get(op);
            if (callbacks != null) {
                for (int cbi = callbacks.size() - 1; !curValue && cbi >= 0; cbi--) {
                    if ((callbacks.valueAt(cbi).mFlags & 1) != 0) {
                        this.hasForegroundWatchers = true;
                        curValue = true;
                    }
                }
            }
            which.put(op, curValue);
        }

        public void evalForegroundOps(SparseArray<ArraySet<ModeCallback>> watchers) {
            SparseBooleanArray which = null;
            this.hasForegroundWatchers = false;
            SparseIntArray sparseIntArray = this.opModes;
            if (sparseIntArray != null) {
                for (int i = sparseIntArray.size() - 1; i >= 0; i--) {
                    if (this.opModes.valueAt(i) == 4) {
                        if (which == null) {
                            which = new SparseBooleanArray();
                        }
                        evalForegroundWatchers(this.opModes.keyAt(i), watchers, which);
                    }
                }
            }
            ArrayMap<String, Ops> arrayMap = this.pkgOps;
            if (arrayMap != null) {
                for (int i2 = arrayMap.size() - 1; i2 >= 0; i2--) {
                    Ops ops = this.pkgOps.valueAt(i2);
                    for (int j = ops.size() - 1; j >= 0; j--) {
                        if (ops.valueAt(j).mode == 4) {
                            if (which == null) {
                                which = new SparseBooleanArray();
                            }
                            evalForegroundWatchers(ops.keyAt(j), watchers, which);
                        }
                    }
                }
            }
            this.foregroundOps = which;
        }
    }

    static final class Ops extends SparseArray<Op> {
        final boolean isPrivileged;
        final String packageName;
        final UidState uidState;

        Ops(String _packageName, UidState _uidState, boolean _isPrivileged) {
            this.packageName = _packageName;
            this.uidState = _uidState;
            this.isPrivileged = _isPrivileged;
        }
    }

    static final class Op {
        private LongSparseLongArray mAccessTimes;
        private LongSparseLongArray mDurations;
        private LongSparseArray<String> mProxyPackageNames;
        private LongSparseLongArray mProxyUids;
        private LongSparseLongArray mRejectTimes;
        private int mode;
        int op;
        final String packageName;
        boolean running;
        int startNesting;
        long startRealtime;
        final UidState uidState;

        Op(UidState uidState, String packageName, int op) {
            this.op = op;
            this.uidState = uidState;
            this.packageName = packageName;
            this.mode = AppOpsManager.opToDefaultMode(op);
        }

        int getMode() {
            return this.mode;
        }

        int evalMode() {
            return this.uidState.evalMode(this.op, this.mode);
        }

        public void accessed(long time, int proxyUid, String proxyPackageName, int uidState, int flags) {
            long key = AppOpsManager.makeKey(uidState, flags);
            if (this.mAccessTimes == null) {
                this.mAccessTimes = new LongSparseLongArray();
            }
            this.mAccessTimes.put(key, time);
            updateProxyState(key, proxyUid, proxyPackageName);
            LongSparseLongArray longSparseLongArray = this.mDurations;
            if (longSparseLongArray != null) {
                longSparseLongArray.delete(key);
            }
        }

        public void rejected(long time, int proxyUid, String proxyPackageName, int uidState, int flags) {
            long key = AppOpsManager.makeKey(uidState, flags);
            if (this.mRejectTimes == null) {
                this.mRejectTimes = new LongSparseLongArray();
            }
            this.mRejectTimes.put(key, time);
            updateProxyState(key, proxyUid, proxyPackageName);
            LongSparseLongArray longSparseLongArray = this.mDurations;
            if (longSparseLongArray != null) {
                longSparseLongArray.delete(key);
            }
        }

        public void started(long time, int uidState, int flags) {
            updateAccessTimeAndDuration(time, -1L, uidState, flags);
            this.running = true;
        }

        public void finished(long time, long duration, int uidState, int flags) {
            updateAccessTimeAndDuration(time, duration, uidState, flags);
            this.running = false;
        }

        public void running(long time, long duration, int uidState, int flags) {
            updateAccessTimeAndDuration(time, duration, uidState, flags);
        }

        public void continuing(long duration, int uidState, int flags) {
            long key = AppOpsManager.makeKey(uidState, flags);
            if (this.mDurations == null) {
                this.mDurations = new LongSparseLongArray();
            }
            this.mDurations.put(key, duration);
        }

        private void updateAccessTimeAndDuration(long time, long duration, int uidState, int flags) {
            long key = AppOpsManager.makeKey(uidState, flags);
            if (this.mAccessTimes == null) {
                this.mAccessTimes = new LongSparseLongArray();
            }
            this.mAccessTimes.put(key, time);
            if (this.mDurations == null) {
                this.mDurations = new LongSparseLongArray();
            }
            this.mDurations.put(key, duration);
        }

        private void updateProxyState(long key, int proxyUid, String proxyPackageName) {
            if (this.mProxyUids == null) {
                this.mProxyUids = new LongSparseLongArray();
            }
            this.mProxyUids.put(key, proxyUid);
            if (this.mProxyPackageNames == null) {
                this.mProxyPackageNames = new LongSparseArray<>();
            }
            this.mProxyPackageNames.put(key, proxyPackageName);
        }

        boolean hasAnyTime() {
            LongSparseLongArray longSparseLongArray;
            LongSparseLongArray longSparseLongArray2 = this.mAccessTimes;
            return (longSparseLongArray2 != null && longSparseLongArray2.size() > 0) || ((longSparseLongArray = this.mRejectTimes) != null && longSparseLongArray.size() > 0);
        }
    }

    final class ModeCallback implements IBinder.DeathRecipient {
        final IAppOpsCallback mCallback;
        final int mCallingPid;
        final int mCallingUid;
        final int mFlags;
        final int mWatchingUid;

        ModeCallback(IAppOpsCallback callback, int watchingUid, int flags, int callingUid, int callingPid) {
            this.mCallback = callback;
            this.mWatchingUid = watchingUid;
            this.mFlags = flags;
            this.mCallingUid = callingUid;
            this.mCallingPid = callingPid;
            try {
                this.mCallback.asBinder().linkToDeath(this, 0);
            } catch (RemoteException e) {
            }
        }

        public boolean isWatchingUid(int uid) {
            int i;
            return uid == -2 || (i = this.mWatchingUid) < 0 || i == uid;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(128);
            sb.append("ModeCallback{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" watchinguid=");
            UserHandle.formatUid(sb, this.mWatchingUid);
            sb.append(" flags=0x");
            sb.append(Integer.toHexString(this.mFlags));
            sb.append(" from uid=");
            UserHandle.formatUid(sb, this.mCallingUid);
            sb.append(" pid=");
            sb.append(this.mCallingPid);
            sb.append('}');
            return sb.toString();
        }

        void unlinkToDeath() {
            this.mCallback.asBinder().unlinkToDeath(this, 0);
        }

        @Override // android.os.IBinder.DeathRecipient
        public void binderDied() {
            AppOpsService.this.stopWatchingMode(this.mCallback);
        }
    }

    final class ActiveCallback implements IBinder.DeathRecipient {
        final IAppOpsActiveCallback mCallback;
        final int mCallingPid;
        final int mCallingUid;
        final int mWatchingUid;

        ActiveCallback(IAppOpsActiveCallback callback, int watchingUid, int callingUid, int callingPid) {
            this.mCallback = callback;
            this.mWatchingUid = watchingUid;
            this.mCallingUid = callingUid;
            this.mCallingPid = callingPid;
            try {
                this.mCallback.asBinder().linkToDeath(this, 0);
            } catch (RemoteException e) {
            }
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(128);
            sb.append("ActiveCallback{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" watchinguid=");
            UserHandle.formatUid(sb, this.mWatchingUid);
            sb.append(" from uid=");
            UserHandle.formatUid(sb, this.mCallingUid);
            sb.append(" pid=");
            sb.append(this.mCallingPid);
            sb.append('}');
            return sb.toString();
        }

        void destroy() {
            this.mCallback.asBinder().unlinkToDeath(this, 0);
        }

        @Override // android.os.IBinder.DeathRecipient
        public void binderDied() {
            AppOpsService.this.stopWatchingActive(this.mCallback);
        }
    }

    final class NotedCallback implements IBinder.DeathRecipient {
        final IAppOpsNotedCallback mCallback;
        final int mCallingPid;
        final int mCallingUid;
        final int mWatchingUid;

        NotedCallback(IAppOpsNotedCallback callback, int watchingUid, int callingUid, int callingPid) {
            this.mCallback = callback;
            this.mWatchingUid = watchingUid;
            this.mCallingUid = callingUid;
            this.mCallingPid = callingPid;
            try {
                this.mCallback.asBinder().linkToDeath(this, 0);
            } catch (RemoteException e) {
            }
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(128);
            sb.append("NotedCallback{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" watchinguid=");
            UserHandle.formatUid(sb, this.mWatchingUid);
            sb.append(" from uid=");
            UserHandle.formatUid(sb, this.mCallingUid);
            sb.append(" pid=");
            sb.append(this.mCallingPid);
            sb.append('}');
            return sb.toString();
        }

        void destroy() {
            this.mCallback.asBinder().unlinkToDeath(this, 0);
        }

        @Override // android.os.IBinder.DeathRecipient
        public void binderDied() {
            AppOpsService.this.stopWatchingNoted(this.mCallback);
        }
    }

    final class ClientState extends Binder implements IBinder.DeathRecipient {
        final IBinder mAppToken;
        final ArrayList<Op> mStartedOps = new ArrayList<>();
        final int mPid = Binder.getCallingPid();

        ClientState(IBinder appToken) {
            this.mAppToken = appToken;
            if (!(appToken instanceof Binder)) {
                try {
                    this.mAppToken.linkToDeath(this, 0);
                } catch (RemoteException e) {
                }
            }
        }

        public String toString() {
            return "ClientState{mAppToken=" + this.mAppToken + ", pid=" + this.mPid + '}';
        }

        @Override // android.os.IBinder.DeathRecipient
        public void binderDied() {
            synchronized (AppOpsService.this) {
                for (int i = this.mStartedOps.size() - 1; i >= 0; i--) {
                    AppOpsService.this.finishOperationLocked(this.mStartedOps.get(i), true);
                }
                AppOpsService.this.mClients.remove(this.mAppToken);
            }
        }
    }

    public AppOpsService(File storagePath, Handler handler) {
        LockGuard.installLock(this, 0);
        this.mFile = new AtomicFile(storagePath, "appops");
        this.mHandler = handler;
        this.mConstants = new Constants(this.mHandler);
        readState();
    }

    public void publish(Context context) {
        this.mContext = context;
        ServiceManager.addService("appops", asBinder());
        LocalServices.addService(AppOpsManagerInternal.class, this.mAppOpsManagerInternal);
    }

    public void systemReady() {
        this.mConstants.startMonitoring(this.mContext.getContentResolver());
        this.mHistoricalRegistry.systemReady(this.mContext.getContentResolver());
        synchronized (this) {
            boolean changed = false;
            for (int i = this.mUidStates.size() - 1; i >= 0; i--) {
                UidState uidState = this.mUidStates.valueAt(i);
                String[] packageNames = getPackagesForUid(uidState.uid);
                if (ArrayUtils.isEmpty(packageNames)) {
                    uidState.clear();
                    this.mUidStates.removeAt(i);
                    changed = true;
                } else {
                    ArrayMap<String, Ops> pkgs = uidState.pkgOps;
                    if (pkgs != null) {
                        Iterator<Ops> it = pkgs.values().iterator();
                        while (it.hasNext()) {
                            Ops ops = it.next();
                            int curUid = -1;
                            try {
                                curUid = AppGlobals.getPackageManager().getPackageUid(ops.packageName, 8192, UserHandle.getUserId(ops.uidState.uid));
                            } catch (RemoteException e) {
                            }
                            if (curUid != ops.uidState.uid) {
                                Slog.i(TAG, "Pruning old package " + ops.packageName + SliceClientPermissions.SliceAuthority.DELIMITER + ops.uidState + ": new uid=" + curUid);
                                it.remove();
                                changed = true;
                            }
                        }
                        if (uidState.isDefault()) {
                            this.mUidStates.removeAt(i);
                        }
                    }
                }
            }
            if (changed) {
                scheduleFastWriteLocked();
            }
        }
        IntentFilter packageSuspendFilter = new IntentFilter();
        packageSuspendFilter.addAction("android.intent.action.PACKAGES_UNSUSPENDED");
        packageSuspendFilter.addAction("android.intent.action.PACKAGES_SUSPENDED");
        this.mContext.registerReceiver(new BroadcastReceiver() { // from class: com.android.server.appop.AppOpsService.2
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                int[] changedUids = intent.getIntArrayExtra("android.intent.extra.changed_uid_list");
                String[] changedPkgs = intent.getStringArrayExtra("android.intent.extra.changed_package_list");
                for (int code : AppOpsService.OPS_RESTRICTED_ON_SUSPEND) {
                    synchronized (AppOpsService.this) {
                        ArraySet<ModeCallback> callbacks = AppOpsService.this.mOpModeWatchers.get(code);
                        if (callbacks != null) {
                            ArraySet<ModeCallback> callbacks2 = new ArraySet<>(callbacks);
                            for (int i2 = 0; i2 < changedUids.length; i2++) {
                                int changedUid = changedUids[i2];
                                String changedPkg = changedPkgs[i2];
                                AppOpsService.this.notifyOpChanged(callbacks2, code, changedUid, changedPkg);
                            }
                        }
                    }
                }
            }
        }, packageSuspendFilter);
        PackageManagerInternal packageManagerInternal = (PackageManagerInternal) LocalServices.getService(PackageManagerInternal.class);
        packageManagerInternal.setExternalSourcesPolicy(new PackageManagerInternal.ExternalSourcesPolicy() { // from class: com.android.server.appop.AppOpsService.3
            public int getPackageTrustedToInstallApps(String packageName, int uid) {
                int appOpMode = AppOpsService.this.checkOperation(66, uid, packageName);
                if (appOpMode != 0) {
                    return appOpMode != 2 ? 2 : 1;
                }
                return 0;
            }
        });
        if (!StorageManager.hasIsolatedStorage()) {
            StorageManagerInternal storageManagerInternal = (StorageManagerInternal) LocalServices.getService(StorageManagerInternal.class);
            storageManagerInternal.addExternalStoragePolicy(new StorageManagerInternal.ExternalStorageMountPolicy() { // from class: com.android.server.appop.AppOpsService.4
                public int getMountMode(int uid, String packageName) {
                    if (Process.isIsolated(uid) || AppOpsService.this.noteOperation(59, uid, packageName) != 0) {
                        return 0;
                    }
                    if (AppOpsService.this.noteOperation(60, uid, packageName) != 0) {
                        return 2;
                    }
                    return 3;
                }

                public boolean hasExternalStorage(int uid, String packageName) {
                    int mountMode = getMountMode(uid, packageName);
                    return mountMode == 2 || mountMode == 3;
                }
            });
        }
    }

    public void packageRemoved(int uid, String packageName) {
        synchronized (this) {
            UidState uidState = this.mUidStates.get(uid);
            if (uidState == null) {
                return;
            }
            Ops ops = null;
            if (uidState.pkgOps != null) {
                ops = uidState.pkgOps.remove(packageName);
            }
            if (ops != null && uidState.pkgOps.isEmpty() && getPackagesForUid(uid).length <= 0) {
                this.mUidStates.remove(uid);
            }
            int clientCount = this.mClients.size();
            for (int i = 0; i < clientCount; i++) {
                ClientState client = this.mClients.valueAt(i);
                if (client.mStartedOps != null) {
                    int opCount = client.mStartedOps.size();
                    for (int j = opCount - 1; j >= 0; j--) {
                        Op op = client.mStartedOps.get(j);
                        if (uid == op.uidState.uid && packageName.equals(op.packageName)) {
                            finishOperationLocked(op, true);
                            client.mStartedOps.remove(j);
                            if (op.startNesting <= 0) {
                                scheduleOpActiveChangedIfNeededLocked(op.op, uid, packageName, false);
                            }
                        }
                    }
                }
            }
            if (ops != null) {
                scheduleFastWriteLocked();
                int opCount2 = ops.size();
                for (int i2 = 0; i2 < opCount2; i2++) {
                    Op op2 = ops.valueAt(i2);
                    if (op2.running) {
                        scheduleOpActiveChangedIfNeededLocked(op2.op, op2.uidState.uid, op2.packageName, false);
                    }
                }
            }
            this.mHistoricalRegistry.clearHistory(uid, packageName);
        }
    }

    public void uidRemoved(int uid) {
        synchronized (this) {
            if (this.mUidStates.indexOfKey(uid) >= 0) {
                this.mUidStates.remove(uid);
                scheduleFastWriteLocked();
            }
        }
    }

    public void updateUidProcState(int uid, int procState) {
        long now;
        long settleTime;
        synchronized (this) {
            UidState uidState = getUidStateLocked(uid, true);
            int newState = PROCESS_STATE_TO_UID_STATE[procState];
            if (uidState != null && uidState.pendingState != newState) {
                int oldPendingState = uidState.pendingState;
                uidState.pendingState = newState;
                if (newState < uidState.state || (newState <= 400 && uidState.state > 400)) {
                    commitUidPendingStateLocked(uidState);
                } else if (uidState.pendingStateCommitTime == 0) {
                    if (uidState.state <= 200) {
                        settleTime = this.mConstants.TOP_STATE_SETTLE_TIME;
                    } else if (uidState.state <= 400) {
                        settleTime = this.mConstants.FG_SERVICE_STATE_SETTLE_TIME;
                    } else {
                        settleTime = this.mConstants.BG_STATE_SETTLE_TIME;
                    }
                    uidState.pendingStateCommitTime = SystemClock.elapsedRealtime() + settleTime;
                }
                if (uidState.startNesting != 0) {
                    long now2 = System.currentTimeMillis();
                    for (int i = uidState.pkgOps.size() - 1; i >= 0; i--) {
                        Ops ops = uidState.pkgOps.valueAt(i);
                        int j = ops.size() - 1;
                        while (j >= 0) {
                            Op op = ops.valueAt(j);
                            if (op.startNesting > 0) {
                                long duration = SystemClock.elapsedRealtime() - op.startRealtime;
                                this.mHistoricalRegistry.increaseOpAccessDuration(op.op, op.uidState.uid, op.packageName, oldPendingState, 1, duration);
                                now = now2;
                                op.finished(now2, duration, oldPendingState, 1);
                                op.startRealtime = now;
                                op.started(now, newState, 1);
                            } else {
                                now = now2;
                            }
                            j--;
                            now2 = now;
                            ops = ops;
                        }
                    }
                }
            }
        }
    }

    public void shutdown() {
        Slog.w(TAG, "Writing app ops before shutdown...");
        boolean doWrite = false;
        synchronized (this) {
            if (this.mWriteScheduled) {
                this.mWriteScheduled = false;
                doWrite = true;
            }
        }
        if (doWrite) {
            writeState();
        }
    }

    private ArrayList<AppOpsManager.OpEntry> collectOps(Ops pkgOps, int[] ops) {
        ArrayList<AppOpsManager.OpEntry> resOps = null;
        long elapsedNow = SystemClock.elapsedRealtime();
        if (ops == null) {
            resOps = new ArrayList<>();
            for (int j = 0; j < pkgOps.size(); j++) {
                resOps.add(getOpEntryForResult(pkgOps.valueAt(j), elapsedNow));
            }
        } else {
            for (int i : ops) {
                Op curOp = pkgOps.get(i);
                if (curOp != null) {
                    if (resOps == null) {
                        resOps = new ArrayList<>();
                    }
                    resOps.add(getOpEntryForResult(curOp, elapsedNow));
                }
            }
        }
        return resOps;
    }

    private ArrayList<AppOpsManager.OpEntry> collectOps(SparseIntArray uidOps, int[] ops) {
        if (uidOps == null) {
            return null;
        }
        ArrayList<AppOpsManager.OpEntry> resOps = null;
        if (ops == null) {
            resOps = new ArrayList<>();
            for (int j = 0; j < uidOps.size(); j++) {
                resOps.add(new AppOpsManager.OpEntry(uidOps.keyAt(j), uidOps.valueAt(j)));
            }
        } else {
            for (int j2 = 0; j2 < ops.length; j2++) {
                int index = uidOps.indexOfKey(ops[j2]);
                if (index >= 0) {
                    if (resOps == null) {
                        resOps = new ArrayList<>();
                    }
                    resOps.add(new AppOpsManager.OpEntry(uidOps.keyAt(j2), uidOps.valueAt(j2)));
                }
            }
        }
        return resOps;
    }

    private static AppOpsManager.OpEntry getOpEntryForResult(Op op, long elapsedNow) {
        if (op.running) {
            op.continuing(elapsedNow - op.startRealtime, op.uidState.state, 1);
        }
        AppOpsManager.OpEntry entry = new AppOpsManager.OpEntry(op.op, op.running, op.mode, op.mAccessTimes != null ? op.mAccessTimes.clone() : null, op.mRejectTimes != null ? op.mRejectTimes.clone() : null, op.mDurations != null ? op.mDurations.clone() : null, op.mProxyUids != null ? op.mProxyUids.clone() : null, op.mProxyPackageNames != null ? op.mProxyPackageNames.clone() : null);
        return entry;
    }

    public List<AppOpsManager.PackageOps> getPackagesForOps(int[] ops) {
        this.mContext.enforcePermission("android.permission.GET_APP_OPS_STATS", Binder.getCallingPid(), Binder.getCallingUid(), null);
        ArrayList<AppOpsManager.PackageOps> res = null;
        synchronized (this) {
            int uidStateCount = this.mUidStates.size();
            for (int i = 0; i < uidStateCount; i++) {
                UidState uidState = this.mUidStates.valueAt(i);
                if (uidState.pkgOps != null && !uidState.pkgOps.isEmpty()) {
                    ArrayMap<String, Ops> packages = uidState.pkgOps;
                    int packageCount = packages.size();
                    for (int j = 0; j < packageCount; j++) {
                        Ops pkgOps = packages.valueAt(j);
                        ArrayList<AppOpsManager.OpEntry> resOps = collectOps(pkgOps, ops);
                        if (resOps != null) {
                            if (res == null) {
                                res = new ArrayList<>();
                            }
                            AppOpsManager.PackageOps resPackage = new AppOpsManager.PackageOps(pkgOps.packageName, pkgOps.uidState.uid, resOps);
                            res.add(resPackage);
                        }
                    }
                }
            }
        }
        return res;
    }

    public List<AppOpsManager.PackageOps> getOpsForPackage(int uid, String packageName, int[] ops) {
        this.mContext.enforcePermission("android.permission.GET_APP_OPS_STATS", Binder.getCallingPid(), Binder.getCallingUid(), null);
        String resolvedPackageName = resolvePackageName(uid, packageName);
        if (resolvedPackageName == null) {
            return Collections.emptyList();
        }
        synchronized (this) {
            Ops pkgOps = getOpsRawLocked(uid, resolvedPackageName, false, false);
            if (pkgOps == null) {
                return null;
            }
            ArrayList<AppOpsManager.OpEntry> resOps = collectOps(pkgOps, ops);
            if (resOps == null) {
                return null;
            }
            ArrayList<AppOpsManager.PackageOps> res = new ArrayList<>();
            AppOpsManager.PackageOps resPackage = new AppOpsManager.PackageOps(pkgOps.packageName, pkgOps.uidState.uid, resOps);
            res.add(resPackage);
            return res;
        }
    }

    public void getHistoricalOps(int uid, String packageName, List<String> opNames, long beginTimeMillis, long endTimeMillis, int flags, RemoteCallback callback) throws Throwable {
        new AppOpsManager.HistoricalOpsRequest.Builder(beginTimeMillis, endTimeMillis).setUid(uid).setPackageName(packageName).setOpNames(opNames).setFlags(flags).build();
        Preconditions.checkNotNull(callback, "callback cannot be null");
        this.mContext.enforcePermission("android.permission.GET_APP_OPS_STATS", Binder.getCallingPid(), Binder.getCallingUid(), "getHistoricalOps");
        String[] opNamesArray = opNames != null ? (String[]) opNames.toArray(new String[opNames.size()]) : null;
        this.mHistoricalRegistry.getHistoricalOps(uid, packageName, opNamesArray, beginTimeMillis, endTimeMillis, flags, callback);
    }

    public void getHistoricalOpsFromDiskRaw(int uid, String packageName, List<String> opNames, long beginTimeMillis, long endTimeMillis, int flags, RemoteCallback callback) {
        new AppOpsManager.HistoricalOpsRequest.Builder(beginTimeMillis, endTimeMillis).setUid(uid).setPackageName(packageName).setOpNames(opNames).setFlags(flags).build();
        Preconditions.checkNotNull(callback, "callback cannot be null");
        this.mContext.enforcePermission("android.permission.MANAGE_APPOPS", Binder.getCallingPid(), Binder.getCallingUid(), "getHistoricalOps");
        String[] opNamesArray = opNames != null ? (String[]) opNames.toArray(new String[opNames.size()]) : null;
        this.mHistoricalRegistry.getHistoricalOpsFromDiskRaw(uid, packageName, opNamesArray, beginTimeMillis, endTimeMillis, flags, callback);
    }

    public void reloadNonHistoricalState() {
        this.mContext.enforcePermission("android.permission.MANAGE_APPOPS", Binder.getCallingPid(), Binder.getCallingUid(), "reloadNonHistoricalState");
        writeState();
        readState();
    }

    public List<AppOpsManager.PackageOps> getUidOps(int uid, int[] ops) {
        this.mContext.enforcePermission("android.permission.GET_APP_OPS_STATS", Binder.getCallingPid(), Binder.getCallingUid(), null);
        synchronized (this) {
            UidState uidState = getUidStateLocked(uid, false);
            if (uidState == null) {
                return null;
            }
            ArrayList<AppOpsManager.OpEntry> resOps = collectOps(uidState.opModes, ops);
            if (resOps == null) {
                return null;
            }
            ArrayList<AppOpsManager.PackageOps> res = new ArrayList<>();
            AppOpsManager.PackageOps resPackage = new AppOpsManager.PackageOps((String) null, uidState.uid, resOps);
            res.add(resPackage);
            return res;
        }
    }

    private void pruneOp(Op op, int uid, String packageName) {
        Ops ops;
        UidState uidState;
        ArrayMap<String, Ops> pkgOps;
        if (!op.hasAnyTime() && (ops = getOpsRawLocked(uid, packageName, false, false)) != null) {
            ops.remove(op.op);
            if (ops.size() <= 0 && (pkgOps = (uidState = ops.uidState).pkgOps) != null) {
                pkgOps.remove(ops.packageName);
                if (pkgOps.isEmpty()) {
                    uidState.pkgOps = null;
                }
                if (uidState.isDefault()) {
                    this.mUidStates.remove(uid);
                }
            }
        }
    }

    private void enforceManageAppOpsModes(int callingPid, int callingUid, int targetUid) {
        if (callingPid == Process.myPid()) {
            return;
        }
        int callingUser = UserHandle.getUserId(callingUid);
        synchronized (this) {
            if (this.mProfileOwners == null || this.mProfileOwners.get(callingUser, -1) != callingUid || targetUid < 0 || callingUser != UserHandle.getUserId(targetUid)) {
                this.mContext.enforcePermission("android.permission.MANAGE_APP_OPS_MODES", Binder.getCallingPid(), Binder.getCallingUid(), null);
            }
        }
    }

    public void setUidMode(int code, int uid, int mode) throws Throwable {
        enforceManageAppOpsModes(Binder.getCallingPid(), Binder.getCallingUid(), uid);
        verifyIncomingOp(code);
        int code2 = AppOpsManager.opToSwitch(code);
        synchronized (this) {
            int defaultMode = AppOpsManager.opToDefaultMode(code2);
            UidState uidState = getUidStateLocked(uid, false);
            String str = null;
            if (uidState == null) {
                if (mode == defaultMode) {
                    return;
                }
                uidState = new UidState(uid);
                uidState.opModes = new SparseIntArray();
                uidState.opModes.put(code2, mode);
                this.mUidStates.put(uid, uidState);
                scheduleWriteLocked();
            } else if (uidState.opModes == null) {
                if (mode != defaultMode) {
                    uidState.opModes = new SparseIntArray();
                    uidState.opModes.put(code2, mode);
                    scheduleWriteLocked();
                }
            } else {
                if (uidState.opModes.indexOfKey(code2) >= 0 && uidState.opModes.get(code2) == mode) {
                    return;
                }
                if (mode == defaultMode) {
                    uidState.opModes.delete(code2);
                    if (uidState.opModes.size() <= 0) {
                        uidState.opModes = null;
                    }
                } else {
                    uidState.opModes.put(code2, mode);
                }
                scheduleWriteLocked();
            }
            uidState.evalForegroundOps(this.mOpModeWatchers);
            String[] uidPackageNames = getPackagesForUid(uid);
            ArrayMap<ModeCallback, ArraySet<String>> callbackSpecs = null;
            synchronized (this) {
                try {
                    ArraySet<ModeCallback> callbacks = this.mOpModeWatchers.get(code2);
                    if (callbacks != null) {
                        int callbackCount = callbacks.size();
                        for (int i = 0; i < callbackCount; i++) {
                            ModeCallback callback = callbacks.valueAt(i);
                            ArraySet<String> changedPackages = new ArraySet<>();
                            Collections.addAll(changedPackages, uidPackageNames);
                            if (callbackSpecs == null) {
                                callbackSpecs = new ArrayMap<>();
                            }
                            callbackSpecs.put(callback, changedPackages);
                        }
                    }
                    ArrayMap<ModeCallback, ArraySet<String>> callbackSpecs2 = callbackSpecs;
                    for (String uidPackageName : uidPackageNames) {
                        try {
                            ArraySet<ModeCallback> callbacks2 = this.mPackageModeWatchers.get(uidPackageName);
                            if (callbacks2 != null) {
                                if (callbackSpecs2 == null) {
                                    callbackSpecs2 = new ArrayMap<>();
                                }
                                int callbackCount2 = callbacks2.size();
                                for (int i2 = 0; i2 < callbackCount2; i2++) {
                                    ModeCallback callback2 = callbacks2.valueAt(i2);
                                    ArraySet<String> changedPackages2 = callbackSpecs2.get(callback2);
                                    if (changedPackages2 == null) {
                                        changedPackages2 = new ArraySet<>();
                                        callbackSpecs2.put(callback2, changedPackages2);
                                    }
                                    changedPackages2.add(uidPackageName);
                                }
                            }
                        } catch (Throwable th) {
                            th = th;
                            throw th;
                        }
                    }
                    if (callbackSpecs2 == null) {
                        notifyOpChangedSync(code2, uid, null, mode);
                        return;
                    }
                    int i3 = 0;
                    while (i3 < callbackSpecs2.size()) {
                        ModeCallback callback3 = callbackSpecs2.keyAt(i3);
                        ArraySet<String> reportedPackageNames = callbackSpecs2.valueAt(i3);
                        if (reportedPackageNames == null) {
                            this.mHandler.sendMessage(PooledLambda.obtainMessage($$Lambda$AppOpsService$FYLTtxqrHmv8Y5UdZ9ybXKsSJhs.INSTANCE, this, callback3, Integer.valueOf(code2), Integer.valueOf(uid), str));
                        } else {
                            int j = 0;
                            for (int reportedPackageCount = reportedPackageNames.size(); j < reportedPackageCount; reportedPackageCount = reportedPackageCount) {
                                String reportedPackageName = reportedPackageNames.valueAt(j);
                                this.mHandler.sendMessage(PooledLambda.obtainMessage($$Lambda$AppOpsService$FYLTtxqrHmv8Y5UdZ9ybXKsSJhs.INSTANCE, this, callback3, Integer.valueOf(code2), Integer.valueOf(uid), reportedPackageName));
                                j++;
                            }
                        }
                        i3++;
                        str = null;
                    }
                    notifyOpChangedSync(code2, uid, null, mode);
                } catch (Throwable th2) {
                    th = th2;
                }
            }
        }
    }

    private void notifyOpChangedSync(int code, int uid, String packageName, int mode) {
        StorageManagerInternal storageManagerInternal = (StorageManagerInternal) LocalServices.getService(StorageManagerInternal.class);
        if (storageManagerInternal != null) {
            storageManagerInternal.onAppOpsChanged(code, uid, packageName, mode);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setAllPkgModesToDefault(int code, int uid) {
        int defaultMode;
        synchronized (this) {
            UidState uidState = getUidStateLocked(uid, false);
            if (uidState == null) {
                return;
            }
            ArrayMap<String, Ops> pkgOps = uidState.pkgOps;
            if (pkgOps == null) {
                return;
            }
            boolean scheduleWrite = false;
            int numPkgs = pkgOps.size();
            for (int pkgNum = 0; pkgNum < numPkgs; pkgNum++) {
                Ops ops = pkgOps.valueAt(pkgNum);
                Op op = ops.get(code);
                if (op != null && op.mode != (defaultMode = AppOpsManager.opToDefaultMode(code))) {
                    op.mode = defaultMode;
                    scheduleWrite = true;
                }
            }
            if (scheduleWrite) {
                scheduleWriteLocked();
            }
        }
    }

    public void setMode(int code, int uid, String packageName, int mode) {
        setMode(code, uid, packageName, mode, true, false);
    }

    private void setMode(int code, int uid, String packageName, int mode, boolean verifyUid, boolean isPrivileged) {
        enforceManageAppOpsModes(Binder.getCallingPid(), Binder.getCallingUid(), uid);
        verifyIncomingOp(code);
        ArraySet<ModeCallback> repCbs = null;
        int code2 = AppOpsManager.opToSwitch(code);
        synchronized (this) {
            UidState uidState = getUidStateLocked(uid, false);
            Op op = getOpLocked(code2, uid, packageName, true, verifyUid, isPrivileged);
            if (op != null && op.mode != mode) {
                op.mode = mode;
                if (uidState != null) {
                    uidState.evalForegroundOps(this.mOpModeWatchers);
                }
                ArraySet<? extends ModeCallback> arraySet = this.mOpModeWatchers.get(code2);
                if (arraySet != null) {
                    if (0 == 0) {
                        repCbs = new ArraySet<>();
                    }
                    repCbs.addAll(arraySet);
                }
                ArraySet<? extends ModeCallback> arraySet2 = this.mPackageModeWatchers.get(packageName);
                if (arraySet2 != null) {
                    if (repCbs == null) {
                        repCbs = new ArraySet<>();
                    }
                    repCbs.addAll(arraySet2);
                }
                if (mode == AppOpsManager.opToDefaultMode(op.op)) {
                    pruneOp(op, uid, packageName);
                }
                scheduleFastWriteLocked();
            }
        }
        if (repCbs != null) {
            this.mHandler.sendMessage(PooledLambda.obtainMessage(new QuintConsumer() { // from class: com.android.server.appop.-$$Lambda$AppOpsService$NDUi03ZZuuR42-RDEIQ0UELKycc
                public final void accept(Object obj, Object obj2, Object obj3, Object obj4, Object obj5) {
                    ((AppOpsService) obj).notifyOpChanged((ArraySet<AppOpsService.ModeCallback>) obj2, ((Integer) obj3).intValue(), ((Integer) obj4).intValue(), (String) obj5);
                }
            }, this, repCbs, Integer.valueOf(code2), Integer.valueOf(uid), packageName));
        }
        notifyOpChangedSync(code2, uid, packageName, mode);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void notifyOpChanged(ArraySet<ModeCallback> callbacks, int code, int uid, String packageName) {
        for (int i = 0; i < callbacks.size(); i++) {
            ModeCallback callback = callbacks.valueAt(i);
            notifyOpChanged(callback, code, uid, packageName);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void notifyOpChanged(ModeCallback callback, int code, int uid, String packageName) {
        if (uid != -2 && callback.mWatchingUid >= 0 && callback.mWatchingUid != uid) {
            return;
        }
        long identity = Binder.clearCallingIdentity();
        try {
            callback.mCallback.opChanged(code, uid, packageName);
        } catch (RemoteException e) {
        } finally {
            Binder.restoreCallingIdentity(identity);
        }
    }

    private static HashMap<ModeCallback, ArrayList<ChangeRec>> addCallbacks(HashMap<ModeCallback, ArrayList<ChangeRec>> callbacks, int op, int uid, String packageName, ArraySet<ModeCallback> cbs) {
        if (cbs == null) {
            return callbacks;
        }
        if (callbacks == null) {
            callbacks = new HashMap<>();
        }
        boolean duplicate = false;
        int N = cbs.size();
        for (int i = 0; i < N; i++) {
            ModeCallback cb = cbs.valueAt(i);
            ArrayList<ChangeRec> reports = callbacks.get(cb);
            if (reports == null) {
                reports = new ArrayList<>();
                callbacks.put(cb, reports);
            } else {
                int reportCount = reports.size();
                for (int j = 0; j < reportCount; j++) {
                    ChangeRec report = reports.get(j);
                    if (report.op == op && report.pkg.equals(packageName)) {
                        duplicate = true;
                        break;
                    }
                }
            }
            if (!duplicate) {
                reports.add(new ChangeRec(op, uid, packageName));
            }
        }
        return callbacks;
    }

    static final class ChangeRec {
        final int op;
        final String pkg;
        final int uid;

        ChangeRec(int _op, int _uid, String _pkg) {
            this.op = _op;
            this.uid = _uid;
            this.pkg = _pkg;
        }
    }

    /* JADX WARN: Bottom block not found for handler: all -> 0x028e */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void resetAllModes(int r23, java.lang.String r24) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 656
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.server.appop.AppOpsService.resetAllModes(int, java.lang.String):void");
    }

    private void evalAllForegroundOpsLocked() {
        for (int uidi = this.mUidStates.size() - 1; uidi >= 0; uidi--) {
            UidState uidState = this.mUidStates.valueAt(uidi);
            if (uidState.foregroundOps != null) {
                uidState.evalForegroundOps(this.mOpModeWatchers);
            }
        }
    }

    public void startWatchingMode(int op, String packageName, IAppOpsCallback callback) {
        startWatchingModeWithFlags(op, packageName, 0, callback);
    }

    public void startWatchingModeWithFlags(int op, String packageName, int flags, IAppOpsCallback callback) throws Throwable {
        int iOpToSwitch;
        int callingUid = Binder.getCallingUid();
        int callingPid = Binder.getCallingPid();
        Preconditions.checkArgumentInRange(op, -1, 90, "Invalid op code: " + op);
        if (callback == null) {
            return;
        }
        synchronized (this) {
            try {
                if (op == -1) {
                    iOpToSwitch = op;
                } else {
                    try {
                        iOpToSwitch = AppOpsManager.opToSwitch(op);
                    } catch (Throwable th) {
                        th = th;
                        throw th;
                    }
                }
                int op2 = iOpToSwitch;
                ModeCallback cb = this.mModeWatchers.get(callback.asBinder());
                if (cb == null) {
                    cb = new ModeCallback(callback, -1, flags, callingUid, callingPid);
                    this.mModeWatchers.put(callback.asBinder(), cb);
                }
                if (op2 != -1) {
                    ArraySet<ModeCallback> cbs = this.mOpModeWatchers.get(op2);
                    if (cbs == null) {
                        cbs = new ArraySet<>();
                        this.mOpModeWatchers.put(op2, cbs);
                    }
                    cbs.add(cb);
                }
                if (packageName != null) {
                    ArraySet<ModeCallback> cbs2 = this.mPackageModeWatchers.get(packageName);
                    if (cbs2 == null) {
                        cbs2 = new ArraySet<>();
                        this.mPackageModeWatchers.put(packageName, cbs2);
                    }
                    cbs2.add(cb);
                }
                evalAllForegroundOpsLocked();
            } catch (Throwable th2) {
                th = th2;
            }
        }
    }

    public void stopWatchingMode(IAppOpsCallback callback) {
        if (callback == null) {
            return;
        }
        synchronized (this) {
            ModeCallback cb = this.mModeWatchers.remove(callback.asBinder());
            if (cb != null) {
                cb.unlinkToDeath();
                for (int i = this.mOpModeWatchers.size() - 1; i >= 0; i--) {
                    ArraySet<ModeCallback> cbs = this.mOpModeWatchers.valueAt(i);
                    cbs.remove(cb);
                    if (cbs.size() <= 0) {
                        this.mOpModeWatchers.removeAt(i);
                    }
                }
                for (int i2 = this.mPackageModeWatchers.size() - 1; i2 >= 0; i2--) {
                    ArraySet<ModeCallback> cbs2 = this.mPackageModeWatchers.valueAt(i2);
                    cbs2.remove(cb);
                    if (cbs2.size() <= 0) {
                        this.mPackageModeWatchers.removeAt(i2);
                    }
                }
            }
            evalAllForegroundOpsLocked();
        }
    }

    public IBinder getToken(IBinder clientToken) {
        ClientState cs;
        synchronized (this) {
            cs = this.mClients.get(clientToken);
            if (cs == null) {
                cs = new ClientState(clientToken);
                this.mClients.put(clientToken, cs);
            }
        }
        return cs;
    }

    public AppOpsManagerInternal.CheckOpsDelegate getAppOpsServiceDelegate() {
        AppOpsManagerInternal.CheckOpsDelegate checkOpsDelegate;
        synchronized (this) {
            checkOpsDelegate = this.mCheckOpsDelegate;
        }
        return checkOpsDelegate;
    }

    public void setAppOpsServiceDelegate(AppOpsManagerInternal.CheckOpsDelegate delegate) {
        synchronized (this) {
            this.mCheckOpsDelegate = delegate;
        }
    }

    public int checkOperationRaw(int code, int uid, String packageName) {
        return checkOperationInternal(code, uid, packageName, true);
    }

    public int checkOperation(int code, int uid, String packageName) {
        return checkOperationInternal(code, uid, packageName, false);
    }

    private int checkOperationInternal(int code, int uid, String packageName, boolean raw) {
        AppOpsManagerInternal.CheckOpsDelegate delegate;
        synchronized (this) {
            delegate = this.mCheckOpsDelegate;
        }
        if (delegate == null) {
            return checkOperationImpl(code, uid, packageName, raw);
        }
        return delegate.checkOperation(code, uid, packageName, raw, new QuadFunction() { // from class: com.android.server.appop.-$$Lambda$AppOpsService$gQy7GOuCV6GbjQtdNhNG6xld8I4
            public final Object apply(Object obj, Object obj2, Object obj3, Object obj4) {
                return Integer.valueOf(this.f$0.checkOperationImpl(((Integer) obj).intValue(), ((Integer) obj2).intValue(), (String) obj3, ((Boolean) obj4).booleanValue()));
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int checkOperationImpl(int code, int uid, String packageName, boolean raw) {
        verifyIncomingUid(uid);
        verifyIncomingOp(code);
        String resolvedPackageName = resolvePackageName(uid, packageName);
        if (resolvedPackageName == null) {
            return 1;
        }
        return checkOperationUnchecked(code, uid, resolvedPackageName, raw);
    }

    private int checkOperationUnchecked(int code, int uid, String packageName, boolean raw) {
        return checkOperationUnchecked(code, uid, packageName, raw, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int checkOperationUnchecked(int code, int uid, String packageName, boolean raw, boolean verify) {
        if (isOpRestrictedDueToSuspend(code, packageName, uid)) {
            return 1;
        }
        synchronized (this) {
            if (verify) {
                checkPackage(uid, packageName);
            }
            if (isOpRestrictedLocked(uid, code, packageName)) {
                return 1;
            }
            int code2 = AppOpsManager.opToSwitch(code);
            UidState uidState = getUidStateLocked(uid, false);
            if (uidState != null && uidState.opModes != null && uidState.opModes.indexOfKey(code2) >= 0) {
                int rawMode = uidState.opModes.get(code2);
                return raw ? rawMode : uidState.evalMode(code2, rawMode);
            }
            Op op = getOpLocked(code2, uid, packageName, false, verify, false);
            if (op == null) {
                return AppOpsManager.opToDefaultMode(code2);
            }
            return raw ? op.mode : op.evalMode();
        }
    }

    public int checkAudioOperation(int code, int usage, int uid, String packageName) {
        AppOpsManagerInternal.CheckOpsDelegate delegate;
        synchronized (this) {
            delegate = this.mCheckOpsDelegate;
        }
        if (delegate == null) {
            return checkAudioOperationImpl(code, usage, uid, packageName);
        }
        return delegate.checkAudioOperation(code, usage, uid, packageName, new QuadFunction() { // from class: com.android.server.appop.-$$Lambda$AppOpsService$mfUWTdGevxEoIUv1cEPEFG0qAaI
            public final Object apply(Object obj, Object obj2, Object obj3, Object obj4) {
                return Integer.valueOf(this.f$0.checkAudioOperationImpl(((Integer) obj).intValue(), ((Integer) obj2).intValue(), ((Integer) obj3).intValue(), (String) obj4));
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int checkAudioOperationImpl(int code, int usage, int uid, String packageName) {
        boolean suspended;
        try {
            suspended = isPackageSuspendedForUser(packageName, uid);
        } catch (IllegalArgumentException e) {
            suspended = false;
        }
        if (suspended) {
            Slog.i(TAG, "Audio disabled for suspended package=" + packageName + " for uid=" + uid);
            return 1;
        }
        synchronized (this) {
            int mode = checkRestrictionLocked(code, usage, uid, packageName);
            return mode != 0 ? mode : checkOperation(code, uid, packageName);
        }
    }

    private boolean isPackageSuspendedForUser(String pkg, int uid) {
        long identity = Binder.clearCallingIdentity();
        try {
            try {
                boolean zIsPackageSuspendedForUser = AppGlobals.getPackageManager().isPackageSuspendedForUser(pkg, UserHandle.getUserId(uid));
                Binder.restoreCallingIdentity(identity);
                return zIsPackageSuspendedForUser;
            } catch (RemoteException e) {
                throw new SecurityException("Could not talk to package manager service");
            }
        } catch (Throwable th) {
            Binder.restoreCallingIdentity(identity);
            throw th;
        }
    }

    private int checkRestrictionLocked(int code, int usage, int uid, String packageName) {
        Restriction r;
        SparseArray<Restriction> usageRestrictions = this.mAudioRestrictions.get(code);
        if (usageRestrictions != null && (r = usageRestrictions.get(usage)) != null && !r.exceptionPackages.contains(packageName)) {
            return r.mode;
        }
        return 0;
    }

    public void setAudioRestriction(int code, int usage, int uid, int mode, String[] exceptionPackages) {
        enforceManageAppOpsModes(Binder.getCallingPid(), Binder.getCallingUid(), uid);
        verifyIncomingUid(uid);
        verifyIncomingOp(code);
        synchronized (this) {
            SparseArray<Restriction> usageRestrictions = this.mAudioRestrictions.get(code);
            if (usageRestrictions == null) {
                usageRestrictions = new SparseArray<>();
                this.mAudioRestrictions.put(code, usageRestrictions);
            }
            usageRestrictions.remove(usage);
            if (mode != 0) {
                Restriction r = new Restriction();
                r.mode = mode;
                if (exceptionPackages != null) {
                    int N = exceptionPackages.length;
                    r.exceptionPackages = new ArraySet<>(N);
                    for (String pkg : exceptionPackages) {
                        if (pkg != null) {
                            r.exceptionPackages.add(pkg.trim());
                        }
                    }
                }
                usageRestrictions.put(usage, r);
            }
        }
        this.mHandler.sendMessage(PooledLambda.obtainMessage($$Lambda$AppOpsService$GUeKjlbzT65s86vaxy5gvOajuhw.INSTANCE, this, Integer.valueOf(code), -2));
    }

    public int checkPackage(int uid, String packageName) {
        Preconditions.checkNotNull(packageName);
        synchronized (this) {
            Ops ops = getOpsRawLocked(uid, packageName, true, true);
            if (ops != null) {
                return 0;
            }
            return 2;
        }
    }

    public int noteProxyOperation(int code, int proxyUid, String proxyPackageName, int proxiedUid, String proxiedPackageName) {
        verifyIncomingUid(proxyUid);
        verifyIncomingOp(code);
        String resolveProxyPackageName = resolvePackageName(proxyUid, proxyPackageName);
        if (resolveProxyPackageName == null) {
            return 1;
        }
        boolean isProxyTrusted = this.mContext.checkPermission("android.permission.UPDATE_APP_OPS_STATS", -1, proxyUid) == 0;
        int proxyFlags = isProxyTrusted ? 2 : 4;
        int proxyMode = noteOperationUnchecked(code, proxyUid, resolveProxyPackageName, -1, null, proxyFlags);
        if (proxyMode == 0 && Binder.getCallingUid() != proxiedUid) {
            String resolveProxiedPackageName = resolvePackageName(proxiedUid, proxiedPackageName);
            if (resolveProxiedPackageName == null) {
                return 1;
            }
            int proxiedFlags = isProxyTrusted ? 8 : 16;
            return noteOperationUnchecked(code, proxiedUid, resolveProxiedPackageName, proxyUid, resolveProxyPackageName, proxiedFlags);
        }
        return proxyMode;
    }

    public int noteOperation(int code, int uid, String packageName) {
        AppOpsManagerInternal.CheckOpsDelegate delegate;
        synchronized (this) {
            delegate = this.mCheckOpsDelegate;
        }
        if (delegate == null) {
            return noteOperationImpl(code, uid, packageName);
        }
        return delegate.noteOperation(code, uid, packageName, new TriFunction() { // from class: com.android.server.appop.-$$Lambda$AppOpsService$hqd76gFlOJ1gAuDYDPVUaSkXjTc
            public final Object apply(Object obj, Object obj2, Object obj3) {
                return Integer.valueOf(this.f$0.noteOperationImpl(((Integer) obj).intValue(), ((Integer) obj2).intValue(), (String) obj3));
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int noteOperationImpl(int code, int uid, String packageName) {
        verifyIncomingUid(uid);
        verifyIncomingOp(code);
        String resolvedPackageName = resolvePackageName(uid, packageName);
        if (resolvedPackageName == null) {
            return 1;
        }
        if (resolvedPackageName.equals(SystemProperties.get("persist.sys.navi.packagename", "com.autonavi.amapauto"))) {
            return 0;
        }
        return noteOperationUnchecked(code, uid, resolvedPackageName, -1, null, 1);
    }

    private int noteOperationUnchecked(int code, int uid, String packageName, int proxyUid, String proxyPackageName, int flags) {
        UidState uidState;
        Op op;
        synchronized (this) {
            Ops ops = getOpsRawLocked(uid, packageName, true, false);
            if (ops == null) {
                scheduleOpNotedIfNeededLocked(code, uid, packageName, 1);
                return 2;
            }
            Op op2 = getOpLocked(ops, code, true);
            if (isOpRestrictedLocked(uid, code, packageName)) {
                scheduleOpNotedIfNeededLocked(code, uid, packageName, 1);
                return 1;
            }
            UidState uidState2 = ops.uidState;
            if (op2.running) {
                AppOpsManager.OpEntry entry = new AppOpsManager.OpEntry(op2.op, op2.running, op2.mode, op2.mAccessTimes, op2.mRejectTimes, op2.mDurations, op2.mProxyUids, op2.mProxyPackageNames);
                Slog.w(TAG, "Noting op not finished: uid " + uid + " pkg " + packageName + " code " + code + " time=" + entry.getLastAccessTime(uidState2.state, uidState2.state, flags) + " duration=" + entry.getLastDuration(uidState2.state, uidState2.state, flags));
            }
            int switchCode = AppOpsManager.opToSwitch(code);
            if (uidState2.opModes != null && uidState2.opModes.indexOfKey(switchCode) >= 0) {
                int uidMode = uidState2.evalMode(code, uidState2.opModes.get(switchCode));
                if (uidMode != 0) {
                    op2.rejected(System.currentTimeMillis(), proxyUid, proxyPackageName, uidState2.state, flags);
                    this.mHistoricalRegistry.incrementOpRejected(code, uid, packageName, uidState2.state, flags);
                    scheduleOpNotedIfNeededLocked(code, uid, packageName, uidMode);
                    return uidMode;
                }
                uidState = uidState2;
                op = op2;
            } else {
                Op switchOp = switchCode != code ? getOpLocked(ops, switchCode, true) : op2;
                int mode = switchOp.evalMode();
                if (switchOp.mode != 0) {
                    op2.rejected(System.currentTimeMillis(), proxyUid, proxyPackageName, uidState2.state, flags);
                    this.mHistoricalRegistry.incrementOpRejected(code, uid, packageName, uidState2.state, flags);
                    scheduleOpNotedIfNeededLocked(code, uid, packageName, mode);
                    return mode;
                }
                uidState = uidState2;
                op = op2;
            }
            op.accessed(System.currentTimeMillis(), proxyUid, proxyPackageName, uidState.state, flags);
            this.mHistoricalRegistry.incrementOpAccessedCount(op.op, uid, packageName, uidState.state, flags);
            scheduleOpNotedIfNeededLocked(code, uid, packageName, 0);
            return 0;
        }
    }

    public void startWatchingActive(int[] ops, IAppOpsActiveCallback callback) {
        SparseArray<ActiveCallback> callbacks;
        int watchedUid = -1;
        int callingUid = Binder.getCallingUid();
        int callingPid = Binder.getCallingPid();
        if (this.mContext.checkCallingOrSelfPermission("android.permission.WATCH_APPOPS") != 0) {
            watchedUid = callingUid;
        }
        if (ops != null) {
            Preconditions.checkArrayElementsInRange(ops, 0, 90, "Invalid op code in: " + Arrays.toString(ops));
        }
        if (callback == null) {
            return;
        }
        synchronized (this) {
            SparseArray<ActiveCallback> callbacks2 = this.mActiveWatchers.get(callback.asBinder());
            if (callbacks2 != null) {
                callbacks = callbacks2;
            } else {
                SparseArray<ActiveCallback> callbacks3 = new SparseArray<>();
                this.mActiveWatchers.put(callback.asBinder(), callbacks3);
                callbacks = callbacks3;
            }
            ActiveCallback activeCallback = new ActiveCallback(callback, watchedUid, callingUid, callingPid);
            for (int op : ops) {
                callbacks.put(op, activeCallback);
            }
        }
    }

    public void stopWatchingActive(IAppOpsActiveCallback callback) {
        if (callback == null) {
            return;
        }
        synchronized (this) {
            SparseArray<ActiveCallback> activeCallbacks = this.mActiveWatchers.remove(callback.asBinder());
            if (activeCallbacks == null) {
                return;
            }
            int callbackCount = activeCallbacks.size();
            for (int i = 0; i < callbackCount; i++) {
                activeCallbacks.valueAt(i).destroy();
            }
        }
    }

    public void startWatchingNoted(int[] ops, IAppOpsNotedCallback callback) {
        SparseArray<NotedCallback> callbacks;
        int watchedUid = -1;
        int callingUid = Binder.getCallingUid();
        int callingPid = Binder.getCallingPid();
        if (this.mContext.checkCallingOrSelfPermission("android.permission.WATCH_APPOPS") != 0) {
            watchedUid = callingUid;
        }
        Preconditions.checkArgument(!ArrayUtils.isEmpty(ops), "Ops cannot be null or empty");
        Preconditions.checkArrayElementsInRange(ops, 0, 90, "Invalid op code in: " + Arrays.toString(ops));
        Preconditions.checkNotNull(callback, "Callback cannot be null");
        synchronized (this) {
            SparseArray<NotedCallback> callbacks2 = this.mNotedWatchers.get(callback.asBinder());
            if (callbacks2 != null) {
                callbacks = callbacks2;
            } else {
                SparseArray<NotedCallback> callbacks3 = new SparseArray<>();
                this.mNotedWatchers.put(callback.asBinder(), callbacks3);
                callbacks = callbacks3;
            }
            NotedCallback notedCallback = new NotedCallback(callback, watchedUid, callingUid, callingPid);
            for (int op : ops) {
                callbacks.put(op, notedCallback);
            }
        }
    }

    public void stopWatchingNoted(IAppOpsNotedCallback callback) {
        Preconditions.checkNotNull(callback, "Callback cannot be null");
        synchronized (this) {
            SparseArray<NotedCallback> notedCallbacks = this.mNotedWatchers.remove(callback.asBinder());
            if (notedCallbacks == null) {
                return;
            }
            int callbackCount = notedCallbacks.size();
            for (int i = 0; i < callbackCount; i++) {
                notedCallbacks.valueAt(i).destroy();
            }
        }
    }

    public int startOperation(IBinder token, int code, int uid, String packageName, boolean startIfModeDefault) throws Throwable {
        UidState uidState;
        verifyIncomingUid(uid);
        verifyIncomingOp(code);
        String resolvedPackageName = resolvePackageName(uid, packageName);
        if (resolvedPackageName == null) {
            return 1;
        }
        ClientState client = (ClientState) token;
        synchronized (this) {
            try {
                try {
                    Ops ops = getOpsRawLocked(uid, resolvedPackageName, true, false);
                    if (ops == null) {
                        return 2;
                    }
                    Op op = getOpLocked(ops, code, true);
                    if (isOpRestrictedLocked(uid, code, resolvedPackageName)) {
                        return 1;
                    }
                    int switchCode = AppOpsManager.opToSwitch(code);
                    UidState uidState2 = ops.uidState;
                    int opCode = op.op;
                    if (uidState2.opModes != null && uidState2.opModes.indexOfKey(switchCode) >= 0) {
                        int uidMode = uidState2.evalMode(code, uidState2.opModes.get(switchCode));
                        if (uidMode != 0 && (!startIfModeDefault || uidMode != 3)) {
                            op.rejected(System.currentTimeMillis(), -1, null, uidState2.state, 1);
                            this.mHistoricalRegistry.incrementOpRejected(opCode, uid, packageName, uidState2.state, 1);
                            return uidMode;
                        }
                    } else {
                        Op switchOp = switchCode != code ? getOpLocked(ops, switchCode, true) : op;
                        int mode = switchOp.evalMode();
                        if (mode == 0 || (startIfModeDefault && mode == 3)) {
                        }
                        op.rejected(System.currentTimeMillis(), -1, null, uidState2.state, 1);
                        this.mHistoricalRegistry.incrementOpRejected(opCode, uid, packageName, uidState2.state, 1);
                        return mode;
                    }
                    if (op.startNesting == 0) {
                        op.startRealtime = SystemClock.elapsedRealtime();
                        uidState = uidState2;
                        op.started(System.currentTimeMillis(), uidState.state, 1);
                        this.mHistoricalRegistry.incrementOpAccessedCount(opCode, uid, packageName, uidState.state, 1);
                        scheduleOpActiveChangedIfNeededLocked(code, uid, packageName, true);
                    } else {
                        uidState = 
                        /*  JADX ERROR: Method code generation error
                            jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x00fd: MOVE (r15v3 'uidState' com.android.server.appop.AppOpsService$UidState) = (r8v0 com.android.server.appop.AppOpsService$UidState) in method: com.android.server.appop.AppOpsService.startOperation(android.os.IBinder, int, int, java.lang.String, boolean):int, file: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex
                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:310)
                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:273)
                            	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:94)
                            	at jadx.core.dex.nodes.IBlock.generate(IBlock.java:15)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:140)
                            	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                            	at jadx.core.codegen.RegionGen.makeTryCatch(RegionGen.java:320)
                            	at jadx.core.dex.regions.TryCatchRegion.generate(TryCatchRegion.java:85)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                            	at jadx.core.codegen.RegionGen.makeTryCatch(RegionGen.java:320)
                            	at jadx.core.dex.regions.TryCatchRegion.generate(TryCatchRegion.java:85)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                            	at jadx.core.codegen.RegionGen.makeSynchronizedRegion(RegionGen.java:240)
                            	at jadx.core.dex.regions.SynchronizedRegion.generate(SynchronizedRegion.java:44)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:291)
                            	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:270)
                            	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:420)
                            	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:345)
                            	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:299)
                            	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
                            	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
                            	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                            	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
                            	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
                            	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
                            	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
                            	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
                            	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
                            	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
                            	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
                            	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:295)
                            	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:284)
                            	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:268)
                            	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:160)
                            	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:104)
                            	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
                            	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
                            	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
                            	at jadx.core.ProcessClass.process(ProcessClass.java:89)
                            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
                            	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
                            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
                            	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
                            Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r8v0 com.android.server.appop.AppOpsService$UidState
                            	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
                            */
                        /*
                            Method dump skipped, instruction units count: 284
                            To view this dump change 'Code comments level' option to 'DEBUG'
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.android.server.appop.AppOpsService.startOperation(android.os.IBinder, int, int, java.lang.String, boolean):int");
                    }

                    public void finishOperation(IBinder token, int code, int uid, String packageName) {
                        verifyIncomingUid(uid);
                        verifyIncomingOp(code);
                        String resolvedPackageName = resolvePackageName(uid, packageName);
                        if (resolvedPackageName == null || !(token instanceof ClientState)) {
                            return;
                        }
                        ClientState client = (ClientState) token;
                        synchronized (this) {
                            Op op = getOpLocked(code, uid, resolvedPackageName, true, true, false);
                            if (op == null) {
                                return;
                            }
                            if (!client.mStartedOps.remove(op)) {
                                long identity = Binder.clearCallingIdentity();
                                try {
                                    if (((PackageManagerInternal) LocalServices.getService(PackageManagerInternal.class)).getPackageUid(resolvedPackageName, 0, UserHandle.getUserId(uid)) < 0) {
                                        Slog.i(TAG, "Finishing op=" + AppOpsManager.opToName(code) + " for non-existing package=" + resolvedPackageName + " in uid=" + uid);
                                        Binder.restoreCallingIdentity(identity);
                                        return;
                                    }
                                    Binder.restoreCallingIdentity(identity);
                                    Slog.wtf(TAG, "Operation not started: uid=" + op.uidState.uid + " pkg=" + op.packageName + " op=" + AppOpsManager.opToName(op.op));
                                    return;
                                } catch (Throwable th) {
                                    Binder.restoreCallingIdentity(identity);
                                    throw th;
                                }
                            }
                            finishOperationLocked(op, false);
                            if (op.startNesting <= 0) {
                                scheduleOpActiveChangedIfNeededLocked(code, uid, packageName, false);
                            }
                        }
                    }

                    private void scheduleOpActiveChangedIfNeededLocked(int code, int uid, String packageName, boolean active) {
                        ArraySet<ActiveCallback> dispatchedCallbacks = null;
                        int callbackListCount = this.mActiveWatchers.size();
                        for (int i = 0; i < callbackListCount; i++) {
                            SparseArray<ActiveCallback> callbacks = this.mActiveWatchers.valueAt(i);
                            ActiveCallback callback = callbacks.get(code);
                            if (callback != null && (callback.mWatchingUid < 0 || callback.mWatchingUid == uid)) {
                                if (dispatchedCallbacks == null) {
                                    dispatchedCallbacks = new ArraySet<>();
                                }
                                dispatchedCallbacks.add(callback);
                            }
                        }
                        if (dispatchedCallbacks == null) {
                            return;
                        }
                        this.mHandler.sendMessage(PooledLambda.obtainMessage(new HexConsumer() { // from class: com.android.server.appop.-$$Lambda$AppOpsService$ac4Ra3Yhj0OQzvkaL2dLbsuLAmQ
                            public final void accept(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, Object obj6) {
                                ((AppOpsService) obj).notifyOpActiveChanged((ArraySet) obj2, ((Integer) obj3).intValue(), ((Integer) obj4).intValue(), (String) obj5, ((Boolean) obj6).booleanValue());
                            }
                        }, this, dispatchedCallbacks, Integer.valueOf(code), Integer.valueOf(uid), packageName, Boolean.valueOf(active)));
                    }

                    /* JADX INFO: Access modifiers changed from: private */
                    public void notifyOpActiveChanged(ArraySet<ActiveCallback> callbacks, int code, int uid, String packageName, boolean active) {
                        long identity = Binder.clearCallingIdentity();
                        try {
                            int callbackCount = callbacks.size();
                            for (int i = 0; i < callbackCount; i++) {
                                ActiveCallback callback = callbacks.valueAt(i);
                                try {
                                    callback.mCallback.opActiveChanged(code, uid, packageName, active);
                                } catch (RemoteException e) {
                                }
                            }
                            Binder.restoreCallingIdentity(identity);
                        } catch (Throwable th) {
                            Binder.restoreCallingIdentity(identity);
                            throw th;
                        }
                    }

                    private void scheduleOpNotedIfNeededLocked(int code, int uid, String packageName, int result) {
                        ArraySet<NotedCallback> dispatchedCallbacks = null;
                        int callbackListCount = this.mNotedWatchers.size();
                        for (int i = 0; i < callbackListCount; i++) {
                            SparseArray<NotedCallback> callbacks = this.mNotedWatchers.valueAt(i);
                            NotedCallback callback = callbacks.get(code);
                            if (callback != null && (callback.mWatchingUid < 0 || callback.mWatchingUid == uid)) {
                                if (dispatchedCallbacks == null) {
                                    dispatchedCallbacks = new ArraySet<>();
                                }
                                dispatchedCallbacks.add(callback);
                            }
                        }
                        if (dispatchedCallbacks == null) {
                            return;
                        }
                        this.mHandler.sendMessage(PooledLambda.obtainMessage(new HexConsumer() { // from class: com.android.server.appop.-$$Lambda$AppOpsService$AfBLuTvVESlqN91IyRX84hMV5nE
                            public final void accept(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, Object obj6) {
                                ((AppOpsService) obj).notifyOpChecked((ArraySet) obj2, ((Integer) obj3).intValue(), ((Integer) obj4).intValue(), (String) obj5, ((Integer) obj6).intValue());
                            }
                        }, this, dispatchedCallbacks, Integer.valueOf(code), Integer.valueOf(uid), packageName, Integer.valueOf(result)));
                    }

                    /* JADX INFO: Access modifiers changed from: private */
                    public void notifyOpChecked(ArraySet<NotedCallback> callbacks, int code, int uid, String packageName, int result) {
                        long identity = Binder.clearCallingIdentity();
                        try {
                            int callbackCount = callbacks.size();
                            for (int i = 0; i < callbackCount; i++) {
                                NotedCallback callback = callbacks.valueAt(i);
                                try {
                                    callback.mCallback.opNoted(code, uid, packageName, result);
                                } catch (RemoteException e) {
                                }
                            }
                            Binder.restoreCallingIdentity(identity);
                        } catch (Throwable th) {
                            Binder.restoreCallingIdentity(identity);
                            throw th;
                        }
                    }

                    public int permissionToOpCode(String permission) {
                        if (permission == null) {
                            return -1;
                        }
                        return AppOpsManager.permissionToOpCode(permission);
                    }

                    void finishOperationLocked(Op op, boolean finishNested) {
                        int opCode = op.op;
                        int uid = op.uidState.uid;
                        if (op.startNesting > 1 && !finishNested) {
                            op.startNesting--;
                            op.uidState.startNesting--;
                            return;
                        }
                        if (op.startNesting == 1 || finishNested) {
                            long duration = SystemClock.elapsedRealtime() - op.startRealtime;
                            op.finished(System.currentTimeMillis(), duration, op.uidState.state, 1);
                            this.mHistoricalRegistry.increaseOpAccessDuration(opCode, uid, op.packageName, op.uidState.state, 1, duration);
                        } else {
                            AppOpsManager.OpEntry entry = new AppOpsManager.OpEntry(op.op, op.running, op.mode, op.mAccessTimes, op.mRejectTimes, op.mDurations, op.mProxyUids, op.mProxyPackageNames);
                            Slog.w(TAG, "Finishing op nesting under-run: uid " + uid + " pkg " + op.packageName + " code " + opCode + " time=" + entry.getLastAccessTime(31) + " duration=" + entry.getLastDuration(100, 700, 31) + " nesting=" + op.startNesting);
                        }
                        if (op.startNesting >= 1) {
                            op.uidState.startNesting -= op.startNesting;
                        }
                        op.startNesting = 0;
                    }

                    private void verifyIncomingUid(int uid) {
                        if (uid == Binder.getCallingUid() || Binder.getCallingPid() == Process.myPid()) {
                            return;
                        }
                        this.mContext.enforcePermission("android.permission.UPDATE_APP_OPS_STATS", Binder.getCallingPid(), Binder.getCallingUid(), null);
                    }

                    private void verifyIncomingOp(int op) {
                        if (op >= 0 && op < 91) {
                            return;
                        }
                        throw new IllegalArgumentException("Bad operation #" + op);
                    }

                    private UidState getUidStateLocked(int uid, boolean edit) {
                        UidState uidState = this.mUidStates.get(uid);
                        if (uidState == null) {
                            if (!edit) {
                                return null;
                            }
                            UidState uidState2 = new UidState(uid);
                            this.mUidStates.put(uid, uidState2);
                            return uidState2;
                        }
                        if (uidState.pendingStateCommitTime == 0) {
                            return uidState;
                        }
                        if (uidState.pendingStateCommitTime < this.mLastRealtime) {
                            commitUidPendingStateLocked(uidState);
                            return uidState;
                        }
                        this.mLastRealtime = SystemClock.elapsedRealtime();
                        if (uidState.pendingStateCommitTime < this.mLastRealtime) {
                            commitUidPendingStateLocked(uidState);
                            return uidState;
                        }
                        return uidState;
                    }

                    private void commitUidPendingStateLocked(UidState uidState) {
                        ArraySet<ModeCallback> callbacks;
                        int i;
                        if (uidState.hasForegroundWatchers) {
                            int i2 = 1;
                            int fgi = uidState.foregroundOps.size() - 1;
                            while (fgi >= 0) {
                                if (uidState.foregroundOps.valueAt(fgi)) {
                                    int code = uidState.foregroundOps.keyAt(fgi);
                                    long firstUnrestrictedUidState = AppOpsManager.resolveFirstUnrestrictedUidState(code);
                                    if ((((long) uidState.state) <= firstUnrestrictedUidState ? i2 : 0) != (((long) uidState.pendingState) <= firstUnrestrictedUidState ? i2 : 0) && (callbacks = this.mOpModeWatchers.get(code)) != null) {
                                        int cbi = callbacks.size() - i2;
                                        while (cbi >= 0) {
                                            ModeCallback callback = callbacks.valueAt(cbi);
                                            if ((callback.mFlags & i2) != 0 && callback.isWatchingUid(uidState.uid)) {
                                                int i3 = 4;
                                                int i4 = (uidState.opModes == null || uidState.opModes.indexOfKey(code) < 0 || uidState.opModes.get(code) != 4) ? 0 : i2;
                                                if (uidState.pkgOps != null) {
                                                    int pkgi = uidState.pkgOps.size() - i2;
                                                    while (pkgi >= 0) {
                                                        Op op = uidState.pkgOps.valueAt(pkgi).get(code);
                                                        if (op == null) {
                                                            i = i3;
                                                        } else if (i4 != 0 || op.mode == i3) {
                                                            i = 4;
                                                            this.mHandler.sendMessage(PooledLambda.obtainMessage($$Lambda$AppOpsService$FYLTtxqrHmv8Y5UdZ9ybXKsSJhs.INSTANCE, this, callback, Integer.valueOf(code), Integer.valueOf(uidState.uid), uidState.pkgOps.keyAt(pkgi)));
                                                        } else {
                                                            i = i3;
                                                        }
                                                        pkgi--;
                                                        cbi = cbi;
                                                        i3 = i;
                                                        callbacks = callbacks;
                                                        callback = callback;
                                                    }
                                                }
                                            }
                                            cbi--;
                                            callbacks = callbacks;
                                            i2 = 1;
                                        }
                                    }
                                }
                                fgi--;
                                i2 = 1;
                            }
                        }
                        uidState.state = uidState.pendingState;
                        uidState.pendingStateCommitTime = 0L;
                    }

                    private Ops getOpsRawLocked(int uid, String packageName, boolean edit, boolean uidMismatchExpected) {
                        UidState uidState = getUidStateLocked(uid, edit);
                        if (uidState == null) {
                            return null;
                        }
                        if (uidState.pkgOps == null) {
                            if (!edit) {
                                return null;
                            }
                            uidState.pkgOps = new ArrayMap<>();
                        }
                        Ops ops = uidState.pkgOps.get(packageName);
                        if (ops != null) {
                            return ops;
                        }
                        if (!edit) {
                            return null;
                        }
                        boolean isPrivileged = false;
                        if (uid != 0) {
                            long ident = Binder.clearCallingIdentity();
                            int pkgUid = -1;
                            try {
                                try {
                                    ApplicationInfo appInfo = ActivityThread.getPackageManager().getApplicationInfo(packageName, 786432, UserHandle.getUserId(uid));
                                    if (appInfo != null) {
                                        pkgUid = appInfo.uid;
                                        isPrivileged = (appInfo.privateFlags & 8) != 0;
                                    } else {
                                        pkgUid = resolveUid(packageName);
                                        if (pkgUid >= 0) {
                                            isPrivileged = false;
                                        }
                                    }
                                } catch (RemoteException e) {
                                    Slog.w(TAG, "Could not contact PackageManager", e);
                                }
                                if (pkgUid != uid) {
                                    if (!uidMismatchExpected) {
                                        RuntimeException ex = new RuntimeException("here");
                                        ex.fillInStackTrace();
                                        Slog.w(TAG, "Bad call: specified package " + packageName + " under uid " + uid + " but it is really " + pkgUid, ex);
                                    }
                                    Binder.restoreCallingIdentity(ident);
                                    return null;
                                }
                                Binder.restoreCallingIdentity(ident);
                            } catch (Throwable th) {
                                Binder.restoreCallingIdentity(ident);
                                throw th;
                            }
                        }
                        Ops ops2 = new Ops(packageName, uidState, isPrivileged);
                        uidState.pkgOps.put(packageName, ops2);
                        return ops2;
                    }

                    private Ops getOpsRawNoVerifyLocked(int uid, String packageName, boolean edit, boolean isPrivileged) {
                        UidState uidState = getUidStateLocked(uid, edit);
                        if (uidState == null) {
                            return null;
                        }
                        if (uidState.pkgOps == null) {
                            if (!edit) {
                                return null;
                            }
                            uidState.pkgOps = new ArrayMap<>();
                        }
                        Ops ops = uidState.pkgOps.get(packageName);
                        if (ops == null) {
                            if (!edit) {
                                return null;
                            }
                            Ops ops2 = new Ops(packageName, uidState, isPrivileged);
                            uidState.pkgOps.put(packageName, ops2);
                            return ops2;
                        }
                        return ops;
                    }

                    private void scheduleWriteLocked() {
                        if (!this.mWriteScheduled) {
                            this.mWriteScheduled = true;
                            this.mHandler.postDelayed(this.mWriteRunner, 1800000L);
                        }
                    }

                    private void scheduleFastWriteLocked() {
                        if (!this.mFastWriteScheduled) {
                            this.mWriteScheduled = true;
                            this.mFastWriteScheduled = true;
                            this.mHandler.removeCallbacks(this.mWriteRunner);
                            this.mHandler.postDelayed(this.mWriteRunner, JobStatus.DEFAULT_TRIGGER_UPDATE_DELAY);
                        }
                    }

                    private Op getOpLocked(int code, int uid, String packageName, boolean edit, boolean verifyUid, boolean isPrivileged) {
                        Ops ops;
                        if (verifyUid) {
                            ops = getOpsRawLocked(uid, packageName, edit, false);
                        } else {
                            ops = getOpsRawNoVerifyLocked(uid, packageName, edit, isPrivileged);
                        }
                        if (ops == null) {
                            return null;
                        }
                        return getOpLocked(ops, code, edit);
                    }

                    private Op getOpLocked(Ops ops, int code, boolean edit) {
                        Op op = ops.get(code);
                        if (op == null) {
                            if (!edit) {
                                return null;
                            }
                            op = new Op(ops.uidState, ops.packageName, code);
                            ops.put(code, op);
                        }
                        if (edit) {
                            scheduleWriteLocked();
                        }
                        return op;
                    }

                    private boolean isOpRestrictedDueToSuspend(int code, String packageName, int uid) {
                        if (!ArrayUtils.contains(OPS_RESTRICTED_ON_SUSPEND, code)) {
                            return false;
                        }
                        PackageManagerInternal pmi = (PackageManagerInternal) LocalServices.getService(PackageManagerInternal.class);
                        return pmi.isPackageSuspended(packageName, UserHandle.getUserId(uid));
                    }

                    private boolean isOpRestrictedLocked(int uid, int code, String packageName) {
                        int userHandle = UserHandle.getUserId(uid);
                        int restrictionSetCount = this.mOpUserRestrictions.size();
                        for (int i = 0; i < restrictionSetCount; i++) {
                            ClientRestrictionState restrictionState = this.mOpUserRestrictions.valueAt(i);
                            if (restrictionState.hasRestriction(code, packageName, userHandle)) {
                                if (AppOpsManager.opAllowSystemBypassRestriction(code)) {
                                    synchronized (this) {
                                        Ops ops = getOpsRawLocked(uid, packageName, true, false);
                                        if (ops != null && ops.isPrivileged) {
                                            return false;
                                        }
                                    }
                                }
                                return true;
                            }
                        }
                        return false;
                    }

                    void readState() {
                        int type;
                        int oldVersion = -1;
                        synchronized (this.mFile) {
                            synchronized (this) {
                                try {
                                    try {
                                        FileInputStream stream = this.mFile.openRead();
                                        try {
                                            this.mUidStates.clear();
                                            try {
                                                try {
                                                    try {
                                                        try {
                                                            try {
                                                                XmlPullParser parser = Xml.newPullParser();
                                                                parser.setInput(stream, StandardCharsets.UTF_8.name());
                                                                do {
                                                                    type = parser.next();
                                                                    if (type == 2) {
                                                                        break;
                                                                    }
                                                                } while (type != 1);
                                                                if (type != 2) {
                                                                    throw new IllegalStateException("no start tag found");
                                                                }
                                                                String versionString = parser.getAttributeValue(null, "v");
                                                                oldVersion = versionString != null ? Integer.parseInt(versionString) : -1;
                                                                int outerDepth = parser.getDepth();
                                                                while (true) {
                                                                    int type2 = parser.next();
                                                                    if (type2 == 1 || (type2 == 3 && parser.getDepth() <= outerDepth)) {
                                                                        break;
                                                                    }
                                                                    if (type2 != 3 && type2 != 4) {
                                                                        String tagName = parser.getName();
                                                                        if (tagName.equals("pkg")) {
                                                                            readPackage(parser);
                                                                        } else if (tagName.equals(WatchlistLoggingHandler.WatchlistEventKeys.UID)) {
                                                                            readUidOps(parser);
                                                                        } else {
                                                                            Slog.w(TAG, "Unknown element under <app-ops>: " + parser.getName());
                                                                            XmlUtils.skipCurrentTag(parser);
                                                                        }
                                                                    }
                                                                }
                                                                if (1 == 0) {
                                                                    this.mUidStates.clear();
                                                                }
                                                                stream.close();
                                                            } catch (NumberFormatException e) {
                                                                Slog.w(TAG, "Failed parsing " + e);
                                                                if (0 == 0) {
                                                                    this.mUidStates.clear();
                                                                }
                                                                stream.close();
                                                            }
                                                        } catch (IndexOutOfBoundsException e2) {
                                                            Slog.w(TAG, "Failed parsing " + e2);
                                                            if (0 == 0) {
                                                                this.mUidStates.clear();
                                                            }
                                                            stream.close();
                                                        }
                                                    } catch (Throwable th) {
                                                        if (0 == 0) {
                                                            this.mUidStates.clear();
                                                        }
                                                        try {
                                                            stream.close();
                                                        } catch (IOException e3) {
                                                        }
                                                        throw th;
                                                    }
                                                } catch (IOException e4) {
                                                    Slog.w(TAG, "Failed parsing " + e4);
                                                    if (0 == 0) {
                                                        this.mUidStates.clear();
                                                    }
                                                    stream.close();
                                                } catch (NullPointerException e5) {
                                                    Slog.w(TAG, "Failed parsing " + e5);
                                                    if (0 == 0) {
                                                        this.mUidStates.clear();
                                                    }
                                                    stream.close();
                                                }
                                            } catch (IllegalStateException e6) {
                                                Slog.w(TAG, "Failed parsing " + e6);
                                                if (0 == 0) {
                                                    this.mUidStates.clear();
                                                }
                                                stream.close();
                                            } catch (XmlPullParserException e7) {
                                                Slog.w(TAG, "Failed parsing " + e7);
                                                if (0 == 0) {
                                                    this.mUidStates.clear();
                                                }
                                                stream.close();
                                            }
                                        } catch (IOException e8) {
                                        }
                                    } catch (FileNotFoundException e9) {
                                        Slog.i(TAG, "No existing app ops " + this.mFile.getBaseFile() + "; starting empty");
                                        return;
                                    }
                                } catch (Throwable th2) {
                                    throw th2;
                                }
                            }
                        }
                        synchronized (this) {
                            upgradeLocked(oldVersion);
                        }
                    }

                    private void upgradeRunAnyInBackgroundLocked() {
                        Op op;
                        int idx;
                        for (int i = 0; i < this.mUidStates.size(); i++) {
                            UidState uidState = this.mUidStates.valueAt(i);
                            if (uidState != null) {
                                if (uidState.opModes != null && (idx = uidState.opModes.indexOfKey(63)) >= 0) {
                                    uidState.opModes.put(70, uidState.opModes.valueAt(idx));
                                }
                                if (uidState.pkgOps != null) {
                                    boolean changed = false;
                                    for (int j = 0; j < uidState.pkgOps.size(); j++) {
                                        Ops ops = uidState.pkgOps.valueAt(j);
                                        if (ops != null && (op = ops.get(63)) != null && op.mode != AppOpsManager.opToDefaultMode(op.op)) {
                                            Op copy = new Op(op.uidState, op.packageName, 70);
                                            copy.mode = op.mode;
                                            ops.put(70, copy);
                                            changed = true;
                                        }
                                    }
                                    if (changed) {
                                        uidState.evalForegroundOps(this.mOpModeWatchers);
                                    }
                                }
                            }
                        }
                    }

                    private void upgradeLocked(int oldVersion) {
                        if (oldVersion >= 1) {
                            return;
                        }
                        Slog.d(TAG, "Upgrading app-ops xml from version " + oldVersion + " to 1");
                        if (oldVersion == -1) {
                            upgradeRunAnyInBackgroundLocked();
                        }
                        scheduleFastWriteLocked();
                    }

                    private void readUidOps(XmlPullParser parser) throws XmlPullParserException, IOException, NumberFormatException {
                        int uid = Integer.parseInt(parser.getAttributeValue(null, "n"));
                        int outerDepth = parser.getDepth();
                        while (true) {
                            int type = parser.next();
                            if (type != 1) {
                                if (type != 3 || parser.getDepth() > outerDepth) {
                                    if (type != 3 && type != 4) {
                                        String tagName = parser.getName();
                                        if (tagName.equals("op")) {
                                            int code = Integer.parseInt(parser.getAttributeValue(null, "n"));
                                            int mode = Integer.parseInt(parser.getAttributeValue(null, "m"));
                                            UidState uidState = getUidStateLocked(uid, true);
                                            if (uidState.opModes == null) {
                                                uidState.opModes = new SparseIntArray();
                                            }
                                            uidState.opModes.put(code, mode);
                                        } else {
                                            Slog.w(TAG, "Unknown element under <uid-ops>: " + parser.getName());
                                            XmlUtils.skipCurrentTag(parser);
                                        }
                                    }
                                } else {
                                    return;
                                }
                            } else {
                                return;
                            }
                        }
                    }

                    private void readPackage(XmlPullParser parser) throws XmlPullParserException, IOException, NumberFormatException {
                        String pkgName = parser.getAttributeValue(null, "n");
                        int outerDepth = parser.getDepth();
                        while (true) {
                            int type = parser.next();
                            if (type != 1) {
                                if (type != 3 || parser.getDepth() > outerDepth) {
                                    if (type != 3 && type != 4) {
                                        String tagName = parser.getName();
                                        if (tagName.equals(WatchlistLoggingHandler.WatchlistEventKeys.UID)) {
                                            readUid(parser, pkgName);
                                        } else {
                                            Slog.w(TAG, "Unknown element under <pkg>: " + parser.getName());
                                            XmlUtils.skipCurrentTag(parser);
                                        }
                                    }
                                } else {
                                    return;
                                }
                            } else {
                                return;
                            }
                        }
                    }

                    private void readUid(XmlPullParser parser, String pkgName) throws XmlPullParserException, IOException, NumberFormatException {
                        int uid = Integer.parseInt(parser.getAttributeValue(null, "n"));
                        UidState uidState = getUidStateLocked(uid, true);
                        String isPrivilegedString = parser.getAttributeValue(null, "p");
                        boolean isPrivileged = false;
                        if (isPrivilegedString == null) {
                            try {
                                IPackageManager packageManager = ActivityThread.getPackageManager();
                                if (packageManager != null) {
                                    ApplicationInfo appInfo = ActivityThread.getPackageManager().getApplicationInfo(pkgName, 0, UserHandle.getUserId(uid));
                                    if (appInfo != null) {
                                        isPrivileged = (appInfo.privateFlags & 8) != 0;
                                    }
                                } else {
                                    return;
                                }
                            } catch (RemoteException e) {
                                Slog.w(TAG, "Could not contact PackageManager", e);
                            }
                        } else {
                            isPrivileged = Boolean.parseBoolean(isPrivilegedString);
                        }
                        int outerDepth = parser.getDepth();
                        while (true) {
                            int type = parser.next();
                            if (type == 1 || (type == 3 && parser.getDepth() <= outerDepth)) {
                                break;
                            }
                            if (type != 3 && type != 4) {
                                String tagName = parser.getName();
                                if (tagName.equals("op")) {
                                    readOp(parser, uidState, pkgName, isPrivileged);
                                } else {
                                    Slog.w(TAG, "Unknown element under <pkg>: " + parser.getName());
                                    XmlUtils.skipCurrentTag(parser);
                                }
                            }
                        }
                        uidState.evalForegroundOps(this.mOpModeWatchers);
                    }

                    private void readOp(XmlPullParser parser, UidState uidState, String pkgName, boolean isPrivileged) throws XmlPullParserException, IOException, NumberFormatException {
                        Op op = new Op(uidState, pkgName, Integer.parseInt(parser.getAttributeValue(null, "n")));
                        int mode = XmlUtils.readIntAttribute(parser, "m", AppOpsManager.opToDefaultMode(op.op));
                        op.mode = mode;
                        int outerDepth = parser.getDepth();
                        while (true) {
                            int type = parser.next();
                            if (type == 1 || (type == 3 && parser.getDepth() <= outerDepth)) {
                                break;
                            }
                            if (type != 3 && type != 4) {
                                String tagName = parser.getName();
                                if (tagName.equals("st")) {
                                    long key = XmlUtils.readLongAttribute(parser, "n");
                                    int flags = AppOpsManager.extractFlagsFromKey(key);
                                    int state = AppOpsManager.extractUidStateFromKey(key);
                                    long accessTime = XmlUtils.readLongAttribute(parser, "t", 0L);
                                    long rejectTime = XmlUtils.readLongAttribute(parser, "r", 0L);
                                    long accessDuration = XmlUtils.readLongAttribute(parser, "d", 0L);
                                    String proxyPkg = XmlUtils.readStringAttribute(parser, "pp");
                                    int proxyUid = XmlUtils.readIntAttribute(parser, "pu", 0);
                                    if (accessTime > 0) {
                                        op.accessed(accessTime, proxyUid, proxyPkg, state, flags);
                                    }
                                    if (rejectTime > r11) {
                                        op.rejected(rejectTime, proxyUid, proxyPkg, state, flags);
                                    }
                                    if (accessDuration > 0) {
                                        op.running(accessTime, accessDuration, state, flags);
                                    }
                                } else {
                                    Slog.w(TAG, "Unknown element under <op>: " + parser.getName());
                                    XmlUtils.skipCurrentTag(parser);
                                }
                            }
                        }
                        if (uidState.pkgOps == null) {
                            uidState.pkgOps = new ArrayMap<>();
                        }
                        Ops ops = uidState.pkgOps.get(pkgName);
                        if (ops == null) {
                            ops = new Ops(pkgName, uidState, isPrivileged);
                            uidState.pkgOps.put(pkgName, ops);
                        }
                        ops.put(op.op, op);
                    }

                    /* JADX WARN: Bottom block not found for handler: all -> 0x029a */
                    /* JADX WARN: Multi-variable type inference failed */
                    /* JADX WARN: Type inference failed for: r10v6, types: [java.util.List] */
                    /* JADX WARN: Type inference failed for: r11v12 */
                    /* JADX WARN: Type inference failed for: r11v4 */
                    /* JADX WARN: Type inference failed for: r11v5, types: [int] */
                    /*
                        Code decompiled incorrectly, please refer to instructions dump.
                        To view partially-correct code enable 'Show inconsistent code' option in preferences
                    */
                    void writeState() {
                        /*
                            Method dump skipped, instruction units count: 714
                            To view this dump change 'Code comments level' option to 'DEBUG'
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.android.server.appop.AppOpsService.writeState():void");
                    }

                    static class Shell extends ShellCommand {
                        static final Binder sBinder = new Binder();
                        final IAppOpsService mInterface;
                        final AppOpsService mInternal;
                        IBinder mToken;
                        int mode;
                        String modeStr;
                        int nonpackageUid;
                        int op;
                        String opStr;
                        String packageName;
                        int packageUid;
                        boolean targetsUid;
                        int userId = 0;

                        Shell(IAppOpsService iface, AppOpsService internal) {
                            this.mInterface = iface;
                            this.mInternal = internal;
                            try {
                                this.mToken = this.mInterface.getToken(sBinder);
                            } catch (RemoteException e) {
                            }
                        }

                        public int onCommand(String cmd) {
                            return AppOpsService.onShellCommand(this, cmd);
                        }

                        public void onHelp() {
                            PrintWriter pw = getOutPrintWriter();
                            AppOpsService.dumpCommandHelp(pw);
                        }

                        /* JADX INFO: Access modifiers changed from: private */
                        public static int strOpToOp(String op, PrintWriter err) {
                            try {
                                return AppOpsManager.strOpToOp(op);
                            } catch (IllegalArgumentException e) {
                                try {
                                    return Integer.parseInt(op);
                                } catch (NumberFormatException e2) {
                                    try {
                                        return AppOpsManager.strDebugOpToOp(op);
                                    } catch (IllegalArgumentException e3) {
                                        err.println("Error: " + e3.getMessage());
                                        return -1;
                                    }
                                }
                            }
                        }

                        static int strModeToMode(String modeStr, PrintWriter err) {
                            for (int i = AppOpsManager.MODE_NAMES.length - 1; i >= 0; i--) {
                                if (AppOpsManager.MODE_NAMES[i].equals(modeStr)) {
                                    return i;
                                }
                            }
                            try {
                                int i2 = Integer.parseInt(modeStr);
                                return i2;
                            } catch (NumberFormatException e) {
                                err.println("Error: Mode " + modeStr + " is not valid");
                                return -1;
                            }
                        }

                        int parseUserOpMode(int defMode, PrintWriter err) throws RemoteException {
                            this.userId = -2;
                            this.opStr = null;
                            this.modeStr = null;
                            while (true) {
                                String argument = getNextArg();
                                if (argument == null) {
                                    break;
                                }
                                if ("--user".equals(argument)) {
                                    this.userId = UserHandle.parseUserArg(getNextArgRequired());
                                } else if (this.opStr == null) {
                                    this.opStr = argument;
                                } else if (this.modeStr == null) {
                                    this.modeStr = argument;
                                    break;
                                }
                            }
                            String str = this.opStr;
                            if (str == null) {
                                err.println("Error: Operation not specified.");
                                return -1;
                            }
                            this.op = strOpToOp(str, err);
                            if (this.op < 0) {
                                return -1;
                            }
                            String str2 = this.modeStr;
                            if (str2 != null) {
                                int iStrModeToMode = strModeToMode(str2, err);
                                this.mode = iStrModeToMode;
                                return iStrModeToMode < 0 ? -1 : 0;
                            }
                            this.mode = defMode;
                            return 0;
                        }

                        int parseUserPackageOp(boolean reqOp, PrintWriter err) throws RemoteException {
                            this.userId = -2;
                            this.packageName = null;
                            this.opStr = null;
                            while (true) {
                                String argument = getNextArg();
                                if (argument == null) {
                                    break;
                                }
                                if ("--user".equals(argument)) {
                                    this.userId = UserHandle.parseUserArg(getNextArgRequired());
                                } else if ("--uid".equals(argument)) {
                                    this.targetsUid = true;
                                } else if (this.packageName == null) {
                                    this.packageName = argument;
                                } else if (this.opStr == null) {
                                    this.opStr = argument;
                                    break;
                                }
                            }
                            if (this.packageName == null) {
                                err.println("Error: Package name not specified.");
                                return -1;
                            }
                            if (this.opStr == null && reqOp) {
                                err.println("Error: Operation not specified.");
                                return -1;
                            }
                            String str = this.opStr;
                            if (str != null) {
                                this.op = strOpToOp(str, err);
                                if (this.op < 0) {
                                    return -1;
                                }
                            } else {
                                this.op = -1;
                            }
                            if (this.userId == -2) {
                                this.userId = ActivityManager.getCurrentUser();
                            }
                            this.nonpackageUid = -1;
                            try {
                                this.nonpackageUid = Integer.parseInt(this.packageName);
                            } catch (NumberFormatException e) {
                            }
                            if (this.nonpackageUid == -1 && this.packageName.length() > 1 && this.packageName.charAt(0) == 'u' && this.packageName.indexOf(46) < 0) {
                                int i = 1;
                                while (i < this.packageName.length() && this.packageName.charAt(i) >= '0' && this.packageName.charAt(i) <= '9') {
                                    i++;
                                }
                                if (i > 1 && i < this.packageName.length()) {
                                    String userStr = this.packageName.substring(1, i);
                                    try {
                                        int user = Integer.parseInt(userStr);
                                        char type = this.packageName.charAt(i);
                                        int i2 = i + 1;
                                        while (i2 < this.packageName.length() && this.packageName.charAt(i2) >= '0' && this.packageName.charAt(i2) <= '9') {
                                            i2++;
                                        }
                                        if (i2 > i2) {
                                            String typeValStr = this.packageName.substring(i2, i2);
                                            try {
                                                int typeVal = Integer.parseInt(typeValStr);
                                                if (type == 'a') {
                                                    this.nonpackageUid = UserHandle.getUid(user, typeVal + 10000);
                                                } else if (type == 's') {
                                                    this.nonpackageUid = UserHandle.getUid(user, typeVal);
                                                }
                                            } catch (NumberFormatException e2) {
                                            }
                                        }
                                    } catch (NumberFormatException e3) {
                                    }
                                }
                            }
                            int i3 = this.nonpackageUid;
                            if (i3 == -1) {
                                this.packageUid = AppOpsService.resolveUid(this.packageName);
                                if (this.packageUid < 0) {
                                    this.packageUid = AppGlobals.getPackageManager().getPackageUid(this.packageName, 8192, this.userId);
                                }
                                if (this.packageUid < 0) {
                                    err.println("Error: No UID for " + this.packageName + " in user " + this.userId);
                                    return -1;
                                }
                            } else {
                                this.packageName = null;
                            }
                            return 0;
                        }
                    }

                    /* JADX WARN: Multi-variable type inference failed */
                    public void onShellCommand(FileDescriptor in, FileDescriptor out, FileDescriptor err, String[] args, ShellCallback callback, ResultReceiver resultReceiver) {
                        new Shell(this, this).exec(this, in, out, err, args, callback, resultReceiver);
                    }

                    static void dumpCommandHelp(PrintWriter pw) {
                        pw.println("AppOps service (appops) commands:");
                        pw.println("  help");
                        pw.println("    Print this help text.");
                        pw.println("  start [--user <USER_ID>] <PACKAGE | UID> <OP> ");
                        pw.println("    Starts a given operation for a particular application.");
                        pw.println("  stop [--user <USER_ID>] <PACKAGE | UID> <OP> ");
                        pw.println("    Stops a given operation for a particular application.");
                        pw.println("  set [--user <USER_ID>] <[--uid] PACKAGE | UID> <OP> <MODE>");
                        pw.println("    Set the mode for a particular application and operation.");
                        pw.println("  get [--user <USER_ID>] <PACKAGE | UID> [<OP>]");
                        pw.println("    Return the mode for a particular application and optional operation.");
                        pw.println("  query-op [--user <USER_ID>] <OP> [<MODE>]");
                        pw.println("    Print all packages that currently have the given op in the given mode.");
                        pw.println("  reset [--user <USER_ID>] [<PACKAGE>]");
                        pw.println("    Reset the given application or all applications to default modes.");
                        pw.println("  write-settings");
                        pw.println("    Immediately write pending changes to storage.");
                        pw.println("  read-settings");
                        pw.println("    Read the last written settings, replacing current state in RAM.");
                        pw.println("  options:");
                        pw.println("    <PACKAGE> an Android package name or its UID if prefixed by --uid");
                        pw.println("    <OP>      an AppOps operation.");
                        pw.println("    <MODE>    one of allow, ignore, deny, or default");
                        pw.println("    <USER_ID> the user id under which the package is installed. If --user is not");
                        pw.println("              specified, the current user is assumed.");
                    }

                    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
                    /* JADX WARN: Code duplicated, block: B:116:0x01d6 A[Catch: RemoteException -> 0x0396, TryCatch #4 {RemoteException -> 0x0396, blocks: (B:7:0x0014, B:8:0x001a, B:35:0x0076, B:36:0x0079, B:37:0x007f, B:40:0x0086, B:42:0x008a, B:45:0x0099, B:48:0x00a0, B:50:0x00a4, B:53:0x00b4, B:55:0x00cf, B:58:0x00d5, B:59:0x00d8, B:60:0x00d9, B:66:0x0103, B:72:0x010c, B:73:0x010f, B:75:0x0113, B:77:0x011a, B:79:0x0122, B:82:0x0130, B:85:0x0147, B:86:0x014c, B:88:0x0158, B:90:0x0167, B:92:0x016e, B:93:0x0174, B:89:0x015e, B:95:0x017e, B:98:0x0185, B:100:0x0193, B:104:0x019b, B:106:0x01a1, B:107:0x01b3, B:109:0x01b9, B:111:0x01c7, B:114:0x01d1, B:116:0x01d6, B:117:0x01dd, B:119:0x01e1, B:121:0x01e7, B:124:0x01ee, B:126:0x01f8, B:128:0x0200, B:130:0x0208, B:132:0x020e, B:133:0x0211, B:135:0x021b, B:136:0x0221, B:138:0x0227, B:145:0x0240, B:175:0x0308, B:177:0x0311, B:179:0x0317, B:148:0x024a, B:149:0x024f, B:151:0x0255, B:153:0x0261, B:154:0x0266, B:155:0x026b, B:157:0x0271, B:159:0x029c, B:161:0x02b4, B:163:0x02bc, B:164:0x02cf, B:166:0x02d9, B:170:0x02f3, B:167:0x02df, B:169:0x02e7, B:171:0x02fd, B:140:0x022b, B:142:0x0233, B:143:0x0239, B:182:0x0337, B:185:0x033f, B:187:0x0346, B:189:0x034c, B:192:0x0354, B:194:0x0358, B:196:0x035c, B:197:0x0368, B:199:0x036c, B:201:0x0370, B:205:0x038a, B:10:0x001e, B:13:0x0029, B:16:0x0034, B:19:0x003f, B:22:0x004a, B:25:0x0055, B:28:0x005f, B:31:0x006a, B:54:0x00c5, B:61:0x00ea, B:62:0x00ec, B:65:0x00f9, B:70:0x010a, B:63:0x00ed, B:64:0x00f8), top: B:219:0x0014, inners: #1, #3 }] */
                    /* JADX WARN: Code duplicated, block: B:229:0x01dd A[SYNTHETIC] */
                    /* JADX WARN: Code duplicated, block: B:9:0x001d  */
                    static int onShellCommand(Shell shell, String cmd) {
                        if (cmd == null) {
                            return shell.handleDefaultCommands(cmd);
                        }
                        PrintWriter pw = shell.getOutPrintWriter();
                        PrintWriter err = shell.getErrPrintWriter();
                        try {
                            int i = 0;
                            switch (cmd) {
                                case "set":
                                    int res = shell.parseUserPackageOp(true, err);
                                    if (res < 0) {
                                        return res;
                                    }
                                    String modeStr = shell.getNextArg();
                                    if (modeStr == null) {
                                        err.println("Error: Mode not specified.");
                                        return -1;
                                    }
                                    int mode = Shell.strModeToMode(modeStr, err);
                                    if (mode < 0) {
                                        return -1;
                                    }
                                    if (!shell.targetsUid && shell.packageName != null) {
                                        shell.mInterface.setMode(shell.op, shell.packageUid, shell.packageName, mode);
                                        return 0;
                                    }
                                    if (!shell.targetsUid || shell.packageName == null) {
                                        shell.mInterface.setUidMode(shell.op, shell.nonpackageUid, mode);
                                        return 0;
                                    }
                                    try {
                                        int uid = shell.mInternal.mContext.getPackageManager().getPackageUid(shell.packageName, shell.userId);
                                        shell.mInterface.setUidMode(shell.op, uid, mode);
                                        return 0;
                                    } catch (PackageManager.NameNotFoundException e) {
                                        return -1;
                                    }
                                case "get":
                                    int res2 = shell.parseUserPackageOp(false, err);
                                    if (res2 < 0) {
                                        return res2;
                                    }
                                    List<AppOpsManager.PackageOps> ops = new ArrayList<>();
                                    if (shell.packageName != null) {
                                        List<AppOpsManager.PackageOps> r = shell.mInterface.getUidOps(shell.packageUid, shell.op != -1 ? new int[]{shell.op} : null);
                                        if (r != null) {
                                            ops.addAll(r);
                                        }
                                        List<AppOpsManager.PackageOps> r2 = shell.mInterface.getOpsForPackage(shell.packageUid, shell.packageName, shell.op != -1 ? new int[]{shell.op} : null);
                                        if (r2 != null) {
                                            ops.addAll(r2);
                                        }
                                    } else {
                                        ops = shell.mInterface.getUidOps(shell.nonpackageUid, shell.op != -1 ? new int[]{shell.op} : null);
                                    }
                                    if (ops == null || ops.size() <= 0) {
                                        pw.println("No operations.");
                                        if (shell.op > -1 && shell.op < 91) {
                                            pw.println("Default mode: " + AppOpsManager.modeToName(AppOpsManager.opToDefaultMode(shell.op)));
                                            return 0;
                                        }
                                        return 0;
                                    }
                                    long now = System.currentTimeMillis();
                                    int i2 = 0;
                                    while (i2 < ops.size()) {
                                        AppOpsManager.PackageOps packageOps = ops.get(i2);
                                        if (packageOps.getPackageName() == null) {
                                            pw.print("Uid mode: ");
                                        }
                                        List<AppOpsManager.OpEntry> entries = packageOps.getOps();
                                        int j = i;
                                        while (j < entries.size()) {
                                            AppOpsManager.OpEntry ent = entries.get(j);
                                            pw.print(AppOpsManager.opToName(ent.getOp()));
                                            pw.print(": ");
                                            pw.print(AppOpsManager.modeToName(ent.getMode()));
                                            if (ent.getTime() != 0) {
                                                pw.print("; time=");
                                                TimeUtils.formatDuration(now - ent.getTime(), pw);
                                                pw.print(" ago");
                                            }
                                            if (ent.getRejectTime() != 0) {
                                                pw.print("; rejectTime=");
                                                TimeUtils.formatDuration(now - ent.getRejectTime(), pw);
                                                pw.print(" ago");
                                            }
                                            if (ent.getDuration() == -1) {
                                                pw.print(" (running)");
                                            } else if (ent.getDuration() != 0) {
                                                pw.print("; duration=");
                                                TimeUtils.formatDuration(ent.getDuration(), pw);
                                            }
                                            pw.println();
                                            j++;
                                            ops = ops;
                                        }
                                        i2++;
                                        i = 0;
                                    }
                                    return 0;
                                case "query-op":
                                    int res3 = shell.parseUserOpMode(1, err);
                                    if (res3 < 0) {
                                        return res3;
                                    }
                                    List<AppOpsManager.PackageOps> ops2 = shell.mInterface.getPackagesForOps(new int[]{shell.op});
                                    if (ops2 != null && ops2.size() > 0) {
                                        for (int i3 = 0; i3 < ops2.size(); i3++) {
                                            AppOpsManager.PackageOps pkg = ops2.get(i3);
                                            boolean hasMatch = false;
                                            List<AppOpsManager.OpEntry> entries2 = ops2.get(i3).getOps();
                                            for (int j2 = 0; j2 < entries2.size(); j2++) {
                                                AppOpsManager.OpEntry ent2 = entries2.get(j2);
                                                if (ent2.getOp() == shell.op && ent2.getMode() == shell.mode) {
                                                    hasMatch = true;
                                                    if (hasMatch) {
                                                        pw.println(pkg.getPackageName());
                                                    }
                                                }
                                            }
                                            if (hasMatch) {
                                                pw.println(pkg.getPackageName());
                                            }
                                        }
                                        return 0;
                                    }
                                    pw.println("No operations.");
                                    return 0;
                                case "reset":
                                    String packageName = null;
                                    int userId = -2;
                                    while (true) {
                                        String argument = shell.getNextArg();
                                        if (argument != null) {
                                            if ("--user".equals(argument)) {
                                                String userStr = shell.getNextArgRequired();
                                                userId = UserHandle.parseUserArg(userStr);
                                            } else {
                                                if (packageName != null) {
                                                    err.println("Error: Unsupported argument: " + argument);
                                                    return -1;
                                                }
                                                packageName = argument;
                                            }
                                        } else {
                                            if (userId == -2) {
                                                userId = ActivityManager.getCurrentUser();
                                            }
                                            shell.mInterface.resetAllModes(userId, packageName);
                                            pw.print("Reset all modes for: ");
                                            if (userId == -1) {
                                                pw.print("all users");
                                            } else {
                                                pw.print("user ");
                                                pw.print(userId);
                                            }
                                            pw.print(", ");
                                            if (packageName == null) {
                                                pw.println("all packages");
                                            } else {
                                                pw.print("package ");
                                                pw.println(packageName);
                                            }
                                            return 0;
                                        }
                                    }
                                    break;
                                case "write-settings":
                                    shell.mInternal.enforceManageAppOpsModes(Binder.getCallingPid(), Binder.getCallingUid(), -1);
                                    long token = Binder.clearCallingIdentity();
                                    try {
                                        synchronized (shell.mInternal) {
                                            shell.mInternal.mHandler.removeCallbacks(shell.mInternal.mWriteRunner);
                                            break;
                                        }
                                        shell.mInternal.writeState();
                                        pw.println("Current settings written.");
                                        Binder.restoreCallingIdentity(token);
                                        return 0;
                                    } catch (Throwable th) {
                                        Binder.restoreCallingIdentity(token);
                                        throw th;
                                    }
                                case "read-settings":
                                    shell.mInternal.enforceManageAppOpsModes(Binder.getCallingPid(), Binder.getCallingUid(), -1);
                                    long token2 = Binder.clearCallingIdentity();
                                    try {
                                        shell.mInternal.readState();
                                        pw.println("Last settings read.");
                                        return 0;
                                    } finally {
                                        Binder.restoreCallingIdentity(token2);
                                    }
                                case "start":
                                    int res4 = shell.parseUserPackageOp(true, err);
                                    if (res4 < 0) {
                                        return res4;
                                    }
                                    if (shell.packageName != null) {
                                        shell.mInterface.startOperation(shell.mToken, shell.op, shell.packageUid, shell.packageName, true);
                                        return 0;
                                    }
                                    return -1;
                                case "stop":
                                    int res5 = shell.parseUserPackageOp(true, err);
                                    if (res5 < 0) {
                                        return res5;
                                    }
                                    if (shell.packageName != null) {
                                        shell.mInterface.finishOperation(shell.mToken, shell.op, shell.packageUid, shell.packageName);
                                        return 0;
                                    }
                                    return -1;
                                default:
                                    return shell.handleDefaultCommands(cmd);
                            }
                        } catch (RemoteException e2) {
                            pw.println("Remote exception: " + e2);
                            return -1;
                        }
                        pw.println("Remote exception: " + e2);
                        return -1;
                    }

                    private void dumpHelp(PrintWriter pw) {
                        pw.println("AppOps service (appops) dump options:");
                        pw.println("  -h");
                        pw.println("    Print this help text.");
                        pw.println("  --op [OP]");
                        pw.println("    Limit output to data associated with the given app op code.");
                        pw.println("  --mode [MODE]");
                        pw.println("    Limit output to data associated with the given app op mode.");
                        pw.println("  --package [PACKAGE]");
                        pw.println("    Limit output to data associated with the given package name.");
                        pw.println("  --watchers");
                        pw.println("    Only output the watcher sections.");
                    }

                    private void dumpStatesLocked(PrintWriter pw, Op op, long now, SimpleDateFormat sdf, Date date, String prefix) {
                        String str;
                        AppOpsManager.OpEntry entry = new AppOpsManager.OpEntry(op.op, op.running, op.mode, op.mAccessTimes, op.mRejectTimes, op.mDurations, op.mProxyUids, op.mProxyPackageNames);
                        LongSparseArray keys = entry.collectKeys();
                        if (keys != null && keys.size() > 0) {
                            int keyCount = keys.size();
                            int proxyUid = 0;
                            while (proxyUid < keyCount) {
                                long key = keys.keyAt(proxyUid);
                                int uidState = AppOpsManager.extractUidStateFromKey(key);
                                int flags = AppOpsManager.extractFlagsFromKey(key);
                                long accessTime = entry.getLastAccessTime(uidState, uidState, flags);
                                long rejectTime = entry.getLastRejectTime(uidState, uidState, flags);
                                LongSparseArray keys2 = keys;
                                int keyCount2 = keyCount;
                                long accessDuration = entry.getLastDuration(uidState, uidState, flags);
                                String proxyPkg = entry.getProxyPackageName(uidState, flags);
                                int k = proxyUid;
                                int proxyUid2 = entry.getProxyUid(uidState, flags);
                                AppOpsManager.OpEntry entry2 = entry;
                                if (accessTime > 0) {
                                    pw.print(prefix);
                                    pw.print("Access: ");
                                    pw.print(AppOpsManager.keyToString(key));
                                    pw.print(" ");
                                    date.setTime(accessTime);
                                    pw.print(sdf.format(date));
                                    pw.print(" (");
                                    TimeUtils.formatDuration(accessTime - now, pw);
                                    pw.print(")");
                                    if (accessDuration > 0) {
                                        pw.print(" duration=");
                                        TimeUtils.formatDuration(accessDuration, pw);
                                    }
                                    if (proxyUid2 < 0) {
                                        str = "]";
                                    } else {
                                        pw.print(" proxy[");
                                        pw.print("uid=");
                                        pw.print(proxyUid2);
                                        pw.print(", pkg=");
                                        pw.print(proxyPkg);
                                        str = "]";
                                        pw.print(str);
                                    }
                                    pw.println();
                                } else {
                                    str = "]";
                                }
                                if (rejectTime > 0) {
                                    pw.print(prefix);
                                    pw.print("Reject: ");
                                    pw.print(AppOpsManager.keyToString(key));
                                    date.setTime(rejectTime);
                                    pw.print(sdf.format(date));
                                    pw.print(" (");
                                    TimeUtils.formatDuration(rejectTime - now, pw);
                                    pw.print(")");
                                    if (proxyUid2 >= 0) {
                                        pw.print(" proxy[");
                                        pw.print("uid=");
                                        pw.print(proxyUid2);
                                        pw.print(", pkg=");
                                        pw.print(proxyPkg);
                                        pw.print(str);
                                    }
                                    pw.println();
                                }
                                proxyUid = k + 1;
                                keys = keys2;
                                keyCount = keyCount2;
                                entry = entry2;
                            }
                        }
                    }

                    protected void dump(FileDescriptor fd, PrintWriter pw, String[] args) throws Throwable {
                        int dumpOp;
                        boolean dumpWatchers;
                        String dumpPackage;
                        int dumpUid;
                        boolean needSep;
                        long now;
                        int dumpUid2;
                        int userRestrictionCount;
                        long now2;
                        SimpleDateFormat sdf;
                        Date date;
                        ClientRestrictionState restrictionState;
                        boolean hasPackage;
                        boolean dumpWatchers2;
                        boolean hasOp;
                        boolean hasPackage2;
                        boolean hasOp2;
                        boolean hasOp3;
                        boolean needSep2;
                        long nowElapsed;
                        long nowElapsed2;
                        String dumpPackage2;
                        int dumpMode;
                        ArrayMap<String, Ops> pkgOps;
                        UidState uidState;
                        String dumpPackage3;
                        long now3;
                        long now4;
                        SimpleDateFormat sdf2;
                        int dumpOp2;
                        int j;
                        boolean printedPackage;
                        SimpleDateFormat sdf3;
                        int j2;
                        long now5;
                        long now6;
                        int opModeCount;
                        int opModeCount2;
                        long nowElapsed3;
                        int mode;
                        SparseArray<Restriction> restrictions;
                        int dumpUid3;
                        boolean needSep3;
                        boolean needSep4;
                        boolean needSep5;
                        boolean needSep6;
                        boolean needSep7;
                        ArraySet<ModeCallback> callbacks;
                        if (!DumpUtils.checkDumpAndUsageStatsPermission(this.mContext, TAG, pw)) {
                            return;
                        }
                        String dumpPackage4 = null;
                        int dumpUid4 = -1;
                        int dumpOp3 = 0;
                        if (args != null) {
                            int i = 0;
                            boolean dumpWatchers3 = false;
                            int dumpMode2 = -1;
                            int dumpUid5 = -1;
                            int dumpOp4 = -1;
                            while (i < args.length) {
                                String arg = args[i];
                                if ("-h".equals(arg)) {
                                    dumpHelp(pw);
                                    return;
                                }
                                if (!"-a".equals(arg)) {
                                    if ("--op".equals(arg)) {
                                        i++;
                                        if (i >= args.length) {
                                            pw.println("No argument for --op option");
                                            return;
                                        }
                                        int dumpOp5 = Shell.strOpToOp(args[i], pw);
                                        if (dumpOp5 < 0) {
                                            return;
                                        } else {
                                            dumpOp4 = dumpOp5;
                                        }
                                    } else if ("--package".equals(arg)) {
                                        i++;
                                        if (i >= args.length) {
                                            pw.println("No argument for --package option");
                                            return;
                                        }
                                        dumpPackage4 = args[i];
                                        try {
                                            dumpUid5 = AppGlobals.getPackageManager().getPackageUid(dumpPackage4, 12591104, 0);
                                        } catch (RemoteException e) {
                                        }
                                        if (dumpUid5 < 0) {
                                            pw.println("Unknown package: " + dumpPackage4);
                                            return;
                                        }
                                        dumpUid5 = UserHandle.getAppId(dumpUid5);
                                    } else if ("--mode".equals(arg)) {
                                        i++;
                                        if (i >= args.length) {
                                            pw.println("No argument for --mode option");
                                            return;
                                        }
                                        int dumpMode3 = Shell.strModeToMode(args[i], pw);
                                        if (dumpMode3 < 0) {
                                            return;
                                        } else {
                                            dumpMode2 = dumpMode3;
                                        }
                                    } else {
                                        if (!"--watchers".equals(arg)) {
                                            if (arg.length() <= 0 || arg.charAt(0) != '-') {
                                                pw.println("Unknown command: " + arg);
                                                return;
                                            }
                                            pw.println("Unknown option: " + arg);
                                            return;
                                        }
                                        dumpWatchers3 = true;
                                    }
                                }
                                i++;
                            }
                            dumpOp = dumpOp4;
                            dumpWatchers = dumpWatchers3;
                            dumpPackage = dumpPackage4;
                            dumpUid = dumpUid5;
                            dumpUid4 = dumpMode2;
                        } else {
                            dumpOp = -1;
                            dumpWatchers = false;
                            dumpPackage = null;
                            dumpUid = -1;
                        }
                        synchronized (this) {
                            try {
                                try {
                                    pw.println("Current AppOps Service state:");
                                    if (0 == 0 && !dumpWatchers) {
                                        try {
                                            this.mConstants.dump(pw);
                                        } catch (Throwable th) {
                                            th = th;
                                        }
                                    }
                                    pw.println();
                                    long now7 = System.currentTimeMillis();
                                    long nowElapsed4 = SystemClock.elapsedRealtime();
                                    SystemClock.uptimeMillis();
                                    long now8 = nowElapsed4;
                                    SimpleDateFormat sdf4 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                                    Date date2 = new Date();
                                    if (dumpOp < 0 && dumpUid4 < 0 && dumpPackage == null && this.mProfileOwners != null && !dumpWatchers && 0 == 0) {
                                        pw.println("  Profile owners:");
                                        for (int poi = 0; poi < this.mProfileOwners.size(); poi++) {
                                            pw.print("    User #");
                                            pw.print(this.mProfileOwners.keyAt(poi));
                                            pw.print(": ");
                                            UserHandle.formatUid(pw, this.mProfileOwners.valueAt(poi));
                                            pw.println();
                                        }
                                        pw.println();
                                    }
                                    if (this.mOpModeWatchers.size() <= 0 || 0 != 0) {
                                        needSep = false;
                                    } else {
                                        boolean printedHeader = false;
                                        needSep = false;
                                        for (int i2 = 0; i2 < this.mOpModeWatchers.size(); i2++) {
                                            if (dumpOp < 0 || dumpOp == this.mOpModeWatchers.keyAt(i2)) {
                                                boolean printedOpHeader = false;
                                                ArraySet<ModeCallback> callbacks2 = this.mOpModeWatchers.valueAt(i2);
                                                boolean printedHeader2 = printedHeader;
                                                int j3 = 0;
                                                while (true) {
                                                    needSep7 = needSep;
                                                    if (j3 >= callbacks2.size()) {
                                                        break;
                                                    }
                                                    ModeCallback cb = callbacks2.valueAt(j3);
                                                    if (dumpPackage != null) {
                                                        callbacks = callbacks2;
                                                        needSep = dumpUid != UserHandle.getAppId(cb.mWatchingUid) ? needSep7 : true;
                                                        j3++;
                                                        callbacks2 = callbacks;
                                                    } else {
                                                        callbacks = callbacks2;
                                                    }
                                                    if (!printedHeader2) {
                                                        pw.println("  Op mode watchers:");
                                                        printedHeader2 = true;
                                                    }
                                                    if (!printedOpHeader) {
                                                        pw.print("    Op ");
                                                        pw.print(AppOpsManager.opToName(this.mOpModeWatchers.keyAt(i2)));
                                                        pw.println(":");
                                                        printedOpHeader = true;
                                                    }
                                                    pw.print("      #");
                                                    pw.print(j3);
                                                    pw.print(": ");
                                                    pw.println(cb);
                                                    j3++;
                                                    callbacks2 = callbacks;
                                                }
                                                printedHeader = printedHeader2;
                                                needSep = needSep7;
                                            }
                                        }
                                    }
                                    if (this.mPackageModeWatchers.size() > 0 && dumpOp < 0 && 0 == 0) {
                                        boolean printedHeader3 = false;
                                        for (int i3 = 0; i3 < this.mPackageModeWatchers.size(); i3++) {
                                            if (dumpPackage == null || dumpPackage.equals(this.mPackageModeWatchers.keyAt(i3))) {
                                                boolean needSep8 = true;
                                                if (!printedHeader3) {
                                                    pw.println("  Package mode watchers:");
                                                    printedHeader3 = true;
                                                }
                                                pw.print("    Pkg ");
                                                pw.print(this.mPackageModeWatchers.keyAt(i3));
                                                pw.println(":");
                                                ArraySet<ModeCallback> callbacks3 = this.mPackageModeWatchers.valueAt(i3);
                                                boolean printedHeader4 = printedHeader3;
                                                int j4 = 0;
                                                while (true) {
                                                    needSep6 = needSep8;
                                                    if (j4 >= callbacks3.size()) {
                                                        break;
                                                    }
                                                    pw.print("      #");
                                                    pw.print(j4);
                                                    pw.print(": ");
                                                    pw.println(callbacks3.valueAt(j4));
                                                    j4++;
                                                    needSep8 = needSep6;
                                                }
                                                needSep = needSep6;
                                                printedHeader3 = printedHeader4;
                                            }
                                        }
                                    }
                                    if (this.mModeWatchers.size() > 0 && dumpOp < 0 && 0 == 0) {
                                        boolean printedHeader5 = false;
                                        for (int i4 = 0; i4 < this.mModeWatchers.size(); i4++) {
                                            ModeCallback cb2 = this.mModeWatchers.valueAt(i4);
                                            if (dumpPackage != null) {
                                                needSep = dumpUid != UserHandle.getAppId(cb2.mWatchingUid) ? needSep : true;
                                            }
                                            if (!printedHeader5) {
                                                pw.println("  All op mode watchers:");
                                                printedHeader5 = true;
                                            }
                                            boolean printedHeader6 = printedHeader5;
                                            pw.print("    ");
                                            pw.print(Integer.toHexString(System.identityHashCode(this.mModeWatchers.keyAt(i4))));
                                            pw.print(": ");
                                            pw.println(cb2);
                                            printedHeader5 = printedHeader6;
                                        }
                                    }
                                    if (this.mActiveWatchers.size() <= 0 || dumpUid4 >= 0) {
                                        now = now7;
                                    } else {
                                        needSep = true;
                                        boolean printedHeader7 = false;
                                        int watcherNum = 0;
                                        while (watcherNum < this.mActiveWatchers.size()) {
                                            SparseArray<ActiveCallback> activeWatchers = this.mActiveWatchers.valueAt(watcherNum);
                                            if (activeWatchers.size() <= 0) {
                                                needSep5 = needSep;
                                            } else {
                                                ActiveCallback cb3 = activeWatchers.valueAt(0);
                                                if (dumpOp < 0 || activeWatchers.indexOfKey(dumpOp) >= 0) {
                                                    if (dumpPackage != null) {
                                                        needSep5 = needSep;
                                                        if (dumpUid != UserHandle.getAppId(cb3.mWatchingUid)) {
                                                        }
                                                        watcherNum++;
                                                        needSep = needSep5;
                                                        now7 = now7;
                                                    } else {
                                                        needSep5 = needSep;
                                                    }
                                                    if (!printedHeader7) {
                                                        pw.println("  All op active watchers:");
                                                        printedHeader7 = true;
                                                    }
                                                    pw.print("    ");
                                                    pw.print(Integer.toHexString(System.identityHashCode(this.mActiveWatchers.keyAt(watcherNum))));
                                                    pw.println(" ->");
                                                    pw.print("        [");
                                                    int opCount = activeWatchers.size();
                                                    for (int opNum = 0; opNum < opCount; opNum++) {
                                                        if (opNum > 0) {
                                                            pw.print(' ');
                                                        }
                                                        pw.print(AppOpsManager.opToName(activeWatchers.keyAt(opNum)));
                                                        if (opNum < opCount - 1) {
                                                            pw.print(',');
                                                        }
                                                    }
                                                    pw.println("]");
                                                    pw.print("        ");
                                                    pw.println(cb3);
                                                    watcherNum++;
                                                    needSep = needSep5;
                                                    now7 = now7;
                                                } else {
                                                    needSep5 = needSep;
                                                }
                                            }
                                            watcherNum++;
                                            needSep = needSep5;
                                            now7 = now7;
                                        }
                                        now = now7;
                                    }
                                    if (this.mNotedWatchers.size() > 0 && dumpUid4 < 0) {
                                        needSep = true;
                                        boolean printedHeader8 = false;
                                        int i5 = 0;
                                        while (i5 < this.mNotedWatchers.size()) {
                                            SparseArray<NotedCallback> notedWatchers = this.mNotedWatchers.valueAt(i5);
                                            if (notedWatchers.size() > 0) {
                                                NotedCallback cb4 = notedWatchers.valueAt(0);
                                                if ((dumpOp < 0 || notedWatchers.indexOfKey(dumpOp) >= 0) && (dumpPackage == null || dumpUid == UserHandle.getAppId(cb4.mWatchingUid))) {
                                                    if (!printedHeader8) {
                                                        pw.println("  All op noted watchers:");
                                                        printedHeader8 = true;
                                                    }
                                                    pw.print("    ");
                                                    pw.print(Integer.toHexString(System.identityHashCode(this.mNotedWatchers.keyAt(i5))));
                                                    pw.println(" ->");
                                                    pw.print("        [");
                                                    int opCount2 = notedWatchers.size();
                                                    i5 = 0;
                                                    while (i5 < opCount2) {
                                                        if (i5 > 0) {
                                                            pw.print(' ');
                                                        }
                                                        pw.print(AppOpsManager.opToName(notedWatchers.keyAt(i5)));
                                                        if (i5 < opCount2 - 1) {
                                                            pw.print(',');
                                                        }
                                                        i5++;
                                                        printedHeader8 = printedHeader8;
                                                    }
                                                    boolean printedHeader9 = printedHeader8;
                                                    pw.println("]");
                                                    pw.print("        ");
                                                    pw.println(cb4);
                                                    printedHeader8 = printedHeader9;
                                                }
                                            }
                                            i5++;
                                        }
                                    }
                                    if (this.mClients.size() <= 0 || dumpUid4 >= 0 || dumpWatchers || 0 != 0) {
                                        dumpUid2 = dumpUid;
                                    } else {
                                        needSep = true;
                                        boolean printedHeader10 = false;
                                        int i6 = 0;
                                        while (i6 < this.mClients.size()) {
                                            try {
                                                boolean printedClient = false;
                                                ClientState cs = this.mClients.valueAt(i6);
                                                if (cs.mStartedOps.size() > 0) {
                                                    boolean printedStarted = false;
                                                    boolean printedHeader11 = printedHeader10;
                                                    int j5 = 0;
                                                    while (true) {
                                                        dumpUid3 = dumpUid;
                                                        try {
                                                            if (j5 >= cs.mStartedOps.size()) {
                                                                break;
                                                            }
                                                            Op op = cs.mStartedOps.get(j5);
                                                            if (dumpOp >= 0) {
                                                                needSep4 = needSep;
                                                                if (op.op != dumpOp) {
                                                                }
                                                                j5++;
                                                                dumpUid = dumpUid3;
                                                                needSep = needSep4;
                                                            } else {
                                                                needSep4 = needSep;
                                                            }
                                                            if (dumpPackage == null || dumpPackage.equals(op.packageName)) {
                                                                if (!printedHeader11) {
                                                                    pw.println("  Clients:");
                                                                    printedHeader11 = true;
                                                                }
                                                                if (!printedClient) {
                                                                    pw.print("    ");
                                                                    pw.print(this.mClients.keyAt(i6));
                                                                    pw.println(":");
                                                                    pw.print("      ");
                                                                    pw.println(cs);
                                                                    printedClient = true;
                                                                }
                                                                if (!printedStarted) {
                                                                    pw.println("      Started ops:");
                                                                    printedStarted = true;
                                                                }
                                                                pw.print("        ");
                                                                pw.print("uid=");
                                                                pw.print(op.uidState.uid);
                                                                pw.print(" pkg=");
                                                                pw.print(op.packageName);
                                                                pw.print(" op=");
                                                                pw.println(AppOpsManager.opToName(op.op));
                                                            }
                                                            j5++;
                                                            dumpUid = dumpUid3;
                                                            needSep = needSep4;
                                                        } catch (Throwable th2) {
                                                            th = th2;
                                                        }
                                                    }
                                                    needSep3 = needSep;
                                                    printedHeader10 = printedHeader11;
                                                } else {
                                                    dumpUid3 = dumpUid;
                                                    needSep3 = needSep;
                                                }
                                                i6++;
                                                dumpUid = dumpUid3;
                                                needSep = needSep3;
                                            } catch (Throwable th3) {
                                                th = th3;
                                            }
                                        }
                                        dumpUid2 = dumpUid;
                                    }
                                    try {
                                        if (this.mAudioRestrictions.size() > 0 && dumpOp < 0 && dumpPackage != null && dumpUid4 < 0 && !dumpWatchers && !dumpWatchers) {
                                            boolean printedHeader12 = false;
                                            for (int o = 0; o < this.mAudioRestrictions.size(); o++) {
                                                String op2 = AppOpsManager.opToName(this.mAudioRestrictions.keyAt(o));
                                                SparseArray<Restriction> restrictions2 = this.mAudioRestrictions.valueAt(o);
                                                int i7 = 0;
                                                while (i7 < restrictions2.size()) {
                                                    if (!printedHeader12) {
                                                        pw.println("  Audio Restrictions:");
                                                        printedHeader12 = true;
                                                        needSep = true;
                                                    }
                                                    int usage = restrictions2.keyAt(i7);
                                                    boolean printedHeader13 = printedHeader12;
                                                    pw.print("    ");
                                                    pw.print(op2);
                                                    pw.print(" usage=");
                                                    pw.print(AudioAttributes.usageToString(usage));
                                                    Restriction r = restrictions2.valueAt(i7);
                                                    String op3 = op2;
                                                    pw.print(": mode=");
                                                    pw.println(AppOpsManager.modeToName(r.mode));
                                                    if (r.exceptionPackages.isEmpty()) {
                                                        restrictions = restrictions2;
                                                    } else {
                                                        pw.println("      Exceptions:");
                                                        int j6 = 0;
                                                        while (true) {
                                                            restrictions = restrictions2;
                                                            if (j6 < r.exceptionPackages.size()) {
                                                                pw.print("        ");
                                                                pw.println(r.exceptionPackages.valueAt(j6));
                                                                j6++;
                                                                restrictions2 = restrictions;
                                                            }
                                                        }
                                                    }
                                                    i7++;
                                                    printedHeader12 = printedHeader13;
                                                    op2 = op3;
                                                    restrictions2 = restrictions;
                                                }
                                            }
                                        }
                                        if (needSep) {
                                            pw.println();
                                        }
                                        int i8 = 0;
                                        while (i8 < this.mUidStates.size()) {
                                            UidState uidState2 = this.mUidStates.valueAt(i8);
                                            SparseIntArray opModes = uidState2.opModes;
                                            ArrayMap<String, Ops> pkgOps2 = uidState2.pkgOps;
                                            if (dumpWatchers || dumpOp3 != 0) {
                                                dumpOp3 = dumpOp3;
                                                needSep = needSep;
                                                dumpWatchers2 = dumpWatchers;
                                            } else {
                                                try {
                                                    if (dumpOp >= 0 || dumpPackage != null || dumpUid4 >= 0) {
                                                        boolean hasOp4 = dumpOp < 0 || (uidState2.opModes != null && uidState2.opModes.indexOfKey(dumpOp) >= 0);
                                                        boolean hasPackage3 = dumpPackage == null;
                                                        boolean hasMode = dumpUid4 < 0;
                                                        if (!hasMode && opModes != null) {
                                                            hasOp = hasOp4;
                                                            int opi = 0;
                                                            while (true) {
                                                                if (hasMode) {
                                                                    hasPackage2 = hasPackage3;
                                                                    break;
                                                                }
                                                                hasPackage2 = hasPackage3;
                                                                if (opi >= opModes.size()) {
                                                                    break;
                                                                }
                                                                if (opModes.valueAt(opi) == dumpUid4) {
                                                                    hasMode = true;
                                                                }
                                                                opi++;
                                                                hasPackage3 = hasPackage2;
                                                            }
                                                        } else {
                                                            hasOp = hasOp4;
                                                            hasPackage2 = hasPackage3;
                                                        }
                                                        if (pkgOps2 != null) {
                                                            boolean hasPackage4 = hasPackage2;
                                                            int pkgi = 0;
                                                            hasOp2 = hasOp;
                                                            while (true) {
                                                                if (hasOp2 && hasPackage4 && hasMode) {
                                                                    dumpWatchers2 = dumpWatchers;
                                                                    break;
                                                                }
                                                                dumpWatchers2 = dumpWatchers;
                                                                if (pkgi >= pkgOps2.size()) {
                                                                    break;
                                                                }
                                                                Ops ops = pkgOps2.valueAt(pkgi);
                                                                if (!hasOp2 && ops != null && ops.indexOfKey(dumpOp) >= 0) {
                                                                    hasOp2 = true;
                                                                }
                                                                if (!hasMode) {
                                                                    hasOp3 = hasOp2;
                                                                    int opi2 = 0;
                                                                    while (true) {
                                                                        if (hasMode) {
                                                                            needSep2 = needSep;
                                                                            break;
                                                                        }
                                                                        needSep2 = needSep;
                                                                        if (opi2 >= ops.size()) {
                                                                            break;
                                                                        }
                                                                        if (ops.valueAt(opi2).mode == dumpUid4) {
                                                                            hasMode = true;
                                                                        }
                                                                        opi2++;
                                                                        needSep = needSep2;
                                                                    }
                                                                } else {
                                                                    hasOp3 = hasOp2;
                                                                    needSep2 = needSep;
                                                                }
                                                                if (!hasPackage4 && dumpPackage.equals(ops.packageName)) {
                                                                    hasPackage4 = true;
                                                                }
                                                                pkgi++;
                                                                hasOp2 = hasOp3;
                                                                dumpWatchers = dumpWatchers2;
                                                                needSep = needSep2;
                                                            }
                                                            hasPackage2 = hasPackage4;
                                                        } else {
                                                            needSep = needSep;
                                                            dumpWatchers2 = dumpWatchers;
                                                            hasOp2 = hasOp;
                                                        }
                                                        if (uidState2.foregroundOps != null && !hasOp2 && uidState2.foregroundOps.indexOfKey(dumpOp) > 0) {
                                                            hasOp2 = true;
                                                        }
                                                        if (!hasOp2 || !hasPackage2 || !hasMode) {
                                                        }
                                                        i8++;
                                                        dumpPackage = dumpPackage;
                                                        dumpOp = dumpOp;
                                                        dumpOp3 = dumpOp3;
                                                        now8 = now8;
                                                        dumpWatchers = dumpWatchers2;
                                                        dumpUid4 = dumpUid4;
                                                        now = now;
                                                    } else {
                                                        dumpOp3 = dumpOp3;
                                                        dumpWatchers2 = dumpWatchers;
                                                    }
                                                    pw.print("  Uid ");
                                                    UserHandle.formatUid(pw, uidState2.uid);
                                                    pw.println(":");
                                                    pw.print("    state=");
                                                    pw.println(AppOpsManager.getUidStateName(uidState2.state));
                                                    if (uidState2.state != uidState2.pendingState) {
                                                        try {
                                                            pw.print("    pendingState=");
                                                            pw.println(AppOpsManager.getUidStateName(uidState2.pendingState));
                                                        } catch (Throwable th4) {
                                                            th = th4;
                                                        }
                                                    }
                                                    if (uidState2.pendingStateCommitTime != 0) {
                                                        pw.print("    pendingStateCommitTime=");
                                                        nowElapsed = now8;
                                                        TimeUtils.formatDuration(uidState2.pendingStateCommitTime, nowElapsed, pw);
                                                        pw.println();
                                                    } else {
                                                        nowElapsed = now8;
                                                    }
                                                    if (uidState2.startNesting != 0) {
                                                        pw.print("    startNesting=");
                                                        pw.println(uidState2.startNesting);
                                                    }
                                                    if (uidState2.foregroundOps != null && (dumpUid4 < 0 || dumpUid4 == 4)) {
                                                        pw.println("    foregroundOps:");
                                                        for (int j7 = 0; j7 < uidState2.foregroundOps.size(); j7++) {
                                                            if (dumpOp < 0 || dumpOp == uidState2.foregroundOps.keyAt(j7)) {
                                                                pw.print("      ");
                                                                pw.print(AppOpsManager.opToName(uidState2.foregroundOps.keyAt(j7)));
                                                                pw.print(": ");
                                                                pw.println(uidState2.foregroundOps.valueAt(j7) ? "WATCHER" : "SILENT");
                                                            }
                                                        }
                                                        pw.print("    hasForegroundWatchers=");
                                                        pw.println(uidState2.hasForegroundWatchers);
                                                    }
                                                    needSep = true;
                                                    if (opModes != null) {
                                                        int opModeCount3 = opModes.size();
                                                        int j8 = 0;
                                                        while (j8 < opModeCount3) {
                                                            int code = opModes.keyAt(j8);
                                                            int mode2 = opModes.valueAt(j8);
                                                            if (dumpOp >= 0) {
                                                                opModeCount = opModeCount3;
                                                                opModeCount2 = code;
                                                                if (dumpOp != opModeCount2) {
                                                                    nowElapsed3 = nowElapsed;
                                                                }
                                                                j8++;
                                                                opModeCount3 = opModeCount;
                                                                nowElapsed = nowElapsed3;
                                                            } else {
                                                                opModeCount = opModeCount3;
                                                                opModeCount2 = code;
                                                            }
                                                            if (dumpUid4 >= 0) {
                                                                nowElapsed3 = nowElapsed;
                                                                mode = mode2;
                                                                if (dumpUid4 != mode) {
                                                                }
                                                                j8++;
                                                                opModeCount3 = opModeCount;
                                                                nowElapsed = nowElapsed3;
                                                            } else {
                                                                nowElapsed3 = nowElapsed;
                                                                mode = mode2;
                                                            }
                                                            pw.print("      ");
                                                            pw.print(AppOpsManager.opToName(opModeCount2));
                                                            pw.print(": mode=");
                                                            pw.println(AppOpsManager.modeToName(mode));
                                                            j8++;
                                                            opModeCount3 = opModeCount;
                                                            nowElapsed = nowElapsed3;
                                                        }
                                                        nowElapsed2 = nowElapsed;
                                                    } else {
                                                        nowElapsed2 = nowElapsed;
                                                    }
                                                    if (pkgOps2 == null) {
                                                        dumpPackage = dumpPackage;
                                                        dumpUid4 = dumpUid4;
                                                        sdf4 = sdf4;
                                                        now = now;
                                                        dumpOp = dumpOp;
                                                        now8 = nowElapsed2;
                                                    } else {
                                                        int pkgi2 = 0;
                                                        while (pkgi2 < pkgOps2.size()) {
                                                            Ops ops2 = pkgOps2.valueAt(pkgi2);
                                                            if (dumpPackage == null || dumpPackage.equals(ops2.packageName)) {
                                                                boolean printedPackage2 = false;
                                                                int j9 = 0;
                                                                while (true) {
                                                                    dumpPackage2 = dumpPackage;
                                                                    try {
                                                                        if (j9 >= ops2.size()) {
                                                                            break;
                                                                        }
                                                                        Op op4 = ops2.valueAt(j9);
                                                                        ArrayMap<String, Ops> pkgOps3 = pkgOps2;
                                                                        int opCode = op4.op;
                                                                        if (dumpOp < 0 || dumpOp == opCode) {
                                                                            if (dumpUid4 >= 0) {
                                                                                j = j9;
                                                                                try {
                                                                                    int j10 = op4.mode;
                                                                                    if (dumpUid4 != j10) {
                                                                                    }
                                                                                    int i9 = j2 + 1;
                                                                                    dumpOp = dumpOp;
                                                                                    nowElapsed2 = now6;
                                                                                    dumpUid4 = dumpUid4;
                                                                                    now = now5;
                                                                                    sdf4 = sdf3;
                                                                                    pkgOps2 = pkgOps3;
                                                                                    ops2 = ops2;
                                                                                    j9 = i9;
                                                                                    dumpPackage = dumpPackage2;
                                                                                    uidState2 = uidState2;
                                                                                } catch (Throwable th5) {
                                                                                    th = th5;
                                                                                }
                                                                            } else {
                                                                                j = j9;
                                                                            }
                                                                            if (printedPackage2) {
                                                                                printedPackage = printedPackage2;
                                                                            } else {
                                                                                pw.print("    Package ");
                                                                                pw.print(ops2.packageName);
                                                                                pw.println(":");
                                                                                printedPackage = true;
                                                                            }
                                                                            pw.print("      ");
                                                                            pw.print(AppOpsManager.opToName(opCode));
                                                                            pw.print(" (");
                                                                            pw.print(AppOpsManager.modeToName(op4.mode));
                                                                            int switchOp = AppOpsManager.opToSwitch(opCode);
                                                                            if (switchOp != opCode) {
                                                                                pw.print(" / switch ");
                                                                                pw.print(AppOpsManager.opToName(switchOp));
                                                                                Op switchObj = ops2.get(switchOp);
                                                                                int mode3 = switchObj != null ? switchObj.mode : AppOpsManager.opToDefaultMode(switchOp);
                                                                                pw.print("=");
                                                                                pw.print(AppOpsManager.modeToName(mode3));
                                                                            }
                                                                            pw.println("): ");
                                                                            sdf3 = sdf4;
                                                                            long j11 = nowElapsed2;
                                                                            j2 = j;
                                                                            now5 = now;
                                                                            now6 = j11;
                                                                            dumpStatesLocked(pw, op4, now5, sdf3, date2, "          ");
                                                                            if (op4.running) {
                                                                                pw.print("          Running start at: ");
                                                                                TimeUtils.formatDuration(now6 - op4.startRealtime, pw);
                                                                                pw.println();
                                                                            }
                                                                            if (op4.startNesting != 0) {
                                                                                pw.print("          startNesting=");
                                                                                pw.println(op4.startNesting);
                                                                            }
                                                                            printedPackage2 = printedPackage;
                                                                            int i10 = j2 + 1;
                                                                            dumpOp = dumpOp;
                                                                            nowElapsed2 = now6;
                                                                            dumpUid4 = dumpUid4;
                                                                            now = now5;
                                                                            sdf4 = sdf3;
                                                                            pkgOps2 = pkgOps3;
                                                                            ops2 = ops2;
                                                                            j9 = i10;
                                                                            dumpPackage = dumpPackage2;
                                                                            uidState2 = uidState2;
                                                                        } else {
                                                                            j = j9;
                                                                        }
                                                                        sdf3 = sdf4;
                                                                        now5 = now;
                                                                        now6 = nowElapsed2;
                                                                        j2 = j;
                                                                        int i11 = j2 + 1;
                                                                        dumpOp = dumpOp;
                                                                        nowElapsed2 = now6;
                                                                        dumpUid4 = dumpUid4;
                                                                        now = now5;
                                                                        sdf4 = sdf3;
                                                                        pkgOps2 = pkgOps3;
                                                                        ops2 = ops2;
                                                                        j9 = i11;
                                                                        dumpPackage = dumpPackage2;
                                                                        uidState2 = uidState2;
                                                                    } catch (Throwable th6) {
                                                                        th = th6;
                                                                    }
                                                                    throw th;
                                                                }
                                                                dumpMode = dumpUid4;
                                                                pkgOps = pkgOps2;
                                                                uidState = uidState2;
                                                                dumpPackage3 = dumpPackage2;
                                                                now3 = now;
                                                                now4 = nowElapsed2;
                                                                sdf2 = sdf4;
                                                                dumpOp2 = dumpOp;
                                                            } else {
                                                                dumpMode = dumpUid4;
                                                                pkgOps = pkgOps2;
                                                                uidState = uidState2;
                                                                sdf2 = sdf4;
                                                                now3 = now;
                                                                dumpPackage3 = dumpPackage;
                                                                dumpOp2 = dumpOp;
                                                                now4 = nowElapsed2;
                                                            }
                                                            pkgi2++;
                                                            dumpPackage = dumpPackage3;
                                                            dumpOp = dumpOp2;
                                                            nowElapsed2 = now4;
                                                            uidState2 = uidState;
                                                            dumpUid4 = dumpMode;
                                                            now = now3;
                                                            sdf4 = sdf2;
                                                            pkgOps2 = pkgOps;
                                                        }
                                                        dumpUid4 = dumpUid4;
                                                        sdf4 = sdf4;
                                                        now = now;
                                                        dumpPackage = dumpPackage;
                                                        dumpOp = dumpOp;
                                                        now8 = nowElapsed2;
                                                    }
                                                    i8++;
                                                    dumpPackage = dumpPackage;
                                                    dumpOp = dumpOp;
                                                    dumpOp3 = dumpOp3;
                                                    now8 = now8;
                                                    dumpWatchers = dumpWatchers2;
                                                    dumpUid4 = dumpUid4;
                                                    now = now;
                                                } catch (Throwable th7) {
                                                    th = th7;
                                                }
                                            }
                                            needSep = needSep;
                                            i8++;
                                            dumpPackage = dumpPackage;
                                            dumpOp = dumpOp;
                                            dumpOp3 = dumpOp3;
                                            now8 = now8;
                                            dumpWatchers = dumpWatchers2;
                                            dumpUid4 = dumpUid4;
                                            now = now;
                                        }
                                        String dumpPackage5 = dumpPackage;
                                        int dumpMode4 = dumpUid4;
                                        int i12 = dumpOp3;
                                        boolean dumpWatchers4 = dumpWatchers;
                                        long now9 = now;
                                        int dumpOp6 = dumpOp;
                                        if (needSep) {
                                            pw.println();
                                        }
                                        int userRestrictionCount2 = this.mOpUserRestrictions.size();
                                        int i13 = 0;
                                        while (i13 < userRestrictionCount2) {
                                            IBinder token = this.mOpUserRestrictions.keyAt(i13);
                                            ClientRestrictionState restrictionState2 = this.mOpUserRestrictions.valueAt(i13);
                                            boolean printedTokenHeader = false;
                                            if (dumpMode4 >= 0 || dumpWatchers4) {
                                                userRestrictionCount = userRestrictionCount2;
                                                now2 = now9;
                                                sdf = sdf4;
                                                date = date2;
                                            } else if (i12 != 0) {
                                                userRestrictionCount = userRestrictionCount2;
                                                now2 = now9;
                                                sdf = sdf4;
                                                date = date2;
                                            } else {
                                                int restrictionCount = restrictionState2.perUserRestrictions != null ? restrictionState2.perUserRestrictions.size() : 0;
                                                if (restrictionCount <= 0 || dumpPackage5 != null) {
                                                    userRestrictionCount = userRestrictionCount2;
                                                    now2 = now9;
                                                    sdf = sdf4;
                                                    date = date2;
                                                } else {
                                                    boolean printedOpsHeader = false;
                                                    int j12 = 0;
                                                    while (j12 < restrictionCount) {
                                                        int userRestrictionCount3 = userRestrictionCount2;
                                                        int userId = restrictionState2.perUserRestrictions.keyAt(j12);
                                                        long now10 = now9;
                                                        boolean[] restrictedOps = restrictionState2.perUserRestrictions.valueAt(j12);
                                                        if (restrictedOps != null && (dumpOp6 < 0 || (dumpOp6 < restrictedOps.length && restrictedOps[dumpOp6]))) {
                                                            if (!printedTokenHeader) {
                                                                pw.println("  User restrictions for token " + token + ":");
                                                                printedTokenHeader = true;
                                                            }
                                                            if (!printedOpsHeader) {
                                                                pw.println("      Restricted ops:");
                                                                printedOpsHeader = true;
                                                            }
                                                            StringBuilder restrictedOpsValue = new StringBuilder();
                                                            restrictedOpsValue.append("[");
                                                            int k = 0;
                                                            for (int restrictedOpCount = restrictedOps.length; k < restrictedOpCount; restrictedOpCount = restrictedOpCount) {
                                                                if (restrictedOps[k]) {
                                                                    if (restrictedOpsValue.length() > 1) {
                                                                        restrictedOpsValue.append(", ");
                                                                    }
                                                                    restrictedOpsValue.append(AppOpsManager.opToName(k));
                                                                }
                                                                k++;
                                                                restrictedOps = restrictedOps;
                                                            }
                                                            restrictedOpsValue.append("]");
                                                            pw.print("        ");
                                                            pw.print("user: ");
                                                            pw.print(userId);
                                                            pw.print(" restricted ops: ");
                                                            pw.println(restrictedOpsValue);
                                                        } else {
                                                            sdf4 = sdf4;
                                                        }
                                                        j12++;
                                                        userRestrictionCount2 = userRestrictionCount3;
                                                        now9 = now10;
                                                        date2 = date2;
                                                        sdf4 = sdf4;
                                                    }
                                                    userRestrictionCount = userRestrictionCount2;
                                                    now2 = now9;
                                                    sdf = sdf4;
                                                    date = date2;
                                                }
                                                int excludedPackageCount = restrictionState2.perUserExcludedPackages != null ? restrictionState2.perUserExcludedPackages.size() : 0;
                                                if (excludedPackageCount > 0 && dumpOp6 < 0) {
                                                    boolean printedPackagesHeader = false;
                                                    int j13 = 0;
                                                    while (j13 < excludedPackageCount) {
                                                        int userId2 = restrictionState2.perUserExcludedPackages.keyAt(j13);
                                                        String[] packageNames = restrictionState2.perUserExcludedPackages.valueAt(j13);
                                                        if (packageNames == null) {
                                                            excludedPackageCount = excludedPackageCount;
                                                            restrictionState = restrictionState2;
                                                        } else {
                                                            if (dumpPackage5 != null) {
                                                                hasPackage = false;
                                                                int length = packageNames.length;
                                                                int excludedPackageCount2 = 0;
                                                                while (true) {
                                                                    if (excludedPackageCount2 >= length) {
                                                                        restrictionState = restrictionState2;
                                                                        break;
                                                                    }
                                                                    String pkg = packageNames[excludedPackageCount2];
                                                                    restrictionState = restrictionState2;
                                                                    if (dumpPackage5.equals(pkg)) {
                                                                        hasPackage = true;
                                                                        break;
                                                                    } else {
                                                                        excludedPackageCount2++;
                                                                        restrictionState2 = restrictionState;
                                                                    }
                                                                }
                                                            } else {
                                                                restrictionState = restrictionState2;
                                                                hasPackage = true;
                                                            }
                                                            if (hasPackage) {
                                                                if (!printedTokenHeader) {
                                                                    pw.println("  User restrictions for token " + token + ":");
                                                                    printedTokenHeader = true;
                                                                }
                                                                if (!printedPackagesHeader) {
                                                                    pw.println("      Excluded packages:");
                                                                    printedPackagesHeader = true;
                                                                }
                                                                pw.print("        ");
                                                                pw.print("user: ");
                                                                pw.print(userId2);
                                                                pw.print(" packages: ");
                                                                pw.println(Arrays.toString(packageNames));
                                                            }
                                                        }
                                                        j13++;
                                                        excludedPackageCount = excludedPackageCount;
                                                        restrictionState2 = restrictionState;
                                                    }
                                                }
                                            }
                                            i13++;
                                            userRestrictionCount2 = userRestrictionCount;
                                            now9 = now2;
                                            date2 = date;
                                            sdf4 = sdf;
                                        }
                                        if (i12 == 0 || dumpWatchers4) {
                                            return;
                                        }
                                        this.mHistoricalRegistry.dump("  ", pw, dumpUid2, dumpPackage5, dumpOp6);
                                    } catch (Throwable th8) {
                                        th = th8;
                                    }
                                } catch (Throwable th9) {
                                    th = th9;
                                }
                            } catch (Throwable th10) {
                                th = th10;
                            }
                        }
                    }

                    private static final class Restriction {
                        private static final ArraySet<String> NO_EXCEPTIONS = new ArraySet<>();
                        ArraySet<String> exceptionPackages;
                        int mode;

                        private Restriction() {
                            this.exceptionPackages = NO_EXCEPTIONS;
                        }
                    }

                    public void setUserRestrictions(Bundle restrictions, IBinder token, int userHandle) {
                        checkSystemUid("setUserRestrictions");
                        Preconditions.checkNotNull(restrictions);
                        Preconditions.checkNotNull(token);
                        for (int i = 0; i < 91; i++) {
                            String restriction = AppOpsManager.opToRestriction(i);
                            if (restriction != null) {
                                setUserRestrictionNoCheck(i, restrictions.getBoolean(restriction, false), token, userHandle, null);
                            }
                        }
                    }

                    public void setUserRestriction(int code, boolean restricted, IBinder token, int userHandle, String[] exceptionPackages) {
                        if (Binder.getCallingPid() != Process.myPid()) {
                            this.mContext.enforcePermission("android.permission.MANAGE_APP_OPS_RESTRICTIONS", Binder.getCallingPid(), Binder.getCallingUid(), null);
                        }
                        if (userHandle != UserHandle.getCallingUserId() && this.mContext.checkCallingOrSelfPermission("android.permission.INTERACT_ACROSS_USERS_FULL") != 0 && this.mContext.checkCallingOrSelfPermission("android.permission.INTERACT_ACROSS_USERS") != 0) {
                            throw new SecurityException("Need INTERACT_ACROSS_USERS_FULL or INTERACT_ACROSS_USERS to interact cross user ");
                        }
                        verifyIncomingOp(code);
                        Preconditions.checkNotNull(token);
                        setUserRestrictionNoCheck(code, restricted, token, userHandle, exceptionPackages);
                    }

                    private void setUserRestrictionNoCheck(int code, boolean restricted, IBinder token, int userHandle, String[] exceptionPackages) {
                        synchronized (this) {
                            ClientRestrictionState restrictionState = this.mOpUserRestrictions.get(token);
                            if (restrictionState == null) {
                                try {
                                    restrictionState = new ClientRestrictionState(token);
                                    this.mOpUserRestrictions.put(token, restrictionState);
                                } catch (RemoteException e) {
                                    return;
                                }
                            }
                            if (restrictionState.setRestriction(code, restricted, exceptionPackages, userHandle)) {
                                this.mHandler.sendMessage(PooledLambda.obtainMessage($$Lambda$AppOpsService$GUeKjlbzT65s86vaxy5gvOajuhw.INSTANCE, this, Integer.valueOf(code), -2));
                            }
                            if (restrictionState.isDefault()) {
                                this.mOpUserRestrictions.remove(token);
                                restrictionState.destroy();
                            }
                        }
                    }

                    /* JADX INFO: Access modifiers changed from: private */
                    public void notifyWatchersOfChange(int code, int uid) {
                        synchronized (this) {
                            ArraySet<ModeCallback> callbacks = this.mOpModeWatchers.get(code);
                            if (callbacks == null) {
                                return;
                            }
                            ArraySet<ModeCallback> clonedCallbacks = new ArraySet<>(callbacks);
                            notifyOpChanged(clonedCallbacks, code, uid, (String) null);
                        }
                    }

                    public void removeUser(int userHandle) throws RemoteException {
                        checkSystemUid("removeUser");
                        synchronized (this) {
                            int tokenCount = this.mOpUserRestrictions.size();
                            for (int i = tokenCount - 1; i >= 0; i--) {
                                ClientRestrictionState opRestrictions = this.mOpUserRestrictions.valueAt(i);
                                opRestrictions.removeUser(userHandle);
                            }
                            removeUidsForUserLocked(userHandle);
                        }
                    }

                    public boolean isOperationActive(int code, int uid, String packageName) {
                        if (Binder.getCallingUid() != uid && this.mContext.checkCallingOrSelfPermission("android.permission.WATCH_APPOPS") != 0) {
                            return false;
                        }
                        verifyIncomingOp(code);
                        String resolvedPackageName = resolvePackageName(uid, packageName);
                        if (resolvedPackageName == null) {
                            return false;
                        }
                        synchronized (this) {
                            for (int i = this.mClients.size() - 1; i >= 0; i--) {
                                ClientState client = this.mClients.valueAt(i);
                                for (int j = client.mStartedOps.size() - 1; j >= 0; j--) {
                                    Op op = client.mStartedOps.get(j);
                                    if (op.op == code && op.uidState.uid == uid) {
                                        return true;
                                    }
                                }
                            }
                            return false;
                        }
                    }

                    public void setHistoryParameters(int mode, long baseSnapshotInterval, int compressionStep) {
                        this.mContext.enforceCallingOrSelfPermission("android.permission.MANAGE_APPOPS", "setHistoryParameters");
                        this.mHistoricalRegistry.setHistoryParameters(mode, baseSnapshotInterval, compressionStep);
                    }

                    public void offsetHistory(long offsetMillis) {
                        this.mContext.enforceCallingOrSelfPermission("android.permission.MANAGE_APPOPS", "offsetHistory");
                        this.mHistoricalRegistry.offsetHistory(offsetMillis);
                    }

                    public void addHistoricalOps(AppOpsManager.HistoricalOps ops) {
                        this.mContext.enforceCallingOrSelfPermission("android.permission.MANAGE_APPOPS", "addHistoricalOps");
                        this.mHistoricalRegistry.addHistoricalOps(ops);
                    }

                    public void resetHistoryParameters() {
                        this.mContext.enforceCallingOrSelfPermission("android.permission.MANAGE_APPOPS", "resetHistoryParameters");
                        this.mHistoricalRegistry.resetHistoryParameters();
                    }

                    public void clearHistory() {
                        this.mContext.enforceCallingOrSelfPermission("android.permission.MANAGE_APPOPS", "clearHistory");
                        this.mHistoricalRegistry.clearHistory();
                    }

                    private void removeUidsForUserLocked(int userHandle) {
                        for (int i = this.mUidStates.size() - 1; i >= 0; i--) {
                            int uid = this.mUidStates.keyAt(i);
                            if (UserHandle.getUserId(uid) == userHandle) {
                                this.mUidStates.removeAt(i);
                            }
                        }
                    }

                    private void checkSystemUid(String function) {
                        int uid = Binder.getCallingUid();
                        if (uid != 1000) {
                            throw new SecurityException(function + " must by called by the system");
                        }
                    }

                    private static String resolvePackageName(int uid, String packageName) {
                        if (uid == 0) {
                            return "root";
                        }
                        if (uid == 2000) {
                            return NotificationShellCmd.NOTIFICATION_PACKAGE;
                        }
                        if (uid == 1013) {
                            return "media";
                        }
                        if (uid == 1041) {
                            return "audioserver";
                        }
                        if (uid == 1047) {
                            return "cameraserver";
                        }
                        if (uid == 1000 && packageName == null) {
                            return PackageManagerService.PLATFORM_PACKAGE_NAME;
                        }
                        return packageName;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
                    public static int resolveUid(String packageName) {
                        byte b;
                        if (packageName == null) {
                            return -1;
                        }
                        switch (packageName) {
                            case "cameraserver":
                                b = 4;
                                break;
                            case "root":
                                b = 0;
                                break;
                            case "media":
                                b = 2;
                                break;
                            case "shell":
                                b = 1;
                                break;
                            case "audioserver":
                                b = 3;
                                break;
                            default:
                                b = -1;
                                break;
                        }
                        if (b == 0) {
                            return 0;
                        }
                        if (b == 1) {
                            return 2000;
                        }
                        if (b == 2) {
                            return 1013;
                        }
                        if (b == 3) {
                            return 1041;
                        }
                        if (b != 4) {
                            return -1;
                        }
                        return 1047;
                    }

                    private static String[] getPackagesForUid(int uid) {
                        String[] packageNames = null;
                        if (AppGlobals.getPackageManager() != null) {
                            try {
                                packageNames = AppGlobals.getPackageManager().getPackagesForUid(uid);
                            } catch (RemoteException e) {
                            }
                        }
                        if (packageNames == null) {
                            return EmptyArray.STRING;
                        }
                        return packageNames;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
                    final class ClientRestrictionState implements IBinder.DeathRecipient {
                        SparseArray<String[]> perUserExcludedPackages;
                        SparseArray<boolean[]> perUserRestrictions;
                        private final IBinder token;

                        public ClientRestrictionState(IBinder token) throws RemoteException {
                            token.linkToDeath(this, 0);
                            this.token = token;
                        }

                        public boolean setRestriction(int code, boolean restricted, String[] excludedPackages, int userId) {
                            int[] users;
                            boolean changed = false;
                            if (this.perUserRestrictions == null && restricted) {
                                this.perUserRestrictions = new SparseArray<>();
                            }
                            if (userId == -1) {
                                List<UserInfo> liveUsers = UserManager.get(AppOpsService.this.mContext).getUsers(false);
                                users = new int[liveUsers.size()];
                                for (int i = 0; i < liveUsers.size(); i++) {
                                    users[i] = liveUsers.get(i).id;
                                }
                            } else {
                                users = new int[]{userId};
                            }
                            if (this.perUserRestrictions != null) {
                                for (int thisUserId : users) {
                                    boolean[] userRestrictions = this.perUserRestrictions.get(thisUserId);
                                    if (userRestrictions == null && restricted) {
                                        userRestrictions = new boolean[91];
                                        this.perUserRestrictions.put(thisUserId, userRestrictions);
                                    }
                                    if (userRestrictions != null && userRestrictions[code] != restricted) {
                                        userRestrictions[code] = restricted;
                                        if (!restricted && isDefault(userRestrictions)) {
                                            this.perUserRestrictions.remove(thisUserId);
                                            userRestrictions = null;
                                        }
                                        changed = true;
                                    }
                                    if (userRestrictions != null) {
                                        boolean noExcludedPackages = ArrayUtils.isEmpty(excludedPackages);
                                        if (this.perUserExcludedPackages == null && !noExcludedPackages) {
                                            this.perUserExcludedPackages = new SparseArray<>();
                                        }
                                        SparseArray<String[]> sparseArray = this.perUserExcludedPackages;
                                        if (sparseArray != null && !Arrays.equals(excludedPackages, sparseArray.get(thisUserId))) {
                                            if (noExcludedPackages) {
                                                this.perUserExcludedPackages.remove(thisUserId);
                                                if (this.perUserExcludedPackages.size() <= 0) {
                                                    this.perUserExcludedPackages = null;
                                                }
                                            } else {
                                                this.perUserExcludedPackages.put(thisUserId, excludedPackages);
                                            }
                                            changed = true;
                                        }
                                    }
                                }
                            }
                            return changed;
                        }

                        public boolean hasRestriction(int restriction, String packageName, int userId) {
                            boolean[] restrictions;
                            String[] perUserExclusions;
                            SparseArray<boolean[]> sparseArray = this.perUserRestrictions;
                            if (sparseArray == null || (restrictions = sparseArray.get(userId)) == null || !restrictions[restriction]) {
                                return false;
                            }
                            SparseArray<String[]> sparseArray2 = this.perUserExcludedPackages;
                            if (sparseArray2 == null || (perUserExclusions = sparseArray2.get(userId)) == null) {
                                return true;
                            }
                            return true ^ ArrayUtils.contains(perUserExclusions, packageName);
                        }

                        public void removeUser(int userId) {
                            SparseArray<String[]> sparseArray = this.perUserExcludedPackages;
                            if (sparseArray != null) {
                                sparseArray.remove(userId);
                                if (this.perUserExcludedPackages.size() <= 0) {
                                    this.perUserExcludedPackages = null;
                                }
                            }
                            SparseArray<boolean[]> sparseArray2 = this.perUserRestrictions;
                            if (sparseArray2 != null) {
                                sparseArray2.remove(userId);
                                if (this.perUserRestrictions.size() <= 0) {
                                    this.perUserRestrictions = null;
                                }
                            }
                        }

                        public boolean isDefault() {
                            SparseArray<boolean[]> sparseArray = this.perUserRestrictions;
                            return sparseArray == null || sparseArray.size() <= 0;
                        }

                        @Override // android.os.IBinder.DeathRecipient
                        public void binderDied() {
                            synchronized (AppOpsService.this) {
                                AppOpsService.this.mOpUserRestrictions.remove(this.token);
                                if (this.perUserRestrictions == null) {
                                    return;
                                }
                                int userCount = this.perUserRestrictions.size();
                                for (int i = 0; i < userCount; i++) {
                                    boolean[] restrictions = this.perUserRestrictions.valueAt(i);
                                    int restrictionCount = restrictions.length;
                                    for (int j = 0; j < restrictionCount; j++) {
                                        if (restrictions[j]) {
                                            final int changedCode = j;
                                            AppOpsService.this.mHandler.post(new Runnable() { // from class: com.android.server.appop.-$$Lambda$AppOpsService$ClientRestrictionState$uMVYManZlOG3nljcsmHU5SaC48k
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    this.f$0.lambda$binderDied$0$AppOpsService$ClientRestrictionState(changedCode);
                                                }
                                            });
                                        }
                                    }
                                }
                                destroy();
                            }
                        }

                        public /* synthetic */ void lambda$binderDied$0$AppOpsService$ClientRestrictionState(int changedCode) {
                            AppOpsService.this.notifyWatchersOfChange(changedCode, -2);
                        }

                        public void destroy() {
                            this.token.unlinkToDeath(this, 0);
                        }

                        private boolean isDefault(boolean[] array) {
                            if (ArrayUtils.isEmpty(array)) {
                                return true;
                            }
                            for (boolean value : array) {
                                if (value) {
                                    return false;
                                }
                            }
                            return true;
                        }
                    }

                    private final class AppOpsManagerInternalImpl extends AppOpsManagerInternal {
                        private AppOpsManagerInternalImpl() {
                        }

                        public void setDeviceAndProfileOwners(SparseIntArray owners) {
                            synchronized (AppOpsService.this) {
                                AppOpsService.this.mProfileOwners = owners;
                            }
                        }

                        public void setUidMode(int code, int uid, int mode) throws Throwable {
                            AppOpsService.this.setUidMode(code, uid, mode);
                        }

                        public void setAllPkgModesToDefault(int code, int uid) {
                            AppOpsService.this.setAllPkgModesToDefault(code, uid);
                        }

                        public int checkOperationUnchecked(int code, int uid, String packageName) {
                            return AppOpsService.this.checkOperationUnchecked(code, uid, packageName, true, false);
                        }
                    }
                }
