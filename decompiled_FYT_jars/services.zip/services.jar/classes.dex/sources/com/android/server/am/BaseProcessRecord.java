package com.android.server.am;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
class BaseProcessRecord {
    int protectStatus = 0;
    int protectMinAdj = 0;
    int protectMaxAdj = 0;

    BaseProcessRecord() {
    }
}
