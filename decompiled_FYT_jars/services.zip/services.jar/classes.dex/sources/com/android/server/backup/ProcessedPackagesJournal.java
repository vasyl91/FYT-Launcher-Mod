package com.android.server.backup;

import android.util.Slog;
import com.android.internal.annotations.GuardedBy;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
final class ProcessedPackagesJournal {
    private static final boolean DEBUG = true;
    private static final String JOURNAL_FILE_NAME = "processed";
    private static final String TAG = "ProcessedPackagesJournal";

    @GuardedBy({"mProcessedPackages"})
    private final Set<String> mProcessedPackages = new HashSet();
    private final File mStateDirectory;

    ProcessedPackagesJournal(File stateDirectory) {
        this.mStateDirectory = stateDirectory;
    }

    void init() {
        synchronized (this.mProcessedPackages) {
            loadFromDisk();
        }
    }

    boolean hasBeenProcessed(String packageName) {
        boolean zContains;
        synchronized (this.mProcessedPackages) {
            zContains = this.mProcessedPackages.contains(packageName);
        }
        return zContains;
    }

    void addPackage(String packageName) {
        synchronized (this.mProcessedPackages) {
            if (!this.mProcessedPackages.add(packageName)) {
                return;
            }
            File journalFile = new File(this.mStateDirectory, JOURNAL_FILE_NAME);
            try {
                RandomAccessFile out = new RandomAccessFile(journalFile, "rws");
                try {
                    out.seek(out.length());
                    out.writeUTF(packageName);
                    $closeResource(null, out);
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        $closeResource(th, out);
                        throw th2;
                    }
                }
            } catch (IOException e) {
                Slog.e(TAG, "Can't log backup of " + packageName + " to " + journalFile);
            }
        }
    }

    private static /* synthetic */ void $closeResource(Throwable x0, AutoCloseable x1) throws Exception {
        if (x0 == null) {
            x1.close();
            return;
        }
        try {
            x1.close();
        } catch (Throwable th) {
            x0.addSuppressed(th);
        }
    }

    Set<String> getPackagesCopy() {
        HashSet hashSet;
        synchronized (this.mProcessedPackages) {
            hashSet = new HashSet(this.mProcessedPackages);
        }
        return hashSet;
    }

    void reset() {
        synchronized (this.mProcessedPackages) {
            this.mProcessedPackages.clear();
            File journalFile = new File(this.mStateDirectory, JOURNAL_FILE_NAME);
            journalFile.delete();
        }
    }

    private void loadFromDisk() throws Exception {
        File journalFile = new File(this.mStateDirectory, JOURNAL_FILE_NAME);
        if (!journalFile.exists()) {
            return;
        }
        try {
            DataInputStream oldJournal = new DataInputStream(new BufferedInputStream(new FileInputStream(journalFile)));
            while (true) {
                try {
                    String packageName = oldJournal.readUTF();
                    Slog.v(TAG, "   + " + packageName);
                    this.mProcessedPackages.add(packageName);
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        $closeResource(th, oldJournal);
                        throw th2;
                    }
                }
            }
        } catch (EOFException e) {
        } catch (IOException e2) {
            Slog.e(TAG, "Error reading processed packages journal", e2);
        }
    }
}
