package com.android.server.backup;

import com.android.server.backup.transport.OnTransportRegisteredListener;

/* JADX INFO: renamed from: com.android.server.backup.-$$Lambda$TransportManager$Z9ckpFUW2V4jkdHnyXIEiLuAoBc, reason: invalid class name */
/* JADX INFO: compiled from: lambda */
/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public final /* synthetic */ class $$Lambda$TransportManager$Z9ckpFUW2V4jkdHnyXIEiLuAoBc implements OnTransportRegisteredListener {
    public static final /* synthetic */ $$Lambda$TransportManager$Z9ckpFUW2V4jkdHnyXIEiLuAoBc INSTANCE = new $$Lambda$TransportManager$Z9ckpFUW2V4jkdHnyXIEiLuAoBc();

    private /* synthetic */ $$Lambda$TransportManager$Z9ckpFUW2V4jkdHnyXIEiLuAoBc() {
    }

    @Override // com.android.server.backup.transport.OnTransportRegisteredListener
    public final void onTransportRegistered(String str, String str2) {
        TransportManager.lambda$new$0(str, str2);
    }
}
