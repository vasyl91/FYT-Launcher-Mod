package com.android.server.am;

import android.app.ActivityDebugConfigs;
import android.app.ActivityManager;
import android.app.AppGlobals;
import android.content.ContentResolver;
import android.os.Binder;
import android.os.Bundle;
import android.provider.Settings;
import android.util.ArrayMap;
import android.util.Log;
import android.util.Slog;
import com.android.server.wm.ActivityTaskManagerDebugConfig;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
class ActivityManagerDebugConfigDynamics {
    private static final String TAG = "ActivityManagerDebugConfigDynamics";
    static ArrayMap<String, Field> sDebugSwitchStateMap;
    static ArrayMap<String, ActivityDebugConfigs.Builder> sPackageDebugConfigsMap = new ArrayMap<>();

    ActivityManagerDebugConfigDynamics() {
    }

    static void printIfNeeded(PrintWriter pw, String message) {
        if (pw != null) {
            pw.println(message);
        } else {
            Slog.w(TAG, message);
        }
    }

    static void ensureMapIfNeeded(PrintWriter pw) {
        if (sDebugSwitchStateMap == null) {
            ArrayMap<String, Field> tempDebugSwitchMap = new ArrayMap<>();
            Field[] amFields = ActivityManagerDebugConfig.class.getDeclaredFields();
            Field[] atmFields = ActivityTaskManagerDebugConfig.class.getDeclaredFields();
            List<Field> debugFields = new ArrayList<>();
            debugFields.addAll(Arrays.asList(amFields));
            debugFields.addAll(Arrays.asList(atmFields));
            for (Field f : debugFields) {
                if (f.getType().getName().equals("boolean") && f.getName().startsWith("DEBUG")) {
                    f.setAccessible(true);
                    tempDebugSwitchMap.put(f.getName(), f);
                }
            }
            sDebugSwitchStateMap = tempDebugSwitchMap;
        }
    }

    static void setBooleanFromFieldSilently(PrintWriter pw, Field field, boolean enabled) {
        try {
            field.setBoolean(null, enabled);
        } catch (IllegalAccessException e) {
            printIfNeeded(pw, "throw the IllegalAccessException when setSwitchEnabled " + e.toString() + "\n" + e.getStackTrace());
        }
    }

    static boolean getBooleanFromFieldSilently(PrintWriter pw, Field field) {
        try {
            boolean enabled = field.getBoolean(null);
            return enabled;
        } catch (IllegalAccessException e) {
            printIfNeeded(pw, "throw the IllegalAccessException when setSwitchEnabled " + e.toString() + "\n" + e.getStackTrace());
            return false;
        }
    }

    static void setSwitchEnabled(String secondInput, boolean enabled, PrintWriter pw) {
        ensureMapIfNeeded(pw);
        Field field = sDebugSwitchStateMap.get(secondInput);
        if (field != null) {
            setBooleanFromFieldSilently(pw, field, enabled);
            printIfNeeded(pw, "\n" + secondInput + " SWITCH was set " + enabled + "\n");
            return;
        }
        printIfNeeded(pw, "\nSorry,your parameter was unsupported: " + secondInput + "\n");
    }

    private static ActivityDebugConfigs.Builder findPackageDebugConfigs(String pkg, PrintWriter pw) {
        ActivityDebugConfigs.Builder builder;
        boolean validPackageName = false;
        try {
            validPackageName = AppGlobals.getPackageManager().getPackageInfo(pkg, 0, 0) != null;
        } catch (Exception e) {
            printIfNeeded(pw, "Caught exception when query package: " + pkg);
            printIfNeeded(pw, e.toString());
            printIfNeeded(pw, Log.getStackTraceString(e));
        }
        if (!(validPackageName | "all".equals(pkg))) {
            printIfNeeded(pw, "Can not find package: " + pkg);
            return null;
        }
        if (pkg.equals("all")) {
            return ActivityDebugConfigs.Builder.getOrCreateGlobal();
        }
        synchronized (sPackageDebugConfigsMap) {
            builder = sPackageDebugConfigsMap.get(pkg);
            if (builder == null) {
                builder = new ActivityDebugConfigs.Builder();
                builder.setPackage(pkg);
                sPackageDebugConfigsMap.put(pkg, builder);
            }
        }
        return builder;
    }

    static void setPackageSwitchEnabled(String pkg, String logSwitch, boolean enabled, PrintWriter pw) {
        if (!ActivityDebugConfigs.Builder.isControlSupported(logSwitch)) {
            printIfNeeded(pw, logSwitch + " may not supported, have you declared with annotation @DebugControl?");
            return;
        }
        ActivityDebugConfigs.Builder builder = findPackageDebugConfigs(pkg, pw);
        if (builder == null) {
            return;
        }
        builder.setEnabled(logSwitch, enabled);
        applyPackageDebugConfigs(builder.build());
        printIfNeeded(pw, "Log switch " + logSwitch + " was set " + enabled + " for package: " + pkg);
    }

    static void setPackageBundle(String pkg, Bundle bundle, PrintWriter pw) {
        ActivityDebugConfigs.Builder builder = findPackageDebugConfigs(pkg, pw);
        if (builder == null) {
            return;
        }
        builder.setExtras(bundle);
        applyPackageDebugConfigs(builder.build());
        printIfNeeded(pw, "Bundle dispatched to package: " + pkg);
    }

    static ActivityDebugConfigs getPackageDebugConfigs(String pkg) {
        ActivityDebugConfigs.Builder builder;
        synchronized (sPackageDebugConfigsMap) {
            builder = sPackageDebugConfigsMap.get(pkg);
        }
        if (builder == null && (builder = ActivityDebugConfigs.Builder.getGlobal()) == null) {
            return null;
        }
        return builder.build();
    }

    static void applyPackageDebugConfigs(ActivityDebugConfigs config) {
        ActivityManagerService am = ActivityManager.getService();
        am.applyPackageDebugConfigs(config);
    }

    static void listSwitchState(String secondInput, String packageName, PrintWriter pw) {
        ActivityDebugConfigs.Builder builder;
        ensureMapIfNeeded(pw);
        if (secondInput != null) {
            if (secondInput.equals("package")) {
                if (packageName != null) {
                    synchronized (sPackageDebugConfigsMap) {
                        builder = sPackageDebugConfigsMap.get(packageName);
                    }
                    if (builder != null) {
                        builder.dump(pw);
                        return;
                    }
                    pw.println("\tPackage " + packageName + " debug control not set");
                    return;
                }
                dumpAllPackageEnabledConfigs(pw);
                return;
            }
            Field field = sDebugSwitchStateMap.get(secondInput);
            if (field != null) {
                pw.println("\n" + field.getName() + " = " + getBooleanFromFieldSilently(pw, field) + "\n");
                return;
            }
            pw.println("\nHi,please check your parameter: " + secondInput + "\n");
            return;
        }
        for (int i = 0; i < sDebugSwitchStateMap.size(); i++) {
            pw.println("\t" + sDebugSwitchStateMap.keyAt(i) + " = " + getBooleanFromFieldSilently(pw, sDebugSwitchStateMap.valueAt(i)));
        }
        dumpAllPackageEnabledConfigs(pw);
    }

    private static void dumpAllPackageEnabledConfigs(PrintWriter pw) {
        pw.println();
        ActivityDebugConfigs.Builder.dumpAllSupportedFlags(pw);
        pw.println();
        pw.println("All package enabled states:");
        synchronized (sPackageDebugConfigsMap) {
            if (sPackageDebugConfigsMap.size() == 0) {
                pw.println("Currently no package debug control enabled");
                return;
            }
            ArrayMap<String, ActivityDebugConfigs.Builder> map = new ArrayMap<>(sPackageDebugConfigsMap);
            for (int i = 0; i < map.size(); i++) {
                pw.println();
                pw.println("Package: " + map.keyAt(i));
                ActivityDebugConfigs.Builder builder = map.valueAt(i);
                if (builder != null) {
                    builder.dump(pw);
                }
            }
        }
    }

    static void resetAllSwitchState(PrintWriter pw) {
        ensureMapIfNeeded(pw);
        for (int i = 0; i < sDebugSwitchStateMap.size(); i++) {
            setBooleanFromFieldSilently(pw, sDebugSwitchStateMap.valueAt(i), false);
        }
        synchronized (sPackageDebugConfigsMap) {
            sPackageDebugConfigsMap.clear();
        }
        ActivityDebugConfigs.Builder.clearGlobal();
        applyPackageDebugConfigs(ActivityDebugConfigs.Builder.getOrCreateGlobal().build());
        ActivityDebugConfigs.Builder.clearGlobal();
        pw.println("\nAll the Log_switch have been reset false\n");
    }

    static String buildEnabledSwitchesString(PrintWriter pw) {
        String enabledSwitchesString = "";
        for (String key : sDebugSwitchStateMap.keySet()) {
            if (getBooleanFromFieldSilently(pw, sDebugSwitchStateMap.get(key))) {
                enabledSwitchesString = enabledSwitchesString + key + ",";
            }
        }
        return enabledSwitchesString;
    }

    static void saveDebugSwtichStates(ContentResolver contentResolver, PrintWriter pw) {
        ensureMapIfNeeded(pw);
        long ident = Binder.clearCallingIdentity();
        Settings.Global.putString(contentResolver, "ams_enabled_debug_switches", buildEnabledSwitchesString(pw));
        Binder.restoreCallingIdentity(ident);
        pw.println("\nAll the Log_switch state have been saved\n");
    }

    static void showLogSwitchHelp(PrintWriter pw) {
        pw.println("usage:");
        pw.println("\tenable <DEBUG_NAME> : only open the switch of DEBUG_NAME.");
        pw.println("\tdisable <DEBUG_NAME> : only close the switch of DEBUG_NAME.");
        pw.println("\tpkg-enable <PACKAGE_NAME> <DEBUG_NAME>: Set package debug control enabled");
        pw.println("\tpkg-disable <PACKAGE_NAME> <DEBUG_NAME>: Set package debug control disabled");
        pw.println("\tpkg-bundle <PACKAGE_NAME> <Bundle Options>: Pass the bundle to package for debug configs");
        pw.println("\tlist [DEBUG_NAME] or list package [PACKAGE_NAME] : list all the debug state, optionally passing DEBUG_NAME only to list the needed.");
        pw.println("\treset : set all the debug state to false.");
        pw.println("\tsave_state : save the debug state to storage zone and read from AMS again when the phone restart. \n");
    }

    static List<String> parseEnabledSwitchKeys(String switchKeys) {
        List<String> enabledDebugSwitchesList = new ArrayList<>();
        if (switchKeys != null && switchKeys.length() > 0) {
            for (String key : switchKeys.split(",")) {
                enabledDebugSwitchesList.add(key);
            }
        }
        return enabledDebugSwitchesList;
    }

    static void restoreDebugSwitchStates(ContentResolver contentResolver) {
        String enabledDebugSwitches = Settings.Global.getString(contentResolver, "ams_enabled_debug_switches");
        List<String> enabledDebugSwitchesList = parseEnabledSwitchKeys(enabledDebugSwitches);
        if (enabledDebugSwitchesList.size() > 0) {
            for (String key : enabledDebugSwitchesList) {
                setSwitchEnabled(key, true, null);
            }
        }
    }
}
