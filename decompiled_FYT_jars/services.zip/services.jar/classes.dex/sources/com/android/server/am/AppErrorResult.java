package com.android.server.am;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
final class AppErrorResult {
    boolean mHasResult = false;
    int mResult;

    AppErrorResult() {
    }

    public void set(int res) {
        synchronized (this) {
            this.mHasResult = true;
            this.mResult = res;
            notifyAll();
        }
    }

    public int get() {
        synchronized (this) {
            while (!this.mHasResult) {
                try {
                    wait();
                } catch (InterruptedException e) {
                }
            }
        }
        return this.mResult;
    }
}
