package com.android.server;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.sprdpower.AbsPowerGuru;
import android.app.sprdpower.PowerGuruAlarmInfo;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.WorkSource;
import android.util.Slog;
import java.util.Calendar;
import java.util.List;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
final class AlarmAlignHelperEx extends AlarmAlignHelper {
    private static final String ALIGN_ENABLE = "persist.sys.heartbeat.enable";
    private static final String ALIGN_LENGTH = "persist.sys.align_length";
    private static final int DEFAULT_ALIGN_LENGTH = 5;
    private static final int DEFAULT_LENGTH = 5;
    private static final long DEFAULT_MIN_FUTURITY = 5000;
    private static final int MAX_LENGTH = 60;
    private static final int MIN_LENGTH = 3;
    private static final String TAG = "AlarmManagerHelperEx";
    private AlarmManagerService mAlarmManager;
    private boolean mAlignEnable;
    private int mAlignLength;
    private List<PowerGuruAlarmInfo> mBeatlist;
    private AbsPowerGuru mPowerGuruService;

    public AlarmAlignHelperEx(Context context) {
        super(context);
        this.mPowerGuruService = (AbsPowerGuru) context.getSystemService("powerguru");
        updateBeatlist();
        this.mAlignLength = 5;
    }

    private long convertToElapsed(long when, int type) {
        boolean isRtc = true;
        if (type != 1 && type != 0 && type != 4 && type != 5 && type != 6) {
            isRtc = false;
        }
        if (isRtc) {
            return when - (System.currentTimeMillis() - SystemClock.elapsedRealtime());
        }
        return when;
    }

    @Override // com.android.server.AlarmAlignHelper
    protected void updateBeatlist() {
        AbsPowerGuru absPowerGuru = this.mPowerGuruService;
        if (absPowerGuru != null) {
            this.mBeatlist = absPowerGuru.getBeatList();
        } else {
            Slog.w(TAG, "updateBeatlist() -> PowerGuruService is not running ???");
        }
    }

    @Override // com.android.server.AlarmAlignHelper
    protected boolean getAlignEnable() {
        return this.mAlignEnable;
    }

    @Override // com.android.server.AlarmAlignHelper
    protected void setAlignEnable(boolean enable) {
        this.mAlignEnable = enable;
    }

    @Override // com.android.server.AlarmAlignHelper
    protected boolean isEnabled() {
        int temp = SystemProperties.getInt(ALIGN_ENABLE, 1);
        return temp == 1;
    }

    @Override // com.android.server.AlarmAlignHelper
    protected boolean checkAlignEnable(int type, PowerGuruAlarmInfo palarm) {
        boolean isWakeup = type == 0 || type == 2;
        return isWakeup && palarm != null && this.mAlignEnable;
    }

    @Override // com.android.server.AlarmAlignHelper
    protected boolean isUnavailableGMS(PowerGuruAlarmInfo guruAlarm) {
        if (guruAlarm != null && guruAlarm.isFromGMS && !guruAlarm.isAvailable) {
            Slog.w(TAG, "setImplLocked() return, this alarm is from GMS and is not available!!!");
            return true;
        }
        return false;
    }

    private int getAlignLength() {
        return this.mAlignLength;
    }

    @Override // com.android.server.AlarmAlignHelper
    public boolean setAlignLength(int length) {
        if (length < 3 || length > MAX_LENGTH || this.mAlignLength == length) {
            return false;
        }
        Slog.d(TAG, "setAlignLength()  oldLength=" + this.mAlignLength + ", newLength=" + length);
        this.mAlignLength = length;
        super.setAlignLength(length);
        return true;
    }

    @Override // com.android.server.AlarmAlignHelper
    protected long adjustTriggerTime(long whenElapsed, long maxWhenElapsed, int type) {
        if ((type != 0 && type != 2) || maxWhenElapsed <= whenElapsed) {
            return -1L;
        }
        long triggerTime = whenElapsed + (System.currentTimeMillis() - SystemClock.elapsedRealtime());
        long triggerTimeAlign = triggerTime - (triggerTime % 1000);
        long adjustedRtcTime = adjustTriggerTimeInternal(triggerTimeAlign, 5);
        long nowRTC = System.currentTimeMillis();
        if (adjustedRtcTime < nowRTC + DEFAULT_MIN_FUTURITY) {
            Slog.w(TAG, "the triggerTime is adjuested to past, so it need adjusted to future time.");
            if (isAlignPoint(nowRTC, 5)) {
                nowRTC += DEFAULT_MIN_FUTURITY;
            }
            adjustedRtcTime = adjustTriggerTimeInternal(nowRTC - (nowRTC % 1000), 5);
        }
        long adjuestedMillis = convertToElapsed(adjustedRtcTime, 0);
        if (adjuestedMillis > maxWhenElapsed) {
            return -1L;
        }
        return adjuestedMillis;
    }

    @Override // com.android.server.AlarmAlignHelper
    protected long adjustTriggerTime(long triggerTime, int type) {
        int alignLength = getAlignLength();
        long triggerTime2 = (type == 2 || type == 3) ? triggerTime + (System.currentTimeMillis() - SystemClock.elapsedRealtime()) : triggerTime;
        long triggerTimeAlign = triggerTime2 - (triggerTime2 % 1000);
        long adjustedRtcTime = adjustTriggerTimeInternal(triggerTimeAlign, alignLength);
        long nowRTC = System.currentTimeMillis();
        if (adjustedRtcTime < nowRTC + DEFAULT_MIN_FUTURITY) {
            Slog.w(TAG, "the triggerTime is adjuested to past, so it need adjusted to future time.");
            if (isAlignPoint(nowRTC, alignLength)) {
                nowRTC += DEFAULT_MIN_FUTURITY;
            }
            adjustedRtcTime = adjustTriggerTimeInternal(nowRTC - (nowRTC % 1000), alignLength);
        }
        long adjuestedMillis = convertToElapsed(adjustedRtcTime, 0);
        return adjuestedMillis;
    }

    private boolean isAlignPoint(long rtcTime, int length) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(rtcTime);
        int minutes = calendar.get(12);
        int seconds = calendar.get(13);
        if (seconds == 0 && minutes % length == 0) {
            return true;
        }
        return false;
    }

    private long adjustTriggerTimeInternal(long rtcTime, int alignLength) {
        if (alignLength <= 0) {
            throw new IllegalStateException("The align length can not be less than 0 !");
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(rtcTime);
        int minute = calendar.get(12);
        int seconds = calendar.get(13);
        int residue = minute / alignLength;
        if (residue == 0) {
            if (minute != 0 || seconds != 0) {
                calendar.set(12, alignLength);
                calendar.set(13, 0);
            }
        } else if (minute % alignLength != 0 || seconds != 0) {
            int alignMinute = (residue + 1) * alignLength;
            if (alignMinute >= MAX_LENGTH) {
                calendar.add(11, 1);
                calendar.set(12, 0);
            } else {
                calendar.set(12, alignMinute);
            }
            calendar.set(13, 0);
        }
        return calendar.getTimeInMillis();
    }

    @Override // com.android.server.AlarmAlignHelper
    protected PowerGuruAlarmInfo matchBeatListPackage(PendingIntent pi) {
        long ident = Binder.clearCallingIdentity();
        if (pi != null) {
            try {
                if (this.mBeatlist != null && this.mBeatlist.size() > 0) {
                    String pn = pi.getCreatorPackage();
                    Intent in = pi.getIntent();
                    String action = null;
                    String component = null;
                    if (in != null) {
                        action = in.getAction();
                        if (in.getComponent() != null) {
                            component = in.getComponent().getClassName();
                        }
                    }
                    for (PowerGuruAlarmInfo palarm : this.mBeatlist) {
                        if (pn.equals(palarm.packageName) && ((action != null && action.equals(palarm.actionName)) || (action == null && palarm.actionName == null))) {
                            if ((component != null && component.equals(palarm.componentName)) || (component == null && palarm.componentName == null)) {
                                return palarm;
                            }
                        }
                    }
                }
            } finally {
                Binder.restoreCallingIdentity(ident);
            }
        }
        return null;
    }

    @Override // com.android.server.AlarmAlignHelper
    protected boolean notifyPowerGuru(int type, long when, long whenElapsed, long windowLength, long maxWhen, long interval, PendingIntent operation) {
        AbsPowerGuru absPowerGuru = this.mPowerGuruService;
        if (absPowerGuru != null) {
            absPowerGuru.notifyPowerguruAlarm(type, when, whenElapsed, windowLength, maxWhen, interval, operation);
            return true;
        }
        return false;
    }

    @Override // com.android.server.AlarmAlignHelper
    protected boolean notifyPowerGuru(int type, long when, long whenElapsed, long windowLength, long maxWhen, long interval, PendingIntent operation, int flags, WorkSource workSource, AlarmManager.AlarmClockInfo alarmClock, int uid, String pkgName) {
        AbsPowerGuru absPowerGuru = this.mPowerGuruService;
        if (absPowerGuru != null) {
            absPowerGuru.notifyAlarm(type, when, whenElapsed, windowLength, maxWhen, interval, operation, flags, workSource, alarmClock, uid, pkgName);
            return true;
        }
        return false;
    }

    @Override // com.android.server.AlarmAlignHelper
    protected boolean noteWakeupAlarm(int uid, String pkgName) {
        AbsPowerGuru absPowerGuru = this.mPowerGuruService;
        if (absPowerGuru != null) {
            absPowerGuru.noteWakeupAlarm(pkgName, uid);
            return true;
        }
        return false;
    }
}
