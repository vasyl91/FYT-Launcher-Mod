package com.android.server;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.sprdpower.AbsPowerGuru;
import android.app.sprdpower.PowerGuruAlarmInfo;
import android.content.Context;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.WorkSource;
import android.util.Slog;
import java.util.List;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class AlarmAlignHelper {
    private static final String TAG = "AlarmManagerHelper";
    protected boolean DEBUG = "1".equals(SystemProperties.get("persist.sys.alarm.debug"));
    protected AlarmManagerService mAlarmManager;
    private boolean mAlignEnable;
    private int mAlignLength;
    private List<PowerGuruAlarmInfo> mBeatlist;
    private AbsPowerGuru mPowerGuruService;

    public AlarmAlignHelper(Context context) {
    }

    protected void updateBeatlist() {
    }

    protected boolean getAlignEnable() {
        return false;
    }

    protected void setAlignEnable(boolean enable) {
        this.mAlignEnable = false;
    }

    public void setAlarmManager(AlarmManagerService alarmManager) {
        this.mAlarmManager = alarmManager;
    }

    protected boolean isEnabled() {
        return false;
    }

    protected boolean checkAlignEnable(int type, PowerGuruAlarmInfo palarm) {
        return false;
    }

    protected boolean isUnavailableGMS(PowerGuruAlarmInfo guruAlarm) {
        if (this.DEBUG) {
            Slog.w(TAG, "isUnavailableGMS return false immediately for no-powerguru feature!!!");
            return false;
        }
        return false;
    }

    private int getAlignLength() {
        return this.mAlignLength;
    }

    protected long adjustTriggerTime(long whenElapsed, long maxWhenElapsed, int type) {
        return -1L;
    }

    protected long adjustTriggerTime(long triggerTime, int type) {
        return 0L;
    }

    private boolean isAlignPoint(long rtcTime, int length) {
        return false;
    }

    private long adjustTriggerTimeInternal(long rtcTime, int alignLength) {
        return 0L;
    }

    protected PowerGuruAlarmInfo matchBeatListPackage(PendingIntent pi) {
        return null;
    }

    protected boolean notifyPowerGuru(int type, long when, long whenElapsed, long windowLength, long maxWhen, long interval, PendingIntent operation) {
        if (this.DEBUG) {
            Slog.w(TAG, "notifyPowerGuru() -> PowerGuruService is not running results from no heartbeat feature ???");
            return false;
        }
        return false;
    }

    protected boolean notifyPowerGuru(int type, long when, long whenElapsed, long windowLength, long maxWhen, long interval, PendingIntent operation, int flags, WorkSource workSource, AlarmManager.AlarmClockInfo alarmClock, int uid, String pkgName) {
        if (this.DEBUG) {
            Slog.w(TAG, "notifyPowerGuru() -> PowerGuruService is not running results from no heartbeat feature ???");
            return false;
        }
        return false;
    }

    protected boolean noteWakeupAlarm(int uid, String pkgName) {
        if (this.DEBUG) {
            Slog.w(TAG, "notifyPowerGuru() -> PowerGuruService is not running results from no heartbeat feature ???");
            return false;
        }
        return false;
    }

    public boolean setHeartBeatAdjustEnable(boolean enable, boolean updated) {
        try {
            Slog.d(TAG, "setHeartBeatAdjustEnable() enable = " + enable + ", updated = " + updated);
            if (updated) {
                updateBeatlist();
            }
            setAlignEnable(enable);
            if (this.mAlarmManager != null) {
                this.mAlarmManager.rebatchAllAlarms();
                return true;
            }
            return true;
        } catch (Exception ex) {
            Slog.d(TAG, "setHeartBeatAdjustEnable occurs Exception!!", ex);
            return false;
        }
    }

    public boolean setAlignLength(int length) {
        Slog.d(TAG, "mAlighHelper setAlighLenth to " + length);
        AlarmManagerService alarmManagerService = this.mAlarmManager;
        if (alarmManagerService != null) {
            alarmManagerService.rebatchAllAlarms();
            return true;
        }
        return true;
    }

    public long checkAndAdjustAlarm(int type, long triggerAtTime, long triggerElapsed, long maxElapsed, PendingIntent operation, int flags, boolean tiggerTimeAdjusted) {
        long j;
        String str;
        if ((flags & 18) == 0) {
            PowerGuruAlarmInfo guruAlarm = matchBeatListPackage(operation);
            if (isUnavailableGMS(guruAlarm)) {
                return 0L;
            }
            if (isEnabled() && checkAlignEnable(type, guruAlarm)) {
                long alignTime = adjustTriggerTime(triggerAtTime, type);
                if (alignTime > SystemClock.elapsedRealtime()) {
                    if (this.DEBUG) {
                        Slog.d(TAG, " alarm type = " + type + ", operation = " + operation + ", triggerAtTime =" + triggerAtTime + ", triggerElapsed =" + triggerElapsed + ", maxElapsed =" + maxElapsed + ", alignTime = " + alignTime + ", guruAlarm" + guruAlarm + ", is adjusted for PowerGuru!!!!");
                    }
                    return alignTime;
                }
            }
        }
        if ((flags & 18) != 0) {
            return triggerElapsed;
        }
        try {
            if (!isEnabled() || !getAlignEnable() || tiggerTimeAdjusted) {
                return triggerElapsed;
            }
            try {
                long alignTime2 = adjustTriggerTime(triggerElapsed, maxElapsed, type);
                try {
                    if (alignTime2 <= SystemClock.elapsedRealtime()) {
                        return triggerElapsed;
                    }
                    if (this.DEBUG) {
                        StringBuilder sb = new StringBuilder();
                        sb.append(" alarm type = ");
                        sb.append(type);
                        sb.append(", operation = ");
                        sb.append(operation);
                        sb.append(", triggerAtTime =");
                        sb.append(triggerAtTime);
                        sb.append(", triggerElapsed =");
                        j = triggerElapsed;
                        try {
                            sb.append(j);
                            sb.append(", maxElapsed =");
                            try {
                                sb.append(maxElapsed);
                                sb.append(", alignTime = ");
                                sb.append(alignTime2);
                                sb.append(", is adjusted!!");
                                String string = sb.toString();
                                str = TAG;
                                try {
                                    Slog.d(str, string);
                                } catch (Exception e) {
                                    e = e;
                                }
                            } catch (Exception e2) {
                                e = e2;
                                str = r14;
                            }
                        } catch (Exception e3) {
                            e = e3;
                        }
                    }
                    return alignTime2;
                } catch (Exception e4) {
                    e = e4;
                    j = triggerElapsed;
                }
                str = r14;
            } catch (Exception e5) {
                e = e5;
                j = triggerElapsed;
                str = r14;
            }
            Slog.w(str, "LSL here is some Exception!!", e);
            return j;
        } catch (Exception e6) {
            e = e6;
            j = triggerElapsed;
        }
    }
}
