package com.android.server.backup.encryption.chunking;

import java.io.IOException;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public interface BackupWriter {
    void flush() throws IOException;

    long getBytesWritten();

    void writeBytes(byte[] bArr) throws IOException;

    void writeChunk(long j, int i) throws IOException;
}
