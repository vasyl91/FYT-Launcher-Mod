package com.android.server.am;

import android.app.ActivityManagerInternal;
import android.app.AppGlobals;
import android.content.IIntentSender;
import android.content.Intent;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.os.UserHandle;
import android.util.ArrayMap;
import android.util.Slog;
import com.android.internal.os.IResultReceiver;
import com.android.internal.util.function.pooled.PooledLambda;
import com.android.server.LocalServices;
import com.android.server.wm.ActivityTaskManagerInternal;
import com.android.server.wm.SafeActivityOptions;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.function.BiConsumer;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class PendingIntentController {
    private static final String TAG = "ActivityManager";
    private static final String TAG_MU = "ActivityManager_MU";
    ActivityManagerInternal mAmInternal;
    final Handler mH;
    final UserController mUserController;
    final Object mLock = new Object();
    final HashMap<PendingIntentRecord.Key, WeakReference<PendingIntentRecord>> mIntentSenderRecords = new HashMap<>();
    final ActivityTaskManagerInternal mAtmInternal = (ActivityTaskManagerInternal) LocalServices.getService(ActivityTaskManagerInternal.class);

    PendingIntentController(Looper looper, UserController userController) {
        this.mH = new Handler(looper);
        this.mUserController = userController;
    }

    void onActivityManagerInternalAdded() {
        synchronized (this.mLock) {
            this.mAmInternal = (ActivityManagerInternal) LocalServices.getService(ActivityManagerInternal.class);
        }
    }

    public PendingIntentRecord getIntentSender(int type, String packageName, int callingUid, int userId, IBinder token, String resultWho, int requestCode, Intent[] intents, String[] resolvedTypes, int flags, Bundle bOptions) throws Throwable {
        Intent intent;
        synchronized (this.mLock) {
            try {
                try {
                    if (ActivityManagerDebugConfig.DEBUG_MU) {
                        Slog.v(TAG_MU, "getIntentSender(): uid=" + callingUid);
                    }
                    if (intents != null) {
                        for (Intent intent2 : intents) {
                            intent2.setDefusable(true);
                        }
                    }
                    Bundle.setDefusable(bOptions, true);
                    boolean noCreate = (flags & 536870912) != 0;
                    boolean cancelCurrent = (flags & 268435456) != 0;
                    boolean updateCurrent = (flags & 134217728) != 0;
                    try {
                        PendingIntentRecord.Key key = new PendingIntentRecord.Key(type, packageName, token, resultWho, requestCode, intents, resolvedTypes, flags & (-939524097), SafeActivityOptions.fromBundle(bOptions), userId);
                        WeakReference<PendingIntentRecord> ref = this.mIntentSenderRecords.get(key);
                        PendingIntentRecord rec = ref != null ? ref.get() : null;
                        if (rec != null) {
                            if (cancelCurrent) {
                                makeIntentSenderCanceled(rec);
                                this.mIntentSenderRecords.remove(key);
                            } else {
                                if (updateCurrent) {
                                    if (rec.key.requestIntent != null) {
                                        Intent intent3 = rec.key.requestIntent;
                                        if (intents == null) {
                                            intent = null;
                                        } else {
                                            intent = intents[intents.length - 1];
                                        }
                                        intent3.replaceExtras(intent);
                                    }
                                    if (intents == null) {
                                        rec.key.allIntents = null;
                                        rec.key.allResolvedTypes = null;
                                    } else {
                                        intents[intents.length - 1] = rec.key.requestIntent;
                                        rec.key.allIntents = intents;
                                        rec.key.allResolvedTypes = resolvedTypes;
                                    }
                                }
                                return rec;
                            }
                        }
                        if (noCreate) {
                            return rec;
                        }
                        PendingIntentRecord rec2 = new PendingIntentRecord(this, key, callingUid);
                        this.mIntentSenderRecords.put(key, rec2.ref);
                        return rec2;
                    } catch (Throwable th) {
                        th = th;
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                }
            } catch (Throwable th3) {
                th = th3;
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:37:0x0063 A[Catch: all -> 0x0084, TryCatch #0 {, blocks: (B:4:0x0004, B:7:0x000d, B:9:0x000f, B:10:0x0019, B:12:0x001f, B:14:0x0027, B:15:0x002b, B:17:0x0033, B:19:0x0039, B:35:0x0061, B:37:0x0063, B:39:0x0070, B:22:0x0040, B:27:0x004c, B:30:0x0053, B:41:0x0082), top: B:46:0x0004 }] */
    /* JADX WARN: Code duplicated, block: B:39:0x0070 A[Catch: all -> 0x0084, TryCatch #0 {, blocks: (B:4:0x0004, B:7:0x000d, B:9:0x000f, B:10:0x0019, B:12:0x001f, B:14:0x0027, B:15:0x002b, B:17:0x0033, B:19:0x0039, B:35:0x0061, B:37:0x0063, B:39:0x0070, B:22:0x0040, B:27:0x004c, B:30:0x0053, B:41:0x0082), top: B:46:0x0004 }] */
    /* JADX WARN: Code duplicated, block: B:58:0x0060 A[SYNTHETIC] */
    boolean removePendingIntentsForPackage(String packageName, int userId, int appId, boolean doIt) {
        boolean didSomething = false;
        synchronized (this.mLock) {
            if (this.mIntentSenderRecords.size() <= 0) {
                return false;
            }
            Iterator<WeakReference<PendingIntentRecord>> it = this.mIntentSenderRecords.values().iterator();
            while (it.hasNext()) {
                WeakReference<PendingIntentRecord> wpir = it.next();
                if (wpir == null) {
                    it.remove();
                } else {
                    PendingIntentRecord pir = wpir.get();
                    if (pir == null) {
                        it.remove();
                    } else if (packageName == null) {
                        if (pir.key.userId == userId) {
                            if (!doIt) {
                                return true;
                            }
                            didSomething = true;
                            it.remove();
                            makeIntentSenderCanceled(pir);
                            if (pir.key.activity != null) {
                                Message m = PooledLambda.obtainMessage($$Lambda$PendingIntentController$sPmaborOkBSSEP2wiimxXweYDQ.INSTANCE, this, pir.key.activity, pir.ref);
                                this.mH.sendMessage(m);
                            }
                        }
                    } else if (UserHandle.getAppId(pir.uid) == appId && (userId == -1 || pir.key.userId == userId)) {
                        if (pir.key.packageName.equals(packageName)) {
                            if (!doIt) {
                                return true;
                            }
                            didSomething = true;
                            it.remove();
                            makeIntentSenderCanceled(pir);
                            if (pir.key.activity != null) {
                                Message m2 = PooledLambda.obtainMessage($$Lambda$PendingIntentController$sPmaborOkBSSEP2wiimxXweYDQ.INSTANCE, this, pir.key.activity, pir.ref);
                                this.mH.sendMessage(m2);
                            }
                        }
                    }
                }
            }
            return didSomething;
        }
    }

    public void cancelIntentSender(IIntentSender sender) {
        if (!(sender instanceof PendingIntentRecord)) {
            return;
        }
        synchronized (this.mLock) {
            PendingIntentRecord rec = (PendingIntentRecord) sender;
            try {
                int uid = AppGlobals.getPackageManager().getPackageUid(rec.key.packageName, 268435456, UserHandle.getCallingUserId());
                if (!UserHandle.isSameApp(uid, Binder.getCallingUid())) {
                    String msg = "Permission Denial: cancelIntentSender() from pid=" + Binder.getCallingPid() + ", uid=" + Binder.getCallingUid() + " is not allowed to cancel package " + rec.key.packageName;
                    Slog.w(TAG, msg);
                    throw new SecurityException(msg);
                }
                cancelIntentSender(rec, true);
            } catch (RemoteException e) {
                throw new SecurityException(e);
            }
        }
    }

    public void cancelIntentSender(PendingIntentRecord rec, boolean cleanActivity) {
        synchronized (this.mLock) {
            makeIntentSenderCanceled(rec);
            this.mIntentSenderRecords.remove(rec.key);
            if (cleanActivity && rec.key.activity != null) {
                Message m = PooledLambda.obtainMessage($$Lambda$PendingIntentController$sPmaborOkBSSEP2wiimxXweYDQ.INSTANCE, this, rec.key.activity, rec.ref);
                this.mH.sendMessage(m);
            }
        }
    }

    void registerIntentSenderCancelListener(IIntentSender sender, IResultReceiver receiver) {
        boolean isCancelled;
        if (!(sender instanceof PendingIntentRecord)) {
            return;
        }
        synchronized (this.mLock) {
            PendingIntentRecord pendingIntent = (PendingIntentRecord) sender;
            isCancelled = pendingIntent.canceled;
            if (!isCancelled) {
                pendingIntent.registerCancelListenerLocked(receiver);
            }
        }
        if (isCancelled) {
            try {
                receiver.send(0, (Bundle) null);
            } catch (RemoteException e) {
            }
        }
    }

    void unregisterIntentSenderCancelListener(IIntentSender sender, IResultReceiver receiver) {
        if (!(sender instanceof PendingIntentRecord)) {
            return;
        }
        synchronized (this.mLock) {
            ((PendingIntentRecord) sender).unregisterCancelListenerLocked(receiver);
        }
    }

    void setPendingIntentWhitelistDuration(IIntentSender target, IBinder whitelistToken, long duration) {
        if (!(target instanceof PendingIntentRecord)) {
            Slog.w(TAG, "markAsSentFromNotification(): not a PendingIntentRecord: " + target);
            return;
        }
        synchronized (this.mLock) {
            ((PendingIntentRecord) target).setWhitelistDurationLocked(whitelistToken, duration);
        }
    }

    private void makeIntentSenderCanceled(PendingIntentRecord rec) {
        rec.canceled = true;
        RemoteCallbackList<IResultReceiver> callbacks = rec.detachCancelListenersLocked();
        if (callbacks != null) {
            Message m = PooledLambda.obtainMessage(new BiConsumer() { // from class: com.android.server.am.-$$Lambda$PendingIntentController$pDmmJDvS20vSAAXh9qdzbN0P8N0
                @Override // java.util.function.BiConsumer
                public final void accept(Object obj, Object obj2) {
                    ((PendingIntentController) obj).handlePendingIntentCancelled((RemoteCallbackList) obj2);
                }
            }, this, callbacks);
            this.mH.sendMessage(m);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handlePendingIntentCancelled(RemoteCallbackList<IResultReceiver> callbacks) {
        int N = callbacks.beginBroadcast();
        for (int i = 0; i < N; i++) {
            try {
                callbacks.getBroadcastItem(i).send(0, (Bundle) null);
            } catch (RemoteException e) {
            }
        }
        callbacks.finishBroadcast();
        callbacks.kill();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void clearPendingResultForActivity(IBinder activityToken, WeakReference<PendingIntentRecord> pir) {
        this.mAtmInternal.clearPendingResultForActivity(activityToken, pir);
    }

    void dumpPendingIntents(PrintWriter pw, boolean dumpAll, String dumpPackage) {
        synchronized (this.mLock) {
            boolean printed = false;
            pw.println("ACTIVITY MANAGER PENDING INTENTS (dumpsys activity intents)");
            if (this.mIntentSenderRecords.size() > 0) {
                ArrayMap<String, ArrayList<PendingIntentRecord>> byPackage = new ArrayMap<>();
                ArrayList<WeakReference<PendingIntentRecord>> weakRefs = new ArrayList<>();
                Iterator<WeakReference<PendingIntentRecord>> it = this.mIntentSenderRecords.values().iterator();
                while (it.hasNext()) {
                    WeakReference<PendingIntentRecord> ref = it.next();
                    PendingIntentRecord rec = ref != null ? ref.get() : null;
                    if (rec == null) {
                        weakRefs.add(ref);
                    } else if (dumpPackage == null || dumpPackage.equals(rec.key.packageName)) {
                        ArrayList<PendingIntentRecord> list = byPackage.get(rec.key.packageName);
                        if (list == null) {
                            list = new ArrayList<>();
                            byPackage.put(rec.key.packageName, list);
                        }
                        list.add(rec);
                    }
                }
                for (int i = 0; i < byPackage.size(); i++) {
                    ArrayList<PendingIntentRecord> intents = byPackage.valueAt(i);
                    printed = true;
                    pw.print("  * ");
                    pw.print(byPackage.keyAt(i));
                    pw.print(": ");
                    pw.print(intents.size());
                    pw.println(" items");
                    for (int j = 0; j < intents.size(); j++) {
                        pw.print("    #");
                        pw.print(j);
                        pw.print(": ");
                        pw.println(intents.get(j));
                        if (dumpAll) {
                            intents.get(j).dump(pw, "      ");
                        }
                    }
                }
                int i2 = weakRefs.size();
                if (i2 > 0) {
                    printed = true;
                    pw.println("  * WEAK REFS:");
                    for (int i3 = 0; i3 < weakRefs.size(); i3++) {
                        pw.print("    #");
                        pw.print(i3);
                        pw.print(": ");
                        pw.println(weakRefs.get(i3));
                    }
                }
            }
            if (!printed) {
                pw.println("  (nothing)");
            }
        }
    }
}
