package com.android.server.audio;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public interface PlayerFocusEnforcer {
    boolean duckPlayers(FocusRequester focusRequester, FocusRequester focusRequester2, boolean z);

    void mutePlayersForCall(int[] iArr);

    void unduckPlayers(FocusRequester focusRequester);

    void unmutePlayersForCall();
}
