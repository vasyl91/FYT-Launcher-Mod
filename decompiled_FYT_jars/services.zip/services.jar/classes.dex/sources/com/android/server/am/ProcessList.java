package com.android.server.am;

import android.R;
import android.app.ActivityManager;
import android.app.ActivityThread;
import android.app.AppGlobals;
import android.app.IApplicationThread;
import android.app.PreForkArgs;
import android.content.ComponentName;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;
import android.graphics.Point;
import android.hardware.biometrics.face.V1_0.FaceAcquiredInfo;
import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.os.AppZygote;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.os.RemoteException;
import android.os.StrictMode;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.Trace;
import android.os.UserHandle;
import android.os.storage.StorageManager;
import android.os.storage.StorageManagerInternal;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.EventLog;
import android.util.LongSparseArray;
import android.util.Slog;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.util.StatsLog;
import com.android.internal.annotations.GuardedBy;
import com.android.internal.annotations.VisibleForTesting;
import com.android.internal.app.ProcessMap;
import com.android.internal.app.procstats.ProcessStats;
import com.android.internal.os.Zygote;
import com.android.internal.util.ArrayUtils;
import com.android.internal.util.MemInfoReader;
import com.android.server.LocalServices;
import com.android.server.ServiceThread;
import com.android.server.Watchdog;
import com.android.server.backup.BackupAgentTimeoutParameters;
import com.android.server.job.controllers.JobStatus;
import com.android.server.pm.DumpState;
import com.android.server.pm.dex.DexManager;
import com.android.server.slice.SliceClientPermissions;
import com.android.server.usage.AppStandbyController;
import com.android.server.wm.ActivityServiceConnectionsHolder;
import com.android.server.wm.WindowManagerService;
import dalvik.system.VMRuntime;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Iterator;
import java.util.List;
import libcore.io.IoUtils;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public final class ProcessList {
    static final int BACKUP_APP_ADJ = 300;
    static final int CACHED_APP_IMPORTANCE_LEVELS = 5;
    static final int CACHED_APP_LMK_FIRST_ADJ = 950;
    static final int CACHED_APP_MAX_ADJ = 999;
    static final int CACHED_APP_MIN_ADJ = 900;
    static final int FOREGROUND_APP_ADJ = 0;
    static final int HEAVY_WEIGHT_APP_ADJ = 400;
    static final int HOME_APP_ADJ = 600;
    static final int INVALID_ADJ = -10000;
    static final byte LMK_FASTKILL = 5;
    static final byte LMK_GETKILLCNT = 4;
    static final byte LMK_PROCPRIO = 1;
    static final byte LMK_PROCPURGE = 3;
    static final byte LMK_PROCREMOVE = 2;
    static final byte LMK_TARGET = 0;
    static final long MAX_EMPTY_TIME = 1800000;
    static final int MIN_CACHED_APPS = 2;
    static final int MIN_CRASH_INTERVAL = 60000;
    static final int NATIVE_ADJ = -1000;
    static final int PAGE_SIZE = 4096;
    static final int PERCEPTIBLE_APP_ADJ = 200;
    static final int PERCEPTIBLE_LOW_APP_ADJ = 250;
    static final int PERCEPTIBLE_RECENT_FOREGROUND_APP_ADJ = 50;
    static final int PERSISTENT_PROC_ADJ = -800;
    static final int PERSISTENT_SERVICE_ADJ = -700;
    static final int PREVIOUS_APP_ADJ = 700;
    public static final int PROC_MEM_CACHED = 4;
    public static final int PROC_MEM_IMPORTANT = 2;
    public static final int PROC_MEM_NUM = 5;
    public static final int PROC_MEM_PERSISTENT = 0;
    public static final int PROC_MEM_SERVICE = 3;
    public static final int PROC_MEM_TOP = 1;
    private static final String PROPERTY_USE_APP_IMAGE_STARTUP_CACHE = "persist.device_config.runtime_native.use_app_image_startup_cache";
    public static final int PSS_ALL_INTERVAL = 1200000;
    private static final int PSS_FIRST_ASLEEP_BACKGROUND_INTERVAL = 30000;
    private static final int PSS_FIRST_ASLEEP_CACHED_INTERVAL = 60000;
    private static final int PSS_FIRST_ASLEEP_PERSISTENT_INTERVAL = 60000;
    private static final int PSS_FIRST_ASLEEP_TOP_INTERVAL = 20000;
    private static final int PSS_FIRST_BACKGROUND_INTERVAL = 20000;
    private static final int PSS_FIRST_CACHED_INTERVAL = 20000;
    private static final int PSS_FIRST_PERSISTENT_INTERVAL = 30000;
    private static final int PSS_FIRST_TOP_INTERVAL = 10000;
    public static final int PSS_MAX_INTERVAL = 3600000;
    public static final int PSS_MIN_TIME_FROM_STATE_CHANGE = 15000;
    public static final int PSS_SAFE_TIME_FROM_STATE_CHANGE = 1000;
    private static final int PSS_SAME_CACHED_INTERVAL = 600000;
    private static final int PSS_SAME_IMPORTANT_INTERVAL = 600000;
    private static final int PSS_SAME_PERSISTENT_INTERVAL = 600000;
    private static final int PSS_SAME_SERVICE_INTERVAL = 300000;
    private static final int PSS_SAME_TOP_INTERVAL = 60000;
    private static final int PSS_TEST_FIRST_BACKGROUND_INTERVAL = 5000;
    private static final int PSS_TEST_FIRST_TOP_INTERVAL = 3000;
    public static final int PSS_TEST_MIN_TIME_FROM_STATE_CHANGE = 10000;
    private static final int PSS_TEST_SAME_BACKGROUND_INTERVAL = 15000;
    private static final int PSS_TEST_SAME_IMPORTANT_INTERVAL = 10000;
    static final int SCHED_GROUP_BACKGROUND = 0;
    static final int SCHED_GROUP_DEFAULT = 2;
    static final int SCHED_GROUP_RESTRICTED = 1;
    public static final int SCHED_GROUP_TOP_APP = 3;
    static final int SCHED_GROUP_TOP_APP_BOUND = 4;
    static final int SERVICE_ADJ = 500;
    static final int SERVICE_B_ADJ = 800;
    static final int SYSTEM_ADJ = -900;
    static final String TAG = "ActivityManager";
    static final int TRIM_CRITICAL_THRESHOLD = 3;
    static final int TRIM_LOW_THRESHOLD = 5;
    static final int UNKNOWN_ADJ = 1001;
    static final int VISIBLE_APP_ADJ = 100;
    static final int VISIBLE_APP_LAYER_MAX = 99;

    @GuardedBy({"sLmkdSocketLock"})
    private static InputStream sLmkdInputStream;

    @GuardedBy({"sLmkdSocketLock"})
    private static OutputStream sLmkdOutputStream;

    @GuardedBy({"sLmkdSocketLock"})
    private static LocalSocket sLmkdSocket;
    ActiveUids mActiveUids;
    private long mCachedRestoreLevel;
    private boolean mHaveDisplaySize;
    private final long mTotalMemMb;
    static KillHandler sKillHandler = null;
    static ServiceThread sKillThread = null;
    private static Object sLmkdSocketLock = new Object();
    private static final int[] sProcStateToProcMem = {0, 0, 1, 2, 2, 1, 2, 2, 2, 2, 2, 3, 4, 1, 2, 4, 4, 4, 4, 4, 4};
    private static final long[] sFirstAwakePssTimes = {30000, JobStatus.DEFAULT_TRIGGER_UPDATE_DELAY, 20000, 20000, 20000};
    private static final long[] sSameAwakePssTimes = {600000, 60000, 600000, BackupAgentTimeoutParameters.DEFAULT_FULL_BACKUP_AGENT_TIMEOUT_MILLIS, 600000};
    private static final long[] sFirstAsleepPssTimes = {60000, 20000, 30000, 30000, 60000};
    private static final long[] sSameAsleepPssTimes = {600000, 60000, 600000, BackupAgentTimeoutParameters.DEFAULT_FULL_BACKUP_AGENT_TIMEOUT_MILLIS, 600000};
    private static final long[] sTestFirstPssTimes = {BackupAgentTimeoutParameters.DEFAULT_QUOTA_EXCEEDED_TIMEOUT_MILLIS, BackupAgentTimeoutParameters.DEFAULT_QUOTA_EXCEEDED_TIMEOUT_MILLIS, 5000, 5000, 5000};
    private static final long[] sTestSamePssTimes = {15000, JobStatus.DEFAULT_TRIGGER_UPDATE_DELAY, JobStatus.DEFAULT_TRIGGER_UPDATE_DELAY, 15000, 15000};
    ActivityManagerService mService = null;
    private final int[] mOomAdj = {0, 100, 200, PERCEPTIBLE_LOW_APP_ADJ, CACHED_APP_MIN_ADJ, CACHED_APP_LMK_FIRST_ADJ};
    private final int[] mOomMinFreeLow = {12288, 18432, 24576, 36864, 43008, 49152};
    private final int[] mOomMinFreeHigh = {73728, 92160, 110592, 129024, 147456, 184320};
    private final int[] mOomMinFree = new int[this.mOomAdj.length];

    @GuardedBy({"mService"})
    final StringBuilder mStringBuilder = new StringBuilder(256);

    @GuardedBy({"mService"})
    @VisibleForTesting
    long mProcStateSeqCounter = 0;

    @GuardedBy({"mService"})
    private long mProcStartSeqCounter = 0;

    @GuardedBy({"mService"})
    final LongSparseArray<ProcessRecord> mPendingStarts = new LongSparseArray<>();
    final ArrayList<ProcessRecord> mLruProcesses = new ArrayList<>();
    int mLruProcessActivityStart = 0;
    int mLruProcessServiceStart = 0;
    int mLruSeq = 0;
    final SparseArray<ProcessRecord> mIsolatedProcesses = new SparseArray<>();
    final ProcessMap<AppZygote> mAppZygotes = new ProcessMap<>();
    final ArrayMap<AppZygote, ArrayList<ProcessRecord>> mAppZygoteProcesses = new ArrayMap<>();

    @VisibleForTesting
    IsolatedUidRange mGlobalIsolatedUids = new IsolatedUidRange(99000, 99999);

    @VisibleForTesting
    IsolatedUidRangeAllocator mAppIsolatedUidRangeAllocator = new IsolatedUidRangeAllocator(90000, 98999, 100);
    final ArrayList<ProcessRecord> mRemovedProcesses = new ArrayList<>();
    final MyProcessMap mProcessNames = new MyProcessMap();

    final class IsolatedUidRange {

        @VisibleForTesting
        public final int mFirstUid;

        @VisibleForTesting
        public final int mLastUid;

        @GuardedBy({"ProcessList.this.mService"})
        private int mNextUid;

        @GuardedBy({"ProcessList.this.mService"})
        private final SparseBooleanArray mUidUsed = new SparseBooleanArray();

        IsolatedUidRange(int firstUid, int lastUid) {
            this.mFirstUid = firstUid;
            this.mLastUid = lastUid;
            this.mNextUid = firstUid;
        }

        @GuardedBy({"ProcessList.this.mService"})
        int allocateIsolatedUidLocked(int userId) {
            int stepsLeft = (this.mLastUid - this.mFirstUid) + 1;
            for (int i = 0; i < stepsLeft; i++) {
                int i2 = this.mNextUid;
                if (i2 < this.mFirstUid || i2 > this.mLastUid) {
                    this.mNextUid = this.mFirstUid;
                }
                int uid = UserHandle.getUid(userId, this.mNextUid);
                this.mNextUid++;
                if (!this.mUidUsed.get(uid, false)) {
                    this.mUidUsed.put(uid, true);
                    return uid;
                }
            }
            return -1;
        }

        @GuardedBy({"ProcessList.this.mService"})
        void freeIsolatedUidLocked(int uid) {
            int appId = UserHandle.getAppId(uid);
            this.mUidUsed.delete(appId);
        }
    }

    final class IsolatedUidRangeAllocator {

        @GuardedBy({"ProcessList.this.mService"})
        private final ProcessMap<IsolatedUidRange> mAppRanges = new ProcessMap<>();

        @GuardedBy({"ProcessList.this.mService"})
        private final BitSet mAvailableUidRanges;
        private final int mFirstUid;
        private final int mNumUidRanges;
        private final int mNumUidsPerRange;

        IsolatedUidRangeAllocator(int firstUid, int lastUid, int numUidsPerRange) {
            this.mFirstUid = firstUid;
            this.mNumUidsPerRange = numUidsPerRange;
            this.mNumUidRanges = ((lastUid - firstUid) + 1) / numUidsPerRange;
            this.mAvailableUidRanges = new BitSet(this.mNumUidRanges);
            this.mAvailableUidRanges.set(0, this.mNumUidRanges);
        }

        @GuardedBy({"ProcessList.this.mService"})
        IsolatedUidRange getIsolatedUidRangeLocked(String processName, int uid) {
            return (IsolatedUidRange) this.mAppRanges.get(processName, uid);
        }

        @GuardedBy({"ProcessList.this.mService"})
        IsolatedUidRange getOrCreateIsolatedUidRangeLocked(String processName, int uid) {
            IsolatedUidRange range = getIsolatedUidRangeLocked(processName, uid);
            if (range == null) {
                int uidRangeIndex = this.mAvailableUidRanges.nextSetBit(0);
                if (uidRangeIndex < 0) {
                    return null;
                }
                this.mAvailableUidRanges.clear(uidRangeIndex);
                int i = this.mFirstUid;
                int i2 = this.mNumUidsPerRange;
                int actualUid = i + (uidRangeIndex * i2);
                IsolatedUidRange range2 = ProcessList.this.new IsolatedUidRange(actualUid, (i2 + actualUid) - 1);
                this.mAppRanges.put(processName, uid, range2);
                return range2;
            }
            return range;
        }

        @GuardedBy({"ProcessList.this.mService"})
        void freeUidRangeLocked(ApplicationInfo info) {
            IsolatedUidRange range = (IsolatedUidRange) this.mAppRanges.get(info.processName, info.uid);
            if (range != null) {
                int uidRangeIndex = (range.mFirstUid - this.mFirstUid) / this.mNumUidsPerRange;
                this.mAvailableUidRanges.set(uidRangeIndex);
                this.mAppRanges.remove(info.processName, info.uid);
            }
        }
    }

    final class MyProcessMap extends ProcessMap<ProcessRecord> {
        MyProcessMap() {
        }

        public ProcessRecord put(String name, int uid, ProcessRecord value) {
            ProcessRecord r = (ProcessRecord) super.put(name, uid, value);
            ProcessList.this.mService.mAtmInternal.onProcessAdded(r.getWindowProcessController());
            return r;
        }

        /* JADX INFO: renamed from: remove, reason: merged with bridge method [inline-methods] */
        public ProcessRecord m13remove(String name, int uid) {
            ProcessRecord r = (ProcessRecord) super.remove(name, uid);
            ProcessList.this.mService.mAtmInternal.onProcessRemoved(name, uid);
            return r;
        }
    }

    final class KillHandler extends Handler {
        static final int KILL_PROCESS_GROUP_MSG = 4000;

        public KillHandler(Looper looper) {
            super(looper, null, true);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            if (msg.what == KILL_PROCESS_GROUP_MSG) {
                Trace.traceBegin(64L, "killProcessGroup");
                Process.killProcessGroup(msg.arg1, msg.arg2);
                Trace.traceEnd(64L);
                return;
            }
            super.handleMessage(msg);
        }
    }

    ProcessList() {
        MemInfoReader minfo = new MemInfoReader();
        minfo.readMemInfo();
        this.mTotalMemMb = minfo.getTotalSize() / 1048576;
        updateOomLevels(0, 0, false);
    }

    void init(ActivityManagerService service, ActiveUids activeUids) {
        this.mService = service;
        this.mActiveUids = activeUids;
        if (sKillHandler == null) {
            sKillThread = new ServiceThread("ActivityManager:kill", 10, true);
            sKillThread.start();
            sKillHandler = new KillHandler(sKillThread.getLooper());
        }
    }

    void applyDisplaySize(WindowManagerService wm) {
        if (!this.mHaveDisplaySize) {
            Point p = new Point();
            wm.getBaseDisplaySize(0, p);
            if (p.x != 0 && p.y != 0) {
                updateOomLevels(p.x, p.y, true);
                this.mHaveDisplaySize = true;
            }
        }
    }

    private void updateOomLevels(int displayWidth, int displayHeight, boolean write) {
        float scaleMem = (this.mTotalMemMb - 350) / 350.0f;
        float scaleDisp = ((displayWidth * displayHeight) - 384000) / (1024000 - 384000);
        float scale = scaleMem > scaleDisp ? scaleMem : scaleDisp;
        if (scale < 0.0f) {
            scale = 0.0f;
        } else if (scale > 1.0f) {
            scale = 1.0f;
        }
        int minfree_adj = Resources.getSystem().getInteger(R.integer.config_default_cellular_usage_setting);
        int minfree_abs = Resources.getSystem().getInteger(R.integer.config_defaultVibrationAmplitude);
        boolean is64bit = Build.SUPPORTED_64_BIT_ABIS.length > 0;
        for (int i = 0; i < this.mOomAdj.length; i++) {
            int low = this.mOomMinFreeLow[i];
            int high = this.mOomMinFreeHigh[i];
            if (is64bit) {
                if (i == 4) {
                    high = (high * 3) / 2;
                } else if (i == 5) {
                    high = (high * 7) / 4;
                }
            }
            this.mOomMinFree[i] = (int) (low + ((high - low) * scale));
        }
        if (minfree_abs >= 0) {
            int i2 = 0;
            while (true) {
                int[] iArr = this.mOomAdj;
                if (i2 >= iArr.length) {
                    break;
                }
                int[] iArr2 = this.mOomMinFree;
                iArr2[i2] = (int) ((minfree_abs * iArr2[i2]) / iArr2[iArr.length - 1]);
                i2++;
            }
        }
        if (minfree_adj != 0) {
            int i3 = 0;
            while (true) {
                int[] iArr3 = this.mOomAdj;
                if (i3 >= iArr3.length) {
                    break;
                }
                int[] iArr4 = this.mOomMinFree;
                iArr4[i3] = iArr4[i3] + ((int) ((minfree_adj * iArr4[i3]) / iArr4[iArr3.length - 1]));
                if (iArr4[i3] < 0) {
                    iArr4[i3] = 0;
                }
                i3++;
            }
        }
        this.mCachedRestoreLevel = (getMemLevel(CACHED_APP_MAX_ADJ) / 1024) / 3;
        int reserve = (((displayWidth * displayHeight) * 4) * 3) / 1024;
        int reserve_adj = Resources.getSystem().getInteger(R.integer.config_defaultMaxDurationBetweenUndimsMillis);
        int reserve_abs = Resources.getSystem().getInteger(R.integer.config_defaultKeyboardVibrationIntensity);
        if (reserve_abs >= 0) {
            reserve = reserve_abs;
        }
        if (reserve_adj != 0 && (reserve = reserve + reserve_adj) < 0) {
            reserve = 0;
        }
        if (calcLmkMinfree(write)) {
            Slog.i(TAG, "lmk use custom minfree!");
            return;
        }
        if (write) {
            ByteBuffer buf = ByteBuffer.allocate(((this.mOomAdj.length * 2) + 1) * 4);
            buf.putInt(0);
            for (int i4 = 0; i4 < this.mOomAdj.length; i4++) {
                buf.putInt((this.mOomMinFree[i4] * 1024) / 4096);
                buf.putInt(this.mOomAdj[i4]);
            }
            writeLmkd(buf, null);
            SystemProperties.set("sys.sysctl.extra_free_kbytes", Integer.toString(reserve));
        }
    }

    public static int computeEmptyProcessLimit(int totalProcessLimit) {
        return totalProcessLimit / 2;
    }

    private static String buildOomTag(String prefix, String compactPrefix, String space, int val, int base, boolean compact) {
        int diff = val - base;
        if (diff == 0) {
            if (compact) {
                return compactPrefix;
            }
            if (space == null) {
                return prefix;
            }
            return prefix + space;
        }
        if (diff < 10) {
            StringBuilder sb = new StringBuilder();
            sb.append(prefix);
            sb.append(compact ? "+" : "+ ");
            sb.append(Integer.toString(diff));
            return sb.toString();
        }
        return prefix + "+" + Integer.toString(diff);
    }

    public static String makeOomAdjString(int setAdj, boolean compact) {
        if (setAdj >= CACHED_APP_MIN_ADJ) {
            return buildOomTag("cch", "cch", "   ", setAdj, CACHED_APP_MIN_ADJ, compact);
        }
        if (setAdj >= SERVICE_B_ADJ) {
            return buildOomTag("svcb  ", "svcb", null, setAdj, SERVICE_B_ADJ, compact);
        }
        if (setAdj >= PREVIOUS_APP_ADJ) {
            return buildOomTag("prev  ", "prev", null, setAdj, PREVIOUS_APP_ADJ, compact);
        }
        if (setAdj >= 600) {
            return buildOomTag("home  ", "home", null, setAdj, 600, compact);
        }
        if (setAdj >= 500) {
            return buildOomTag("svc   ", "svc", null, setAdj, 500, compact);
        }
        if (setAdj >= HEAVY_WEIGHT_APP_ADJ) {
            return buildOomTag("hvy   ", "hvy", null, setAdj, HEAVY_WEIGHT_APP_ADJ, compact);
        }
        if (setAdj >= 300) {
            return buildOomTag("bkup  ", "bkup", null, setAdj, 300, compact);
        }
        if (setAdj >= PERCEPTIBLE_LOW_APP_ADJ) {
            return buildOomTag("prcl  ", "prcl", null, setAdj, PERCEPTIBLE_LOW_APP_ADJ, compact);
        }
        if (setAdj >= 200) {
            return buildOomTag("prcp  ", "prcp", null, setAdj, 200, compact);
        }
        if (setAdj >= 100) {
            return buildOomTag("vis", "vis", "   ", setAdj, 100, compact);
        }
        if (setAdj >= 0) {
            return buildOomTag("fore  ", "fore", null, setAdj, 0, compact);
        }
        if (setAdj >= PERSISTENT_SERVICE_ADJ) {
            return buildOomTag("psvc  ", "psvc", null, setAdj, PERSISTENT_SERVICE_ADJ, compact);
        }
        if (setAdj >= PERSISTENT_PROC_ADJ) {
            return buildOomTag("pers  ", "pers", null, setAdj, PERSISTENT_PROC_ADJ, compact);
        }
        if (setAdj >= SYSTEM_ADJ) {
            return buildOomTag("sys   ", "sys", null, setAdj, SYSTEM_ADJ, compact);
        }
        if (setAdj >= -1000) {
            return buildOomTag("ntv  ", "ntv", null, setAdj, -1000, compact);
        }
        return Integer.toString(setAdj);
    }

    public static String makeProcStateString(int curProcState) {
        switch (curProcState) {
            case 0:
                return "PER ";
            case 1:
                return "PERU";
            case 2:
                return "TOP ";
            case 3:
                return "FGSL";
            case 4:
                return "BTOP";
            case 5:
                return "FGS ";
            case 6:
                return "BFGS";
            case 7:
                return "IMPF";
            case 8:
                return "IMPB";
            case 9:
                return "TRNB";
            case 10:
                return "BKUP";
            case 11:
                return "SVC ";
            case 12:
                return "RCVR";
            case 13:
                return "TPSL";
            case 14:
                return "HVY ";
            case 15:
                return "HOME";
            case 16:
                return "LAST";
            case 17:
                return "CAC ";
            case 18:
                return "CACC";
            case FaceAcquiredInfo.FACE_OBSCURED /* 19 */:
                return "CRE ";
            case 20:
                return "CEM ";
            case 21:
                return "NONE";
            default:
                return "??";
        }
    }

    public static int makeProcStateProtoEnum(int curProcState) {
        switch (curProcState) {
            case -1:
                return CACHED_APP_MAX_ADJ;
            case 0:
                return 1000;
            case 1:
                return 1001;
            case 2:
                return 1002;
            case 3:
                return 1003;
            case 4:
                return 1020;
            case 5:
                return 1003;
            case 6:
                return 1004;
            case 7:
                return 1005;
            case 8:
                return 1006;
            case 9:
                return 1007;
            case 10:
                return 1008;
            case 11:
                return 1009;
            case 12:
                return 1010;
            case 13:
                return 1011;
            case 14:
                return 1012;
            case 15:
                return 1013;
            case 16:
                return 1014;
            case 17:
                return 1015;
            case 18:
                return 1016;
            case FaceAcquiredInfo.FACE_OBSCURED /* 19 */:
                return 1017;
            case 20:
                return 1018;
            case 21:
                return 1019;
            default:
                return 998;
        }
    }

    public static void appendRamKb(StringBuilder sb, long ramKb) {
        int j = 0;
        int fact = 10;
        while (j < 6) {
            if (ramKb < fact) {
                sb.append(' ');
            }
            j++;
            fact *= 10;
        }
        sb.append(ramKb);
    }

    public static final class ProcStateMemTracker {
        int mPendingHighestMemState;
        int mPendingMemState;
        float mPendingScalingFactor;
        final int[] mHighestMem = new int[5];
        final float[] mScalingFactor = new float[5];
        int mTotalHighestMem = 4;

        public ProcStateMemTracker() {
            for (int i = 0; i < 5; i++) {
                this.mHighestMem[i] = 5;
                this.mScalingFactor[i] = 1.0f;
            }
            this.mPendingMemState = -1;
        }

        public void dumpLine(PrintWriter pw) {
            pw.print("best=");
            pw.print(this.mTotalHighestMem);
            pw.print(" (");
            boolean needSep = false;
            for (int i = 0; i < 5; i++) {
                if (this.mHighestMem[i] < 5) {
                    if (needSep) {
                        pw.print(", ");
                    }
                    pw.print(i);
                    pw.print("=");
                    pw.print(this.mHighestMem[i]);
                    pw.print(" ");
                    pw.print(this.mScalingFactor[i]);
                    pw.print("x");
                    needSep = true;
                }
            }
            pw.print(")");
            if (this.mPendingMemState >= 0) {
                pw.print(" / pending state=");
                pw.print(this.mPendingMemState);
                pw.print(" highest=");
                pw.print(this.mPendingHighestMemState);
                pw.print(" ");
                pw.print(this.mPendingScalingFactor);
                pw.print("x");
            }
            pw.println();
        }
    }

    public static boolean procStatesDifferForMem(int procState1, int procState2) {
        int[] iArr = sProcStateToProcMem;
        return iArr[procState1] != iArr[procState2];
    }

    public static long minTimeFromStateChange(boolean test) {
        if (test) {
            return JobStatus.DEFAULT_TRIGGER_UPDATE_DELAY;
        }
        return 15000L;
    }

    public static void commitNextPssTime(ProcStateMemTracker tracker) {
        if (tracker.mPendingMemState >= 0) {
            tracker.mHighestMem[tracker.mPendingMemState] = tracker.mPendingHighestMemState;
            tracker.mScalingFactor[tracker.mPendingMemState] = tracker.mPendingScalingFactor;
            tracker.mTotalHighestMem = tracker.mPendingHighestMemState;
            tracker.mPendingMemState = -1;
        }
    }

    public static void abortNextPssTime(ProcStateMemTracker tracker) {
        tracker.mPendingMemState = -1;
    }

    public static long computeNextPssTime(int procState, ProcStateMemTracker tracker, boolean test, boolean sleeping, long now) {
        boolean first;
        float scalingFactor;
        long[] table;
        int memState = sProcStateToProcMem[procState];
        if (tracker != null) {
            int highestMemState = memState < tracker.mTotalHighestMem ? memState : tracker.mTotalHighestMem;
            first = highestMemState < tracker.mHighestMem[memState];
            tracker.mPendingMemState = memState;
            tracker.mPendingHighestMemState = highestMemState;
            if (first) {
                scalingFactor = 1.0f;
                tracker.mPendingScalingFactor = 1.0f;
            } else {
                scalingFactor = tracker.mScalingFactor[memState];
                tracker.mPendingScalingFactor = 1.5f * scalingFactor;
            }
        } else {
            first = true;
            scalingFactor = 1.0f;
        }
        if (test) {
            if (first) {
                table = sTestFirstPssTimes;
            } else {
                table = sTestSamePssTimes;
            }
        } else if (first) {
            table = sleeping ? sFirstAsleepPssTimes : sFirstAwakePssTimes;
        } else {
            table = sleeping ? sSameAsleepPssTimes : sSameAwakePssTimes;
        }
        long delay = (long) (table[memState] * scalingFactor);
        if (delay > AppStandbyController.SettingsObserver.DEFAULT_STRONG_USAGE_TIMEOUT) {
            delay = AppStandbyController.SettingsObserver.DEFAULT_STRONG_USAGE_TIMEOUT;
        }
        return now + delay;
    }

    long getMemLevel(int adjustment) {
        int i = 0;
        while (true) {
            int[] iArr = this.mOomAdj;
            if (i < iArr.length) {
                if (adjustment > iArr[i]) {
                    i++;
                } else {
                    return this.mOomMinFree[i] * 1024;
                }
            } else {
                return this.mOomMinFree[iArr.length - 1] * 1024;
            }
        }
    }

    long getCachedRestoreThresholdKb() {
        return this.mCachedRestoreLevel;
    }

    public static void setOomAdj(int pid, int uid, int amt) {
        if (pid <= 0 || amt == 1001) {
            return;
        }
        long start = SystemClock.elapsedRealtime();
        ByteBuffer buf = ByteBuffer.allocate(16);
        buf.putInt(1);
        buf.putInt(pid);
        buf.putInt(uid);
        buf.putInt(amt);
        writeLmkd(buf, null);
        long now = SystemClock.elapsedRealtime();
        if (now - start > 250) {
            Slog.w(TAG, "SLOW OOM ADJ: " + (now - start) + "ms for pid " + pid + " = " + amt);
        }
    }

    public static final void remove(int pid) {
        if (pid <= 0) {
            return;
        }
        ByteBuffer buf = ByteBuffer.allocate(8);
        buf.putInt(2);
        buf.putInt(pid);
        writeLmkd(buf, null);
    }

    public static final Integer getLmkdKillCount(int min_oom_adj, int max_oom_adj) {
        ByteBuffer buf = ByteBuffer.allocate(12);
        ByteBuffer repl = ByteBuffer.allocate(8);
        buf.putInt(4);
        buf.putInt(min_oom_adj);
        buf.putInt(max_oom_adj);
        if (!writeLmkd(buf, repl)) {
            return null;
        }
        int i = repl.getInt();
        if (i != 4) {
            Slog.e(TAG, "Failed to get kill count, code mismatch");
            return null;
        }
        return new Integer(repl.getInt());
    }

    public static final void doFastKill() {
        ByteBuffer buf = ByteBuffer.allocate(8);
        buf.putInt(5);
        buf.putInt(1);
        writeLmkd(buf, null);
    }

    @GuardedBy({"sLmkdSocketLock"})
    private static boolean openLmkdSocketLS() {
        try {
            sLmkdSocket = new LocalSocket(3);
            sLmkdSocket.connect(new LocalSocketAddress("lmkd", LocalSocketAddress.Namespace.RESERVED));
            sLmkdOutputStream = sLmkdSocket.getOutputStream();
            sLmkdInputStream = sLmkdSocket.getInputStream();
            return true;
        } catch (IOException e) {
            Slog.w(TAG, "lowmemorykiller daemon socket open failed");
            sLmkdSocket = null;
            return false;
        }
    }

    @GuardedBy({"sLmkdSocketLock"})
    private static boolean writeLmkdCommandLS(ByteBuffer buf) {
        try {
            sLmkdOutputStream.write(buf.array(), 0, buf.position());
            return true;
        } catch (IOException e) {
            Slog.w(TAG, "Error writing to lowmemorykiller socket");
            IoUtils.closeQuietly(sLmkdSocket);
            sLmkdSocket = null;
            return false;
        }
    }

    @GuardedBy({"sLmkdSocketLock"})
    private static boolean readLmkdReplyLS(ByteBuffer buf) {
        try {
            int len = sLmkdInputStream.read(buf.array(), 0, buf.array().length);
            if (len == buf.array().length) {
                return true;
            }
        } catch (IOException e) {
            Slog.w(TAG, "Error reading from lowmemorykiller socket");
        }
        IoUtils.closeQuietly(sLmkdSocket);
        sLmkdSocket = null;
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:20:0x0028 A[Catch: all -> 0x003f, TryCatch #1 {, blocks: (B:7:0x0007, B:9:0x000b, B:12:0x0013, B:28:0x0039, B:17:0x001a, B:20:0x0028, B:23:0x0030, B:25:0x0036, B:29:0x003c), top: B:37:0x0007 }] */
    private static boolean writeLmkd(ByteBuffer buf, ByteBuffer repl) {
        synchronized (sLmkdSocketLock) {
            for (int i = 0; i < 3; i++) {
                if (sLmkdSocket == null) {
                    if (!openLmkdSocketLS()) {
                        try {
                            Thread.sleep(1000L);
                        } catch (InterruptedException e) {
                        }
                    } else {
                        ByteBuffer purge_buf = ByteBuffer.allocate(4);
                        purge_buf.putInt(3);
                        if (writeLmkdCommandLS(purge_buf)) {
                            if (writeLmkdCommandLS(buf)) {
                                continue;
                            }
                        }
                    }
                } else if (writeLmkdCommandLS(buf) && (repl == null || readLmkdReplyLS(repl))) {
                    return true;
                }
            }
            return false;
        }
    }

    static void killProcessGroup(int uid, int pid) {
        KillHandler killHandler = sKillHandler;
        if (killHandler != null) {
            killHandler.sendMessage(killHandler.obtainMessage(4000, uid, pid));
        } else {
            Slog.w(TAG, "Asked to kill process group before system bringup!");
            Process.killProcessGroup(uid, pid);
        }
    }

    final ProcessRecord getProcessRecordLocked(String processName, int uid, boolean keepIfLarge) {
        if (uid == 1000) {
            SparseArray<ProcessRecord> procs = (SparseArray) this.mProcessNames.getMap().get(processName);
            if (procs == null) {
                return null;
            }
            int procCount = procs.size();
            for (int i = 0; i < procCount; i++) {
                int procUid = procs.keyAt(i);
                if (UserHandle.isCore(procUid) && UserHandle.isSameUser(procUid, uid)) {
                    return procs.valueAt(i);
                }
            }
        }
        ProcessRecord proc = (ProcessRecord) this.mProcessNames.get(processName, uid);
        if (proc != null && !keepIfLarge && this.mService.mLastMemoryLevel > 0 && proc.setProcState >= 20) {
            if (ActivityManagerDebugConfig.DEBUG_PSS) {
                Slog.d(TAG, "May not keep " + proc + ": pss=" + proc.lastCachedPss);
            }
            if (proc.lastCachedPss >= getCachedRestoreThresholdKb()) {
                if (proc.baseProcessTracker != null) {
                    proc.baseProcessTracker.reportCachedKill(proc.pkgList.mPkgList, proc.lastCachedPss);
                    for (int ipkg = proc.pkgList.size() - 1; ipkg >= 0; ipkg--) {
                        ProcessStats.ProcessStateHolder holder = proc.pkgList.valueAt(ipkg);
                        StatsLog.write(17, proc.info.uid, holder.state.getName(), holder.state.getPackage(), proc.lastCachedPss, holder.appVersion);
                    }
                }
                proc.kill(Long.toString(proc.lastCachedPss) + "k from cached", true);
            }
        }
        return proc;
    }

    void getMemoryInfo(ActivityManager.MemoryInfo outInfo) {
        long homeAppMem = getMemLevel(600);
        long cachedAppMem = getMemLevel(CACHED_APP_MIN_ADJ);
        outInfo.availMem = Process.getFreeMemory();
        outInfo.totalMem = Process.getTotalMemory();
        outInfo.threshold = homeAppMem;
        outInfo.lowMemory = outInfo.availMem < ((cachedAppMem - homeAppMem) / 2) + homeAppMem;
        outInfo.hiddenAppThreshold = cachedAppMem;
        outInfo.secondaryServerThreshold = getMemLevel(500);
        outInfo.visibleAppThreshold = getMemLevel(100);
        outInfo.foregroundAppThreshold = getMemLevel(0);
    }

    ProcessRecord findAppProcessLocked(IBinder app, String reason) {
        int NP = this.mProcessNames.getMap().size();
        for (int ip = 0; ip < NP; ip++) {
            SparseArray<ProcessRecord> apps = (SparseArray) this.mProcessNames.getMap().valueAt(ip);
            int NA = apps.size();
            for (int ia = 0; ia < NA; ia++) {
                ProcessRecord p = apps.valueAt(ia);
                if (p.thread != null && p.thread.asBinder() == app) {
                    return p;
                }
            }
        }
        Slog.w(TAG, "Can't find mystery application for " + reason + " from pid=" + Binder.getCallingPid() + " uid=" + Binder.getCallingUid() + ": " + app);
        return null;
    }

    private void checkSlow(long startTime, String where) {
        long now = SystemClock.uptimeMillis();
        if (now - startTime > 50) {
            Slog.w(TAG, "Slow operation: " + (now - startTime) + "ms so far, now at " + where);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v0, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r13v0, types: [com.android.server.am.ProcessRecord, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r15v0, types: [com.android.server.am.ProcessList] */
    /* JADX WARN: Type inference failed for: r15v4, types: [com.android.server.am.ProcessRecord] */
    /* JADX WARN: Type inference failed for: r15v5 */
    /* JADX WARN: Type inference failed for: r15v6 */
    /* JADX WARN: Type inference failed for: r15v8, types: [com.android.server.am.ProcessRecord] */
    /* JADX WARN: Type inference failed for: r2v10, types: [com.android.server.am.ProcessRecord] */
    /* JADX WARN: Type inference failed for: r2v63, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r2v68, types: [com.android.server.am.ActivityManagerService$PidMap] */
    /* JADX WARN: Type inference failed for: r2v70, types: [com.android.server.am.ActivityManagerService$MainHandler] */
    /* JADX WARN: Type inference failed for: r3v61, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r4v1 */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v17 */
    /* JADX WARN: Type inference failed for: r4v20 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v42 */
    /* JADX WARN: Type inference failed for: r4v43 */
    /* JADX WARN: Type inference failed for: r4v44 */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v9, types: [android.content.pm.IPackageManager] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @GuardedBy({"mService"})
    boolean startProcessLocked(ProcessRecord processRecord, HostingRecord hostingRecord, boolean z, boolean z2, String str) {
        long j;
        boolean z3;
        int[] iArr;
        int i;
        String str2;
        String str3;
        String str4;
        int[] iArr2;
        int i2;
        ?? r15 = this;
        r15 = processRecord;
        if (r15.pendingStart) {
            return true;
        }
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        boolean z4 = false;
        if (r15.pid > 0) {
            int i3 = r15.pid;
            i2 = ActivityManagerService.MY_PID;
            if (i3 != i2) {
                j = i2;
                r15.checkSlow(jElapsedRealtime, "startProcess: removing from pids map");
                r15.mService.mPidsSelfLocked.remove(r15);
                r15.mService.mHandler.removeMessages(20, r15);
                r15.checkSlow(jElapsedRealtime, "startProcess: done removing from pids map");
                r15.setPid(0);
                j = 0;
                r15.startSeq = 0L;
            }
        }
        j = i2;
        boolean z5 = ActivityManagerDebugConfig.DEBUG_PROCESSES;
        ?? packageManager = TAG;
        packageManager = j;
        if (z5 && r15.mService.mProcessesOnHold.contains(r15)) {
            packageManager = j;
            Slog.v(TAG, "startProcessLocked removing on hold: " + r15);
            packageManager = "startProcessLocked removing on hold: ";
        }
        packageManager = j;
        r15.mService.mProcessesOnHold.remove((Object) r15);
        r15.checkSlow(jElapsedRealtime, "startProcess: starting to update cpu stats");
        r15.mService.updateCpuStats();
        r15.checkSlow(jElapsedRealtime, "startProcess: done updating cpu stats");
        try {
            try {
                try {
                    int userId = UserHandle.getUserId(r15.uid);
                    packageManager = AppGlobals.getPackageManager();
                    packageManager.checkPackageStartable(r15.info.packageName, userId);
                    int i4 = r15.uid;
                    try {
                        if (r15.isolated) {
                            iArr = null;
                            i = 0;
                        } else {
                            try {
                                r15.checkSlow(jElapsedRealtime, "startProcess: getting gids from package manager");
                                int[] packageGids = AppGlobals.getPackageManager().getPackageGids(r15.info.packageName, 268435456, r15.userId);
                                int externalStorageMountMode = (StorageManager.hasIsolatedStorage() && z2) ? 6 : ((StorageManagerInternal) LocalServices.getService(StorageManagerInternal.class)).getExternalStorageMountMode(i4, r15.info.packageName);
                                if (ArrayUtils.isEmpty(packageGids)) {
                                    iArr2 = new int[3];
                                } else {
                                    iArr2 = new int[packageGids.length + 3];
                                    System.arraycopy(packageGids, 0, iArr2, 3, packageGids.length);
                                }
                                iArr2[0] = UserHandle.getSharedAppGid(UserHandle.getAppId(i4));
                                iArr2[1] = UserHandle.getCacheAppGid(UserHandle.getAppId(i4));
                                iArr2[2] = UserHandle.getUserGid(UserHandle.getUserId(i4));
                                if (iArr2[0] == -1) {
                                    iArr2[0] = iArr2[2];
                                }
                                if (iArr2[1] == -1) {
                                    iArr2[1] = iArr2[2];
                                }
                                i = externalStorageMountMode;
                                iArr = iArr2;
                            } catch (RemoteException e) {
                                throw e.rethrowAsRuntimeException();
                            }
                        }
                        r15.mountMode = i;
                        r15.checkSlow(jElapsedRealtime, "startProcess: building args");
                        int i5 = r15.mService.mAtmInternal.isFactoryTestProcess(processRecord.getWindowProcessController()) ? 0 : i4;
                        int i6 = 0;
                        if ((r15.info.flags & 2) != 0) {
                            i6 = 0 | 1 | 256 | 2;
                            if (Settings.Global.getInt(r15.mService.mContext.getContentResolver(), "art_verifier_verify_debuggable", 1) == 0) {
                                i6 |= 512;
                                Slog.w(TAG, r15 + ": ART verification disabled");
                            }
                        }
                        if ((r15.info.flags & 16384) != 0 || r15.mService.mSafeMode) {
                            i6 |= 8;
                        }
                        if ((r15.info.privateFlags & DumpState.DUMP_VOLUMES) != 0) {
                            i6 |= 32768;
                        }
                        if ("1".equals(SystemProperties.get("debug.checkjni"))) {
                            i6 |= 2;
                        }
                        String str5 = SystemProperties.get("debug.generate-debug-info");
                        if ("1".equals(str5) || "true".equals(str5)) {
                            i6 |= 32;
                        }
                        String str6 = SystemProperties.get("dalvik.vm.minidebuginfo");
                        if ("1".equals(str6) || "true".equals(str6)) {
                            i6 |= 2048;
                        }
                        if ("1".equals(SystemProperties.get("debug.jni.logging"))) {
                            i6 |= 16;
                        }
                        if ("1".equals(SystemProperties.get("debug.assert"))) {
                            i6 |= 4;
                        }
                        if (r15.mService.mNativeDebuggingApp != null && r15.mService.mNativeDebuggingApp.equals(r15.processName)) {
                            i6 = i6 | 64 | 32 | 128;
                            r15.mService.mNativeDebuggingApp = null;
                        }
                        if (r15.info.isEmbeddedDexUsed() || (r15.info.isPrivilegedApp() && DexManager.isPackageSelectedToRunOob(r15.pkgList.mPkgList.keySet()))) {
                            i6 |= 1024;
                        }
                        if (!z && !r15.mService.mHiddenApiBlacklist.isDisabled()) {
                            r15.info.maybeUpdateHiddenApiEnforcementPolicy(r15.mService.mHiddenApiBlacklist.getPolicy());
                            int hiddenApiEnforcementPolicy = r15.info.getHiddenApiEnforcementPolicy();
                            int i7 = hiddenApiEnforcementPolicy << Zygote.API_ENFORCEMENT_POLICY_SHIFT;
                            if ((i7 & 12288) != i7) {
                                throw new IllegalStateException("Invalid API policy: " + hiddenApiEnforcementPolicy);
                            }
                            i6 |= i7;
                        }
                        String str7 = SystemProperties.get(PROPERTY_USE_APP_IMAGE_STARTUP_CACHE, "");
                        int i8 = (TextUtils.isEmpty(str7) || str7.equals("false")) ? i6 : 65536 | i6;
                        String str8 = null;
                        try {
                            if ((r15.info.flags & 2) != 0) {
                                String str9 = r15.info.nativeLibraryDir + "/wrap.sh";
                                StrictMode.ThreadPolicy threadPolicyAllowThreadDiskReads = StrictMode.allowThreadDiskReads();
                                try {
                                    if (new File(str9).exists()) {
                                        str8 = "/system/bin/logwrapper " + str9;
                                    }
                                    StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskReads);
                                    str2 = str8;
                                } catch (Throwable th) {
                                    StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskReads);
                                    throw th;
                                }
                            } else {
                                str2 = null;
                            }
                            if (str != null) {
                                str3 = str;
                            } else {
                                try {
                                    str3 = r15.info.primaryCpuAbi;
                                } catch (RuntimeException e2) {
                                    e = e2;
                                    z3 = false;
                                    Slog.e((String) packageManager, "Failure starting process " + r15.processName, e);
                                    ?? r2 = r15;
                                    this.mService.forceStopPackageLocked(r2.info.packageName, UserHandle.getAppId(r2.uid), false, false, true, false, false, r2.userId, "start failure");
                                    return z3;
                                }
                            }
                            if (str3 == null) {
                                z4 = false;
                                str4 = Build.SUPPORTED_ABIS[0];
                            } else {
                                z4 = false;
                                str4 = str3;
                            }
                            String instructionSet = r15.info.primaryCpuAbi != null ? VMRuntime.getInstructionSet(r15.info.primaryCpuAbi) : null;
                            r15.gids = iArr;
                            r15.setRequiredAbi(str4);
                            r15.instructionSet = instructionSet;
                            if (TextUtils.isEmpty(r15.info.seInfoUser)) {
                                Slog.wtf(TAG, "SELinux tag not defined", new IllegalStateException("SELinux tag not defined for " + r15.info.packageName + " (uid " + r15.uid + ")"));
                            }
                            StringBuilder sb = new StringBuilder();
                            sb.append(r15.info.seInfo);
                            sb.append(TextUtils.isEmpty(r15.info.seInfoUser) ? "" : r15.info.seInfoUser);
                            r15 = r15;
                            z3 = false;
                            try {
                                boolean zStartProcessLocked = startProcessLocked(hostingRecord, "android.app.ActivityThread", processRecord, i5, iArr, i8, i, sb.toString(), str4, instructionSet, str2, jElapsedRealtime);
                                if (r15.processName != null) {
                                    ActivityManagerServiceEx.ProtectArea protectArea = ActivityManagerServiceEx.sPreProtectAreaList.get(r15.processName);
                                    if (protectArea != null) {
                                        r15.protectStatus = protectArea.mLevel;
                                        r15.protectMinAdj = protectArea.mMinAdj;
                                        r15.protectMaxAdj = protectArea.mMaxAdj;
                                    }
                                    if (ActivityManagerServiceEx.DEBUG_AMSEX) {
                                        Slog.d(TAG, "startProcessLocked app.protectLevel :" + r15.protectStatus + " app.protectMinAdj: " + r15.protectMinAdj + " app.protectMaxAdj: " + r15.protectMaxAdj);
                                    }
                                }
                                return zStartProcessLocked;
                            } catch (RuntimeException e3) {
                                e = e3;
                                packageManager = TAG;
                                Slog.e((String) packageManager, "Failure starting process " + r15.processName, e);
                                ?? r3 = r15;
                                this.mService.forceStopPackageLocked(r3.info.packageName, UserHandle.getAppId(r3.uid), false, false, true, false, false, r3.userId, "start failure");
                                return z3;
                            }
                        } catch (RuntimeException e4) {
                            e = e4;
                            packageManager = TAG;
                            r15 = r15;
                            z3 = false;
                        }
                    } catch (RuntimeException e5) {
                        e = e5;
                        packageManager = TAG;
                        r15 = r15;
                        z3 = false;
                    }
                } catch (RemoteException e6) {
                    throw e6.rethrowAsRuntimeException();
                }
            } catch (RuntimeException e7) {
                e = e7;
                z3 = z4;
            }
        } catch (RuntimeException e8) {
            e = e8;
        }
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0091  */
    /* JADX WARN: Code duplicated, block: B:40:0x01af  */
    /* JADX WARN: Code duplicated, block: B:48:? A[RETURN, SYNTHETIC] */
    @GuardedBy({"mService"})
    boolean startProcessLocked(HostingRecord hostingRecord, final String entryPoint, final ProcessRecord app, int uid, final int[] gids, final int runtimeFlags, final int mountExternal, String seInfo, final String requiredAbi, final String instructionSet, final String invokeWith, long startTime) {
        boolean z;
        ProcessList processList;
        ProcessRecord processRecord;
        app.pendingStart = true;
        app.killedByAm = false;
        app.removed = false;
        app.killed = false;
        if (app.startSeq != 0) {
            Slog.wtf(TAG, "startProcessLocked processName:" + app.processName + " with non-zero startSeq:" + app.startSeq);
        }
        if (app.pid != 0) {
            Slog.wtf(TAG, "startProcessLocked processName:" + app.processName + " with non-zero pid:" + app.pid);
        }
        final long startSeq = this.mProcStartSeqCounter + 1;
        this.mProcStartSeqCounter = startSeq;
        app.startSeq = startSeq;
        app.setStartParams(uid, hostingRecord, seInfo, startTime);
        if (invokeWith == null) {
            if (SystemProperties.get("wrap." + app.processName) != null) {
                z = true;
            } else {
                z = false;
            }
        } else {
            z = true;
        }
        app.setUsingWrapper(z);
        this.mPendingStarts.put(startSeq, app);
        final PreForkArgs preforkArgs = new PreForkArgs(entryPoint, app.processName, uid, uid, gids, runtimeFlags, mountExternal, app.info.targetSdkVersion, app.seInfo, requiredAbi, instructionSet, app.info.dataDir, invokeWith, app.info.packageName, new String[]{"seq=" + app.startSeq});
        if (this.mService.mConstants.FLAG_PROCESS_START_ASYNC) {
            if (ActivityManagerDebugConfig.DEBUG_PROCESSES) {
                Slog.i(TAG, "Posting procStart msg for " + app.toShortString());
            }
            this.mService.mProcStartHandler.post(new Runnable() { // from class: com.android.server.am.-$$Lambda$ProcessList$rb16eVEwJVjZ4wX3bDiSZI-mz5Q
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    this.f$0.lambda$startProcessLocked$0$ProcessList(app, entryPoint, gids, runtimeFlags, mountExternal, requiredAbi, instructionSet, invokeWith, startSeq, preforkArgs);
                }
            });
            return true;
        }
        try {
            Process.ProcessStartResult startResult = startProcess(hostingRecord, entryPoint, app, uid, gids, runtimeFlags, mountExternal, seInfo, requiredAbi, instructionSet, invokeWith, startTime);
            handleProcessStartedLocked(app, startResult.pid, startResult.usingWrapper, startSeq, false);
            processList = this;
            try {
                processRecord = app;
                try {
                    processList.mService.notifyProcessStart(processRecord.info.packageName, processRecord.hostingRecord.getType(), startResult.pid);
                    processList.mService.preforkStart(preforkArgs);
                } catch (RuntimeException e) {
                    e = e;
                    Slog.e(TAG, "Failure starting process " + processRecord.processName, e);
                    processRecord.pendingStart = false;
                    processList.mService.forceStopPackageLocked(processRecord.info.packageName, UserHandle.getAppId(processRecord.uid), false, false, true, false, false, processRecord.userId, "start failure");
                }
            } catch (RuntimeException e2) {
                e = e2;
                processRecord = app;
                Slog.e(TAG, "Failure starting process " + processRecord.processName, e);
                processRecord.pendingStart = false;
                processList.mService.forceStopPackageLocked(processRecord.info.packageName, UserHandle.getAppId(processRecord.uid), false, false, true, false, false, processRecord.userId, "start failure");
                if (processRecord.pid > 0) {
                    return true;
                }
                return false;
            }
        } catch (RuntimeException e3) {
            e = e3;
            processList = this;
        }
        if (processRecord.pid > 0) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v3 */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v2, types: [com.android.server.am.ProcessRecord] */
    /* JADX WARN: Type inference failed for: r4v3 */
    public /* synthetic */ void lambda$startProcessLocked$0$ProcessList(ProcessRecord app, String entryPoint, int[] gids, int runtimeFlags, int mountExternal, String requiredAbi, String instructionSet, String invokeWith, long startSeq, PreForkArgs preforkArgs) throws Throwable {
        long j;
        ProcessRecord processRecord;
        try {
            processRecord = entryPoint;
            j = app;
            try {
                Process.ProcessStartResult startResult = startProcess(app.hostingRecord, processRecord, j, app.startUid, gids, runtimeFlags, mountExternal, app.seInfo, requiredAbi, instructionSet, invokeWith, app.startTime);
                try {
                    try {
                        synchronized (this.mService) {
                            try {
                                ActivityManagerService.boostPriorityForLockedSection();
                                try {
                                    handleProcessStartedLocked(app, startResult, startSeq);
                                    this.mService.notifyProcessStart(app.info.packageName, app.hostingRecord.getType(), startResult.pid);
                                    this.mService.preforkStart(preforkArgs);
                                    ActivityManagerService.resetPriorityAfterLockedSection();
                                } catch (Throwable th) {
                                    th = th;
                                    ActivityManagerService.resetPriorityAfterLockedSection();
                                    throw th;
                                }
                            } catch (Throwable th2) {
                                th = th2;
                            }
                        }
                    } catch (RuntimeException e) {
                        e = e;
                        RuntimeException e2 = e;
                        synchronized (this.mService) {
                            try {
                                ActivityManagerService.boostPriorityForLockedSection();
                                Slog.e(TAG, "Failure starting process " + processRecord.processName, e2);
                                this.mPendingStarts.remove(j);
                                processRecord.pendingStart = false;
                                this.mService.forceStopPackageLocked(processRecord.info.packageName, UserHandle.getAppId(processRecord.uid), false, false, true, false, false, processRecord.userId, "start failure");
                            } finally {
                                ActivityManagerService.resetPriorityAfterLockedSection();
                            }
                        }
                    }
                } catch (Throwable th3) {
                    th = th3;
                }
            } catch (RuntimeException e3) {
                e = e3;
                processRecord = app;
                j = startSeq;
            }
        } catch (RuntimeException e4) {
            e = e4;
            j = startSeq;
            processRecord = app;
        }
    }

    @GuardedBy({"mService"})
    public void killAppZygoteIfNeededLocked(AppZygote appZygote) {
        ApplicationInfo appInfo = appZygote.getAppInfo();
        ArrayList<ProcessRecord> zygoteProcesses = this.mAppZygoteProcesses.get(appZygote);
        if (zygoteProcesses != null && zygoteProcesses.size() == 0) {
            this.mAppZygotes.remove(appInfo.processName, appInfo.uid);
            this.mAppZygoteProcesses.remove(appZygote);
            this.mAppIsolatedUidRangeAllocator.freeUidRangeLocked(appInfo);
            appZygote.stopZygote();
        }
    }

    @GuardedBy({"mService"})
    private void removeProcessFromAppZygoteLocked(ProcessRecord app) {
        IsolatedUidRange appUidRange = this.mAppIsolatedUidRangeAllocator.getIsolatedUidRangeLocked(app.info.processName, app.hostingRecord.getDefiningUid());
        if (appUidRange != null) {
            appUidRange.freeIsolatedUidLocked(app.uid);
        }
        AppZygote appZygote = (AppZygote) this.mAppZygotes.get(app.info.processName, app.hostingRecord.getDefiningUid());
        if (appZygote != null) {
            ArrayList<ProcessRecord> zygoteProcesses = this.mAppZygoteProcesses.get(appZygote);
            zygoteProcesses.remove(app);
            if (zygoteProcesses.size() == 0) {
                this.mService.mHandler.removeMessages(71);
                if (app.removed) {
                    killAppZygoteIfNeededLocked(appZygote);
                    return;
                }
                Message msg = this.mService.mHandler.obtainMessage(71);
                msg.obj = appZygote;
                this.mService.mHandler.sendMessageDelayed(msg, 5000L);
            }
        }
    }

    private AppZygote createAppZygoteForProcessIfNeeded(ProcessRecord app) {
        AppZygote appZygote;
        ArrayList<ProcessRecord> zygoteProcessList;
        synchronized (this.mService) {
            try {
                ActivityManagerService.boostPriorityForLockedSection();
                int uid = app.hostingRecord.getDefiningUid();
                appZygote = (AppZygote) this.mAppZygotes.get(app.info.processName, uid);
                if (appZygote == null) {
                    if (ActivityManagerDebugConfig.DEBUG_PROCESSES) {
                        Slog.d(TAG, "Creating new app zygote.");
                    }
                    IsolatedUidRange uidRange = this.mAppIsolatedUidRangeAllocator.getIsolatedUidRangeLocked(app.info.processName, app.hostingRecord.getDefiningUid());
                    int userId = UserHandle.getUserId(uid);
                    int firstUid = UserHandle.getUid(userId, uidRange.mFirstUid);
                    int lastUid = UserHandle.getUid(userId, uidRange.mLastUid);
                    ApplicationInfo appInfo = new ApplicationInfo(app.info);
                    appInfo.packageName = app.hostingRecord.getDefiningPackageName();
                    appInfo.uid = uid;
                    appZygote = new AppZygote(appInfo, uid, firstUid, lastUid);
                    this.mAppZygotes.put(app.info.processName, uid, appZygote);
                    zygoteProcessList = new ArrayList<>();
                    this.mAppZygoteProcesses.put(appZygote, zygoteProcessList);
                } else {
                    if (ActivityManagerDebugConfig.DEBUG_PROCESSES) {
                        Slog.d(TAG, "Reusing existing app zygote.");
                    }
                    this.mService.mHandler.removeMessages(71, appZygote);
                    zygoteProcessList = this.mAppZygoteProcesses.get(appZygote);
                }
                zygoteProcessList.add(app);
            } finally {
                ActivityManagerService.resetPriorityAfterLockedSection();
            }
        }
        return appZygote;
    }

    private Process.ProcessStartResult startProcess(HostingRecord hostingRecord, String entryPoint, ProcessRecord app, int uid, int[] gids, int runtimeFlags, int mountExternal, String seInfo, String requiredAbi, String instructionSet, String invokeWith, long startTime) {
        Process.ProcessStartResult startResult;
        try {
            Trace.traceBegin(64L, "Start proc: " + app.processName);
            checkSlow(startTime, "startProcess: asking zygote to start proc");
            if (hostingRecord.usesWebviewZygote()) {
                startResult = Process.startWebView(entryPoint, app.processName, uid, uid, gids, runtimeFlags, mountExternal, app.info.targetSdkVersion, seInfo, requiredAbi, instructionSet, app.info.dataDir, null, app.info.packageName, new String[]{"seq=" + app.startSeq});
            } else if (hostingRecord.usesAppZygote()) {
                AppZygote appZygote = createAppZygoteForProcessIfNeeded(app);
                startResult = appZygote.getProcess().start(entryPoint, app.processName, uid, uid, gids, runtimeFlags, mountExternal, app.info.targetSdkVersion, seInfo, requiredAbi, instructionSet, app.info.dataDir, (String) null, app.info.packageName, false, new String[]{"seq=" + app.startSeq});
            } else {
                PreForkArgs preforkArgs = new PreForkArgs(entryPoint, app.processName, uid, uid, gids, runtimeFlags, mountExternal, app.info.targetSdkVersion, seInfo, requiredAbi, instructionSet, app.info.dataDir, invokeWith, app.info.packageName, new String[]{"seq=" + app.startSeq});
                startResult = this.mService.handlePreForkStartProcess(preforkArgs);
                if (startResult == null) {
                    startResult = Process.start(entryPoint, app.processName, uid, uid, gids, runtimeFlags, mountExternal, app.info.targetSdkVersion, seInfo, requiredAbi, instructionSet, app.info.dataDir, invokeWith, app.info.packageName, new String[]{"seq=" + app.startSeq});
                }
            }
            checkSlow(startTime, "startProcess: returned from zygote!");
            return startResult;
        } finally {
            Trace.traceEnd(64L);
        }
    }

    @GuardedBy({"mService"})
    final void startProcessLocked(ProcessRecord app, HostingRecord hostingRecord) {
        startProcessLocked(app, hostingRecord, null);
    }

    @GuardedBy({"mService"})
    final boolean startProcessLocked(ProcessRecord app, HostingRecord hostingRecord, String abiOverride) {
        return startProcessLocked(app, hostingRecord, false, false, abiOverride);
    }

    @GuardedBy({"mService"})
    final ProcessRecord startProcessLocked(String processName, ApplicationInfo info, boolean knownToBeDead, int intentFlags, HostingRecord hostingRecord, boolean allowWhileBooting, boolean isolated, int isolatedUid, boolean keepIfLarge, String abiOverride, String entryPoint, String[] entryPointArgs, Runnable crashHandler) {
        ProcessRecord app;
        long startTime = SystemClock.elapsedRealtime();
        if (isolated) {
            app = null;
        } else {
            ProcessRecord app2 = getProcessRecordLocked(processName, info.uid, keepIfLarge);
            checkSlow(startTime, "startProcess: after getProcessRecord");
            if ((intentFlags & 4) != 0) {
                if (this.mService.mAppErrors.isBadProcessLocked(info)) {
                    if (ActivityManagerDebugConfig.DEBUG_PROCESSES) {
                        Slog.v(TAG, "Bad process: " + info.uid + SliceClientPermissions.SliceAuthority.DELIMITER + info.processName);
                    }
                    return null;
                }
            } else {
                if (ActivityManagerDebugConfig.DEBUG_PROCESSES) {
                    Slog.v(TAG, "Clearing bad process: " + info.uid + SliceClientPermissions.SliceAuthority.DELIMITER + info.processName);
                }
                this.mService.mAppErrors.resetProcessCrashTimeLocked(info);
                if (this.mService.mAppErrors.isBadProcessLocked(info)) {
                    EventLog.writeEvent(EventLogTags.AM_PROC_GOOD, Integer.valueOf(UserHandle.getUserId(info.uid)), Integer.valueOf(info.uid), info.processName);
                    this.mService.mAppErrors.clearBadProcessLocked(info);
                    if (app2 != null) {
                        app2.bad = false;
                    }
                }
            }
            app = app2;
        }
        if (ActivityManagerDebugConfig.DEBUG_PROCESSES) {
            StringBuilder sb = new StringBuilder();
            sb.append("startProcess: name=");
            sb.append(processName);
            sb.append(" app=");
            sb.append(app);
            sb.append(" knownToBeDead=");
            sb.append(knownToBeDead);
            sb.append(" thread=");
            sb.append(app != null ? app.thread : null);
            sb.append(" pid=");
            sb.append(app != null ? app.pid : -1);
            Slog.v(TAG, sb.toString());
        }
        if (app != null && app.pid > 0) {
            if ((!knownToBeDead && !app.killed) || (app.thread == null && (!this.mService.mActivityTaskManager.isProcessStartedForTopActivity(app.getWindowProcessController()) || !app.killed))) {
                if (ActivityManagerDebugConfig.DEBUG_PROCESSES) {
                    Slog.v(TAG, "App already running: " + app);
                }
                app.addPackage(info.packageName, info.longVersionCode, this.mService.mProcessStats);
                checkSlow(startTime, "startProcess: done, added package to proc");
                return app;
            }
            if (ActivityManagerDebugConfig.DEBUG_PROCESSES) {
                Slog.v(TAG, "App died: " + app);
            }
            checkSlow(startTime, "startProcess: bad proc running, killing");
            killProcessGroup(app.uid, app.pid);
            this.mService.handleAppDiedLocked(app, true, true);
            checkSlow(startTime, "startProcess: done killing old proc");
        }
        if (app == null) {
            checkSlow(startTime, "startProcess: creating new process record");
            ProcessRecord app3 = newProcessRecordLocked(info, processName, isolated, isolatedUid, hostingRecord);
            if (app3 == null) {
                Slog.w(TAG, "Failed making new process record for " + processName + SliceClientPermissions.SliceAuthority.DELIMITER + info.uid + " isolated=" + isolated);
                return null;
            }
            app3.crashHandler = crashHandler;
            app3.isolatedEntryPoint = entryPoint;
            app3.isolatedEntryPointArgs = entryPointArgs;
            checkSlow(startTime, "startProcess: done creating new process record");
            app = app3;
        } else {
            app.addPackage(info.packageName, info.longVersionCode, this.mService.mProcessStats);
            checkSlow(startTime, "startProcess: added package to existing proc");
        }
        if (this.mService.mProcessesReady || this.mService.isAllowedWhileBooting(info) || allowWhileBooting) {
            checkSlow(startTime, "startProcess: stepping in to startProcess");
            boolean success = startProcessLocked(app, hostingRecord, abiOverride);
            checkSlow(startTime, "startProcess: done starting proc!");
            if (success) {
                return app;
            }
            return null;
        }
        if (!this.mService.mProcessesOnHold.contains(app)) {
            this.mService.mProcessesOnHold.add(app);
        }
        if (ActivityManagerDebugConfig.DEBUG_PROCESSES) {
            Slog.v(TAG, "System not ready, putting on hold: " + app);
        }
        checkSlow(startTime, "startProcess: returning with proc on hold");
        return app;
    }

    @GuardedBy({"mService"})
    private String isProcStartValidLocked(ProcessRecord app, long expectedStartSeq) {
        StringBuilder sb = null;
        boolean isStartedForTopActivity = this.mService.mActivityTaskManager.isProcessStartedForTopActivity(app.getWindowProcessController());
        if (isStartedForTopActivity) {
            app.killedByAm = false;
            app.pendingStart = true;
        }
        if (app.killedByAm) {
            sb = 0 == 0 ? new StringBuilder() : null;
            sb.append("killedByAm=true;");
        }
        if (this.mProcessNames.get(app.processName, app.uid) != app) {
            if (sb == null) {
                sb = new StringBuilder();
            }
            sb.append("No entry in mProcessNames;");
        }
        if (!app.pendingStart) {
            if (sb == null) {
                sb = new StringBuilder();
            }
            sb.append("pendingStart=false;");
        }
        if (app.startSeq > expectedStartSeq) {
            if (sb == null) {
                sb = new StringBuilder();
            }
            sb.append("seq=" + app.startSeq + ",expected=" + expectedStartSeq + ";");
        }
        if (sb == null) {
            return null;
        }
        return sb.toString();
    }

    @GuardedBy({"mService"})
    private boolean handleProcessStartedLocked(ProcessRecord pending, Process.ProcessStartResult startResult, long expectedStartSeq) {
        if (this.mPendingStarts.get(expectedStartSeq) == null) {
            if (pending.pid == startResult.pid) {
                pending.setUsingWrapper(startResult.usingWrapper);
                return false;
            }
            return false;
        }
        return handleProcessStartedLocked(pending, startResult.pid, startResult.usingWrapper, expectedStartSeq, false);
    }

    @GuardedBy({"mService"})
    boolean handleProcessStartedLocked(ProcessRecord app, int pid, boolean usingWrapper, long expectedStartSeq, boolean procAttached) {
        ProcessRecord oldApp;
        this.mPendingStarts.remove(expectedStartSeq);
        String reason = isProcStartValidLocked(app, expectedStartSeq);
        if (reason != null) {
            Slog.w(TAG, app + " start not valid, killing pid=" + pid + ", " + reason);
            app.pendingStart = false;
            Process.killProcessQuiet(pid);
            Process.killProcessGroup(app.uid, app.pid);
            return false;
        }
        this.mService.mBatteryStatsService.noteProcessStart(app.processName, app.info.uid);
        checkSlow(app.startTime, "startProcess: done updating battery stats");
        Object[] objArr = new Object[6];
        objArr[0] = Integer.valueOf(UserHandle.getUserId(app.startUid));
        objArr[1] = Integer.valueOf(pid);
        objArr[2] = Integer.valueOf(app.startUid);
        objArr[3] = app.processName;
        objArr[4] = app.hostingRecord.getType();
        objArr[5] = app.hostingRecord.getName() != null ? app.hostingRecord.getName() : "";
        EventLog.writeEvent(EventLogTags.AM_PROC_START, objArr);
        try {
            AppGlobals.getPackageManager().logAppProcessStartIfNeeded(app.processName, app.uid, app.seInfo, app.info.sourceDir, pid);
        } catch (RemoteException e) {
        }
        if (app.isPersistent()) {
            Watchdog.getInstance().processStarted(app.processName, pid);
        }
        checkSlow(app.startTime, "startProcess: building log message");
        StringBuilder buf = this.mStringBuilder;
        buf.setLength(0);
        buf.append("Start proc ");
        buf.append(pid);
        buf.append(':');
        buf.append(app.processName);
        buf.append('/');
        UserHandle.formatUid(buf, app.startUid);
        if (app.isolatedEntryPoint != null) {
            buf.append(" [");
            buf.append(app.isolatedEntryPoint);
            buf.append("]");
        }
        buf.append(" for ");
        buf.append(app.hostingRecord.getType());
        if (app.hostingRecord.getName() != null) {
            buf.append(" ");
            buf.append(app.hostingRecord.getName());
        }
        this.mService.reportUidInfoMessageLocked(TAG, buf.toString(), app.startUid);
        app.setPid(pid);
        app.setUsingWrapper(usingWrapper);
        app.pendingStart = false;
        checkSlow(app.startTime, "startProcess: starting to update pids map");
        synchronized (this.mService.mPidsSelfLocked) {
            oldApp = this.mService.mPidsSelfLocked.get(pid);
        }
        if (oldApp != null && !app.isolated) {
            Slog.wtf(TAG, "handleProcessStartedLocked process:" + app.processName + " startSeq:" + app.startSeq + " pid:" + pid + " belongs to another existing app:" + oldApp.processName + " startSeq:" + oldApp.startSeq);
            this.mService.cleanUpApplicationRecordLocked(oldApp, false, false, -1, true);
        }
        this.mService.mPidsSelfLocked.put(app);
        synchronized (this.mService.mPidsSelfLocked) {
            if (!procAttached) {
                Message msg = this.mService.mHandler.obtainMessage(20);
                msg.obj = app;
                this.mService.mHandler.sendMessageDelayed(msg, usingWrapper ? 1200000L : JobStatus.DEFAULT_TRIGGER_UPDATE_DELAY);
            }
        }
        checkSlow(app.startTime, "startProcess: done updating pids map");
        return true;
    }

    final void removeLruProcessLocked(ProcessRecord app) {
        int lrui = this.mLruProcesses.lastIndexOf(app);
        if (lrui >= 0) {
            if (!app.killed) {
                if (app.isPersistent()) {
                    Slog.w(TAG, "Removing persistent process that hasn't been killed: " + app);
                } else {
                    Slog.wtfStack(TAG, "Removing process that hasn't been killed: " + app);
                    if (app.pid > 0) {
                        Process.killProcessQuiet(app.pid);
                        killProcessGroup(app.uid, app.pid);
                    } else {
                        app.pendingStart = false;
                    }
                }
            }
            int i = this.mLruProcessActivityStart;
            if (lrui <= i && i > 0) {
                this.mLruProcessActivityStart = i - 1;
            }
            int i2 = this.mLruProcessServiceStart;
            if (lrui <= i2 && i2 > 0) {
                this.mLruProcessServiceStart = i2 - 1;
            }
            this.mLruProcesses.remove(lrui);
        }
    }

    @GuardedBy({"mService"})
    boolean killPackageProcessesLocked(String packageName, int appId, int userId, int minOomAdj, String reason) {
        return killPackageProcessesLocked(packageName, appId, userId, minOomAdj, false, true, true, false, false, reason);
    }

    /* JADX WARN: Code duplicated, block: B:46:0x0097 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:48:0x009a A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:49:0x009c  */
    /* JADX WARN: Code duplicated, block: B:89:0x0099 A[SYNTHETIC] */
    @GuardedBy({"mService"})
    final boolean killPackageProcessesLocked(String packageName, int appId, int userId, int minOomAdj, boolean callerWillRestart, boolean allowRestart, boolean doit, boolean evenPersistent, boolean setRemoved, String reason) {
        int i = appId;
        ArrayList<ProcessRecord> procs = new ArrayList<>();
        int NP = this.mProcessNames.getMap().size();
        for (int ip = 0; ip < NP; ip++) {
            SparseArray<ProcessRecord> apps = (SparseArray) this.mProcessNames.getMap().valueAt(ip);
            int NA = apps.size();
            for (int ia = 0; ia < NA; ia++) {
                ProcessRecord app = apps.valueAt(ia);
                if (!app.isPersistent() || evenPersistent) {
                    if (app.removed) {
                        if (doit) {
                            procs.add(app);
                        }
                    } else if (app.setAdj < minOomAdj) {
                        continue;
                    } else if (packageName == null) {
                        if ((userId == -1 || app.userId == userId) && (i < 0 || UserHandle.getAppId(app.uid) == i)) {
                            if (!doit) {
                                return true;
                            }
                            if (setRemoved) {
                                app.removed = true;
                            }
                            procs.add(app);
                        }
                    } else {
                        boolean isDep = app.pkgDeps != null && app.pkgDeps.contains(packageName);
                        if ((isDep || UserHandle.getAppId(app.uid) == i) && ((userId == -1 || app.userId == userId) && (app.pkgList.containsKey(packageName) || isDep))) {
                            if (!doit) {
                                return true;
                            }
                            if (setRemoved) {
                                app.removed = true;
                            }
                            procs.add(app);
                        }
                    }
                }
            }
        }
        int N = procs.size();
        for (int i2 = 0; i2 < N; i2++) {
            removeProcessLocked(procs.get(i2), callerWillRestart, allowRestart, reason);
        }
        ArrayList<AppZygote> zygotesToKill = new ArrayList<>();
        for (SparseArray<AppZygote> appZygotes : this.mAppZygotes.getMap().values()) {
            int i3 = 0;
            while (i3 < appZygotes.size()) {
                int appZygoteUid = appZygotes.keyAt(i3);
                ArrayList<ProcessRecord> procs2 = procs;
                if ((userId == -1 || UserHandle.getUserId(appZygoteUid) == userId) && (i < 0 || UserHandle.getAppId(appZygoteUid) == i)) {
                    AppZygote appZygote = appZygotes.valueAt(i3);
                    if (packageName == null || packageName.equals(appZygote.getAppInfo().packageName)) {
                        zygotesToKill.add(appZygote);
                    }
                }
                i3++;
                i = appId;
                procs = procs2;
            }
            i = appId;
        }
        Iterator<AppZygote> it = zygotesToKill.iterator();
        while (it.hasNext()) {
            killAppZygoteIfNeededLocked(it.next());
        }
        this.mService.updateOomAdjLocked("updateOomAdj_processEnd");
        return N > 0;
    }

    @GuardedBy({"mService"})
    boolean removeProcessLocked(ProcessRecord app, boolean callerWillRestart, boolean allowRestart, String reason) {
        String name = app.processName;
        int uid = app.uid;
        if (ActivityManagerDebugConfig.DEBUG_PROCESSES) {
            Slog.d(TAG, "Force removing proc " + app.toShortString() + " (" + name + SliceClientPermissions.SliceAuthority.DELIMITER + uid + ")");
        }
        ProcessRecord old = (ProcessRecord) this.mProcessNames.get(name, uid);
        if (old != app) {
            Slog.w(TAG, "Ignoring remove of inactive process: " + app);
            return false;
        }
        removeProcessNameLocked(name, uid);
        this.mService.mAtmInternal.clearHeavyWeightProcessIfEquals(app.getWindowProcessController());
        boolean needRestart = false;
        if ((app.pid > 0 && app.pid != ActivityManagerService.MY_PID) || (app.pid == 0 && app.pendingStart)) {
            int pid = app.pid;
            if (pid > 0) {
                this.mService.mPidsSelfLocked.remove(app);
                this.mService.mHandler.removeMessages(20, app);
                this.mService.mBatteryStatsService.noteProcessFinish(app.processName, app.info.uid);
                if (app.isolated) {
                    this.mService.mBatteryStatsService.removeIsolatedUid(app.uid, app.info.uid);
                    this.mService.getPackageManagerInternalLocked().removeIsolatedUid(app.uid);
                }
            }
            boolean willRestart = false;
            if (app.isPersistent() && !app.isolated) {
                if (!callerWillRestart) {
                    willRestart = true;
                } else {
                    needRestart = true;
                }
            }
            app.kill(reason, true);
            this.mService.handleAppDiedLocked(app, willRestart, allowRestart);
            if (willRestart) {
                removeLruProcessLocked(app);
                this.mService.addAppLocked(app.info, null, false, null);
            }
        } else {
            this.mRemovedProcesses.add(app);
        }
        return needRestart;
    }

    @GuardedBy({"mService"})
    final void addProcessNameLocked(ProcessRecord proc) {
        ProcessRecord old = removeProcessNameLocked(proc.processName, proc.uid);
        if (old == proc && proc.isPersistent()) {
            Slog.w(TAG, "Re-adding persistent process " + proc);
        } else if (old != null) {
            Slog.wtf(TAG, "Already have existing proc " + old + " when adding " + proc);
        }
        UidRecord uidRec = this.mActiveUids.get(proc.uid);
        if (uidRec == null) {
            uidRec = new UidRecord(proc.uid);
            if (ActivityManagerDebugConfig.DEBUG_UID_OBSERVERS) {
                Slog.i(TAG, "Creating new process uid: " + uidRec);
            }
            if (Arrays.binarySearch(this.mService.mDeviceIdleTempWhitelist, UserHandle.getAppId(proc.uid)) >= 0 || this.mService.mPendingTempWhitelist.indexOfKey(proc.uid) >= 0) {
                uidRec.curWhitelist = true;
                uidRec.setWhitelist = true;
            }
            uidRec.updateHasInternetPermission();
            this.mActiveUids.put(proc.uid, uidRec);
            EventLogTags.writeAmUidRunning(uidRec.uid);
            this.mService.noteUidProcessState(uidRec.uid, uidRec.getCurProcState());
        }
        proc.uidRecord = uidRec;
        proc.renderThreadTid = 0;
        uidRec.numProcs++;
        this.mProcessNames.put(proc.processName, proc.uid, proc);
        if (proc.isolated) {
            this.mIsolatedProcesses.put(proc.uid, proc);
        }
    }

    @GuardedBy({"mService"})
    private IsolatedUidRange getOrCreateIsolatedUidRangeLocked(ApplicationInfo info, HostingRecord hostingRecord) {
        if (hostingRecord == null || !hostingRecord.usesAppZygote()) {
            return this.mGlobalIsolatedUids;
        }
        return this.mAppIsolatedUidRangeAllocator.getOrCreateIsolatedUidRangeLocked(info.processName, hostingRecord.getDefiningUid());
    }

    @GuardedBy({"mService"})
    final ProcessRecord newProcessRecordLocked(ApplicationInfo info, String customProcess, boolean isolated, int isolatedUid, HostingRecord hostingRecord) {
        String proc = customProcess != null ? customProcess : info.processName;
        int userId = UserHandle.getUserId(info.uid);
        int uid = info.uid;
        if (isolated) {
            if (isolatedUid == 0) {
                IsolatedUidRange uidRange = getOrCreateIsolatedUidRangeLocked(info, hostingRecord);
                if (uidRange == null || (uid = uidRange.allocateIsolatedUidLocked(userId)) == -1) {
                    return null;
                }
            } else {
                uid = isolatedUid;
            }
            this.mService.getPackageManagerInternalLocked().addIsolatedUid(uid, info.uid);
            this.mService.mBatteryStatsService.addIsolatedUid(uid, info.uid);
            StatsLog.write(43, info.uid, uid, 1);
        }
        ProcessRecord r = new ProcessRecord(this.mService, info, proc, uid);
        if (!this.mService.mBooted && !this.mService.mBooting && userId == 0 && (info.flags & 9) == 9) {
            r.setCurrentSchedulingGroup(2);
            r.setSchedGroup = 2;
            r.setPersistent(true);
            r.maxAdj = PERSISTENT_PROC_ADJ;
        }
        if (isolated && isolatedUid != 0) {
            r.maxAdj = PERSISTENT_SERVICE_ADJ;
        }
        addProcessNameLocked(r);
        return r;
    }

    @GuardedBy({"mService"})
    final ProcessRecord removeProcessNameLocked(String name, int uid) {
        return removeProcessNameLocked(name, uid, null);
    }

    @GuardedBy({"mService"})
    final ProcessRecord removeProcessNameLocked(String name, int uid, ProcessRecord expecting) {
        ProcessRecord old = (ProcessRecord) this.mProcessNames.get(name, uid);
        if (expecting == null || old == expecting) {
            this.mProcessNames.m13remove(name, uid);
        }
        if (old != null && old.uidRecord != null) {
            old.uidRecord.numProcs--;
            if (old.uidRecord.numProcs == 0) {
                if (ActivityManagerDebugConfig.DEBUG_UID_OBSERVERS) {
                    Slog.i(TAG, "No more processes in " + old.uidRecord);
                }
                this.mService.enqueueUidChangeLocked(old.uidRecord, -1, 1);
                EventLogTags.writeAmUidStopped(uid);
                this.mActiveUids.remove(uid);
                this.mService.noteUidProcessState(uid, 21);
            }
            old.uidRecord = null;
        }
        this.mIsolatedProcesses.remove(uid);
        this.mGlobalIsolatedUids.freeIsolatedUidLocked(uid);
        ProcessRecord record = expecting != null ? expecting : old;
        if (record != null && record.appZygote) {
            removeProcessFromAppZygoteLocked(record);
        }
        return old;
    }

    @GuardedBy({"mService"})
    void updateCoreSettingsLocked(Bundle settings) {
        for (int i = this.mLruProcesses.size() - 1; i >= 0; i--) {
            ProcessRecord processRecord = this.mLruProcesses.get(i);
            try {
                if (processRecord.thread != null) {
                    processRecord.thread.setCoreSettings(settings);
                }
            } catch (RemoteException e) {
            }
        }
    }

    @GuardedBy({"mService"})
    void killAllBackgroundProcessesExceptLocked(int minTargetSdk, int maxProcState) {
        ArrayList<ProcessRecord> procs = new ArrayList<>();
        int NP = this.mProcessNames.getMap().size();
        for (int ip = 0; ip < NP; ip++) {
            SparseArray<ProcessRecord> apps = (SparseArray) this.mProcessNames.getMap().valueAt(ip);
            int NA = apps.size();
            for (int ia = 0; ia < NA; ia++) {
                ProcessRecord app = apps.valueAt(ia);
                if (app.removed || ((minTargetSdk < 0 || app.info.targetSdkVersion < minTargetSdk) && (maxProcState < 0 || app.setProcState > maxProcState))) {
                    procs.add(app);
                }
            }
        }
        int N = procs.size();
        for (int i = 0; i < N; i++) {
            removeProcessLocked(procs.get(i), false, true, "kill all background except");
        }
    }

    @GuardedBy({"mService"})
    void updateAllTimePrefsLocked(int timePref) {
        for (int i = this.mLruProcesses.size() - 1; i >= 0; i--) {
            ProcessRecord r = this.mLruProcesses.get(i);
            if (r.thread != null) {
                try {
                    r.thread.updateTimePrefs(timePref);
                } catch (RemoteException e) {
                    Slog.w(TAG, "Failed to update preferences for: " + r.info.processName);
                }
            }
        }
    }

    void setAllHttpProxy() {
        synchronized (this.mService) {
            try {
                ActivityManagerService.boostPriorityForLockedSection();
                for (int i = this.mLruProcesses.size() - 1; i >= 0; i--) {
                    ProcessRecord r = this.mLruProcesses.get(i);
                    if (r.pid != ActivityManagerService.MY_PID && r.thread != null && !r.isolated) {
                        try {
                            r.thread.updateHttpProxy();
                        } catch (RemoteException e) {
                            Slog.w(TAG, "Failed to update http proxy for: " + r.info.processName);
                        }
                    }
                }
            } catch (Throwable th) {
                ActivityManagerService.resetPriorityAfterLockedSection();
                throw th;
            }
        }
        ActivityManagerService.resetPriorityAfterLockedSection();
        ActivityThread.updateHttpProxy(this.mService.mContext);
    }

    @GuardedBy({"mService"})
    void clearAllDnsCacheLocked() {
        for (int i = this.mLruProcesses.size() - 1; i >= 0; i--) {
            ProcessRecord r = this.mLruProcesses.get(i);
            if (r.thread != null) {
                try {
                    r.thread.clearDnsCache();
                } catch (RemoteException e) {
                    Slog.w(TAG, "Failed to clear dns cache for: " + r.info.processName);
                }
            }
        }
    }

    @GuardedBy({"mService"})
    void handleAllTrustStorageUpdateLocked() {
        for (int i = this.mLruProcesses.size() - 1; i >= 0; i--) {
            ProcessRecord r = this.mLruProcesses.get(i);
            if (r.thread != null) {
                try {
                    r.thread.handleTrustStorageUpdate();
                } catch (RemoteException e) {
                    Slog.w(TAG, "Failed to handle trust storage update for: " + r.info.processName);
                }
            }
        }
    }

    @GuardedBy({"mService"})
    int updateLruProcessInternalLocked(ProcessRecord app, long now, int index, int lruSeq, String what, Object obj, ProcessRecord srcApp) {
        app.lastActivityTime = now;
        if (app.hasActivitiesOrRecentTasks()) {
            return index;
        }
        int lrui = this.mLruProcesses.lastIndexOf(app);
        if (lrui < 0) {
            Slog.wtf(TAG, "Adding dependent process " + app + " not on LRU list: " + what + " " + obj + " from " + srcApp);
            return index;
        }
        if (lrui >= index) {
            return index;
        }
        int i = this.mLruProcessActivityStart;
        if (lrui >= i && index < i) {
            return index;
        }
        this.mLruProcesses.remove(lrui);
        if (index > 0) {
            index--;
        }
        if (ActivityManagerDebugConfig.DEBUG_LRU) {
            Slog.d(TAG, "Moving dep from " + lrui + " to " + index + " in LRU list: " + app);
        }
        this.mLruProcesses.add(index, app);
        app.lruSeq = lruSeq;
        return index;
    }

    private void updateClientActivitiesOrdering(ProcessRecord topApp, int topI, int bottomI, int endIndex) {
        int endIndex2;
        int endImportance;
        ProcessRecord processRecord = topApp;
        if (topApp.hasActivitiesOrRecentTasks() || processRecord.treatLikeActivity || !topApp.hasClientActivities()) {
            return;
        }
        int uid = processRecord.info.uid;
        if (processRecord.connectionGroup <= 0) {
            endIndex2 = endIndex;
        } else {
            int endImportance2 = processRecord.connectionImportance;
            int i = endIndex;
            endIndex2 = endIndex;
            while (i >= bottomI) {
                ProcessRecord subProc = this.mLruProcesses.get(i);
                if (subProc.info.uid != uid || subProc.connectionGroup != processRecord.connectionGroup) {
                    endImportance2 = endImportance2;
                } else if (i == endIndex2 && subProc.connectionImportance >= endImportance2) {
                    if (ActivityManagerDebugConfig.DEBUG_LRU) {
                        Slog.d(TAG, "Keeping in-place above " + subProc + " endImportance=" + endImportance2 + " group=" + subProc.connectionGroup + " importance=" + subProc.connectionImportance);
                    }
                    endIndex2--;
                    endImportance2 = subProc.connectionImportance;
                } else {
                    if (ActivityManagerDebugConfig.DEBUG_LRU) {
                        Slog.d(TAG, "Pulling up " + subProc + " to position in group with importance=" + subProc.connectionImportance);
                    }
                    boolean moved = false;
                    int pos = topI;
                    while (true) {
                        if (pos <= endIndex2) {
                            endImportance = endImportance2;
                            break;
                        }
                        ProcessRecord posProc = this.mLruProcesses.get(pos);
                        int i2 = subProc.connectionImportance;
                        endImportance = endImportance2;
                        int endImportance3 = posProc.connectionImportance;
                        if (i2 > endImportance3) {
                            pos--;
                            endImportance2 = endImportance;
                        } else {
                            this.mLruProcesses.remove(i);
                            this.mLruProcesses.add(pos, subProc);
                            if (ActivityManagerDebugConfig.DEBUG_LRU) {
                                Slog.d(TAG, "Moving " + subProc + " from position " + i + " to above " + posProc + " @ " + pos);
                            }
                            moved = true;
                            endIndex2--;
                            break;
                        }
                    }
                    if (moved) {
                        endImportance2 = endImportance;
                    } else {
                        this.mLruProcesses.remove(i);
                        this.mLruProcesses.add(endIndex2 - 1, subProc);
                        if (ActivityManagerDebugConfig.DEBUG_LRU) {
                            Slog.d(TAG, "Moving " + subProc + " from position " + i + " to end of group @ " + endIndex2);
                        }
                        endIndex2--;
                        endImportance2 = subProc.connectionImportance;
                    }
                }
                i--;
                processRecord = topApp;
            }
        }
        int i3 = endIndex2;
        while (i3 >= bottomI) {
            ProcessRecord subProc2 = this.mLruProcesses.get(i3);
            if (ActivityManagerDebugConfig.DEBUG_LRU) {
                Slog.d(TAG, "Looking to spread old procs, at " + subProc2 + " @ " + i3);
            }
            if (subProc2.info.uid != uid) {
                if (i3 < endIndex2) {
                    boolean hasActivity = false;
                    int connUid = 0;
                    int connGroup = 0;
                    while (i3 >= bottomI) {
                        this.mLruProcesses.remove(i3);
                        this.mLruProcesses.add(endIndex2, subProc2);
                        if (ActivityManagerDebugConfig.DEBUG_LRU) {
                            Slog.d(TAG, "Different app, moving to " + endIndex2);
                        }
                        i3--;
                        if (i3 < bottomI) {
                            break;
                        }
                        subProc2 = this.mLruProcesses.get(i3);
                        if (ActivityManagerDebugConfig.DEBUG_LRU) {
                            Slog.d(TAG, "Looking at next app at " + i3 + ": " + subProc2);
                        }
                        if (subProc2.hasActivitiesOrRecentTasks() || subProc2.treatLikeActivity) {
                            if (ActivityManagerDebugConfig.DEBUG_LRU) {
                                Slog.d(TAG, "This is hosting an activity!");
                            }
                            if (hasActivity) {
                                if (!ActivityManagerDebugConfig.DEBUG_LRU) {
                                    break;
                                }
                                Slog.d(TAG, "Already found an activity, done");
                                break;
                            }
                            hasActivity = true;
                            endIndex2--;
                        } else {
                            if (subProc2.hasClientActivities()) {
                                if (ActivityManagerDebugConfig.DEBUG_LRU) {
                                    Slog.d(TAG, "This is a client of an activity");
                                }
                                if (hasActivity) {
                                    if (connUid == 0 || connUid != subProc2.info.uid) {
                                        if (!ActivityManagerDebugConfig.DEBUG_LRU) {
                                            break;
                                        }
                                        Slog.d(TAG, "Already found a different activity: connUid=" + connUid + " uid=" + subProc2.info.uid);
                                        break;
                                    }
                                    if (connGroup == 0 || connGroup != subProc2.connectionGroup) {
                                        if (!ActivityManagerDebugConfig.DEBUG_LRU) {
                                            break;
                                        }
                                        Slog.d(TAG, "Already found a different group: connGroup=" + connGroup + " group=" + subProc2.connectionGroup);
                                        break;
                                    }
                                } else {
                                    if (ActivityManagerDebugConfig.DEBUG_LRU) {
                                        Slog.d(TAG, "This is an activity client!  uid=" + subProc2.info.uid + " group=" + subProc2.connectionGroup);
                                    }
                                    hasActivity = true;
                                    connUid = subProc2.info.uid;
                                    connGroup = subProc2.connectionGroup;
                                }
                            } else {
                                continue;
                            }
                            endIndex2--;
                        }
                    }
                }
                while (true) {
                    endIndex2--;
                    if (endIndex2 < bottomI) {
                        break;
                    }
                    ProcessRecord endProc = this.mLruProcesses.get(endIndex2);
                    if (endProc.info.uid == uid) {
                        if (!ActivityManagerDebugConfig.DEBUG_LRU) {
                            break;
                        }
                        Slog.d(TAG, "Found next group of app: " + endProc + " @ " + endIndex2);
                        break;
                    }
                }
                if (endIndex2 >= bottomI) {
                    ProcessRecord endProc2 = this.mLruProcesses.get(endIndex2);
                    while (true) {
                        endIndex2--;
                        if (endIndex2 < bottomI) {
                            break;
                        }
                        ProcessRecord nextEndProc = this.mLruProcesses.get(endIndex2);
                        if (nextEndProc.info.uid != uid || nextEndProc.connectionGroup != endProc2.connectionGroup) {
                            if (!ActivityManagerDebugConfig.DEBUG_LRU) {
                                break;
                            }
                            Slog.d(TAG, "Found next group or app: " + nextEndProc + " @ " + endIndex2 + " group=" + nextEndProc.connectionGroup);
                            break;
                        }
                    }
                }
                if (ActivityManagerDebugConfig.DEBUG_LRU) {
                    Slog.d(TAG, "Bumping scan position to " + endIndex2);
                }
                i3 = endIndex2;
            } else {
                i3--;
            }
        }
    }

    final void updateLruProcessLocked(ProcessRecord app, boolean activityChange, ProcessRecord client) {
        int nextIndex;
        long now;
        boolean hasActivity = app.hasActivitiesOrRecentTasks() || app.hasClientActivities() || app.treatLikeActivity;
        if (activityChange || !hasActivity) {
            this.mLruSeq++;
            long now2 = SystemClock.uptimeMillis();
            app.lastActivityTime = now2;
            if (hasActivity) {
                int N = this.mLruProcesses.size();
                if (N > 0 && this.mLruProcesses.get(N - 1) == app) {
                    if (ActivityManagerDebugConfig.DEBUG_LRU) {
                        Slog.d(TAG, "Not moving, already top activity: " + app);
                        return;
                    }
                    return;
                }
            } else {
                int i = this.mLruProcessServiceStart;
                if (i > 0 && this.mLruProcesses.get(i - 1) == app) {
                    if (ActivityManagerDebugConfig.DEBUG_LRU) {
                        Slog.d(TAG, "Not moving, already top other: " + app);
                        return;
                    }
                    return;
                }
            }
            int lrui = this.mLruProcesses.lastIndexOf(app);
            if (app.isPersistent() && lrui >= 0) {
                if (ActivityManagerDebugConfig.DEBUG_LRU) {
                    Slog.d(TAG, "Not moving, persistent: " + app);
                    return;
                }
                return;
            }
            if (lrui >= 0) {
                int i2 = this.mLruProcessActivityStart;
                if (lrui < i2) {
                    this.mLruProcessActivityStart = i2 - 1;
                }
                int i3 = this.mLruProcessServiceStart;
                if (lrui < i3) {
                    this.mLruProcessServiceStart = i3 - 1;
                }
                this.mLruProcesses.remove(lrui);
            }
            int nextActivityIndex = -1;
            if (hasActivity) {
                int N2 = this.mLruProcesses.size();
                int nextIndex2 = this.mLruProcessServiceStart;
                if (!app.hasActivitiesOrRecentTasks() && !app.treatLikeActivity && this.mLruProcessActivityStart < N2 - 1) {
                    if (ActivityManagerDebugConfig.DEBUG_LRU) {
                        Slog.d(TAG, "Adding to second-top of LRU activity list: " + app + " group=" + app.connectionGroup + " importance=" + app.connectionImportance);
                    }
                    int pos = N2 - 1;
                    while (pos > this.mLruProcessActivityStart) {
                        ProcessRecord posproc = this.mLruProcesses.get(pos);
                        if (posproc.info.uid == app.info.uid) {
                            break;
                        } else {
                            pos--;
                        }
                    }
                    this.mLruProcesses.add(pos, app);
                    int i4 = this.mLruProcessActivityStart;
                    if (pos == i4) {
                        this.mLruProcessActivityStart = i4 + 1;
                    }
                    int i5 = this.mLruProcessServiceStart;
                    if (pos == i5) {
                        this.mLruProcessServiceStart = i5 + 1;
                    }
                    int endIndex = pos - 1;
                    if (endIndex < this.mLruProcessActivityStart) {
                        endIndex = this.mLruProcessActivityStart;
                    }
                    nextActivityIndex = endIndex;
                    updateClientActivitiesOrdering(app, pos, this.mLruProcessActivityStart, endIndex);
                } else {
                    if (ActivityManagerDebugConfig.DEBUG_LRU) {
                        Slog.d(TAG, "Adding to top of LRU activity list: " + app);
                    }
                    this.mLruProcesses.add(app);
                    nextActivityIndex = this.mLruProcesses.size() - 1;
                }
                nextIndex = nextIndex2;
            } else {
                int index = this.mLruProcessServiceStart;
                if (client != null) {
                    int clientIndex = this.mLruProcesses.lastIndexOf(client);
                    if (ActivityManagerDebugConfig.DEBUG_LRU && clientIndex < 0) {
                        Slog.d(TAG, "Unknown client " + client + " when updating " + app);
                    }
                    if (clientIndex <= lrui) {
                        clientIndex = lrui;
                    }
                    if (clientIndex >= 0 && index > clientIndex) {
                        index = clientIndex;
                    }
                }
                if (ActivityManagerDebugConfig.DEBUG_LRU) {
                    Slog.d(TAG, "Adding at " + index + " of LRU list: " + app);
                }
                this.mLruProcesses.add(index, app);
                nextIndex = index - 1;
                this.mLruProcessActivityStart++;
                this.mLruProcessServiceStart++;
                if (index > 1) {
                    updateClientActivitiesOrdering(app, this.mLruProcessServiceStart - 1, 0, index - 1);
                }
            }
            app.lruSeq = this.mLruSeq;
            int nextIndex3 = nextIndex;
            int j = app.connections.size() - 1;
            int nextActivityIndex2 = nextActivityIndex;
            while (j >= 0) {
                ConnectionRecord cr = app.connections.valueAt(j);
                if (cr.binding == null || cr.serviceDead || cr.binding.service == null || cr.binding.service.app == null || cr.binding.service.app.lruSeq == this.mLruSeq || (cr.flags & 1073742128) != 0) {
                    now = now2;
                } else if (cr.binding.service.app.isPersistent()) {
                    now = now2;
                } else if (cr.binding.service.app.hasClientActivities()) {
                    if (nextActivityIndex2 >= 0) {
                        now = now2;
                        nextActivityIndex2 = updateLruProcessInternalLocked(cr.binding.service.app, now2, nextActivityIndex2, this.mLruSeq, "service connection", cr, app);
                    } else {
                        now = now2;
                    }
                } else {
                    now = now2;
                    nextIndex3 = updateLruProcessInternalLocked(cr.binding.service.app, now, nextIndex3, this.mLruSeq, "service connection", cr, app);
                }
                j--;
                now2 = now;
            }
            long now3 = now2;
            for (int j2 = app.conProviders.size() - 1; j2 >= 0; j2--) {
                ContentProviderRecord cpr = app.conProviders.get(j2).provider;
                if (cpr.proc != null && cpr.proc.lruSeq != this.mLruSeq && !cpr.proc.isPersistent()) {
                    nextIndex3 = updateLruProcessInternalLocked(cpr.proc, now3, nextIndex3, this.mLruSeq, "provider reference", cpr, app);
                }
            }
        }
    }

    final ProcessRecord getLRURecordForAppLocked(IApplicationThread thread) {
        IBinder threadBinder = thread.asBinder();
        for (int i = this.mLruProcesses.size() - 1; i >= 0; i--) {
            ProcessRecord rec = this.mLruProcesses.get(i);
            if (rec.thread != null && rec.thread.asBinder() == threadBinder) {
                return rec;
            }
        }
        return null;
    }

    boolean haveBackgroundProcessLocked() {
        for (int i = this.mLruProcesses.size() - 1; i >= 0; i--) {
            ProcessRecord rec = this.mLruProcesses.get(i);
            if (rec.thread != null && rec.setProcState >= 17) {
                return true;
            }
        }
        return false;
    }

    private static int procStateToImportance(int procState, int memAdj, ActivityManager.RunningAppProcessInfo currApp, int clientTargetSdk) {
        int imp = ActivityManager.RunningAppProcessInfo.procStateToImportanceForTargetSdk(procState, clientTargetSdk);
        if (imp == HEAVY_WEIGHT_APP_ADJ) {
            currApp.lru = memAdj;
        } else {
            currApp.lru = 0;
        }
        return imp;
    }

    @GuardedBy({"mService"})
    void fillInProcMemInfoLocked(ProcessRecord app, ActivityManager.RunningAppProcessInfo outInfo, int clientTargetSdk) {
        outInfo.pid = app.pid;
        outInfo.uid = app.info.uid;
        if (this.mService.mAtmInternal.isHeavyWeightProcess(app.getWindowProcessController())) {
            outInfo.flags |= 1;
        }
        if (app.isPersistent()) {
            outInfo.flags |= 2;
        }
        if (app.hasActivities()) {
            outInfo.flags |= 4;
        }
        outInfo.lastTrimLevel = app.trimMemoryLevel;
        int adj = app.curAdj;
        int procState = app.getCurProcState();
        outInfo.importance = procStateToImportance(procState, adj, outInfo, clientTargetSdk);
        outInfo.importanceReasonCode = app.adjTypeCode;
        outInfo.processState = app.getCurProcState();
        outInfo.isFocused = app == this.mService.getTopAppLocked();
        outInfo.lastActivityTime = app.lastActivityTime;
    }

    @GuardedBy({"mService"})
    List<ActivityManager.RunningAppProcessInfo> getRunningAppProcessesLocked(boolean allUsers, int userId, boolean allUids, int callingUid, int clientTargetSdk) {
        List<ActivityManager.RunningAppProcessInfo> runList = null;
        for (int i = this.mLruProcesses.size() - 1; i >= 0; i--) {
            ProcessRecord app = this.mLruProcesses.get(i);
            if ((allUsers || app.userId == userId) && ((allUids || app.uid == callingUid) && app.thread != null && !app.isCrashing() && !app.isNotResponding())) {
                ActivityManager.RunningAppProcessInfo currApp = new ActivityManager.RunningAppProcessInfo(app.processName, app.pid, app.getPackageList());
                fillInProcMemInfoLocked(app, currApp, clientTargetSdk);
                if (app.adjSource instanceof ProcessRecord) {
                    currApp.importanceReasonPid = ((ProcessRecord) app.adjSource).pid;
                    currApp.importanceReasonImportance = ActivityManager.RunningAppProcessInfo.procStateToImportance(app.adjSourceProcState);
                } else if (app.adjSource instanceof ActivityServiceConnectionsHolder) {
                    ActivityServiceConnectionsHolder r = (ActivityServiceConnectionsHolder) app.adjSource;
                    int pid = r.getActivityPid();
                    if (pid != -1) {
                        currApp.importanceReasonPid = pid;
                    }
                }
                if (app.adjTarget instanceof ComponentName) {
                    currApp.importanceReasonComponent = (ComponentName) app.adjTarget;
                }
                if (runList == null) {
                    runList = new ArrayList<>();
                }
                runList.add(currApp);
            }
        }
        return runList;
    }

    @GuardedBy({"mService"})
    int getLruSizeLocked() {
        return this.mLruProcesses.size();
    }

    @GuardedBy({"mService"})
    void dumpLruListHeaderLocked(PrintWriter pw) {
        pw.print("  Process LRU list (sorted by oom_adj, ");
        pw.print(this.mLruProcesses.size());
        pw.print(" total, non-act at ");
        pw.print(this.mLruProcesses.size() - this.mLruProcessActivityStart);
        pw.print(", non-svc at ");
        pw.print(this.mLruProcesses.size() - this.mLruProcessServiceStart);
        pw.println("):");
    }

    @GuardedBy({"mService"})
    ArrayList<ProcessRecord> collectProcessesLocked(int start, boolean allPkgs, String[] args) {
        if (args != null && args.length > start && args[start].charAt(0) != '-') {
            ArrayList<ProcessRecord> procs = new ArrayList<>();
            int pid = -1;
            try {
                pid = Integer.parseInt(args[start]);
            } catch (NumberFormatException e) {
            }
            for (int i = this.mLruProcesses.size() - 1; i >= 0; i--) {
                ProcessRecord proc = this.mLruProcesses.get(i);
                if (proc.pid > 0 && proc.pid == pid) {
                    procs.add(proc);
                } else if (allPkgs && proc.pkgList != null && proc.pkgList.containsKey(args[start])) {
                    procs.add(proc);
                } else if (proc.processName.equals(args[start])) {
                    procs.add(proc);
                }
            }
            int i2 = procs.size();
            if (i2 <= 0) {
                return null;
            }
            return procs;
        }
        return new ArrayList<>(this.mLruProcesses);
    }

    @GuardedBy({"mService"})
    void updateApplicationInfoLocked(List<String> packagesToUpdate, int userId, boolean updateFrameworkRes) {
        for (int i = this.mLruProcesses.size() - 1; i >= 0; i--) {
            ProcessRecord app = this.mLruProcesses.get(i);
            if (app.info != null && (updateFrameworkRes || packagesToUpdate.contains(app.info.packageName))) {
                try {
                    ApplicationInfo ai = AppGlobals.getPackageManager().getApplicationInfo(app.info.packageName, 1024, app.userId);
                    if (ai != null) {
                        app.updateApplicationInfoLocked(ai);
                    }
                    if (ActivityManagerDebugConfig.DEBUG_LRU) {
                        Slog.d(TAG, "Updated to " + app + " resourceDirs = " + Arrays.toString(app.info.resourceDirs));
                    }
                } catch (RemoteException e) {
                }
            }
            if (app.thread != null && (userId == -1 || app.userId == userId)) {
                int packageCount = app.pkgList.size();
                for (int j = 0; j < packageCount; j++) {
                    String packageName = app.pkgList.keyAt(j);
                    if (updateFrameworkRes || packagesToUpdate.contains(packageName)) {
                        try {
                            ApplicationInfo ai2 = AppGlobals.getPackageManager().getApplicationInfo(packageName, 1024, app.userId);
                            if (ai2 != null) {
                                app.thread.scheduleApplicationInfoChanged(ai2);
                            }
                        } catch (RemoteException e2) {
                            Slog.w(TAG, String.format("Failed to update %s ApplicationInfo for %s", packageName, app));
                        }
                    }
                }
            }
        }
    }

    @GuardedBy({"mService"})
    void sendPackageBroadcastLocked(int cmd, String[] packages, int userId) {
        boolean foundProcess = false;
        for (int i = this.mLruProcesses.size() - 1; i >= 0; i--) {
            ProcessRecord r = this.mLruProcesses.get(i);
            if (r.thread != null && (userId == -1 || r.userId == userId)) {
                try {
                    for (int index = packages.length - 1; index >= 0 && !foundProcess; index--) {
                        if (packages[index].equals(r.info.packageName)) {
                            foundProcess = true;
                        }
                    }
                    r.thread.dispatchPackageBroadcast(cmd, packages);
                } catch (RemoteException e) {
                }
            }
        }
        if (!foundProcess) {
            try {
                AppGlobals.getPackageManager().notifyPackagesReplacedReceived(packages);
            } catch (RemoteException e2) {
            }
        }
    }

    @GuardedBy({"mService"})
    int getUidProcStateLocked(int uid) {
        UidRecord uidRec = this.mActiveUids.get(uid);
        if (uidRec == null) {
            return 21;
        }
        return uidRec.getCurProcState();
    }

    @GuardedBy({"mService"})
    UidRecord getUidRecordLocked(int uid) {
        return this.mActiveUids.get(uid);
    }

    @GuardedBy({"mService"})
    void doStopUidForIdleUidsLocked() {
        int size = this.mActiveUids.size();
        for (int i = 0; i < size; i++) {
            int uid = this.mActiveUids.keyAt(i);
            if (!UserHandle.isCore(uid)) {
                UidRecord uidRec = this.mActiveUids.valueAt(i);
                if (uidRec.idle) {
                    this.mService.doStopUidLocked(uidRec.uid, uidRec);
                }
            }
        }
    }

    private boolean calcLmkMinfree(boolean write) {
        boolean autocalc = SystemProperties.getBoolean("sys.lmk.autocalc", true);
        int[] iArr = this.mOomAdj;
        int[] tmpOomAdj = new int[iArr.length];
        int[] tmpOomMinFree = new int[iArr.length];
        if (!autocalc) {
            String adj = SystemProperties.get("sys.lmk.adj", "");
            String minfree = SystemProperties.get("sys.lmk.minfree", "");
            if (!TextUtils.isEmpty(adj) && !TextUtils.isEmpty(minfree)) {
                try {
                    String[] adjs = adj.split(",");
                    String[] minfrees = minfree.split(",");
                    int length = Math.min(adjs.length, this.mOomAdj.length);
                    for (int i = 0; i < length; i++) {
                        tmpOomAdj[i] = Integer.parseInt(adjs[i]);
                        if (tmpOomAdj[i] < 1001 && tmpOomAdj[i] >= 0) {
                            tmpOomMinFree[i] = (Integer.parseInt(minfrees[i]) * 4096) / 1024;
                        }
                        Slog.w(TAG, "lmk custom adj has error value(" + tmpOomAdj[i] + ").");
                        return false;
                    }
                    for (int i2 = 0; i2 < this.mOomAdj.length; i2++) {
                        if (i2 < length) {
                            this.mOomAdj[i2] = tmpOomAdj[i2];
                            this.mOomMinFree[i2] = tmpOomMinFree[i2];
                        } else {
                            this.mOomAdj[i2] = tmpOomAdj[length - 1];
                            this.mOomMinFree[i2] = tmpOomMinFree[length - 1];
                        }
                    }
                    if (write) {
                        ByteBuffer buf = ByteBuffer.allocate(((this.mOomAdj.length * 2) + 1) * 4);
                        buf.putInt(0);
                        for (int i3 = 0; i3 < length; i3++) {
                            buf.putInt((this.mOomMinFree[i3] * 1024) / 4096);
                            buf.putInt(this.mOomAdj[i3]);
                        }
                        writeLmkd(buf, null);
                    }
                    return true;
                } catch (Exception e) {
                    Slog.w(TAG, "calc lmk minfree fail.");
                }
            }
        }
        return false;
    }
}
