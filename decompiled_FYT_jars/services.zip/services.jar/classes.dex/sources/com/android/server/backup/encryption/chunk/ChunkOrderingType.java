package com.android.server.backup.encryption.chunk;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
@Retention(RetentionPolicy.SOURCE)
public @interface ChunkOrderingType {
}
