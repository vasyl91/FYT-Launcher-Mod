package com.android.server.backup.encryption.chunking;

import java.io.IOException;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public interface EncryptedChunkEncoder {
    int getChunkOrderingType();

    int getEncodedLengthOfChunk(EncryptedChunk encryptedChunk);

    void writeChunkToWriter(BackupWriter backupWriter, EncryptedChunk encryptedChunk) throws IOException;
}
