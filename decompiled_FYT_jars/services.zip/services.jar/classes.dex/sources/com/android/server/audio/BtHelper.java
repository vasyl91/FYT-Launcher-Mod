package com.android.server.audio;

import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothCodecConfig;
import android.bluetooth.BluetoothCodecStatus;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHeadset;
import android.bluetooth.BluetoothHearingAid;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.media.AudioSystem;
import android.os.Binder;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.UserHandle;
import android.provider.Settings;
import android.util.Log;
import com.android.internal.annotations.GuardedBy;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class BtHelper {
    private static final int BT_HEARING_AID_GAIN_MIN = -128;
    static final int EVENT_ACTIVE_DEVICE_CHANGE = 1;
    static final int EVENT_DEVICE_CONFIG_CHANGE = 0;
    private static final int SCO_MODE_MAX = 2;
    private static final int SCO_MODE_RAW = 1;
    static final int SCO_MODE_UNDEFINED = -1;
    static final int SCO_MODE_VIRTUAL_CALL = 0;
    private static final int SCO_MODE_VR = 2;
    private static final int SCO_STATE_ACTIVATE_REQ = 1;
    private static final int SCO_STATE_ACTIVE_EXTERNAL = 2;
    private static final int SCO_STATE_ACTIVE_INTERNAL = 3;
    private static final int SCO_STATE_DEACTIVATE_REQ = 4;
    private static final int SCO_STATE_DEACTIVATING = 5;
    private static final int SCO_STATE_INACTIVE = 0;
    private static final String TAG = "AS.BtHelper";
    private BluetoothA2dp mA2dp;
    private BluetoothHeadset mBluetoothHeadset;
    private BluetoothDevice mBluetoothHeadsetDevice;
    private final AudioDeviceBroker mDeviceBroker;
    private BluetoothHearingAid mHearingAid;
    private int mScoAudioMode;
    private int mScoAudioState;
    private int mScoConnectionState;
    private final ArrayList<ScoClient> mScoClients = new ArrayList<>();
    private boolean mAvrcpAbsVolSupported = false;
    private BluetoothProfile.ServiceListener mBluetoothProfileServiceListener = new BluetoothProfile.ServiceListener() { // from class: com.android.server.audio.BtHelper.1
        @Override // android.bluetooth.BluetoothProfile.ServiceListener
        public void onServiceConnected(int profile, BluetoothProfile proxy) {
            Log.d(BtHelper.TAG, "onServiceConnected() profile: " + profile + ", proxy: " + proxy);
            if (profile == 1) {
                AudioService.sDeviceLogger.log(new AudioEventLogger.StringEvent("BT profile service: connecting HEADSET profile"));
                BtHelper.this.mDeviceBroker.postBtHeasetProfileConnected((BluetoothHeadset) proxy);
                return;
            }
            if (profile == 2) {
                AudioService.sDeviceLogger.log(new AudioEventLogger.StringEvent("BT profile service: connecting A2DP profile"));
                BtHelper.this.mDeviceBroker.postBtA2dpProfileConnected((BluetoothA2dp) proxy);
            } else if (profile == 11) {
                AudioService.sDeviceLogger.log(new AudioEventLogger.StringEvent("BT profile service: connecting A2DP_SINK profile"));
                BtHelper.this.mDeviceBroker.postBtA2dpSinkProfileConnected(proxy);
            } else if (profile == 21) {
                AudioService.sDeviceLogger.log(new AudioEventLogger.StringEvent("BT profile service: connecting HEARING_AID profile"));
                BtHelper.this.mDeviceBroker.postBtHearingAidProfileConnected((BluetoothHearingAid) proxy);
            }
        }

        @Override // android.bluetooth.BluetoothProfile.ServiceListener
        public void onServiceDisconnected(int profile) {
            Log.d(BtHelper.TAG, "onServiceDisconnected() profile: " + profile);
            if (profile == 1) {
                BtHelper.this.mDeviceBroker.postDisconnectHeadset();
                return;
            }
            if (profile == 2) {
                BtHelper.this.mDeviceBroker.postDisconnectA2dp();
            } else if (profile == 11) {
                BtHelper.this.mDeviceBroker.postDisconnectA2dpSink();
            } else if (profile == 21) {
                BtHelper.this.mDeviceBroker.postDisconnectHearingAid();
            }
        }
    };

    BtHelper(AudioDeviceBroker broker) {
        this.mDeviceBroker = broker;
    }

    static class BluetoothA2dpDeviceInfo {
        private final BluetoothDevice mBtDevice;
        private final int mCodec;
        private final int mVolume;

        BluetoothA2dpDeviceInfo(BluetoothDevice btDevice) {
            this(btDevice, -1, 0);
        }

        BluetoothA2dpDeviceInfo(BluetoothDevice btDevice, int volume, int codec) {
            this.mBtDevice = btDevice;
            this.mVolume = volume;
            this.mCodec = codec;
        }

        public BluetoothDevice getBtDevice() {
            return this.mBtDevice;
        }

        public int getVolume() {
            return this.mVolume;
        }

        public int getCodec() {
            return this.mCodec;
        }
    }

    static String a2dpDeviceEventToString(int event) {
        if (event == 0) {
            return "DEVICE_CONFIG_CHANGE";
        }
        if (event == 1) {
            return "ACTIVE_DEVICE_CHANGE";
        }
        return new String("invalid event:" + event);
    }

    static String getName(BluetoothDevice device) {
        String deviceName = device.getName();
        if (deviceName == null) {
            return "";
        }
        return deviceName;
    }

    @GuardedBy({"AudioDeviceBroker.mDeviceStateLock"})
    synchronized void onSystemReady() {
        this.mScoConnectionState = -1;
        resetBluetoothSco();
        getBluetoothHeadset();
        Intent newIntent = new Intent("android.media.SCO_AUDIO_STATE_CHANGED");
        newIntent.putExtra("android.media.extra.SCO_AUDIO_STATE", 0);
        sendStickyBroadcastToAll(newIntent);
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter != null) {
            adapter.getProfileProxy(this.mDeviceBroker.getContext(), this.mBluetoothProfileServiceListener, 2);
            adapter.getProfileProxy(this.mDeviceBroker.getContext(), this.mBluetoothProfileServiceListener, 21);
        }
    }

    synchronized void onAudioServerDiedRestoreA2dp() {
        int forMed = this.mDeviceBroker.getBluetoothA2dpEnabled() ? 0 : 10;
        this.mDeviceBroker.setForceUse_Async(1, forMed, "onAudioServerDied()");
    }

    synchronized boolean isAvrcpAbsoluteVolumeSupported() {
        return this.mA2dp != null && this.mAvrcpAbsVolSupported;
    }

    synchronized void setAvrcpAbsoluteVolumeSupported(boolean supported) {
        this.mAvrcpAbsVolSupported = supported;
        Log.i(TAG, "setAvrcpAbsoluteVolumeSupported supported=" + supported);
    }

    synchronized void setAvrcpAbsoluteVolumeIndex(int index) {
        if (this.mA2dp == null) {
            AudioService.sVolumeLogger.log(new AudioEventLogger.StringEvent("setAvrcpAbsoluteVolumeIndex: bailing due to null mA2dp").printLog(TAG));
            return;
        }
        if (!this.mAvrcpAbsVolSupported) {
            AudioService.sVolumeLogger.log(new AudioEventLogger.StringEvent("setAvrcpAbsoluteVolumeIndex: abs vol not supported ").printLog(TAG));
            return;
        }
        Log.i(TAG, "setAvrcpAbsoluteVolumeIndex index=" + index);
        AudioService.sVolumeLogger.log(new AudioServiceEvents.VolumeEvent(4, index));
        this.mA2dp.setAvrcpAbsoluteVolume(index);
    }

    synchronized int getA2dpCodec(BluetoothDevice device) {
        if (this.mA2dp == null) {
            return 0;
        }
        BluetoothCodecStatus btCodecStatus = this.mA2dp.getCodecStatus(device);
        if (btCodecStatus == null) {
            return 0;
        }
        BluetoothCodecConfig btCodecConfig = btCodecStatus.getCodecConfig();
        if (btCodecConfig == null) {
            return 0;
        }
        return mapBluetoothCodecToAudioFormat(btCodecConfig.getCodecType());
    }

    @GuardedBy({"AudioDeviceBroker.mDeviceStateLock"})
    synchronized void receiveBtEvent(Intent intent) {
        String action = intent.getAction();
        if (action.equals("android.bluetooth.headset.profile.action.ACTIVE_DEVICE_CHANGED")) {
            BluetoothDevice btDevice = (BluetoothDevice) intent.getParcelableExtra("android.bluetooth.device.extra.DEVICE");
            setBtScoActiveDevice(btDevice);
        } else if (action.equals("android.bluetooth.headset.profile.action.AUDIO_STATE_CHANGED")) {
            boolean broadcast = false;
            int scoAudioState = -1;
            int btState = intent.getIntExtra("android.bluetooth.profile.extra.STATE", -1);
            Log.d(TAG, "receiveBtEvent() btState: " + btState + ", mScoAudioState: " + this.mScoAudioState + ", mBluetoothHeadsetDevice: " + this.mBluetoothHeadsetDevice + ", mBluetoothHeadset: " + this.mBluetoothHeadset);
            boolean z = true;
            if (!this.mScoClients.isEmpty() && (this.mScoAudioState == 3 || this.mScoAudioState == 1 || this.mScoAudioState == 4 || this.mScoAudioState == 5)) {
                broadcast = true;
            }
            switch (btState) {
                case 10:
                    this.mDeviceBroker.setBluetoothScoOn(false, "BtHelper.receiveBtEvent");
                    scoAudioState = 0;
                    if (this.mScoAudioState == 1 && this.mBluetoothHeadset != null && this.mBluetoothHeadsetDevice != null && connectBluetoothScoAudioHelper(this.mBluetoothHeadset, this.mBluetoothHeadsetDevice, this.mScoAudioMode)) {
                        this.mScoAudioState = 3;
                        broadcast = false;
                    } else {
                        if (this.mScoAudioState != 3) {
                            z = false;
                        }
                        clearAllScoClients(0, z);
                        this.mScoAudioState = 0;
                    }
                    break;
                case 11:
                    if (this.mScoAudioState != 3 && this.mScoAudioState != 4) {
                        this.mScoAudioState = 2;
                    }
                    break;
                case 12:
                    scoAudioState = 1;
                    if (this.mScoAudioState != 3 && this.mScoAudioState != 4) {
                        this.mScoAudioState = 2;
                    }
                    this.mDeviceBroker.setBluetoothScoOn(true, "BtHelper.receiveBtEvent");
                    break;
                default:
                    broadcast = false;
                    break;
            }
            if (broadcast) {
                broadcastScoConnectionState(scoAudioState);
                Intent newIntent = new Intent("android.media.SCO_AUDIO_STATE_CHANGED");
                newIntent.putExtra("android.media.extra.SCO_AUDIO_STATE", scoAudioState);
                sendStickyBroadcastToAll(newIntent);
            }
        }
    }

    synchronized boolean isBluetoothScoOn() {
        if (this.mBluetoothHeadset != null && this.mBluetoothHeadset.getAudioState(this.mBluetoothHeadsetDevice) != 12) {
            Log.w(TAG, "isBluetoothScoOn(true) returning false because " + this.mBluetoothHeadsetDevice + " is not in audio connected mode");
            return false;
        }
        return true;
    }

    @GuardedBy({"AudioDeviceBroker.mDeviceStateLock"})
    synchronized void disconnectBluetoothSco(int exceptPid) {
        Log.d(TAG, "disconnectBluetoothSco() exceptPid: " + exceptPid);
        checkScoAudioState();
        if (this.mScoAudioState == 2) {
            return;
        }
        clearAllScoClients(exceptPid, true);
    }

    @GuardedBy({"AudioDeviceBroker.mDeviceStateLock"})
    synchronized void startBluetoothScoForClient(IBinder cb, int scoAudioMode, String eventSource) {
        ScoClient client = getScoClient(cb, true);
        long ident = Binder.clearCallingIdentity();
        try {
            AudioService.sDeviceLogger.log(new AudioEventLogger.StringEvent(eventSource + " client count before=" + client.getCount()));
            client.incCount(scoAudioMode);
        } catch (NullPointerException e) {
            Log.e(TAG, "Null ScoClient", e);
        }
        Binder.restoreCallingIdentity(ident);
    }

    @GuardedBy({"AudioDeviceBroker.mDeviceStateLock"})
    synchronized void stopBluetoothScoForClient(IBinder cb, String eventSource) {
        ScoClient client = getScoClient(cb, false);
        long ident = Binder.clearCallingIdentity();
        if (client != null) {
            AudioService.sDeviceLogger.log(new AudioEventLogger.StringEvent(eventSource + " client count before=" + client.getCount()));
            client.decCount();
        }
        Binder.restoreCallingIdentity(ident);
    }

    synchronized void setHearingAidVolume(int index, int streamType) {
        if (this.mHearingAid == null) {
            Log.i(TAG, "setHearingAidVolume: null mHearingAid");
            return;
        }
        int gainDB = (int) AudioSystem.getStreamVolumeDB(streamType, index / 10, 134217728);
        if (gainDB < -128) {
            gainDB = -128;
        }
        Log.i(TAG, "setHearingAidVolume: calling mHearingAid.setVolume idx=" + index + " gain=" + gainDB);
        AudioService.sVolumeLogger.log(new AudioServiceEvents.VolumeEvent(3, index, gainDB));
        this.mHearingAid.setVolume(gainDB);
    }

    synchronized void onBroadcastScoConnectionState(int state) {
        if (state == this.mScoConnectionState) {
            return;
        }
        Intent newIntent = new Intent("android.media.ACTION_SCO_AUDIO_STATE_UPDATED");
        newIntent.putExtra("android.media.extra.SCO_AUDIO_STATE", state);
        newIntent.putExtra("android.media.extra.SCO_AUDIO_PREVIOUS_STATE", this.mScoConnectionState);
        sendStickyBroadcastToAll(newIntent);
        this.mScoConnectionState = state;
    }

    synchronized void disconnectAllBluetoothProfiles() {
        this.mDeviceBroker.postDisconnectA2dp();
        this.mDeviceBroker.postDisconnectA2dpSink();
        this.mDeviceBroker.postDisconnectHeadset();
        this.mDeviceBroker.postDisconnectHearingAid();
    }

    @GuardedBy({"AudioDeviceBroker.mDeviceStateLock"})
    synchronized void resetBluetoothSco() {
        clearAllScoClients(0, false);
        this.mScoAudioState = 0;
        broadcastScoConnectionState(0);
        AudioSystem.setParameters("A2dpSuspended=false");
        this.mDeviceBroker.setBluetoothScoOn(false, "resetBluetoothSco");
    }

    @GuardedBy({"AudioDeviceBroker.mDeviceStateLock"})
    synchronized void disconnectHeadset() {
        setBtScoActiveDevice(null);
        this.mBluetoothHeadset = null;
    }

    synchronized void onA2dpProfileConnected(BluetoothA2dp a2dp) {
        this.mA2dp = a2dp;
        List<BluetoothDevice> deviceList = this.mA2dp.getConnectedDevices();
        if (deviceList.isEmpty()) {
            return;
        }
        BluetoothDevice btDevice = deviceList.get(0);
        int state = this.mA2dp.getConnectionState(btDevice);
        this.mDeviceBroker.handleSetA2dpSinkConnectionState(state, new BluetoothA2dpDeviceInfo(btDevice));
    }

    synchronized void onA2dpSinkProfileConnected(BluetoothProfile profile) {
        List<BluetoothDevice> deviceList = profile.getConnectedDevices();
        if (deviceList.isEmpty()) {
            return;
        }
        BluetoothDevice btDevice = deviceList.get(0);
        int state = profile.getConnectionState(btDevice);
        this.mDeviceBroker.postSetA2dpSourceConnectionState(state, new BluetoothA2dpDeviceInfo(btDevice));
    }

    synchronized void onHearingAidProfileConnected(BluetoothHearingAid hearingAid) {
        this.mHearingAid = hearingAid;
        List<BluetoothDevice> deviceList = this.mHearingAid.getConnectedDevices();
        if (deviceList.isEmpty()) {
            return;
        }
        BluetoothDevice btDevice = deviceList.get(0);
        int state = this.mHearingAid.getConnectionState(btDevice);
        this.mDeviceBroker.postBluetoothHearingAidDeviceConnectionState(btDevice, state, false, 0, "mBluetoothProfileServiceListener");
    }

    @GuardedBy({"AudioDeviceBroker.mDeviceStateLock"})
    synchronized void onHeadsetProfileConnected(BluetoothHeadset headset) {
        this.mDeviceBroker.handleCancelFailureToConnectToBtHeadsetService();
        this.mBluetoothHeadset = headset;
        setBtScoActiveDevice(this.mBluetoothHeadset.getActiveDevice());
        checkScoAudioState();
        if (this.mScoAudioState == 1 || this.mScoAudioState == 4) {
            boolean status = false;
            if (this.mBluetoothHeadsetDevice != null) {
                int i = this.mScoAudioState;
                if (i == 1) {
                    status = connectBluetoothScoAudioHelper(this.mBluetoothHeadset, this.mBluetoothHeadsetDevice, this.mScoAudioMode);
                    if (status) {
                        this.mScoAudioState = 3;
                    }
                } else if (i == 4 && (status = disconnectBluetoothScoAudioHelper(this.mBluetoothHeadset, this.mBluetoothHeadsetDevice, this.mScoAudioMode))) {
                    this.mScoAudioState = 5;
                }
            }
            if (!status) {
                this.mScoAudioState = 0;
                broadcastScoConnectionState(0);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void broadcastScoConnectionState(int state) {
        this.mDeviceBroker.postBroadcastScoConnectionState(state);
    }

    private boolean handleBtScoActiveDeviceChange(BluetoothDevice btDevice, boolean isActive) {
        boolean result;
        if (btDevice == null) {
            return true;
        }
        String address = btDevice.getAddress();
        BluetoothClass btClass = btDevice.getBluetoothClass();
        int[] outDeviceTypes = {16, 32, 64};
        if (btClass != null) {
            int deviceClass = btClass.getDeviceClass();
            if (deviceClass == 1028 || deviceClass == 1032) {
                outDeviceTypes = new int[]{32};
            } else if (deviceClass == 1056) {
                outDeviceTypes = new int[]{64};
            }
        }
        if (!BluetoothAdapter.checkBluetoothAddress(address)) {
            address = "";
        }
        String btDeviceName = getName(btDevice);
        if (isActive) {
            result = false | this.mDeviceBroker.handleDeviceConnection(isActive, outDeviceTypes[0], address, btDeviceName);
        } else {
            boolean result2 = false;
            for (int outDeviceType : outDeviceTypes) {
                result2 |= this.mDeviceBroker.handleDeviceConnection(isActive, outDeviceType, address, btDeviceName);
            }
            result = result2;
        }
        if (this.mDeviceBroker.handleDeviceConnection(isActive, -2147483640, address, btDeviceName) && result) {
            return true;
        }
        return false;
    }

    @GuardedBy({"BtHelper.this"})
    private void setBtScoActiveDevice(BluetoothDevice btDevice) {
        Log.i(TAG, "setBtScoActiveDevice: " + this.mBluetoothHeadsetDevice + " -> " + btDevice);
        BluetoothDevice previousActiveDevice = this.mBluetoothHeadsetDevice;
        if (Objects.equals(btDevice, previousActiveDevice)) {
            return;
        }
        if (!handleBtScoActiveDeviceChange(previousActiveDevice, false)) {
            Log.w(TAG, "setBtScoActiveDevice() failed to remove previous device " + previousActiveDevice);
        }
        if (!handleBtScoActiveDeviceChange(btDevice, true)) {
            Log.e(TAG, "setBtScoActiveDevice() failed to add new device " + btDevice);
            btDevice = null;
        }
        this.mBluetoothHeadsetDevice = btDevice;
        if (this.mBluetoothHeadsetDevice == null) {
            resetBluetoothSco();
        }
    }

    @GuardedBy({"AudioDeviceBroker.mDeviceStateLock"})
    synchronized void scoClientDied(Object obj) {
        ScoClient client = (ScoClient) obj;
        Log.w(TAG, "SCO client died");
        int index = this.mScoClients.indexOf(client);
        if (index < 0) {
            Log.w(TAG, "unregistered SCO client died");
        } else {
            client.clearCount(true);
            this.mScoClients.remove(client);
        }
    }

    private class ScoClient implements IBinder.DeathRecipient {
        private IBinder mCb;
        private int mCreatorPid = Binder.getCallingPid();
        private int mStartcount = 0;

        ScoClient(IBinder cb) {
            this.mCb = cb;
            Log.d(BtHelper.TAG, "ScoClient()  mCreatorPid= " + this.mCreatorPid);
        }

        @Override // android.os.IBinder.DeathRecipient
        public void binderDied() {
            BtHelper.this.mDeviceBroker.postScoClientDied(this);
        }

        @GuardedBy({"BtHelper.this"})
        void incCount(int scoAudioMode) {
            if (!requestScoState(12, scoAudioMode)) {
                Log.e(BtHelper.TAG, "Request sco connected with scoAudioMode(" + scoAudioMode + ") failed");
                return;
            }
            if (this.mStartcount == 0) {
                try {
                    this.mCb.linkToDeath(this, 0);
                } catch (RemoteException e) {
                    Log.w(BtHelper.TAG, "ScoClient  incCount() could not link to " + this.mCb + " binder death");
                }
            }
            this.mStartcount++;
            Log.d(BtHelper.TAG, "incCount()  mStartcount= " + this.mStartcount);
        }

        @GuardedBy({"BtHelper.this"})
        void decCount() {
            int i = this.mStartcount;
            if (i == 0) {
                Log.w(BtHelper.TAG, "ScoClient.decCount() already 0");
                return;
            }
            this.mStartcount = i - 1;
            if (this.mStartcount == 0) {
                try {
                    this.mCb.unlinkToDeath(this, 0);
                } catch (NoSuchElementException e) {
                    Log.w(BtHelper.TAG, "decCount() going to 0 but not registered to binder");
                }
            }
            Log.d(BtHelper.TAG, "decCount()  mStartcount= " + this.mStartcount);
            if (!requestScoState(10, 0)) {
                Log.w(BtHelper.TAG, "Request sco disconnected with scoAudioMode(0) failed");
            }
        }

        @GuardedBy({"BtHelper.this"})
        void clearCount(boolean stopSco) {
            if (this.mStartcount != 0) {
                try {
                    this.mCb.unlinkToDeath(this, 0);
                } catch (NoSuchElementException e) {
                    Log.w(BtHelper.TAG, "clearCount() mStartcount: " + this.mStartcount + " != 0 but not registered to binder");
                }
            }
            this.mStartcount = 0;
            Log.d(BtHelper.TAG, "clearCount()  stopSco= " + stopSco);
            if (stopSco) {
                requestScoState(10, 0);
            }
        }

        int getCount() {
            Log.d(BtHelper.TAG, "getCount()  mStartcount= " + this.mStartcount);
            return this.mStartcount;
        }

        IBinder getBinder() {
            return this.mCb;
        }

        int getPid() {
            Log.d(BtHelper.TAG, "getPid()  mCreatorPid= " + this.mCreatorPid);
            return this.mCreatorPid;
        }

        private int totalCount() {
            int count = 0;
            for (ScoClient mScoClient : BtHelper.this.mScoClients) {
                count += mScoClient.getCount();
            }
            return count;
        }

        @GuardedBy({"BtHelper.this"})
        private boolean requestScoState(int state, int scoAudioMode) {
            BtHelper.this.checkScoAudioState();
            int clientCount = totalCount();
            if (clientCount != 0) {
                Log.i(BtHelper.TAG, "requestScoState: state=" + state + ", scoAudioMode=" + scoAudioMode + ", clientCount=" + clientCount);
                return true;
            }
            if (state == 12) {
                BtHelper.this.broadcastScoConnectionState(2);
                int modeOwnerPid = BtHelper.this.mDeviceBroker.getModeOwnerPid();
                if (modeOwnerPid == 0 || modeOwnerPid == this.mCreatorPid) {
                    int i = BtHelper.this.mScoAudioState;
                    if (i == 0) {
                        BtHelper.this.mScoAudioMode = scoAudioMode;
                        if (scoAudioMode == -1) {
                            BtHelper.this.mScoAudioMode = 0;
                            if (BtHelper.this.mBluetoothHeadsetDevice != null) {
                                BtHelper btHelper = BtHelper.this;
                                btHelper.mScoAudioMode = Settings.Global.getInt(btHelper.mDeviceBroker.getContentResolver(), "bluetooth_sco_channel_" + BtHelper.this.mBluetoothHeadsetDevice.getAddress(), 0);
                                if (BtHelper.this.mScoAudioMode > 2 || BtHelper.this.mScoAudioMode < 0) {
                                    BtHelper.this.mScoAudioMode = 0;
                                }
                            }
                        }
                        if (BtHelper.this.mBluetoothHeadset == null) {
                            if (BtHelper.this.getBluetoothHeadset()) {
                                BtHelper.this.mScoAudioState = 1;
                            } else {
                                Log.w(BtHelper.TAG, "requestScoState: getBluetoothHeadset failed during connection, mScoAudioMode=" + BtHelper.this.mScoAudioMode);
                                BtHelper.this.broadcastScoConnectionState(0);
                                return false;
                            }
                        } else if (BtHelper.this.mBluetoothHeadsetDevice != null) {
                            if (BtHelper.connectBluetoothScoAudioHelper(BtHelper.this.mBluetoothHeadset, BtHelper.this.mBluetoothHeadsetDevice, BtHelper.this.mScoAudioMode)) {
                                BtHelper.this.mScoAudioState = 3;
                            } else {
                                Log.w(BtHelper.TAG, "requestScoState: connect to " + BtHelper.this.mBluetoothHeadsetDevice + " failed, mScoAudioMode=" + BtHelper.this.mScoAudioMode);
                                BtHelper.this.broadcastScoConnectionState(0);
                                return false;
                            }
                        } else {
                            Log.w(BtHelper.TAG, "requestScoState: no active device while connecting, mScoAudioMode=" + BtHelper.this.mScoAudioMode);
                            BtHelper.this.broadcastScoConnectionState(0);
                            return false;
                        }
                    } else if (i == 4) {
                        BtHelper.this.mScoAudioState = 3;
                        BtHelper.this.broadcastScoConnectionState(1);
                    } else if (i == 5) {
                        BtHelper.this.mScoAudioState = 1;
                    } else {
                        Log.w(BtHelper.TAG, "requestScoState: failed to connect in state " + BtHelper.this.mScoAudioState + ", scoAudioMode=" + scoAudioMode);
                        BtHelper.this.broadcastScoConnectionState(0);
                        return false;
                    }
                } else {
                    Log.w(BtHelper.TAG, "requestScoState: audio mode is not NORMAL and modeOwnerPid " + modeOwnerPid + " != creatorPid " + this.mCreatorPid);
                    BtHelper.this.broadcastScoConnectionState(0);
                    return false;
                }
            } else if (state == 10) {
                int i2 = BtHelper.this.mScoAudioState;
                if (i2 == 1) {
                    BtHelper.this.mScoAudioState = 0;
                    BtHelper.this.broadcastScoConnectionState(0);
                } else if (i2 == 3) {
                    if (BtHelper.this.mBluetoothHeadset == null) {
                        if (BtHelper.this.getBluetoothHeadset()) {
                            BtHelper.this.mScoAudioState = 4;
                        } else {
                            Log.w(BtHelper.TAG, "requestScoState: getBluetoothHeadset failed during disconnection, mScoAudioMode=" + BtHelper.this.mScoAudioMode);
                            BtHelper.this.mScoAudioState = 0;
                            BtHelper.this.broadcastScoConnectionState(0);
                            return false;
                        }
                    } else if (BtHelper.this.mBluetoothHeadsetDevice != null && BtHelper.disconnectBluetoothScoAudioHelper(BtHelper.this.mBluetoothHeadset, BtHelper.this.mBluetoothHeadsetDevice, BtHelper.this.mScoAudioMode)) {
                        BtHelper.this.mScoAudioState = 5;
                    } else {
                        BtHelper.this.mScoAudioState = 0;
                        BtHelper.this.broadcastScoConnectionState(0);
                    }
                } else {
                    Log.w(BtHelper.TAG, "requestScoState: failed to disconnect in state " + BtHelper.this.mScoAudioState + ", scoAudioMode=" + scoAudioMode);
                    BtHelper.this.broadcastScoConnectionState(0);
                    return false;
                }
            }
            return true;
        }
    }

    private void sendStickyBroadcastToAll(Intent intent) {
        intent.addFlags(268435456);
        long ident = Binder.clearCallingIdentity();
        try {
            this.mDeviceBroker.getContext().sendStickyBroadcastAsUser(intent, UserHandle.ALL);
        } finally {
            Binder.restoreCallingIdentity(ident);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean disconnectBluetoothScoAudioHelper(BluetoothHeadset bluetoothHeadset, BluetoothDevice device, int scoAudioMode) {
        if (scoAudioMode == 0) {
            return bluetoothHeadset.stopScoUsingVirtualVoiceCall();
        }
        if (scoAudioMode == 1) {
            return bluetoothHeadset.disconnectAudio();
        }
        if (scoAudioMode == 2) {
            return bluetoothHeadset.stopVoiceRecognition(device);
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean connectBluetoothScoAudioHelper(BluetoothHeadset bluetoothHeadset, BluetoothDevice device, int scoAudioMode) {
        if (scoAudioMode == 0) {
            return bluetoothHeadset.startScoUsingVirtualVoiceCall();
        }
        if (scoAudioMode == 1) {
            return bluetoothHeadset.connectAudio();
        }
        if (scoAudioMode == 2) {
            return bluetoothHeadset.startVoiceRecognition(device);
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void checkScoAudioState() {
        BluetoothDevice bluetoothDevice;
        BluetoothHeadset bluetoothHeadset = this.mBluetoothHeadset;
        if (bluetoothHeadset != null && (bluetoothDevice = this.mBluetoothHeadsetDevice) != null && this.mScoAudioState == 0 && bluetoothHeadset.getAudioState(bluetoothDevice) != 10) {
            this.mScoAudioState = 2;
        }
    }

    private ScoClient getScoClient(IBinder cb, boolean create) {
        for (ScoClient existingClient : this.mScoClients) {
            if (existingClient.getBinder() == cb) {
                return existingClient;
            }
        }
        if (create) {
            ScoClient newClient = new ScoClient(cb);
            this.mScoClients.add(newClient);
            return newClient;
        }
        return null;
    }

    @GuardedBy({"BtHelper.this"})
    private void clearAllScoClients(int exceptPid, boolean stopSco) {
        Log.d(TAG, "clearAllScoClients() exceptPid: " + exceptPid + "  stopSco= " + stopSco);
        ScoClient savedClient = null;
        for (ScoClient cl : this.mScoClients) {
            if (cl.getPid() != exceptPid) {
                cl.clearCount(stopSco);
            } else {
                savedClient = cl;
            }
        }
        this.mScoClients.clear();
        if (savedClient != null) {
            this.mScoClients.add(savedClient);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean getBluetoothHeadset() {
        boolean result = false;
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter != null) {
            result = adapter.getProfileProxy(this.mDeviceBroker.getContext(), this.mBluetoothProfileServiceListener, 1);
        }
        this.mDeviceBroker.handleFailureToConnectToBtHeadsetService(result ? 3000 : 0);
        return result;
    }

    private int mapBluetoothCodecToAudioFormat(int btCodecType) {
        if (btCodecType == 0) {
            return 520093696;
        }
        if (btCodecType == 1) {
            return 67108864;
        }
        if (btCodecType == 2) {
            return 536870912;
        }
        if (btCodecType == 3) {
            return 553648128;
        }
        if (btCodecType == 4) {
            return 587202560;
        }
        return 0;
    }
}
