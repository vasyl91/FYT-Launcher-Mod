package com.android.server.backup.keyvalue;

import android.util.AndroidException;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
class BackupException extends AndroidException {
    BackupException() {
    }

    BackupException(Exception cause) {
        super(cause);
    }
}
