package com.android.server.autofill.ui;

import android.app.AppOpsManager;
import android.content.Context;
import android.os.Binder;
import android.os.IBinder;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
class OverlayControl {
    private final AppOpsManager mAppOpsManager;
    private final IBinder mToken = new Binder();

    OverlayControl(Context context) {
        this.mAppOpsManager = (AppOpsManager) context.getSystemService(AppOpsManager.class);
    }

    void hideOverlays() {
        setOverlayAllowed(false);
    }

    void showOverlays() {
        setOverlayAllowed(true);
    }

    private void setOverlayAllowed(boolean allowed) {
        AppOpsManager appOpsManager = this.mAppOpsManager;
        if (appOpsManager != null) {
            appOpsManager.setUserRestrictionForUser(24, !allowed, this.mToken, null, -1);
            this.mAppOpsManager.setUserRestrictionForUser(45, !allowed, this.mToken, null, -1);
        }
    }
}
