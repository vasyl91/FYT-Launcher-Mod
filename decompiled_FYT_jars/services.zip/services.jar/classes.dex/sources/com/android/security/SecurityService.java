package com.android.security;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Binder;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.ISecurityService;
import android.os.Message;
import android.os.SystemProperties;
import android.telecom.TelecomManager;
import android.util.Log;
import android.widget.Button;
import com.android.server.display.color.DisplayTransformManager;
import com.android.server.hdmi.HdmiCecKeycode;
import com.android.server.input.InputManagerService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public class SecurityService extends ISecurityService.Stub {
    private static final String ASSIST = "assist";
    private static final String AUTHORITY = "com.unisoc.ccsa.permission.provider";
    private static final String COUNT = "count(*) count ";
    private static final long CTA_DIALOG_TIMEOUT_MS = 15000;
    private static final int DATA_POLICY_ID = 105;
    private static final String ID = "_id";
    private static final int JDG_POLICY_ALLOW = 1;
    private static final int JDG_POLICY_REFUSE = -10;
    private static final int JDG_TIME_ALLOW = 3;
    private static final int JDG_UNKNOWN = 0;
    private static final int JDG_USER_ALLOW = 2;
    private static final int JDG_USER_REFUSE = -9;
    private static final String KEYWORDS = "keywords";
    private static final String KEYWORDS_TABLE = "opr2keywords";
    private static final String LOG_ID = "_id";
    private static final String LOG_PERMID = "permName";
    private static final String LOG_PKGNAME = "pkgName";
    private static final String LOG_STRATEGY = "permStrategy";
    private static final String LOG_TIME = "time";
    private static final int MEDIA_RECORDER_OPERATION_ID = 9;
    private static final String OPR_ID = "operation_id";
    private static final int OPR_NORMAL = 0;
    private static final int OPR_PROVIDER = 1;
    private static final int OPR_STARTACTIVITY = 2;
    private static final String OPR_TYPE = "operation_type";
    private static final String PACKAGENAME = "package_name";
    private static final String PERMISSION = "permission";
    private static final String PERMISSIONID = "permission_id";
    private static final int PERMISSION_ALERT = 2;
    private static final int PERMISSION_ALLOW = 0;
    private static final int PERMISSION_REFUSE = 1;
    private static final String POLICYID_TABLE = "opr2policy";
    private static final String POLICY_ID = "policy_id";
    private static final String SECURE_DEBUG_LOG = "persist.sys.secure.debuglog";
    private static final String SECURE_DEBUG_OPEN = "!@#$%^&*";
    private static final String SECURE_SELECTED = "service.project.sec";
    private static final String SECURITY_DB = "/system/etc/telephonesec.db";
    private static final String SERVICENAME = "service_name";
    private static final String SERVICE_NAME = "service_name";
    private static final String SIGN = "sign";
    private static final String TAG = "SecurityService";
    private static final String UID = "uid";
    private static final int WIFI_POLICY_ID = 106;
    private Context mContext;
    private Handler mHandler;
    private PackageManager mPackageManager;
    private Context resourceContext;
    private static final Object permissionlock = new Object();
    private static final Object seqlock = new Object();
    private static final Object sysUidlock = new Object();
    private static final int MEDIA_RECORDER_POLICY_ID = 202;
    private static final int[] CacheOPrID = {MEDIA_RECORDER_POLICY_ID, 203};
    private static final Uri CONTENT_URI = Uri.parse("content://com.unisoc.ccsa.permission.provider/permission");
    private static final Uri CONTENT_URI_UID = Uri.parse("content://com.unisoc.ccsa.permission.provider/permissionUID");
    private static final Uri CONTENT_URI_PERMISSIONID = Uri.parse("content://com.unisoc.ccsa.permission.provider/permissionID");
    private static final Uri CONTENT_URI_PERMISSIONCOUNT = Uri.parse("content://com.unisoc.ccsa.permission.provider/permissionCount");
    private static final Uri CONTENT_URI_APPCOUNT = Uri.parse("content://com.unisoc.ccsa.permission.provider/appCount");
    private static final Uri CONTENT_URI_SELFSTART = Uri.parse("content://com.unisoc.ccsa.permission.provider/self_start");
    private static final Uri CONTENT_URI_SELFSTART_UID = Uri.parse("content://com.unisoc.ccsa.permission.provider/self_startUID");
    private static final Uri CONTENT_URI_CONTROL = Uri.parse("content://com.unisoc.ccsa.permission.provider/control");
    private static final Uri CONTENT_URI_LOG = Uri.parse("content://com.unisoc.ccsa.permission.provider/log");
    private boolean vdebug = false;
    private int[] sysuid = null;
    private int[][] mPolicy2ResID = null;
    private Map<String, List<Opr2Policy>> gPolicyIDCache = new HashMap();
    private Map<PermissionKey, Integer> gPermissionCache = new HashMap();
    private Map<KeywordsKey, Integer> gKeywordsCache = new HashMap();
    private Map<uidKey, String> gApplicationCache = new HashMap();
    private Map<PermissionKey, Integer> gOPrID2ResIDCache = new HashMap();
    private Object mAlertLock = new Object();
    private volatile boolean mAlertRet = false;
    private String mAlertMsg = null;
    private volatile int controlflag = 1;

    private static class Opr2Policy {
        int mOprID;
        int mOprType;
        int mPolicyID;

        public Opr2Policy(int oprID, int oprType, int policyID) {
            this.mOprID = oprID;
            this.mOprType = oprType;
            this.mPolicyID = policyID;
        }
    }

    private static class PermissionKey {
        int mPolicyID;
        int mUid;

        public PermissionKey(int uid, int policyID) {
            this.mUid = uid;
            this.mPolicyID = policyID;
        }

        public int hashCode() {
            int ret = new Integer(this.mUid).hashCode() ^ new Integer(this.mPolicyID).hashCode();
            return ret;
        }

        public boolean equals(Object obj) {
            if (obj == null || !(obj instanceof PermissionKey)) {
                return false;
            }
            PermissionKey tmpObj = (PermissionKey) obj;
            return tmpObj.mUid == this.mUid && tmpObj.mPolicyID == this.mPolicyID;
        }
    }

    private static class uidKey {
        int mUid;

        public uidKey(int uid) {
            this.mUid = uid;
        }

        public int hashCode() {
            int ret = new Integer(this.mUid).hashCode();
            return ret;
        }

        public boolean equals(Object obj) {
            if (obj == null || !(obj instanceof uidKey)) {
                return false;
            }
            uidKey tmpObj = (uidKey) obj;
            return tmpObj.mUid == this.mUid;
        }
    }

    private static class KeywordsKey {
        String mKeywords;
        int mOprType;

        public KeywordsKey(int oprType, String keywords) {
            this.mOprType = oprType;
            this.mKeywords = keywords;
        }

        public int hashCode() {
            int ret = new Integer(this.mOprType).hashCode() ^ this.mKeywords.hashCode();
            return ret;
        }

        public boolean equals(Object obj) {
            if (obj == null || !(obj instanceof KeywordsKey)) {
                return false;
            }
            KeywordsKey tmpObj = (KeywordsKey) obj;
            return tmpObj.mOprType == this.mOprType && tmpObj.mKeywords.equals(this.mKeywords);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initResIDCache() {
        this.gOPrID2ResIDCache.put(new PermissionKey(203, 9), Integer.valueOf(getStringId(this.resourceContext, "security_alert_recordcall")));
        this.gOPrID2ResIDCache.put(new PermissionKey(203, 10), Integer.valueOf(getStringId(this.resourceContext, "security_alert_record")));
        this.gOPrID2ResIDCache.put(new PermissionKey(MEDIA_RECORDER_POLICY_ID, 9), Integer.valueOf(getStringId(this.resourceContext, "security_alert_recordcall")));
        this.gOPrID2ResIDCache.put(new PermissionKey(MEDIA_RECORDER_POLICY_ID, 10), Integer.valueOf(getStringId(this.resourceContext, "security_alert_record")));
    }

    public SecurityService() {
        log("Constructor start");
        initKeywordsCache();
        initPolicyIDCache();
        log("Constructor end");
    }

    private class PermissionObserver extends ContentObserver {
        PermissionObserver(Handler handler) {
            super(handler);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange) {
            SecurityService.this.log("PermissionObserver onChange start");
            SecurityService.this.initPermissionCache();
            SecurityService.this.getSysUids();
            SecurityService.this.log("PermissionObserver onChange end");
        }
    }

    private class ControlObserver extends ContentObserver {
        ControlObserver(Handler handler) {
            super(handler);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange) {
            SecurityService.this.log("ControlObserver onChange start initControlFlag");
            SecurityService.this.initControlFlag();
            SecurityService.this.log("ControlObserver onChange end initControlFlag");
        }
    }

    public void systemReady(Context context) {
        this.mContext = context;
        IntentFilter filter = new IntentFilter("android.intent.action.BOOT_COMPLETED");
        this.mContext.registerReceiver(new BroadcastReceiver() { // from class: com.android.security.SecurityService.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context2, Intent intent) {
                if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
                    SecurityService.this.log("systemReady start");
                    SecurityService.this.initPermissionCache();
                    SecurityService.this.initControlFlag();
                    SecurityService.this.mHandler = new Handler();
                    SecurityService securityService = SecurityService.this;
                    securityService.mPackageManager = securityService.mContext.getPackageManager();
                    ContentResolver contentResolver = SecurityService.this.mContext.getContentResolver();
                    Uri uri = SecurityService.CONTENT_URI;
                    SecurityService securityService2 = SecurityService.this;
                    contentResolver.registerContentObserver(uri, false, securityService2.new PermissionObserver(securityService2.mHandler));
                    ContentResolver contentResolver2 = SecurityService.this.mContext.getContentResolver();
                    Uri uri2 = SecurityService.CONTENT_URI_CONTROL;
                    SecurityService securityService3 = SecurityService.this;
                    contentResolver2.registerContentObserver(uri2, false, securityService3.new ControlObserver(securityService3.mHandler));
                    try {
                        SecurityService.this.resourceContext = SecurityService.this.mContext.createPackageContext("com.unisoc.ccsa", 3);
                        SecurityService.this.log("success to get resourceContext");
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                        SecurityService.this.log("fail to get resourceContext");
                    }
                    SecurityService.this.initResIDCache();
                    SecurityService securityService4 = SecurityService.this;
                    securityService4.mPolicy2ResID = securityService4.initPolicy2ResID();
                    SecurityService.this.log("systemReady end");
                }
            }
        }, filter);
    }

    public boolean isSystemUId(int uid) {
        synchronized (sysUidlock) {
            for (int i = 0; i < this.sysuid.length; i++) {
                if (uid == this.sysuid[i]) {
                    log("isSystemUId true");
                    return true;
                }
            }
            log("isSystemUId false");
            return false;
        }
    }

    /* JADX WARN: Code duplicated, block: B:44:0x0129 A[PHI: r0
  0x0129: PHI (r0v3 'cr' android.database.Cursor) = (r0v2 'cr' android.database.Cursor), (r0v4 'cr' android.database.Cursor) binds: [B:43:0x0127, B:37:0x011e] A[DONT_GENERATE, DONT_INLINE]] */
    private void initPolicyIDCache() {
        Cursor cr = null;
        SQLiteDatabase db = SQLiteDatabase.openDatabase(SECURITY_DB, null, 1);
        try {
            if (db == null) {
                log("initPolicyIDCache(), open db fail");
                return;
            }
            try {
                cr = db.query(POLICYID_TABLE, new String[]{"service_name"}, null, null, null, null, null);
                if (cr != null && cr.moveToFirst()) {
                    log("initPolicyIDCache(), name count: " + cr.getCount());
                    this.gPolicyIDCache.clear();
                    Cursor cur = null;
                    do {
                        try {
                            try {
                                String name = cr.getString(0);
                                log("initPolicyIDCache(), name: " + name);
                                List<Opr2Policy> list = new ArrayList<>();
                                cur = db.query(POLICYID_TABLE, new String[]{OPR_ID, OPR_TYPE, POLICY_ID}, "service_name=?", new String[]{name}, null, null, null);
                                if (cur != null && cur.moveToFirst()) {
                                    log("initPolicyIDCache(), policy count: " + cur.getCount());
                                    do {
                                        log("initPolicyIDCache(), opr_id: " + cur.getInt(0) + ", opr_type: " + cur.getInt(1) + ", policy_id: " + cur.getInt(2));
                                        list.add(new Opr2Policy(cur.getInt(0), cur.getInt(1), cur.getInt(2)));
                                    } while (cur.moveToNext());
                                    this.gPolicyIDCache.put(name, list);
                                }
                                if (cur != null) {
                                    cur.close();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                if (cur != null) {
                                }
                            }
                        } catch (Throwable th) {
                            if (cur != null) {
                                cur.close();
                            }
                            throw th;
                        }
                    } while (cr.moveToNext());
                }
                if (cr != null) {
                    cr.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                if (cr != null) {
                    cr.close();
                }
            }
            db.close();
        } catch (Throwable th2) {
            if (cr != null) {
                cr.close();
            }
            db.close();
            throw th2;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initControlFlag() {
        Cursor cur = null;
        long identityToken = clearCallingIdentity();
        try {
            try {
                cur = this.mContext.getContentResolver().query(CONTENT_URI_CONTROL, new String[]{"service_name", PERMISSION}, "service_name=? ", new String[]{String.valueOf("security")}, null);
                if (cur != null && cur.moveToFirst()) {
                    this.controlflag = cur.getInt(1);
                    SystemProperties.set(SECURE_SELECTED, String.valueOf(this.controlflag));
                    log("initControlFlag(),controlflag : " + this.controlflag);
                    cur.close();
                    restoreCallingIdentity(identityToken);
                }
                log("initControlFlag(), cur is null");
                if (cur != null) {
                    cur.close();
                }
                restoreCallingIdentity(identityToken);
            } catch (Exception ex) {
                ex.printStackTrace();
                if (0 != 0) {
                }
                restoreCallingIdentity(identityToken);
            }
        } catch (Throwable th) {
            if (0 != 0) {
                cur.close();
            }
            restoreCallingIdentity(identityToken);
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initPermissionCache() {
        Cursor cur = null;
        long identityToken = clearCallingIdentity();
        try {
            try {
                cur = this.mContext.getContentResolver().query(CONTENT_URI, new String[]{"uid", PERMISSIONID, PERMISSION}, null, null, null);
                if (cur != null && cur.moveToFirst()) {
                    log("initPermissionCache(), permission count: " + cur.getCount());
                    synchronized (permissionlock) {
                        this.gPermissionCache.clear();
                        do {
                            log("initPermissionCache(), uid: " + cur.getInt(0) + ", policyID: " + cur.getInt(1) + ", permission: " + cur.getInt(2));
                            PermissionKey key = new PermissionKey(cur.getInt(0), cur.getInt(1));
                            this.gPermissionCache.put(key, new Integer(cur.getInt(2)));
                        } while (cur.moveToNext());
                    }
                    cur.close();
                    restoreCallingIdentity(identityToken);
                }
                log("initPermissionCache(), cur is null");
                if (cur != null) {
                    cur.close();
                }
                restoreCallingIdentity(identityToken);
            } catch (Exception ex) {
                ex.printStackTrace();
                if (0 != 0) {
                }
                restoreCallingIdentity(identityToken);
            }
        } catch (Throwable th) {
            if (0 != 0) {
                cur.close();
            }
            restoreCallingIdentity(identityToken);
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:19:0x008b A[DONT_GENERATE, PHI: r0
  0x008b: PHI (r0v3 'cr' android.database.Cursor) = (r0v2 'cr' android.database.Cursor), (r0v4 'cr' android.database.Cursor) binds: [B:18:0x0089, B:12:0x0080] A[DONT_GENERATE, DONT_INLINE]] */
    private void initKeywordsCache() {
        Cursor cr = null;
        SQLiteDatabase db = SQLiteDatabase.openDatabase(SECURITY_DB, null, 1);
        try {
            if (db == null) {
                log("initKeywordsCache(), open db fail");
                return;
            }
            try {
                cr = db.query(KEYWORDS_TABLE, new String[]{KEYWORDS, POLICY_ID}, "operation_type=?", new String[]{String.valueOf(2)}, null, null, null);
                if (cr != null && cr.moveToFirst()) {
                    do {
                        log("initKeywordsCache(), policyID: " + cr.getInt(1) + ", keywords: " + cr.getString(0));
                        KeywordsKey key = new KeywordsKey(2, cr.getString(0));
                        this.gKeywordsCache.put(key, new Integer(cr.getInt(1)));
                    } while (cr.moveToNext());
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } finally {
            if (cr != null) {
                cr.close();
            }
            db.close();
        }
    }

    /* JADX WARN: Code duplicated, block: B:16:0x007d A[PHI: r0 r1
  0x007d: PHI (r0v3 'pem' int) = (r0v2 'pem' int), (r0v5 'pem' int) binds: [B:15:0x007b, B:9:0x0072] A[DONT_GENERATE, DONT_INLINE]
  0x007d: PHI (r1v3 'cur' android.database.Cursor) = (r1v2 'cur' android.database.Cursor), (r1v4 'cur' android.database.Cursor) binds: [B:15:0x007b, B:9:0x0072] A[DONT_GENERATE, DONT_INLINE]] */
    private int getPermission(int uid, int policyId) {
        log("getPermission uid:" + uid + ", policyId: " + policyId);
        int pem = 1;
        Cursor cur = null;
        long identityToken = clearCallingIdentity();
        try {
            try {
                cur = this.mContext.getContentResolver().query(CONTENT_URI, new String[]{PERMISSION}, "uid=? AND permission_id=?", new String[]{String.valueOf(uid), String.valueOf(policyId)}, null);
                if (cur == null || !cur.moveToFirst()) {
                    log("getPermission cur is null");
                } else {
                    pem = cur.getInt(0);
                    log("getPermission find pem: " + pem);
                }
                if (cur != null) {
                    cur.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                if (0 != 0) {
                    cur.close();
                }
            }
            restoreCallingIdentity(identityToken);
            log("getPermission perm: " + pem);
            return pem;
        } catch (Throwable th) {
            if (0 != 0) {
                cur.close();
            }
            restoreCallingIdentity(identityToken);
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int updatePermission(int uid, int policyId, int perm) {
        log("updatePermission uid:" + uid + ", policyId: " + policyId + ",perm:" + perm);
        int rows = 0;
        long identityToken = clearCallingIdentity();
        try {
            try {
                ContentValues permValue = new ContentValues();
                permValue.put(PERMISSION, Integer.valueOf(perm));
                rows = this.mContext.getContentResolver().update(CONTENT_URI, permValue, "uid=? AND permission_id=?", new String[]{String.valueOf(uid), String.valueOf(policyId)});
                log("updatePermission rows: " + rows);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return rows;
        } finally {
            restoreCallingIdentity(identityToken);
        }
    }

    /* JADX WARN: Bottom block not found for handler: all -> 0x0086 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private int updateOperationLog(java.lang.String r8, int r9, int r10) {
        /*
            r7 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "updateOperationLog:"
            r0.append(r1)
            r0.append(r8)
            java.lang.String r1 = ", policyId: "
            r0.append(r1)
            r0.append(r9)
            java.lang.String r1 = ",perm:"
            r0.append(r1)
            r0.append(r10)
            java.lang.String r0 = r0.toString()
            r7.log(r0)
            r0 = 0
            java.text.SimpleDateFormat r1 = new java.text.SimpleDateFormat
            java.lang.String r2 = "yyyy-MM-dd HH:mm:ss"
            r1.<init>(r2)
            long r2 = clearCallingIdentity()
            android.content.ContentValues r4 = new android.content.ContentValues     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            r4.<init>()     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            r0 = r4
            java.lang.String r4 = "pkgName"
            r0.put(r4, r8)     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            java.lang.String r4 = "permName"
            java.lang.String r5 = java.lang.String.valueOf(r9)     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            r0.put(r4, r5)     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            java.lang.String r4 = "permStrategy"
            java.lang.String r5 = java.lang.String.valueOf(r10)     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            r0.put(r4, r5)     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            java.lang.String r4 = "time"
            java.util.Date r5 = new java.util.Date     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            r5.<init>()     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            java.lang.String r5 = r1.format(r5)     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            r0.put(r4, r5)     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            android.content.Context r4 = r7.mContext     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            android.content.ContentResolver r4 = r4.getContentResolver()     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            android.net.Uri r5 = com.android.security.SecurityService.CONTENT_URI_LOG     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            android.net.Uri r4 = r4.insert(r5, r0)     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            r5.<init>()     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            java.lang.String r6 = "updateOperationLog: "
            r5.append(r6)     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            r5.append(r4)     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            java.lang.String r5 = r5.toString()     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            r7.log(r5)     // Catch: java.lang.Throwable -> L86 java.lang.Exception -> L88
            restoreCallingIdentity(r2)
            goto L90
        L86:
            r4 = move-exception
            goto L92
        L88:
            r4 = move-exception
            r4.printStackTrace()     // Catch: java.lang.Throwable -> L86
            restoreCallingIdentity(r2)
        L90:
            r4 = 0
            return r4
        L92:
            restoreCallingIdentity(r2)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.security.SecurityService.updateOperationLog(java.lang.String, int, int):int");
    }

    private int getPermissionFromCache(int uid, int policyId) {
        log("getPermissionFromCache uid:" + uid + ", policyId: " + policyId);
        synchronized (permissionlock) {
            Integer perm = this.gPermissionCache.get(new PermissionKey(uid, policyId));
            if (perm != null) {
                log("getPermissionFromCache permission:" + perm);
                return perm.intValue();
            }
            log("getPermissionFromCache cann't find permission");
            return 1;
        }
    }

    private int getPolicyIDFromCache(String name, int oprID, int oprType, String keyword) {
        log("getPolicyIDFromCache name:" + name + ", oprID: " + oprID + ", oprType: " + oprType + ", keyword: " + keyword);
        List<Opr2Policy> list = this.gPolicyIDCache.get(name);
        if (list != null && !list.isEmpty()) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                Opr2Policy o2p = list.get(i);
                log("getPolicyIDFromCache(), i: " + i + ", mOprID: " + o2p.mOprID + ", mOprType: " + o2p.mOprType);
                if (o2p.mOprID == oprID) {
                    if (o2p.mOprType == 0 || o2p.mOprType == 1) {
                        log("getPolicyIDFromCache(), find 1, policyID: " + o2p.mPolicyID);
                        return o2p.mPolicyID;
                    }
                    Integer id = this.gKeywordsCache.get(new KeywordsKey(oprType, keyword));
                    if (id != null) {
                        log("getPolicyIDFromCache(), find 2, policyID: " + id);
                        return id.intValue();
                    }
                }
            }
        }
        log("getPolicyIDFromCache(), find nothing");
        return -1;
    }

    private int isInCall(int oprID) {
        TelecomManager telecomManager = (TelecomManager) this.mContext.getSystemService("telecom");
        long ident = Binder.clearCallingIdentity();
        if (telecomManager.isInCall()) {
            oprID = 9;
        }
        Binder.restoreCallingIdentity(ident);
        return oprID;
    }

    private String trimServiceName(String name) {
        char endChar = name.charAt(name.length() - 1);
        if ('0' <= endChar && endChar <= '9') {
            return name.substring(0, name.length() - 1);
        }
        return name;
    }

    public boolean isKeyService(String name) {
        log("isKeyService(), name: " + name);
        List<Opr2Policy> list = this.gPolicyIDCache.get(trimServiceName(name));
        if (list != null && !list.isEmpty()) {
            log("isKeyService(), true");
            return true;
        }
        log("isKeyService(), false");
        return false;
    }

    public boolean getKeyInterfaces(String name, int[] oprID, int[] oprType) {
        log("getKeyInterfaces(), name: " + name);
        List<Opr2Policy> list = this.gPolicyIDCache.get(trimServiceName(name));
        if (list != null && !list.isEmpty() && oprID != null && oprType != null) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                Opr2Policy o2p = list.get(i);
                oprID[i] = o2p.mOprID;
                oprType[i] = o2p.mOprType;
                log("getKeyInterfaces(), i: " + i + ", oprID: " + o2p.mOprID + ", oprType: " + o2p.mOprType + ";name: " + name);
            }
            log("return true keyInterfaces - name =" + name);
            return true;
        }
        log("getKeyInterfaces(), find nothing");
        return false;
    }

    public int[] getSysUids() {
        int[] tmp;
        int uidCounts = 0;
        int[] myCount = new int[DisplayTransformManager.LEVEL_COLOR_MATRIX_INVERT_COLOR];
        this.mPackageManager = this.mContext.getPackageManager();
        if (this.mPackageManager == null) {
            log("getSysUids(), pm is null");
            return null;
        }
        synchronized (sysUidlock) {
            log("add getSysUids sysUidlock");
            List<PackageInfo> packageinfo = this.mPackageManager.getInstalledPackages(0);
            int count = packageinfo.size();
            this.gApplicationCache.clear();
            for (int i = 0; i < count; i++) {
                PackageInfo pinfo = packageinfo.get(i);
                ApplicationInfo appInfo = pinfo.applicationInfo;
                if ((appInfo.flags & 1) > 0) {
                    myCount[uidCounts] = appInfo.uid;
                    uidCounts++;
                    log("getSysUids i=" + i + " uidCount= " + uidCounts + " name=" + pinfo.packageName);
                } else {
                    uidKey uido = new uidKey(appInfo.uid);
                    String name = appInfo.loadLabel(this.mContext.getPackageManager()).toString();
                    log("gApplicationCache.put(), name" + name);
                    this.gApplicationCache.put(uido, name);
                    log("gApplicationCache.put(), uido" + uido);
                }
            }
            log("getSysUids(), count" + uidCounts);
            tmp = new int[uidCounts];
            for (int j = 0; j < uidCounts; j++) {
                tmp[j] = myCount[j];
                log("getSysUids(),  j: " + j + ", uid: " + tmp[j]);
            }
            if (this.sysuid == null) {
                this.sysuid = new int[uidCounts];
                for (int j2 = 0; j2 < uidCounts; j2++) {
                    this.sysuid[j2] = myCount[j2];
                    log("init sysUids(),  j: " + j2 + ", uid: " + tmp[j2]);
                }
            }
        }
        return tmp;
    }

    private int Policy2AlertMsg(int policyID, int oprID) {
        int k = 0;
        while (true) {
            int[] iArr = CacheOPrID;
            if (k < iArr.length) {
                if (policyID != iArr[k]) {
                    k++;
                } else {
                    return this.gOPrID2ResIDCache.get(new PermissionKey(policyID, oprID)).intValue();
                }
            } else {
                int i = 0;
                while (true) {
                    int[][] iArr2 = this.mPolicy2ResID;
                    if (i < iArr2.length) {
                        if (policyID != iArr2[i][0]) {
                            i++;
                        } else {
                            return iArr2[i][1];
                        }
                    } else {
                        return -1;
                    }
                }
            }
        }
    }

    public int judge(int uid, String name, int oprID, int oprType, String param) throws Throwable {
        String msg;
        String msg2;
        int oprID2 = oprID;
        String s = SystemProperties.get(SECURE_DEBUG_LOG);
        this.vdebug = s.equals(SECURE_DEBUG_OPEN);
        log("judge() uid: " + uid + ", name:" + name + ", oprID: " + oprID2 + ", oprType: " + oprType + ", param: " + param);
        int iRet = 1;
        synchronized (seqlock) {
            try {
                try {
                    if (this.controlflag != 0 && !isSystemUId(uid)) {
                        String[] packagename = this.mPackageManager.getPackagesForUid(uid);
                        int policyID = getPolicyIDFromCache(trimServiceName(name), oprID2, oprType, param);
                        if (policyID == MEDIA_RECORDER_POLICY_ID) {
                            oprID2 = isInCall(oprID2);
                        }
                        try {
                            log("judge(), policyID: " + policyID + "; oprID == " + oprID2);
                            if (policyID > 0) {
                                int perm = getPermissionFromCache(uid, policyID);
                                if (perm == 2) {
                                    int resID = Policy2AlertMsg(policyID, oprID2);
                                    if (resID > 0) {
                                        try {
                                            String msg3 = this.resourceContext.getResources().getText(resID).toString();
                                            if (policyID == 106) {
                                                WifiManager mWifiManager = (WifiManager) this.mContext.getSystemService("wifi");
                                                if (mWifiManager.isWifiEnabled()) {
                                                    msg = this.resourceContext.getResources().getText(getStringId(this.resourceContext, "security_alert_closewifi")).toString();
                                                }
                                                if (policyID == 105 && param.equals("0")) {
                                                    msg = this.resourceContext.getResources().getText(getStringId(this.resourceContext, "security_alert_closedataconnect")).toString();
                                                }
                                                log("judge() policyID:" + policyID + ",msg:" + msg);
                                                msg2 = msg;
                                            }
                                            msg = msg3;
                                            if (policyID == 105) {
                                                msg = this.resourceContext.getResources().getText(getStringId(this.resourceContext, "security_alert_closedataconnect")).toString();
                                            }
                                            log("judge() policyID:" + policyID + ",msg:" + msg);
                                            msg2 = msg;
                                        } catch (Throwable th) {
                                            th = th;
                                            throw th;
                                        }
                                    } else {
                                        msg2 = "" + policyID;
                                    }
                                    uidKey uidkeyo = new uidKey(uid);
                                    String appname = this.gApplicationCache.get(uidkeyo);
                                    if (appname == null) {
                                        try {
                                            int index = packagename.length;
                                            try {
                                                ApplicationInfo appInfo = this.mPackageManager.getApplicationInfo(packagename[index - 1], 0);
                                                appname = appInfo.loadLabel(this.mContext.getPackageManager()).toString();
                                                uidKey uido = new uidKey(uid);
                                                this.gApplicationCache.put(uido, appname);
                                                int x = 0;
                                                while (x < index) {
                                                    int index2 = index;
                                                    StringBuilder sb = new StringBuilder();
                                                    ApplicationInfo appInfo2 = appInfo;
                                                    sb.append("judge() packagename=");
                                                    sb.append(packagename[x].toString());
                                                    log(sb.toString());
                                                    x++;
                                                    index = index2;
                                                    appInfo = appInfo2;
                                                }
                                            } catch (PackageManager.NameNotFoundException e) {
                                                log("PackageManager.NameNotFoundException");
                                            }
                                        } catch (PackageManager.NameNotFoundException e2) {
                                        }
                                    }
                                    iRet = showAlert(appname + ((Object) this.resourceContext.getResources().getText(getStringId(this.resourceContext, "security_alert_tryto"))) + " " + msg2, uid, policyID) ? 2 : JDG_USER_REFUSE;
                                } else if (perm == 0) {
                                    iRet = 1;
                                } else if (perm == 1) {
                                    iRet = -10;
                                }
                                if (iRet > 0) {
                                    updateOperationLog(packagename[0], policyID, 1);
                                } else {
                                    updateOperationLog(packagename[0], policyID, 0);
                                }
                            }
                            log("judge(), ret: " + iRet);
                            return iRet;
                        } catch (Throwable th2) {
                            th = th2;
                        }
                    }
                    return 1;
                } catch (Throwable th3) {
                    th = th3;
                }
            } catch (Throwable th4) {
                th = th4;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getTimeText(String text, int count) {
        if (text != null && text.length() > 0 && count > 0) {
            int index = text.indexOf("(");
            if (index > 0) {
                return text.substring(0, index) + "(" + count + "s)";
            }
            return text + "(" + count + "s)";
        }
        return text;
    }

    private class selectDialog {
        private static final int TYPE_NEGATIVE = 1;
        private Handler mHcountdwn;
        private volatile int spolicyId;
        private volatile int suid;
        private HandlerThread mTcountdwn = new HandlerThread("countdwn");
        private Button n = null;
        private int mNegativeCount = 15;
        private AlertDialog d = null;
        private volatile boolean remind = false;
        private final Runnable mUpdatatime = new Runnable() { // from class: com.android.security.SecurityService.selectDialog.1
            @Override // java.lang.Runnable
            public void run() {
                if (selectDialog.this.n != null) {
                    if (selectDialog.this.mNegativeCount > 0) {
                        String text = (String) selectDialog.this.n.getText();
                        selectDialog.this.n.setText(SecurityService.this.getTimeText(text, selectDialog.this.mNegativeCount));
                    } else {
                        selectDialog.this.n.performClick();
                    }
                }
            }
        };
        private final Runnable mPowerLongPress = new Runnable() { // from class: com.android.security.SecurityService.selectDialog.3
            final CharSequence[] items;
            CharSequence msg;
            boolean[] state = {false};

            {
                this.msg = SecurityService.this.resourceContext.getResources().getText(SecurityService.this.getStringId(SecurityService.this.resourceContext, "security_alert_remind"));
                this.items = new CharSequence[]{this.msg};
            }

            @Override // java.lang.Runnable
            public void run() {
                AlertDialog.Builder b = new AlertDialog.Builder(SecurityService.this.mContext).setTitle("Security Alert").setTitle(SecurityService.this.mAlertMsg).setMultiChoiceItems(this.items, this.state, new DialogInterface.OnMultiChoiceClickListener() { // from class: com.android.security.SecurityService.selectDialog.3.3
                    @Override // android.content.DialogInterface.OnMultiChoiceClickListener
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        if (isChecked) {
                            selectDialog.this.remind = true;
                        } else {
                            selectDialog.this.remind = false;
                        }
                    }
                }).setPositiveButton(SecurityService.this.resourceContext.getResources().getText(SecurityService.this.getStringId(SecurityService.this.resourceContext, "security_alert_choice_allow")), new DialogInterface.OnClickListener() { // from class: com.android.security.SecurityService.selectDialog.3.2
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int whichButton) {
                        SecurityService.this.log("allow");
                        SecurityService.this.mAlertRet = true;
                        if (selectDialog.this.remind) {
                            SecurityService.this.updatePermission(selectDialog.this.suid, selectDialog.this.spolicyId, 0);
                        }
                    }
                }).setNegativeButton(((Object) SecurityService.this.resourceContext.getResources().getText(SecurityService.this.getStringId(SecurityService.this.resourceContext, "security_alert_choice_refuse"))) + "(" + selectDialog.this.mNegativeCount + "s)", new DialogInterface.OnClickListener() { // from class: com.android.security.SecurityService.selectDialog.3.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int whichButton) {
                        SecurityService.this.log("refuse");
                        SecurityService.this.mAlertRet = false;
                        if (selectDialog.this.remind) {
                            SecurityService.this.updatePermission(selectDialog.this.suid, selectDialog.this.spolicyId, 1);
                        }
                    }
                });
                selectDialog.this.d = b.create();
                selectDialog.this.d.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.android.security.SecurityService.selectDialog.3.4
                    @Override // android.content.DialogInterface.OnDismissListener
                    public void onDismiss(DialogInterface dialog) {
                        selectDialog.this.mHcountdwn.removeMessages(1);
                        selectDialog.this.mHcountdwn.getLooper().quit();
                        synchronized (SecurityService.this.mAlertLock) {
                            SecurityService.this.log("dismiss");
                            SecurityService.this.mAlertLock.notify();
                        }
                    }
                });
                selectDialog.this.d.getWindow().setType(2008);
                selectDialog.this.d.getWindow().setType(2003);
                selectDialog.this.d.show();
                selectDialog selectdialog = selectDialog.this;
                selectdialog.n = selectdialog.d.getButton(-2);
                selectDialog.this.mHcountdwn.sendEmptyMessageDelayed(1, 1000L);
            }
        };

        static /* synthetic */ int access$1310(selectDialog x0) {
            int i = x0.mNegativeCount;
            x0.mNegativeCount = i - 1;
            return i;
        }

        public selectDialog(int uid, int policyId) {
            this.mHcountdwn = null;
            this.suid = 0;
            this.spolicyId = 0;
            this.suid = uid;
            this.spolicyId = policyId;
            this.mTcountdwn.start();
            this.mHcountdwn = new Handler(this.mTcountdwn.getLooper()) { // from class: com.android.security.SecurityService.selectDialog.2
                @Override // android.os.Handler
                public void handleMessage(Message msg) {
                    if (msg.what == 1) {
                        SecurityService.this.log("mNegativeCount = " + selectDialog.this.mNegativeCount + selectDialog.this.n);
                        if (selectDialog.this.mNegativeCount > 0) {
                            selectDialog.access$1310(selectDialog.this);
                            SecurityService.this.mHandler.post(selectDialog.this.mUpdatatime);
                            selectDialog.this.mHcountdwn.sendEmptyMessageDelayed(1, 1000L);
                        } else {
                            SecurityService.this.log("mNegativeCount <= 0" + selectDialog.this.n);
                            SecurityService.this.mHandler.post(selectDialog.this.mUpdatatime);
                        }
                    }
                }
            };
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean show(String msg) {
            boolean z;
            SecurityService.this.log("showAlert, msg: " + msg);
            synchronized (SecurityService.this.mAlertLock) {
                SecurityService.this.mAlertMsg = msg;
                SecurityService.this.mAlertRet = false;
                SecurityService.this.mHandler.post(this.mPowerLongPress);
                try {
                    SecurityService.this.mAlertLock.wait(SecurityService.CTA_DIALOG_TIMEOUT_MS);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                z = SecurityService.this.mAlertRet;
            }
            return z;
        }
    }

    private boolean showAlert(String msg, int uid, int policyId) {
        log("showAlert, msg: " + msg);
        return new selectDialog(uid, policyId).show(msg);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int[][] initPolicy2ResID() {
        log("start initPolicy2resid");
        int[][] mPolicy = {new int[]{101, getStringId(this.resourceContext, "security_alert_placecall")}, new int[]{HdmiCecKeycode.CEC_KEYCODE_RESTORE_VOLUME_FUNCTION, getStringId(this.resourceContext, "security_alert_sendmessage")}, new int[]{HdmiCecKeycode.CEC_KEYCODE_TUNE_FUNCTION, getStringId(this.resourceContext, "security_alert_sendmms")}, new int[]{HdmiCecKeycode.CEC_KEYCODE_SELECT_MEDIA_FUNCTION, getStringId(this.resourceContext, "security_alert_sendemail")}, new int[]{105, getStringId(this.resourceContext, "security_alert_enalbedataconnect")}, new int[]{106, getStringId(this.resourceContext, "security_alert_enablewifi")}, new int[]{201, getStringId(this.resourceContext, "security_alert_enablelocation")}, new int[]{204, getStringId(this.resourceContext, "security_alert_opencamera")}, new int[]{205, getStringId(this.resourceContext, "security_alert_writecontacts")}, new int[]{206, getStringId(this.resourceContext, "security_alert_writecalllog")}, new int[]{207, getStringId(this.resourceContext, "security_alert_writemessage")}, new int[]{208, getStringId(this.resourceContext, "security_alert_writemms")}, new int[]{209, getStringId(this.resourceContext, "security_alert_readcontacts")}, new int[]{210, getStringId(this.resourceContext, "security_alert_readcalllog")}, new int[]{211, getStringId(this.resourceContext, "security_alert_readmessage")}, new int[]{InputManagerService.SW_JACK_BITS, getStringId(this.resourceContext, "security_alert_readmms")}, new int[]{213, getStringId(this.resourceContext, "security_alert_readprotectedfiles")}, new int[]{301, getStringId(this.resourceContext, "security_alert_bt")}, new int[]{302, getStringId(this.resourceContext, "security_alert_nfc")}};
        return mPolicy;
    }

    public int getStringId(Context paramContext, String paramString) {
        return paramContext.getResources().getIdentifier(paramString, "string", paramContext.getPackageName());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(String msg) {
        if (this.vdebug) {
            Log.i(TAG, msg);
        }
    }
}
