package android.hardware.power.V1_3;

import android.hardware.power.V1_0.PowerStatePlatformSleepState;
import android.hardware.power.V1_1.PowerStateSubsystem;
import android.hidl.base.V1_0.DebugInfo;
import android.hidl.base.V1_0.IBase;
import android.os.HidlSupport;
import android.os.HwBinder;
import android.os.HwBlob;
import android.os.HwParcel;
import android.os.IHwBinder;
import android.os.IHwInterface;
import android.os.NativeHandle;
import android.os.RemoteException;
import com.android.server.usb.descriptors.UsbASFormat;
import com.android.server.usb.descriptors.UsbDescriptor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public interface IPower extends android.hardware.power.V1_2.IPower {
    public static final String kInterfaceName = "android.hardware.power@1.3::IPower";

    @Override // android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
    IHwBinder asBinder();

    @Override // android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
    void debug(NativeHandle nativeHandle, ArrayList<String> arrayList) throws RemoteException;

    @Override // android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
    DebugInfo getDebugInfo() throws RemoteException;

    @Override // android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
    ArrayList<byte[]> getHashChain() throws RemoteException;

    @Override // android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
    ArrayList<String> interfaceChain() throws RemoteException;

    @Override // android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
    String interfaceDescriptor() throws RemoteException;

    @Override // android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
    boolean linkToDeath(IHwBinder.DeathRecipient deathRecipient, long j) throws RemoteException;

    @Override // android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
    void notifySyspropsChanged() throws RemoteException;

    @Override // android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
    void ping() throws RemoteException;

    void powerHintAsync_1_3(int i, int i2) throws RemoteException;

    @Override // android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
    void setHALInstrumentation() throws RemoteException;

    @Override // android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
    boolean unlinkToDeath(IHwBinder.DeathRecipient deathRecipient) throws RemoteException;

    static IPower asInterface(IHwBinder binder) {
        if (binder == null) {
            return null;
        }
        IHwInterface iface = binder.queryLocalInterface(kInterfaceName);
        if (iface != null && (iface instanceof IPower)) {
            return (IPower) iface;
        }
        IPower proxy = new Proxy(binder);
        try {
            for (String descriptor : proxy.interfaceChain()) {
                if (descriptor.equals(kInterfaceName)) {
                    return proxy;
                }
            }
        } catch (RemoteException e) {
        }
        return null;
    }

    static IPower castFrom(IHwInterface iface) {
        if (iface == null) {
            return null;
        }
        return asInterface(iface.asBinder());
    }

    static IPower getService(String serviceName, boolean retry) throws RemoteException {
        return asInterface(HwBinder.getService(kInterfaceName, serviceName, retry));
    }

    static IPower getService(boolean retry) throws RemoteException {
        return getService("default", retry);
    }

    static IPower getService(String serviceName) throws RemoteException {
        return asInterface(HwBinder.getService(kInterfaceName, serviceName));
    }

    static IPower getService() throws RemoteException {
        return getService("default");
    }

    public static final class Proxy implements IPower {
        private IHwBinder mRemote;

        public Proxy(IHwBinder remote) {
            this.mRemote = (IHwBinder) Objects.requireNonNull(remote);
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public IHwBinder asBinder() {
            return this.mRemote;
        }

        public String toString() {
            try {
                return interfaceDescriptor() + "@Proxy";
            } catch (RemoteException e) {
                return "[class or subclass of android.hardware.power@1.3::IPower]@Proxy";
            }
        }

        public final boolean equals(Object other) {
            return HidlSupport.interfacesEqual(this, other);
        }

        public final int hashCode() {
            return asBinder().hashCode();
        }

        @Override // android.hardware.power.V1_0.IPower
        public void setInteractive(boolean interactive) throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(android.hardware.power.V1_0.IPower.kInterfaceName);
            _hidl_request.writeBool(interactive);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(1, _hidl_request, _hidl_reply, 0);
                _hidl_reply.verifySuccess();
                _hidl_request.releaseTemporaryStorage();
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_0.IPower
        public void powerHint(int hint, int data) throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(android.hardware.power.V1_0.IPower.kInterfaceName);
            _hidl_request.writeInt32(hint);
            _hidl_request.writeInt32(data);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(2, _hidl_request, _hidl_reply, 0);
                _hidl_reply.verifySuccess();
                _hidl_request.releaseTemporaryStorage();
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_0.IPower
        public void setFeature(int feature, boolean activate) throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(android.hardware.power.V1_0.IPower.kInterfaceName);
            _hidl_request.writeInt32(feature);
            _hidl_request.writeBool(activate);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(3, _hidl_request, _hidl_reply, 0);
                _hidl_reply.verifySuccess();
                _hidl_request.releaseTemporaryStorage();
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_0.IPower
        public void getPlatformLowPowerStats(android.hardware.power.V1_0.IPower.getPlatformLowPowerStatsCallback _hidl_cb) throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(android.hardware.power.V1_0.IPower.kInterfaceName);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(4, _hidl_request, _hidl_reply, 0);
                _hidl_reply.verifySuccess();
                _hidl_request.releaseTemporaryStorage();
                ArrayList<PowerStatePlatformSleepState> _hidl_out_states = PowerStatePlatformSleepState.readVectorFromParcel(_hidl_reply);
                int _hidl_out_retval = _hidl_reply.readInt32();
                _hidl_cb.onValues(_hidl_out_states, _hidl_out_retval);
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_1.IPower
        public void getSubsystemLowPowerStats(android.hardware.power.V1_1.IPower.getSubsystemLowPowerStatsCallback _hidl_cb) throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(android.hardware.power.V1_1.IPower.kInterfaceName);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(5, _hidl_request, _hidl_reply, 0);
                _hidl_reply.verifySuccess();
                _hidl_request.releaseTemporaryStorage();
                ArrayList<PowerStateSubsystem> _hidl_out_subsystems = PowerStateSubsystem.readVectorFromParcel(_hidl_reply);
                int _hidl_out_retval = _hidl_reply.readInt32();
                _hidl_cb.onValues(_hidl_out_subsystems, _hidl_out_retval);
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_1.IPower
        public void powerHintAsync(int hint, int data) throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(android.hardware.power.V1_1.IPower.kInterfaceName);
            _hidl_request.writeInt32(hint);
            _hidl_request.writeInt32(data);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(6, _hidl_request, _hidl_reply, 1);
                _hidl_request.releaseTemporaryStorage();
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_2.IPower
        public void powerHintAsync_1_2(int hint, int data) throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(android.hardware.power.V1_2.IPower.kInterfaceName);
            _hidl_request.writeInt32(hint);
            _hidl_request.writeInt32(data);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(7, _hidl_request, _hidl_reply, 1);
                _hidl_request.releaseTemporaryStorage();
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_3.IPower
        public void powerHintAsync_1_3(int hint, int data) throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(IPower.kInterfaceName);
            _hidl_request.writeInt32(hint);
            _hidl_request.writeInt32(data);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(8, _hidl_request, _hidl_reply, 1);
                _hidl_request.releaseTemporaryStorage();
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public ArrayList<String> interfaceChain() throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(256067662, _hidl_request, _hidl_reply, 0);
                _hidl_reply.verifySuccess();
                _hidl_request.releaseTemporaryStorage();
                ArrayList<String> _hidl_out_descriptors = _hidl_reply.readStringVector();
                return _hidl_out_descriptors;
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public void debug(NativeHandle fd, ArrayList<String> options) throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(IBase.kInterfaceName);
            _hidl_request.writeNativeHandle(fd);
            _hidl_request.writeStringVector(options);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(256131655, _hidl_request, _hidl_reply, 0);
                _hidl_reply.verifySuccess();
                _hidl_request.releaseTemporaryStorage();
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public String interfaceDescriptor() throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(256136003, _hidl_request, _hidl_reply, 0);
                _hidl_reply.verifySuccess();
                _hidl_request.releaseTemporaryStorage();
                String _hidl_out_descriptor = _hidl_reply.readString();
                return _hidl_out_descriptor;
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public ArrayList<byte[]> getHashChain() throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(256398152, _hidl_request, _hidl_reply, 0);
                _hidl_reply.verifySuccess();
                _hidl_request.releaseTemporaryStorage();
                ArrayList<byte[]> _hidl_out_hashchain = new ArrayList<>();
                HwBlob _hidl_blob = _hidl_reply.readBuffer(16L);
                int _hidl_vec_size = _hidl_blob.getInt32(8L);
                HwBlob childBlob = _hidl_reply.readEmbeddedBuffer(_hidl_vec_size * 32, _hidl_blob.handle(), 0L, true);
                _hidl_out_hashchain.clear();
                for (int _hidl_index_0 = 0; _hidl_index_0 < _hidl_vec_size; _hidl_index_0++) {
                    byte[] _hidl_vec_element = new byte[32];
                    long _hidl_array_offset_1 = _hidl_index_0 * 32;
                    childBlob.copyToInt8Array(_hidl_array_offset_1, _hidl_vec_element, 32);
                    _hidl_out_hashchain.add(_hidl_vec_element);
                }
                _hidl_reply.release();
                return _hidl_out_hashchain;
            } catch (Throwable th) {
                _hidl_reply.release();
                throw th;
            }
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public void setHALInstrumentation() throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(256462420, _hidl_request, _hidl_reply, 1);
                _hidl_request.releaseTemporaryStorage();
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public boolean linkToDeath(IHwBinder.DeathRecipient recipient, long cookie) throws RemoteException {
            return this.mRemote.linkToDeath(recipient, cookie);
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public void ping() throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(256921159, _hidl_request, _hidl_reply, 0);
                _hidl_reply.verifySuccess();
                _hidl_request.releaseTemporaryStorage();
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public DebugInfo getDebugInfo() throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(257049926, _hidl_request, _hidl_reply, 0);
                _hidl_reply.verifySuccess();
                _hidl_request.releaseTemporaryStorage();
                DebugInfo _hidl_out_info = new DebugInfo();
                _hidl_out_info.readFromParcel(_hidl_reply);
                return _hidl_out_info;
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public void notifySyspropsChanged() throws RemoteException {
            HwParcel _hidl_request = new HwParcel();
            _hidl_request.writeInterfaceToken(IBase.kInterfaceName);
            HwParcel _hidl_reply = new HwParcel();
            try {
                this.mRemote.transact(257120595, _hidl_request, _hidl_reply, 1);
                _hidl_request.releaseTemporaryStorage();
            } finally {
                _hidl_reply.release();
            }
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public boolean unlinkToDeath(IHwBinder.DeathRecipient recipient) throws RemoteException {
            return this.mRemote.unlinkToDeath(recipient);
        }
    }

    public static abstract class Stub extends HwBinder implements IPower {
        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public IHwBinder asBinder() {
            return this;
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public final ArrayList<String> interfaceChain() {
            return new ArrayList<>(Arrays.asList(IPower.kInterfaceName, android.hardware.power.V1_2.IPower.kInterfaceName, android.hardware.power.V1_1.IPower.kInterfaceName, android.hardware.power.V1_0.IPower.kInterfaceName, IBase.kInterfaceName));
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public void debug(NativeHandle fd, ArrayList<String> options) {
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public final String interfaceDescriptor() {
            return IPower.kInterfaceName;
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public final ArrayList<byte[]> getHashChain() {
            return new ArrayList<>(Arrays.asList(new byte[]{90, 70, 78, 109, -75, 63, -83, UsbDescriptor.DESCRIPTORTYPE_REPORT, 57, -122, -42, 85, 2, -118, 24, 24, 91, 115, -37, -114, 43, -6, -106, 99, -7, 4, 44, -106, UsbDescriptor.DESCRIPTORTYPE_PHYSICAL, -21, 10, -96}, new byte[]{22, 62, 17, 94, UsbASFormat.EXT_FORMAT_TYPE_III, 63, -63, -41, 124, -35, 74, -116, -16, -56, 51, -69, -117, -115, 116, -2, 53, -56, -128, -2, 105, 49, 1, -47, 119, 116, -110, 111}, new byte[]{UsbDescriptor.DESCRIPTORTYPE_REPORT, 79, -99, UsbDescriptor.DESCRIPTORTYPE_REPORT, -93, 103, -96, 1, 111, 9, -74, -36, 103, 111, 83, -15, 68, 102, -105, -39, -36, 116, 113, 99, 3, UsbDescriptor.DESCRIPTORTYPE_PHYSICAL, UsbDescriptor.DESCRIPTORTYPE_HUB, -27, -38, 85, 45, -27}, new byte[]{-34, -18, 29, -60, -108, -113, 51, -81, 32, 126, UsbDescriptor.DESCRIPTORTYPE_CAPABILITY, 8, -85, -96, -10, -52, 7, -81, -73, -112, 14, -85, 83, -13, 49, -110, -56, -54, -63, 55, -18, -4}, new byte[]{-20, 127, -41, -98, -48, 45, -6, -123, -68, 73, -108, 38, -83, -82, 62, -66, UsbDescriptor.DESCRIPTORTYPE_PHYSICAL, -17, 5, UsbDescriptor.DESCRIPTORTYPE_AUDIO_INTERFACE, -13, -51, 105, 87, 19, -109, UsbDescriptor.DESCRIPTORTYPE_AUDIO_INTERFACE, -72, 59, 24, -54, 76}));
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public final void setHALInstrumentation() {
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public final boolean linkToDeath(IHwBinder.DeathRecipient recipient, long cookie) {
            return true;
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public final void ping() {
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public final DebugInfo getDebugInfo() {
            DebugInfo info = new DebugInfo();
            info.pid = HidlSupport.getPidIfSharable();
            info.ptr = 0L;
            info.arch = 0;
            return info;
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public final void notifySyspropsChanged() {
            HwBinder.enableInstrumentation();
        }

        @Override // android.hardware.power.V1_3.IPower, android.hardware.power.V1_2.IPower, android.hardware.power.V1_1.IPower, android.hardware.power.V1_0.IPower, android.hidl.base.V1_0.IBase
        public final boolean unlinkToDeath(IHwBinder.DeathRecipient recipient) {
            return true;
        }

        public IHwInterface queryLocalInterface(String descriptor) {
            if (IPower.kInterfaceName.equals(descriptor)) {
                return this;
            }
            return null;
        }

        public void registerAsService(String serviceName) throws RemoteException {
            registerService(serviceName);
        }

        public String toString() {
            return interfaceDescriptor() + "@Stub";
        }

        public void onTransact(int _hidl_code, HwParcel _hidl_request, final HwParcel _hidl_reply, int _hidl_flags) throws RemoteException {
            switch (_hidl_code) {
                case 1:
                    boolean _hidl_is_oneway = (_hidl_flags & 1) != 0;
                    if (_hidl_is_oneway) {
                        _hidl_reply.writeStatus(Integer.MIN_VALUE);
                        _hidl_reply.send();
                        return;
                    }
                    _hidl_request.enforceInterface(android.hardware.power.V1_0.IPower.kInterfaceName);
                    boolean interactive = _hidl_request.readBool();
                    setInteractive(interactive);
                    _hidl_reply.writeStatus(0);
                    _hidl_reply.send();
                    return;
                case 2:
                    boolean _hidl_is_oneway2 = (_hidl_flags & 1) != 0;
                    if (_hidl_is_oneway2) {
                        _hidl_reply.writeStatus(Integer.MIN_VALUE);
                        _hidl_reply.send();
                        return;
                    }
                    _hidl_request.enforceInterface(android.hardware.power.V1_0.IPower.kInterfaceName);
                    int hint = _hidl_request.readInt32();
                    int data = _hidl_request.readInt32();
                    powerHint(hint, data);
                    _hidl_reply.writeStatus(0);
                    _hidl_reply.send();
                    return;
                case 3:
                    boolean _hidl_is_oneway3 = (_hidl_flags & 1) != 0;
                    if (_hidl_is_oneway3) {
                        _hidl_reply.writeStatus(Integer.MIN_VALUE);
                        _hidl_reply.send();
                        return;
                    }
                    _hidl_request.enforceInterface(android.hardware.power.V1_0.IPower.kInterfaceName);
                    int feature = _hidl_request.readInt32();
                    boolean activate = _hidl_request.readBool();
                    setFeature(feature, activate);
                    _hidl_reply.writeStatus(0);
                    _hidl_reply.send();
                    return;
                case 4:
                    boolean _hidl_is_oneway4 = (_hidl_flags & 1) != 0;
                    if (_hidl_is_oneway4) {
                        _hidl_reply.writeStatus(Integer.MIN_VALUE);
                        _hidl_reply.send();
                        return;
                    } else {
                        _hidl_request.enforceInterface(android.hardware.power.V1_0.IPower.kInterfaceName);
                        getPlatformLowPowerStats(new android.hardware.power.V1_0.IPower.getPlatformLowPowerStatsCallback() { // from class: android.hardware.power.V1_3.IPower.Stub.1
                            @Override // android.hardware.power.V1_0.IPower.getPlatformLowPowerStatsCallback
                            public void onValues(ArrayList<PowerStatePlatformSleepState> states, int retval) {
                                _hidl_reply.writeStatus(0);
                                PowerStatePlatformSleepState.writeVectorToParcel(_hidl_reply, states);
                                _hidl_reply.writeInt32(retval);
                                _hidl_reply.send();
                            }
                        });
                        return;
                    }
                case 5:
                    boolean _hidl_is_oneway5 = (_hidl_flags & 1) != 0;
                    if (_hidl_is_oneway5) {
                        _hidl_reply.writeStatus(Integer.MIN_VALUE);
                        _hidl_reply.send();
                        return;
                    } else {
                        _hidl_request.enforceInterface(android.hardware.power.V1_1.IPower.kInterfaceName);
                        getSubsystemLowPowerStats(new android.hardware.power.V1_1.IPower.getSubsystemLowPowerStatsCallback() { // from class: android.hardware.power.V1_3.IPower.Stub.2
                            @Override // android.hardware.power.V1_1.IPower.getSubsystemLowPowerStatsCallback
                            public void onValues(ArrayList<PowerStateSubsystem> subsystems, int retval) {
                                _hidl_reply.writeStatus(0);
                                PowerStateSubsystem.writeVectorToParcel(_hidl_reply, subsystems);
                                _hidl_reply.writeInt32(retval);
                                _hidl_reply.send();
                            }
                        });
                        return;
                    }
                case 6:
                    int hint2 = _hidl_flags & 1;
                    boolean _hidl_is_oneway6 = hint2 != 0;
                    if (!_hidl_is_oneway6) {
                        _hidl_reply.writeStatus(Integer.MIN_VALUE);
                        _hidl_reply.send();
                        return;
                    } else {
                        _hidl_request.enforceInterface(android.hardware.power.V1_1.IPower.kInterfaceName);
                        int hint3 = _hidl_request.readInt32();
                        int data2 = _hidl_request.readInt32();
                        powerHintAsync(hint3, data2);
                        return;
                    }
                case 7:
                    boolean _hidl_is_oneway7 = (_hidl_flags & 1) != 0;
                    if (!_hidl_is_oneway7) {
                        _hidl_reply.writeStatus(Integer.MIN_VALUE);
                        _hidl_reply.send();
                        return;
                    } else {
                        _hidl_request.enforceInterface(android.hardware.power.V1_2.IPower.kInterfaceName);
                        int hint4 = _hidl_request.readInt32();
                        int data3 = _hidl_request.readInt32();
                        powerHintAsync_1_2(hint4, data3);
                        return;
                    }
                case 8:
                    boolean _hidl_is_oneway8 = (_hidl_flags & 1) != 0;
                    if (!_hidl_is_oneway8) {
                        _hidl_reply.writeStatus(Integer.MIN_VALUE);
                        _hidl_reply.send();
                        return;
                    } else {
                        _hidl_request.enforceInterface(IPower.kInterfaceName);
                        int hint5 = _hidl_request.readInt32();
                        int data4 = _hidl_request.readInt32();
                        powerHintAsync_1_3(hint5, data4);
                        return;
                    }
                default:
                    switch (_hidl_code) {
                        case 256067662:
                            boolean _hidl_is_oneway9 = (_hidl_flags & 1) != 0;
                            if (_hidl_is_oneway9) {
                                _hidl_reply.writeStatus(Integer.MIN_VALUE);
                                _hidl_reply.send();
                                return;
                            }
                            _hidl_request.enforceInterface(IBase.kInterfaceName);
                            ArrayList<String> _hidl_out_descriptors = interfaceChain();
                            _hidl_reply.writeStatus(0);
                            _hidl_reply.writeStringVector(_hidl_out_descriptors);
                            _hidl_reply.send();
                            return;
                        case 256131655:
                            boolean _hidl_is_oneway10 = (_hidl_flags & 1) != 0;
                            if (_hidl_is_oneway10) {
                                _hidl_reply.writeStatus(Integer.MIN_VALUE);
                                _hidl_reply.send();
                                return;
                            }
                            _hidl_request.enforceInterface(IBase.kInterfaceName);
                            NativeHandle fd = _hidl_request.readNativeHandle();
                            ArrayList<String> options = _hidl_request.readStringVector();
                            debug(fd, options);
                            _hidl_reply.writeStatus(0);
                            _hidl_reply.send();
                            return;
                        case 256136003:
                            boolean _hidl_is_oneway11 = (_hidl_flags & 1) != 0;
                            if (_hidl_is_oneway11) {
                                _hidl_reply.writeStatus(Integer.MIN_VALUE);
                                _hidl_reply.send();
                                return;
                            }
                            _hidl_request.enforceInterface(IBase.kInterfaceName);
                            String _hidl_out_descriptor = interfaceDescriptor();
                            _hidl_reply.writeStatus(0);
                            _hidl_reply.writeString(_hidl_out_descriptor);
                            _hidl_reply.send();
                            return;
                        case 256398152:
                            boolean _hidl_is_oneway12 = (_hidl_flags & 1) != 0;
                            if (_hidl_is_oneway12) {
                                _hidl_reply.writeStatus(Integer.MIN_VALUE);
                                _hidl_reply.send();
                                return;
                            }
                            _hidl_request.enforceInterface(IBase.kInterfaceName);
                            ArrayList<byte[]> _hidl_out_hashchain = getHashChain();
                            _hidl_reply.writeStatus(0);
                            HwBlob _hidl_blob = new HwBlob(16);
                            int _hidl_vec_size = _hidl_out_hashchain.size();
                            _hidl_blob.putInt32(8L, _hidl_vec_size);
                            _hidl_blob.putBool(12L, false);
                            HwBlob childBlob = new HwBlob(_hidl_vec_size * 32);
                            for (int _hidl_index_0 = 0; _hidl_index_0 < _hidl_vec_size; _hidl_index_0++) {
                                long _hidl_array_offset_1 = _hidl_index_0 * 32;
                                byte[] _hidl_array_item_1 = _hidl_out_hashchain.get(_hidl_index_0);
                                if (_hidl_array_item_1 == null || _hidl_array_item_1.length != 32) {
                                    throw new IllegalArgumentException("Array element is not of the expected length");
                                }
                                childBlob.putInt8Array(_hidl_array_offset_1, _hidl_array_item_1);
                            }
                            _hidl_blob.putBlob(0L, childBlob);
                            _hidl_reply.writeBuffer(_hidl_blob);
                            _hidl_reply.send();
                            return;
                        case 256462420:
                            boolean _hidl_is_oneway13 = (_hidl_flags & 1) != 0;
                            if (!_hidl_is_oneway13) {
                                _hidl_reply.writeStatus(Integer.MIN_VALUE);
                                _hidl_reply.send();
                                return;
                            } else {
                                _hidl_request.enforceInterface(IBase.kInterfaceName);
                                setHALInstrumentation();
                                return;
                            }
                        case 256660548:
                            boolean _hidl_is_oneway14 = (_hidl_flags & 1) != 0;
                            if (_hidl_is_oneway14) {
                                _hidl_reply.writeStatus(Integer.MIN_VALUE);
                                _hidl_reply.send();
                                return;
                            }
                            return;
                        case 256921159:
                            boolean _hidl_is_oneway15 = (_hidl_flags & 1) != 0;
                            if (_hidl_is_oneway15) {
                                _hidl_reply.writeStatus(Integer.MIN_VALUE);
                                _hidl_reply.send();
                                return;
                            } else {
                                _hidl_request.enforceInterface(IBase.kInterfaceName);
                                ping();
                                _hidl_reply.writeStatus(0);
                                _hidl_reply.send();
                                return;
                            }
                        case 257049926:
                            boolean _hidl_is_oneway16 = (_hidl_flags & 1) != 0;
                            if (_hidl_is_oneway16) {
                                _hidl_reply.writeStatus(Integer.MIN_VALUE);
                                _hidl_reply.send();
                                return;
                            }
                            _hidl_request.enforceInterface(IBase.kInterfaceName);
                            DebugInfo _hidl_out_info = getDebugInfo();
                            _hidl_reply.writeStatus(0);
                            _hidl_out_info.writeToParcel(_hidl_reply);
                            _hidl_reply.send();
                            return;
                        case 257120595:
                            boolean _hidl_is_oneway17 = (_hidl_flags & 1) != 0;
                            if (!_hidl_is_oneway17) {
                                _hidl_reply.writeStatus(Integer.MIN_VALUE);
                                _hidl_reply.send();
                                return;
                            } else {
                                _hidl_request.enforceInterface(IBase.kInterfaceName);
                                notifySyspropsChanged();
                                return;
                            }
                        case 257250372:
                            boolean _hidl_is_oneway18 = (_hidl_flags & 1) != 0;
                            if (_hidl_is_oneway18) {
                                _hidl_reply.writeStatus(Integer.MIN_VALUE);
                                _hidl_reply.send();
                                return;
                            }
                            return;
                        default:
                            return;
                    }
            }
        }
    }
}
