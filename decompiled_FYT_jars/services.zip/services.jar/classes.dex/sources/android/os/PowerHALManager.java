package android.os;

import android.content.Context;
import android.hidl.base.V1_0.IBase;
import android.util.Log;
import vendor.sprd.hardware.power.V4_0.IPower;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public final class PowerHALManager implements IHwBinder.DeathRecipient {
    public static final int POWER_HINT_VENDOR_TIMEOUT_MAX = 5000;
    public static final int POWER_HINT_VENDOR_TIMEOUT_MIN = 500;
    private static final String TAG = "PowerHALManager";
    private Context mContext;
    private Handler mHandler;
    private IPower mService;

    public PowerHALManager(Context context, Handler handler) {
        this.mContext = context;
        this.mHandler = handler;
        try {
            this.mService = IPower.getService();
        } catch (Exception e) {
            Log.e(TAG, "Get Power HIDL HAL service failed!!!");
            e.printStackTrace();
        }
    }

    public PowerHintScene createPowerHintScene(String tag, int sceneId, String sceneName) {
        IPower iPower = this.mService;
        if (iPower == null) {
            Log.e(TAG, "Power HAL service isn't working");
            return null;
        }
        try {
            iPower.linkToDeath(this, 0L);
        } catch (Exception e) {
            Log.e(TAG, "linkToDeath() failed");
            e.printStackTrace();
        }
        return new PowerHintScene(tag, sceneId, sceneName);
    }

    public final int getSceneIdByName(String sceneName) {
        IPower iPower;
        if (sceneName == null || (iPower = this.mService) == null) {
            Log.e(TAG, "getSceneIdByName(null) or mService is null!!!");
            return 0;
        }
        try {
            int sceneId = iPower.getSceneIdByName(sceneName);
            return sceneId;
        } catch (RemoteException e) {
            return 0;
        }
    }

    public void enable() {
        IPower iPower = this.mService;
        if (iPower == null) {
            Log.e(TAG, "mService is null!!!");
        } else {
            try {
                iPower.controlPowerHint(1);
            } catch (RemoteException e) {
            }
        }
    }

    public void disable() {
        IPower iPower = this.mService;
        if (iPower == null) {
            Log.e(TAG, "mService is null!!!");
        } else {
            try {
                iPower.controlPowerHint(0);
            } catch (RemoteException e) {
            }
        }
    }

    public void serviceDied(long cookie) {
        Log.e(TAG, "Power HAL service has died");
        this.mService = null;
    }

    public final class PowerHintScene {
        private int mCount;
        private final Runnable mReleaser;
        private int mSceneId;
        private String mSceneName;
        private String mTag;
        private IBase mToken;

        private PowerHintScene(String tag, int sceneId, String sceneName) {
            this.mReleaser = new Runnable() { // from class: android.os.PowerHALManager.PowerHintScene.1
                @Override // java.lang.Runnable
                public void run() {
                    PowerHintScene.this.release();
                }
            };
            this.mTag = tag;
            this.mSceneId = sceneId;
            this.mSceneName = sceneName;
            this.mCount = 0;
            this.mToken = new IBase.Stub() { // from class: android.os.PowerHALManager.PowerHintScene.2
            };
        }

        protected void finalize() throws Throwable {
            synchronized (this) {
                if (this.mCount > 0) {
                    try {
                        if (PowerHALManager.this.mHandler != null) {
                            PowerHALManager.this.mHandler.removeCallbacks(this.mReleaser);
                        }
                        if (PowerHALManager.this.mService == null) {
                            try {
                                PowerHALManager.this.mService = IPower.getService();
                            } catch (Exception e) {
                                Log.e(PowerHALManager.TAG, "Get Power HIDL HAL service failed!!!");
                                e.printStackTrace();
                            }
                            if (PowerHALManager.this.mService == null) {
                                return;
                            }
                            try {
                                PowerHALManager.this.mService.linkToDeath(PowerHALManager.this, 0L);
                            } catch (Exception e2) {
                                Log.e(PowerHALManager.TAG, "linkToDeath() failed");
                                e2.printStackTrace();
                            }
                        }
                        if (this.mSceneId != 0) {
                            PowerHALManager.this.mService.releasePowerHintBySceneId(this.mToken, this.mSceneId);
                        } else {
                            PowerHALManager.this.mService.releasePowerHintBySceneName(this.mToken, this.mSceneName);
                        }
                    } catch (RemoteException e3) {
                    }
                }
            }
        }

        public void acquire() {
            synchronized (this) {
                acquireLocked();
            }
        }

        public void acquire(long timeout) {
            if (PowerHALManager.this.mHandler == null) {
                Log.e(PowerHALManager.TAG, "mHandler == null, Unable to support timed release!!!");
                return;
            }
            synchronized (this) {
                acquireLocked();
                if (timeout < 500) {
                    timeout = 500;
                } else if (timeout > 5000) {
                    timeout = 5000;
                }
                PowerHALManager.this.mHandler.postDelayed(this.mReleaser, timeout);
            }
        }

        private void acquireLocked() {
            int i = this.mCount;
            this.mCount = i + 1;
            if (i == 0) {
                if (PowerHALManager.this.mHandler != null) {
                    PowerHALManager.this.mHandler.removeCallbacks(this.mReleaser);
                }
                try {
                    if (PowerHALManager.this.mService == null) {
                        return;
                    }
                    if (this.mSceneId != 0) {
                        PowerHALManager.this.mService.acquirePowerHintBySceneId(this.mToken, this.mTag, this.mSceneId);
                    } else {
                        PowerHALManager.this.mService.acquirePowerHintBySceneName(this.mToken, this.mTag, this.mSceneName);
                    }
                } catch (RemoteException e) {
                }
            }
        }

        public void release() {
            synchronized (this) {
                int i = this.mCount - 1;
                this.mCount = i;
                if (i == 0) {
                    if (PowerHALManager.this.mHandler != null) {
                        PowerHALManager.this.mHandler.removeCallbacks(this.mReleaser);
                    }
                    try {
                        if (PowerHALManager.this.mService == null) {
                            return;
                        }
                        if (this.mSceneId != 0) {
                            PowerHALManager.this.mService.releasePowerHintBySceneId(this.mToken, this.mSceneId);
                        } else {
                            PowerHALManager.this.mService.releasePowerHintBySceneName(this.mToken, this.mSceneName);
                        }
                    } catch (RemoteException e) {
                    }
                }
            }
        }
    }
}
