package android.net.dhcp;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public abstract class DhcpServerCallbacks extends IDhcpServerCallbacks.Stub {
    @Override // android.net.dhcp.IDhcpServerCallbacks
    public int getInterfaceVersion() {
        return 0;
    }
}
