package android.net.shared;

import android.net.LinkProperties;
import android.net.ProxyInfo;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public final class LinkPropertiesParcelableUtil {
    @Deprecated
    public static LinkProperties toStableParcelable(LinkProperties lp) {
        return lp;
    }

    @Deprecated
    public static ProxyInfo toStableParcelable(ProxyInfo info) {
        return info;
    }
}
