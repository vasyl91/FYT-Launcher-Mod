package android.net.util;

import android.net.NattKeepalivePacketData;
import android.net.NattKeepalivePacketDataParcelable;

/* JADX INFO: loaded from: D:\APK\APKRepatcher_v1.1.2\Projects\services.jar\dexFile\classes.dex */
public final class KeepalivePacketDataUtil {
    public static NattKeepalivePacketDataParcelable toStableParcelable(NattKeepalivePacketData pkt) {
        NattKeepalivePacketDataParcelable parcel = new NattKeepalivePacketDataParcelable();
        parcel.srcAddress = pkt.srcAddress.getAddress();
        parcel.srcPort = pkt.srcPort;
        parcel.dstAddress = pkt.dstAddress.getAddress();
        parcel.dstPort = pkt.dstPort;
        return parcel;
    }
}
