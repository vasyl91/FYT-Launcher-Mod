package android.test.suitebuilder;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\android.test.runner\classes.dex */
@Deprecated
public class UnitTestSuiteBuilder extends TestSuiteBuilder {
    public UnitTestSuiteBuilder(Class clazz) {
        this(clazz.getName(), clazz.getClassLoader());
    }

    public UnitTestSuiteBuilder(String name, ClassLoader classLoader) {
        super(name, classLoader);
        addRequirements(TestPredicates.REJECT_INSTRUMENTATION);
    }
}
