package android.test;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\android.test.runner\classes.dex */
@Deprecated
public class AssertionFailedError extends Error {
    public AssertionFailedError() {
    }

    public AssertionFailedError(String errorMessage) {
        super(errorMessage);
    }
}
