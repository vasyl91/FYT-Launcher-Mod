package android.test.suitebuilder;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\android.test.runner\classes.dex */
public class SmokeTestSuiteBuilder extends TestSuiteBuilder {
    public SmokeTestSuiteBuilder(Class clazz) {
        this(clazz.getName(), clazz.getClassLoader());
    }

    public SmokeTestSuiteBuilder(String name, ClassLoader classLoader) {
        super(name, classLoader);
        addRequirements(TestPredicates.SELECT_SMOKE);
    }
}
