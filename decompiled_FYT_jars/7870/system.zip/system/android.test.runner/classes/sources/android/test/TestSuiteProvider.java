package android.test;

import junit.framework.TestSuite;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\android.test.runner\classes.dex */
@Deprecated
public interface TestSuiteProvider {
    TestSuite getTestSuite();
}
