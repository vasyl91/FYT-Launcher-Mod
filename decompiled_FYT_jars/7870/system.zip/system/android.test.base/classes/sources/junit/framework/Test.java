package junit.framework;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\android.test.base\classes.dex */
public interface Test {
    int countTestCases();

    void run(TestResult testResult);
}
