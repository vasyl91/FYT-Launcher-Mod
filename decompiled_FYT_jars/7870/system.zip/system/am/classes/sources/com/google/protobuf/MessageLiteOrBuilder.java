package com.google.protobuf;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\am\classes.dex */
public interface MessageLiteOrBuilder {
    MessageLite getDefaultInstanceForType();

    boolean isInitialized();
}
