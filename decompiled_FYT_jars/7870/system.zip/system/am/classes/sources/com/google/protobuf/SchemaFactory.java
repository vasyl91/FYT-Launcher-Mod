package com.google.protobuf;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\am\classes.dex */
interface SchemaFactory {
    <T> Schema<T> createSchema(Class<T> cls);
}
