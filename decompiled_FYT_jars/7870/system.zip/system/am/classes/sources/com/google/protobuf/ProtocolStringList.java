package com.google.protobuf;

import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\am\classes.dex */
public interface ProtocolStringList extends List<String> {
    List<ByteString> asByteStringList();
}
