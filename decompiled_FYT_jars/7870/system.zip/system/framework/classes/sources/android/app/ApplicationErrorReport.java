package android.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.UnisocPackageManager;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Process;
import android.os.SystemProperties;
import android.provider.Settings;
import android.util.Log;
import android.util.Printer;
import com.android.internal.util.FastPrintWriter;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public class ApplicationErrorReport implements Parcelable {
    public static final Parcelable.Creator<ApplicationErrorReport> CREATOR = new Parcelable.Creator<ApplicationErrorReport>() { // from class: android.app.ApplicationErrorReport.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ApplicationErrorReport createFromParcel(Parcel source) {
            return new ApplicationErrorReport(source);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ApplicationErrorReport[] newArray(int size) {
            return new ApplicationErrorReport[size];
        }
    };
    static final String DEFAULT_ERROR_RECEIVER_PROPERTY = "ro.error.receiver.default";
    static final String SYSTEM_APPS_ERROR_RECEIVER_PROPERTY = "ro.error.receiver.system.apps";
    public static final int TYPE_ANR = 2;
    public static final int TYPE_BATTERY = 3;
    public static final int TYPE_CRASH = 1;
    public static final int TYPE_NONE = 0;
    public static final int TYPE_RUNNING_SERVICE = 5;
    public AnrInfo anrInfo;
    public BatteryInfo batteryInfo;
    public CrashInfo crashInfo;
    public String installerPackageName;
    public String packageName;
    public String processName;
    public RunningServiceInfo runningServiceInfo;
    public boolean systemApp;
    public long time;
    public int type;

    public ApplicationErrorReport() {
    }

    ApplicationErrorReport(Parcel in) {
        readFromParcel(in);
    }

    public static ComponentName getErrorReportReceiver(Context context, String packageName, int appFlags) {
        ComponentName result;
        int enabled = Settings.Global.getInt(context.getContentResolver(), "send_action_app_error", 0);
        if (enabled == 0) {
            return null;
        }
        PackageManager pm = context.getPackageManager();
        String candidate = null;
        try {
            candidate = pm.getInstallerPackageName(packageName);
        } catch (IllegalArgumentException e) {
        }
        if (candidate != null && (result = getErrorReportReceiver(pm, packageName, candidate)) != null) {
            return result;
        }
        if ((appFlags & 1) != 0) {
            String candidate2 = SystemProperties.get(SYSTEM_APPS_ERROR_RECEIVER_PROPERTY);
            ComponentName result2 = getErrorReportReceiver(pm, packageName, candidate2);
            if (result2 != null) {
                return result2;
            }
        }
        String candidate3 = SystemProperties.get(DEFAULT_ERROR_RECEIVER_PROPERTY);
        return getErrorReportReceiver(pm, packageName, candidate3);
    }

    static ComponentName getErrorReportReceiver(PackageManager pm, String errorPackage, String receiverPackage) {
        if (receiverPackage == null || receiverPackage.length() == 0 || receiverPackage.equals(errorPackage)) {
            return null;
        }
        Intent intent = new Intent(Intent.ACTION_APP_ERROR);
        intent.setPackage(receiverPackage);
        ResolveInfo info = pm.resolveActivity(intent, 0);
        if (info == null || info.activityInfo == null) {
            return null;
        }
        return new ComponentName(receiverPackage, info.activityInfo.name);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.type);
        parcel.writeString(this.packageName);
        parcel.writeString(this.installerPackageName);
        parcel.writeString(this.processName);
        parcel.writeLong(this.time);
        parcel.writeInt(this.systemApp ? 1 : 0);
        parcel.writeInt(this.crashInfo != null ? 1 : 0);
        switch (this.type) {
            case 1:
                CrashInfo crashInfo = this.crashInfo;
                if (crashInfo != null) {
                    crashInfo.writeToParcel(parcel, i);
                }
                break;
            case 2:
                this.anrInfo.writeToParcel(parcel, i);
                break;
            case 3:
                this.batteryInfo.writeToParcel(parcel, i);
                break;
            case 5:
                this.runningServiceInfo.writeToParcel(parcel, i);
                break;
        }
    }

    public void readFromParcel(Parcel in) {
        this.type = in.readInt();
        this.packageName = in.readString();
        this.installerPackageName = in.readString();
        this.processName = in.readString();
        this.time = in.readLong();
        this.systemApp = in.readInt() == 1;
        boolean hasCrashInfo = in.readInt() == 1;
        switch (this.type) {
            case 1:
                this.crashInfo = hasCrashInfo ? new CrashInfo(in) : null;
                this.anrInfo = null;
                this.batteryInfo = null;
                this.runningServiceInfo = null;
                break;
            case 2:
                this.anrInfo = new AnrInfo(in);
                this.crashInfo = null;
                this.batteryInfo = null;
                this.runningServiceInfo = null;
                break;
            case 3:
                this.batteryInfo = new BatteryInfo(in);
                this.anrInfo = null;
                this.crashInfo = null;
                this.runningServiceInfo = null;
                break;
            case 5:
                this.batteryInfo = null;
                this.anrInfo = null;
                this.crashInfo = null;
                this.runningServiceInfo = new RunningServiceInfo(in);
                break;
        }
    }

    public static class CrashInfo {
        public String crashTag;
        public String exceptionClassName;
        public String exceptionMessage;
        public String stackTrace;
        public String throwClassName;
        public String throwFileName;
        public int throwLineNumber;
        public String throwMethodName;

        public CrashInfo() {
        }

        /* JADX WARN: Code duplicated, block: B:37:0x00dd A[Catch: Exception -> 0x00d9, TryCatch #1 {Exception -> 0x00d9, blocks: (B:33:0x00d5, B:37:0x00dd, B:39:0x00e2), top: B:65:0x00d5 }] */
        /* JADX WARN: Code duplicated, block: B:39:0x00e2 A[Catch: Exception -> 0x00d9, TRY_LEAVE, TryCatch #1 {Exception -> 0x00d9, blocks: (B:33:0x00d5, B:37:0x00dd, B:39:0x00e2), top: B:65:0x00d5 }] */
        public CrashInfo(Throwable tr) {
            StringWriter sw = new StringWriter();
            FastPrintWriter fastPrintWriter = new FastPrintWriter(sw, false, 256);
            tr.printStackTrace((PrintWriter) fastPrintWriter);
            fastPrintWriter.flush();
            this.stackTrace = sanitizeString(sw.toString());
            this.exceptionMessage = tr.getMessage();
            if (this.stackTrace.contains("OutOfMemoryError")) {
                int pid = Process.myPid();
                String cmd = "cat /proc/" + pid + "/maps";
                Process proc = null;
                InputStream is = null;
                BufferedReader buf = null;
                Log.w("ApplicationErrorReport", "the memory map of " + pid);
                try {
                    try {
                        try {
                            Runtime runtime = Runtime.getRuntime();
                            proc = runtime.exec(cmd);
                            is = proc.getInputStream();
                            buf = new BufferedReader(new InputStreamReader(is));
                            while (true) {
                                String line = buf.readLine();
                                if (line == null) {
                                    break;
                                } else {
                                    Log.w("ApplicationErrorReport", line + "\n");
                                }
                            }
                            buf.close();
                            if (is != null) {
                                is.close();
                            }
                            if (proc != null) {
                                proc.destroy();
                            }
                        } catch (Throwable th) {
                            if (buf != null) {
                                try {
                                    buf.close();
                                    if (is != null) {
                                        is.close();
                                    }
                                    if (proc != null) {
                                        proc.destroy();
                                    }
                                } catch (Exception e) {
                                    Log.w("ApplicationErrorReport", "Fail to destroy resource as catch the Exception e: ", e);
                                    throw th;
                                }
                            } else {
                                if (is != null) {
                                    is.close();
                                }
                                if (proc != null) {
                                    proc.destroy();
                                }
                            }
                            throw th;
                        }
                    } catch (Exception e2) {
                        Log.w("ApplicationErrorReport", "Fail to get memory map:", e2);
                        if (buf != null) {
                            buf.close();
                        }
                        if (is != null) {
                            is.close();
                        }
                        if (proc != null) {
                            proc.destroy();
                        }
                    }
                } catch (Exception e3) {
                    Log.w("ApplicationErrorReport", "Fail to destroy resource as catch the Exception e: ", e3);
                }
            }
            Throwable rootTr = tr;
            while (tr.getCause() != null) {
                tr = tr.getCause();
                if (tr.getStackTrace() != null && tr.getStackTrace().length > 0) {
                    rootTr = tr;
                }
                String msg = tr.getMessage();
                if (msg != null && msg.length() > 0) {
                    this.exceptionMessage = msg;
                }
            }
            this.exceptionClassName = rootTr.getClass().getName();
            if (rootTr.getStackTrace().length > 0) {
                StackTraceElement trace = rootTr.getStackTrace()[0];
                this.throwFileName = trace.getFileName();
                this.throwClassName = trace.getClassName();
                this.throwMethodName = trace.getMethodName();
                this.throwLineNumber = trace.getLineNumber();
            } else {
                this.throwFileName = UnisocPackageManager.UNKNOWN;
                this.throwClassName = UnisocPackageManager.UNKNOWN;
                this.throwMethodName = UnisocPackageManager.UNKNOWN;
                this.throwLineNumber = 0;
            }
            this.exceptionMessage = sanitizeString(this.exceptionMessage);
        }

        public void appendStackTrace(String tr) {
            this.stackTrace = sanitizeString(this.stackTrace + tr);
        }

        private String sanitizeString(String s) {
            int acceptableLength = 10240 + 10240;
            if (s != null && s.length() > acceptableLength) {
                String replacement = "\n[TRUNCATED " + (s.length() - acceptableLength) + " CHARS]\n";
                StringBuilder sb = new StringBuilder(replacement.length() + acceptableLength);
                sb.append(s.substring(0, 10240));
                sb.append(replacement);
                sb.append(s.substring(s.length() - 10240));
                return sb.toString();
            }
            return s;
        }

        public CrashInfo(Parcel in) {
            this.exceptionClassName = in.readString();
            this.exceptionMessage = in.readString();
            this.throwFileName = in.readString();
            this.throwClassName = in.readString();
            this.throwMethodName = in.readString();
            this.throwLineNumber = in.readInt();
            this.stackTrace = in.readString();
            this.crashTag = in.readString();
        }

        public void writeToParcel(Parcel dest, int flags) {
            int start = dest.dataPosition();
            dest.writeString(this.exceptionClassName);
            dest.writeString(this.exceptionMessage);
            dest.writeString(this.throwFileName);
            dest.writeString(this.throwClassName);
            dest.writeString(this.throwMethodName);
            dest.writeInt(this.throwLineNumber);
            dest.writeString(this.stackTrace);
            dest.writeString(this.crashTag);
            int iDataPosition = dest.dataPosition() - start;
        }

        public void dump(Printer pw, String prefix) {
            pw.println(prefix + "exceptionClassName: " + this.exceptionClassName);
            pw.println(prefix + "exceptionMessage: " + this.exceptionMessage);
            pw.println(prefix + "throwFileName: " + this.throwFileName);
            pw.println(prefix + "throwClassName: " + this.throwClassName);
            pw.println(prefix + "throwMethodName: " + this.throwMethodName);
            pw.println(prefix + "throwLineNumber: " + this.throwLineNumber);
            pw.println(prefix + "stackTrace: " + this.stackTrace);
        }
    }

    public static class ParcelableCrashInfo extends CrashInfo implements Parcelable {
        public static final Parcelable.Creator<ParcelableCrashInfo> CREATOR = new Parcelable.Creator<ParcelableCrashInfo>() { // from class: android.app.ApplicationErrorReport.ParcelableCrashInfo.1
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public ParcelableCrashInfo createFromParcel(Parcel in) {
                return new ParcelableCrashInfo(in);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public ParcelableCrashInfo[] newArray(int size) {
                return new ParcelableCrashInfo[size];
            }
        };

        public ParcelableCrashInfo() {
        }

        public ParcelableCrashInfo(Throwable tr) {
            super(tr);
        }

        public ParcelableCrashInfo(Parcel in) {
            super(in);
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }
    }

    public static class AnrInfo {
        public String activity;
        public String cause;
        public String info;

        public AnrInfo() {
        }

        public AnrInfo(Parcel in) {
            this.activity = in.readString();
            this.cause = in.readString();
            this.info = in.readString();
        }

        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.activity);
            dest.writeString(this.cause);
            dest.writeString(this.info);
        }

        public void dump(Printer pw, String prefix) {
            pw.println(prefix + "activity: " + this.activity);
            pw.println(prefix + "cause: " + this.cause);
            pw.println(prefix + "info: " + this.info);
        }
    }

    public static class BatteryInfo {
        public String checkinDetails;
        public long durationMicros;
        public String usageDetails;
        public int usagePercent;

        public BatteryInfo() {
        }

        public BatteryInfo(Parcel in) {
            this.usagePercent = in.readInt();
            this.durationMicros = in.readLong();
            this.usageDetails = in.readString();
            this.checkinDetails = in.readString();
        }

        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(this.usagePercent);
            dest.writeLong(this.durationMicros);
            dest.writeString(this.usageDetails);
            dest.writeString(this.checkinDetails);
        }

        public void dump(Printer pw, String prefix) {
            pw.println(prefix + "usagePercent: " + this.usagePercent);
            pw.println(prefix + "durationMicros: " + this.durationMicros);
            pw.println(prefix + "usageDetails: " + this.usageDetails);
            pw.println(prefix + "checkinDetails: " + this.checkinDetails);
        }
    }

    public static class RunningServiceInfo {
        public long durationMillis;
        public String serviceDetails;

        public RunningServiceInfo() {
        }

        public RunningServiceInfo(Parcel in) {
            this.durationMillis = in.readLong();
            this.serviceDetails = in.readString();
        }

        public void writeToParcel(Parcel dest, int flags) {
            dest.writeLong(this.durationMillis);
            dest.writeString(this.serviceDetails);
        }

        public void dump(Printer pw, String prefix) {
            pw.println(prefix + "durationMillis: " + this.durationMillis);
            pw.println(prefix + "serviceDetails: " + this.serviceDetails);
        }
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public void dump(Printer pw, String prefix) {
        pw.println(prefix + "type: " + this.type);
        pw.println(prefix + "packageName: " + this.packageName);
        pw.println(prefix + "installerPackageName: " + this.installerPackageName);
        pw.println(prefix + "processName: " + this.processName);
        pw.println(prefix + "time: " + this.time);
        pw.println(prefix + "systemApp: " + this.systemApp);
        switch (this.type) {
            case 1:
                this.crashInfo.dump(pw, prefix);
                break;
            case 2:
                this.anrInfo.dump(pw, prefix);
                break;
            case 3:
                this.batteryInfo.dump(pw, prefix);
                break;
            case 5:
                this.runningServiceInfo.dump(pw, prefix);
                break;
        }
    }
}
