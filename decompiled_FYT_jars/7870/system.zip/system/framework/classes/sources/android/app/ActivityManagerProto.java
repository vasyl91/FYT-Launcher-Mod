package android.app;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public final class ActivityManagerProto {
    public static final int UID_OBSERVER_FLAG_ACTIVE = 4;
    public static final int UID_OBSERVER_FLAG_CACHED = 5;
    public static final int UID_OBSERVER_FLAG_CAPABILITY = 6;
    public static final int UID_OBSERVER_FLAG_GONE = 2;
    public static final int UID_OBSERVER_FLAG_IDLE = 3;
    public static final int UID_OBSERVER_FLAG_PROCSTATE = 1;
    public static final int UID_OBSERVER_FLAG_PROC_OOM_ADJ = 7;
}
