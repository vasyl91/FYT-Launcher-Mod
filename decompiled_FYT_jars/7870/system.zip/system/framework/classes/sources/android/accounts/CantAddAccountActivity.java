package android.accounts;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.app.admin.DevicePolicyResources;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.util.function.Supplier;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public class CantAddAccountActivity extends Activity {
    public static final String EXTRA_ERROR_CODE = "android.accounts.extra.ERROR_CODE";

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(17367100);
        TextView view = (TextView) findViewById(16908960);
        String text = ((DevicePolicyManager) getSystemService(DevicePolicyManager.class)).getResources().getString(DevicePolicyResources.Strings.Core.CANT_ADD_ACCOUNT_MESSAGE, new Supplier() { // from class: android.accounts.CantAddAccountActivity$$ExternalSyntheticLambda0
            @Override // java.util.function.Supplier
            public final Object get() {
                return this.f$0.m42lambda$onCreate$0$androidaccountsCantAddAccountActivity();
            }
        });
        view.setText(text);
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$android-accounts-CantAddAccountActivity, reason: not valid java name */
    /* synthetic */ String m42lambda$onCreate$0$androidaccountsCantAddAccountActivity() {
        return getString(17040208);
    }

    public void onCancelButtonClicked(View view) {
        onBackPressed();
    }
}
