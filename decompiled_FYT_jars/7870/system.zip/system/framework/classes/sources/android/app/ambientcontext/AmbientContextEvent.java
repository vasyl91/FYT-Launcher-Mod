package android.app.ambientcontext;

import android.annotation.NonNull;
import android.annotation.SystemApi;
import android.os.Parcel;
import android.os.Parcelable;
import com.android.internal.util.AnnotationValidations;
import com.android.internal.util.Parcelling;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.time.Instant;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
@SystemApi
public final class AmbientContextEvent implements Parcelable {
    public static final Parcelable.Creator<AmbientContextEvent> CREATOR;
    public static final int EVENT_COUGH = 1;
    public static final int EVENT_SNORE = 2;
    public static final int EVENT_UNKNOWN = 0;
    public static final int LEVEL_HIGH = 5;
    public static final int LEVEL_LOW = 1;
    public static final int LEVEL_MEDIUM = 3;
    public static final int LEVEL_MEDIUM_HIGH = 4;
    public static final int LEVEL_MEDIUM_LOW = 2;
    public static final int LEVEL_UNKNOWN = 0;
    static Parcelling<Instant> sParcellingForEndTime;
    static Parcelling<Instant> sParcellingForStartTime;
    private final int mConfidenceLevel;
    private final int mDensityLevel;
    private final Instant mEndTime;
    private final int mEventType;
    private final Instant mStartTime;

    @Retention(RetentionPolicy.SOURCE)
    public @interface Event {
    }

    public @interface EventCode {
    }

    @Retention(RetentionPolicy.SOURCE)
    public @interface Level {
    }

    public @interface LevelValue {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int defaultEventType() {
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static Instant defaultStartTime() {
        return Instant.MIN;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static Instant defaultEndTime() {
        return Instant.MAX;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int defaultConfidenceLevel() {
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int defaultDensityLevel() {
        return 0;
    }

    public static String eventToString(int value) {
        switch (value) {
            case 0:
                return "EVENT_UNKNOWN";
            case 1:
                return "EVENT_COUGH";
            case 2:
                return "EVENT_SNORE";
            default:
                return Integer.toHexString(value);
        }
    }

    public static String levelToString(int value) {
        switch (value) {
            case 0:
                return "LEVEL_UNKNOWN";
            case 1:
                return "LEVEL_LOW";
            case 2:
                return "LEVEL_MEDIUM_LOW";
            case 3:
                return "LEVEL_MEDIUM";
            case 4:
                return "LEVEL_MEDIUM_HIGH";
            case 5:
                return "LEVEL_HIGH";
            default:
                return Integer.toHexString(value);
        }
    }

    AmbientContextEvent(int eventType, Instant startTime, Instant endTime, int confidenceLevel, int densityLevel) {
        this.mEventType = eventType;
        AnnotationValidations.validate(EventCode.class, (Annotation) null, eventType);
        this.mStartTime = startTime;
        AnnotationValidations.validate(NonNull.class, (NonNull) null, startTime);
        this.mEndTime = endTime;
        AnnotationValidations.validate(NonNull.class, (NonNull) null, endTime);
        this.mConfidenceLevel = confidenceLevel;
        AnnotationValidations.validate(LevelValue.class, (Annotation) null, confidenceLevel);
        this.mDensityLevel = densityLevel;
        AnnotationValidations.validate(LevelValue.class, (Annotation) null, densityLevel);
    }

    public int getEventType() {
        return this.mEventType;
    }

    public Instant getStartTime() {
        return this.mStartTime;
    }

    public Instant getEndTime() {
        return this.mEndTime;
    }

    public int getConfidenceLevel() {
        return this.mConfidenceLevel;
    }

    public int getDensityLevel() {
        return this.mDensityLevel;
    }

    public String toString() {
        return "AmbientContextEvent { eventType = " + this.mEventType + ", startTime = " + this.mStartTime + ", endTime = " + this.mEndTime + ", confidenceLevel = " + this.mConfidenceLevel + ", densityLevel = " + this.mDensityLevel + " }";
    }

    static {
        Parcelling<Instant> parcelling = Parcelling.Cache.get(Parcelling.BuiltIn.ForInstant.class);
        sParcellingForStartTime = parcelling;
        if (parcelling == null) {
            sParcellingForStartTime = Parcelling.Cache.put(new Parcelling.BuiltIn.ForInstant());
        }
        Parcelling<Instant> parcelling2 = Parcelling.Cache.get(Parcelling.BuiltIn.ForInstant.class);
        sParcellingForEndTime = parcelling2;
        if (parcelling2 == null) {
            sParcellingForEndTime = Parcelling.Cache.put(new Parcelling.BuiltIn.ForInstant());
        }
        CREATOR = new Parcelable.Creator<AmbientContextEvent>() { // from class: android.app.ambientcontext.AmbientContextEvent.1
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public AmbientContextEvent[] newArray(int size) {
                return new AmbientContextEvent[size];
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public AmbientContextEvent createFromParcel(Parcel in) {
                return new AmbientContextEvent(in);
            }
        };
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.mEventType);
        sParcellingForStartTime.parcel(this.mStartTime, dest, flags);
        sParcellingForEndTime.parcel(this.mEndTime, dest, flags);
        dest.writeInt(this.mConfidenceLevel);
        dest.writeInt(this.mDensityLevel);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    AmbientContextEvent(Parcel in) {
        int eventType = in.readInt();
        Instant startTime = (Instant) sParcellingForStartTime.unparcel(in);
        Instant endTime = (Instant) sParcellingForEndTime.unparcel(in);
        int confidenceLevel = in.readInt();
        int densityLevel = in.readInt();
        this.mEventType = eventType;
        AnnotationValidations.validate(EventCode.class, (Annotation) null, eventType);
        this.mStartTime = startTime;
        AnnotationValidations.validate(NonNull.class, (NonNull) null, startTime);
        this.mEndTime = endTime;
        AnnotationValidations.validate(NonNull.class, (NonNull) null, endTime);
        this.mConfidenceLevel = confidenceLevel;
        AnnotationValidations.validate(LevelValue.class, (Annotation) null, confidenceLevel);
        this.mDensityLevel = densityLevel;
        AnnotationValidations.validate(LevelValue.class, (Annotation) null, densityLevel);
    }

    public static final class Builder {
        private long mBuilderFieldsSet = 0;
        private int mConfidenceLevel;
        private int mDensityLevel;
        private Instant mEndTime;
        private int mEventType;
        private Instant mStartTime;

        public Builder setEventType(int value) {
            checkNotUsed();
            this.mBuilderFieldsSet |= 1;
            this.mEventType = value;
            return this;
        }

        public Builder setStartTime(Instant value) {
            checkNotUsed();
            this.mBuilderFieldsSet |= 2;
            this.mStartTime = value;
            return this;
        }

        public Builder setEndTime(Instant value) {
            checkNotUsed();
            this.mBuilderFieldsSet |= 4;
            this.mEndTime = value;
            return this;
        }

        public Builder setConfidenceLevel(int value) {
            checkNotUsed();
            this.mBuilderFieldsSet |= 8;
            this.mConfidenceLevel = value;
            return this;
        }

        public Builder setDensityLevel(int value) {
            checkNotUsed();
            this.mBuilderFieldsSet |= 16;
            this.mDensityLevel = value;
            return this;
        }

        public AmbientContextEvent build() {
            checkNotUsed();
            long j = this.mBuilderFieldsSet | 32;
            this.mBuilderFieldsSet = j;
            if ((j & 1) == 0) {
                this.mEventType = AmbientContextEvent.defaultEventType();
            }
            if ((this.mBuilderFieldsSet & 2) == 0) {
                this.mStartTime = AmbientContextEvent.defaultStartTime();
            }
            if ((this.mBuilderFieldsSet & 4) == 0) {
                this.mEndTime = AmbientContextEvent.defaultEndTime();
            }
            if ((this.mBuilderFieldsSet & 8) == 0) {
                this.mConfidenceLevel = AmbientContextEvent.defaultConfidenceLevel();
            }
            if ((this.mBuilderFieldsSet & 16) == 0) {
                this.mDensityLevel = AmbientContextEvent.defaultDensityLevel();
            }
            AmbientContextEvent o = new AmbientContextEvent(this.mEventType, this.mStartTime, this.mEndTime, this.mConfidenceLevel, this.mDensityLevel);
            return o;
        }

        private void checkNotUsed() {
            if ((this.mBuilderFieldsSet & 32) != 0) {
                throw new IllegalStateException("This Builder should not be reused. Use a new Builder instance instead");
            }
        }
    }

    @Deprecated
    private void __metadata() {
    }
}
