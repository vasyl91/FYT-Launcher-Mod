package android.animation;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public interface TypeEvaluator<T> {
    T evaluate(float f, T t, T t2);
}
