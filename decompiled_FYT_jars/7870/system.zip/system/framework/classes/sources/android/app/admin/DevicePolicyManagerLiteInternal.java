package android.app.admin;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public interface DevicePolicyManagerLiteInternal {
    void notifyUnsafeOperationStateChanged(DevicePolicySafetyChecker devicePolicySafetyChecker, int i, boolean z);
}
