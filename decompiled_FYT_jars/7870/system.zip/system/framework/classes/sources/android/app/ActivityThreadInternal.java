package android.app;

import android.content.ComponentCallbacks2;
import java.util.ArrayList;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
interface ActivityThreadInternal {
    ArrayList<ComponentCallbacks2> collectComponentCallbacks(boolean z);

    Application getApplication();

    ContextImpl getSystemContext();

    ContextImpl getSystemUiContextNoCreate();

    boolean isCachedProcessState();

    boolean isInDensityCompatMode();
}
