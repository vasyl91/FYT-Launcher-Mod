package android.app;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public final class AlarmManagerProto {
    public static final int ELAPSED_REALTIME = 3;
    public static final int ELAPSED_REALTIME_WAKEUP = 2;
    public static final int RTC = 1;
    public static final int RTC_WAKEUP = 0;
}
