package android.app.admin;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.AppSearchShortcutInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Printer;
import android.util.SparseArray;
import android.util.TypedXmlPullParser;
import android.util.TypedXmlSerializer;
import android.util.Xml;
import com.android.internal.R;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public final class DeviceAdminInfo implements Parcelable {
    public static final Parcelable.Creator<DeviceAdminInfo> CREATOR;
    static final String TAG = "DeviceAdminInfo";
    public static final int USES_ENCRYPTED_STORAGE = 7;
    public static final int USES_POLICY_DISABLE_CAMERA = 8;
    public static final int USES_POLICY_DISABLE_KEYGUARD_FEATURES = 9;
    public static final int USES_POLICY_EXPIRE_PASSWORD = 6;
    public static final int USES_POLICY_FORCE_LOCK = 3;
    public static final int USES_POLICY_LIMIT_PASSWORD = 0;
    public static final int USES_POLICY_RESET_PASSWORD = 2;
    public static final int USES_POLICY_SETS_GLOBAL_PROXY = 5;
    public static final int USES_POLICY_WATCH_LOGIN = 1;
    public static final int USES_POLICY_WIPE_DATA = 4;
    final ActivityInfo mActivityInfo;
    boolean mSupportsTransferOwnership;
    int mUsesPolicies;
    boolean mVisible;
    static ArrayList<PolicyInfo> sPoliciesDisplayOrder = new ArrayList<>();
    static HashMap<String, Integer> sKnownPolicies = new HashMap<>();
    static SparseArray<PolicyInfo> sRevKnownPolicies = new SparseArray<>();

    public static class PolicyInfo {
        public final int description;
        public final int descriptionForSecondaryUsers;
        public final int ident;
        public final int label;
        public final int labelForSecondaryUsers;
        public final String tag;

        public PolicyInfo(int ident, String tag, int label, int description) {
            this(ident, tag, label, description, label, description);
        }

        public PolicyInfo(int ident, String tag, int label, int description, int labelForSecondaryUsers, int descriptionForSecondaryUsers) {
            this.ident = ident;
            this.tag = tag;
            this.label = label;
            this.description = description;
            this.labelForSecondaryUsers = labelForSecondaryUsers;
            this.descriptionForSecondaryUsers = descriptionForSecondaryUsers;
        }
    }

    static {
        sPoliciesDisplayOrder.add(new PolicyInfo(4, "wipe-data", 17041330, 17041319, 17041331, 17041320));
        sPoliciesDisplayOrder.add(new PolicyInfo(2, "reset-password", 17041327, 17041315));
        sPoliciesDisplayOrder.add(new PolicyInfo(0, "limit-password", 17041326, 17041314));
        sPoliciesDisplayOrder.add(new PolicyInfo(1, "watch-login", 17041329, 17041317, 17041329, 17041318));
        sPoliciesDisplayOrder.add(new PolicyInfo(3, "force-lock", 17041325, 17041313));
        sPoliciesDisplayOrder.add(new PolicyInfo(5, "set-global-proxy", 17041328, 17041316));
        sPoliciesDisplayOrder.add(new PolicyInfo(6, "expire-password", 17041324, 17041312));
        sPoliciesDisplayOrder.add(new PolicyInfo(7, "encrypted-storage", 17041323, 17041311));
        sPoliciesDisplayOrder.add(new PolicyInfo(8, "disable-camera", 17041321, 17041309));
        sPoliciesDisplayOrder.add(new PolicyInfo(9, "disable-keyguard-features", 17041322, 17041310));
        for (int i = 0; i < sPoliciesDisplayOrder.size(); i++) {
            PolicyInfo pi = sPoliciesDisplayOrder.get(i);
            sRevKnownPolicies.put(pi.ident, pi);
            sKnownPolicies.put(pi.tag, Integer.valueOf(pi.ident));
        }
        CREATOR = new Parcelable.Creator<DeviceAdminInfo>() { // from class: android.app.admin.DeviceAdminInfo.1
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public DeviceAdminInfo createFromParcel(Parcel source) {
                return new DeviceAdminInfo(source);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public DeviceAdminInfo[] newArray(int size) {
                return new DeviceAdminInfo[size];
            }
        };
    }

    public DeviceAdminInfo(Context context, ResolveInfo resolveInfo) throws XmlPullParserException, IOException {
        this(context, resolveInfo.activityInfo);
    }

    public DeviceAdminInfo(Context context, ActivityInfo activityInfo) throws XmlPullParserException, IOException {
        int type;
        int i;
        int i2;
        this.mActivityInfo = activityInfo;
        PackageManager pm = context.getPackageManager();
        XmlResourceParser parser = null;
        try {
            try {
                XmlResourceParser parser2 = activityInfo.loadXmlMetaData(pm, DeviceAdminReceiver.DEVICE_ADMIN_META_DATA);
                if (parser2 == null) {
                    throw new XmlPullParserException("No android.app.device_admin meta-data");
                }
                Resources res = pm.getResourcesForApplication(activityInfo.applicationInfo);
                AttributeSet attrs = Xml.asAttributeSet(parser2);
                do {
                    type = parser2.next();
                    i = 1;
                    if (type == 1) {
                        break;
                    }
                } while (type != 2);
                String nodeName = parser2.getName();
                if (!"device-admin".equals(nodeName)) {
                    throw new XmlPullParserException("Meta-data does not start with device-admin tag");
                }
                TypedArray sa = res.obtainAttributes(attrs, R.styleable.DeviceAdmin);
                this.mVisible = sa.getBoolean(0, true);
                sa.recycle();
                int outerDepth = parser2.getDepth();
                while (true) {
                    int type2 = parser2.next();
                    if (type2 == i) {
                        break;
                    }
                    int i3 = 3;
                    if (type2 == 3 && parser2.getDepth() <= outerDepth) {
                        break;
                    }
                    if (type2 != 3) {
                        int i4 = 4;
                        if (type2 != 4) {
                            String tagName = parser2.getName();
                            if (tagName.equals("uses-policies")) {
                                int innerDepth = parser2.getDepth();
                                while (true) {
                                    int type3 = parser2.next();
                                    if (type3 == i) {
                                        break;
                                    }
                                    if (type3 == i3 && parser2.getDepth() <= innerDepth) {
                                        break;
                                    }
                                    if (type3 == i3) {
                                        res = res;
                                    } else if (type3 == i4) {
                                        res = res;
                                    } else {
                                        String policyName = parser2.getName();
                                        Integer val = sKnownPolicies.get(policyName);
                                        if (val != null) {
                                            this.mUsesPolicies |= i << val.intValue();
                                        } else {
                                            Log.w(TAG, "Unknown tag under uses-policies of " + getComponent() + ": " + policyName);
                                        }
                                    }
                                    res = res;
                                    i = 1;
                                    i3 = 3;
                                    i4 = 4;
                                }
                                i2 = 1;
                            } else {
                                res = res;
                                if (!tagName.equals("support-transfer-ownership")) {
                                    i2 = 1;
                                } else {
                                    if (parser2.next() != 3) {
                                        throw new XmlPullParserException("support-transfer-ownership tag must be empty.");
                                    }
                                    i2 = 1;
                                    this.mSupportsTransferOwnership = true;
                                }
                            }
                            i = i2;
                            res = res;
                        }
                    }
                    i = i;
                    res = res;
                }
                if (parser2 != null) {
                    parser2.close();
                }
            } catch (PackageManager.NameNotFoundException e) {
                throw new XmlPullParserException("Unable to create context for: " + this.mActivityInfo.packageName);
            }
        } catch (Throwable th) {
            if (0 != 0) {
                parser.close();
            }
            throw th;
        }
    }

    DeviceAdminInfo(Parcel source) {
        this.mActivityInfo = ActivityInfo.CREATOR.createFromParcel(source);
        this.mUsesPolicies = source.readInt();
        this.mSupportsTransferOwnership = source.readBoolean();
    }

    public String getPackageName() {
        return this.mActivityInfo.packageName;
    }

    public String getReceiverName() {
        return this.mActivityInfo.name;
    }

    public ActivityInfo getActivityInfo() {
        return this.mActivityInfo;
    }

    public ComponentName getComponent() {
        return new ComponentName(this.mActivityInfo.packageName, this.mActivityInfo.name);
    }

    public CharSequence loadLabel(PackageManager pm) {
        return this.mActivityInfo.loadLabel(pm);
    }

    public CharSequence loadDescription(PackageManager pm) throws Resources.NotFoundException {
        if (this.mActivityInfo.descriptionRes != 0) {
            return pm.getText(this.mActivityInfo.packageName, this.mActivityInfo.descriptionRes, this.mActivityInfo.applicationInfo);
        }
        throw new Resources.NotFoundException();
    }

    public Drawable loadIcon(PackageManager pm) {
        return this.mActivityInfo.loadIcon(pm);
    }

    public boolean isVisible() {
        return this.mVisible;
    }

    public boolean usesPolicy(int policyIdent) {
        return (this.mUsesPolicies & (1 << policyIdent)) != 0;
    }

    public String getTagForPolicy(int policyIdent) {
        return sRevKnownPolicies.get(policyIdent).tag;
    }

    public boolean supportsTransferOwnership() {
        return this.mSupportsTransferOwnership;
    }

    public ArrayList<PolicyInfo> getUsedPolicies() {
        ArrayList<PolicyInfo> res = new ArrayList<>();
        for (int i = 0; i < sPoliciesDisplayOrder.size(); i++) {
            PolicyInfo pi = sPoliciesDisplayOrder.get(i);
            if (usesPolicy(pi.ident)) {
                res.add(pi);
            }
        }
        return res;
    }

    public void writePoliciesToXml(TypedXmlSerializer out) throws IllegalStateException, IOException, IllegalArgumentException {
        out.attributeInt((String) null, AppSearchShortcutInfo.KEY_FLAGS, this.mUsesPolicies);
    }

    public void readPoliciesFromXml(TypedXmlPullParser parser) throws XmlPullParserException, IOException {
        this.mUsesPolicies = parser.getAttributeInt((String) null, AppSearchShortcutInfo.KEY_FLAGS);
    }

    public void dump(Printer pw, String prefix) {
        pw.println(prefix + "Receiver:");
        this.mActivityInfo.dump(pw, prefix + "  ");
    }

    public String toString() {
        return "DeviceAdminInfo{" + this.mActivityInfo.name + "}";
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        this.mActivityInfo.writeToParcel(dest, flags);
        dest.writeInt(this.mUsesPolicies);
        dest.writeBoolean(this.mSupportsTransferOwnership);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }
}
