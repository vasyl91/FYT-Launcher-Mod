package android.app.admin;

import com.android.internal.os.IResultReceiver;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public interface DevicePolicySafetyChecker {
    int getUnsafeOperationReason(int i);

    boolean isSafeOperation(int i);

    void onFactoryReset(IResultReceiver iResultReceiver);

    default UnsafeStateException newUnsafeStateException(int operation, int reason) {
        return new UnsafeStateException(operation, reason);
    }
}
