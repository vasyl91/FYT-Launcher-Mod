package android.app;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public interface AnrController {
    long getAnrDelayMillis(String str, int i);

    boolean onAnrDelayCompleted(String str, int i);

    void onAnrDelayStarted(String str, int i);
}
