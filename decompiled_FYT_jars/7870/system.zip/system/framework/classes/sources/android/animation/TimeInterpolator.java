package android.animation;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public interface TimeInterpolator {
    float getInterpolation(float f);
}
