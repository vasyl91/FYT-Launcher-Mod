package android.accounts;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public class AuthenticatorException extends AccountsException {
    public AuthenticatorException() {
    }

    public AuthenticatorException(String message) {
        super(message);
    }

    public AuthenticatorException(String message, Throwable cause) {
        super(message, cause);
    }

    public AuthenticatorException(Throwable cause) {
        super(cause);
    }
}
