package android.accounts;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public interface OnAccountsUpdateListener {
    void onAccountsUpdated(Account[] accountArr);
}
