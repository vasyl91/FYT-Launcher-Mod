package android.app.admin;

import java.util.function.ToIntFunction;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public final /* synthetic */ class PreferentialNetworkServiceConfig$$ExternalSyntheticLambda2 implements ToIntFunction {
    @Override // java.util.function.ToIntFunction
    public final int applyAsInt(Object obj) {
        return ((Integer) obj).intValue();
    }
}
