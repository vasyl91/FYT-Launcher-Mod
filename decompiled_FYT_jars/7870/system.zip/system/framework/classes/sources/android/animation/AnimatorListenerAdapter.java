package android.animation;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public abstract class AnimatorListenerAdapter implements Animator.AnimatorListener, Animator.AnimatorPauseListener {
    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationCancel(Animator animation) {
    }

    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animation) {
    }

    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationRepeat(Animator animation) {
    }

    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animation) {
    }

    @Override // android.animation.Animator.AnimatorPauseListener
    public void onAnimationPause(Animator animation) {
    }

    @Override // android.animation.Animator.AnimatorPauseListener
    public void onAnimationResume(Animator animation) {
    }
}
