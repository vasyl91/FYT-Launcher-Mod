package android.app.backup;

import android.os.ParcelFileDescriptor;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public interface BackupHelper {
    void performBackup(ParcelFileDescriptor parcelFileDescriptor, BackupDataOutput backupDataOutput, ParcelFileDescriptor parcelFileDescriptor2);

    void restoreEntity(BackupDataInputStream backupDataInputStream);

    void writeNewStateDescription(ParcelFileDescriptor parcelFileDescriptor);
}
