package android.accounts;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
public class AccountsException extends Exception {
    public AccountsException() {
    }

    public AccountsException(String message) {
        super(message);
    }

    public AccountsException(String message, Throwable cause) {
        super(message, cause);
    }

    public AccountsException(Throwable cause) {
        super(cause);
    }
}
