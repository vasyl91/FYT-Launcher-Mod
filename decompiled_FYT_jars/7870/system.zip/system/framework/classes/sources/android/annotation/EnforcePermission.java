package android.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\framework\classes.dex */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.CLASS)
public @interface EnforcePermission {
    String[] allOf() default {};

    String[] anyOf() default {};

    String value() default "";
}
