package com.android.i18n.phonenumbers;

import java.io.InputStream;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\ext\classes.dex */
public interface MetadataLoader {
    InputStream loadMetadata(String str);
}
