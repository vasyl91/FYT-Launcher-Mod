package com.android.i18n.phonenumbers;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\ext\classes.dex */
interface MetadataSource {
    Phonemetadata.PhoneMetadata getMetadataForNonGeographicalRegion(int i);

    Phonemetadata.PhoneMetadata getMetadataForRegion(String str);
}
