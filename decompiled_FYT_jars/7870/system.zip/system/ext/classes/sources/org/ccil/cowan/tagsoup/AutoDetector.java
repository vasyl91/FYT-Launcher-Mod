package org.ccil.cowan.tagsoup;

import java.io.InputStream;
import java.io.Reader;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\ext\classes.dex */
public interface AutoDetector {
    Reader autoDetectingReader(InputStream inputStream);
}
