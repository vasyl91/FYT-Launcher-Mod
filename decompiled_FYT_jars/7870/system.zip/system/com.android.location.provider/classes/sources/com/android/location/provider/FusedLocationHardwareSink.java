package com.android.location.provider;

import android.annotation.SystemApi;
import android.location.Location;

/* JADX INFO: loaded from: C:\payload\7870_jars\system\com.android.location.provider\classes.dex */
@SystemApi
@Deprecated
public class FusedLocationHardwareSink {
    public void onLocationAvailable(Location[] locations) {
    }

    public void onDiagnosticDataAvailable(String data) {
    }

    public void onCapabilities(int capabilities) {
    }

    public void onStatusChanged(int status) {
    }
}
