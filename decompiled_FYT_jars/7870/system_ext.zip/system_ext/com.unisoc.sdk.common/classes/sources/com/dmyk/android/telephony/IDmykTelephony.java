package com.dmyk.android.telephony;

import android.bluetooth.BluetoothDevice;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\com.unisoc.sdk.common\classes.dex */
public interface IDmykTelephony extends IInterface {
    public static final String DESCRIPTOR = "com.dmyk.android.telephony.IDmykTelephony";

    Uri getAPNContentUri(int i) throws RemoteException;

    String getCdmaImsi(int i) throws RemoteException;

    int getCellId(int i) throws RemoteException;

    int getDataState(int i) throws RemoteException;

    int getSubId(int i) throws RemoteException;

    int getSwitchState(int i) throws RemoteException;

    int getVolteState(int i) throws RemoteException;

    boolean isBluetoothConnected(BluetoothDevice bluetoothDevice) throws RemoteException;

    boolean isInternationalNetworkRoaming(int i) throws RemoteException;

    boolean isServiceStateInService(int i) throws RemoteException;

    int queryLteCtccSimType(int i) throws RemoteException;

    String readMeidFromCsim(int i) throws RemoteException;

    void setVolteState(boolean z, int i) throws RemoteException;

    void writeMeidToCsim(int i, String str) throws RemoteException;

    public static class Default implements IDmykTelephony {
        @Override // com.dmyk.android.telephony.IDmykTelephony
        public int getDataState(int phoneId) throws RemoteException {
            return 0;
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public boolean isInternationalNetworkRoaming(int phoneId) throws RemoteException {
            return false;
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public int getVolteState(int phoneId) throws RemoteException {
            return 0;
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public Uri getAPNContentUri(int phoneId) throws RemoteException {
            return null;
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public int getSubId(int phoneId) throws RemoteException {
            return 0;
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public int getCellId(int phoneId) throws RemoteException {
            return 0;
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public void setVolteState(boolean enabled, int phoneId) throws RemoteException {
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public int queryLteCtccSimType(int phoneId) throws RemoteException {
            return 0;
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public boolean isServiceStateInService(int phoneId) throws RemoteException {
            return false;
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public int getSwitchState(int switchId) throws RemoteException {
            return 0;
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public String getCdmaImsi(int phoneId) throws RemoteException {
            return null;
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public String readMeidFromCsim(int phoneId) throws RemoteException {
            return null;
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public void writeMeidToCsim(int phoneId, String meid) throws RemoteException {
        }

        @Override // com.dmyk.android.telephony.IDmykTelephony
        public boolean isBluetoothConnected(BluetoothDevice bluetoothDevice) throws RemoteException {
            return false;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }
    }

    public static abstract class Stub extends Binder implements IDmykTelephony {
        static final int TRANSACTION_getAPNContentUri = 4;
        static final int TRANSACTION_getCdmaImsi = 11;
        static final int TRANSACTION_getCellId = 6;
        static final int TRANSACTION_getDataState = 1;
        static final int TRANSACTION_getSubId = 5;
        static final int TRANSACTION_getSwitchState = 10;
        static final int TRANSACTION_getVolteState = 3;
        static final int TRANSACTION_isBluetoothConnected = 14;
        static final int TRANSACTION_isInternationalNetworkRoaming = 2;
        static final int TRANSACTION_isServiceStateInService = 9;
        static final int TRANSACTION_queryLteCtccSimType = 8;
        static final int TRANSACTION_readMeidFromCsim = 12;
        static final int TRANSACTION_setVolteState = 7;
        static final int TRANSACTION_writeMeidToCsim = 13;

        public Stub() {
            attachInterface(this, IDmykTelephony.DESCRIPTOR);
        }

        public static IDmykTelephony asInterface(IBinder obj) {
            if (obj == null) {
                return null;
            }
            IInterface iin = obj.queryLocalInterface(IDmykTelephony.DESCRIPTOR);
            if (iin != null && (iin instanceof IDmykTelephony)) {
                return (IDmykTelephony) iin;
            }
            return new Proxy(obj);
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            if (code >= 1 && code <= 16777215) {
                data.enforceInterface(IDmykTelephony.DESCRIPTOR);
            }
            switch (code) {
                case 1598968902:
                    reply.writeString(IDmykTelephony.DESCRIPTOR);
                    return true;
                default:
                    switch (code) {
                        case 1:
                            int _arg0 = data.readInt();
                            data.enforceNoDataAvail();
                            int _result = getDataState(_arg0);
                            reply.writeNoException();
                            reply.writeInt(_result);
                            return true;
                        case 2:
                            int _arg1 = data.readInt();
                            data.enforceNoDataAvail();
                            boolean _result2 = isInternationalNetworkRoaming(_arg1);
                            reply.writeNoException();
                            reply.writeBoolean(_result2);
                            return true;
                        case 3:
                            int _arg2 = data.readInt();
                            data.enforceNoDataAvail();
                            int _result3 = getVolteState(_arg2);
                            reply.writeNoException();
                            reply.writeInt(_result3);
                            return true;
                        case 4:
                            int _arg3 = data.readInt();
                            data.enforceNoDataAvail();
                            Uri _result4 = getAPNContentUri(_arg3);
                            reply.writeNoException();
                            reply.writeTypedObject(_result4, 1);
                            return true;
                        case 5:
                            int _arg4 = data.readInt();
                            data.enforceNoDataAvail();
                            int _result5 = getSubId(_arg4);
                            reply.writeNoException();
                            reply.writeInt(_result5);
                            return true;
                        case 6:
                            int _arg5 = data.readInt();
                            data.enforceNoDataAvail();
                            int _result6 = getCellId(_arg5);
                            reply.writeNoException();
                            reply.writeInt(_result6);
                            return true;
                        case 7:
                            boolean _arg6 = data.readBoolean();
                            int _arg7 = data.readInt();
                            data.enforceNoDataAvail();
                            setVolteState(_arg6, _arg7);
                            reply.writeNoException();
                            return true;
                        case 8:
                            int _arg8 = data.readInt();
                            data.enforceNoDataAvail();
                            int _result7 = queryLteCtccSimType(_arg8);
                            reply.writeNoException();
                            reply.writeInt(_result7);
                            return true;
                        case 9:
                            int _arg9 = data.readInt();
                            data.enforceNoDataAvail();
                            boolean _result8 = isServiceStateInService(_arg9);
                            reply.writeNoException();
                            reply.writeBoolean(_result8);
                            return true;
                        case 10:
                            int _arg10 = data.readInt();
                            data.enforceNoDataAvail();
                            int _result9 = getSwitchState(_arg10);
                            reply.writeNoException();
                            reply.writeInt(_result9);
                            return true;
                        case 11:
                            int _arg11 = data.readInt();
                            data.enforceNoDataAvail();
                            String _result10 = getCdmaImsi(_arg11);
                            reply.writeNoException();
                            reply.writeString(_result10);
                            return true;
                        case 12:
                            int _arg12 = data.readInt();
                            data.enforceNoDataAvail();
                            String _result11 = readMeidFromCsim(_arg12);
                            reply.writeNoException();
                            reply.writeString(_result11);
                            return true;
                        case 13:
                            int _arg13 = data.readInt();
                            String _arg14 = data.readString();
                            data.enforceNoDataAvail();
                            writeMeidToCsim(_arg13, _arg14);
                            reply.writeNoException();
                            return true;
                        case 14:
                            BluetoothDevice _arg15 = (BluetoothDevice) data.readTypedObject(BluetoothDevice.CREATOR);
                            data.enforceNoDataAvail();
                            boolean _result12 = isBluetoothConnected(_arg15);
                            reply.writeNoException();
                            reply.writeBoolean(_result12);
                            return true;
                        default:
                            return super.onTransact(code, data, reply, flags);
                    }
            }
        }

        private static class Proxy implements IDmykTelephony {
            private IBinder mRemote;

            Proxy(IBinder remote) {
                this.mRemote = remote;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return IDmykTelephony.DESCRIPTOR;
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public int getDataState(int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(1, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public boolean isInternationalNetworkRoaming(int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(2, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public int getVolteState(int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(3, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public Uri getAPNContentUri(int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(4, _data, _reply, 0);
                    _reply.readException();
                    Uri _result = (Uri) _reply.readTypedObject(Uri.CREATOR);
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public int getSubId(int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(5, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public int getCellId(int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(6, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public void setVolteState(boolean enabled, int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeBoolean(enabled);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(7, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public int queryLteCtccSimType(int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(8, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public boolean isServiceStateInService(int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(9, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public int getSwitchState(int switchId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(switchId);
                    this.mRemote.transact(10, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public String getCdmaImsi(int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(11, _data, _reply, 0);
                    _reply.readException();
                    String _result = _reply.readString();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public String readMeidFromCsim(int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(12, _data, _reply, 0);
                    _reply.readException();
                    String _result = _reply.readString();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public void writeMeidToCsim(int phoneId, String meid) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    _data.writeString(meid);
                    this.mRemote.transact(13, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.dmyk.android.telephony.IDmykTelephony
            public boolean isBluetoothConnected(BluetoothDevice bluetoothDevice) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IDmykTelephony.DESCRIPTOR);
                    _data.writeTypedObject(bluetoothDevice, 0);
                    this.mRemote.transact(14, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }
        }
    }
}
