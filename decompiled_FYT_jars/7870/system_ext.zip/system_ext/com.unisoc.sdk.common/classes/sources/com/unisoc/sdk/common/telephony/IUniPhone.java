package com.unisoc.sdk.common.telephony;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Message;
import android.os.Parcel;
import android.os.RemoteException;
import android.telephony.CellIdentity;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\com.unisoc.sdk.common\classes.dex */
public interface IUniPhone extends IInterface {
    public static final String DESCRIPTOR = "com.unisoc.sdk.common.telephony.IUniPhone";

    void endAllLiveCalls(String str, String str2) throws RemoteException;

    CellIdentity getCellLocationForPhone(int i, String str, String str2) throws RemoteException;

    boolean getIccFdnEnabledForSubscriber(int i) throws RemoteException;

    String getMsisdnNumber(int i) throws RemoteException;

    String getPnnHomeName(int i, String str, String str2) throws RemoteException;

    boolean isAllDataDisconnected(int i) throws RemoteException;

    boolean isDefaultDataRoamingEnabled(int i) throws RemoteException;

    boolean isTestUsim(int i, String str, String str2) throws RemoteException;

    void setDataRoamingEnabled(int i, boolean z) throws RemoteException;

    boolean setMsisdnNumber(int i, String str, String str2, Message message) throws RemoteException;

    void setRadioPower(int i, boolean z) throws RemoteException;

    void setVendorDataEnabled(int i, boolean z) throws RemoteException;

    public static class Default implements IUniPhone {
        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public boolean setMsisdnNumber(int subId, String alphaTag, String number, Message onComplete) throws RemoteException {
            return false;
        }

        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public void setDataRoamingEnabled(int subid, boolean isEnabled) throws RemoteException {
        }

        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public boolean isDefaultDataRoamingEnabled(int subId) throws RemoteException {
            return false;
        }

        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public void setVendorDataEnabled(int phoneId, boolean enabled) throws RemoteException {
        }

        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public boolean isAllDataDisconnected(int phoneId) throws RemoteException {
            return false;
        }

        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public String getMsisdnNumber(int subId) throws RemoteException {
            return null;
        }

        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public void endAllLiveCalls(String callingPackage, String featureId) throws RemoteException {
        }

        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public String getPnnHomeName(int subId, String callingPkg, String featureId) throws RemoteException {
            return null;
        }

        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public boolean isTestUsim(int phoneId, String callingPackage, String featureId) throws RemoteException {
            return false;
        }

        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public boolean getIccFdnEnabledForSubscriber(int subId) throws RemoteException {
            return false;
        }

        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public CellIdentity getCellLocationForPhone(int phoneId, String callingPkg, String featureId) throws RemoteException {
            return null;
        }

        @Override // com.unisoc.sdk.common.telephony.IUniPhone
        public void setRadioPower(int phoneId, boolean onOff) throws RemoteException {
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }
    }

    public static abstract class Stub extends Binder implements IUniPhone {
        static final int TRANSACTION_endAllLiveCalls = 7;
        static final int TRANSACTION_getCellLocationForPhone = 11;
        static final int TRANSACTION_getIccFdnEnabledForSubscriber = 10;
        static final int TRANSACTION_getMsisdnNumber = 6;
        static final int TRANSACTION_getPnnHomeName = 8;
        static final int TRANSACTION_isAllDataDisconnected = 5;
        static final int TRANSACTION_isDefaultDataRoamingEnabled = 3;
        static final int TRANSACTION_isTestUsim = 9;
        static final int TRANSACTION_setDataRoamingEnabled = 2;
        static final int TRANSACTION_setMsisdnNumber = 1;
        static final int TRANSACTION_setRadioPower = 12;
        static final int TRANSACTION_setVendorDataEnabled = 4;

        public Stub() {
            attachInterface(this, IUniPhone.DESCRIPTOR);
        }

        public static IUniPhone asInterface(IBinder obj) {
            if (obj == null) {
                return null;
            }
            IInterface iin = obj.queryLocalInterface(IUniPhone.DESCRIPTOR);
            if (iin != null && (iin instanceof IUniPhone)) {
                return (IUniPhone) iin;
            }
            return new Proxy(obj);
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            if (code >= 1 && code <= 16777215) {
                data.enforceInterface(IUniPhone.DESCRIPTOR);
            }
            switch (code) {
                case 1598968902:
                    reply.writeString(IUniPhone.DESCRIPTOR);
                    return true;
                default:
                    switch (code) {
                        case 1:
                            int _arg0 = data.readInt();
                            String _arg1 = data.readString();
                            String _arg2 = data.readString();
                            Message _arg3 = (Message) data.readTypedObject(Message.CREATOR);
                            data.enforceNoDataAvail();
                            boolean _result = setMsisdnNumber(_arg0, _arg1, _arg2, _arg3);
                            reply.writeNoException();
                            reply.writeBoolean(_result);
                            return true;
                        case 2:
                            int _arg4 = data.readInt();
                            boolean _arg5 = data.readBoolean();
                            data.enforceNoDataAvail();
                            setDataRoamingEnabled(_arg4, _arg5);
                            reply.writeNoException();
                            return true;
                        case 3:
                            int _arg6 = data.readInt();
                            data.enforceNoDataAvail();
                            boolean _result2 = isDefaultDataRoamingEnabled(_arg6);
                            reply.writeNoException();
                            reply.writeBoolean(_result2);
                            return true;
                        case 4:
                            int _arg7 = data.readInt();
                            boolean _arg8 = data.readBoolean();
                            data.enforceNoDataAvail();
                            setVendorDataEnabled(_arg7, _arg8);
                            reply.writeNoException();
                            return true;
                        case 5:
                            int _arg9 = data.readInt();
                            data.enforceNoDataAvail();
                            boolean _result3 = isAllDataDisconnected(_arg9);
                            reply.writeNoException();
                            reply.writeBoolean(_result3);
                            return true;
                        case 6:
                            int _arg10 = data.readInt();
                            data.enforceNoDataAvail();
                            String _result4 = getMsisdnNumber(_arg10);
                            reply.writeNoException();
                            reply.writeString(_result4);
                            return true;
                        case 7:
                            String _arg11 = data.readString();
                            String _arg12 = data.readString();
                            data.enforceNoDataAvail();
                            endAllLiveCalls(_arg11, _arg12);
                            reply.writeNoException();
                            return true;
                        case 8:
                            int _arg13 = data.readInt();
                            String _arg14 = data.readString();
                            String _arg15 = data.readString();
                            data.enforceNoDataAvail();
                            String _result5 = getPnnHomeName(_arg13, _arg14, _arg15);
                            reply.writeNoException();
                            reply.writeString(_result5);
                            return true;
                        case 9:
                            int _arg16 = data.readInt();
                            String _arg17 = data.readString();
                            String _arg18 = data.readString();
                            data.enforceNoDataAvail();
                            boolean _result6 = isTestUsim(_arg16, _arg17, _arg18);
                            reply.writeNoException();
                            reply.writeBoolean(_result6);
                            return true;
                        case 10:
                            int _arg19 = data.readInt();
                            data.enforceNoDataAvail();
                            boolean _result7 = getIccFdnEnabledForSubscriber(_arg19);
                            reply.writeNoException();
                            reply.writeBoolean(_result7);
                            return true;
                        case 11:
                            int _arg20 = data.readInt();
                            String _arg21 = data.readString();
                            String _arg22 = data.readString();
                            data.enforceNoDataAvail();
                            CellIdentity _result8 = getCellLocationForPhone(_arg20, _arg21, _arg22);
                            reply.writeNoException();
                            reply.writeTypedObject(_result8, 1);
                            return true;
                        case 12:
                            int _arg23 = data.readInt();
                            boolean _arg24 = data.readBoolean();
                            data.enforceNoDataAvail();
                            setRadioPower(_arg23, _arg24);
                            reply.writeNoException();
                            return true;
                        default:
                            return super.onTransact(code, data, reply, flags);
                    }
            }
        }

        private static class Proxy implements IUniPhone {
            private IBinder mRemote;

            Proxy(IBinder remote) {
                this.mRemote = remote;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return IUniPhone.DESCRIPTOR;
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public boolean setMsisdnNumber(int subId, String alphaTag, String number, Message onComplete) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeInt(subId);
                    _data.writeString(alphaTag);
                    _data.writeString(number);
                    _data.writeTypedObject(onComplete, 0);
                    this.mRemote.transact(1, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public void setDataRoamingEnabled(int subid, boolean isEnabled) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeInt(subid);
                    _data.writeBoolean(isEnabled);
                    this.mRemote.transact(2, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public boolean isDefaultDataRoamingEnabled(int subId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeInt(subId);
                    this.mRemote.transact(3, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public void setVendorDataEnabled(int phoneId, boolean enabled) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    _data.writeBoolean(enabled);
                    this.mRemote.transact(4, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public boolean isAllDataDisconnected(int phoneId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    this.mRemote.transact(5, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public String getMsisdnNumber(int subId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeInt(subId);
                    this.mRemote.transact(6, _data, _reply, 0);
                    _reply.readException();
                    String _result = _reply.readString();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public void endAllLiveCalls(String callingPackage, String featureId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeString(callingPackage);
                    _data.writeString(featureId);
                    this.mRemote.transact(7, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public String getPnnHomeName(int subId, String callingPkg, String featureId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeInt(subId);
                    _data.writeString(callingPkg);
                    _data.writeString(featureId);
                    this.mRemote.transact(8, _data, _reply, 0);
                    _reply.readException();
                    String _result = _reply.readString();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public boolean isTestUsim(int phoneId, String callingPackage, String featureId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    _data.writeString(callingPackage);
                    _data.writeString(featureId);
                    this.mRemote.transact(9, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public boolean getIccFdnEnabledForSubscriber(int subId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeInt(subId);
                    this.mRemote.transact(10, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public CellIdentity getCellLocationForPhone(int phoneId, String callingPkg, String featureId) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    _data.writeString(callingPkg);
                    _data.writeString(featureId);
                    this.mRemote.transact(11, _data, _reply, 0);
                    _reply.readException();
                    CellIdentity _result = (CellIdentity) _reply.readTypedObject(CellIdentity.CREATOR);
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.sdk.common.telephony.IUniPhone
            public void setRadioPower(int phoneId, boolean onOff) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(IUniPhone.DESCRIPTOR);
                    _data.writeInt(phoneId);
                    _data.writeBoolean(onOff);
                    this.mRemote.transact(12, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }
        }
    }
}
