package com.unisoc.sdk.common.telephony;

import android.content.Context;
import android.database.Cursor;
import android.os.Message;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemProperties;
import android.telephony.CellIdentity;
import android.telephony.CellLocation;
import android.telephony.SubscriptionManager;
import android.util.Log;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\com.unisoc.sdk.common\classes.dex */
public class UniTelephonyManager {
    public static final String CB_FACILITY_BA_PC = "PC";
    public static final String CB_FACILITY_BA_PC_PUK = "PCP";
    public static final String CB_FACILITY_BA_PN = "PN";
    public static final String CB_FACILITY_BA_PN_PUK = "PNP";
    public static final String CB_FACILITY_BA_PP = "PP";
    public static final String CB_FACILITY_BA_PP_PUK = "PPP";
    public static final String CB_FACILITY_BA_PS = "PS";
    public static final String CB_FACILITY_BA_PS_PUK = "PSP";
    public static final String CB_FACILITY_BA_PU = "PU";
    public static final String CB_FACILITY_BA_PU_PUK = "PUP";
    public static final int DATA_ENABLED_REASON_VENDOR = 5;
    private static final String LTE_INDICATOR = "L";
    private static final String MODEM_CONFIG_PROP = "persist.vendor.radio.modem.config";
    public static final int NETWORK_CLASS_2_G = 1;
    public static final int NETWORK_CLASS_3_G = 2;
    public static final int NETWORK_CLASS_4_G = 3;
    public static final int NETWORK_CLASS_5_G = 4;
    public static final int NETWORK_CLASS_UNKNOWN = 0;
    private static final String NR_INDICATOR = "NR";
    public static final int SIM_STATE_BASE = 12;
    public static final int SIM_STATE_CORPORATE_LOCKED = 16;
    public static final int SIM_STATE_CORPORATE_LOCKED_PUK = 21;
    public static final int SIM_STATE_NETWORKSUBSET_LOCKED = 14;
    public static final int SIM_STATE_NETWORK_LOCKED = 4;
    public static final int SIM_STATE_NETWORK_LOCKED_PUK = 18;
    public static final int SIM_STATE_NETWORK_SUBSET_LOCKED_PUK = 19;
    public static final int SIM_STATE_SERVICEPROVIDER_LOCKED = 15;
    public static final int SIM_STATE_SERVICE_PROVIDER_LOCKED_PUK = 20;
    public static final int SIM_STATE_SIM_LOCKED = 13;
    public static final int SIM_STATE_SIM_LOCKED_PERMANENTLY = 22;
    public static final int SIM_STATE_SIM_LOCKED_PUK = 17;
    private static final String TAG = "UniTelephonyManager";
    public static final int UNLOCK_BASE = 0;
    public static final int UNLOCK_CORPORATE = 5;
    public static final int UNLOCK_CORPORATE_PUK = 10;
    public static final int UNLOCK_NETWORK = 2;
    public static final int UNLOCK_NETWORK_PUK = 7;
    public static final int UNLOCK_NETWORK_SUBSET = 3;
    public static final int UNLOCK_NETWORK_SUBSET_PUK = 8;
    public static final int UNLOCK_SERVICE_PORIVDER = 4;
    public static final int UNLOCK_SERVICE_PORIVDER_PUK = 9;
    public static final int UNLOCK_SIM = 1;
    public static final int UNLOCK_SIM_PUK = 6;
    private static UniTelephonyManager sInstance;
    private Context mContext;

    public UniTelephonyManager(Context context) {
        this(context, Integer.MAX_VALUE);
    }

    public UniTelephonyManager(Context context, int subId) {
        this.mContext = context;
    }

    public static UniTelephonyManager from(Context context) {
        if (sInstance == null) {
            sInstance = new UniTelephonyManager(context);
        }
        return sInstance;
    }

    public boolean isDefaultDataRoamingEnabled(int subId) {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService != null) {
                phoneService.isDefaultDataRoamingEnabled(subId);
                return false;
            }
            return false;
        } catch (RemoteException e) {
            Log.e(TAG, "Error calling IUniPhone#isDefaultDataRoamingEnabled", e);
            return false;
        }
    }

    public void setDataRoamingEnabled(int subId, boolean isEnabled) {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService != null) {
                phoneService.setDataRoamingEnabled(subId, isEnabled);
            }
        } catch (RemoteException e) {
            Log.e(TAG, "Error calling IUniPhone#setDataRoamingEnabled", e);
        }
    }

    public void setVendorDataEnabled(int phoneId, boolean enabled) {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService != null) {
                phoneService.setVendorDataEnabled(phoneId, enabled);
            }
        } catch (RemoteException e) {
            Log.e(TAG, "Error calling IUniPhone#setVendorDataEnabled", e);
        }
    }

    public boolean isAllDataDisconnected(int phoneId) {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService != null) {
                return phoneService.isAllDataDisconnected(phoneId);
            }
            return false;
        } catch (RemoteException e) {
            Log.e(TAG, "Error calling IUniPhone#isAllDataDisconnected", e);
            return false;
        }
    }

    public boolean setMsisdnNumber(int subId, String alphaTag, String number, Message onComplete) {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService == null) {
                return false;
            }
            return phoneService.setMsisdnNumber(subId, alphaTag, number, onComplete);
        } catch (RemoteException ex) {
            Log.e(TAG, "RemoteException setMsisdnNumber", ex);
            return false;
        } catch (NullPointerException ex2) {
            Log.e(TAG, "NullPointerException setMsisdnNumber", ex2);
            return false;
        }
    }

    public static boolean isDeviceSupportLte() {
        String prop = SystemProperties.get(MODEM_CONFIG_PROP, "");
        if (!prop.isEmpty() && prop.toUpperCase().contains(LTE_INDICATOR)) {
            return true;
        }
        return false;
    }

    public String getMsisdnNumber(int subId) {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService == null) {
                return null;
            }
            return phoneService.getMsisdnNumber(subId);
        } catch (RemoteException ex) {
            Log.e(TAG, "RemoteException getMsisdnNumber", ex);
            return null;
        } catch (NullPointerException ex2) {
            Log.e(TAG, "NullPointerException getMsisdnNumber", ex2);
            return null;
        }
    }

    public void endAllLiveCalls() {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService != null) {
                phoneService.endAllLiveCalls(this.mContext.getOpPackageName(), this.mContext.getAttributionTag());
            }
        } catch (RemoteException ex) {
            log("RemoteException ex =" + ex);
        } catch (NullPointerException ex2) {
            log("NullPointerException ex =" + ex2);
        }
    }

    public boolean isTestUsim(int phoneId) {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService == null) {
                return false;
            }
            return phoneService.isTestUsim(phoneId, this.mContext.getOpPackageName(), this.mContext.getAttributionTag());
        } catch (RemoteException ex) {
            log("RemoteException ex = " + ex);
            return false;
        } catch (NullPointerException ex2) {
            log("NullPointerException ex = " + ex2);
            return false;
        }
    }

    @Deprecated
    private IUniPhone getIUniPhone() {
        return IUniPhone.Stub.asInterface(ServiceManager.getService("uni_phone"));
    }

    private void log(String message) {
        Log.d(TAG, message);
    }

    public CellLocation getCellLocationForPhone(int phoneId) {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService == null) {
                return null;
            }
            CellIdentity cellIdentity = phoneService.getCellLocationForPhone(phoneId, this.mContext.getOpPackageName(), this.mContext.getAttributionTag());
            CellLocation cl = cellIdentity.asCellLocation();
            if (cl == null || cl.isEmpty()) {
                return null;
            }
            return cl;
        } catch (RemoteException e) {
            return null;
        } catch (NullPointerException e2) {
            return null;
        }
    }

    public int isEnableSubId(int subId) {
        Cursor cursor = this.mContext.getContentResolver().query(SubscriptionManager.CONTENT_URI, null, "_id=?", new String[]{String.valueOf(subId)}, null);
        int enable = -1;
        if (cursor != null) {
            try {
                if (cursor.getCount() > 0) {
                    cursor.moveToFirst();
                    enable = cursor.getInt(cursor.getColumnIndexOrThrow("uicc_applications_enabled"));
                }
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return enable;
    }

    public String getPnnHomeName(int subId) {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService == null) {
                return null;
            }
            return phoneService.getPnnHomeName(subId, this.mContext.getOpPackageName(), this.mContext.getAttributionTag());
        } catch (RemoteException ex) {
            Log.e(TAG, "RemoteException calling getPnnHomeName", ex);
            return null;
        } catch (NullPointerException ex2) {
            Log.e(TAG, "NullPointerException calling getPnnHomeName", ex2);
            return null;
        }
    }

    public static int getNetworkClass(int networkType) {
        switch (networkType) {
            case 1:
            case 2:
            case 4:
            case 7:
            case 11:
            case 16:
                return 1;
            case 3:
            case 5:
            case 6:
            case 8:
            case 9:
            case 10:
            case 12:
            case 14:
            case 15:
            case 17:
                return 2;
            case 13:
            case 18:
            case 19:
                return 3;
            case SIM_STATE_SERVICE_PROVIDER_LOCKED_PUK /* 20 */:
                return 4;
            default:
                return 0;
        }
    }

    public boolean getIccFdnEnabled(int subId) {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService == null) {
                return false;
            }
            return phoneService.getIccFdnEnabledForSubscriber(subId);
        } catch (RemoteException ex) {
            log("RemoteException getIccFdnEnabled" + ex);
            return false;
        } catch (NullPointerException ex2) {
            log("NullPointerException getIccFdnEnabled" + ex2);
            return false;
        }
    }

    public static boolean isDeviceSupportNr() {
        String config = SystemProperties.get(MODEM_CONFIG_PROP, "");
        if (!config.isEmpty() && config.toUpperCase().contains(NR_INDICATOR)) {
            return true;
        }
        return false;
    }

    public static boolean isDeviceSupportDualNr() {
        String[] modemConfigs = SystemProperties.get(MODEM_CONFIG_PROP, "").split(",");
        boolean isMultiSim = !"ssss".equals(SystemProperties.get("persist.radio.multisim.config", "ssss"));
        return modemConfigs.length > 1 && modemConfigs[0].contains(NR_INDICATOR) && modemConfigs[1].contains(NR_INDICATOR) && isMultiSim;
    }

    public void setRadioPower(int phoneId, boolean onOff) {
        try {
            IUniPhone phoneService = getIUniPhone();
            if (phoneService == null) {
                return;
            }
            phoneService.setRadioPower(phoneId, onOff);
        } catch (RemoteException ex) {
            Log.e(TAG, "RemoteException calling setRadioPower", ex);
        } catch (NullPointerException ex2) {
            Log.e(TAG, "NullPointerException calling setRadioPower", ex2);
        }
    }
}
