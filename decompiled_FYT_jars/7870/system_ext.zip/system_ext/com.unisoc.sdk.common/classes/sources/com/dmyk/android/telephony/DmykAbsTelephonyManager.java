package com.dmyk.android.telephony;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import java.util.ArrayList;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\com.unisoc.sdk.common\classes.dex */
public abstract class DmykAbsTelephonyManager {
    public static final String ACTION_5G_STATE_SETTING = "com.dmyk.android.telephony.action.5G_STATE_SETTING";
    public static final String ACTION_APN_STATE_CHANGE = "com.dmyk.android.telephony.action.APN_STATE_CHANGE";
    public static final String ACTION_BATTERY_CHARGE_STATE_CHANGE = "android.dmyk.action.BATTERY_CHARGE_STATE_CHANGE";
    public static final String ACTION_BLUETOOTH_CONNECTIVITY_CHANGE = "android.dmyk.action.BLUETOOTH_CONNECTIVITY_CHANGE";
    public static final String ACTION_CONNECTIVITY_CHANGE = "android.dmyk.net.conn.CONNECTIVITY_CHANGE";
    public static final String ACTION_SIM_STATE_CHANGED = "com.dmyk.android.telephony.action.SIM_STATE_CHANGED";
    public static final String ACTION_VOLTE_STATE_CHANGE = "com.dmyk.android.telephony.action.VOLTE_STATE_CHANGE";
    public static final String ACTION_VOLTE_STATE_SETTING = "com.dmyk.android.telephony.action.VOLTE_STATE_SETTING";
    public static final String BATTERY_TEMPERATURE = "battery_temperature";
    public static final int DATA_CONNECTED = 2;
    public static final int DATA_CONNECTING = 1;
    public static final int DATA_DISCONNECTED = 0;
    public static final int DATA_SUSPENDED = 3;
    public static final int DATA_UNKNOWN = -1;
    public static final int DEVICE_TYPE_BRACELET = 5;
    public static final int DEVICE_TYPE_CELLPHONE = 1;
    public static final int DEVICE_TYPE_PAD = 2;
    public static final int DEVICE_TYPE_STB = 3;
    public static final int DEVICE_TYPE_UNKNOWN = 0;
    public static final int DEVICE_TYPE_WATCH = 4;
    public static final String EXTRA_BATTERY_CHARGE_STATE = "com.dmyk.android.telephony.extra.BATTERY_CHARGE_STATE";
    public static final String EXTRA_SIM_PHONEID = "com.dmyk.android.telephony.extra.SIM_PHONEID";
    public static final String EXTRA_SIM_STATE = "com.dmyk.android.telephony.extra.SIM_STATE";
    public static final int NETWORK_TYPE_1xRTT = 7;
    public static final int NETWORK_TYPE_CDMA = 4;
    public static final int NETWORK_TYPE_EDGE = 2;
    public static final int NETWORK_TYPE_EHRPD = 14;
    public static final int NETWORK_TYPE_EVDO_0 = 5;
    public static final int NETWORK_TYPE_EVDO_A = 6;
    public static final int NETWORK_TYPE_EVDO_B = 12;
    public static final int NETWORK_TYPE_GPRS = 1;
    public static final int NETWORK_TYPE_GSM = 16;
    public static final int NETWORK_TYPE_HSDPA = 8;
    public static final int NETWORK_TYPE_HSPA = 10;
    public static final int NETWORK_TYPE_HSPAP = 15;
    public static final int NETWORK_TYPE_HSUPA = 9;
    public static final int NETWORK_TYPE_IDEN = 11;
    public static final int NETWORK_TYPE_IWLAN = 18;
    public static final int NETWORK_TYPE_LTE = 13;
    public static final int NETWORK_TYPE_LTE_CA = 19;
    public static final int NETWORK_TYPE_TD_SCDMA = 17;
    public static final int NETWORK_TYPE_UMTS = 3;
    public static final int NETWORK_TYPE_UNKNOWN = 0;
    public static final int NR_STATE_OFF = 0;
    public static final int NR_STATE_ON = 1;
    public static final int NR_STATE_UNKNOWN = -1;
    public static final int NR_STATE_UNSUPPORT = 2;
    public static final String PACKAGE_NAME = "com.sprd.opm";
    public static final int SIM_STATE_ABSENT = 1;
    public static final int SIM_STATE_CARD_IO_ERROR = 8;
    public static final int SIM_STATE_LOADED = 10;
    public static final int SIM_STATE_NETWORK_LOCKED = 4;
    public static final int SIM_STATE_NOT_READY = 6;
    public static final int SIM_STATE_PERM_DISABLED = 7;
    public static final int SIM_STATE_PIN_REQUIRED = 2;
    public static final int SIM_STATE_PUK_REQUIRED = 3;
    public static final int SIM_STATE_READY = 5;
    public static final int SIM_STATE_UNKNOWN = 0;
    public static final int SWITCH_AUTO_BRIGHT = 12;
    public static final int SWITCH_BLUETOOTH = 2;
    public static final int SWITCH_FLASH_LIGHT = 8;
    public static final int SWITCH_FLYING = 7;
    public static final int SWITCH_GPRS = 1;
    public static final int SWITCH_GPS = 3;
    public static final int SWITCH_HOT_SPOT = 6;
    public static final int SWITCH_LTE = 11;
    public static final int SWITCH_SCREEN = 9;
    public static final int SWITCH_SCREEN_ROTATE = 10;
    public static final int SWITCH_SHOCK = 4;
    public static final int SWITCH_SILENT = 5;
    public static final int SWITCH_STATE_OFF = 0;
    public static final int SWITCH_STATE_ON = 1;
    public static final int SWITCH_STATE_UNKNOWN = 2;
    public static final int SWITCH_WIFI = 0;
    static final String TAG = "DmykAbsMgr";
    public static final String VOLTE_DMYK_STATE_0 = "volte_dmyk_state_0";
    public static final String VOLTE_DMYK_STATE_1 = "volte_dmyk_state_1";
    public static final int VOLTE_STATE_OFF = 0;
    public static final int VOLTE_STATE_ON = 1;
    public static final int VOLTE_STATE_UNKNOWN = -1;
    protected static DmykAbsTelephonyManager mInstance;
    protected Context mContext;

    public abstract int get5GOpenOrNot(int i);

    public abstract int get5GSW(int i);

    public abstract int get5GSWModem(int i);

    public abstract int get5GState(int i);

    public abstract Uri getAPNContentUri(int i);

    public abstract String getBatteryLevel();

    public abstract String getBatteryTemp();

    public abstract ArrayList<BluetoothInfo> getBluetoothInfo();

    public abstract String getCPUModel();

    public abstract String getCTAModel();

    public abstract String getCdmaDeviceId();

    public abstract String getCdmaImsi(int i);

    public abstract long getCellId(int i);

    public abstract String getCurrentRam();

    public abstract String getCurrentRom();

    public abstract int getDataState(int i);

    public abstract String getDeviceSoftwareVersion();

    public abstract int getDeviceType();

    public abstract String getGsmDeviceId(int i);

    public abstract String getIccId(int i);

    public abstract int getLac(int i);

    public abstract LocationMsg getLocationMsg();

    public abstract String getMacAddress();

    public abstract int getMasterPhoneId();

    public abstract int getMobileSignalIntensity(int i);

    public abstract long getMobileTotalBytes(int i, long j, long j2);

    public abstract String getModel();

    public abstract int getNetworkClass(int i);

    public abstract int getNetworkType(int i);

    public abstract long getNrCellId(int i);

    public abstract String getOSVersion();

    public abstract int getPhoneCount();

    public abstract String getPhoneNumber(int i);

    public abstract int getPriorNetworkType();

    public abstract String getRamStorageSize();

    public abstract String getRomStorageSize();

    public abstract int getSimState(int i);

    public abstract int getSlotId(int i);

    public abstract int getSubId(int i);

    public abstract String getSubscriberId(int i);

    public abstract int getSwitchState(int i);

    public abstract int getVoLTEState(int i);

    public abstract int getWLANState();

    public abstract long getWiFiTotalBytes(long j, long j2);

    public abstract WifiInfo getWifiInfo();

    public abstract int getWlanSignalIntensity();

    public abstract boolean isInternationalNetworkRoaming(int i);

    public abstract boolean isServiceStateInService(int i);

    public abstract int queryLteCtccSimType(int i);

    public abstract String readMeidFromCsim(int i);

    public abstract boolean set5G(int i, int i2);

    public abstract void setNotification(int i, String str);

    public abstract void setVolteState(int i, int i2);

    public abstract void writeMeidToCsim(int i, String str);

    private DmykAbsTelephonyManager() {
        this.mContext = null;
    }

    protected DmykAbsTelephonyManager(Context context) {
        Context appContext = context.getApplicationContext();
        if (appContext != null) {
            this.mContext = appContext;
        } else {
            this.mContext = context;
        }
    }

    public static DmykAbsTelephonyManager getDefault(Context context) {
        synchronized (DmykAbsTelephonyManager.class) {
            if (mInstance == null) {
                mInstance = new DmykImplTelephonyManager(context);
            } else {
                Log.wtf(TAG, "called multiple times!  mInstance = " + mInstance);
            }
        }
        return mInstance;
    }

    public class LocationMsg {
        public int addrFrom;
        public double latitude;
        public double longitude;

        public LocationMsg() {
        }
    }

    public class WifiInfo {
        public String BSSID;
        public String SSID;
        public String WLANName;
        public String wifiMAC;

        public WifiInfo() {
        }
    }

    public class BluetoothInfo {
        public String deviceMAC;
        public String name;
        public String uuid;

        public BluetoothInfo() {
        }
    }
}
