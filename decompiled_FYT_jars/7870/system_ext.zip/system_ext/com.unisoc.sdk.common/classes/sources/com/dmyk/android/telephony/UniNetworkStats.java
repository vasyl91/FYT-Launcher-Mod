package com.dmyk.android.telephony;

import android.app.usage.NetworkStats;
import android.app.usage.NetworkStatsManager;
import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.util.Log;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\com.unisoc.sdk.common\classes.dex */
public class UniNetworkStats extends Handler {
    public static final int METERED_YES = 1;
    private static final String TAG = "UniNetworkStats";
    Context mContext;
    private static Looper sLooper = null;
    private static UniNetworkStats sInstance = null;

    public UniNetworkStats(Looper looper) {
        super(looper);
    }

    public static synchronized UniNetworkStats getInstance() {
        if (sInstance == null) {
            if (sLooper == null) {
                HandlerThread thread = new HandlerThread(TAG);
                thread.start();
                sLooper = thread.getLooper();
            }
            sInstance = new UniNetworkStats(sLooper);
        }
        return sInstance;
    }

    public void init(Context context) {
        this.mContext = context;
    }

    public long getWiFiTotalBytes(long startTime, long endTime) {
        try {
            Log.d(TAG, " getWiFiTotalBytes start do!! ");
            NetworkStatsManager mNetworkStatsManager = (NetworkStatsManager) this.mContext.getSystemService(NetworkStatsManager.class);
            NetworkStats.Bucket ret = mNetworkStatsManager.querySummaryForDevice(1, "", startTime, endTime);
            long wifiTotal = ret.getRxBytes() + ret.getTxBytes();
            Log.d(TAG, "startTimStamp: " + ret.getStartTimeStamp() + ", endTimeStamp: " + ret.getEndTimeStamp());
            Log.d(TAG, " get wifi Bytes = " + wifiTotal + " , startTime =  " + startTime + ",  endTime = " + endTime);
            return wifiTotal;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public long getMobileTotalBytes(int phoneId, long startTime, long endTime) {
        String subscriberId = getSubscriberId(phoneId);
        try {
            if (subscriberId == null) {
                Log.e(TAG, " not insert sim card !!!");
                return 0L;
            }
            Log.d(TAG, " test  mobile start do!! ");
            try {
                NetworkStatsManager mNetworkStatsManager = (NetworkStatsManager) this.mContext.getSystemService(NetworkStatsManager.class);
                NetworkStats.Bucket ret = mNetworkStatsManager.querySummaryForDevice(0, subscriberId, startTime, endTime);
                long mobileBytes = ret.getRxBytes() + ret.getTxBytes();
                Log.d(TAG, "startTimStamp: " + ret.getStartTimeStamp() + ", endTimeStamp: " + ret.getEndTimeStamp());
                Log.d(TAG, " phoneId =  " + phoneId + ", get mobileBytes = " + mobileBytes + " , startTime =  " + startTime + ",  endTime = " + endTime);
                return mobileBytes;
            } catch (Exception e) {
                e = e;
                throw new RuntimeException(e);
            }
        } catch (Exception e2) {
            e = e2;
        }
    }

    private String getSubscriberId(int phoneId) {
        TelephonyManager mTelephonyManager = (TelephonyManager) this.mContext.getSystemService("phone");
        if (mTelephonyManager != null) {
            if (SubscriptionManager.from(this.mContext).getActiveSubscriptionInfoForSimSlotIndex(phoneId) == null) {
                Log.e(TAG, "get subscriberId is null !");
                return null;
            }
            int subId = SubscriptionManager.from(this.mContext).getActiveSubscriptionInfoForSimSlotIndex(phoneId).getSubscriptionId();
            String subscriberId = mTelephonyManager.getSubscriberId(subId);
            return subscriberId;
        }
        Log.d(TAG, "get mTelephonyManager is null !");
        return null;
    }
}
