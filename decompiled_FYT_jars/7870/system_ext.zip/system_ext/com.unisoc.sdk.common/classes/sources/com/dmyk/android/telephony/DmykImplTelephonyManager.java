package com.dmyk.android.telephony;

import android.app.ActivityManager;
import android.app.ActivityThread;
import android.app.usage.StorageStatsManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.res.Resources;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.HandlerThread;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.storage.StorageManager;
import android.provider.Settings;
import android.telephony.CellIdentity;
import android.telephony.CellIdentityCdma;
import android.telephony.CellIdentityGsm;
import android.telephony.CellIdentityLte;
import android.telephony.CellIdentityNr;
import android.telephony.CellIdentityTdscdma;
import android.telephony.CellIdentityWcdma;
import android.telephony.CellInfo;
import android.telephony.CellInfoLte;
import android.telephony.CellInfoNr;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import com.android.internal.telephony.IPhoneSubInfo;
import com.android.internal.telephony.ITelephony;
import com.unisoc.sdk.common.telephony.IUniPhone;
import com.unisoc.sdk.common.telephony.UniTelephonyManager;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\com.unisoc.sdk.common\classes.dex */
public class DmykImplTelephonyManager extends DmykAbsTelephonyManager {
    private static final long BYTES_IN_GIGABYTE = 1000000000;
    private static final long BYTES_IN_KILOBYTE = 1000;
    private static final int DEFAULT_BATTERY_TEMPERATURE = 260;
    public static final int DM_NETWORK_CLASS_2_G = 1;
    public static final int DM_NETWORK_CLASS_3_G = 2;
    public static final int DM_NETWORK_CLASS_4_G = 3;
    public static final int DM_NETWORK_CLASS_5_G = 4;
    public static final int DM_NETWORK_CLASS_UNKNOWN = 0;
    private static final int INVALID_CELLID = -1;
    private static final int INVALID_LAC = -1;
    private static final String MODEM_CONFIG_PROP = "persist.vendor.radio.modem.config";
    private static final String NR_INDICATOR = "NR";
    private static final String TAG = "DmykImplMger";
    private static final long sleepTime = 10000;
    LocationListener locationListener;
    private DmykAbsTelephonyManager.LocationMsg mLocationMsg;
    private static String PROP_CTA_MODEL = "ro.cta.hardware.model";
    private static String PROP_CTA_ROM_SIZE = "ro.cta.hardware.rom.size";
    private static String PROP_CTA_RAM_SIZE = "ro.cta.hardware.ram.size";
    private static String CONFIG_PROP_CTA_MODEL = "cta_model_need_config";
    private static String CONFIG_PROP_CTA_ROM_SIZE = "cta_rom_need_config";
    private static String COMFIG_PROP_CTA_RAM_SIZE = "cta_ram_need_config";

    private enum MultiSimVariants {
        DSDS,
        DSDA,
        TSTS,
        UNKNOWN
    }

    public DmykImplTelephonyManager(Context context) {
        super(context);
        this.locationListener = new LocationListener() { // from class: com.dmyk.android.telephony.DmykImplTelephonyManager.1
            @Override // android.location.LocationListener
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            @Override // android.location.LocationListener
            public void onProviderEnabled(String provider) {
            }

            @Override // android.location.LocationListener
            public void onProviderDisabled(String provider) {
            }

            @Override // android.location.LocationListener
            public void onLocationChanged(Location location) {
                Log.d(DmykImplTelephonyManager.TAG, "locationListener onLocationChanged");
                DmykImplTelephonyManager.this.mLocationMsg.latitude = location.getLatitude();
                DmykImplTelephonyManager.this.mLocationMsg.longitude = location.getLongitude();
            }
        };
        Log.d(TAG, " context =  " + context);
        UniNetworkStats.getInstance().init(context);
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getPhoneCount() {
        Log.d(TAG, " getPhoneCount ");
        int phoneCount = 1;
        switch (AnonymousClass2.$SwitchMap$com$dmyk$android$telephony$DmykImplTelephonyManager$MultiSimVariants[getMultiSimConfiguration().ordinal()]) {
            case 1:
                phoneCount = 1;
                break;
            case 2:
            case 3:
                phoneCount = 2;
                break;
            case 4:
                phoneCount = 3;
                break;
        }
        Log.d(TAG, "getPhoneCount phoneCount = " + phoneCount);
        return phoneCount;
    }

    /* JADX INFO: renamed from: com.dmyk.android.telephony.DmykImplTelephonyManager$2, reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$com$dmyk$android$telephony$DmykImplTelephonyManager$MultiSimVariants;

        static {
            int[] iArr = new int[MultiSimVariants.values().length];
            $SwitchMap$com$dmyk$android$telephony$DmykImplTelephonyManager$MultiSimVariants = iArr;
            try {
                iArr[MultiSimVariants.UNKNOWN.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$dmyk$android$telephony$DmykImplTelephonyManager$MultiSimVariants[MultiSimVariants.DSDS.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$dmyk$android$telephony$DmykImplTelephonyManager$MultiSimVariants[MultiSimVariants.DSDA.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$dmyk$android$telephony$DmykImplTelephonyManager$MultiSimVariants[MultiSimVariants.TSTS.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getGsmDeviceId(int phoneId) {
        ITelephony telephony;
        Log.d(TAG, " getGsmDeviceId  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || (telephony = getITelephony()) == null) {
            return null;
        }
        try {
            return telephony.getImeiForSlot(phoneId, getOpPackageName(), this.mContext.getAttributionTag());
        } catch (RemoteException e) {
            return null;
        } catch (NullPointerException e2) {
            return null;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getCdmaDeviceId() {
        Log.d(TAG, " getCdmaDeviceId ");
        ITelephony telephony = getITelephony();
        if (telephony == null) {
            return null;
        }
        try {
            return telephony.getMeidForSlot(0, getOpPackageName(), this.mContext.getAttributionTag());
        } catch (RemoteException e) {
            return null;
        } catch (NullPointerException e2) {
            return null;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getSubscriberId(int phoneId) {
        int subId;
        IPhoneSubInfo info;
        Log.d(TAG, " getSubscriberId  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || (subId = getSubId(phoneId)) == -1 || (info = getSubscriberInfo()) == null) {
            return null;
        }
        try {
            return info.getSubscriberIdForSubscriber(subId, getOpPackageName(), this.mContext.getAttributionTag());
        } catch (RemoteException e) {
            return null;
        } catch (NullPointerException e2) {
            return null;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getIccId(int phoneId) {
        int subId;
        IPhoneSubInfo info;
        Log.d(TAG, " getIccId  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || (subId = getSubId(phoneId)) == -1 || (info = getSubscriberInfo()) == null) {
            return null;
        }
        try {
            return info.getIccSerialNumberForSubscriber(subId, getOpPackageName(), this.mContext.getAttributionTag());
        } catch (RemoteException e) {
            return null;
        } catch (NullPointerException e2) {
            return null;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getDataState(int phoneId) {
        Log.d(TAG, " getDataState  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId)) {
            Log.d(TAG, " getDataState = DATA_DISCONNECTED_1 ");
            return 0;
        }
        IDmykTelephony dmykTelephony = getIDmykTelephony();
        if (dmykTelephony == null) {
            Log.d(TAG, " getDataState = DATA_DISCONNECTED_2 ");
            return 0;
        }
        try {
            Log.d(TAG, " getDataState");
            return dmykTelephony.getDataState(phoneId);
        } catch (RemoteException e) {
            return 0;
        } catch (NullPointerException e2) {
            return 0;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getSimState(int phoneId) {
        Log.d(TAG, " getSimState  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId)) {
            return 0;
        }
        int simState = SubscriptionManager.getSimStateForSlotIndex(phoneId);
        if (simState == 10) {
            simState = 5;
        }
        Log.d(TAG, " getSimState  simState: " + simState);
        return simState;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getNetworkType(int phoneId) {
        int subId;
        ITelephony telephony;
        Log.d(TAG, " getNetworkType  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || (subId = getSubId(phoneId)) == -1 || (telephony = getITelephony()) == null) {
            return 0;
        }
        try {
            ServiceState serviceState = telephony.getServiceStateForSubscriber(subId, false, false, getOpPackageName(), this.mContext.getAttributionTag());
            if (serviceState.getState() == 0) {
                return telephony.getVoiceNetworkTypeForSubscriber(subId, getOpPackageName(), this.mContext.getAttributionTag());
            }
            if (serviceState.getDataRegState() == 0) {
                return telephony.getDataNetworkTypeForSubscriber(subId, getOpPackageName(), this.mContext.getAttributionTag());
            }
            return 0;
        } catch (RemoteException e) {
            return 0;
        } catch (NullPointerException e2) {
            return 0;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getDeviceSoftwareVersion() {
        Log.d(TAG, " getDeviceSoftwareVersion ");
        return SystemProperties.get("ro.build.display.id", "");
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getDeviceType() {
        Log.d(TAG, " getDeviceType ");
        return 1;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getMasterPhoneId() {
        int currentSysDefaultDataSubId = SystemProperties.getInt("persist.radio.data.subid", SubscriptionManager.getDefaultDataSubscriptionId());
        int masterPhoneId = SubscriptionManager.getPhoneId(currentSysDefaultDataSubId);
        Log.d(TAG, " getMasterPhoneId  masterPhoneId: " + masterPhoneId + "currentSysDefaultDataSubId: " + currentSysDefaultDataSubId);
        return masterPhoneId;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public boolean isInternationalNetworkRoaming(int phoneId) {
        IDmykTelephony dmykTelephony;
        Log.d(TAG, " isInternationalNetworkRoaming  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || (dmykTelephony = getIDmykTelephony()) == null) {
            return false;
        }
        try {
            return dmykTelephony.isInternationalNetworkRoaming(phoneId);
        } catch (RemoteException e) {
            return false;
        } catch (NullPointerException e2) {
            return false;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getVoLTEState(int phoneId) {
        IDmykTelephony dmykTelephony;
        Log.d(TAG, " getVoLTEState  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || (dmykTelephony = getIDmykTelephony()) == null) {
            return -1;
        }
        try {
            return dmykTelephony.getVolteState(phoneId);
        } catch (RemoteException e) {
            return -1;
        } catch (NullPointerException e2) {
            return -1;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public Uri getAPNContentUri(int phoneId) {
        IDmykTelephony dmykTelephony;
        Log.d(TAG, " getAPNContentUri  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || (dmykTelephony = getIDmykTelephony()) == null) {
            return null;
        }
        try {
            return dmykTelephony.getAPNContentUri(phoneId);
        } catch (RemoteException e) {
            return null;
        } catch (NullPointerException e2) {
            return null;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getSlotId(int phoneId) {
        Log.d(TAG, " getSlotId ");
        if (!SubscriptionManager.isValidPhoneId(phoneId)) {
            return -1;
        }
        return phoneId;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getSubId(int phoneId) {
        IDmykTelephony dmykTelephony;
        Log.d(TAG, " getSubId  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || (dmykTelephony = getIDmykTelephony()) == null) {
            return -1;
        }
        try {
            return dmykTelephony.getSubId(phoneId);
        } catch (RemoteException e) {
            return -1;
        } catch (NullPointerException e2) {
            return -1;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public long getCellId(int phoneId) {
        IDmykTelephony dmykTelephony;
        int subId;
        Log.d(TAG, " getCellId  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || (dmykTelephony = getIDmykTelephony()) == null || (subId = getSubId(phoneId)) == -1) {
            return -1L;
        }
        TelephonyManager tm = ((TelephonyManager) this.mContext.getSystemService(TelephonyManager.class)).createForSubscriptionId(subId);
        ServiceState serviceState = tm.getServiceStateForSubscriber(subId);
        if (serviceState != null && serviceState.getDataRegState() == 0 && serviceState.getDataNetworkType() == 20) {
            Log.d(TAG, "NetworkUtils is InNrService");
            return getNrCellId(phoneId);
        }
        try {
            Long longCellId = new Long(dmykTelephony.getCellId(phoneId));
            return longCellId.longValue();
        } catch (RemoteException e) {
            return -1L;
        } catch (NullPointerException e2) {
            return -1L;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getLac(int phoneId) {
        Log.d(TAG, " getLac phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId)) {
            Log.d(TAG, " getLac inValidPhoneId");
            return -1;
        }
        IUniPhone uniPhone = getIUniPhone();
        if (uniPhone == null) {
            Log.d(TAG, " getLac uniPhone is null");
            return -1;
        }
        int subId = getSubId(phoneId);
        if (subId == -1) {
            Log.d(TAG, " getLac invalid subscription ID");
            return -1;
        }
        TelephonyManager tm = TelephonyManager.from(this.mContext);
        if (tm.getCurrentPhoneTypeForSlot(phoneId) == 1) {
            try {
                CellIdentity cellIdentity = uniPhone.getCellLocationForPhone(phoneId, getOpPackageName(), this.mContext.getAttributionTag());
                if (cellIdentity != null) {
                    int lac = getLacFromCellIdentity(cellIdentity);
                    Log.d(TAG, " getLac lac: " + lac);
                    return lac;
                }
            } catch (RemoteException e) {
            } catch (NullPointerException e2) {
            }
        } else if (tm.getCurrentPhoneTypeForSlot(phoneId) == 2) {
            ServiceState serviceState = tm.getServiceStateForSubscriber(subId);
            if (serviceState != null && serviceState.getDataRegState() == 0 && serviceState.getDataNetworkType() == 13) {
                List<CellInfo> cellInfoList = tm.getAllCellInfo();
                if (cellInfoList != null && cellInfoList.size() > 0) {
                    for (CellInfo c : cellInfoList) {
                        if (c.isRegistered() && (c instanceof CellInfoLte)) {
                            int tac = ((CellInfoLte) c).getCellIdentity().getTac();
                            Log.d(TAG, "phone type is cdma  lac: " + tac);
                            return tac;
                        }
                    }
                }
            } else {
                try {
                    CellIdentity cellIdentity2 = uniPhone.getCellLocationForPhone(phoneId, getOpPackageName(), this.mContext.getAttributionTag());
                    if (cellIdentity2 != null && cellIdentity2.getType() == 2) {
                        int networkId = ((CellIdentityCdma) cellIdentity2).getNetworkId();
                        Log.d(TAG, "getNetworkId networkId: " + networkId);
                        return networkId;
                    }
                } catch (RemoteException e3) {
                } catch (NullPointerException e4) {
                }
            }
        }
        return -1;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getPriorNetworkType() {
        Log.d(TAG, " getPriorNetworkType ");
        int type = Resources.getSystem().getInteger(134807559);
        return type;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public void setVolteState(int phoneId, int value) {
        IDmykTelephony dmykTelephony;
        Log.d(TAG, " setVolteState  phoneId: " + phoneId + " value: " + value);
        if (SubscriptionManager.isValidPhoneId(phoneId) && (dmykTelephony = getIDmykTelephony()) != null) {
            try {
                dmykTelephony.setVolteState(value == 1, phoneId);
            } catch (RemoteException e) {
            } catch (NullPointerException e2) {
            }
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int queryLteCtccSimType(int phoneId) {
        IDmykTelephony dmykTelephony;
        Log.d(TAG, " queryLteCtccSimType  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || (dmykTelephony = getIDmykTelephony()) == null) {
            return -1;
        }
        try {
            return dmykTelephony.queryLteCtccSimType(phoneId);
        } catch (RemoteException e) {
            return -1;
        } catch (NullPointerException e2) {
            return -1;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public boolean isServiceStateInService(int phoneId) {
        IDmykTelephony dmykTelephony;
        Log.d(TAG, " isServiceStateInService  phoneId: " + phoneId);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || (dmykTelephony = getIDmykTelephony()) == null) {
            return false;
        }
        try {
            return dmykTelephony.isServiceStateInService(phoneId);
        } catch (RemoteException e) {
            return false;
        } catch (NullPointerException e2) {
            return false;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getCTAModel() {
        String model = SystemProperties.get(PROP_CTA_MODEL);
        Log.d(TAG, "getCTAModel = " + model);
        if (model.isEmpty()) {
            return CONFIG_PROP_CTA_MODEL;
        }
        return model;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getRomStorageSize() {
        String romSize = SystemProperties.get(PROP_CTA_ROM_SIZE);
        Log.d(TAG, "getRomStorageSize = " + romSize);
        if (romSize.isEmpty()) {
            return CONFIG_PROP_CTA_ROM_SIZE;
        }
        return romSize;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getRamStorageSize() {
        String ramSize = SystemProperties.get(PROP_CTA_RAM_SIZE);
        Log.d(TAG, "getRamStorageSize = " + ramSize);
        if (ramSize.isEmpty()) {
            return COMFIG_PROP_CTA_RAM_SIZE;
        }
        return ramSize;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getMacAddress() {
        WifiManager wifiManager = (WifiManager) this.mContext.getSystemService("wifi");
        if (wifiManager == null) {
            return null;
        }
        int wifiState = wifiManager.getWifiState();
        Log.d(TAG, "getMacAddress wifiState = " + wifiState);
        if (3 != wifiState) {
            return null;
        }
        String macAddress = null;
        String[] macAddresses = wifiManager.getFactoryMacAddresses();
        if (macAddresses != null && macAddresses.length > 0) {
            macAddress = macAddresses[0];
        }
        Log.d(TAG, "getMacAddress = " + macAddress);
        if (TextUtils.isEmpty(macAddress)) {
            return null;
        }
        return macAddress;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getCPUModel() {
        String str;
        try {
            str = getCpuHardwareByFile();
            if (TextUtils.isEmpty(str)) {
                str = Build.HARDWARE;
            }
        } catch (Exception e) {
            str = Build.HARDWARE;
        }
        Log.d(TAG, "getCPUModel  = " + str);
        return str;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getOSVersion() {
        return Build.VERSION.RELEASE;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getModel() {
        return Build.MODEL;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public boolean set5G(int phoneId, int state) {
        int networkType;
        int subId = getSubId(phoneId);
        TelephonyManager tm = new TelephonyManager(this.mContext, subId);
        long supportedRadioBitmask = tm.getSupportedRadioAccessFamily();
        boolean checkSupportedRadioBitmask = (524288 & supportedRadioBitmask) > 0;
        if (!checkSupportedRadioBitmask || subId == -1) {
            return false;
        }
        if (state == 1) {
            networkType = 26;
        } else {
            networkType = 9;
        }
        if (!tm.setPreferredNetworkType(subId, networkType)) {
            return false;
        }
        Log.d(TAG, "successfully to set networkmode");
        return true;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int get5GState(int phoneId) {
        int subId = getSubId(phoneId);
        TelephonyManager tm = new TelephonyManager(this.mContext, subId);
        long supportedRadioBitmask = tm.getSupportedRadioAccessFamily();
        boolean checkSupportedRadioBitmask = (524288 & supportedRadioBitmask) > 0;
        if (!checkSupportedRadioBitmask || subId == -1) {
            return -1;
        }
        int networkType = tm.getPreferredNetworkType(subId);
        return networkType == 26 ? 1 : 0;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int get5GSW(int phoneId) {
        if (!SubscriptionManager.isValidPhoneId(phoneId)) {
            return -1;
        }
        boolean isMultiSim = !"ssss".equals(SystemProperties.get("persist.radio.multisim.config", "ssss"));
        if (isMultiSim) {
            Log.d(TAG, "multi sim, get5GSW.");
            int subId = getSubId(phoneId);
            if (!SubscriptionManager.isValidSubscriptionId(subId)) {
                Log.d(TAG, "multi sim, subid is not valid.");
                return -1;
            }
            TelephonyManager tm = new TelephonyManager(this.mContext, subId);
            long supportedRadioBitmask = tm.getSupportedRadioAccessFamily();
            Log.d(TAG, "multi sim, get5GSW. phoneId:" + phoneId + ", subId: " + subId + ", supportedRadioBitmask: " + supportedRadioBitmask);
            boolean checkSupportedRadioBitmask = (524288 & supportedRadioBitmask) > 0;
            if (!checkSupportedRadioBitmask) {
                return 2;
            }
            return get5GOpenOrNot(phoneId);
        }
        Log.d(TAG, "single sim, get5GSW.");
        String config = SystemProperties.get(MODEM_CONFIG_PROP, "");
        if (config.isEmpty() || !config.toUpperCase().contains(NR_INDICATOR)) {
            return 2;
        }
        return get5GOpenOrNot(phoneId);
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int get5GSWModem(int phoneId) {
        if (!SubscriptionManager.isValidPhoneId(phoneId)) {
            return -1;
        }
        boolean isMultiSim = !"ssss".equals(SystemProperties.get("persist.radio.multisim.config", "ssss"));
        if (isMultiSim) {
            Log.d(TAG, "multi sim, get5GSW.");
            String[] modemConfigs = SystemProperties.get(MODEM_CONFIG_PROP, "").split(",");
            if (modemConfigs.length <= phoneId || !modemConfigs[phoneId].contains(NR_INDICATOR)) {
                return 2;
            }
            return get5GOpenOrNot(phoneId);
        }
        Log.d(TAG, "single sim, get5GSW.");
        String config = SystemProperties.get(MODEM_CONFIG_PROP, "");
        if (config.isEmpty() || !config.toUpperCase().contains(NR_INDICATOR)) {
            return 2;
        }
        return get5GOpenOrNot(phoneId);
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int get5GOpenOrNot(int phoneId) {
        int subId = getSubId(phoneId);
        if (subId == -1) {
            return -1;
        }
        TelephonyManager tm = new TelephonyManager(this.mContext, subId);
        int networkType = tm.getPreferredNetworkType(subId);
        Log.d(TAG, "get5GOpenOrNot, phoneId: " + phoneId + ", subId: " + subId);
        int state = networkType == 26 ? 1 : 0;
        Log.d(TAG, "get5GOpenOrNot, networkType: " + networkType + ", state: " + state);
        return state;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getMobileSignalIntensity(int phoneId) {
        int subId = getSubId(phoneId);
        int simState = getSimState(phoneId);
        Log.d(TAG, "getMobileSignalIntensity phoneId : " + phoneId + ", subId: " + subId);
        if (simState == 1 || simState == 0 || !SubscriptionManager.isValidSubscriptionId(subId)) {
            return 0;
        }
        TelephonyManager tm = new TelephonyManager(this.mContext, subId);
        SignalStrength ssh = tm.getSignalStrength();
        int signalDbm = ssh.getDbm();
        Log.d(TAG, "getMobileSignalIntensity signalDbm: " + signalDbm);
        long supportedRadioBitmask = tm.getSupportedRadioAccessFamily();
        boolean checkSupportedRadioBitmask = (524288 & supportedRadioBitmask) > 0;
        int dataNetworkType = tm.getDataNetworkType(subId);
        Log.d(TAG, "updateSignalStrength dataNetworkType : " + dataNetworkType);
        if (checkSupportedRadioBitmask && 20 == dataNetworkType) {
            int signalNrDbm = ssh.getNrDbm();
            Log.d(TAG, "signalNrDbm : " + signalNrDbm);
            return signalNrDbm;
        }
        return signalDbm;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public long getWiFiTotalBytes(long startTime, long endTime) {
        Log.d(TAG, "getWiFiTotalBytes startTime: " + startTime + ", endTime: " + endTime);
        long wifiTotalBytes = UniNetworkStats.getInstance().getWiFiTotalBytes(startTime, endTime);
        Log.d(TAG, "getWiFiTotalBytes wifiTotalBytes: " + wifiTotalBytes);
        return wifiTotalBytes;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public long getMobileTotalBytes(int phoneId, long startTime, long endTime) {
        Log.d(TAG, "getMobileTotalBytes startTime: " + startTime + ", endTime: " + endTime + ", phoneId: " + phoneId);
        long mobileTotalBytes = UniNetworkStats.getInstance().getMobileTotalBytes(phoneId, startTime, endTime);
        Log.d(TAG, "getMobileTotalBytes mobileTotalBytes: " + mobileTotalBytes);
        return mobileTotalBytes;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getPhoneNumber(int phoneId) {
        Log.d(TAG, " getPhoneNumber  phoneId: " + phoneId);
        String number = null;
        int subId = getSubId(phoneId);
        Log.d(TAG, "getPhoneNumber subId: " + subId);
        if (subId == -1) {
            return null;
        }
        try {
            ITelephony telephony = getITelephony();
            if (telephony != null) {
                number = telephony.getLine1NumberForDisplay(subId, getOpPackageName(), this.mContext.getAttributionTag());
            }
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
        if (number != null) {
            return number;
        }
        try {
            IPhoneSubInfo info = getSubscriberInfo();
            if (info == null) {
                return null;
            }
            return info.getLine1NumberForSubscriber(subId, getOpPackageName(), this.mContext.getAttributionTag());
        } catch (RemoteException e3) {
            return null;
        } catch (NullPointerException e4) {
            return null;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getSwitchState(int switchId) {
        Log.d(TAG, " getSwitchState  switchId: " + switchId);
        IDmykTelephony dmykTelephony = getIDmykTelephony();
        if (dmykTelephony == null) {
            return 2;
        }
        try {
            return dmykTelephony.getSwitchState(switchId);
        } catch (RemoteException e) {
            return 2;
        } catch (NullPointerException e2) {
            return 2;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public DmykAbsTelephonyManager.LocationMsg getLocationMsg() {
        Log.d(TAG, "getLocationMsg Enter");
        DmykAbsTelephonyManager.LocationMsg locationMsg = new DmykAbsTelephonyManager.LocationMsg();
        this.mLocationMsg = locationMsg;
        locationMsg.latitude = Double.MAX_VALUE;
        this.mLocationMsg.longitude = Double.MAX_VALUE;
        this.mLocationMsg.addrFrom = 0;
        LocationManager locationManager = (LocationManager) this.mContext.getSystemService("location");
        if (locationManager == null) {
            Log.d(TAG, "getLocationMsg locationManager null");
            return this.mLocationMsg;
        }
        if (!locationManager.isProviderEnabled("gps")) {
            Log.d(TAG, "getLocationMsg GPS off, just return default value");
            return this.mLocationMsg;
        }
        HandlerThread handlerThread = new HandlerThread("getLocation");
        handlerThread.start();
        try {
            locationManager.requestSingleUpdate("gps", this.locationListener, handlerThread.getLooper());
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d(TAG, "getLocationMsg sleep 10s");
        SystemClock.sleep(sleepTime);
        locationManager.removeUpdates(this.locationListener);
        handlerThread.quit();
        Log.d(TAG, "getLocationMsg latitude: " + this.mLocationMsg.latitude + ", longitude: " + this.mLocationMsg.longitude + ", addrFrom: " + this.mLocationMsg.addrFrom);
        return this.mLocationMsg;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getCdmaImsi(int phoneId) {
        try {
            IDmykTelephony dmykTelephony = getIDmykTelephony();
            if (dmykTelephony != null) {
                return dmykTelephony.getCdmaImsi(phoneId);
            }
            return null;
        } catch (RemoteException e) {
            return null;
        } catch (NullPointerException e2) {
            return null;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String readMeidFromCsim(int phoneId) {
        try {
            IDmykTelephony dmykTelephony = getIDmykTelephony();
            if (dmykTelephony != null) {
                return dmykTelephony.readMeidFromCsim(phoneId);
            }
            return null;
        } catch (RemoteException e) {
            return null;
        } catch (NullPointerException e2) {
            return null;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public void writeMeidToCsim(int phoneId, String meid) {
        try {
            IDmykTelephony dmykTelephony = getIDmykTelephony();
            if (dmykTelephony != null) {
                dmykTelephony.writeMeidToCsim(phoneId, meid);
            }
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    private MultiSimVariants getMultiSimConfiguration() {
        String mSimConfig = SystemProperties.get("persist.radio.multisim.config");
        if (mSimConfig.equals("dsds")) {
            return MultiSimVariants.DSDS;
        }
        if (mSimConfig.equals("dsda")) {
            return MultiSimVariants.DSDA;
        }
        if (mSimConfig.equals("tsts")) {
            return MultiSimVariants.TSTS;
        }
        return MultiSimVariants.UNKNOWN;
    }

    private IPhoneSubInfo getSubscriberInfo() {
        return IPhoneSubInfo.Stub.asInterface(ServiceManager.getService("iphonesubinfo"));
    }

    private String getOpPackageName() {
        if (this.mContext != null) {
            return this.mContext.getOpPackageName();
        }
        return ActivityThread.currentOpPackageName();
    }

    private ITelephony getITelephony() {
        return ITelephony.Stub.asInterface(ServiceManager.getService("phone"));
    }

    private IUniPhone getIUniPhone() {
        return IUniPhone.Stub.asInterface(ServiceManager.getService("uni_phone"));
    }

    private IDmykTelephony getIDmykTelephony() {
        return IDmykTelephony.Stub.asInterface(ServiceManager.getService("phone_dmyk"));
    }

    private static String getCpuHardwareByFile() {
        HashMap localHashMap = new HashMap();
        Scanner localScanner = null;
        try {
            try {
                localScanner = new Scanner(new File("/proc/cpuinfo"), StandardCharsets.UTF_8.toString());
                while (localScanner.hasNextLine()) {
                    String[] arrayOfString = localScanner.nextLine().split(": ");
                    if (arrayOfString.length > 1) {
                        localHashMap.put(arrayOfString[0].trim(), arrayOfString[1].trim());
                    }
                }
            } catch (Exception localException) {
                localException.printStackTrace();
                if (localScanner != null) {
                }
                return (String) localHashMap.get("Hardware");
            }
            localScanner.close();
            return (String) localHashMap.get("Hardware");
        } catch (Throwable th) {
            if (localScanner != null) {
                localScanner.close();
            }
            throw th;
        }
    }

    private static int getLacFromCellIdentity(CellIdentity id) {
        if (id == null) {
            return -1;
        }
        int lac = -1;
        switch (id.getType()) {
            case 1:
                lac = ((CellIdentityGsm) id).getLac();
                break;
            case 3:
                lac = ((CellIdentityLte) id).getTac();
                break;
            case 4:
                lac = ((CellIdentityWcdma) id).getLac();
                break;
            case 5:
                lac = ((CellIdentityTdscdma) id).getLac();
                break;
            case 6:
                lac = ((CellIdentityNr) id).getTac();
                break;
        }
        if (lac == Integer.MAX_VALUE) {
            return -1;
        }
        return lac;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public long getNrCellId(int phoneId) {
        int subId;
        TelephonyManager tm;
        ServiceState serviceState;
        Log.d(TAG, "getNrCellId phoneId = " + phoneId);
        int simState = getSimState(phoneId);
        if (simState != 1 && simState != 0 && (subId = getSubId(phoneId)) != -1 && (serviceState = (tm = new TelephonyManager(this.mContext, subId)).getServiceStateForSubscriber(subId)) != null && serviceState.getDataRegState() == 0 && serviceState.getDataNetworkType() == 20) {
            List<CellInfo> cellInfoList = tm.getAllCellInfo();
            List<CellInfo> regCells = new ArrayList<>();
            CellInfo regCell = null;
            for (int index = 0; index < cellInfoList.size(); index++) {
                CellInfo c = cellInfoList.get(index);
                if (c != null && c.isRegistered()) {
                    regCells.add(c);
                }
            }
            int index2 = regCells.size();
            if (index2 == 1) {
                CellInfo regCell2 = regCells.get(0);
                regCell = regCell2;
            } else if (regCells.size() == 2) {
                CellInfo regCell3 = regCells.get(phoneId);
                regCell = regCell3;
            }
            if (regCell != null && (regCell instanceof CellInfoNr)) {
                CellInfoNr cellInfoNr = (CellInfoNr) regCell;
                CellIdentityNr cellIdentitynr = (CellIdentityNr) cellInfoNr.getCellIdentity();
                long nrCellId = cellIdentitynr.getNci();
                Log.d(TAG, " nrCellId = " + nrCellId);
                return nrCellId;
            }
        }
        return -1L;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getNetworkClass(int phoneId) {
        Log.d(TAG, "getNetworkClass phoneId = " + phoneId);
        int subId = getSubId(phoneId);
        if (!SubscriptionManager.isValidSubscriptionId(subId)) {
            return 0;
        }
        TelephonyManager tm = new TelephonyManager(this.mContext, subId);
        ServiceState serviceState = tm.getServiceStateForSubscriber(subId);
        if (serviceState == null) {
            return 0;
        }
        int networkType = getNetworkType(phoneId);
        int nrStatus = serviceState.getNrState();
        int netWorkClass = getNetwork(networkType);
        Log.d(TAG, " netWorkClass = " + netWorkClass);
        if (networkType == 13 && (nrStatus == 3 || nrStatus == 2)) {
            return netWorkClass + 2;
        }
        return netWorkClass + 1;
    }

    public static int getNetwork(int networkType) {
        switch (networkType) {
            case 1:
            case 2:
            case 4:
            case 7:
            case 11:
            case 16:
                return 1;
            case 3:
            case 5:
            case 6:
            case 8:
            case 9:
            case 10:
            case 12:
            case 14:
            case 15:
            case 17:
                return 2;
            case 13:
            case 18:
            case 19:
                return 3;
            case UniTelephonyManager.SIM_STATE_SERVICE_PROVIDER_LOCKED_PUK /* 20 */:
                return 4;
            default:
                return 0;
        }
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getCurrentRam() {
        ActivityManager activityManager = (ActivityManager) this.mContext.getSystemService("activity");
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        float currentRam = (memoryInfo.totalMem - memoryInfo.availMem) / 1.0E9f;
        String currentRamSize = String.format("%.1f", Float.valueOf(currentRam));
        Log.d(TAG, "getCurrentRam = " + currentRamSize);
        return currentRamSize + "GB";
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getCurrentRom() throws IOException {
        File path = Environment.getDataDirectory();
        long romFreeSpace = path.getUsableSpace();
        long romTotalSpace = 0;
        try {
            StorageStatsManager stats = (StorageStatsManager) this.mContext.getSystemService(StorageStatsManager.class);
            romTotalSpace = stats.getTotalBytes(StorageManager.UUID_DEFAULT);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        long romCurrentSpace = romTotalSpace - romFreeSpace;
        String currentRom = String.format("%.1f", Float.valueOf(romCurrentSpace / 1.0E9f));
        Log.d(TAG, "getCurrentRom = " + currentRom);
        return currentRom + "GB";
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getBatteryTemp() {
        float batteryTempValue = Settings.Global.getInt(this.mContext.getContentResolver(), DmykAbsTelephonyManager.BATTERY_TEMPERATURE, DEFAULT_BATTERY_TEMPERATURE) / 10.0f;
        String batteryTemperature = String.format("%.1f", Float.valueOf(batteryTempValue));
        Log.d(TAG, "batteryTemp = " + batteryTemperature);
        return batteryTemperature + "℃";
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getWlanSignalIntensity() {
        WifiInfo wifiInfo;
        WifiManager wifiManager = (WifiManager) this.mContext.getSystemService("wifi");
        if (wifiManager == null || !wifiManager.isWifiEnabled() || (wifiInfo = wifiManager.getConnectionInfo()) == null) {
            return 0;
        }
        return wifiInfo.getRssi();
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public DmykAbsTelephonyManager.WifiInfo getWifiInfo() {
        DmykAbsTelephonyManager.WifiInfo sdkWifiInfo = new DmykAbsTelephonyManager.WifiInfo();
        WifiManager wifiManager = (WifiManager) this.mContext.getSystemService("wifi");
        if (wifiManager == null || !wifiManager.isWifiEnabled()) {
            Log.d(TAG, "Wifi is disabled.");
            return sdkWifiInfo;
        }
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        if (wifiInfo == null || wifiInfo.getNetworkId() == -1) {
            Log.d(TAG, "Not connected to any wireless network.");
            return sdkWifiInfo;
        }
        String macAddress = null;
        String[] wifiMacAddresses = wifiManager.getFactoryMacAddresses();
        if (wifiMacAddresses != null && wifiMacAddresses.length > 0) {
            macAddress = wifiMacAddresses[0];
        }
        if (!TextUtils.isEmpty(macAddress)) {
            sdkWifiInfo.wifiMAC = macAddress;
        } else {
            sdkWifiInfo.wifiMAC = null;
        }
        sdkWifiInfo.BSSID = wifiInfo.getBSSID();
        sdkWifiInfo.WLANName = wifiInfo.getSSID();
        sdkWifiInfo.SSID = wifiInfo.getSSID();
        Log.d(TAG, "wifiMAC = " + sdkWifiInfo.wifiMAC + "WLANName = " + sdkWifiInfo.WLANName);
        return sdkWifiInfo;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public int getWLANState() {
        int wifiState;
        WifiManager wifiManager = (WifiManager) this.mContext.getSystemService("wifi");
        if (wifiManager == null) {
            return 0;
        }
        int state = wifiManager.getWifiState();
        if (3 == state) {
            wifiState = 1;
        } else {
            wifiState = 0;
        }
        Log.d(TAG, "getWLANState: WLANState = " + wifiState);
        return wifiState;
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public String getBatteryLevel() {
        BatteryManager manager = (BatteryManager) this.mContext.getSystemService("batterymanager");
        int currentLevel = manager.getIntProperty(4);
        return String.valueOf(currentLevel);
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public void setNotification(int type, String content) {
        Log.d(TAG, "setNotification type :" + type);
        Log.d(TAG, "setNotification content :" + content);
    }

    @Override // com.dmyk.android.telephony.DmykAbsTelephonyManager
    public ArrayList<DmykAbsTelephonyManager.BluetoothInfo> getBluetoothInfo() {
        Log.d(TAG, "getBluetoothInfo enter");
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        ArrayList<DmykAbsTelephonyManager.BluetoothInfo> bluetoothInfo = new ArrayList<>();
        if (bluetoothAdapter == null) {
            Log.d(TAG, "getBluetoothInfo BluetoothAdapter is null and return");
            return bluetoothInfo;
        }
        Set<BluetoothDevice> bluetoothDevices = bluetoothAdapter.getBondedDevices();
        if (bluetoothDevices == null || bluetoothDevices.isEmpty()) {
            Log.w(TAG, "getBluetoothInfo bonded devices are null or no bonded device");
            return bluetoothInfo;
        }
        IDmykTelephony dmykTelephony = getIDmykTelephony();
        if (dmykTelephony == null) {
            return null;
        }
        try {
            for (BluetoothDevice bluetoothDevice : bluetoothDevices) {
                Log.d(TAG, "getBluetoothInfo isConnected: " + bluetoothDevice.isConnected() + "isEncrypted: " + bluetoothDevice.isEncrypted() + "addr: " + bluetoothDevice);
                if (dmykTelephony.isBluetoothConnected(bluetoothDevice)) {
                    DmykAbsTelephonyManager.BluetoothInfo info = new DmykAbsTelephonyManager.BluetoothInfo();
                    info.deviceMAC = bluetoothDevice.getAddress();
                    info.name = bluetoothDevice.getName();
                    info.uuid = Arrays.toString(bluetoothDevice.getUuids());
                    Log.d(TAG, "bluetooth deviceMAC =" + bluetoothDevice.getAddress() + " bluetooth name = " + bluetoothDevice.getName() + "bluetooth uuid =" + Arrays.toString(bluetoothDevice.getUuids()));
                    bluetoothInfo.add(info);
                }
            }
        } catch (RemoteException | NullPointerException ex) {
            Log.w(TAG, "getBluetoothInfo", ex);
        }
        return bluetoothInfo;
    }
}
