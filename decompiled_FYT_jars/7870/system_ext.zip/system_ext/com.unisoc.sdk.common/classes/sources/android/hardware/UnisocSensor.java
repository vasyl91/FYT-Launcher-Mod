package android.hardware;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\com.unisoc.sdk.common\classes.dex */
public final class UnisocSensor {
    public static final String STRING_TYPE_UNISOCHUB_FACE_UP_DOWN = "com.unisoc.face_up_down";
    public static final String STRING_TYPE_UNISOCHUB_FLIP = "com.unisoc.flip";
    public static final String STRING_TYPE_UNISOCHUB_HAND_DOWN = "com.unisoc.hand_down";
    public static final String STRING_TYPE_UNISOCHUB_HAND_UP = "com.unisoc.hand_up";
    public static final String STRING_TYPE_UNISOCHUB_POCKET_MODE = "com.unisoc.pocket_mode";
    public static final String STRING_TYPE_UNISOCHUB_SHAKE = "com.unisoc.shake";
    public static final String STRING_TYPE_UNISOCHUB_TAP = "com.unisoc.tap";
    public static final int TYPE_UNISOCHUB_FACE_UP_DOWN = 65540;
    public static final int TYPE_UNISOCHUB_FLIP = 65546;
    public static final int TYPE_UNISOCHUB_HAND_DOWN = 65549;
    public static final int TYPE_UNISOCHUB_HAND_UP = 65548;
    public static final int TYPE_UNISOCHUB_POCKET_MODE = 65538;
    public static final int TYPE_UNISOCHUB_SHAKE = 65537;
    public static final int TYPE_UNISOCHUB_TAP = 65539;
    private static final int UNISOC_SENSOR_TYPE_BASE = 65536;
}
