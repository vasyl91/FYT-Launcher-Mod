package androidx.window.common;

import android.R;
import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import androidx.window.util.BaseDataProducer;
import java.util.Optional;
import java.util.Set;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public final class RawFoldingFeatureProducer extends BaseDataProducer<String> {
    private static final String DISPLAY_FEATURES = "display_features";
    private final Uri mDisplayFeaturesUri = Settings.Global.getUriFor(DISPLAY_FEATURES);
    private final ContentObserver mObserver = new SettingsObserver();
    private boolean mRegisteredObservers;
    private final ContentResolver mResolver;
    private final String mResourceFeature;

    public RawFoldingFeatureProducer(Context context) {
        this.mResolver = context.getContentResolver();
        this.mResourceFeature = context.getResources().getString(R.string.config_defaultWallpaperEffectsGenerationService);
    }

    @Override // androidx.window.util.DataProducer
    public Optional<String> getData() {
        String displayFeaturesString = getFeatureString();
        if (displayFeaturesString == null) {
            return Optional.empty();
        }
        return Optional.of(displayFeaturesString);
    }

    private String getFeatureString() {
        String settingsFeature = Settings.Global.getString(this.mResolver, DISPLAY_FEATURES);
        if (TextUtils.isEmpty(settingsFeature)) {
            return this.mResourceFeature;
        }
        return settingsFeature;
    }

    @Override // androidx.window.util.BaseDataProducer
    protected void onListenersChanged(Set<Runnable> callbacks) {
        if (callbacks.isEmpty()) {
            unregisterObserversIfNeeded();
        } else {
            registerObserversIfNeeded();
        }
    }

    private void registerObserversIfNeeded() {
        if (this.mRegisteredObservers) {
            return;
        }
        this.mRegisteredObservers = true;
        this.mResolver.registerContentObserver(this.mDisplayFeaturesUri, false, this.mObserver);
    }

    private void unregisterObserversIfNeeded() {
        if (!this.mRegisteredObservers) {
            return;
        }
        this.mRegisteredObservers = false;
        this.mResolver.unregisterContentObserver(this.mObserver);
    }

    private final class SettingsObserver extends ContentObserver {
        SettingsObserver() {
            super(new Handler(Looper.getMainLooper()));
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange, Uri uri) {
            if (RawFoldingFeatureProducer.this.mDisplayFeaturesUri.equals(uri)) {
                RawFoldingFeatureProducer.this.notifyDataChanged();
            }
        }
    }
}
