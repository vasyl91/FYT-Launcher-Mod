package androidx.window.extensions.embedding;

import android.util.ArraySet;
import android.view.RemoteAnimationAdapter;
import android.view.RemoteAnimationDefinition;
import android.window.TaskFragmentOrganizer;
import java.util.Iterator;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
class TaskFragmentAnimationController {
    static final boolean DEBUG = false;
    private static final String TAG = "TaskFragAnimationCtrl";
    final RemoteAnimationDefinition mDefinition;
    private final TaskFragmentOrganizer mOrganizer;
    private final ArraySet<Integer> mRegisterTasks;
    private final TaskFragmentAnimationRunner mRemoteRunner;

    TaskFragmentAnimationController(TaskFragmentOrganizer organizer) {
        TaskFragmentAnimationRunner taskFragmentAnimationRunner = new TaskFragmentAnimationRunner();
        this.mRemoteRunner = taskFragmentAnimationRunner;
        this.mRegisterTasks = new ArraySet<>();
        this.mOrganizer = organizer;
        RemoteAnimationDefinition remoteAnimationDefinition = new RemoteAnimationDefinition();
        this.mDefinition = remoteAnimationDefinition;
        RemoteAnimationAdapter animationAdapter = new RemoteAnimationAdapter(taskFragmentAnimationRunner, 0L, 0L, true);
        remoteAnimationDefinition.addRemoteAnimation(6, animationAdapter);
        remoteAnimationDefinition.addRemoteAnimation(28, animationAdapter);
        remoteAnimationDefinition.addRemoteAnimation(8, animationAdapter);
        remoteAnimationDefinition.addRemoteAnimation(7, animationAdapter);
        remoteAnimationDefinition.addRemoteAnimation(29, animationAdapter);
        remoteAnimationDefinition.addRemoteAnimation(9, animationAdapter);
        remoteAnimationDefinition.addRemoteAnimation(30, animationAdapter);
    }

    void registerRemoteAnimations(int taskId) {
        if (this.mRegisterTasks.contains(Integer.valueOf(taskId))) {
            return;
        }
        this.mOrganizer.registerRemoteAnimations(taskId, this.mDefinition);
        this.mRegisterTasks.add(Integer.valueOf(taskId));
    }

    void unregisterRemoteAnimations(int taskId) {
        if (!this.mRegisterTasks.contains(Integer.valueOf(taskId))) {
            return;
        }
        this.mOrganizer.unregisterRemoteAnimations(taskId);
        this.mRegisterTasks.remove(Integer.valueOf(taskId));
    }

    void unregisterAllRemoteAnimations() {
        ArraySet<Integer> tasks = new ArraySet<>(this.mRegisterTasks);
        Iterator<Integer> it = tasks.iterator();
        while (it.hasNext()) {
            int taskId = it.next().intValue();
            unregisterRemoteAnimations(taskId);
        }
    }
}
