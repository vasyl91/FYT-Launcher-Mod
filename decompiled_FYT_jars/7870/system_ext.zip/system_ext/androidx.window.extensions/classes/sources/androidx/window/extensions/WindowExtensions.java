package androidx.window.extensions;

import androidx.window.extensions.embedding.ActivityEmbeddingComponent;
import androidx.window.extensions.layout.WindowLayoutComponent;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public interface WindowExtensions {
    ActivityEmbeddingComponent getActivityEmbeddingComponent();

    WindowLayoutComponent getWindowLayoutComponent();

    default int getVendorApiLevel() {
        return 1;
    }
}
