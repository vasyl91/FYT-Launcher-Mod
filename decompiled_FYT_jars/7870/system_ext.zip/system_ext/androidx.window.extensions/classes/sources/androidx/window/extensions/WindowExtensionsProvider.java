package androidx.window.extensions;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public class WindowExtensionsProvider {
    private static final WindowExtensions sWindowExtensions = new WindowExtensionsImpl();

    public static WindowExtensions getWindowExtensions() {
        return sWindowExtensions;
    }
}
