package androidx.window.extensions.embedding;

import android.graphics.Rect;
import android.view.Choreographer;
import android.view.RemoteAnimationTarget;
import android.view.SurfaceControl;
import android.view.animation.Animation;
import android.view.animation.Transformation;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
class TaskFragmentAnimationAdapter {
    private static final int LAYER_NO_OVERRIDE = -1;
    final Animation mAnimation;
    private boolean mIsFirstFrame;
    final SurfaceControl mLeash;
    final float[] mMatrix;
    private int mOverrideLayer;
    final Rect mRect;
    final RemoteAnimationTarget mTarget;
    final Transformation mTransformation;
    final float[] mVecs;

    TaskFragmentAnimationAdapter(Animation animation, RemoteAnimationTarget target) {
        this(animation, target, target.leash);
    }

    TaskFragmentAnimationAdapter(Animation animation, RemoteAnimationTarget target, SurfaceControl leash) {
        this.mTransformation = new Transformation();
        this.mMatrix = new float[9];
        this.mVecs = new float[4];
        this.mRect = new Rect();
        this.mIsFirstFrame = true;
        this.mOverrideLayer = -1;
        this.mAnimation = animation;
        this.mTarget = target;
        this.mLeash = leash;
    }

    final void overrideLayer(int layer) {
        this.mOverrideLayer = layer;
    }

    final void onAnimationUpdate(SurfaceControl.Transaction t, long currentPlayTime) {
        if (this.mIsFirstFrame) {
            t.show(this.mLeash);
            int i = this.mOverrideLayer;
            if (i != -1) {
                t.setLayer(this.mLeash, i);
            }
            this.mIsFirstFrame = false;
        }
        Animation animation = this.mAnimation;
        animation.getTransformation(Math.min(currentPlayTime, animation.getDuration()), this.mTransformation);
        t.setFrameTimelineVsync(Choreographer.getInstance().getVsyncId());
        onAnimationUpdateInner(t);
    }

    void onAnimationUpdateInner(SurfaceControl.Transaction t) {
        this.mTransformation.getMatrix().postTranslate(this.mTarget.localBounds.left, this.mTarget.localBounds.top);
        t.setMatrix(this.mLeash, this.mTransformation.getMatrix(), this.mMatrix);
        t.setAlpha(this.mLeash, this.mTransformation.getAlpha());
        int positionX = Math.round(this.mMatrix[2]);
        int positionY = Math.round(this.mMatrix[5]);
        int cropOffsetX = this.mTarget.localBounds.left - positionX;
        int cropOffsetY = this.mTarget.localBounds.top - positionY;
        Rect cropRect = new Rect();
        cropRect.set(this.mTarget.localBounds);
        cropRect.offsetTo(0, 0);
        cropRect.offset(cropOffsetX, cropOffsetY);
        t.setCrop(this.mLeash, cropRect);
    }

    final void onAnimationEnd(SurfaceControl.Transaction t) {
        onAnimationUpdate(t, this.mAnimation.getDuration());
    }

    final long getDurationHint() {
        return this.mAnimation.computeDurationHint();
    }

    static class SplitAdapter extends TaskFragmentAnimationAdapter {
        private final boolean mIsLeftHalf;
        private final int mWholeAnimationWidth;

        SplitAdapter(Animation animation, RemoteAnimationTarget target, boolean isLeftHalf, int wholeAnimationWidth) {
            super(animation, target);
            this.mIsLeftHalf = isLeftHalf;
            this.mWholeAnimationWidth = wholeAnimationWidth;
            if (wholeAnimationWidth == 0) {
                throw new IllegalArgumentException("SplitAdapter must provide wholeAnimationWidth");
            }
        }

        @Override // androidx.window.extensions.embedding.TaskFragmentAnimationAdapter
        void onAnimationUpdateInner(SurfaceControl.Transaction t) {
            float posX;
            float posX2 = this.mTarget.localBounds.left;
            float posY = this.mTarget.localBounds.top;
            this.mTransformation.getMatrix().getValues(this.mMatrix);
            int targetWidth = this.mTarget.localBounds.width();
            float scaleX = this.mMatrix[0];
            float totalOffset = (this.mWholeAnimationWidth * (1.0f - scaleX)) / 2.0f;
            float curOffset = (targetWidth * (1.0f - scaleX)) / 2.0f;
            float offsetDiff = totalOffset - curOffset;
            if (this.mIsLeftHalf) {
                posX = posX2 + offsetDiff;
            } else {
                posX = posX2 - offsetDiff;
            }
            this.mTransformation.getMatrix().postTranslate(posX, posY);
            t.setMatrix(this.mLeash, this.mTransformation.getMatrix(), this.mMatrix);
            t.setAlpha(this.mLeash, this.mTransformation.getAlpha());
        }
    }

    static class SnapshotAdapter extends TaskFragmentAnimationAdapter {
        SnapshotAdapter(Animation animation, RemoteAnimationTarget target) {
            super(animation, target, target.startLeash);
        }

        @Override // androidx.window.extensions.embedding.TaskFragmentAnimationAdapter
        void onAnimationUpdateInner(SurfaceControl.Transaction t) {
            this.mTransformation.getMatrix().postTranslate(0.0f, 0.0f);
            t.setMatrix(this.mLeash, this.mTransformation.getMatrix(), this.mMatrix);
            t.setAlpha(this.mLeash, this.mTransformation.getAlpha());
        }
    }

    static class BoundsChangeAdapter extends TaskFragmentAnimationAdapter {
        BoundsChangeAdapter(Animation animation, RemoteAnimationTarget target) {
            super(animation, target);
        }

        @Override // androidx.window.extensions.embedding.TaskFragmentAnimationAdapter
        void onAnimationUpdateInner(SurfaceControl.Transaction t) {
            this.mTransformation.getMatrix().postTranslate(this.mTarget.localBounds.left, this.mTarget.localBounds.top);
            t.setMatrix(this.mLeash, this.mTransformation.getMatrix(), this.mMatrix);
            t.setAlpha(this.mLeash, this.mTransformation.getAlpha());
            float[] fArr = this.mVecs;
            this.mVecs[2] = 0.0f;
            fArr[1] = 0.0f;
            float[] fArr2 = this.mVecs;
            this.mVecs[3] = 1.0f;
            fArr2[0] = 1.0f;
            this.mTransformation.getMatrix().mapVectors(this.mVecs);
            this.mVecs[0] = 1.0f / this.mVecs[0];
            this.mVecs[3] = 1.0f / this.mVecs[3];
            Rect clipRect = this.mTransformation.getClipRect();
            this.mRect.left = (int) ((clipRect.left * this.mVecs[0]) + 0.5f);
            this.mRect.right = (int) ((clipRect.right * this.mVecs[0]) + 0.5f);
            this.mRect.top = (int) ((clipRect.top * this.mVecs[3]) + 0.5f);
            this.mRect.bottom = (int) ((clipRect.bottom * this.mVecs[3]) + 0.5f);
            t.setWindowCrop(this.mLeash, this.mRect);
        }
    }
}
