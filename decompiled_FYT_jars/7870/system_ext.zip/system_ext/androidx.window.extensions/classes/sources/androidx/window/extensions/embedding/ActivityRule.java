package androidx.window.extensions.embedding;

import android.app.Activity;
import android.content.Intent;
import java.util.function.Predicate;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public class ActivityRule extends EmbeddingRule {
    private final Predicate<Activity> mActivityPredicate;
    private final Predicate<Intent> mIntentPredicate;
    private final boolean mShouldAlwaysExpand;

    ActivityRule(Predicate<Activity> activityPredicate, Predicate<Intent> intentPredicate, boolean shouldAlwaysExpand) {
        this.mActivityPredicate = activityPredicate;
        this.mIntentPredicate = intentPredicate;
        this.mShouldAlwaysExpand = shouldAlwaysExpand;
    }

    public boolean matchesActivity(Activity activity) {
        return this.mActivityPredicate.test(activity);
    }

    public boolean matchesIntent(Intent intent) {
        return this.mIntentPredicate.test(intent);
    }

    public boolean shouldAlwaysExpand() {
        return this.mShouldAlwaysExpand;
    }

    public static final class Builder {
        private final Predicate<Activity> mActivityPredicate;
        private boolean mAlwaysExpand;
        private final Predicate<Intent> mIntentPredicate;

        public Builder(Predicate<Activity> activityPredicate, Predicate<Intent> intentPredicate) {
            this.mActivityPredicate = activityPredicate;
            this.mIntentPredicate = intentPredicate;
        }

        public Builder setShouldAlwaysExpand(boolean alwaysExpand) {
            this.mAlwaysExpand = alwaysExpand;
            return this;
        }

        public ActivityRule build() {
            return new ActivityRule(this.mActivityPredicate, this.mIntentPredicate, this.mAlwaysExpand);
        }
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ActivityRule)) {
            return false;
        }
        ActivityRule that = (ActivityRule) o;
        return this.mShouldAlwaysExpand == that.mShouldAlwaysExpand && this.mActivityPredicate.equals(that.mActivityPredicate) && this.mIntentPredicate.equals(that.mIntentPredicate);
    }

    public int hashCode() {
        return (((this.mActivityPredicate.hashCode() * 31) + this.mIntentPredicate.hashCode()) * 31) + (this.mShouldAlwaysExpand ? 1 : 0);
    }

    public String toString() {
        return "ActivityRule{mShouldAlwaysExpand=" + this.mShouldAlwaysExpand + '}';
    }
}
