package androidx.window.extensions.embedding;

import android.app.Activity;
import android.app.ActivityClient;
import android.app.ActivityOptions;
import android.app.ActivityThread;
import android.app.Instrumentation;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.ArraySet;
import android.util.Log;
import android.util.Pair;
import android.util.Size;
import android.util.SparseArray;
import android.window.TaskFragmentInfo;
import android.window.WindowContainerTransaction;
import androidx.window.common.EmptyLifecycleCallbacksAdapter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public class SplitController implements JetpackTaskFragmentOrganizer.TaskFragmentCallback, ActivityEmbeddingComponent {
    static final String TAG = "SplitController";
    private Consumer<List<SplitInfo>> mEmbeddingCallback;
    private final Handler mHandler;
    final SplitPresenter mPresenter;
    private final List<EmbeddingRule> mSplitRules = new ArrayList();
    final SparseArray<TaskContainer> mTaskContainers = new SparseArray<>();
    private final List<SplitInfo> mLastReportedSplitStates = new ArrayList();
    private final Object mLock = new Object();

    /* JADX WARN: Multi-variable type inference failed */
    public SplitController() {
        MainThreadExecutor mainThreadExecutor = new MainThreadExecutor();
        this.mHandler = mainThreadExecutor.mHandler;
        this.mPresenter = new SplitPresenter(mainThreadExecutor, this);
        ActivityThread activityThreadCurrentActivityThread = ActivityThread.currentActivityThread();
        activityThreadCurrentActivityThread.getApplication().registerActivityLifecycleCallbacks(new LifecycleCallbacks());
        activityThreadCurrentActivityThread.getInstrumentation().addMonitor(new ActivityStartMonitor());
    }

    @Override // androidx.window.extensions.embedding.ActivityEmbeddingComponent
    public void setEmbeddingRules(Set<EmbeddingRule> rules) {
        synchronized (this.mLock) {
            this.mSplitRules.clear();
            this.mSplitRules.addAll(rules);
            for (int i = this.mTaskContainers.size() - 1; i >= 0; i--) {
                updateAnimationOverride(this.mTaskContainers.valueAt(i));
            }
        }
    }

    List<EmbeddingRule> getSplitRules() {
        return this.mSplitRules;
    }

    @Override // androidx.window.extensions.embedding.ActivityEmbeddingComponent
    public void setSplitInfoCallback(Consumer<List<SplitInfo>> callback) {
        synchronized (this.mLock) {
            this.mEmbeddingCallback = callback;
            updateCallbackIfNecessary();
        }
    }

    @Override // androidx.window.extensions.embedding.JetpackTaskFragmentOrganizer.TaskFragmentCallback
    public void onTaskFragmentAppeared(TaskFragmentInfo taskFragmentInfo) {
        synchronized (this.mLock) {
            TaskFragmentContainer container = getContainer(taskFragmentInfo.getFragmentToken());
            if (container == null) {
                return;
            }
            container.setInfo(taskFragmentInfo);
            if (container.isFinished()) {
                this.mPresenter.cleanupContainer(container, false);
            }
            updateCallbackIfNecessary();
        }
    }

    @Override // androidx.window.extensions.embedding.JetpackTaskFragmentOrganizer.TaskFragmentCallback
    public void onTaskFragmentInfoChanged(TaskFragmentInfo taskFragmentInfo) {
        synchronized (this.mLock) {
            TaskFragmentContainer container = getContainer(taskFragmentInfo.getFragmentToken());
            if (container == null) {
                return;
            }
            WindowContainerTransaction wct = new WindowContainerTransaction();
            boolean wasInPip = isInPictureInPicture(container);
            container.setInfo(taskFragmentInfo);
            boolean isInPip = isInPictureInPicture(container);
            if (!taskFragmentInfo.hasRunningActivity()) {
                if (taskFragmentInfo.isTaskFragmentClearedForPip()) {
                    cleanupForEnterPip(wct, container);
                    this.mPresenter.cleanupContainer(container, false, wct);
                } else if (taskFragmentInfo.isTaskClearedForReuse()) {
                    this.mPresenter.cleanupContainer(container, false, wct);
                } else if (!container.isWaitingActivityAppear()) {
                    this.mPresenter.cleanupContainer(container, true, wct);
                }
            } else {
                if (wasInPip && isInPip) {
                    return;
                }
                if (isInPip) {
                    container.setLastRequestedBounds(null);
                    container.setLastRequestedWindowingMode(0);
                    cleanupForEnterPip(wct, container);
                } else if (wasInPip) {
                    updateContainer(wct, container);
                }
            }
            this.mPresenter.applyTransaction(wct);
            updateCallbackIfNecessary();
        }
    }

    @Override // androidx.window.extensions.embedding.JetpackTaskFragmentOrganizer.TaskFragmentCallback
    public void onTaskFragmentVanished(TaskFragmentInfo taskFragmentInfo) {
        synchronized (this.mLock) {
            TaskFragmentContainer container = getContainer(taskFragmentInfo.getFragmentToken());
            if (container != null) {
                removeContainer(container);
                TaskFragmentContainer newTopContainer = getTopActiveContainer(container.getTaskId());
                if (newTopContainer != null) {
                    WindowContainerTransaction wct = new WindowContainerTransaction();
                    updateContainer(wct, newTopContainer);
                    this.mPresenter.applyTransaction(wct);
                }
                updateCallbackIfNecessary();
            }
            cleanupTaskFragment(taskFragmentInfo.getFragmentToken());
        }
    }

    @Override // androidx.window.extensions.embedding.JetpackTaskFragmentOrganizer.TaskFragmentCallback
    public void onTaskFragmentParentInfoChanged(IBinder fragmentToken, Configuration parentConfig) {
        synchronized (this.mLock) {
            TaskFragmentContainer container = getContainer(fragmentToken);
            if (container != null) {
                onTaskConfigurationChanged(container.getTaskId(), parentConfig);
                if (isInPictureInPicture(parentConfig)) {
                    return;
                }
                this.mPresenter.updateContainer(container);
                updateCallbackIfNecessary();
            }
        }
    }

    @Override // androidx.window.extensions.embedding.JetpackTaskFragmentOrganizer.TaskFragmentCallback
    public void onActivityReparentToTask(int taskId, Intent activityIntent, IBinder activityToken) {
        synchronized (this.mLock) {
            Activity activity = getActivity(activityToken);
            if (activity != null) {
                if (!resolveActivityToContainer(activity, true)) {
                    placeActivityInTopContainer(activity);
                }
                updateCallbackIfNecessary();
                return;
            }
            TaskContainer taskContainer = getTaskContainer(taskId);
            if (taskContainer != null && !taskContainer.isInPictureInPicture()) {
                WindowContainerTransaction wct = new WindowContainerTransaction();
                TaskFragmentContainer targetContainer = resolveStartActivityIntent(wct, taskId, activityIntent, null);
                if (targetContainer == null) {
                    targetContainer = taskContainer.getTopTaskFragmentContainer();
                }
                if (targetContainer == null) {
                    return;
                }
                wct.reparentActivityToTaskFragment(targetContainer.getTaskFragmentToken(), activityToken);
                this.mPresenter.applyTransaction(wct);
            }
        }
    }

    private void cleanupTaskFragment(IBinder taskFragmentToken) {
        for (int i = this.mTaskContainers.size() - 1; i >= 0; i--) {
            TaskContainer taskContainer = this.mTaskContainers.valueAt(i);
            if (taskContainer.mFinishedContainer.remove(taskFragmentToken)) {
                if (taskContainer.isEmpty()) {
                    this.mPresenter.stopOverrideSplitAnimation(taskContainer.getTaskId());
                    this.mTaskContainers.remove(taskContainer.getTaskId());
                    return;
                }
                return;
            }
        }
    }

    private void onTaskConfigurationChanged(int taskId, Configuration config) {
        TaskContainer taskContainer = this.mTaskContainers.get(taskId);
        if (taskContainer == null) {
            return;
        }
        boolean wasInPip = taskContainer.isInPictureInPicture();
        boolean isInPIp = isInPictureInPicture(config);
        taskContainer.setWindowingMode(config.windowConfiguration.getWindowingMode());
        boolean shouldUpdateAnimationOverride = wasInPip != isInPIp;
        if (taskContainer.setTaskBounds(config.windowConfiguration.getBounds()) && !isInPIp) {
            shouldUpdateAnimationOverride = true;
        }
        if (shouldUpdateAnimationOverride) {
            updateAnimationOverride(taskContainer);
        }
    }

    private void updateAnimationOverride(TaskContainer taskContainer) {
        if (!taskContainer.isTaskBoundsInitialized() || !taskContainer.isWindowingModeInitialized()) {
            return;
        }
        if (supportSplit(taskContainer)) {
            this.mPresenter.startOverrideSplitAnimation(taskContainer.getTaskId());
        } else {
            this.mPresenter.stopOverrideSplitAnimation(taskContainer.getTaskId());
        }
    }

    private boolean supportSplit(TaskContainer taskContainer) {
        if (taskContainer.isInPictureInPicture()) {
            return false;
        }
        for (EmbeddingRule rule : this.mSplitRules) {
            if ((rule instanceof SplitRule) && SplitPresenter.shouldShowSideBySide(taskContainer.getTaskBounds(), (SplitRule) rule)) {
                return true;
            }
        }
        return false;
    }

    void onActivityCreated(Activity launchedActivity) {
        resolveActivityToContainer(launchedActivity, false);
        updateCallbackIfNecessary();
    }

    boolean resolveActivityToContainer(Activity activity, boolean isOnReparent) {
        TaskFragmentContainer otherTopContainer;
        if (isInPictureInPicture(activity) || activity.isFinishing()) {
            return true;
        }
        if (!isOnReparent && getContainerWithActivity(activity) == null && getInitialTaskFragmentToken(activity) != null) {
            Log.d(TAG, "Activity is in a TaskFragment that is not recorded by the organizer. r=" + activity);
            return true;
        }
        if (shouldExpand(activity, null)) {
            expandActivity(activity);
            return true;
        }
        if (launchPlaceholderIfNecessary(activity, !isOnReparent) || isNewActivityInSplitWithRuleMatched(activity)) {
            return true;
        }
        Activity activityBelow = findActivityBelow(activity);
        if (activityBelow == null) {
            return false;
        }
        if (putActivitiesIntoSplitIfNecessary(activityBelow, activity)) {
            return true;
        }
        if (isOnReparent && putActivitiesIntoSplitIfNecessary(activity, activityBelow)) {
            return true;
        }
        TaskFragmentContainer activityBelowContainer = getContainerWithActivity(activityBelow);
        SplitContainer topSplit = getActiveSplitForContainer(activityBelowContainer);
        if (topSplit == null || !isTopMostSplit(topSplit)) {
            return false;
        }
        if (topSplit.getPrimaryContainer() == activityBelowContainer) {
            otherTopContainer = topSplit.getSecondaryContainer();
        } else {
            otherTopContainer = topSplit.getPrimaryContainer();
        }
        Activity otherTopActivity = otherTopContainer.getTopNonFinishingActivity();
        if (otherTopActivity == null || otherTopActivity == activity) {
            return false;
        }
        if (putActivitiesIntoSplitIfNecessary(otherTopActivity, activity)) {
            return true;
        }
        return isOnReparent && putActivitiesIntoSplitIfNecessary(activity, otherTopActivity);
    }

    void placeActivityInTopContainer(Activity activity) {
        TaskFragmentContainer targetContainer;
        if (getContainerWithActivity(activity) != null) {
            return;
        }
        int taskId = getTaskId(activity);
        TaskContainer taskContainer = getTaskContainer(taskId);
        if (taskContainer == null || (targetContainer = taskContainer.getTopTaskFragmentContainer()) == null) {
            return;
        }
        targetContainer.addPendingAppearedActivity(activity);
        WindowContainerTransaction wct = new WindowContainerTransaction();
        wct.reparentActivityToTaskFragment(targetContainer.getTaskFragmentToken(), activity.getActivityToken());
        this.mPresenter.applyTransaction(wct);
    }

    private void startActivityToSide(Activity launchingActivity, Intent intent, Bundle options, SplitRule sideRule, Consumer<Exception> failureCallback, boolean isPlaceholder) {
        try {
            this.mPresenter.startActivityToSide(launchingActivity, intent, options, sideRule, isPlaceholder);
        } catch (Exception e) {
            if (failureCallback != null) {
                failureCallback.accept(e);
            }
        }
    }

    private void expandActivity(Activity activity) {
        TaskFragmentContainer container = getContainerWithActivity(activity);
        if (shouldContainerBeExpanded(container)) {
            this.mPresenter.expandTaskFragment(container.getTaskFragmentToken());
        } else {
            TaskFragmentContainer newContainer = newContainer(activity, getTaskId(activity));
            this.mPresenter.expandActivity(newContainer.getTaskFragmentToken(), activity);
        }
    }

    private boolean isNewActivityInSplitWithRuleMatched(Activity launchedActivity) {
        TaskFragmentContainer container = getContainerWithActivity(launchedActivity);
        SplitContainer splitContainer = getActiveSplitForContainer(container);
        if (splitContainer == null) {
            return false;
        }
        if (container == splitContainer.getPrimaryContainer()) {
            TaskFragmentContainer secondaryContainer = splitContainer.getSecondaryContainer();
            Intent secondaryIntent = secondaryContainer.getPendingAppearedIntent();
            if (secondaryIntent != null) {
                return getSplitRule(launchedActivity, secondaryIntent) != null;
            }
            Activity secondaryActivity = secondaryContainer.getTopNonFinishingActivity();
            return (secondaryActivity == null || getSplitRule(launchedActivity, secondaryActivity) == null) ? false : true;
        }
        if (splitContainer.getSplitRule() instanceof SplitPlaceholderRule) {
            SplitPlaceholderRule placeholderRule = (SplitPlaceholderRule) splitContainer.getSplitRule();
            ComponentName placeholderName = placeholderRule.getPlaceholderIntent().getComponent();
            return placeholderName == null || placeholderName.equals(launchedActivity.getComponentName()) || placeholderRule.getPlaceholderIntent().equals(launchedActivity.getIntent());
        }
        Activity primaryActivity = splitContainer.getPrimaryContainer().getTopNonFinishingActivity();
        return (primaryActivity == null || getSplitRule(primaryActivity, launchedActivity) == null) ? false : true;
    }

    Activity findActivityBelow(Activity activity) {
        IBinder belowToken;
        List<Activity> containerActivities;
        int index;
        Activity activityBelow = null;
        TaskFragmentContainer container = getContainerWithActivity(activity);
        if (container != null && (index = (containerActivities = container.collectNonFinishingActivities()).indexOf(activity)) > 0) {
            activityBelow = containerActivities.get(index - 1);
        }
        if (activityBelow == null && (belowToken = ActivityClient.getInstance().getActivityTokenBelow(activity.getActivityToken())) != null) {
            return getActivity(belowToken);
        }
        return activityBelow;
    }

    private boolean putActivitiesIntoSplitIfNecessary(Activity primaryActivity, Activity secondaryActivity) {
        SplitPairRule splitRule = getSplitRule(primaryActivity, secondaryActivity);
        if (splitRule == null) {
            return false;
        }
        TaskFragmentContainer primaryContainer = getContainerWithActivity(primaryActivity);
        SplitContainer splitContainer = getActiveSplitForContainer(primaryContainer);
        if (splitContainer != null && primaryContainer == splitContainer.getPrimaryContainer() && canReuseContainer(splitRule, splitContainer.getSplitRule())) {
            TaskFragmentContainer secondaryContainer = splitContainer.getSecondaryContainer();
            if (secondaryContainer == getContainerWithActivity(secondaryActivity)) {
                return true;
            }
            secondaryContainer.addPendingAppearedActivity(secondaryActivity);
            WindowContainerTransaction wct = new WindowContainerTransaction();
            if (this.mPresenter.expandSplitContainerIfNeeded(wct, splitContainer, primaryActivity, secondaryActivity, null) != 2) {
                wct.reparentActivityToTaskFragment(secondaryContainer.getTaskFragmentToken(), secondaryActivity.getActivityToken());
                this.mPresenter.applyTransaction(wct);
                return true;
            }
        }
        this.mPresenter.createNewSplitContainer(primaryActivity, secondaryActivity, splitRule);
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onActivityConfigurationChanged(Activity activity) {
        if (activity.isFinishing() || isInPictureInPicture(activity)) {
            return;
        }
        TaskFragmentContainer currentContainer = getContainerWithActivity(activity);
        if (currentContainer != null) {
            return;
        }
        launchPlaceholderIfNecessary(activity, false);
    }

    void onActivityDestroyed(Activity activity) {
        for (int i = this.mTaskContainers.size() - 1; i >= 0; i--) {
            this.mTaskContainers.valueAt(i).cleanupPendingAppearedActivity(activity);
        }
        updateCallbackIfNecessary();
    }

    void onTaskFragmentAppearEmptyTimeout(TaskFragmentContainer container) {
        this.mPresenter.cleanupContainer(container, false);
    }

    TaskFragmentContainer resolveStartActivityIntent(WindowContainerTransaction wct, int taskId, Intent intent, Activity launchingActivity) {
        TaskFragmentContainer otherTopContainer;
        TaskFragmentContainer container;
        TaskFragmentContainer container2;
        if (shouldExpand(null, intent)) {
            return createEmptyExpandedContainer(wct, intent, taskId, launchingActivity);
        }
        if (launchingActivity != null && (container2 = getSecondaryContainerForSplitIfAny(wct, launchingActivity, intent, true)) != null) {
            return container2;
        }
        TaskContainer taskContainer = getTaskContainer(taskId);
        if (taskContainer == null || taskContainer.getTopTaskFragmentContainer() == null) {
            return null;
        }
        TaskFragmentContainer topContainer = taskContainer.getTopTaskFragmentContainer();
        Activity topActivity = topContainer.getTopNonFinishingActivity();
        if (topActivity != null && topActivity != launchingActivity && (container = getSecondaryContainerForSplitIfAny(wct, topActivity, intent, false)) != null) {
            return container;
        }
        SplitContainer topSplit = getActiveSplitForContainer(topContainer);
        if (topSplit == null) {
            return null;
        }
        if (topSplit.getPrimaryContainer() == topContainer) {
            otherTopContainer = topSplit.getSecondaryContainer();
        } else {
            otherTopContainer = topSplit.getPrimaryContainer();
        }
        Activity otherTopActivity = otherTopContainer.getTopNonFinishingActivity();
        if (otherTopActivity == null || otherTopActivity == launchingActivity) {
            return null;
        }
        return getSecondaryContainerForSplitIfAny(wct, otherTopActivity, intent, false);
    }

    private TaskFragmentContainer createEmptyExpandedContainer(WindowContainerTransaction wct, Intent intent, int taskId, Activity launchingActivity) {
        Activity topNonFinishingActivity;
        Activity activityInTask;
        if (launchingActivity != null) {
            activityInTask = launchingActivity;
        } else {
            TaskContainer taskContainer = getTaskContainer(taskId);
            if (taskContainer != null) {
                topNonFinishingActivity = taskContainer.getTopNonFinishingActivity();
            } else {
                topNonFinishingActivity = null;
            }
            activityInTask = topNonFinishingActivity;
        }
        if (activityInTask == null) {
            return null;
        }
        TaskFragmentContainer expandedContainer = newContainer(intent, activityInTask, taskId);
        this.mPresenter.createTaskFragment(wct, expandedContainer.getTaskFragmentToken(), activityInTask.getActivityToken(), new Rect(), 0);
        return expandedContainer;
    }

    private TaskFragmentContainer getSecondaryContainerForSplitIfAny(WindowContainerTransaction wct, Activity primaryActivity, Intent intent, boolean respectClearTop) {
        SplitPairRule splitRule = getSplitRule(primaryActivity, intent);
        if (splitRule == null) {
            return null;
        }
        TaskFragmentContainer existingContainer = getContainerWithActivity(primaryActivity);
        SplitContainer splitContainer = getActiveSplitForContainer(existingContainer);
        if (splitContainer != null && existingContainer == splitContainer.getPrimaryContainer() && ((canReuseContainer(splitRule, splitContainer.getSplitRule()) || !respectClearTop) && this.mPresenter.expandSplitContainerIfNeeded(wct, splitContainer, primaryActivity, null, intent) != 2)) {
            return splitContainer.getSecondaryContainer();
        }
        return this.mPresenter.createNewSplitWithEmptySideContainer(wct, primaryActivity, intent, splitRule);
    }

    TaskFragmentContainer getContainerWithActivity(Activity activity) {
        IBinder activityToken = activity.getActivityToken();
        for (int i = this.mTaskContainers.size() - 1; i >= 0; i--) {
            List<TaskFragmentContainer> containers = this.mTaskContainers.valueAt(i).mContainers;
            for (int j = containers.size() - 1; j >= 0; j--) {
                TaskFragmentContainer container = containers.get(j);
                if (container.hasActivity(activityToken)) {
                    return container;
                }
            }
        }
        return null;
    }

    TaskFragmentContainer newContainer(Activity pendingAppearedActivity, int taskId) {
        return newContainer(pendingAppearedActivity, pendingAppearedActivity, taskId);
    }

    TaskFragmentContainer newContainer(Activity pendingAppearedActivity, Activity activityInTask, int taskId) {
        return newContainer(pendingAppearedActivity, null, activityInTask, taskId);
    }

    TaskFragmentContainer newContainer(Intent pendingAppearedIntent, Activity activityInTask, int taskId) {
        return newContainer(null, pendingAppearedIntent, activityInTask, taskId);
    }

    TaskFragmentContainer newContainer(Activity pendingAppearedActivity, Intent pendingAppearedIntent, Activity activityInTask, int taskId) {
        if (activityInTask == null) {
            throw new IllegalArgumentException("activityInTask must not be null,");
        }
        if (!this.mTaskContainers.contains(taskId)) {
            this.mTaskContainers.put(taskId, new TaskContainer(taskId));
        }
        TaskContainer taskContainer = this.mTaskContainers.get(taskId);
        TaskFragmentContainer container = new TaskFragmentContainer(pendingAppearedActivity, pendingAppearedIntent, taskContainer, this);
        if (!taskContainer.isTaskBoundsInitialized()) {
            Rect taskBounds = SplitPresenter.getNonEmbeddedActivityBounds(activityInTask);
            if (!taskContainer.setTaskBounds(taskBounds)) {
                Log.w(TAG, "Can't find bounds from activity=" + activityInTask);
            }
        }
        if (!taskContainer.isWindowingModeInitialized()) {
            taskContainer.setWindowingMode(activityInTask.getResources().getConfiguration().windowConfiguration.getWindowingMode());
        }
        updateAnimationOverride(taskContainer);
        return container;
    }

    void registerSplit(WindowContainerTransaction wct, TaskFragmentContainer primaryContainer, Activity primaryActivity, TaskFragmentContainer secondaryContainer, SplitRule splitRule) {
        SplitContainer splitContainer = new SplitContainer(primaryContainer, primaryActivity, secondaryContainer, splitRule);
        if ((splitRule instanceof SplitPairRule) && ((SplitPairRule) splitRule).shouldClearTop()) {
            removeExistingSecondaryContainers(wct, primaryContainer);
        }
        primaryContainer.getTaskContainer().mSplitContainers.add(splitContainer);
    }

    private void cleanupForEnterPip(WindowContainerTransaction wct, TaskFragmentContainer container) {
        TaskFragmentContainer splitTf;
        TaskContainer taskContainer = container.getTaskContainer();
        if (taskContainer == null) {
            return;
        }
        List<SplitContainer> splitsToRemove = new ArrayList<>();
        Set<TaskFragmentContainer> containersToUpdate = new ArraySet<>();
        for (SplitContainer splitContainer : taskContainer.mSplitContainers) {
            if (splitContainer.getPrimaryContainer() == container || splitContainer.getSecondaryContainer() == container) {
                splitsToRemove.add(splitContainer);
                if (splitContainer.getPrimaryContainer() == container) {
                    splitTf = splitContainer.getSecondaryContainer();
                } else {
                    splitTf = splitContainer.getPrimaryContainer();
                }
                containersToUpdate.add(splitTf);
                splitTf.removeContainerToFinishOnExit(container);
                if (container.getTopNonFinishingActivity() != null) {
                    splitTf.removeActivityToFinishOnExit(container.getTopNonFinishingActivity());
                }
            }
        }
        container.resetDependencies();
        taskContainer.mSplitContainers.removeAll(splitsToRemove);
        for (TaskFragmentContainer containerToUpdate : containersToUpdate) {
            updateContainer(wct, containerToUpdate);
        }
    }

    void removeContainer(TaskFragmentContainer container) {
        TaskContainer taskContainer = container.getTaskContainer();
        if (taskContainer == null) {
            return;
        }
        taskContainer.mContainers.remove(container);
        taskContainer.mFinishedContainer.add(container.getTaskFragmentToken());
        List<SplitContainer> containersToRemove = new ArrayList<>();
        for (SplitContainer splitContainer : taskContainer.mSplitContainers) {
            if (container.equals(splitContainer.getSecondaryContainer()) || container.equals(splitContainer.getPrimaryContainer())) {
                containersToRemove.add(splitContainer);
            }
        }
        taskContainer.mSplitContainers.removeAll(containersToRemove);
        for (TaskFragmentContainer containerToUpdate : taskContainer.mContainers) {
            containerToUpdate.removeContainerToFinishOnExit(container);
        }
    }

    void removeExistingSecondaryContainers(WindowContainerTransaction wct, TaskFragmentContainer primaryContainer) {
        SplitContainer existingSplitContainer = getActiveSplitForContainer(primaryContainer);
        if (existingSplitContainer == null || primaryContainer == existingSplitContainer.getSecondaryContainer()) {
            return;
        }
        existingSplitContainer.getSecondaryContainer().finish(false, this.mPresenter, wct, this);
    }

    TaskFragmentContainer getTopActiveContainer(int taskId) {
        TaskContainer taskContainer = this.mTaskContainers.get(taskId);
        if (taskContainer == null) {
            return null;
        }
        for (int i = taskContainer.mContainers.size() - 1; i >= 0; i--) {
            TaskFragmentContainer container = taskContainer.mContainers.get(i);
            if (!container.isFinished() && (container.getRunningActivityCount() > 0 || container.isWaitingActivityAppear())) {
                return container;
            }
        }
        return null;
    }

    void updateContainer(WindowContainerTransaction wct, TaskFragmentContainer container) {
        if (launchPlaceholderIfNecessary(container)) {
            return;
        }
        if (shouldContainerBeExpanded(container)) {
            if (container.getInfo() != null) {
                this.mPresenter.expandTaskFragment(wct, container.getTaskFragmentToken());
                return;
            }
            return;
        }
        SplitContainer splitContainer = getActiveSplitForContainer(container);
        if (splitContainer == null || !isTopMostSplit(splitContainer) || splitContainer.getPrimaryContainer().isFinished() || splitContainer.getSecondaryContainer().isFinished() || dismissPlaceholderIfNecessary(splitContainer)) {
            return;
        }
        this.mPresenter.updateSplitContainer(splitContainer, container, wct);
    }

    private boolean isTopMostSplit(SplitContainer splitContainer) {
        List<SplitContainer> splitContainers = splitContainer.getPrimaryContainer().getTaskContainer().mSplitContainers;
        return splitContainer == splitContainers.get(splitContainers.size() - 1);
    }

    private SplitContainer getActiveSplitForContainer(TaskFragmentContainer container) {
        if (container == null) {
            return null;
        }
        List<SplitContainer> splitContainers = container.getTaskContainer().mSplitContainers;
        if (splitContainers.isEmpty()) {
            return null;
        }
        for (int i = splitContainers.size() - 1; i >= 0; i--) {
            SplitContainer splitContainer = splitContainers.get(i);
            if (container.equals(splitContainer.getSecondaryContainer()) || container.equals(splitContainer.getPrimaryContainer())) {
                return splitContainer;
            }
        }
        return null;
    }

    SplitContainer getActiveSplitForContainers(TaskFragmentContainer firstContainer, TaskFragmentContainer secondContainer) {
        List<SplitContainer> splitContainers = firstContainer.getTaskContainer().mSplitContainers;
        for (int i = splitContainers.size() - 1; i >= 0; i--) {
            SplitContainer splitContainer = splitContainers.get(i);
            TaskFragmentContainer primary = splitContainer.getPrimaryContainer();
            TaskFragmentContainer secondary = splitContainer.getSecondaryContainer();
            if ((firstContainer == secondary && secondContainer == primary) || (firstContainer == primary && secondContainer == secondary)) {
                return splitContainer;
            }
        }
        return null;
    }

    private boolean launchPlaceholderIfNecessary(TaskFragmentContainer container) {
        Activity topActivity = container.getTopNonFinishingActivity();
        if (topActivity == null) {
            return false;
        }
        return launchPlaceholderIfNecessary(topActivity, false);
    }

    boolean launchPlaceholderIfNecessary(Activity activity, boolean isOnCreated) {
        SplitPlaceholderRule placeholderRule;
        if (activity.isFinishing()) {
            return false;
        }
        TaskFragmentContainer container = getContainerWithActivity(activity);
        if (container != null && container != getTopActiveContainer(container.getTaskId())) {
            return false;
        }
        SplitContainer splitContainer = getActiveSplitForContainer(container);
        if ((splitContainer != null && container.equals(splitContainer.getPrimaryContainer())) || (placeholderRule = getPlaceholderRule(activity)) == null) {
            return false;
        }
        Pair<Size, Size> minDimensionsPair = SplitPresenter.getActivityIntentMinDimensionsPair(activity, placeholderRule.getPlaceholderIntent());
        if (!SplitPresenter.shouldShowSideBySide(this.mPresenter.getParentContainerBounds(activity), placeholderRule, minDimensionsPair)) {
            return false;
        }
        Bundle options = getPlaceholderOptions(activity, isOnCreated);
        startActivityToSide(activity, placeholderRule.getPlaceholderIntent(), options, placeholderRule, null, true);
        return true;
    }

    Bundle getPlaceholderOptions(Activity primaryActivity, boolean isOnCreated) {
        if (isOnCreated || primaryActivity.isResumed()) {
            return null;
        }
        ActivityOptions options = ActivityOptions.makeBasic();
        options.setAvoidMoveToFront();
        return options.toBundle();
    }

    boolean dismissPlaceholderIfNecessary(SplitContainer splitContainer) {
        if (!splitContainer.isPlaceholderContainer() || SplitContainer.isStickyPlaceholderRule(splitContainer.getSplitRule()) || SplitPresenter.shouldShowSideBySide(splitContainer)) {
            return false;
        }
        this.mPresenter.cleanupContainer(splitContainer.getSecondaryContainer(), false);
        return true;
    }

    private SplitPlaceholderRule getPlaceholderRule(Activity activity) {
        for (EmbeddingRule rule : this.mSplitRules) {
            if (rule instanceof SplitPlaceholderRule) {
                SplitPlaceholderRule placeholderRule = (SplitPlaceholderRule) rule;
                if (placeholderRule.matchesActivity(activity)) {
                    return placeholderRule;
                }
            }
        }
        return null;
    }

    private void updateCallbackIfNecessary() {
        List<SplitInfo> currentSplitStates;
        if (this.mEmbeddingCallback == null || !allActivitiesCreated() || (currentSplitStates = getActiveSplitStates()) == null || this.mLastReportedSplitStates.equals(currentSplitStates)) {
            return;
        }
        this.mLastReportedSplitStates.clear();
        this.mLastReportedSplitStates.addAll(currentSplitStates);
        this.mEmbeddingCallback.accept(currentSplitStates);
    }

    private List<SplitInfo> getActiveSplitStates() {
        float splitRatio;
        List<SplitInfo> splitStates = new ArrayList<>();
        for (int i = this.mTaskContainers.size() - 1; i >= 0; i--) {
            List<SplitContainer> splitContainers = this.mTaskContainers.valueAt(i).mSplitContainers;
            for (SplitContainer container : splitContainers) {
                if (container.getPrimaryContainer().isEmpty() || container.getSecondaryContainer().isEmpty()) {
                    return null;
                }
                ActivityStack primaryContainer = container.getPrimaryContainer().toActivityStack();
                ActivityStack secondaryContainer = container.getSecondaryContainer().toActivityStack();
                if (SplitPresenter.shouldShowSideBySide(container)) {
                    splitRatio = container.getSplitRule().getSplitRatio();
                } else {
                    splitRatio = 0.0f;
                }
                SplitInfo splitState = new SplitInfo(primaryContainer, secondaryContainer, splitRatio);
                splitStates.add(splitState);
            }
        }
        return splitStates;
    }

    private boolean allActivitiesCreated() {
        for (int i = this.mTaskContainers.size() - 1; i >= 0; i--) {
            List<TaskFragmentContainer> containers = this.mTaskContainers.valueAt(i).mContainers;
            for (TaskFragmentContainer container : containers) {
                if (!container.taskInfoActivityCountMatchesCreated()) {
                    return false;
                }
            }
        }
        return true;
    }

    boolean shouldContainerBeExpanded(TaskFragmentContainer container) {
        return container != null && getActiveSplitForContainer(container) == null;
    }

    private SplitPairRule getSplitRule(Activity primaryActivity, Intent secondaryActivityIntent) {
        for (EmbeddingRule rule : this.mSplitRules) {
            if (rule instanceof SplitPairRule) {
                SplitPairRule pairRule = (SplitPairRule) rule;
                if (pairRule.matchesActivityIntentPair(primaryActivity, secondaryActivityIntent)) {
                    return pairRule;
                }
            }
        }
        return null;
    }

    private SplitPairRule getSplitRule(Activity primaryActivity, Activity secondaryActivity) {
        for (EmbeddingRule rule : this.mSplitRules) {
            if (rule instanceof SplitPairRule) {
                SplitPairRule pairRule = (SplitPairRule) rule;
                Intent intent = secondaryActivity.getIntent();
                if (pairRule.matchesActivityPair(primaryActivity, secondaryActivity) && (intent == null || pairRule.matchesActivityIntentPair(primaryActivity, intent))) {
                    return pairRule;
                }
            }
        }
        return null;
    }

    TaskFragmentContainer getContainer(IBinder fragmentToken) {
        for (int i = this.mTaskContainers.size() - 1; i >= 0; i--) {
            List<TaskFragmentContainer> containers = this.mTaskContainers.valueAt(i).mContainers;
            for (TaskFragmentContainer container : containers) {
                if (container.getTaskFragmentToken().equals(fragmentToken)) {
                    return container;
                }
            }
        }
        return null;
    }

    TaskContainer getTaskContainer(int taskId) {
        return this.mTaskContainers.get(taskId);
    }

    Handler getHandler() {
        return this.mHandler;
    }

    int getTaskId(Activity activity) {
        TaskFragmentContainer container = getContainerWithActivity(activity);
        return container != null ? container.getTaskId() : activity.getTaskId();
    }

    Activity getActivity(IBinder activityToken) {
        return ActivityThread.currentActivityThread().getActivity(activityToken);
    }

    IBinder getInitialTaskFragmentToken(Activity activity) {
        ActivityThread.ActivityClientRecord record = ActivityThread.currentActivityThread().getActivityClient(activity.getActivityToken());
        if (record != null) {
            return record.mInitialTaskFragmentToken;
        }
        return null;
    }

    private boolean shouldExpand(Activity activity, Intent intent) {
        for (EmbeddingRule rule : this.mSplitRules) {
            if (rule instanceof ActivityRule) {
                ActivityRule activityRule = (ActivityRule) rule;
                if (!activityRule.shouldAlwaysExpand()) {
                    continue;
                } else {
                    if (activity != null && activityRule.matchesActivity(activity)) {
                        return true;
                    }
                    if (intent != null && activityRule.matchesIntent(intent)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    boolean shouldRetainAssociatedContainer(TaskFragmentContainer finishingContainer, TaskFragmentContainer associatedContainer) {
        int finishBehavior;
        SplitContainer splitContainer = getActiveSplitForContainers(associatedContainer, finishingContainer);
        if (splitContainer == null) {
            return false;
        }
        SplitRule splitRule = splitContainer.getSplitRule();
        if (finishingContainer == splitContainer.getPrimaryContainer()) {
            finishBehavior = SplitContainer.getFinishSecondaryWithPrimaryBehavior(splitRule);
        } else {
            finishBehavior = SplitContainer.getFinishPrimaryWithSecondaryBehavior(splitRule);
        }
        if (SplitPresenter.shouldShowSideBySide(splitContainer)) {
            return !SplitContainer.shouldFinishAssociatedContainerWhenAdjacent(finishBehavior);
        }
        return !SplitContainer.shouldFinishAssociatedContainerWhenStacked(finishBehavior);
    }

    boolean shouldRetainAssociatedActivity(TaskFragmentContainer finishingContainer, Activity associatedActivity) {
        TaskFragmentContainer associatedContainer = getContainerWithActivity(associatedActivity);
        if (associatedContainer == null) {
            return false;
        }
        return shouldRetainAssociatedContainer(finishingContainer, associatedContainer);
    }

    private final class LifecycleCallbacks extends EmptyLifecycleCallbacksAdapter {
        private LifecycleCallbacks() {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreCreated(Activity activity, Bundle savedInstanceState) {
            synchronized (SplitController.this.mLock) {
                IBinder activityToken = activity.getActivityToken();
                IBinder initialTaskFragmentToken = SplitController.this.getInitialTaskFragmentToken(activity);
                if (initialTaskFragmentToken == null) {
                    return;
                }
                for (int i = SplitController.this.mTaskContainers.size() - 1; i >= 0; i--) {
                    List<TaskFragmentContainer> containers = SplitController.this.mTaskContainers.valueAt(i).mContainers;
                    for (int j = containers.size() - 1; j >= 0; j--) {
                        TaskFragmentContainer container = containers.get(j);
                        if (!container.hasActivity(activityToken) && container.getTaskFragmentToken().equals(initialTaskFragmentToken)) {
                            container.addPendingAppearedActivity(activity);
                            return;
                        }
                    }
                }
            }
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostCreated(Activity activity, Bundle savedInstanceState) {
            synchronized (SplitController.this.mLock) {
                SplitController.this.onActivityCreated(activity);
            }
        }

        public void onActivityConfigurationChanged(Activity activity) {
            synchronized (SplitController.this.mLock) {
                SplitController.this.onActivityConfigurationChanged(activity);
            }
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostDestroyed(Activity activity) {
            synchronized (SplitController.this.mLock) {
                SplitController.this.onActivityDestroyed(activity);
            }
        }
    }

    private static class MainThreadExecutor implements Executor {
        private final Handler mHandler;

        private MainThreadExecutor() {
            this.mHandler = new Handler(Looper.getMainLooper());
        }

        @Override // java.util.concurrent.Executor
        public void execute(Runnable r) {
            this.mHandler.post(r);
        }
    }

    private class ActivityStartMonitor extends Instrumentation.ActivityMonitor {
        private ActivityStartMonitor() {
        }

        public Instrumentation.ActivityResult onStartActivity(Context who, Intent intent, Bundle options) {
            if (!(who instanceof Activity)) {
                return super.onStartActivity(who, intent, options);
            }
            Activity launchingActivity = (Activity) who;
            if (SplitController.isInPictureInPicture(launchingActivity)) {
                return super.onStartActivity(who, intent, options);
            }
            synchronized (SplitController.this.mLock) {
                int taskId = SplitController.this.getTaskId(launchingActivity);
                WindowContainerTransaction wct = new WindowContainerTransaction();
                TaskFragmentContainer launchedInTaskFragment = SplitController.this.resolveStartActivityIntent(wct, taskId, intent, launchingActivity);
                if (launchedInTaskFragment != null) {
                    SplitController.this.mPresenter.applyTransaction(wct);
                    options.putBinder("android.activity.launchTaskFragmentToken", launchedInTaskFragment.getTaskFragmentToken());
                }
            }
            return super.onStartActivity(who, intent, options);
        }
    }

    @Override // androidx.window.extensions.embedding.ActivityEmbeddingComponent
    public boolean isActivityEmbedded(Activity activity) {
        boolean zIsActivityEmbedded;
        synchronized (this.mLock) {
            zIsActivityEmbedded = this.mPresenter.isActivityEmbedded(activity.getActivityToken());
        }
        return zIsActivityEmbedded;
    }

    private static boolean canReuseContainer(SplitRule rule1, SplitRule rule2) {
        if (!isContainerReusableRule(rule1) || !isContainerReusableRule(rule2)) {
            return false;
        }
        return haveSamePresentation((SplitPairRule) rule1, (SplitPairRule) rule2);
    }

    private static boolean haveSamePresentation(SplitPairRule rule1, SplitPairRule rule2) {
        return rule1.getSplitRatio() == rule2.getSplitRatio() && rule1.getLayoutDirection() == rule2.getLayoutDirection() && rule1.getFinishPrimaryWithSecondary() == rule2.getFinishPrimaryWithSecondary() && rule1.getFinishSecondaryWithPrimary() == rule2.getFinishSecondaryWithPrimary();
    }

    private static boolean isContainerReusableRule(SplitRule rule) {
        if (!(rule instanceof SplitPairRule)) {
            return false;
        }
        SplitPairRule pairRule = (SplitPairRule) rule;
        return !pairRule.shouldClearTop();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean isInPictureInPicture(Activity activity) {
        return isInPictureInPicture(activity.getResources().getConfiguration());
    }

    private static boolean isInPictureInPicture(TaskFragmentContainer tf) {
        return isInPictureInPicture(tf.getInfo().getConfiguration());
    }

    private static boolean isInPictureInPicture(Configuration configuration) {
        return configuration != null && configuration.windowConfiguration.getWindowingMode() == 2;
    }
}
