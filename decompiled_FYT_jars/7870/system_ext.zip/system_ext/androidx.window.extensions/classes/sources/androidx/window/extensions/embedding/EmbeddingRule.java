package androidx.window.extensions.embedding;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public abstract class EmbeddingRule {
    EmbeddingRule() {
    }
}
