package androidx.window.extensions.embedding;

import android.view.WindowMetrics;
import java.util.function.Predicate;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public abstract class SplitRule extends EmbeddingRule {
    public static final int FINISH_ADJACENT = 2;
    public static final int FINISH_ALWAYS = 1;
    public static final int FINISH_NEVER = 0;
    private final int mLayoutDirection;
    private final Predicate<WindowMetrics> mParentWindowMetricsPredicate;
    private final float mSplitRatio;

    SplitRule(Predicate<WindowMetrics> parentWindowMetricsPredicate, float splitRatio, int layoutDirection) {
        this.mParentWindowMetricsPredicate = parentWindowMetricsPredicate;
        this.mSplitRatio = splitRatio;
        this.mLayoutDirection = layoutDirection;
    }

    public boolean checkParentMetrics(WindowMetrics parentMetrics) {
        return this.mParentWindowMetricsPredicate.test(parentMetrics);
    }

    public float getSplitRatio() {
        return this.mSplitRatio;
    }

    public int getLayoutDirection() {
        return this.mLayoutDirection;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof SplitRule)) {
            return false;
        }
        SplitRule that = (SplitRule) o;
        return Float.compare(that.mSplitRatio, this.mSplitRatio) == 0 && this.mParentWindowMetricsPredicate.equals(that.mParentWindowMetricsPredicate) && this.mLayoutDirection == that.mLayoutDirection;
    }

    public int hashCode() {
        int result = (int) (this.mSplitRatio * 17.0f);
        return (((result * 31) + this.mParentWindowMetricsPredicate.hashCode()) * 31) + this.mLayoutDirection;
    }

    public String toString() {
        return "SplitRule{mSplitRatio=" + this.mSplitRatio + ", mLayoutDirection=" + this.mLayoutDirection + '}';
    }
}
