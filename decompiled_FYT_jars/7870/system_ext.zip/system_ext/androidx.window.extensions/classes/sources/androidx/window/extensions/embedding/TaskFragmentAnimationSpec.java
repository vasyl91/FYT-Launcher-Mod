package androidx.window.extensions.embedding;

import android.R;
import android.app.ActivityThread;
import android.app.Application;
import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.graphics.Rect;
import android.os.Handler;
import android.provider.Settings;
import android.view.RemoteAnimationTarget;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.ClipRectAnimation;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import com.android.internal.policy.AttributeCache;
import com.android.internal.policy.TransitionAnimation;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
class TaskFragmentAnimationSpec {
    private static final int CHANGE_ANIMATION_DURATION = 517;
    private static final int CHANGE_ANIMATION_FADE_DURATION = 80;
    private static final int CHANGE_ANIMATION_FADE_OFFSET = 30;
    private static final String TAG = "TaskFragAnimationSpec";
    private final Context mContext;
    private final Interpolator mFastOutExtraSlowInInterpolator;
    private final LinearInterpolator mLinearInterpolator;
    private final TransitionAnimation mTransitionAnimation;
    private float mTransitionAnimationScaleSetting;

    TaskFragmentAnimationSpec(Handler handler) {
        Application application = ActivityThread.currentActivityThread().getApplication();
        this.mContext = application;
        this.mTransitionAnimation = new TransitionAnimation(application, false, TAG);
        AttributeCache.init(application);
        this.mFastOutExtraSlowInInterpolator = AnimationUtils.loadInterpolator(application, R.interpolator.fast_out_extra_slow_in);
        this.mLinearInterpolator = new LinearInterpolator();
        ContentResolver resolver = application.getContentResolver();
        this.mTransitionAnimationScaleSetting = Settings.Global.getFloat(resolver, "transition_animation_scale", application.getResources().getFloat(R.dimen.car_padding_4));
        resolver.registerContentObserver(Settings.Global.getUriFor("transition_animation_scale"), false, new SettingsObserver(handler));
    }

    static Animation createNoopAnimation(RemoteAnimationTarget target) {
        float alpha = target.mode == 1 ? 0.0f : 1.0f;
        return new AlphaAnimation(alpha, alpha);
    }

    Animation createChangeBoundsOpenAnimation(RemoteAnimationTarget target) {
        Rect bounds = target.localBounds;
        int startLeft = bounds.left == 0 ? -bounds.width() : bounds.width();
        Animation animation = new TranslateAnimation(startLeft, 0.0f, 0.0f, 0.0f);
        animation.setInterpolator(this.mFastOutExtraSlowInInterpolator);
        animation.setDuration(517L);
        animation.initialize(bounds.width(), bounds.height(), bounds.width(), bounds.height());
        animation.scaleCurrentDuration(this.mTransitionAnimationScaleSetting);
        return animation;
    }

    Animation createChangeBoundsCloseAnimation(RemoteAnimationTarget target) {
        Rect bounds = target.localBounds;
        int endLeft = bounds.left == 0 ? -bounds.width() : bounds.width();
        Animation animation = new TranslateAnimation(0.0f, endLeft, 0.0f, 0.0f);
        animation.setInterpolator(this.mFastOutExtraSlowInInterpolator);
        animation.setDuration(517L);
        animation.initialize(bounds.width(), bounds.height(), bounds.width(), bounds.height());
        animation.scaleCurrentDuration(this.mTransitionAnimationScaleSetting);
        return animation;
    }

    Animation[] createChangeBoundsChangeAnimations(RemoteAnimationTarget target) {
        Rect startBounds = target.startBounds;
        Rect parentBounds = target.taskInfo.configuration.windowConfiguration.getBounds();
        Rect endBounds = target.screenSpaceBounds;
        float scaleX = startBounds.width() / endBounds.width();
        float scaleY = startBounds.height() / endBounds.height();
        float startScaleX = 1.0f / scaleX;
        float startScaleY = 1.0f / scaleY;
        AnimationSet startSet = new AnimationSet(false);
        Animation startAlpha = new AlphaAnimation(1.0f, 0.0f);
        startAlpha.setInterpolator(this.mLinearInterpolator);
        startAlpha.setDuration(80L);
        startAlpha.setStartOffset(30L);
        startSet.addAnimation(startAlpha);
        Animation startScale = new ScaleAnimation(startScaleX, startScaleX, startScaleY, startScaleY);
        startScale.setInterpolator(this.mFastOutExtraSlowInInterpolator);
        startScale.setDuration(517L);
        startSet.addAnimation(startScale);
        startSet.initialize(startBounds.width(), startBounds.height(), endBounds.width(), endBounds.height());
        startSet.scaleCurrentDuration(this.mTransitionAnimationScaleSetting);
        AnimationSet endSet = new AnimationSet(true);
        endSet.setInterpolator(this.mFastOutExtraSlowInInterpolator);
        Animation endScale = new ScaleAnimation(scaleX, 1.0f, scaleY, 1.0f);
        endScale.setDuration(517L);
        endSet.addAnimation(endScale);
        Animation endTranslate = new TranslateAnimation(startBounds.left - endBounds.left, 0.0f, 0.0f, 0.0f);
        endTranslate.setDuration(517L);
        endSet.addAnimation(endTranslate);
        Rect startClip = new Rect(startBounds);
        Rect endClip = new Rect(endBounds);
        startClip.offsetTo(0, 0);
        endClip.offsetTo(0, 0);
        ClipRectAnimation clipRectAnimation = new ClipRectAnimation(startClip, endClip);
        clipRectAnimation.setDuration(517L);
        endSet.addAnimation(clipRectAnimation);
        endSet.initialize(startBounds.width(), startBounds.height(), parentBounds.width(), parentBounds.height());
        endSet.scaleCurrentDuration(this.mTransitionAnimationScaleSetting);
        return new Animation[]{startSet, endSet};
    }

    Animation loadOpenAnimation(RemoteAnimationTarget target, Rect wholeAnimationBounds) {
        int i;
        boolean isEnter = target.mode != 1;
        TransitionAnimation transitionAnimation = this.mTransitionAnimation;
        if (isEnter) {
            i = R.anim.task_fragment_clear_top_close_enter;
        } else {
            i = R.anim.task_fragment_clear_top_close_exit;
        }
        Animation animation = transitionAnimation.loadDefaultAnimationRes(i);
        animation.initialize(target.localBounds.width(), target.localBounds.height(), wholeAnimationBounds.width(), wholeAnimationBounds.height());
        animation.scaleCurrentDuration(this.mTransitionAnimationScaleSetting);
        return animation;
    }

    Animation loadCloseAnimation(RemoteAnimationTarget target, Rect wholeAnimationBounds) {
        int i;
        boolean isEnter = target.mode != 1;
        TransitionAnimation transitionAnimation = this.mTransitionAnimation;
        if (isEnter) {
            i = R.anim.task_close_enter;
        } else {
            i = R.anim.task_close_exit;
        }
        Animation animation = transitionAnimation.loadDefaultAnimationRes(i);
        animation.initialize(target.localBounds.width(), target.localBounds.height(), wholeAnimationBounds.width(), wholeAnimationBounds.height());
        animation.scaleCurrentDuration(this.mTransitionAnimationScaleSetting);
        return animation;
    }

    private class SettingsObserver extends ContentObserver {
        SettingsObserver(Handler handler) {
            super(handler);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange) {
            TaskFragmentAnimationSpec taskFragmentAnimationSpec = TaskFragmentAnimationSpec.this;
            taskFragmentAnimationSpec.mTransitionAnimationScaleSetting = Settings.Global.getFloat(taskFragmentAnimationSpec.mContext.getContentResolver(), "transition_animation_scale", TaskFragmentAnimationSpec.this.mTransitionAnimationScaleSetting);
        }
    }
}
