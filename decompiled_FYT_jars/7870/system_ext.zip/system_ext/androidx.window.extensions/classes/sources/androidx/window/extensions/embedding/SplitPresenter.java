package androidx.window.extensions.embedding;

import android.app.Activity;
import android.app.ActivityThread;
import android.app.WindowConfiguration;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Pair;
import android.util.Size;
import android.view.WindowInsets;
import android.view.WindowMetrics;
import android.window.WindowContainerTransaction;
import androidx.window.common.CommonFoldingFeature;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
class SplitPresenter extends JetpackTaskFragmentOrganizer {
    static final int POSITION_END = 1;
    static final int POSITION_FILL = 2;
    static final int POSITION_START = 0;
    static final int RESULT_EXPANDED = 1;
    static final int RESULT_EXPAND_FAILED_NO_TF_INFO = 2;
    static final int RESULT_NOT_EXPANDED = 0;
    private final SplitController mController;

    private @interface Position {
    }

    private @interface ResultCode {
    }

    SplitPresenter(Executor executor, SplitController controller) {
        super(executor, controller);
        this.mController = controller;
        registerOrganizer();
    }

    void updateContainer(TaskFragmentContainer container) {
        WindowContainerTransaction wct = new WindowContainerTransaction();
        this.mController.updateContainer(wct, container);
        applyTransaction(wct);
    }

    void cleanupContainer(TaskFragmentContainer container, boolean shouldFinishDependent) {
        WindowContainerTransaction wct = new WindowContainerTransaction();
        cleanupContainer(container, shouldFinishDependent, wct);
        applyTransaction(wct);
    }

    /* JADX WARN: Failed to analyze thrown exceptions
    java.util.ConcurrentModificationException
    	at java.base/java.util.ArrayList$Itr.checkForComodification(ArrayList.java:1096)
    	at java.base/java.util.ArrayList$Itr.next(ArrayList.java:1050)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.processInstructions(MethodThrowsVisitor.java:130)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.visit(MethodThrowsVisitor.java:68)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.checkInsn(MethodThrowsVisitor.java:178)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.processInstructions(MethodThrowsVisitor.java:131)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.visit(MethodThrowsVisitor.java:68)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.checkInsn(MethodThrowsVisitor.java:178)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.processInstructions(MethodThrowsVisitor.java:131)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.visit(MethodThrowsVisitor.java:68)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.checkInsn(MethodThrowsVisitor.java:178)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.processInstructions(MethodThrowsVisitor.java:131)
    	at jadx.core.dex.visitors.MethodThrowsVisitor.visit(MethodThrowsVisitor.java:68)
     */
    void cleanupContainer(TaskFragmentContainer container, boolean shouldFinishDependent, WindowContainerTransaction wct) {
        container.finish(shouldFinishDependent, this, wct, this.mController);
        TaskFragmentContainer newTopContainer = this.mController.getTopActiveContainer(container.getTaskId());
        if (newTopContainer != null) {
            this.mController.updateContainer(wct, newTopContainer);
        }
    }

    TaskFragmentContainer createNewSplitWithEmptySideContainer(WindowContainerTransaction wct, Activity primaryActivity, Intent secondaryIntent, SplitPairRule rule) {
        Rect parentBounds = getParentContainerBounds(primaryActivity);
        Pair<Size, Size> minDimensionsPair = getActivityIntentMinDimensionsPair(primaryActivity, secondaryIntent);
        Rect primaryRectBounds = getBoundsForPosition(POSITION_START, parentBounds, rule, primaryActivity, minDimensionsPair);
        TaskFragmentContainer primaryContainer = prepareContainerForActivity(wct, primaryActivity, primaryRectBounds, null);
        int taskId = primaryContainer.getTaskId();
        TaskFragmentContainer secondaryContainer = this.mController.newContainer(secondaryIntent, primaryActivity, taskId);
        Rect secondaryRectBounds = getBoundsForPosition(1, parentBounds, rule, primaryActivity, minDimensionsPair);
        int windowingMode = this.mController.getTaskContainer(taskId).getWindowingModeForSplitTaskFragment(secondaryRectBounds);
        createTaskFragment(wct, secondaryContainer.getTaskFragmentToken(), primaryActivity.getActivityToken(), secondaryRectBounds, windowingMode);
        setAdjacentTaskFragments(wct, primaryContainer, secondaryContainer, rule, minDimensionsPair);
        this.mController.registerSplit(wct, primaryContainer, primaryActivity, secondaryContainer, rule);
        return secondaryContainer;
    }

    void createNewSplitContainer(Activity primaryActivity, Activity secondaryActivity, SplitPairRule rule) {
        TaskFragmentContainer containerToAvoid;
        WindowContainerTransaction wct = new WindowContainerTransaction();
        Rect parentBounds = getParentContainerBounds(primaryActivity);
        Pair<Size, Size> minDimensionsPair = getActivitiesMinDimensionsPair(primaryActivity, secondaryActivity);
        Rect primaryRectBounds = getBoundsForPosition(POSITION_START, parentBounds, rule, primaryActivity, minDimensionsPair);
        TaskFragmentContainer primaryContainer = prepareContainerForActivity(wct, primaryActivity, primaryRectBounds, null);
        Rect secondaryRectBounds = getBoundsForPosition(1, parentBounds, rule, primaryActivity, minDimensionsPair);
        TaskFragmentContainer curSecondaryContainer = this.mController.getContainerWithActivity(secondaryActivity);
        if (rule.shouldClearTop() && curSecondaryContainer != null) {
            containerToAvoid = curSecondaryContainer;
        } else {
            containerToAvoid = primaryContainer;
        }
        TaskFragmentContainer secondaryContainer = prepareContainerForActivity(wct, secondaryActivity, secondaryRectBounds, containerToAvoid);
        setAdjacentTaskFragments(wct, primaryContainer, secondaryContainer, rule, minDimensionsPair);
        this.mController.registerSplit(wct, primaryContainer, primaryActivity, secondaryContainer, rule);
        applyTransaction(wct);
    }

    private TaskFragmentContainer prepareContainerForActivity(WindowContainerTransaction wct, Activity activity, Rect bounds, TaskFragmentContainer containerToAvoid) {
        TaskFragmentContainer container = this.mController.getContainerWithActivity(activity);
        int taskId = container != null ? container.getTaskId() : activity.getTaskId();
        if (container == null || container == containerToAvoid) {
            TaskFragmentContainer container2 = this.mController.newContainer(activity, taskId);
            int windowingMode = this.mController.getTaskContainer(taskId).getWindowingModeForSplitTaskFragment(bounds);
            createTaskFragment(wct, container2.getTaskFragmentToken(), activity.getActivityToken(), bounds, windowingMode);
            wct.reparentActivityToTaskFragment(container2.getTaskFragmentToken(), activity.getActivityToken());
            return container2;
        }
        resizeTaskFragmentIfRegistered(wct, container, bounds);
        int windowingMode2 = this.mController.getTaskContainer(taskId).getWindowingModeForSplitTaskFragment(bounds);
        updateTaskFragmentWindowingModeIfRegistered(wct, container, windowingMode2);
        return container;
    }

    void startActivityToSide(Activity launchingActivity, Intent activityIntent, Bundle activityOptions, SplitRule rule, boolean isPlaceholder) {
        TaskFragmentContainer primaryContainer;
        Rect parentBounds = getParentContainerBounds(launchingActivity);
        Pair<Size, Size> minDimensionsPair = getActivityIntentMinDimensionsPair(launchingActivity, activityIntent);
        Rect primaryRectBounds = getBoundsForPosition(POSITION_START, parentBounds, rule, launchingActivity, minDimensionsPair);
        Rect secondaryRectBounds = getBoundsForPosition(1, parentBounds, rule, launchingActivity, minDimensionsPair);
        TaskFragmentContainer primaryContainer2 = this.mController.getContainerWithActivity(launchingActivity);
        if (primaryContainer2 != null) {
            primaryContainer = primaryContainer2;
        } else {
            primaryContainer = this.mController.newContainer(launchingActivity, launchingActivity.getTaskId());
        }
        int taskId = primaryContainer.getTaskId();
        TaskFragmentContainer secondaryContainer = this.mController.newContainer(activityIntent, launchingActivity, taskId);
        int windowingMode = this.mController.getTaskContainer(taskId).getWindowingModeForSplitTaskFragment(primaryRectBounds);
        WindowContainerTransaction wct = new WindowContainerTransaction();
        this.mController.registerSplit(wct, primaryContainer, launchingActivity, secondaryContainer, rule);
        startActivityToSide(wct, primaryContainer.getTaskFragmentToken(), primaryRectBounds, launchingActivity, secondaryContainer.getTaskFragmentToken(), secondaryRectBounds, activityIntent, activityOptions, rule, windowingMode);
        if (isPlaceholder) {
            wct.requestFocusOnTaskFragment(primaryContainer.getTaskFragmentToken());
        }
        applyTransaction(wct);
    }

    void updateSplitContainer(SplitContainer splitContainer, TaskFragmentContainer updatedContainer, WindowContainerTransaction wct) {
        Rect parentBounds = getParentContainerBounds(updatedContainer);
        SplitRule rule = splitContainer.getSplitRule();
        TaskFragmentContainer primaryContainer = splitContainer.getPrimaryContainer();
        Activity activity = primaryContainer.getTopNonFinishingActivity();
        if (activity == null) {
            return;
        }
        Pair<Size, Size> minDimensionsPair = splitContainer.getMinDimensionsPair();
        boolean z = false;
        Rect primaryRectBounds = getBoundsForPosition(POSITION_START, parentBounds, rule, activity, minDimensionsPair);
        Rect secondaryRectBounds = getBoundsForPosition(1, parentBounds, rule, activity, minDimensionsPair);
        TaskFragmentContainer secondaryContainer = splitContainer.getSecondaryContainer();
        if (splitContainer.isPlaceholderContainer() && secondaryContainer.areLastRequestedBoundsEqual(null) && !secondaryRectBounds.isEmpty()) {
            z = true;
        }
        boolean isPlaceholderBecomingSplit = z;
        resizeTaskFragmentIfRegistered(wct, primaryContainer, primaryRectBounds);
        resizeTaskFragmentIfRegistered(wct, secondaryContainer, secondaryRectBounds);
        setAdjacentTaskFragments(wct, primaryContainer, secondaryContainer, rule, minDimensionsPair);
        if (isPlaceholderBecomingSplit) {
            wct.requestFocusOnTaskFragment(primaryContainer.getTaskFragmentToken());
        }
        TaskContainer taskContainer = updatedContainer.getTaskContainer();
        int windowingMode = taskContainer.getWindowingModeForSplitTaskFragment(primaryRectBounds);
        updateTaskFragmentWindowingModeIfRegistered(wct, primaryContainer, windowingMode);
        updateTaskFragmentWindowingModeIfRegistered(wct, secondaryContainer, windowingMode);
    }

    private void setAdjacentTaskFragments(WindowContainerTransaction wct, TaskFragmentContainer primaryContainer, TaskFragmentContainer secondaryContainer, SplitRule splitRule, Pair<Size, Size> minDimensionsPair) {
        Rect parentBounds = getParentContainerBounds(primaryContainer);
        if (!shouldShowSideBySide(parentBounds, splitRule, minDimensionsPair)) {
            setAdjacentTaskFragments(wct, primaryContainer.getTaskFragmentToken(), null, null);
        } else {
            setAdjacentTaskFragments(wct, primaryContainer.getTaskFragmentToken(), secondaryContainer.getTaskFragmentToken(), splitRule);
        }
    }

    void resizeTaskFragmentIfRegistered(WindowContainerTransaction wct, TaskFragmentContainer container, Rect bounds) {
        if (container.getInfo() == null) {
            return;
        }
        resizeTaskFragment(wct, container.getTaskFragmentToken(), bounds);
    }

    private void updateTaskFragmentWindowingModeIfRegistered(WindowContainerTransaction wct, TaskFragmentContainer container, int windowingMode) {
        if (container.getInfo() != null) {
            updateWindowingMode(wct, container.getTaskFragmentToken(), windowingMode);
        }
    }

    @Override // androidx.window.extensions.embedding.JetpackTaskFragmentOrganizer
    void createTaskFragment(WindowContainerTransaction wct, IBinder fragmentToken, IBinder ownerToken, Rect bounds, int windowingMode) {
        TaskFragmentContainer container = this.mController.getContainer(fragmentToken);
        if (container == null) {
            throw new IllegalStateException("Creating a task fragment that is not registered with controller.");
        }
        container.setLastRequestedBounds(bounds);
        container.setLastRequestedWindowingMode(windowingMode);
        super.createTaskFragment(wct, fragmentToken, ownerToken, bounds, windowingMode);
    }

    @Override // androidx.window.extensions.embedding.JetpackTaskFragmentOrganizer
    void resizeTaskFragment(WindowContainerTransaction wct, IBinder fragmentToken, Rect bounds) {
        TaskFragmentContainer container = this.mController.getContainer(fragmentToken);
        if (container == null) {
            throw new IllegalStateException("Resizing a task fragment that is not registered with controller.");
        }
        if (container.areLastRequestedBoundsEqual(bounds)) {
            return;
        }
        container.setLastRequestedBounds(bounds);
        super.resizeTaskFragment(wct, fragmentToken, bounds);
    }

    @Override // androidx.window.extensions.embedding.JetpackTaskFragmentOrganizer
    void updateWindowingMode(WindowContainerTransaction wct, IBinder fragmentToken, int windowingMode) {
        TaskFragmentContainer container = this.mController.getContainer(fragmentToken);
        if (container == null) {
            throw new IllegalStateException("Setting windowing mode for a task fragment that is not registered with controller.");
        }
        if (container.isLastRequestedWindowingModeEqual(windowingMode)) {
            return;
        }
        container.setLastRequestedWindowingMode(windowingMode);
        super.updateWindowingMode(wct, fragmentToken, windowingMode);
    }

    int expandSplitContainerIfNeeded(WindowContainerTransaction wct, SplitContainer splitContainer, Activity primaryActivity, Activity secondaryActivity, Intent secondaryIntent) {
        Pair<Size, Size> minDimensionsPair;
        if (secondaryActivity == null && secondaryIntent == null) {
            throw new IllegalArgumentException("Either secondaryActivity or secondaryIntent must be non-null.");
        }
        Rect taskBounds = getParentContainerBounds(primaryActivity);
        if (secondaryActivity != null) {
            minDimensionsPair = getActivitiesMinDimensionsPair(primaryActivity, secondaryActivity);
        } else {
            minDimensionsPair = getActivityIntentMinDimensionsPair(primaryActivity, secondaryIntent);
        }
        if (!shouldShowSideBySide(taskBounds, splitContainer.getSplitRule(), minDimensionsPair)) {
            if (splitContainer.getPrimaryContainer().getInfo() == null || splitContainer.getSecondaryContainer().getInfo() == null) {
                return 2;
            }
            expandTaskFragment(wct, splitContainer.getPrimaryContainer().getTaskFragmentToken());
            expandTaskFragment(wct, splitContainer.getSecondaryContainer().getTaskFragmentToken());
            return 1;
        }
        return POSITION_START;
    }

    static boolean shouldShowSideBySide(Rect parentBounds, SplitRule rule) {
        return shouldShowSideBySide(parentBounds, rule, null);
    }

    static boolean shouldShowSideBySide(SplitContainer splitContainer) {
        Rect parentBounds = getParentContainerBounds(splitContainer.getPrimaryContainer());
        return shouldShowSideBySide(parentBounds, splitContainer.getSplitRule(), splitContainer.getMinDimensionsPair());
    }

    static boolean shouldShowSideBySide(Rect parentBounds, SplitRule rule, Pair<Size, Size> minDimensionsPair) {
        WindowMetrics parentMetrics = new WindowMetrics(parentBounds, new WindowInsets(new Rect()));
        if (!rule.checkParentMetrics(parentMetrics)) {
            return false;
        }
        float splitRatio = rule.getSplitRatio();
        Rect primaryBounds = getPrimaryBounds(parentBounds, splitRatio, true);
        Rect secondaryBounds = getSecondaryBounds(parentBounds, splitRatio, true);
        if (minDimensionsPair == null) {
            return true;
        }
        return (boundsSmallerThanMinDimensions(primaryBounds, (Size) minDimensionsPair.first) || boundsSmallerThanMinDimensions(secondaryBounds, (Size) minDimensionsPair.second)) ? false : true;
    }

    static Pair<Size, Size> getActivitiesMinDimensionsPair(Activity primaryActivity, Activity secondaryActivity) {
        return new Pair<>(getMinDimensions(primaryActivity), getMinDimensions(secondaryActivity));
    }

    static Pair<Size, Size> getActivityIntentMinDimensionsPair(Activity primaryActivity, Intent secondaryIntent) {
        return new Pair<>(getMinDimensions(primaryActivity), getMinDimensions(secondaryIntent));
    }

    static Size getMinDimensions(Activity activity) {
        ActivityInfo.WindowLayout windowLayout;
        if (activity == null || (windowLayout = activity.getActivityInfo().windowLayout) == null) {
            return null;
        }
        return new Size(windowLayout.minWidth, windowLayout.minHeight);
    }

    static Size getMinDimensions(Intent intent) {
        ActivityInfo activityInfo;
        ActivityInfo.WindowLayout windowLayout;
        if (intent == null) {
            return null;
        }
        PackageManager packageManager = ActivityThread.currentActivityThread().getApplication().getPackageManager();
        ResolveInfo resolveInfo = packageManager.resolveActivity(intent, PackageManager.ResolveInfoFlags.of(131072L));
        if (resolveInfo == null || (activityInfo = resolveInfo.activityInfo) == null || (windowLayout = activityInfo.windowLayout) == null) {
            return null;
        }
        return new Size(windowLayout.minWidth, windowLayout.minHeight);
    }

    static boolean boundsSmallerThanMinDimensions(Rect bounds, Size minDimensions) {
        if (minDimensions == null) {
            return false;
        }
        return bounds.width() < minDimensions.getWidth() || bounds.height() < minDimensions.getHeight();
    }

    static Rect getBoundsForPosition(int position, Rect parentBounds, SplitRule rule, Activity primaryActivity, Pair<Size, Size> minDimensionsPair) {
        if (!shouldShowSideBySide(parentBounds, rule, minDimensionsPair)) {
            return new Rect();
        }
        boolean isLtr = isLtr(primaryActivity, rule);
        float splitRatio = rule.getSplitRatio();
        switch (position) {
            case POSITION_START /* 0 */:
                return getPrimaryBounds(parentBounds, splitRatio, isLtr);
            case 1:
                return getSecondaryBounds(parentBounds, splitRatio, isLtr);
            default:
                return new Rect();
        }
    }

    private static Rect getPrimaryBounds(Rect parentBounds, float splitRatio, boolean isLtr) {
        return isLtr ? getLeftContainerBounds(parentBounds, splitRatio) : getRightContainerBounds(parentBounds, 1.0f - splitRatio);
    }

    private static Rect getSecondaryBounds(Rect parentBounds, float splitRatio, boolean isLtr) {
        return isLtr ? getRightContainerBounds(parentBounds, splitRatio) : getLeftContainerBounds(parentBounds, 1.0f - splitRatio);
    }

    private static Rect getLeftContainerBounds(Rect parentBounds, float splitRatio) {
        return new Rect(parentBounds.left, parentBounds.top, (int) (parentBounds.left + (parentBounds.width() * splitRatio)), parentBounds.bottom);
    }

    private static Rect getRightContainerBounds(Rect parentBounds, float splitRatio) {
        return new Rect((int) (parentBounds.left + (parentBounds.width() * splitRatio)), parentBounds.top, parentBounds.right, parentBounds.bottom);
    }

    private static boolean isLtr(Context context, SplitRule rule) {
        switch (rule.getLayoutDirection()) {
            case 1:
                return false;
            case 2:
            default:
                return true;
            case CommonFoldingFeature.COMMON_STATE_FLAT /* 3 */:
                return context.getResources().getConfiguration().getLayoutDirection() == 0;
        }
    }

    static Rect getParentContainerBounds(TaskFragmentContainer container) {
        return container.getTaskContainer().getTaskBounds();
    }

    Rect getParentContainerBounds(Activity activity) {
        TaskFragmentContainer container = this.mController.getContainerWithActivity(activity);
        if (container != null) {
            return getParentContainerBounds(container);
        }
        return getNonEmbeddedActivityBounds(activity);
    }

    static Rect getNonEmbeddedActivityBounds(Activity activity) {
        WindowConfiguration windowConfiguration = activity.getResources().getConfiguration().windowConfiguration;
        if (!activity.isInMultiWindowMode()) {
            return windowConfiguration.getMaxBounds();
        }
        return windowConfiguration.getBounds();
    }
}
