package androidx.window.extensions.layout;

import android.app.Activity;
import java.util.function.Consumer;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public interface WindowLayoutComponent {
    void addWindowLayoutInfoListener(Activity activity, Consumer<WindowLayoutInfo> consumer);

    void removeWindowLayoutInfoListener(Consumer<WindowLayoutInfo> consumer);
}
