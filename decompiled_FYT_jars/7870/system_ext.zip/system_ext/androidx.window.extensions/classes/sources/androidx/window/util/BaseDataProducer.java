package androidx.window.util;

import java.util.LinkedHashSet;
import java.util.Set;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public abstract class BaseDataProducer<T> implements DataProducer<T> {
    private final Set<Runnable> mCallbacks = new LinkedHashSet();

    @Override // androidx.window.util.DataProducer
    public final void addDataChangedCallback(Runnable callback) {
        this.mCallbacks.add(callback);
        onListenersChanged(this.mCallbacks);
    }

    @Override // androidx.window.util.DataProducer
    public final void removeDataChangedCallback(Runnable callback) {
        this.mCallbacks.remove(callback);
        onListenersChanged(this.mCallbacks);
    }

    protected void onListenersChanged(Set<Runnable> callbacks) {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void notifyDataChanged() {
        for (Runnable callback : this.mCallbacks) {
            callback.run();
        }
    }
}
