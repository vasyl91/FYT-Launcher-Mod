package androidx.window.extensions.embedding;

import android.app.Activity;
import android.content.Intent;
import android.view.WindowMetrics;
import java.util.function.Predicate;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public class SplitPlaceholderRule extends SplitRule {
    private final Predicate<Activity> mActivityPredicate;
    private final int mFinishPrimaryWithSecondary;
    private final Predicate<Intent> mIntentPredicate;
    private final boolean mIsSticky;
    private final Intent mPlaceholderIntent;

    SplitPlaceholderRule(Intent placeholderIntent, float splitRatio, int layoutDirection, boolean isSticky, int finishPrimaryWithSecondary, Predicate<Activity> activityPredicate, Predicate<Intent> intentPredicate, Predicate<WindowMetrics> parentWindowMetricsPredicate) {
        super(parentWindowMetricsPredicate, splitRatio, layoutDirection);
        this.mIsSticky = isSticky;
        this.mFinishPrimaryWithSecondary = finishPrimaryWithSecondary;
        this.mActivityPredicate = activityPredicate;
        this.mIntentPredicate = intentPredicate;
        this.mPlaceholderIntent = placeholderIntent;
    }

    public boolean matchesActivity(Activity activity) {
        return this.mActivityPredicate.test(activity);
    }

    public boolean matchesIntent(Intent intent) {
        return this.mIntentPredicate.test(intent);
    }

    public Intent getPlaceholderIntent() {
        return this.mPlaceholderIntent;
    }

    public boolean isSticky() {
        return this.mIsSticky;
    }

    public int getFinishPrimaryWithSecondary() {
        return this.mFinishPrimaryWithSecondary;
    }

    public static final class Builder {
        private final Predicate<Activity> mActivityPredicate;
        private final Predicate<Intent> mIntentPredicate;
        private int mLayoutDirection;
        private final Predicate<WindowMetrics> mParentWindowMetricsPredicate;
        private final Intent mPlaceholderIntent;
        private float mSplitRatio;
        private boolean mIsSticky = false;
        private int mFinishPrimaryWithSecondary = 1;

        public Builder(Intent placeholderIntent, Predicate<Activity> activityPredicate, Predicate<Intent> intentPredicate, Predicate<WindowMetrics> parentWindowMetricsPredicate) {
            this.mActivityPredicate = activityPredicate;
            this.mIntentPredicate = intentPredicate;
            this.mPlaceholderIntent = placeholderIntent;
            this.mParentWindowMetricsPredicate = parentWindowMetricsPredicate;
        }

        public Builder setSplitRatio(float splitRatio) {
            this.mSplitRatio = splitRatio;
            return this;
        }

        public Builder setLayoutDirection(int layoutDirection) {
            this.mLayoutDirection = layoutDirection;
            return this;
        }

        public Builder setSticky(boolean sticky) {
            this.mIsSticky = sticky;
            return this;
        }

        public Builder setFinishPrimaryWithSecondary(int finishBehavior) {
            this.mFinishPrimaryWithSecondary = finishBehavior;
            return this;
        }

        public SplitPlaceholderRule build() {
            return new SplitPlaceholderRule(this.mPlaceholderIntent, this.mSplitRatio, this.mLayoutDirection, this.mIsSticky, this.mFinishPrimaryWithSecondary, this.mActivityPredicate, this.mIntentPredicate, this.mParentWindowMetricsPredicate);
        }
    }

    @Override // androidx.window.extensions.embedding.SplitRule
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof SplitPlaceholderRule) || !super.equals(o)) {
            return false;
        }
        SplitPlaceholderRule that = (SplitPlaceholderRule) o;
        if (this.mIsSticky == that.mIsSticky && this.mFinishPrimaryWithSecondary == that.mFinishPrimaryWithSecondary && this.mActivityPredicate.equals(that.mActivityPredicate) && this.mIntentPredicate.equals(that.mIntentPredicate)) {
            return this.mPlaceholderIntent.equals(that.mPlaceholderIntent);
        }
        return false;
    }

    @Override // androidx.window.extensions.embedding.SplitRule
    public int hashCode() {
        return (((((((((super.hashCode() * 31) + this.mActivityPredicate.hashCode()) * 31) + this.mIntentPredicate.hashCode()) * 31) + this.mPlaceholderIntent.hashCode()) * 31) + (this.mIsSticky ? 1 : 0)) * 31) + this.mFinishPrimaryWithSecondary;
    }

    @Override // androidx.window.extensions.embedding.SplitRule
    public String toString() {
        return "SplitPlaceholderRule{mActivityPredicate=" + this.mActivityPredicate + ", mIsSticky=" + this.mIsSticky + ", mFinishPrimaryWithPlaceholder=" + this.mFinishPrimaryWithSecondary + '}';
    }
}
