package androidx.window.extensions;

import android.app.ActivityThread;
import android.content.Context;
import androidx.window.extensions.embedding.ActivityEmbeddingComponent;
import androidx.window.extensions.embedding.SplitController;
import androidx.window.extensions.layout.WindowLayoutComponent;
import androidx.window.extensions.layout.WindowLayoutComponentImpl;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public class WindowExtensionsImpl implements WindowExtensions {
    private final Object mLock = new Object();
    private volatile SplitController mSplitController;
    private volatile WindowLayoutComponent mWindowLayoutComponent;

    @Override // androidx.window.extensions.WindowExtensions
    public int getVendorApiLevel() {
        return 1;
    }

    @Override // androidx.window.extensions.WindowExtensions
    public WindowLayoutComponent getWindowLayoutComponent() {
        if (this.mWindowLayoutComponent == null) {
            synchronized (this.mLock) {
                if (this.mWindowLayoutComponent == null) {
                    Context context = ActivityThread.currentApplication();
                    this.mWindowLayoutComponent = new WindowLayoutComponentImpl(context);
                }
            }
        }
        return this.mWindowLayoutComponent;
    }

    @Override // androidx.window.extensions.WindowExtensions
    public ActivityEmbeddingComponent getActivityEmbeddingComponent() {
        if (this.mSplitController == null) {
            synchronized (this.mLock) {
                if (this.mSplitController == null) {
                    this.mSplitController = new SplitController();
                }
            }
        }
        return this.mSplitController;
    }
}
