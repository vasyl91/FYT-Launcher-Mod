package androidx.window.util;

import android.app.Activity;
import android.graphics.Rect;
import android.hardware.display.DisplayManagerGlobal;
import android.view.DisplayInfo;
import androidx.window.common.CommonFoldingFeature;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public final class ExtensionHelper {
    private ExtensionHelper() {
    }

    public static void rotateRectToDisplayRotation(int displayId, Rect inOutRect) {
        DisplayManagerGlobal dmGlobal = DisplayManagerGlobal.getInstance();
        DisplayInfo displayInfo = dmGlobal.getDisplayInfo(displayId);
        int rotation = displayInfo.rotation;
        boolean isSideRotation = true;
        if (rotation != 1 && rotation != 3) {
            isSideRotation = false;
        }
        int displayWidth = isSideRotation ? displayInfo.logicalHeight : displayInfo.logicalWidth;
        int displayHeight = isSideRotation ? displayInfo.logicalWidth : displayInfo.logicalHeight;
        inOutRect.intersect(0, 0, displayWidth, displayHeight);
        rotateBounds(inOutRect, displayWidth, displayHeight, rotation);
    }

    private static void rotateBounds(Rect inOutRect, int parentWidth, int parentHeight, int delta) {
        int origLeft = inOutRect.left;
        switch (delta) {
            case 1:
                inOutRect.left = inOutRect.top;
                inOutRect.top = parentWidth - inOutRect.right;
                inOutRect.right = inOutRect.bottom;
                inOutRect.bottom = parentWidth - origLeft;
                break;
            case 2:
                inOutRect.left = parentWidth - inOutRect.right;
                inOutRect.right = parentWidth - origLeft;
                break;
            case CommonFoldingFeature.COMMON_STATE_FLAT /* 3 */:
                inOutRect.left = parentHeight - inOutRect.bottom;
                inOutRect.bottom = inOutRect.right;
                inOutRect.right = parentHeight - inOutRect.top;
                inOutRect.top = origLeft;
                break;
        }
    }

    public static void transformToWindowSpaceRect(Activity activity, Rect inOutRect) {
        Rect windowRect = getWindowBounds(activity);
        if (windowRect == null) {
            inOutRect.setEmpty();
        } else if (!Rect.intersects(inOutRect, windowRect)) {
            inOutRect.setEmpty();
        } else {
            inOutRect.intersect(windowRect);
            inOutRect.offset(-windowRect.left, -windowRect.top);
        }
    }

    private static Rect getWindowBounds(Activity activity) {
        return activity.getWindowManager().getCurrentWindowMetrics().getBounds();
    }

    public static boolean isZero(Rect rect) {
        return rect.height() == 0 && rect.width() == 0;
    }
}
