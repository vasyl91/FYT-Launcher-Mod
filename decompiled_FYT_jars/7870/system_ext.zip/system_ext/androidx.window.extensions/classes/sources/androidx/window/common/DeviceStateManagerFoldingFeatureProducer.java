package androidx.window.common;

import android.R;
import android.content.Context;
import android.hardware.devicestate.DeviceStateManager;
import android.text.TextUtils;
import android.util.SparseIntArray;
import androidx.window.util.BaseDataProducer;
import androidx.window.util.DataProducer;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public final class DeviceStateManagerFoldingFeatureProducer extends BaseDataProducer<List<CommonFoldingFeature>> {
    private static final boolean DEBUG = false;
    private static final String TAG = DeviceStateManagerFoldingFeatureProducer.class.getSimpleName();
    private final DataProducer<String> mRawFoldSupplier;
    private final SparseIntArray mDeviceStateToPostureMap = new SparseIntArray();
    private int mCurrentDeviceState = -1;
    private final DeviceStateManager.DeviceStateCallback mDeviceStateCallback = new DeviceStateManager.DeviceStateCallback() { // from class: androidx.window.common.DeviceStateManagerFoldingFeatureProducer$$ExternalSyntheticLambda0
        public final void onStateChanged(int i) {
            this.f$0.m0x5ec89acd(i);
        }
    };

    /* JADX INFO: renamed from: lambda$new$0$androidx-window-common-DeviceStateManagerFoldingFeatureProducer, reason: not valid java name */
    /* synthetic */ void m0x5ec89acd(int state) {
        this.mCurrentDeviceState = state;
        notifyDataChanged();
    }

    public DeviceStateManagerFoldingFeatureProducer(Context context, DataProducer<String> rawFoldSupplier) {
        this.mRawFoldSupplier = rawFoldSupplier;
        String[] deviceStatePosturePairs = context.getResources().getStringArray(R.array.config_defaultCloudSearchServices);
        for (String deviceStatePosturePair : deviceStatePosturePairs) {
            String[] deviceStatePostureMapping = deviceStatePosturePair.split(":");
            if (deviceStatePostureMapping.length == 2) {
                try {
                    int deviceState = Integer.parseInt(deviceStatePostureMapping[0]);
                    int posture = Integer.parseInt(deviceStatePostureMapping[1]);
                    this.mDeviceStateToPostureMap.put(deviceState, posture);
                } catch (NumberFormatException e) {
                }
            }
        }
        if (this.mDeviceStateToPostureMap.size() > 0) {
            ((DeviceStateManager) context.getSystemService(DeviceStateManager.class)).registerCallback(context.getMainExecutor(), this.mDeviceStateCallback);
        }
    }

    @Override // androidx.window.util.DataProducer
    public Optional<List<CommonFoldingFeature>> getData() {
        int globalHingeState = globalHingeState();
        Optional<String> displayFeaturesString = this.mRawFoldSupplier.getData();
        if (displayFeaturesString.isEmpty() || TextUtils.isEmpty(displayFeaturesString.get())) {
            return Optional.empty();
        }
        return Optional.of(CommonFoldingFeature.parseListFromString(displayFeaturesString.get(), globalHingeState));
    }

    @Override // androidx.window.util.BaseDataProducer
    protected void onListenersChanged(Set<Runnable> callbacks) {
        super.onListenersChanged(callbacks);
        if (callbacks.isEmpty()) {
            this.mRawFoldSupplier.removeDataChangedCallback(new Runnable() { // from class: androidx.window.common.DeviceStateManagerFoldingFeatureProducer$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.notifyDataChanged();
                }
            });
        } else {
            this.mRawFoldSupplier.addDataChangedCallback(new Runnable() { // from class: androidx.window.common.DeviceStateManagerFoldingFeatureProducer$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.notifyDataChanged();
                }
            });
        }
    }

    private int globalHingeState() {
        return this.mDeviceStateToPostureMap.get(this.mCurrentDeviceState, -1);
    }
}
