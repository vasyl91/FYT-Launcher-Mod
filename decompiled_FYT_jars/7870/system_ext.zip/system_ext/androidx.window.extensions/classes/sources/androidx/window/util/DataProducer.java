package androidx.window.util;

import java.util.Optional;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public interface DataProducer<T> {
    void addDataChangedCallback(Runnable runnable);

    Optional<T> getData();

    void removeDataChangedCallback(Runnable runnable);
}
