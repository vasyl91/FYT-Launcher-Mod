package androidx.window.extensions.embedding;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Binder;
import android.os.IBinder;
import android.util.Size;
import android.window.TaskFragmentInfo;
import android.window.WindowContainerTransaction;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
class TaskFragmentContainer {
    private static final int APPEAR_EMPTY_TIMEOUT_MS = 3000;
    Runnable mAppearEmptyTimeout;
    private final SplitController mController;
    TaskFragmentInfo mInfo;
    private boolean mIsFinished;
    private Intent mPendingAppearedIntent;
    private final TaskContainer mTaskContainer;
    private final IBinder mToken;
    final ArrayList<Activity> mPendingAppearedActivities = new ArrayList<>();
    private final List<TaskFragmentContainer> mContainersToFinishOnExit = new ArrayList();
    private final List<Activity> mActivitiesToFinishOnExit = new ArrayList();
    private final Rect mLastRequestedBounds = new Rect();
    private int mLastRequestedWindowingMode = 0;

    TaskFragmentContainer(Activity pendingAppearedActivity, Intent pendingAppearedIntent, TaskContainer taskContainer, SplitController controller) {
        if ((pendingAppearedActivity == null && pendingAppearedIntent == null) || (pendingAppearedActivity != null && pendingAppearedIntent != null)) {
            throw new IllegalArgumentException("One and only one of pending activity and intent must be non-null");
        }
        this.mController = controller;
        this.mToken = new Binder("TaskFragmentContainer");
        this.mTaskContainer = taskContainer;
        taskContainer.mContainers.add(this);
        if (pendingAppearedActivity != null) {
            addPendingAppearedActivity(pendingAppearedActivity);
        }
        this.mPendingAppearedIntent = pendingAppearedIntent;
    }

    IBinder getTaskFragmentToken() {
        return this.mToken;
    }

    List<Activity> collectNonFinishingActivities() {
        List<Activity> allActivities = new ArrayList<>();
        TaskFragmentInfo taskFragmentInfo = this.mInfo;
        if (taskFragmentInfo != null) {
            for (IBinder token : taskFragmentInfo.getActivities()) {
                Activity activity = this.mController.getActivity(token);
                if (activity != null && !activity.isFinishing()) {
                    allActivities.add(activity);
                }
            }
        }
        for (Activity activity2 : this.mPendingAppearedActivities) {
            if (!activity2.isFinishing()) {
                allActivities.add(activity2);
            }
        }
        return allActivities;
    }

    boolean taskInfoActivityCountMatchesCreated() {
        return this.mInfo != null && this.mPendingAppearedActivities.isEmpty() && this.mInfo.getActivities().size() == collectNonFinishingActivities().size();
    }

    ActivityStack toActivityStack() {
        return new ActivityStack(collectNonFinishingActivities(), isEmpty());
    }

    void addPendingAppearedActivity(Activity pendingAppearedActivity) {
        if (hasActivity(pendingAppearedActivity.getActivityToken())) {
            return;
        }
        this.mTaskContainer.cleanupPendingAppearedActivity(pendingAppearedActivity);
        this.mPendingAppearedActivities.add(pendingAppearedActivity);
    }

    void removePendingAppearedActivity(Activity pendingAppearedActivity) {
        this.mPendingAppearedActivities.remove(pendingAppearedActivity);
    }

    Intent getPendingAppearedIntent() {
        return this.mPendingAppearedIntent;
    }

    boolean hasActivity(IBinder token) {
        TaskFragmentInfo taskFragmentInfo = this.mInfo;
        if (taskFragmentInfo != null && taskFragmentInfo.getActivities().contains(token)) {
            return true;
        }
        for (Activity activity : this.mPendingAppearedActivities) {
            if (activity.getActivityToken().equals(token)) {
                return true;
            }
        }
        return false;
    }

    int getRunningActivityCount() {
        int count = this.mPendingAppearedActivities.size();
        TaskFragmentInfo taskFragmentInfo = this.mInfo;
        if (taskFragmentInfo != null) {
            return count + taskFragmentInfo.getRunningActivityCount();
        }
        return count;
    }

    boolean isWaitingActivityAppear() {
        return !this.mIsFinished && (this.mInfo == null || this.mAppearEmptyTimeout != null);
    }

    TaskFragmentInfo getInfo() {
        return this.mInfo;
    }

    void setInfo(TaskFragmentInfo info) {
        if (!this.mIsFinished && this.mInfo == null && info.isEmpty()) {
            this.mAppearEmptyTimeout = new Runnable() { // from class: androidx.window.extensions.embedding.TaskFragmentContainer$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m12x973fadfb();
                }
            };
            this.mController.getHandler().postDelayed(this.mAppearEmptyTimeout, 3000L);
        } else if (this.mAppearEmptyTimeout != null && !info.isEmpty()) {
            this.mController.getHandler().removeCallbacks(this.mAppearEmptyTimeout);
            this.mAppearEmptyTimeout = null;
        }
        this.mInfo = info;
        if (info == null || info.isEmpty()) {
            return;
        }
        this.mPendingAppearedIntent = null;
        if (this.mPendingAppearedActivities.isEmpty()) {
            return;
        }
        List<IBinder> infoActivities = this.mInfo.getActivities();
        for (int i = this.mPendingAppearedActivities.size() - 1; i >= 0; i--) {
            Activity activity = this.mPendingAppearedActivities.get(i);
            if (infoActivities.contains(activity.getActivityToken())) {
                this.mPendingAppearedActivities.remove(i);
            }
        }
    }

    /* JADX INFO: renamed from: lambda$setInfo$0$androidx-window-extensions-embedding-TaskFragmentContainer, reason: not valid java name */
    /* synthetic */ void m12x973fadfb() {
        this.mAppearEmptyTimeout = null;
        this.mController.onTaskFragmentAppearEmptyTimeout(this);
    }

    Activity getTopNonFinishingActivity() {
        List<Activity> activities = collectNonFinishingActivities();
        if (activities.isEmpty()) {
            return null;
        }
        return activities.get(activities.size() - 1);
    }

    Activity getBottomMostActivity() {
        List<Activity> activities = collectNonFinishingActivities();
        if (activities.isEmpty()) {
            return null;
        }
        return activities.get(0);
    }

    boolean isEmpty() {
        TaskFragmentInfo taskFragmentInfo;
        return this.mPendingAppearedActivities.isEmpty() && ((taskFragmentInfo = this.mInfo) == null || taskFragmentInfo.isEmpty());
    }

    void addContainerToFinishOnExit(TaskFragmentContainer containerToFinish) {
        if (this.mIsFinished) {
            return;
        }
        this.mContainersToFinishOnExit.add(containerToFinish);
    }

    void removeContainerToFinishOnExit(TaskFragmentContainer containerToRemove) {
        if (this.mIsFinished) {
            return;
        }
        this.mContainersToFinishOnExit.remove(containerToRemove);
    }

    void addActivityToFinishOnExit(Activity activityToFinish) {
        if (this.mIsFinished) {
            return;
        }
        this.mActivitiesToFinishOnExit.add(activityToFinish);
    }

    void removeActivityToFinishOnExit(Activity activityToRemove) {
        if (this.mIsFinished) {
            return;
        }
        this.mActivitiesToFinishOnExit.remove(activityToRemove);
    }

    void resetDependencies() {
        if (this.mIsFinished) {
            return;
        }
        this.mContainersToFinishOnExit.clear();
        this.mActivitiesToFinishOnExit.clear();
    }

    void finish(boolean shouldFinishDependent, SplitPresenter presenter, WindowContainerTransaction wct, SplitController controller) {
        if (!this.mIsFinished) {
            this.mIsFinished = true;
            if (this.mAppearEmptyTimeout != null) {
                this.mController.getHandler().removeCallbacks(this.mAppearEmptyTimeout);
                this.mAppearEmptyTimeout = null;
            }
            finishActivities(shouldFinishDependent, presenter, wct, controller);
        }
        if (this.mInfo == null) {
            return;
        }
        presenter.deleteTaskFragment(wct, getTaskFragmentToken());
        controller.removeContainer(this);
        this.mInfo = null;
    }

    private void finishActivities(boolean shouldFinishDependent, SplitPresenter presenter, WindowContainerTransaction wct, SplitController controller) {
        for (Activity activity : collectNonFinishingActivities()) {
            if (!activity.isFinishing() && this.mController.getContainerWithActivity(activity) == this) {
                activity.finish();
            }
        }
        if (!shouldFinishDependent) {
            return;
        }
        for (TaskFragmentContainer container : this.mContainersToFinishOnExit) {
            if (!container.mIsFinished && !controller.shouldRetainAssociatedContainer(this, container)) {
                container.finish(true, presenter, wct, controller);
            }
        }
        this.mContainersToFinishOnExit.clear();
        for (Activity activity2 : this.mActivitiesToFinishOnExit) {
            if (!activity2.isFinishing() && !controller.shouldRetainAssociatedActivity(this, activity2)) {
                activity2.finish();
            }
        }
        this.mActivitiesToFinishOnExit.clear();
    }

    boolean isFinished() {
        return this.mIsFinished;
    }

    boolean areLastRequestedBoundsEqual(Rect bounds) {
        return (bounds == null && this.mLastRequestedBounds.isEmpty()) || this.mLastRequestedBounds.equals(bounds);
    }

    void setLastRequestedBounds(Rect bounds) {
        if (bounds == null) {
            this.mLastRequestedBounds.setEmpty();
        } else {
            this.mLastRequestedBounds.set(bounds);
        }
    }

    Rect getLastRequestedBounds() {
        return this.mLastRequestedBounds;
    }

    boolean isLastRequestedWindowingModeEqual(int windowingMode) {
        return this.mLastRequestedWindowingMode == windowingMode;
    }

    void setLastRequestedWindowingMode(int windowingModes) {
        this.mLastRequestedWindowingMode = windowingModes;
    }

    int getTaskId() {
        return this.mTaskContainer.getTaskId();
    }

    TaskContainer getTaskContainer() {
        return this.mTaskContainer;
    }

    Size getMinDimensions() {
        Size minDimensions;
        TaskFragmentInfo taskFragmentInfo = this.mInfo;
        if (taskFragmentInfo == null) {
            return null;
        }
        int maxMinWidth = taskFragmentInfo.getMinimumWidth();
        int maxMinHeight = this.mInfo.getMinimumHeight();
        for (Activity activity : this.mPendingAppearedActivities) {
            Size minDimensions2 = SplitPresenter.getMinDimensions(activity);
            if (minDimensions2 != null) {
                maxMinWidth = Math.max(maxMinWidth, minDimensions2.getWidth());
                maxMinHeight = Math.max(maxMinHeight, minDimensions2.getHeight());
            }
        }
        Intent intent = this.mPendingAppearedIntent;
        if (intent != null && (minDimensions = SplitPresenter.getMinDimensions(intent)) != null) {
            maxMinWidth = Math.max(maxMinWidth, minDimensions.getWidth());
            maxMinHeight = Math.max(maxMinHeight, minDimensions.getHeight());
        }
        return new Size(maxMinWidth, maxMinHeight);
    }

    public String toString() {
        return toString(true);
    }

    private String toString(boolean includeContainersToFinishOnExit) {
        return "TaskFragmentContainer{ parentTaskId=" + getTaskId() + " token=" + this.mToken + " topNonFinishingActivity=" + getTopNonFinishingActivity() + " runningActivityCount=" + getRunningActivityCount() + " isFinished=" + this.mIsFinished + " lastRequestedBounds=" + this.mLastRequestedBounds + " pendingAppearedActivities=" + this.mPendingAppearedActivities + (includeContainersToFinishOnExit ? " containersToFinishOnExit=" + containersToFinishOnExitToString() : "") + " activitiesToFinishOnExit=" + this.mActivitiesToFinishOnExit + " info=" + this.mInfo + "}";
    }

    private String containersToFinishOnExitToString() {
        StringBuilder sb = new StringBuilder("[");
        Iterator<TaskFragmentContainer> containerIterator = this.mContainersToFinishOnExit.iterator();
        while (containerIterator.hasNext()) {
            sb.append(containerIterator.next().toString(false));
            if (containerIterator.hasNext()) {
                sb.append(", ");
            }
        }
        return sb.append("]").toString();
    }
}
