package androidx.window.extensions.embedding;

import android.app.Activity;
import android.app.WindowConfiguration;
import android.graphics.Rect;
import android.os.IBinder;
import android.util.ArraySet;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
class TaskContainer {
    private final int mTaskId;
    private final Rect mTaskBounds = new Rect();
    private int mWindowingMode = 0;
    final List<TaskFragmentContainer> mContainers = new ArrayList();
    final List<SplitContainer> mSplitContainers = new ArrayList();
    final Set<IBinder> mFinishedContainer = new ArraySet();

    TaskContainer(int taskId) {
        if (taskId == -1) {
            throw new IllegalArgumentException("Invalid Task id");
        }
        this.mTaskId = taskId;
    }

    int getTaskId() {
        return this.mTaskId;
    }

    Rect getTaskBounds() {
        return this.mTaskBounds;
    }

    boolean setTaskBounds(Rect taskBounds) {
        if (!taskBounds.isEmpty() && !this.mTaskBounds.equals(taskBounds)) {
            this.mTaskBounds.set(taskBounds);
            return true;
        }
        return false;
    }

    boolean isTaskBoundsInitialized() {
        return !this.mTaskBounds.isEmpty();
    }

    void setWindowingMode(int windowingMode) {
        this.mWindowingMode = windowingMode;
    }

    boolean isWindowingModeInitialized() {
        return this.mWindowingMode != 0;
    }

    int getWindowingModeForSplitTaskFragment(Rect taskFragmentBounds) {
        if (taskFragmentBounds == null || taskFragmentBounds.isEmpty() || isInPictureInPicture()) {
            return 0;
        }
        if (WindowConfiguration.inMultiWindowMode(this.mWindowingMode)) {
            return this.mWindowingMode;
        }
        return 6;
    }

    boolean isInPictureInPicture() {
        return this.mWindowingMode == 2;
    }

    boolean isEmpty() {
        return this.mContainers.isEmpty() && this.mFinishedContainer.isEmpty();
    }

    void cleanupPendingAppearedActivity(Activity pendingAppearedActivity) {
        for (TaskFragmentContainer container : this.mContainers) {
            container.removePendingAppearedActivity(pendingAppearedActivity);
        }
    }

    TaskFragmentContainer getTopTaskFragmentContainer() {
        if (this.mContainers.isEmpty()) {
            return null;
        }
        List<TaskFragmentContainer> list = this.mContainers;
        return list.get(list.size() - 1);
    }

    Activity getTopNonFinishingActivity() {
        for (int i = this.mContainers.size() - 1; i >= 0; i--) {
            Activity activity = this.mContainers.get(i).getTopNonFinishingActivity();
            if (activity != null) {
                return activity;
            }
        }
        return null;
    }
}
