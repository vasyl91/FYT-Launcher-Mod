package androidx.window.extensions.embedding;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.graphics.Rect;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.RemoteException;
import android.util.Log;
import android.view.IRemoteAnimationFinishedCallback;
import android.view.IRemoteAnimationRunner;
import android.view.RemoteAnimationTarget;
import android.view.SurfaceControl;
import android.view.animation.Animation;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.BiFunction;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
class TaskFragmentAnimationRunner extends IRemoteAnimationRunner.Stub {
    private static final String TAG = "TaskFragAnimationRunner";
    private final TaskFragmentAnimationSpec mAnimationSpec;
    private Animator mAnimator;
    private final Handler mHandler;

    TaskFragmentAnimationRunner() {
        HandlerThread animationThread = new HandlerThread("androidx.window.extensions.embedding", -4);
        animationThread.start();
        Handler threadHandler = animationThread.getThreadHandler();
        this.mHandler = threadHandler;
        this.mAnimationSpec = new TaskFragmentAnimationSpec(threadHandler);
    }

    public void onAnimationStart(final int transit, final RemoteAnimationTarget[] apps, RemoteAnimationTarget[] wallpapers, RemoteAnimationTarget[] nonApps, final IRemoteAnimationFinishedCallback finishedCallback) {
        if (wallpapers.length != 0 || nonApps.length != 0) {
            throw new IllegalArgumentException("TaskFragment shouldn't handle animation withwallpaper or non-app windows.");
        }
        this.mHandler.post(new Runnable() { // from class: androidx.window.extensions.embedding.TaskFragmentAnimationRunner$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m8xe3692e87(transit, apps, finishedCallback);
            }
        });
    }

    public void onAnimationCancelled(boolean isKeyguardOccluded) {
        this.mHandler.post(new Runnable() { // from class: androidx.window.extensions.embedding.TaskFragmentAnimationRunner$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.cancelAnimation();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: startAnimation, reason: merged with bridge method [inline-methods] */
    public void m8xe3692e87(int transit, RemoteAnimationTarget[] targets, IRemoteAnimationFinishedCallback finishedCallback) {
        if (this.mAnimator != null) {
            Log.w(TAG, "start new animation when the previous one is not finished yet.");
            this.mAnimator.cancel();
        }
        Animator animatorCreateAnimator = createAnimator(transit, targets, finishedCallback);
        this.mAnimator = animatorCreateAnimator;
        animatorCreateAnimator.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void cancelAnimation() {
        Animator animator = this.mAnimator;
        if (animator == null) {
            return;
        }
        animator.cancel();
        this.mAnimator = null;
    }

    private Animator createAnimator(int transit, RemoteAnimationTarget[] targets, final IRemoteAnimationFinishedCallback finishedCallback) {
        final List<TaskFragmentAnimationAdapter> adapters = createAnimationAdapters(transit, targets);
        long duration = 0;
        for (TaskFragmentAnimationAdapter adapter : adapters) {
            duration = Math.max(duration, adapter.getDurationHint());
        }
        final ValueAnimator animator = ValueAnimator.ofFloat(0.0f, 1.0f);
        animator.setDuration(duration);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: androidx.window.extensions.embedding.TaskFragmentAnimationRunner$$ExternalSyntheticLambda2
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                TaskFragmentAnimationRunner.lambda$createAnimator$1(adapters, animator, valueAnimator);
            }
        });
        animator.addListener(new Animator.AnimatorListener() { // from class: androidx.window.extensions.embedding.TaskFragmentAnimationRunner.1
            @Override // android.animation.Animator.AnimatorListener
            public void onAnimationStart(Animator animation) {
            }

            @Override // android.animation.Animator.AnimatorListener
            public void onAnimationEnd(Animator animation) {
                SurfaceControl.Transaction t = new SurfaceControl.Transaction();
                for (TaskFragmentAnimationAdapter adapter2 : adapters) {
                    adapter2.onAnimationEnd(t);
                }
                t.apply();
                try {
                    finishedCallback.onAnimationFinished();
                } catch (RemoteException e) {
                    e.rethrowFromSystemServer();
                }
                TaskFragmentAnimationRunner.this.mAnimator = null;
            }

            @Override // android.animation.Animator.AnimatorListener
            public void onAnimationCancel(Animator animation) {
            }

            @Override // android.animation.Animator.AnimatorListener
            public void onAnimationRepeat(Animator animation) {
            }
        });
        return animator;
    }

    static /* synthetic */ void lambda$createAnimator$1(List adapters, ValueAnimator animator, ValueAnimator anim) {
        SurfaceControl.Transaction t = new SurfaceControl.Transaction();
        Iterator it = adapters.iterator();
        while (it.hasNext()) {
            TaskFragmentAnimationAdapter adapter = (TaskFragmentAnimationAdapter) it.next();
            adapter.onAnimationUpdate(t, animator.getCurrentPlayTime());
        }
        t.apply();
    }

    private List<TaskFragmentAnimationAdapter> createAnimationAdapters(int transit, RemoteAnimationTarget[] targets) {
        switch (transit) {
            case 6:
            case 8:
            case 28:
                return createOpenAnimationAdapters(targets);
            case 7:
            case 9:
            case 29:
                return createCloseAnimationAdapters(targets);
            case 30:
                return createChangeAnimationAdapters(targets);
            default:
                throw new IllegalArgumentException("Unhandled transit type=" + transit);
        }
    }

    private List<TaskFragmentAnimationAdapter> createOpenAnimationAdapters(RemoteAnimationTarget[] targets) {
        final TaskFragmentAnimationSpec taskFragmentAnimationSpec = this.mAnimationSpec;
        Objects.requireNonNull(taskFragmentAnimationSpec);
        return createOpenCloseAnimationAdapters(targets, true, new BiFunction() { // from class: androidx.window.extensions.embedding.TaskFragmentAnimationRunner$$ExternalSyntheticLambda1
            @Override // java.util.function.BiFunction
            public final Object apply(Object obj, Object obj2) {
                return taskFragmentAnimationSpec.loadOpenAnimation((RemoteAnimationTarget) obj, (Rect) obj2);
            }
        });
    }

    private List<TaskFragmentAnimationAdapter> createCloseAnimationAdapters(RemoteAnimationTarget[] targets) {
        final TaskFragmentAnimationSpec taskFragmentAnimationSpec = this.mAnimationSpec;
        Objects.requireNonNull(taskFragmentAnimationSpec);
        return createOpenCloseAnimationAdapters(targets, false, new BiFunction() { // from class: androidx.window.extensions.embedding.TaskFragmentAnimationRunner$$ExternalSyntheticLambda0
            @Override // java.util.function.BiFunction
            public final Object apply(Object obj, Object obj2) {
                return taskFragmentAnimationSpec.loadCloseAnimation((RemoteAnimationTarget) obj, (Rect) obj2);
            }
        });
    }

    private List<TaskFragmentAnimationAdapter> createOpenCloseAnimationAdapters(RemoteAnimationTarget[] targets, boolean isOpening, BiFunction<RemoteAnimationTarget, Rect, Animation> animationProvider) {
        List<RemoteAnimationTarget> openingTargets = new ArrayList<>();
        List<RemoteAnimationTarget> closingTargets = new ArrayList<>();
        Rect openingWholeScreenBounds = new Rect();
        Rect closingWholeScreenBounds = new Rect();
        for (RemoteAnimationTarget target : targets) {
            if (target.mode != 1) {
                openingTargets.add(target);
                openingWholeScreenBounds.union(target.localBounds);
            } else {
                closingTargets.add(target);
                closingWholeScreenBounds.union(target.localBounds);
            }
        }
        int offsetLayer = 1000;
        List<TaskFragmentAnimationAdapter> adapters = new ArrayList<>();
        for (RemoteAnimationTarget target2 : openingTargets) {
            TaskFragmentAnimationAdapter adapter = createOpenCloseAnimationAdapter(target2, animationProvider, openingWholeScreenBounds);
            if (isOpening) {
                adapter.overrideLayer(offsetLayer);
                offsetLayer++;
            }
            adapters.add(adapter);
        }
        for (RemoteAnimationTarget target3 : closingTargets) {
            TaskFragmentAnimationAdapter adapter2 = createOpenCloseAnimationAdapter(target3, animationProvider, closingWholeScreenBounds);
            if (!isOpening) {
                adapter2.overrideLayer(offsetLayer);
                offsetLayer++;
            }
            adapters.add(adapter2);
        }
        return adapters;
    }

    private TaskFragmentAnimationAdapter createOpenCloseAnimationAdapter(RemoteAnimationTarget target, BiFunction<RemoteAnimationTarget, Rect, Animation> animationProvider, Rect wholeAnimationBounds) {
        Animation animation = animationProvider.apply(target, wholeAnimationBounds);
        Rect targetBounds = target.localBounds;
        if (targetBounds.left == wholeAnimationBounds.left && targetBounds.right != wholeAnimationBounds.right) {
            return new TaskFragmentAnimationAdapter.SplitAdapter(animation, target, true, wholeAnimationBounds.width());
        }
        if (targetBounds.left != wholeAnimationBounds.left && targetBounds.right == wholeAnimationBounds.right) {
            return new TaskFragmentAnimationAdapter.SplitAdapter(animation, target, false, wholeAnimationBounds.width());
        }
        return new TaskFragmentAnimationAdapter(animation, target);
    }

    private List<TaskFragmentAnimationAdapter> createChangeAnimationAdapters(RemoteAnimationTarget[] targets) {
        Animation animation;
        List<TaskFragmentAnimationAdapter> adapters = new ArrayList<>();
        for (RemoteAnimationTarget target : targets) {
            if (target.startBounds != null) {
                Animation[] animations = this.mAnimationSpec.createChangeBoundsChangeAnimations(target);
                adapters.add(new TaskFragmentAnimationAdapter.SnapshotAdapter(animations[0], target));
                adapters.add(new TaskFragmentAnimationAdapter.BoundsChangeAdapter(animations[1], target));
            } else {
                if (target.hasAnimatingParent) {
                    animation = TaskFragmentAnimationSpec.createNoopAnimation(target);
                } else if (target.mode == 1) {
                    animation = this.mAnimationSpec.createChangeBoundsCloseAnimation(target);
                } else {
                    animation = this.mAnimationSpec.createChangeBoundsOpenAnimation(target);
                }
                adapters.add(new TaskFragmentAnimationAdapter(animation, target));
            }
        }
        return adapters;
    }
}
