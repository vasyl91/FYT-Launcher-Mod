package androidx.window.extensions.embedding;

import android.app.Activity;
import android.content.Intent;
import android.util.Pair;
import android.view.WindowMetrics;
import java.util.function.Predicate;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public class SplitPairRule extends SplitRule {
    private final Predicate<Pair<Activity, Intent>> mActivityIntentPredicate;
    private final Predicate<Pair<Activity, Activity>> mActivityPairPredicate;
    private final boolean mClearTop;
    private final int mFinishPrimaryWithSecondary;
    private final int mFinishSecondaryWithPrimary;

    SplitPairRule(float splitRatio, int layoutDirection, int finishPrimaryWithSecondary, int finishSecondaryWithPrimary, boolean clearTop, Predicate<Pair<Activity, Activity>> activityPairPredicate, Predicate<Pair<Activity, Intent>> activityIntentPredicate, Predicate<WindowMetrics> parentWindowMetricsPredicate) {
        super(parentWindowMetricsPredicate, splitRatio, layoutDirection);
        this.mActivityPairPredicate = activityPairPredicate;
        this.mActivityIntentPredicate = activityIntentPredicate;
        this.mFinishPrimaryWithSecondary = finishPrimaryWithSecondary;
        this.mFinishSecondaryWithPrimary = finishSecondaryWithPrimary;
        this.mClearTop = clearTop;
    }

    public boolean matchesActivityPair(Activity primaryActivity, Activity secondaryActivity) {
        return this.mActivityPairPredicate.test(new Pair<>(primaryActivity, secondaryActivity));
    }

    public boolean matchesActivityIntentPair(Activity primaryActivity, Intent secondaryActivityIntent) {
        return this.mActivityIntentPredicate.test(new Pair<>(primaryActivity, secondaryActivityIntent));
    }

    public int getFinishPrimaryWithSecondary() {
        return this.mFinishPrimaryWithSecondary;
    }

    public int getFinishSecondaryWithPrimary() {
        return this.mFinishSecondaryWithPrimary;
    }

    public boolean shouldClearTop() {
        return this.mClearTop;
    }

    public static final class Builder {
        private final Predicate<Pair<Activity, Intent>> mActivityIntentPredicate;
        private final Predicate<Pair<Activity, Activity>> mActivityPairPredicate;
        private boolean mClearTop;
        private int mFinishPrimaryWithSecondary;
        private int mFinishSecondaryWithPrimary;
        private int mLayoutDirection;
        private final Predicate<WindowMetrics> mParentWindowMetricsPredicate;
        private float mSplitRatio;

        public Builder(Predicate<Pair<Activity, Activity>> activityPairPredicate, Predicate<Pair<Activity, Intent>> activityIntentPredicate, Predicate<WindowMetrics> parentWindowMetricsPredicate) {
            this.mActivityPairPredicate = activityPairPredicate;
            this.mActivityIntentPredicate = activityIntentPredicate;
            this.mParentWindowMetricsPredicate = parentWindowMetricsPredicate;
        }

        public Builder setSplitRatio(float splitRatio) {
            this.mSplitRatio = splitRatio;
            return this;
        }

        public Builder setLayoutDirection(int layoutDirection) {
            this.mLayoutDirection = layoutDirection;
            return this;
        }

        @Deprecated
        public Builder setShouldFinishPrimaryWithSecondary(boolean finishPrimaryWithSecondary) {
            return this;
        }

        @Deprecated
        public Builder setShouldFinishSecondaryWithPrimary(boolean finishSecondaryWithPrimary) {
            return this;
        }

        public Builder setFinishPrimaryWithSecondary(int finishBehavior) {
            this.mFinishPrimaryWithSecondary = finishBehavior;
            return this;
        }

        public Builder setFinishSecondaryWithPrimary(int finishBehavior) {
            this.mFinishSecondaryWithPrimary = finishBehavior;
            return this;
        }

        public Builder setShouldClearTop(boolean shouldClearTop) {
            this.mClearTop = shouldClearTop;
            return this;
        }

        public SplitPairRule build() {
            return new SplitPairRule(this.mSplitRatio, this.mLayoutDirection, this.mFinishPrimaryWithSecondary, this.mFinishSecondaryWithPrimary, this.mClearTop, this.mActivityPairPredicate, this.mActivityIntentPredicate, this.mParentWindowMetricsPredicate);
        }
    }

    @Override // androidx.window.extensions.embedding.SplitRule
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof SplitPairRule)) {
            return false;
        }
        SplitPairRule that = (SplitPairRule) o;
        return super.equals(o) && this.mActivityPairPredicate.equals(that.mActivityPairPredicate) && this.mActivityIntentPredicate.equals(that.mActivityIntentPredicate) && this.mFinishPrimaryWithSecondary == that.mFinishPrimaryWithSecondary && this.mFinishSecondaryWithPrimary == that.mFinishSecondaryWithPrimary && this.mClearTop == that.mClearTop;
    }

    @Override // androidx.window.extensions.embedding.SplitRule
    public int hashCode() {
        return (((((((((super.hashCode() * 31) + this.mActivityPairPredicate.hashCode()) * 31) + this.mActivityIntentPredicate.hashCode()) * 31) + this.mFinishPrimaryWithSecondary) * 31) + this.mFinishSecondaryWithPrimary) * 31) + (this.mClearTop ? 1 : 0);
    }

    @Override // androidx.window.extensions.embedding.SplitRule
    public String toString() {
        return "SplitPairRule{mFinishPrimaryWithSecondary=" + this.mFinishPrimaryWithSecondary + ", mFinishSecondaryWithPrimary=" + this.mFinishSecondaryWithPrimary + ", mClearTop=" + this.mClearTop + '}';
    }
}
