package androidx.window.extensions.embedding;

import android.app.Activity;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public class ActivityStack {
    private final List<Activity> mActivities;
    private final boolean mIsEmpty;

    public ActivityStack(List<Activity> activities, boolean isEmpty) {
        this.mActivities = new ArrayList(activities);
        this.mIsEmpty = isEmpty;
    }

    public List<Activity> getActivities() {
        return new ArrayList(this.mActivities);
    }

    public boolean isEmpty() {
        return this.mIsEmpty;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ActivityStack)) {
            return false;
        }
        ActivityStack that = (ActivityStack) o;
        return this.mActivities.equals(that.mActivities) && this.mIsEmpty == that.mIsEmpty;
    }

    public int hashCode() {
        return ((this.mIsEmpty ? 1 : 0) * 31) + this.mActivities.hashCode();
    }

    public String toString() {
        return "ActivityStack{mActivities=" + this.mActivities + ", mIsEmpty=" + this.mIsEmpty + '}';
    }
}
