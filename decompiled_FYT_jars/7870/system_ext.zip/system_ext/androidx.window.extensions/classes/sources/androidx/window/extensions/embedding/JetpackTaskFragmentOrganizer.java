package androidx.window.extensions.embedding;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.IBinder;
import android.util.ArrayMap;
import android.window.TaskFragmentCreationParams;
import android.window.TaskFragmentInfo;
import android.window.TaskFragmentOrganizer;
import android.window.WindowContainerTransaction;
import java.util.Map;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
class JetpackTaskFragmentOrganizer extends TaskFragmentOrganizer {
    TaskFragmentAnimationController mAnimationController;
    private final TaskFragmentCallback mCallback;
    final Map<IBinder, TaskFragmentInfo> mFragmentInfos;
    final Map<IBinder, Configuration> mFragmentParentConfigs;

    interface TaskFragmentCallback {
        void onActivityReparentToTask(int i, Intent intent, IBinder iBinder);

        void onTaskFragmentAppeared(TaskFragmentInfo taskFragmentInfo);

        void onTaskFragmentInfoChanged(TaskFragmentInfo taskFragmentInfo);

        void onTaskFragmentParentInfoChanged(IBinder iBinder, Configuration configuration);

        void onTaskFragmentVanished(TaskFragmentInfo taskFragmentInfo);
    }

    JetpackTaskFragmentOrganizer(Executor executor, TaskFragmentCallback callback) {
        super(executor);
        this.mFragmentInfos = new ArrayMap();
        this.mFragmentParentConfigs = new ArrayMap();
        this.mCallback = callback;
    }

    public void unregisterOrganizer() {
        TaskFragmentAnimationController taskFragmentAnimationController = this.mAnimationController;
        if (taskFragmentAnimationController != null) {
            taskFragmentAnimationController.unregisterAllRemoteAnimations();
            this.mAnimationController = null;
        }
        super.unregisterOrganizer();
    }

    void startOverrideSplitAnimation(int taskId) {
        if (this.mAnimationController == null) {
            this.mAnimationController = new TaskFragmentAnimationController(this);
        }
        this.mAnimationController.registerRemoteAnimations(taskId);
    }

    void stopOverrideSplitAnimation(int taskId) {
        TaskFragmentAnimationController taskFragmentAnimationController = this.mAnimationController;
        if (taskFragmentAnimationController != null) {
            taskFragmentAnimationController.unregisterRemoteAnimations(taskId);
        }
    }

    void startActivityToSide(WindowContainerTransaction wct, IBinder launchingFragmentToken, Rect launchingFragmentBounds, Activity launchingActivity, IBinder secondaryFragmentToken, Rect secondaryFragmentBounds, Intent activityIntent, Bundle activityOptions, SplitRule rule, int windowingMode) {
        IBinder ownerToken = launchingActivity.getActivityToken();
        if (this.mFragmentInfos.containsKey(launchingFragmentToken)) {
            resizeTaskFragment(wct, launchingFragmentToken, launchingFragmentBounds);
            updateWindowingMode(wct, launchingFragmentToken, windowingMode);
        } else {
            createTaskFragmentAndReparentActivity(wct, launchingFragmentToken, ownerToken, launchingFragmentBounds, windowingMode, launchingActivity);
        }
        createTaskFragmentAndStartActivity(wct, secondaryFragmentToken, ownerToken, secondaryFragmentBounds, windowingMode, activityIntent, activityOptions);
        setAdjacentTaskFragments(wct, launchingFragmentToken, secondaryFragmentToken, rule);
    }

    void expandTaskFragment(WindowContainerTransaction wct, IBinder fragmentToken) {
        resizeTaskFragment(wct, fragmentToken, new Rect());
        setAdjacentTaskFragments(wct, fragmentToken, null, null);
        updateWindowingMode(wct, fragmentToken, 0);
    }

    void expandTaskFragment(IBinder fragmentToken) {
        WindowContainerTransaction wct = new WindowContainerTransaction();
        expandTaskFragment(wct, fragmentToken);
        applyTransaction(wct);
    }

    void expandActivity(IBinder fragmentToken, Activity activity) {
        WindowContainerTransaction wct = new WindowContainerTransaction();
        createTaskFragmentAndReparentActivity(wct, fragmentToken, activity.getActivityToken(), new Rect(), 0, activity);
        applyTransaction(wct);
    }

    void createTaskFragment(WindowContainerTransaction wct, IBinder fragmentToken, IBinder ownerToken, Rect bounds, int windowingMode) {
        TaskFragmentCreationParams fragmentOptions = createFragmentOptions(fragmentToken, ownerToken, bounds, windowingMode);
        wct.createTaskFragment(fragmentOptions);
    }

    private void createTaskFragmentAndReparentActivity(WindowContainerTransaction wct, IBinder fragmentToken, IBinder ownerToken, Rect bounds, int windowingMode, Activity activity) {
        createTaskFragment(wct, fragmentToken, ownerToken, bounds, windowingMode);
        wct.reparentActivityToTaskFragment(fragmentToken, activity.getActivityToken());
    }

    private void createTaskFragmentAndStartActivity(WindowContainerTransaction wct, IBinder fragmentToken, IBinder ownerToken, Rect bounds, int windowingMode, Intent activityIntent, Bundle activityOptions) {
        createTaskFragment(wct, fragmentToken, ownerToken, bounds, windowingMode);
        wct.startActivityInTaskFragment(fragmentToken, ownerToken, activityIntent, activityOptions);
    }

    void setAdjacentTaskFragments(WindowContainerTransaction wct, IBinder primary, IBinder secondary, SplitRule splitRule) {
        WindowContainerTransaction.TaskFragmentAdjacentParams adjacentParams = null;
        boolean finishSecondaryWithPrimary = splitRule != null && SplitContainer.shouldFinishSecondaryWithPrimary(splitRule);
        boolean finishPrimaryWithSecondary = splitRule != null && SplitContainer.shouldFinishPrimaryWithSecondary(splitRule);
        if (finishSecondaryWithPrimary || finishPrimaryWithSecondary) {
            adjacentParams = new WindowContainerTransaction.TaskFragmentAdjacentParams();
            adjacentParams.setShouldDelayPrimaryLastActivityRemoval(finishSecondaryWithPrimary);
            adjacentParams.setShouldDelaySecondaryLastActivityRemoval(finishPrimaryWithSecondary);
        }
        wct.setAdjacentTaskFragments(primary, secondary, adjacentParams);
    }

    TaskFragmentCreationParams createFragmentOptions(IBinder fragmentToken, IBinder ownerToken, Rect bounds, int windowingMode) {
        if (this.mFragmentInfos.containsKey(fragmentToken)) {
            throw new IllegalArgumentException("There is an existing TaskFragment with fragmentToken=" + fragmentToken);
        }
        return new TaskFragmentCreationParams.Builder(getOrganizerToken(), fragmentToken, ownerToken).setInitialBounds(bounds).setWindowingMode(windowingMode).build();
    }

    void resizeTaskFragment(WindowContainerTransaction wct, IBinder fragmentToken, Rect bounds) {
        if (!this.mFragmentInfos.containsKey(fragmentToken)) {
            throw new IllegalArgumentException("Can't find an existing TaskFragment with fragmentToken=" + fragmentToken);
        }
        if (bounds == null) {
            bounds = new Rect();
        }
        wct.setBounds(this.mFragmentInfos.get(fragmentToken).getToken(), bounds);
    }

    void updateWindowingMode(WindowContainerTransaction wct, IBinder fragmentToken, int windowingMode) {
        if (!this.mFragmentInfos.containsKey(fragmentToken)) {
            throw new IllegalArgumentException("Can't find an existing TaskFragment with fragmentToken=" + fragmentToken);
        }
        wct.setWindowingMode(this.mFragmentInfos.get(fragmentToken).getToken(), windowingMode);
    }

    void deleteTaskFragment(WindowContainerTransaction wct, IBinder fragmentToken) {
        if (!this.mFragmentInfos.containsKey(fragmentToken)) {
            throw new IllegalArgumentException("Can't find an existing TaskFragment with fragmentToken=" + fragmentToken);
        }
        wct.deleteTaskFragment(this.mFragmentInfos.get(fragmentToken).getToken());
    }

    public void onTaskFragmentAppeared(TaskFragmentInfo taskFragmentInfo) {
        IBinder fragmentToken = taskFragmentInfo.getFragmentToken();
        this.mFragmentInfos.put(fragmentToken, taskFragmentInfo);
        TaskFragmentCallback taskFragmentCallback = this.mCallback;
        if (taskFragmentCallback != null) {
            taskFragmentCallback.onTaskFragmentAppeared(taskFragmentInfo);
        }
    }

    public void onTaskFragmentInfoChanged(TaskFragmentInfo taskFragmentInfo) {
        IBinder fragmentToken = taskFragmentInfo.getFragmentToken();
        this.mFragmentInfos.put(fragmentToken, taskFragmentInfo);
        TaskFragmentCallback taskFragmentCallback = this.mCallback;
        if (taskFragmentCallback != null) {
            taskFragmentCallback.onTaskFragmentInfoChanged(taskFragmentInfo);
        }
    }

    public void onTaskFragmentVanished(TaskFragmentInfo taskFragmentInfo) {
        this.mFragmentInfos.remove(taskFragmentInfo.getFragmentToken());
        this.mFragmentParentConfigs.remove(taskFragmentInfo.getFragmentToken());
        TaskFragmentCallback taskFragmentCallback = this.mCallback;
        if (taskFragmentCallback != null) {
            taskFragmentCallback.onTaskFragmentVanished(taskFragmentInfo);
        }
    }

    public void onTaskFragmentParentInfoChanged(IBinder fragmentToken, Configuration parentConfig) {
        this.mFragmentParentConfigs.put(fragmentToken, parentConfig);
        TaskFragmentCallback taskFragmentCallback = this.mCallback;
        if (taskFragmentCallback != null) {
            taskFragmentCallback.onTaskFragmentParentInfoChanged(fragmentToken, parentConfig);
        }
    }

    public void onActivityReparentToTask(int taskId, Intent activityIntent, IBinder activityToken) {
        TaskFragmentCallback taskFragmentCallback = this.mCallback;
        if (taskFragmentCallback != null) {
            taskFragmentCallback.onActivityReparentToTask(taskId, activityIntent, activityToken);
        }
    }
}
