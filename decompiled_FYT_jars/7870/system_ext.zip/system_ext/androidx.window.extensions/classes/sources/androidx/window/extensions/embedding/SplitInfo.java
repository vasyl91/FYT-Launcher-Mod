package androidx.window.extensions.embedding;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public class SplitInfo {
    private final ActivityStack mPrimaryActivityStack;
    private final ActivityStack mSecondaryActivityStack;
    private final float mSplitRatio;

    public SplitInfo(ActivityStack primaryActivityStack, ActivityStack secondaryActivityStack, float splitRatio) {
        this.mPrimaryActivityStack = primaryActivityStack;
        this.mSecondaryActivityStack = secondaryActivityStack;
        this.mSplitRatio = splitRatio;
    }

    public ActivityStack getPrimaryActivityStack() {
        return this.mPrimaryActivityStack;
    }

    public ActivityStack getSecondaryActivityStack() {
        return this.mSecondaryActivityStack;
    }

    public float getSplitRatio() {
        return this.mSplitRatio;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof SplitInfo)) {
            return false;
        }
        SplitInfo that = (SplitInfo) o;
        return Float.compare(that.mSplitRatio, this.mSplitRatio) == 0 && this.mPrimaryActivityStack.equals(that.mPrimaryActivityStack) && this.mSecondaryActivityStack.equals(that.mSecondaryActivityStack);
    }

    public int hashCode() {
        int result = this.mPrimaryActivityStack.hashCode();
        return (((result * 31) + this.mSecondaryActivityStack.hashCode()) * 31) + ((int) (this.mSplitRatio * 17.0f));
    }

    public String toString() {
        return "SplitInfo{mPrimaryActivityStack=" + this.mPrimaryActivityStack + ", mSecondaryActivityStack=" + this.mSecondaryActivityStack + ", mSplitRatio=" + this.mSplitRatio + '}';
    }
}
