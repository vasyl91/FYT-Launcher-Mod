package androidx.window.extensions.layout;

import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public class WindowLayoutInfo {
    private List<DisplayFeature> mDisplayFeatures;

    public WindowLayoutInfo(List<DisplayFeature> displayFeatures) {
        this.mDisplayFeatures = Collections.unmodifiableList(displayFeatures);
    }

    public List<DisplayFeature> getDisplayFeatures() {
        return this.mDisplayFeatures;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ExtensionWindowLayoutInfo { ExtensionDisplayFeatures[ ");
        for (int i = 0; i < this.mDisplayFeatures.size(); i++) {
            sb.append(this.mDisplayFeatures.get(i));
            if (i < this.mDisplayFeatures.size() - 1) {
                sb.append(", ");
            }
        }
        sb.append(" ] }");
        return sb.toString();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof WindowLayoutInfo)) {
            return false;
        }
        WindowLayoutInfo other = (WindowLayoutInfo) obj;
        List<DisplayFeature> list = this.mDisplayFeatures;
        if (list == null) {
            return other.mDisplayFeatures == null;
        }
        return list.equals(other.mDisplayFeatures);
    }

    public int hashCode() {
        List<DisplayFeature> list = this.mDisplayFeatures;
        if (list != null) {
            return list.size();
        }
        return 0;
    }
}
