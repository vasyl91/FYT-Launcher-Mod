package androidx.window.extensions.layout;

import android.graphics.Rect;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public class FoldingFeature implements DisplayFeature {
    public static final int STATE_FLAT = 1;
    public static final int STATE_HALF_OPENED = 2;
    public static final int TYPE_FOLD = 1;
    public static final int TYPE_HINGE = 2;
    private final Rect mBounds;
    private final int mState;
    private final int mType;

    public FoldingFeature(Rect bounds, int type, int state) {
        validateFeatureBounds(bounds);
        this.mBounds = new Rect(bounds);
        this.mType = type;
        this.mState = state;
    }

    @Override // androidx.window.extensions.layout.DisplayFeature
    public Rect getBounds() {
        return new Rect(this.mBounds);
    }

    public int getType() {
        return this.mType;
    }

    public int getState() {
        return this.mState;
    }

    private static void validateFeatureBounds(Rect bounds) {
        if (bounds.width() == 0 && bounds.height() == 0) {
            throw new IllegalArgumentException("Bounds must be non zero");
        }
        if (bounds.left != 0 && bounds.top != 0) {
            throw new IllegalArgumentException("Bounding rectangle must start at the top or left window edge for folding features");
        }
    }

    private static String typeToString(int type) {
        switch (type) {
            case 1:
                return "FOLD";
            case 2:
                return "HINGE";
            default:
                return "Unknown feature type (" + type + ")";
        }
    }

    private static String stateToString(int state) {
        switch (state) {
            case 1:
                return "FLAT";
            case 2:
                return "HALF_OPENED";
            default:
                return "Unknown feature state (" + state + ")";
        }
    }

    public String toString() {
        return "ExtensionDisplayFoldFeature { " + this.mBounds + ", type=" + typeToString(getType()) + ", state=" + stateToString(this.mState) + " }";
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FoldingFeature)) {
            return false;
        }
        FoldingFeature other = (FoldingFeature) obj;
        if (this.mType == other.mType && this.mState == other.mState) {
            return this.mBounds.equals(other.mBounds);
        }
        return false;
    }

    private static int hashBounds(Rect bounds) {
        int result = bounds.left;
        return (((((result * 31) + bounds.top) * 31) + bounds.right) * 31) + bounds.bottom;
    }

    public int hashCode() {
        int result = hashBounds(this.mBounds);
        return (((result * 31) + this.mType) * 31) + this.mState;
    }
}
