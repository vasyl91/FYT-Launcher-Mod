package androidx.window.extensions.layout;

import android.graphics.Rect;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public interface DisplayFeature {
    Rect getBounds();
}
