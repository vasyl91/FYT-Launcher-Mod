package androidx.window.extensions.embedding;

import android.app.Activity;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public interface ActivityEmbeddingComponent {
    boolean isActivityEmbedded(Activity activity);

    void setEmbeddingRules(Set<EmbeddingRule> set);

    void setSplitInfoCallback(Consumer<List<SplitInfo>> consumer);
}
