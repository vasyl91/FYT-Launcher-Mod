package androidx.window.common;

import android.graphics.Rect;
import androidx.window.util.ExtensionHelper;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public final class CommonFoldingFeature {
    public static final int COMMON_STATE_FLAT = 3;
    public static final int COMMON_STATE_HALF_OPENED = 2;
    public static final int COMMON_STATE_UNKNOWN = -1;
    public static final int COMMON_TYPE_FOLD = 1;
    public static final int COMMON_TYPE_HINGE = 2;
    private static final boolean DEBUG = false;
    private static final String FEATURE_TYPE_FOLD = "fold";
    private static final String FEATURE_TYPE_HINGE = "hinge";
    private static final String PATTERN_STATE_FLAT = "flat";
    private static final String PATTERN_STATE_HALF_OPENED = "half-opened";
    private final Rect mRect;
    private final int mState;
    private final int mType;
    public static final String TAG = CommonFoldingFeature.class.getSimpleName();
    private static final Pattern FEATURE_PATTERN = Pattern.compile("([a-z]+)-\\[(\\d+),(\\d+),(\\d+),(\\d+)]-?(flat|half-opened)?");

    @Retention(RetentionPolicy.SOURCE)
    public @interface State {
    }

    @Retention(RetentionPolicy.SOURCE)
    public @interface Type {
    }

    static List<CommonFoldingFeature> parseListFromString(String value, int hingeState) {
        List<CommonFoldingFeature> features = new ArrayList<>();
        String[] featureStrings = value.split(";");
        for (String featureString : featureStrings) {
            try {
                CommonFoldingFeature feature = parseFromString(featureString, hingeState);
                features.add(feature);
            } catch (IllegalArgumentException e) {
            }
        }
        return features;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:13:0x0022  */
    /* JADX WARN: Code duplicated, block: B:33:0x0082  */
    private static CommonFoldingFeature parseFromString(String string, int hingeState) {
        int type;
        int state;
        Matcher featureMatcher = FEATURE_PATTERN.matcher(string);
        if (!featureMatcher.matches()) {
            throw new IllegalArgumentException("Malformed feature description format: " + string);
        }
        try {
            String featureType = featureMatcher.group(1);
            String stateString = "";
            String featureType2 = featureType == null ? "" : featureType;
            switch (featureType2) {
                case "fold":
                    type = 1;
                    break;
                case "hinge":
                    type = 2;
                    break;
                default:
                    throw new IllegalArgumentException("Malformed feature type: " + featureType2);
            }
            int left = Integer.parseInt(featureMatcher.group(2));
            int top = Integer.parseInt(featureMatcher.group(3));
            int right = Integer.parseInt(featureMatcher.group(4));
            int bottom = Integer.parseInt(featureMatcher.group(5));
            Rect featureRect = new Rect(left, top, right, bottom);
            if (ExtensionHelper.isZero(featureRect)) {
                throw new IllegalArgumentException("Feature has empty bounds: " + string);
            }
            String stateString2 = featureMatcher.group(6);
            if (stateString2 != null) {
                stateString = stateString2;
            }
            switch (stateString) {
                case "flat":
                    state = 3;
                    break;
                case "half-opened":
                    state = 2;
                    break;
                default:
                    state = hingeState;
                    break;
            }
            return new CommonFoldingFeature(type, state, featureRect);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Malformed feature description: " + string, e);
        }
    }

    CommonFoldingFeature(int type, int state, Rect rect) {
        assertValidState(Integer.valueOf(state));
        this.mType = type;
        this.mState = state;
        if (rect.width() == 0 && rect.height() == 0) {
            throw new IllegalArgumentException("Display feature rectangle cannot have zero width and height simultaneously.");
        }
        this.mRect = rect;
    }

    public int getType() {
        return this.mType;
    }

    public int getState() {
        return this.mState;
    }

    public Rect getRect() {
        return this.mRect;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return DEBUG;
        }
        CommonFoldingFeature that = (CommonFoldingFeature) o;
        if (this.mType == that.mType && Objects.equals(Integer.valueOf(this.mState), Integer.valueOf(that.mState)) && this.mRect.equals(that.mRect)) {
            return true;
        }
        return DEBUG;
    }

    public int hashCode() {
        return Objects.hash(Integer.valueOf(this.mType), Integer.valueOf(this.mState), this.mRect);
    }

    private static void assertValidState(Integer state) {
        if (state != null && state.intValue() != 3 && state.intValue() != 2 && state.intValue() != -1) {
            throw new IllegalArgumentException("Invalid state: " + state + "must be either COMMON_STATE_FLAT or COMMON_STATE_HALF_OPENED");
        }
    }
}
