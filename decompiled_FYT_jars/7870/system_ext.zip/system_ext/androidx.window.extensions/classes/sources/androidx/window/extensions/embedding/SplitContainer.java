package androidx.window.extensions.embedding;

import android.app.Activity;
import android.util.Pair;
import android.util.Size;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
class SplitContainer {
    private final TaskFragmentContainer mPrimaryContainer;
    private final TaskFragmentContainer mSecondaryContainer;
    private final SplitRule mSplitRule;

    SplitContainer(TaskFragmentContainer primaryContainer, Activity primaryActivity, TaskFragmentContainer secondaryContainer, SplitRule splitRule) {
        this.mPrimaryContainer = primaryContainer;
        this.mSecondaryContainer = secondaryContainer;
        this.mSplitRule = splitRule;
        if (shouldFinishPrimaryWithSecondary(splitRule)) {
            if (primaryContainer.getRunningActivityCount() == 1 && primaryContainer.hasActivity(primaryActivity.getActivityToken())) {
                secondaryContainer.addContainerToFinishOnExit(primaryContainer);
            } else {
                secondaryContainer.addActivityToFinishOnExit(primaryActivity);
            }
        }
        if (shouldFinishSecondaryWithPrimary(splitRule)) {
            primaryContainer.addContainerToFinishOnExit(secondaryContainer);
        }
    }

    TaskFragmentContainer getPrimaryContainer() {
        return this.mPrimaryContainer;
    }

    TaskFragmentContainer getSecondaryContainer() {
        return this.mSecondaryContainer;
    }

    SplitRule getSplitRule() {
        return this.mSplitRule;
    }

    Pair<Size, Size> getMinDimensionsPair() {
        return new Pair<>(this.mPrimaryContainer.getMinDimensions(), this.mSecondaryContainer.getMinDimensions());
    }

    boolean isPlaceholderContainer() {
        return this.mSplitRule instanceof SplitPlaceholderRule;
    }

    static boolean shouldFinishPrimaryWithSecondary(SplitRule splitRule) {
        boolean isPlaceholderContainer = splitRule instanceof SplitPlaceholderRule;
        boolean shouldFinishPrimaryWithSecondary = (splitRule instanceof SplitPairRule) && ((SplitPairRule) splitRule).getFinishPrimaryWithSecondary() != 0;
        return shouldFinishPrimaryWithSecondary || isPlaceholderContainer;
    }

    static boolean shouldFinishSecondaryWithPrimary(SplitRule splitRule) {
        boolean isPlaceholderContainer = splitRule instanceof SplitPlaceholderRule;
        boolean shouldFinishSecondaryWithPrimary = (splitRule instanceof SplitPairRule) && ((SplitPairRule) splitRule).getFinishSecondaryWithPrimary() != 0;
        return shouldFinishSecondaryWithPrimary || isPlaceholderContainer;
    }

    static boolean shouldFinishAssociatedContainerWhenStacked(int finishBehavior) {
        return finishBehavior == 1;
    }

    static boolean shouldFinishAssociatedContainerWhenAdjacent(int finishBehavior) {
        return finishBehavior == 1 || finishBehavior == 2;
    }

    static int getFinishPrimaryWithSecondaryBehavior(SplitRule splitRule) {
        if (splitRule instanceof SplitPlaceholderRule) {
            return ((SplitPlaceholderRule) splitRule).getFinishPrimaryWithSecondary();
        }
        if (splitRule instanceof SplitPairRule) {
            return ((SplitPairRule) splitRule).getFinishPrimaryWithSecondary();
        }
        return 0;
    }

    static int getFinishSecondaryWithPrimaryBehavior(SplitRule splitRule) {
        if (splitRule instanceof SplitPlaceholderRule) {
            return 1;
        }
        if (splitRule instanceof SplitPairRule) {
            return ((SplitPairRule) splitRule).getFinishSecondaryWithPrimary();
        }
        return 0;
    }

    static boolean isStickyPlaceholderRule(SplitRule splitRule) {
        if (!(splitRule instanceof SplitPlaceholderRule)) {
            return false;
        }
        return ((SplitPlaceholderRule) splitRule).isSticky();
    }

    public String toString() {
        return "SplitContainer{ primaryContainer=" + this.mPrimaryContainer + " secondaryContainer=" + this.mSecondaryContainer + " splitRule=" + this.mSplitRule + "}";
    }
}
