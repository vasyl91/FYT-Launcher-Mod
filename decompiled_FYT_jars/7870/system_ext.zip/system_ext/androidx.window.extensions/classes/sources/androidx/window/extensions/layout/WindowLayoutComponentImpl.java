package androidx.window.extensions.layout;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.app.WindowConfiguration;
import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.IBinder;
import android.util.ArrayMap;
import android.util.Log;
import androidx.window.common.CommonFoldingFeature;
import androidx.window.common.DeviceStateManagerFoldingFeatureProducer;
import androidx.window.common.EmptyLifecycleCallbacksAdapter;
import androidx.window.common.RawFoldingFeatureProducer;
import androidx.window.util.DataProducer;
import androidx.window.util.ExtensionHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\androidx.window.extensions\classes.dex */
public class WindowLayoutComponentImpl implements WindowLayoutComponent {
    private static final String TAG = "SampleExtension";
    private final DataProducer<List<CommonFoldingFeature>> mFoldingFeatureProducer;
    private final Map<Activity, Consumer<WindowLayoutInfo>> mWindowLayoutChangeListeners = new ArrayMap();

    public WindowLayoutComponentImpl(Context context) {
        ((Application) context.getApplicationContext()).registerActivityLifecycleCallbacks(new NotifyOnConfigurationChanged());
        RawFoldingFeatureProducer foldingFeatureProducer = new RawFoldingFeatureProducer(context);
        DeviceStateManagerFoldingFeatureProducer deviceStateManagerFoldingFeatureProducer = new DeviceStateManagerFoldingFeatureProducer(context, foldingFeatureProducer);
        this.mFoldingFeatureProducer = deviceStateManagerFoldingFeatureProducer;
        deviceStateManagerFoldingFeatureProducer.addDataChangedCallback(new Runnable() { // from class: androidx.window.extensions.layout.WindowLayoutComponentImpl$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.onDisplayFeaturesChanged();
            }
        });
    }

    @Override // androidx.window.extensions.layout.WindowLayoutComponent
    public void addWindowLayoutInfoListener(Activity activity, Consumer<WindowLayoutInfo> consumer) {
        this.mWindowLayoutChangeListeners.put(activity, consumer);
        onDisplayFeaturesChanged();
    }

    @Override // androidx.window.extensions.layout.WindowLayoutComponent
    public void removeWindowLayoutInfoListener(Consumer<WindowLayoutInfo> consumer) {
        this.mWindowLayoutChangeListeners.values().remove(consumer);
        onDisplayFeaturesChanged();
    }

    void updateWindowLayout(Activity activity, WindowLayoutInfo newLayout) {
        Consumer<WindowLayoutInfo> consumer = this.mWindowLayoutChangeListeners.get(activity);
        if (consumer != null) {
            consumer.accept(newLayout);
        }
    }

    Set<Activity> getActivitiesListeningForLayoutChanges() {
        return this.mWindowLayoutChangeListeners.keySet();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isListeningForLayoutChanges(IBinder token) {
        for (Activity activity : getActivitiesListeningForLayoutChanges()) {
            if (token.equals(activity.getWindow().getAttributes().token)) {
                return true;
            }
        }
        return false;
    }

    protected boolean hasListeners() {
        return !this.mWindowLayoutChangeListeners.isEmpty();
    }

    private Integer convertToExtensionState(int state) {
        if (state == 3) {
            return 1;
        }
        if (state == 2) {
            return 2;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDisplayFeaturesChanged() {
        for (Activity activity : getActivitiesListeningForLayoutChanges()) {
            WindowLayoutInfo newLayout = getWindowLayoutInfo(activity);
            updateWindowLayout(activity, newLayout);
        }
    }

    private WindowLayoutInfo getWindowLayoutInfo(Activity activity) {
        List<DisplayFeature> displayFeatures = getDisplayFeatures(activity);
        return new WindowLayoutInfo(displayFeatures);
    }

    private List<DisplayFeature> getDisplayFeatures(Activity activity) {
        List<DisplayFeature> features = new ArrayList<>();
        int displayId = activity.getDisplay().getDisplayId();
        if (displayId != 0) {
            Log.w(TAG, "This sample doesn't support display features on secondary displays");
            return features;
        }
        if (isTaskInMultiWindowMode(activity)) {
            return features;
        }
        Optional<List<CommonFoldingFeature>> storedFeatures = this.mFoldingFeatureProducer.getData();
        if (storedFeatures.isPresent()) {
            for (CommonFoldingFeature baseFeature : storedFeatures.get()) {
                Integer state = convertToExtensionState(baseFeature.getState());
                if (state != null) {
                    Rect featureRect = baseFeature.getRect();
                    ExtensionHelper.rotateRectToDisplayRotation(displayId, featureRect);
                    ExtensionHelper.transformToWindowSpaceRect(activity, featureRect);
                    if (!isRectZero(featureRect)) {
                        features.add(new FoldingFeature(featureRect, baseFeature.getType(), state.intValue()));
                    }
                }
            }
        }
        return features;
    }

    private boolean isTaskInMultiWindowMode(Activity activity) {
        ActivityManager am = (ActivityManager) activity.getSystemService(ActivityManager.class);
        if (am == null) {
            return true;
        }
        List<ActivityManager.AppTask> appTasks = am.getAppTasks();
        int taskId = activity.getTaskId();
        ActivityManager.AppTask task = null;
        for (ActivityManager.AppTask t : appTasks) {
            if (t.getTaskInfo().taskId == taskId) {
                task = t;
                break;
            }
        }
        if (task == null) {
            return true;
        }
        return WindowConfiguration.inMultiWindowMode(task.getTaskInfo().getWindowingMode());
    }

    private boolean isRectZero(Rect rect) {
        return rect.width() == 0 && rect.height() == 0;
    }

    private final class NotifyOnConfigurationChanged extends EmptyLifecycleCallbacksAdapter {
        private NotifyOnConfigurationChanged() {
        }

        @Override // androidx.window.common.EmptyLifecycleCallbacksAdapter, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
            super.onActivityCreated(activity, savedInstanceState);
            onDisplayFeaturesChangedIfListening(activity);
        }

        public void onActivityConfigurationChanged(Activity activity) {
            super.onActivityConfigurationChanged(activity);
            onDisplayFeaturesChangedIfListening(activity);
        }

        private void onDisplayFeaturesChangedIfListening(Activity activity) {
            IBinder token = activity.getWindow().getAttributes().token;
            if (token == null || WindowLayoutComponentImpl.this.isListeningForLayoutChanges(token)) {
                WindowLayoutComponentImpl.this.onDisplayFeaturesChanged();
            }
        }
    }
}
