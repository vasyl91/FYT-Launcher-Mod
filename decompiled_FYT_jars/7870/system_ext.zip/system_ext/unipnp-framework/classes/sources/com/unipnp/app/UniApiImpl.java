package com.unipnp.app;

import android.R;
import android.app.NotificationManager;
import android.app.unipnp.Ulog;
import android.app.unipnp.UnionManager;
import android.app.unipnp.absclass.AbsUniApi;
import android.app.unipnp.parcel.TaskThumbnail;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.service.notification.StatusBarNotification;
import android.view.DisplayCutout;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.window.SplashScreenView;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unipnp-framework\classes.dex */
public class UniApiImpl extends AbsUniApi {
    private static List<String> scrollableViews;

    static {
        String[] views = {"listview", "abslistview", "adapterview", "recyclerview", "scrollview", "pagedview", "gridview", "webview"};
        scrollableViews = Arrays.asList(views);
    }

    public static long getNotificationPostTime(Context context, String packageName, int uid) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(NotificationManager.class);
        if (notificationManager != null) {
            StatusBarNotification[] notifications = notificationManager.getActiveNotifications();
            for (StatusBarNotification notification : notifications) {
                if (notification.getPackageName().equals(packageName) && notification.getUid() == uid) {
                    return notification.getPostTime();
                }
            }
            return -1L;
        }
        return -1L;
    }

    public boolean isScrollableView(ViewGroup viewGroup) {
        int childCount = viewGroup.getChildCount();
        for (int i = childCount - 1; i >= 0; i--) {
            View childView = viewGroup.getChildAt(i);
            if (childView.getVisibility() == 0 && childView.getLocalVisibleRect(new Rect()) && childView.isAttachedToWindow() && (childView instanceof ViewGroup)) {
                ViewGroup childViewGroup = (ViewGroup) childView;
                Class<?> superclass = childViewGroup.getClass();
                for (int j = 0; j < 3; j++) {
                    String classNamepath = superclass.getName().toLowerCase();
                    int index = classNamepath.lastIndexOf(".");
                    String className = classNamepath.substring(index + 1);
                    if (scrollableViews.contains(className)) {
                        return true;
                    }
                    if (className.equals("viewgroup")) {
                        break;
                    }
                    superclass = superclass.getSuperclass();
                }
                if (isScrollableView((ViewGroup) childView)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean hasAddSnapshotView(Context context, ActivityInfo info, SplashScreenView splashScreenView, ImageView snapshotImageView) {
        ImageView snapshotImageView2;
        if (info == null || splashScreenView == null || (snapshotImageView2 = getSnapshotBgView(context, Intent.makeMainActivity(info.getComponentName()))) == null) {
            return false;
        }
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -1);
        splashScreenView.addView(snapshotImageView2, lp);
        return true;
    }

    public void recycleImageView(ImageView imageView) {
        BitmapDrawable bitmapDrawable;
        Bitmap bitmap;
        if (imageView != null && (bitmapDrawable = (BitmapDrawable) imageView.getDrawable()) != null && (bitmap = bitmapDrawable.getBitmap()) != null && !bitmap.isRecycled()) {
            bitmap.recycle();
        }
    }

    private ImageView getSnapshotBgView(Context context, Intent intent) {
        int statusHeight;
        Drawable background = getStartingWindowBgDrawable(intent);
        if (background != null) {
            ImageView bg = new ImageView(context);
            bg.setScaleType(ImageView.ScaleType.FIT_XY);
            bg.setImageDrawable(background);
            DisplayCutout displayCutout = context.getDisplay().getCutout();
            if (displayCutout != null) {
                statusHeight = displayCutout.getSafeInsetTop();
            } else {
                statusHeight = context.getResources().getDimensionPixelSize(R.dimen.notification_2025_messaging_spacing);
            }
            int navHeight = 0;
            if (0 != 0) {
                navHeight = context.getResources().getDimensionPixelSize(R.dimen.indeterminate_progress_alpha_25);
            }
            bg.setPadding(0, statusHeight, 0, navHeight);
            return bg;
        }
        return null;
    }

    private Drawable getStartingWindowBgDrawable(Intent intent) {
        Bitmap thumbnail = null;
        TaskThumbnail thumb = null;
        try {
            try {
                try {
                    thumb = UnionManager.getService().getTaskThumbnail(intent);
                    if (thumb != null) {
                        thumbnail = thumb.mainThumbnail;
                        if (thumbnail != null && thumbnail.isRecycled()) {
                            thumbnail = null;
                        }
                        if (thumbnail == null && thumb.thumbnailFileDescriptor != null) {
                            thumbnail = BitmapFactory.decodeFileDescriptor(thumb.thumbnailFileDescriptor.getFileDescriptor(), null, new BitmapFactory.Options());
                            Ulog.d(TAG, "getTaskThumbnail null or recyled,decode from file...->" + thumbnail);
                        }
                    }
                    if (thumbnail != null) {
                        Ulog.d(TAG, "return thumbnail----->" + thumbnail);
                        BitmapDrawable bitmapDrawable = new BitmapDrawable(thumbnail);
                        if (thumb != null && thumb.thumbnailFileDescriptor != null) {
                            try {
                                thumb.thumbnailFileDescriptor.close();
                            } catch (IOException ioerror) {
                                ioerror.printStackTrace();
                            }
                        }
                        return bitmapDrawable;
                    }
                    if (thumb != null && thumb.thumbnailFileDescriptor != null) {
                        thumb.thumbnailFileDescriptor.close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    if (thumb != null && thumb.thumbnailFileDescriptor != null) {
                        thumb.thumbnailFileDescriptor.close();
                    }
                }
            } catch (IOException ioerror2) {
                ioerror2.printStackTrace();
            }
            return null;
        } catch (Throwable th) {
            if (thumb != null && thumb.thumbnailFileDescriptor != null) {
                try {
                    thumb.thumbnailFileDescriptor.close();
                } catch (IOException ioerror3) {
                    ioerror3.printStackTrace();
                }
            }
            throw th;
        }
    }
}
