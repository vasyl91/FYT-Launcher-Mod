package com.unipnp.app.util;

import android.app.unipnp.Ulog;
import android.text.TextUtils;
import com.unipnp.app.info.RuleNode;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unipnp-framework\classes.dex */
public class PolicyParse {
    private static final String TAG = PolicyParse.class.getSimpleName();
    private final PolicyAction mAction;

    public PolicyParse(String actionName, RuleNode node) {
        this.mAction = parseAction(actionName, node);
    }

    private PolicyAction parseAction(String actionName, RuleNode node) {
        try {
            Action action = Action.valueOf(actionName);
            switch (AnonymousClass1.$SwitchMap$com$unipnp$app$util$Action[action.ordinal()]) {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    PolicyAction policyAction = new ParamAction(actionName, node);
                    return policyAction;
                default:
                    PolicyAction policyAction2 = new PolicyAction(actionName);
                    return policyAction2;
            }
        } catch (Exception e) {
            Ulog.e(TAG, "Do not support this action : " + actionName);
            return new PolicyAction(actionName);
        }
    }

    /* JADX INFO: renamed from: com.unipnp.app.util.PolicyParse$1, reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$unipnp$app$util$Action;

        static {
            int[] iArr = new int[Action.values().length];
            $SwitchMap$com$unipnp$app$util$Action = iArr;
            try {
                iArr[Action.POWER_BOOST.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$unipnp$app$util$Action[Action.FAST_KILL.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$unipnp$app$util$Action[Action.FAST_FREEZER.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$unipnp$app$util$Action[Action.PROCESS_SCHED.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$unipnp$app$util$Action[Action.ANIM_SCALE.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$unipnp$app$util$Action[Action.STOP_POWER_BOOST.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$unipnp$app$util$Action[Action.STOP_PROCESS_SCHED.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
        }
    }

    public String getActionInfo(String data) {
        return this.mAction.getActionInfo(data);
    }

    static class PolicyAction {
        String name;

        public PolicyAction(String name) {
            this.name = name;
        }

        public String getActionInfo(String data) {
            return null;
        }
    }

    static class ParamAction extends PolicyAction {
        RuleNode actionNode;

        public ParamAction(String name, RuleNode actionNode) {
            super(name);
            this.actionNode = actionNode;
        }

        @Override // com.unipnp.app.util.PolicyParse.PolicyAction
        public String getActionInfo(String data) {
            if (TextUtils.isEmpty(data)) {
                return null;
            }
            String defaultAction = null;
            String matchAction = null;
            for (String str : this.actionNode.getList()) {
                if (!TextUtils.isEmpty(str)) {
                    if (str.startsWith("*")) {
                        if (TextUtils.isEmpty(defaultAction)) {
                            defaultAction = str.replaceFirst("[*]", data);
                        }
                    } else {
                        if (str.contains(data)) {
                            matchAction = str;
                            break;
                        }
                        if (TextUtils.isEmpty(matchAction)) {
                            String[] tmp = str.split("[,|]");
                            if (tmp.length > 0 && data.contains(tmp[0])) {
                                matchAction = str.replaceFirst(tmp[0], data);
                            }
                        }
                    }
                }
            }
            return TextUtils.isEmpty(matchAction) ? defaultAction : matchAction;
        }
    }
}
