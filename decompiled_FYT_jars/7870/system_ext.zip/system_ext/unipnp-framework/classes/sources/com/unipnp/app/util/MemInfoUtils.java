package com.unipnp.app.util;

import android.app.ActivityManager;
import android.content.Context;
import com.android.internal.util.MemInfoReader;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unipnp-framework\classes.dex */
public class MemInfoUtils {
    public static long getSwapUsage() {
        MemInfoReader memInfo = new MemInfoReader();
        memInfo.readMemInfo();
        long swapTotal = memInfo.getSwapTotalSizeKb();
        long swapFree = memInfo.getSwapFreeSizeKb();
        return ((swapTotal - swapFree) * 100) / swapTotal;
    }

    public static long getMemAvail(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        if (activityManager != null) {
            activityManager.getMemoryInfo(memoryInfo);
        }
        return memoryInfo.availMem;
    }
}
