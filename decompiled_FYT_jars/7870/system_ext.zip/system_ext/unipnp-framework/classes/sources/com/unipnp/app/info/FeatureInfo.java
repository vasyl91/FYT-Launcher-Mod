package com.unipnp.app.info;

import android.app.unipnp.Ulog;
import java.util.ArrayList;
import java.util.HashSet;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unipnp-framework\classes.dex */
public class FeatureInfo {
    public static final int DEFAULT_PRIORITY = 99;
    private static final String TAG = FeatureInfo.class.getSimpleName();
    public String classname;
    public String dexpath;
    public boolean enabled;
    public int id;
    public final String name;
    public final String pnpVersion;
    RuleNode rootNode;
    public int version;
    public final HashSet<String> events = new HashSet<>();
    public int priority = 99;

    public FeatureInfo(String featureName, String pVersion) {
        this.pnpVersion = pVersion;
        this.name = featureName;
    }

    public void updateEvents(ArrayList<String> eventlist) {
        this.events.clear();
        this.events.addAll(eventlist);
    }

    public void addEvent(String event) {
        if (!this.events.contains(event)) {
            this.events.add(event);
        } else {
            Ulog.i(TAG, event + " already registered in Feature : " + this.name);
        }
    }

    public void removeEvent(String event) {
        if (this.events.contains(event)) {
            this.events.remove(event);
        } else {
            Ulog.i(TAG, event + " no need unregister in Feature : " + this.name);
        }
    }

    public void setRule(RuleNode ruleNode) {
        this.rootNode = ruleNode;
    }

    public RuleNode getPolicy(String key) {
        RuleNode ruleNode = this.rootNode;
        if (ruleNode == null) {
            return null;
        }
        return ruleNode.childNodes.get(key);
    }

    public String toString() {
        StringBuffer sb = new StringBuffer("---------- " + this.name + " FeatureInfo ----------\n");
        sb.append("UNIPNP version : " + this.pnpVersion + "\n");
        sb.append("\n<feature>\n");
        sb.append("    <name>" + this.name + "</name>\n");
        sb.append("    <classname>" + this.classname + "</classname>\n");
        sb.append("    <dexpath>" + this.dexpath + "</dexpath>\n");
        sb.append("    <version>" + this.version + "</version>\n");
        sb.append("    <enabled>" + this.enabled + "</enabled>\n");
        sb.append("    <unievent>\n");
        for (String event : this.events) {
            sb.append("        <event>" + event + "</event>\n");
        }
        sb.append("    </unievent>\n");
        sb.append(this.rootNode);
        sb.append("</feature>\n");
        return sb.toString();
    }
}
