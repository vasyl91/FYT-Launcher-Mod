package com.unipnp.app.info;

import android.app.unipnp.Ulog;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unipnp-framework\classes.dex */
public class RuleNode {
    private static final String TAG = RuleNode.class.getSimpleName();
    final Map<String, RuleNode> childNodes;
    final Boolean isList;
    public final Boolean isRoot;
    public final String key;
    final List<String> list;
    String listTag;
    final Map<String, String> map;
    public final String nodeTag;
    RuleNode parentNode;

    public RuleNode(String tag, String key) {
        this(tag, key, false, null);
    }

    public RuleNode(String tag, String key, Boolean isRoot) {
        this(tag, key, isRoot, null);
    }

    public RuleNode(String tag, String key, RuleNode parentNode) {
        this(tag, key, false, parentNode);
    }

    public RuleNode(String tag, String key, Boolean isRoot, RuleNode parentNode) {
        this.isList = true;
        this.list = new ArrayList();
        this.map = new HashMap();
        this.childNodes = new HashMap();
        this.isRoot = isRoot;
        this.nodeTag = tag;
        this.key = key;
        this.parentNode = parentNode;
    }

    public void setParentNode(RuleNode node) {
        this.parentNode = node;
    }

    public RuleNode getParentNode() {
        return this.parentNode;
    }

    public void addStringValue(String key, String value) {
        if (this.isRoot.booleanValue()) {
            Ulog.e(TAG, "Root rule node not allowed add String KEY : " + key + " VALUE : " + value);
            return;
        }
        this.listTag = key;
        this.list.add(value);
        this.map.put(key, value);
    }

    public void addChildNode(RuleNode node) {
        if (node != null) {
            this.childNodes.put(node.key, node);
        }
    }

    public Map<String, RuleNode> getChildNodes() {
        return this.childNodes;
    }

    public List<String> getList() {
        return this.map.size() > 1 ? new ArrayList() : this.list;
    }

    public Map<String, String> getMap() {
        return this.map;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("    <" + this.nodeTag + ">\n");
        if (this.map.size() > 1) {
            for (Map.Entry<String, String> entry : this.map.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                sb.append("        <" + key + ">" + value + "</" + key + ">\n");
            }
        } else {
            for (String str : this.list) {
                sb.append("        <" + this.listTag + ">" + str + "</" + this.listTag + ">\n");
            }
        }
        Iterator<Map.Entry<String, RuleNode>> it = this.childNodes.entrySet().iterator();
        while (it.hasNext()) {
            RuleNode n = it.next().getValue();
            sb.append(n);
        }
        sb.append("    </" + this.nodeTag + ">\n");
        return sb.toString();
    }
}
