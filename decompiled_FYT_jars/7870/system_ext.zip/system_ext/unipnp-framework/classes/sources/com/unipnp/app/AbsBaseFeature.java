package com.unipnp.app;

import android.app.unipnp.Ulog;
import android.app.unipnp.absclass.UmsLocalServiceInternal;
import android.app.unipnp.parcel.UniEventData;
import android.content.Context;
import com.android.server.LocalServices;
import com.unipnp.app.info.FeatureInfo;
import com.unipnp.app.info.RuleNode;
import com.unipnp.app.util.PolicyParse;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Map;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unipnp-framework\classes.dex */
public abstract class AbsBaseFeature {
    private static final String TAG = AbsBaseFeature.class.getSimpleName();
    protected Context mContext;
    protected FeatureInfo mInfo;
    public UmsLocalServiceInternal mUmsLocalService = (UmsLocalServiceInternal) LocalServices.getService(UmsLocalServiceInternal.class);

    public abstract boolean disable();

    public abstract void dump(FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract boolean enable();

    public abstract Object execFunction(String str, Object... objArr);

    public abstract boolean onReceiveEvent(UniEventData uniEventData);

    public AbsBaseFeature(Context context, FeatureInfo info) {
        this.mContext = context;
        this.mInfo = info;
    }

    public void updateFeatureInfo(FeatureInfo info) {
        this.mInfo = info;
    }

    public FeatureInfo getFeatureInfo() {
        return this.mInfo;
    }

    public boolean custConfigUpdate() {
        return false;
    }

    public void execActions(String timing, String data) {
        RuleNode itemNode = this.mInfo.getPolicy(timing);
        if (itemNode != null) {
            for (Map.Entry<String, RuleNode> entry : itemNode.getChildNodes().entrySet()) {
                PolicyParse policy = new PolicyParse(entry.getKey(), entry.getValue());
                Ulog.i(TAG, "Action name: " + entry.getKey() + " Action info : " + policy.getActionInfo(data));
                this.mUmsLocalService.doAction(this.mInfo.id, entry.getKey(), policy.getActionInfo(data));
            }
        }
    }
}
