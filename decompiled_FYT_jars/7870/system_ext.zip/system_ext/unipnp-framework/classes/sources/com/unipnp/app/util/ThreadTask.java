package com.unipnp.app.util;

import com.unipnp.app.info.FeatureInfo;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unipnp-framework\classes.dex */
public abstract class ThreadTask implements Runnable, Comparable<ThreadTask> {
    private static final int DEFAULT_PRIORITY = 99;
    private static final String DEFAULT_THREADTASK_NAME = "ThreadTask_Default";
    public final long createTime;
    private final int priority;
    public final String taskName;

    public ThreadTask() {
        this(DEFAULT_THREADTASK_NAME);
    }

    public ThreadTask(String taskName) {
        this(taskName, 99);
    }

    public ThreadTask(FeatureInfo info) {
        this(info.name, info.priority);
    }

    public ThreadTask(String taskName, int priority) {
        this.taskName = taskName;
        this.priority = priority;
        this.createTime = System.currentTimeMillis();
    }

    @Override // java.lang.Comparable
    public int compareTo(ThreadTask o) {
        return this.priority > o.priority ? -1 : 1;
    }
}
