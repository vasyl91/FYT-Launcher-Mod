package com.unipnp.app.util;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unipnp-framework\classes.dex */
public enum Action {
    FAST_KILL("release memory size you needed", "Param: 1.action 2.cur package name 3.memory size needed", "eg: FAST_KILL com.android.xxxx,180"),
    POWER_BOOST("Start POWER BOOST", "Param: 1.action 2.package 3.power hint type 4.duration 0 is allways", "eg: POWER_BOOST com.android.xxxx,POWER_HINT_VENDOR_BENCHMARK,0"),
    STOP_POWER_BOOST("Stop POWER BOOST", "Param: 1.action", "STOP_POWER_BOOST "),
    PROCESS_SCHED("resize the thread's priority", "Param: 1.action 2.package 3.process 4.thread name 5.Process.SCHED 6.prio 7.(#4.5.6) 8.(#...))", "eg: PROCESS_SCHED com.example.app,com.example.app,example.test,rr,1,Unity*,rr,-19"),
    STOP_PROCESS_SCHED("Stop PROCESS_SCHED", "Param: 1.action", "STOP_PROCESS_SCHED"),
    ANIM_SCALE("set scale of the anim", "Param: 1.action 2.Window Scale(0),Transition Scale(1),duration Scale(2),All (3) 3.Scale(0~20)", "eg: ANIM_SCALE 2,0"),
    RESTORE_ANIM_SCALE("RESTORE_ANIM_SCALE", "Param: 1.action", "RESTORE_ANIM_SCALE"),
    FAST_FREEZER("freeze some process you needed when app start", "Param: 1.action 2.cur package name 3.target", "eg: FAST_FREEZER com.android.xxxx,com.sprd.helloworld"),
    FAST_UNFREEZER("unfreezer all process that frozen", "Param: 1.action", "eg: FAST_UNFREEZER");

    public final String describe;
    public final String eg;
    public final String param;

    Action(String describe, String param, String eg) {
        this.describe = describe;
        this.param = param;
        this.eg = eg;
    }
}
