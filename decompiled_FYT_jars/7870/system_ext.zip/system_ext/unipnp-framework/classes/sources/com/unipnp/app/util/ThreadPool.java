package com.unipnp.app.util;

import android.app.unipnp.Ulog;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unipnp-framework\classes.dex */
public class ThreadPool {
    private static final int CORE_POOL_SIZE = 1;
    private static final int CPU_COUNT;
    private static final int KEEP_ALIVE = 1;
    private static final int MAXIMUM_POOL_SIZE;
    private static final String TAG = "ThreadPool";
    public static ThreadPoolExecutor THREAD_POOL_EXECUTOR;
    private static ThreadFactory mThreadFactory;

    static {
        int iAvailableProcessors = Runtime.getRuntime().availableProcessors();
        CPU_COUNT = iAvailableProcessors;
        int i = iAvailableProcessors + 1;
        MAXIMUM_POOL_SIZE = i;
        mThreadFactory = new ThreadFactory() { // from class: com.unipnp.app.util.ThreadPool.1
            @Override // java.util.concurrent.ThreadFactory
            public Thread newThread(Runnable r) {
                String thName = String.valueOf(r.hashCode());
                Ulog.d(ThreadPool.TAG, "Thread : " + thName + " created.");
                return new Thread(r, "ThreadPool " + thName);
            }
        };
        THREAD_POOL_EXECUTOR = new ThreadPoolExecutor(1, i, 1L, TimeUnit.SECONDS, new PriorityBlockingQueue(), mThreadFactory, new ThreadPoolExecutor.CallerRunsPolicy()) { // from class: com.unipnp.app.util.ThreadPool.2
            @Override // java.util.concurrent.ThreadPoolExecutor
            protected void beforeExecute(Thread t, Runnable r) {
                Ulog.i(ThreadPool.TAG, "beforeExecute: " + ((ThreadTask) r).taskName);
            }

            @Override // java.util.concurrent.ThreadPoolExecutor
            protected void afterExecute(Runnable r, Throwable t) {
                Ulog.i(ThreadPool.TAG, "afterExecute: " + ((ThreadTask) r).taskName, t);
            }

            @Override // java.util.concurrent.ThreadPoolExecutor
            protected void terminated() {
                Ulog.i(ThreadPool.TAG, "terminated : " + Thread.currentThread().getName());
            }
        };
    }
}
