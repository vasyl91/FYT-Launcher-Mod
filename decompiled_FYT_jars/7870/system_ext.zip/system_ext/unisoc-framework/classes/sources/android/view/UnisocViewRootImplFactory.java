package android.view;

import android.content.Context;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public class UnisocViewRootImplFactory extends ViewRootImplFactory {
    public ViewRootImpl makeViewRootImpl(Context context, Display display) {
        UnisocViewRootImpl unisocViewRootImpl = new UnisocViewRootImpl(context, display);
        return unisocViewRootImpl;
    }
}
