package android.telephony;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public final class UniSettings {

    public static final class UniGlobal {
        public static final String MOBILE_DATA_ALWAYS_ONLINE = "mobile_data_always_online";
        public static final String MOBILE_ICC_OPERATOR_NUMERIC = "mobile_icc_operator_numeric";
        public static final String RESTRICT_NETWORK_TYPE = "restrict_network_type";
        public static final String SPECIAL_SIM_CARD_NAME = "special_sim_card_name";
    }
}
