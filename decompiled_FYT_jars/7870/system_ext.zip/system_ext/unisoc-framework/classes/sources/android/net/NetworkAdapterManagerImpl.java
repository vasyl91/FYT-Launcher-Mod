package android.net;

import android.os.RemoteException;
import android.os.ServiceManager;
import android.util.Log;
import java.net.InetAddress;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public class NetworkAdapterManagerImpl extends NetworkAdapterManager {
    private final String TAG = "NetworkAdapterManagerImpl";
    private INetworkAdapterService mNAS;

    public NetworkAdapterManagerImpl() {
        getNetworkAdapter();
    }

    public void closeInterfaceSockets() {
        Log.d("NetworkAdapterManagerImpl", "close current default cellular network interface whole sockets");
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.closeInterfaceSockets();
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public void setIPv6Mtu(String iface, int ipv6Mtu) {
        Log.d("NetworkAdapterManagerImpl", "setIPv6Mtu: ipv6Mtu = " + ipv6Mtu);
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.setIPv6Mtu(iface, ipv6Mtu);
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public void sendCmdsToDaemon(String cmd) {
        Log.d("NetworkAdapterManagerImpl", "sendCmdsToDaemon: cmd = " + cmd);
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.sendCmdsToDaemon(cmd);
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public void setDnsFilterEnabled(int enabled) {
        Log.d("NetworkAdapterManagerImpl", "setDnsFilterEnabled: enabled = " + enabled);
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.setDnsFilterEnabled(enabled);
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public void setFytAtModem() {
        Log.d("NetworkAdapterManagerImpl", "setFytAtModem");
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.setFytAtModem();
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public void setFytDnsFilter(boolean enable) {
        Log.d("NetworkAdapterManagerImpl", "setFytDnsPort");
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.setFytDnsFilter(enable);
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public void setFytDnsPort(int protocol, int port, boolean add) {
        Log.d("NetworkAdapterManagerImpl", "setFytDnsPort");
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.setFytDnsPort(protocol, port, add);
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public void setFytBlackIpList(String addr, boolean add) {
        Log.d("NetworkAdapterManagerImpl", "setFytBlackIpList");
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.setFytBlackIpList(addr, add);
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public void setFytWhiteIpList(String addr, boolean add) {
        Log.d("NetworkAdapterManagerImpl", "setFytWhiteIpList");
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.setFytWhiteIpList(addr, add);
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public void setFytIpAndPort(int protocol, String addr, int port, boolean add) {
        Log.d("NetworkAdapterManagerImpl", "setFytIpAndPort");
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.setFytIpAndPort(protocol, addr, port, add);
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public void setEthernetInterface(int enabled) {
        Log.d("NetworkAdapterManagerImpl", "setEthernetInterface: enabled = " + enabled);
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.setEthernetInterface(enabled);
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public void deleteExtraIPv6Addr(String ipv6Addr, String interfaceName) {
        Log.d("NetworkAdapterManagerImpl", "deleteExtraIPv6Addr: ipv6Addr = " + ipv6Addr);
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            this.mNAS.deleteExtraIPv6Addr(ipv6Addr, interfaceName);
        } catch (RemoteException e) {
        } catch (NullPointerException e2) {
        }
    }

    public boolean bindAppUidToNetwork(int uid, Network network) {
        Log.d("NetworkAdapterManagerImpl", "Bind app's uid to network");
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            return this.mNAS.bindAppUidToNetwork(uid, network);
        } catch (RemoteException e) {
            Log.e("NetworkAdapterManagerImpl", "Unable to bind appid to network");
            return false;
        } catch (NullPointerException e2) {
            return false;
        }
    }

    public boolean bindDstIpToNetwork(InetAddress dstAddr, Network network) {
        Log.d("NetworkAdapterManagerImpl", "Bind app's IP address to network");
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            return this.mNAS.bindDstIpToNetwork(dstAddr.getHostAddress(), network);
        } catch (RemoteException e) {
            Log.e("NetworkAdapterManagerImpl", "Unable to bind destined IP to network");
            return false;
        } catch (NullPointerException e2) {
            return false;
        }
    }

    private void getNetworkAdapter() {
        if (this.mNAS == null) {
            this.mNAS = INetworkAdapterService.Stub.asInterface(ServiceManager.getService("network_adapter"));
        }
        Log.d("NetworkAdapterManagerImpl", "getNetworkAdapter: mNAS = " + this.mNAS);
    }

    public int doPingForVowifi(int ipv4Flag, String srcIP, String dstIP) {
        Log.d("NetworkAdapterManagerImpl", "doPingForVowifi: dstIP = " + dstIP);
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            return this.mNAS.doPingForVowifi(ipv4Flag, srcIP, dstIP);
        } catch (RemoteException e) {
            Log.e("NetworkAdapterManagerImpl", "Unable to do Ping for Vowifi");
            return -1;
        } catch (NullPointerException e2) {
            return -1;
        }
    }

    public boolean probeNetworkReachableActually() {
        Log.d("NetworkAdapterManagerImpl", "probe isNetworkReachableActually");
        if (this.mNAS == null) {
            getNetworkAdapter();
        }
        try {
            return this.mNAS.probeNetworkReachableActually();
        } catch (RemoteException | NullPointerException e) {
            return false;
        }
    }
}
