package android.media;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public class AudioSystemEx {
    public static final int DEVICE_OUT_FM_HEADSET = 1048576;
    public static final int FOR_FM = 8;
}
