package android.net;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public interface INetworkReachableNotifier extends IInterface {
    public static final String DESCRIPTOR = "android.net.INetworkReachableNotifier";

    void onNotifyNetworkReachable(boolean z) throws RemoteException;

    public static class Default implements INetworkReachableNotifier {
        @Override // android.net.INetworkReachableNotifier
        public void onNotifyNetworkReachable(boolean isReachable) throws RemoteException {
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }
    }

    public static abstract class Stub extends Binder implements INetworkReachableNotifier {
        static final int TRANSACTION_onNotifyNetworkReachable = 1;

        public Stub() {
            attachInterface(this, INetworkReachableNotifier.DESCRIPTOR);
        }

        public static INetworkReachableNotifier asInterface(IBinder obj) {
            if (obj == null) {
                return null;
            }
            IInterface iin = obj.queryLocalInterface(INetworkReachableNotifier.DESCRIPTOR);
            if (iin != null && (iin instanceof INetworkReachableNotifier)) {
                return (INetworkReachableNotifier) iin;
            }
            return new Proxy(obj);
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            if (code >= 1 && code <= 16777215) {
                data.enforceInterface(INetworkReachableNotifier.DESCRIPTOR);
            }
            switch (code) {
                case 1598968902:
                    reply.writeString(INetworkReachableNotifier.DESCRIPTOR);
                    return true;
                default:
                    switch (code) {
                        case 1:
                            boolean _arg0 = data.readBoolean();
                            data.enforceNoDataAvail();
                            onNotifyNetworkReachable(_arg0);
                            return true;
                        default:
                            return super.onTransact(code, data, reply, flags);
                    }
            }
        }

        private static class Proxy implements INetworkReachableNotifier {
            private IBinder mRemote;

            Proxy(IBinder remote) {
                this.mRemote = remote;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return INetworkReachableNotifier.DESCRIPTOR;
            }

            @Override // android.net.INetworkReachableNotifier
            public void onNotifyNetworkReachable(boolean isReachable) throws RemoteException {
                Parcel _data = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkReachableNotifier.DESCRIPTOR);
                    _data.writeBoolean(isReachable);
                    this.mRemote.transact(1, _data, null, 1);
                } finally {
                    _data.recycle();
                }
            }
        }
    }
}
