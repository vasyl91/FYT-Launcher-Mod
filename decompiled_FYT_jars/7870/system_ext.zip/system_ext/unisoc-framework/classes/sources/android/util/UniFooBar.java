package android.util;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public class UniFooBar extends FooBar {
    public void foo() {
        Log.d("UniFooBar", "Override foo()");
    }

    public int bar() {
        Log.d("UniFooBar", "Override bar()");
        return -1;
    }
}
