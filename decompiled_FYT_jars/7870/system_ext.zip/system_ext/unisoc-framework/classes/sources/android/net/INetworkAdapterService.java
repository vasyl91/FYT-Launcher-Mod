package android.net;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public interface INetworkAdapterService extends IInterface {
    public static final String DESCRIPTOR = "android.net.INetworkAdapterService";

    int addAllowedListUidForTraffic(int i, boolean z) throws RemoteException;

    boolean bindAppUidToNetwork(int i, Network network) throws RemoteException;

    boolean bindDstIpToNetwork(String str, Network network) throws RemoteException;

    void closeInterfaceSockets() throws RemoteException;

    void deleteExtraIPv6Addr(String str, String str2) throws RemoteException;

    int doPingForVowifi(int i, String str, String str2) throws RemoteException;

    int enableTrafficLimit(boolean z, String str) throws RemoteException;

    int getMptcpStatus() throws RemoteException;

    int initTrafficLimit() throws RemoteException;

    boolean probeNetworkReachableActually() throws RemoteException;

    void registerNetworkReachableNotifier(INetworkReachableNotifier iNetworkReachableNotifier) throws RemoteException;

    void sendCmdsToDaemon(String str) throws RemoteException;

    void setDnsFilterEnabled(int i) throws RemoteException;

    void setEthernetInterface(int i) throws RemoteException;

    void setFytAtModem() throws RemoteException;

    void setFytBlackIpList(String str, boolean z) throws RemoteException;

    void setFytDnsFilter(boolean z) throws RemoteException;

    void setFytDnsPort(int i, int i2, boolean z) throws RemoteException;

    void setFytIpAndPort(int i, String str, int i2, boolean z) throws RemoteException;

    void setFytWhiteIpList(String str, boolean z) throws RemoteException;

    void setIPv6Mtu(String str, int i) throws RemoteException;

    int setMptcpStatus(boolean z) throws RemoteException;

    int setTrafficLimit(boolean z, int i) throws RemoteException;

    void unregisterNetworkReachableNotifier(INetworkReachableNotifier iNetworkReachableNotifier) throws RemoteException;

    public static class Default implements INetworkAdapterService {
        @Override // android.net.INetworkAdapterService
        public void closeInterfaceSockets() throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public boolean probeNetworkReachableActually() throws RemoteException {
            return false;
        }

        @Override // android.net.INetworkAdapterService
        public void registerNetworkReachableNotifier(INetworkReachableNotifier callback) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public void unregisterNetworkReachableNotifier(INetworkReachableNotifier callback) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public void setIPv6Mtu(String iface, int ipv6Mtu) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public void sendCmdsToDaemon(String cmd) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public void setDnsFilterEnabled(int enabled) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public void setEthernetInterface(int enabled) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public void deleteExtraIPv6Addr(String ipv6Addr, String interfaceName) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public boolean bindAppUidToNetwork(int uid, Network network) throws RemoteException {
            return false;
        }

        @Override // android.net.INetworkAdapterService
        public boolean bindDstIpToNetwork(String dstAddr, Network network) throws RemoteException {
            return false;
        }

        @Override // android.net.INetworkAdapterService
        public int getMptcpStatus() throws RemoteException {
            return 0;
        }

        @Override // android.net.INetworkAdapterService
        public int setMptcpStatus(boolean enable) throws RemoteException {
            return 0;
        }

        @Override // android.net.INetworkAdapterService
        public int doPingForVowifi(int ipv4Flag, String srcIP, String dstIP) throws RemoteException {
            return 0;
        }

        @Override // android.net.INetworkAdapterService
        public int initTrafficLimit() throws RemoteException {
            return 0;
        }

        @Override // android.net.INetworkAdapterService
        public int enableTrafficLimit(boolean enabled, String interfaceName) throws RemoteException {
            return 0;
        }

        @Override // android.net.INetworkAdapterService
        public int setTrafficLimit(boolean enabled, int bw) throws RemoteException {
            return 0;
        }

        @Override // android.net.INetworkAdapterService
        public int addAllowedListUidForTraffic(int uid, boolean add) throws RemoteException {
            return 0;
        }

        @Override // android.net.INetworkAdapterService
        public void setFytBlackIpList(String addr, boolean add) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public void setFytWhiteIpList(String addr, boolean add) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public void setFytIpAndPort(int protocol, String addr, int port, boolean add) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public void setFytDnsPort(int protocol, int port, boolean add) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public void setFytDnsFilter(boolean enable) throws RemoteException {
        }

        @Override // android.net.INetworkAdapterService
        public void setFytAtModem() throws RemoteException {
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }
    }

    public static abstract class Stub extends Binder implements INetworkAdapterService {
        static final int TRANSACTION_addAllowedListUidForTraffic = 18;
        static final int TRANSACTION_bindAppUidToNetwork = 10;
        static final int TRANSACTION_bindDstIpToNetwork = 11;
        static final int TRANSACTION_closeInterfaceSockets = 1;
        static final int TRANSACTION_deleteExtraIPv6Addr = 9;
        static final int TRANSACTION_doPingForVowifi = 14;
        static final int TRANSACTION_enableTrafficLimit = 16;
        static final int TRANSACTION_getMptcpStatus = 12;
        static final int TRANSACTION_initTrafficLimit = 15;
        static final int TRANSACTION_probeNetworkReachableActually = 2;
        static final int TRANSACTION_registerNetworkReachableNotifier = 3;
        static final int TRANSACTION_sendCmdsToDaemon = 6;
        static final int TRANSACTION_setDnsFilterEnabled = 7;
        static final int TRANSACTION_setEthernetInterface = 8;
        static final int TRANSACTION_setFytAtModem = 24;
        static final int TRANSACTION_setFytBlackIpList = 19;
        static final int TRANSACTION_setFytDnsFilter = 23;
        static final int TRANSACTION_setFytDnsPort = 22;
        static final int TRANSACTION_setFytIpAndPort = 21;
        static final int TRANSACTION_setFytWhiteIpList = 20;
        static final int TRANSACTION_setIPv6Mtu = 5;
        static final int TRANSACTION_setMptcpStatus = 13;
        static final int TRANSACTION_setTrafficLimit = 17;
        static final int TRANSACTION_unregisterNetworkReachableNotifier = 4;

        public Stub() {
            attachInterface(this, INetworkAdapterService.DESCRIPTOR);
        }

        public static INetworkAdapterService asInterface(IBinder obj) {
            if (obj == null) {
                return null;
            }
            IInterface iin = obj.queryLocalInterface(INetworkAdapterService.DESCRIPTOR);
            if (iin != null && (iin instanceof INetworkAdapterService)) {
                return (INetworkAdapterService) iin;
            }
            return new Proxy(obj);
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            if (code >= 1 && code <= 16777215) {
                data.enforceInterface(INetworkAdapterService.DESCRIPTOR);
            }
            switch (code) {
                case 1598968902:
                    reply.writeString(INetworkAdapterService.DESCRIPTOR);
                    return true;
                default:
                    switch (code) {
                        case 1:
                            closeInterfaceSockets();
                            reply.writeNoException();
                            return true;
                        case 2:
                            boolean _result = probeNetworkReachableActually();
                            reply.writeNoException();
                            reply.writeBoolean(_result);
                            return true;
                        case 3:
                            INetworkReachableNotifier _arg0 = INetworkReachableNotifier.Stub.asInterface(data.readStrongBinder());
                            data.enforceNoDataAvail();
                            registerNetworkReachableNotifier(_arg0);
                            reply.writeNoException();
                            return true;
                        case 4:
                            INetworkReachableNotifier _arg1 = INetworkReachableNotifier.Stub.asInterface(data.readStrongBinder());
                            data.enforceNoDataAvail();
                            unregisterNetworkReachableNotifier(_arg1);
                            reply.writeNoException();
                            return true;
                        case 5:
                            String _arg2 = data.readString();
                            int _arg3 = data.readInt();
                            data.enforceNoDataAvail();
                            setIPv6Mtu(_arg2, _arg3);
                            reply.writeNoException();
                            return true;
                        case 6:
                            String _arg4 = data.readString();
                            data.enforceNoDataAvail();
                            sendCmdsToDaemon(_arg4);
                            reply.writeNoException();
                            return true;
                        case 7:
                            int _arg5 = data.readInt();
                            data.enforceNoDataAvail();
                            setDnsFilterEnabled(_arg5);
                            reply.writeNoException();
                            return true;
                        case 8:
                            int _arg6 = data.readInt();
                            data.enforceNoDataAvail();
                            setEthernetInterface(_arg6);
                            reply.writeNoException();
                            return true;
                        case 9:
                            String _arg7 = data.readString();
                            String _arg8 = data.readString();
                            data.enforceNoDataAvail();
                            deleteExtraIPv6Addr(_arg7, _arg8);
                            reply.writeNoException();
                            return true;
                        case 10:
                            int _arg9 = data.readInt();
                            Network _arg10 = (Network) data.readTypedObject(Network.CREATOR);
                            data.enforceNoDataAvail();
                            boolean _result2 = bindAppUidToNetwork(_arg9, _arg10);
                            reply.writeNoException();
                            reply.writeBoolean(_result2);
                            return true;
                        case 11:
                            String _arg11 = data.readString();
                            Network _arg12 = (Network) data.readTypedObject(Network.CREATOR);
                            data.enforceNoDataAvail();
                            boolean _result3 = bindDstIpToNetwork(_arg11, _arg12);
                            reply.writeNoException();
                            reply.writeBoolean(_result3);
                            return true;
                        case 12:
                            int _result4 = getMptcpStatus();
                            reply.writeNoException();
                            reply.writeInt(_result4);
                            return true;
                        case 13:
                            boolean _arg13 = data.readBoolean();
                            data.enforceNoDataAvail();
                            int _result5 = setMptcpStatus(_arg13);
                            reply.writeNoException();
                            reply.writeInt(_result5);
                            return true;
                        case 14:
                            int _arg14 = data.readInt();
                            String _arg15 = data.readString();
                            String _arg16 = data.readString();
                            data.enforceNoDataAvail();
                            int _result6 = doPingForVowifi(_arg14, _arg15, _arg16);
                            reply.writeNoException();
                            reply.writeInt(_result6);
                            return true;
                        case 15:
                            int _result7 = initTrafficLimit();
                            reply.writeNoException();
                            reply.writeInt(_result7);
                            return true;
                        case 16:
                            boolean _arg17 = data.readBoolean();
                            String _arg18 = data.readString();
                            data.enforceNoDataAvail();
                            int _result8 = enableTrafficLimit(_arg17, _arg18);
                            reply.writeNoException();
                            reply.writeInt(_result8);
                            return true;
                        case 17:
                            boolean _arg19 = data.readBoolean();
                            int _arg20 = data.readInt();
                            data.enforceNoDataAvail();
                            int _result9 = setTrafficLimit(_arg19, _arg20);
                            reply.writeNoException();
                            reply.writeInt(_result9);
                            return true;
                        case 18:
                            int _arg21 = data.readInt();
                            boolean _arg22 = data.readBoolean();
                            data.enforceNoDataAvail();
                            int _result10 = addAllowedListUidForTraffic(_arg21, _arg22);
                            reply.writeNoException();
                            reply.writeInt(_result10);
                            return true;
                        case 19:
                            String _arg23 = data.readString();
                            boolean _arg24 = data.readBoolean();
                            data.enforceNoDataAvail();
                            setFytBlackIpList(_arg23, _arg24);
                            reply.writeNoException();
                            return true;
                        case 20:
                            String _arg25 = data.readString();
                            boolean _arg26 = data.readBoolean();
                            data.enforceNoDataAvail();
                            setFytWhiteIpList(_arg25, _arg26);
                            reply.writeNoException();
                            return true;
                        case 21:
                            int _arg27 = data.readInt();
                            String _arg28 = data.readString();
                            int _arg29 = data.readInt();
                            boolean _arg30 = data.readBoolean();
                            data.enforceNoDataAvail();
                            setFytIpAndPort(_arg27, _arg28, _arg29, _arg30);
                            reply.writeNoException();
                            return true;
                        case 22:
                            int _arg31 = data.readInt();
                            int _arg32 = data.readInt();
                            boolean _arg33 = data.readBoolean();
                            data.enforceNoDataAvail();
                            setFytDnsPort(_arg31, _arg32, _arg33);
                            reply.writeNoException();
                            return true;
                        case 23:
                            boolean _arg34 = data.readBoolean();
                            data.enforceNoDataAvail();
                            setFytDnsFilter(_arg34);
                            reply.writeNoException();
                            return true;
                        case 24:
                            setFytAtModem();
                            reply.writeNoException();
                            return true;
                        default:
                            return super.onTransact(code, data, reply, flags);
                    }
            }
        }

        private static class Proxy implements INetworkAdapterService {
            private IBinder mRemote;

            Proxy(IBinder remote) {
                this.mRemote = remote;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return INetworkAdapterService.DESCRIPTOR;
            }

            @Override // android.net.INetworkAdapterService
            public void closeInterfaceSockets() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    this.mRemote.transact(1, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public boolean probeNetworkReachableActually() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    this.mRemote.transact(2, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void registerNetworkReachableNotifier(INetworkReachableNotifier callback) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeStrongInterface(callback);
                    this.mRemote.transact(3, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void unregisterNetworkReachableNotifier(INetworkReachableNotifier callback) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeStrongInterface(callback);
                    this.mRemote.transact(4, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void setIPv6Mtu(String iface, int ipv6Mtu) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeString(iface);
                    _data.writeInt(ipv6Mtu);
                    this.mRemote.transact(5, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void sendCmdsToDaemon(String cmd) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeString(cmd);
                    this.mRemote.transact(6, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void setDnsFilterEnabled(int enabled) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeInt(enabled);
                    this.mRemote.transact(7, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void setEthernetInterface(int enabled) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeInt(enabled);
                    this.mRemote.transact(8, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void deleteExtraIPv6Addr(String ipv6Addr, String interfaceName) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeString(ipv6Addr);
                    _data.writeString(interfaceName);
                    this.mRemote.transact(9, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public boolean bindAppUidToNetwork(int uid, Network network) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeInt(uid);
                    _data.writeTypedObject(network, 0);
                    this.mRemote.transact(10, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public boolean bindDstIpToNetwork(String dstAddr, Network network) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeString(dstAddr);
                    _data.writeTypedObject(network, 0);
                    this.mRemote.transact(11, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public int getMptcpStatus() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    this.mRemote.transact(12, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public int setMptcpStatus(boolean enable) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeBoolean(enable);
                    this.mRemote.transact(13, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public int doPingForVowifi(int ipv4Flag, String srcIP, String dstIP) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeInt(ipv4Flag);
                    _data.writeString(srcIP);
                    _data.writeString(dstIP);
                    this.mRemote.transact(14, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public int initTrafficLimit() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    this.mRemote.transact(15, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public int enableTrafficLimit(boolean enabled, String interfaceName) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeBoolean(enabled);
                    _data.writeString(interfaceName);
                    this.mRemote.transact(16, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public int setTrafficLimit(boolean enabled, int bw) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeBoolean(enabled);
                    _data.writeInt(bw);
                    this.mRemote.transact(17, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public int addAllowedListUidForTraffic(int uid, boolean add) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeInt(uid);
                    _data.writeBoolean(add);
                    this.mRemote.transact(18, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void setFytBlackIpList(String addr, boolean add) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeString(addr);
                    _data.writeBoolean(add);
                    this.mRemote.transact(19, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void setFytWhiteIpList(String addr, boolean add) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeString(addr);
                    _data.writeBoolean(add);
                    this.mRemote.transact(20, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void setFytIpAndPort(int protocol, String addr, int port, boolean add) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeInt(protocol);
                    _data.writeString(addr);
                    _data.writeInt(port);
                    _data.writeBoolean(add);
                    this.mRemote.transact(21, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void setFytDnsPort(int protocol, int port, boolean add) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeInt(protocol);
                    _data.writeInt(port);
                    _data.writeBoolean(add);
                    this.mRemote.transact(22, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void setFytDnsFilter(boolean enable) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    _data.writeBoolean(enable);
                    this.mRemote.transact(23, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.net.INetworkAdapterService
            public void setFytAtModem() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(INetworkAdapterService.DESCRIPTOR);
                    this.mRemote.transact(24, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }
        }
    }
}
