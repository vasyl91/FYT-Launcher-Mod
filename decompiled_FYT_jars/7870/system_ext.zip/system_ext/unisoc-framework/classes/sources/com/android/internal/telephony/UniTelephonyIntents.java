package com.android.internal.telephony;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public class UniTelephonyIntents {
    public static final String ACTION_SIM_REFRESH_FILEUPDATE = "android.stkintent.action.ACTION_SIM_REFRESH_FILEUPDATE";
}
