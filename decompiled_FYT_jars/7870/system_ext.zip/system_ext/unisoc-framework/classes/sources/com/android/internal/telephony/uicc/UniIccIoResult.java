package com.android.internal.telephony.uicc;

import com.android.internal.telephony.MobileNetworkUtils;
import com.android.internal.telephony.util.TelephonyUtils;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public class UniIccIoResult {
    private static final String UNKNOWN_ERROR = "unknown";
    public byte[] payload;
    public int sw1;
    public int sw2;

    private String getErrorString() {
        switch (this.sw1) {
            case 97:
                return this.sw2 + " more response bytes available";
            case 98:
                switch (this.sw2) {
                    case 0:
                        return "no information given, state of non volatile memory unchanged";
                    case 129:
                        return "part of returned data may be corrupted";
                    case 130:
                        return "end of file/record reached before reading Le bytes";
                    case UniIccConstants.UST_PS_DATA_OFF_INFO /* 131 */:
                        return "selected file invalidated";
                    case 132:
                        return "selected file in termination state";
                    case 241:
                        return "more data available";
                    case 242:
                        return "more data available and proactive command pending";
                    case 243:
                        return "response data available";
                    default:
                        return UNKNOWN_ERROR;
                }
            case 99:
                int retries = this.sw2;
                if ((retries >> 4) == 12) {
                    int retries2 = retries & 15;
                    return "command successful but after using an internal update retry routine " + retries2 + " times, or verification failed, " + retries2 + " retries remaining";
                }
                switch (retries) {
                    case 241:
                        return "more data expected";
                    case 242:
                        return "more data expected and proactive command pending";
                    default:
                        return UNKNOWN_ERROR;
                }
            case 100:
                switch (this.sw2) {
                    case 0:
                        return "no information given, state of non-volatile memory unchanged";
                    default:
                        return UNKNOWN_ERROR;
                }
            case 101:
                switch (this.sw2) {
                    case 0:
                        return "no information given, state of non-volatile memory changed";
                    case 129:
                        return "memory problem";
                    default:
                        return UNKNOWN_ERROR;
                }
            case 103:
                switch (this.sw2) {
                    case 0:
                        return "incorrect parameter P3";
                    default:
                        return "the interpretation of this status word is command dependent";
                }
            case 104:
                switch (this.sw2) {
                    case 0:
                        return "no information given";
                    case 129:
                        return "logical channel not supported";
                    case 130:
                        return "secure messaging not supported";
                    default:
                        return UNKNOWN_ERROR;
                }
            case 105:
                switch (this.sw2) {
                    case 0:
                        return "no information given";
                    case 129:
                        return "command incompatible with file structure";
                    case 130:
                        return "security status not satisfied";
                    case UniIccConstants.UST_PS_DATA_OFF_INFO /* 131 */:
                        return "authentication/PIN method blocked";
                    case 132:
                        return "referenced data invalidated";
                    case 133:
                        return "conditions of use not satisfied";
                    case 134:
                        return "command not allowed (no EF selected)";
                    case 137:
                        return "command not allowed - secure channel - security not satisfied";
                    default:
                        return UNKNOWN_ERROR;
                }
            case 106:
                switch (this.sw2) {
                    case 128:
                        return "incorrect parameters in the data field";
                    case 129:
                        return "function not supported";
                    case 130:
                        return "file not found";
                    case UniIccConstants.UST_PS_DATA_OFF_INFO /* 131 */:
                        return "record not found";
                    case 132:
                        return "not enough memory space";
                    case 133:
                    default:
                        return UNKNOWN_ERROR;
                    case 134:
                        return "incorrect parameters P1 to P2";
                    case 135:
                        return "lc inconsistent with P1 to P2";
                    case 136:
                        return "referenced data not found";
                }
            case 107:
                return "incorrect parameter P1 or P2";
            case 108:
                return "wrong length, retry with " + this.sw2;
            case 109:
                return "unknown instruction code given in the command";
            case 110:
                return "wrong instruction class given in the command";
            case 111:
                switch (this.sw2) {
                    case 0:
                        return "technical problem with no diagnostic given";
                    default:
                        return "the interpretation of this status word is command dependent";
                }
            case 144:
                return null;
            case 145:
                return null;
            case 146:
                int i = this.sw2;
                if ((i >> 4) == 0) {
                    return "command successful but after using an internal update retry routine";
                }
                switch (i) {
                    case MobileNetworkUtils.RadioAccessFamily.RAF_1xRTT /* 64 */:
                        return "memory problem";
                    default:
                        return UNKNOWN_ERROR;
                }
            case 147:
                switch (this.sw2) {
                    case 0:
                        return "SIM Application Toolkit is busy. Command cannot be executed at present, further normal commands are allowed";
                    default:
                        return UNKNOWN_ERROR;
                }
            case 148:
                switch (this.sw2) {
                    case 0:
                        return "no EF selected";
                    case 2:
                        return "out f range (invalid address)";
                    case 4:
                        return "file ID not found/pattern not found";
                    case 8:
                        return "file is inconsistent with the command";
                    default:
                        return UNKNOWN_ERROR;
                }
            case 152:
                switch (this.sw2) {
                    case 2:
                        return "no CHV initialized";
                    case 4:
                        return "access condition not fulfilled/unsuccessful CHV verification, at least one attempt left/unsuccessful UNBLOCK CHV verification, at least one attempt left/authentication failed";
                    case 8:
                        return "in contradiction with CHV status";
                    case 16:
                        return "in contradiction with invalidation status";
                    case MobileNetworkUtils.RadioAccessFamily.RAF_1xRTT /* 64 */:
                        return "unsuccessful CHV verification, no attempt left/unsuccessful UNBLOCK CHV verification, no attempt left/CHV blocked/UNBLOCK CHV blocked";
                    case 80:
                        return "increase cannot be performed, Max value reached";
                    case 98:
                        return "authentication error, application specific";
                    case 100:
                        return "authentication error, security context not supported";
                    case 101:
                        return "key freshness failure";
                    case 102:
                        return "authentication error, no memory space available";
                    case 103:
                        return "authentication error, no memory space available in EF_MUK";
                    default:
                        return UNKNOWN_ERROR;
                }
            case 158:
                return null;
            case 159:
                return null;
            default:
                return UNKNOWN_ERROR;
        }
    }

    public UniIccIoResult(int sw1, int sw2, byte[] payload) {
        this.sw1 = sw1;
        this.sw2 = sw2;
        this.payload = payload;
    }

    public UniIccIoResult(int sw1, int sw2, String hexString) {
        this(sw1, sw2, IccUtils.hexStringToBytes(hexString));
    }

    public String toString() {
        return "IccIoResult sw1:0x" + Integer.toHexString(this.sw1) + " sw2:0x" + Integer.toHexString(this.sw2) + " Payload: " + (TelephonyUtils.IS_DEBUGGABLE ? IccUtils.bytesToHexString(this.payload) : "*******") + (!success() ? " Error: " + getErrorString() : "");
    }

    public boolean success() {
        int i = this.sw1;
        return i == 144 || i == 145 || i == 158 || i == 159;
    }

    public UniIccException getException() {
        if (success()) {
            return null;
        }
        switch (this.sw1) {
            case 148:
                if (this.sw2 == 8) {
                    return new UniIccFileTypeMismatch();
                }
                return new UniIccFileNotFound();
            default:
                return new UniIccException("sw1:" + this.sw1 + " sw2:" + this.sw2);
        }
    }
}
