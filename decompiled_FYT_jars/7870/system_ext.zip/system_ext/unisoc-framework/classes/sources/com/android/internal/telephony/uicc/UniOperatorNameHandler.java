package com.android.internal.telephony.uicc;

import android.R;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import com.android.internal.telephony.MobileNetworkUtils;
import com.android.internal.telephony.OperatorInfo;
import com.android.internal.util.ArrayUtils;
import com.android.unisoc.telephony.RadioInteractor;
import com.android.unisoc.telephony.aidl.IOperatorNameHandler;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public class UniOperatorNameHandler extends IOperatorNameHandler.Stub implements UniIccConstants {
    private static final String LOG_TAG = "UniOperatorNameHandler";
    private static final String UNISOC_PLMN_COMMON_PERMISSION = "com.unisoc.permisson.PLMN_COMMON";
    private static UniOperatorNameHandler mInstance;
    private static int mPhoneCount = TelephonyManager.getDefault().getPhoneCount();
    private Context mContext;
    private RadioInteractor mRadioInteractor;
    private Boolean mResetPlmn = false;
    private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() { // from class: com.android.internal.telephony.uicc.UniOperatorNameHandler.1
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("android.intent.action.LOCALE_CHANGED")) {
                Log.d(UniOperatorNameHandler.LOG_TAG, "onReceive ACTION_LOCALE_CHANGED");
                UniOperatorNameHandler.this.mResetPlmn = true;
                UniOperatorNameHandler.this.updatePlmn();
            }
        }
    };

    public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
        int check = this.mContext.checkCallingOrSelfPermission(UNISOC_PLMN_COMMON_PERMISSION);
        if (check == -1) {
            Log.d(LOG_TAG, "IRadiointeractor-> permission denied !");
            return false;
        }
        return super.onTransact(code, data, reply, flags);
    }

    private UniOperatorNameHandler(Context context) {
        this.mContext = context;
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.LOCALE_CHANGED");
        context.registerReceiver(this.mIntentReceiver, filter);
        publish();
    }

    public static UniOperatorNameHandler init(Context context) {
        UniOperatorNameHandler uniOperatorNameHandler;
        synchronized (UniOperatorNameHandler.class) {
            if (mInstance == null) {
                mInstance = new UniOperatorNameHandler(context);
            } else {
                Log.d(LOG_TAG, "init() called multiple times!  mInstance = " + mInstance);
            }
            uniOperatorNameHandler = mInstance;
        }
        return uniOperatorNameHandler;
    }

    public static UniOperatorNameHandler getInstance() {
        if (mInstance == null) {
            Log.d(LOG_TAG, "getInstance null");
        }
        return mInstance;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updatePlmn() {
        if (this.mRadioInteractor == null) {
            this.mRadioInteractor = new RadioInteractor(this.mContext);
        }
        for (int phoneId = 0; phoneId < mPhoneCount; phoneId++) {
            String mccmnc = TelephonyManager.from(this.mContext).getNetworkOperatorForPhone(phoneId);
            if (!TextUtils.isEmpty(mccmnc)) {
                this.mRadioInteractor.updateOperatorName(mccmnc, phoneId);
            }
            if (this.mResetPlmn.booleanValue()) {
                this.mRadioInteractor.updateOperatorName((String) null, phoneId);
            }
        }
        this.mResetPlmn = false;
    }

    public String getHighPriorityPlmn(int phoneId, String mccmnc, int lac) {
        Log.d(LOG_TAG, "getHighPriorityPlmn for phone " + phoneId + " mccmnc " + mccmnc + " and lac " + lac);
        if (!SubscriptionManager.isValidPhoneId(phoneId) || TextUtils.isEmpty(mccmnc) || mccmnc.length() <= 3) {
            return mccmnc;
        }
        if (!TextUtils.isEmpty(mccmnc) && mccmnc.substring(0, 3).equals("716") && mccmnc.equals(TelephonyManager.getDefault().getSimOperatorNumericForPhone(phoneId))) {
            return "";
        }
        UniIccRecords iccRecords = UniIccRecordsController.getInstance().getUniIccRecordForPhone(phoneId);
        if (lac == -1) {
            lac = iccRecords.getLac();
        }
        String highPriorityPlmn = getPnn(iccRecords, mccmnc, lac, phoneId);
        if (TextUtils.isEmpty(highPriorityPlmn) && !isIgnoreOns(phoneId) && TelephonyManager.from(this.mContext).getNetworkOperatorForPhone(phoneId).equals(mccmnc) && ArrayUtils.contains(iccRecords.getHomePlmns(), mccmnc)) {
            highPriorityPlmn = iccRecords.getSimOns();
            Log.d(LOG_TAG, "Didn't get pnn from sim, try ons next. ONS = " + highPriorityPlmn);
        }
        String highPriorityPlmn2 = plmnIgnoreDisplayRule(phoneId, mccmnc, highPriorityPlmn);
        String localeName = getLocaleOperatorName(mccmnc);
        if (TextUtils.isEmpty(localeName) || ("46697".equals(mccmnc) && ("GT 4G R".equals(highPriorityPlmn2) || "GT R".equals(highPriorityPlmn2)))) {
            return highPriorityPlmn2;
        }
        return localeName;
    }

    public String updateNetworkList(int phoneId, String[] operatorInfo) {
        Log.d(LOG_TAG, "updateNetworkList");
        if (!SubscriptionManager.isValidPhoneId(phoneId) || operatorInfo == null || operatorInfo.length < 4) {
            return null;
        }
        byte b = 0;
        String operatorName = operatorInfo[0];
        String mccmncAct = operatorInfo[2];
        String stateString = operatorInfo[3];
        Log.d(LOG_TAG, "updateNetworkList: " + mccmncAct + " " + stateString);
        if (mccmncAct != null && mccmncAct.length() > 5) {
            String[] mccmncInfos = mccmncAct.split(" ");
            String mccmnc = mccmncInfos[0];
            if (!TextUtils.isEmpty(mccmnc)) {
                String highPriorityPlmn = getHighPriorityPlmn(phoneId, mccmnc, -1);
                if (!TextUtils.isEmpty(highPriorityPlmn)) {
                    operatorName = highPriorityPlmn;
                }
            }
            if (!TextUtils.isEmpty(operatorName)) {
                if (operatorName.length() > 2 && operatorName.substring(operatorName.length() - 2).matches("\\dG")) {
                    operatorName = operatorName.substring(0, operatorName.length() - 2);
                }
                String act = mccmncInfos.length > 1 ? mccmncInfos[1] : "";
                switch (act.hashCode()) {
                    case 48:
                        if (!act.equals("0")) {
                            b = -1;
                        }
                        break;
                    case 49:
                        b = !act.equals("1") ? (byte) -1 : (byte) 1;
                        break;
                    case 50:
                        b = !act.equals("2") ? (byte) -1 : (byte) 2;
                        break;
                    case 55:
                        b = !act.equals("7") ? (byte) -1 : (byte) 3;
                        break;
                    default:
                        b = -1;
                        break;
                }
                switch (b) {
                    case 0:
                    case 1:
                        operatorName = operatorName + " 2G";
                        break;
                    case 2:
                        operatorName = operatorName + " 3G";
                        break;
                    case MobileNetworkUtils.TelephonyManagerConstants.NETWORK_MODE_GSM_UMTS /* 3 */:
                        operatorName = operatorName + " 4G";
                        break;
                    default:
                        Log.e(LOG_TAG, "ACT was not reported by RIL with PLMN " + mccmnc);
                        break;
                }
                Resources res = Resources.getSystem();
                if (OperatorInfo.State.UNKNOWN.toString().equalsIgnoreCase(stateString)) {
                    operatorName = operatorName + "(" + res.getString(R.string.unknownName);
                }
            }
        }
        Log.d(LOG_TAG, "updateNetworkList operatorName : " + operatorName);
        return operatorName;
    }

    private String getPnn(UniIccRecords iccRecords, String regPlmn, int lac, int phoneId) {
        String pnn = "";
        UniIccServiceTable ist = iccRecords.getIccmServiceTable();
        if (ist == null) {
            Log.d(LOG_TAG, "ist is null, return empty pnn");
            return "";
        }
        if (ist.pnnAvaliable() && ist.oplNrAvaliable()) {
            pnn = getOperatorNameFromOplNrPnn(iccRecords, regPlmn, lac);
        } else if (ist.pnnAvaliable() && ist.oplAvaliable()) {
            pnn = getOperatorNameFromOplPnn(iccRecords, regPlmn, lac);
        } else if (TextUtils.isEmpty("") && ist.pnnAvaliable()) {
            pnn = getFirstPnn(iccRecords, regPlmn, phoneId);
        }
        Log.d(LOG_TAG, "getPnn return " + pnn);
        return pnn;
    }

    private String getOperatorNameFromOplPnn(UniIccRecords iccRecords, String regPlmn, int lac) {
        if (regPlmn == null) {
            log("regplmn is  null,doesn't  getOperatorNameFromOplPnn from sim.");
            return "";
        }
        if (iccRecords.getPnnRecords() == null || iccRecords.getPnnRecords().size() == 0) {
            log("mPnnRecords is null");
            return "";
        }
        int pnnRecordnum = getPnnRecordnum(iccRecords, regPlmn, lac);
        if (pnnRecordnum <= 0 || pnnRecordnum > iccRecords.getPnnRecords().size()) {
            log("invalid PnnRecordnum = " + pnnRecordnum);
            return "";
        }
        log("mPnnRecords.get(PnnRecordnum - 1).getLongName(): " + iccRecords.getPnnRecords().get(pnnRecordnum - 1).getLongName());
        String operatorFromOpnPnn = iccRecords.getPnnRecords().get(pnnRecordnum - 1).getLongName();
        return operatorFromOpnPnn;
    }

    private String getFirstPnn(UniIccRecords iccRecords, String regPlmn, int phoneId) {
        String firstPnn = "";
        if (regPlmn == null) {
            log("regplmn is  null, doesn't get pnn name from sim.");
            return "";
        }
        String homePlmn = TelephonyManager.getDefault().getSimOperatorNumericForPhone(phoneId);
        if (regPlmn.equals(homePlmn) && iccRecords.getPnnRecords() != null && iccRecords.getPnnRecords().size() > 0) {
            log("PNN first record name: " + iccRecords.getPnnRecords().get(0).getLongName());
            firstPnn = iccRecords.getPnnRecords().get(0).getLongName();
        }
        log("firstPnn return " + firstPnn);
        return firstPnn;
    }

    private String getOperatorNameFromOplNrPnn(UniIccRecords iccRecords, String regPlmn, int lac) {
        if (regPlmn == null) {
            log("regplmn is  null,doesn't  getOperatorNameFromOplNrPnn from sim.");
            return "";
        }
        if (iccRecords.getPnnRecords() == null || iccRecords.getPnnRecords().size() == 0) {
            log("mPnnRecords is null");
            return "";
        }
        int PnnRecordnumNr = getPnnRecordnum(iccRecords, regPlmn, lac);
        if (PnnRecordnumNr <= 0 || PnnRecordnumNr > iccRecords.getPnnRecords().size()) {
            log("invalid PnnRecordnumNr = " + PnnRecordnumNr);
            return "";
        }
        log("mPnnRecords.get(PnnRecordnumNr - 1).getLongName(): " + iccRecords.getPnnRecords().get(PnnRecordnumNr - 1).getLongName());
        String operatorFromOpnPnn = iccRecords.getPnnRecords().get(PnnRecordnumNr - 1).getLongName();
        return operatorFromOpnPnn;
    }

    private int getPnnRecordnum(UniIccRecords iccRecords, String regplmn, int lac) {
        int[] regplmnarray = {0, 0, 0, 0, 0, 0};
        int pnnRecordNum = -1;
        if (regplmn == null || regplmn.length() > regplmnarray.length) {
            log("regplmn is invalid, fail to get pnn name from sim.");
            return -1;
        }
        if (lac == -1) {
            log("invalid lac");
            return -1;
        }
        if (iccRecords.getOplNrRecords() == null && iccRecords.getOplRecords() == null) {
            log("OplRecord not exist");
            if (!ArrayUtils.contains(iccRecords.getHomePlmns(), regplmn)) {
                return -1;
            }
            log("OplRecord not exist, but registered in the HPLMN");
            return 1;
        }
        for (int i = 0; i < regplmn.length(); i++) {
            regplmnarray[i] = regplmn.charAt(i) - '0';
        }
        if (iccRecords.getOplNrRecords() != null) {
            for (UniOplNrRecord record : iccRecords.getOplNrRecords()) {
                if (matchOplplmn(record.mOplNrplmn, regplmnarray)) {
                    log("getPnnRecordnumNr  tac:" + lac + ", record.mOplNrtac1:" + record.mOplNrtac1 + ", record.mOplNrtac2:" + record.mOplNrtac2);
                    if (record.mOplNrtac1 <= lac && lac <= record.mOplNrtac2) {
                        log("record.getPnnRecordNumNr() = " + record.getPnnRecordNum());
                        pnnRecordNum = record.getPnnRecordNum();
                    }
                }
            }
        } else if (iccRecords.getOplRecords() != null) {
            for (UniOplRecord record2 : iccRecords.getOplRecords()) {
                if (matchOplplmn(record2.mOplplmn, regplmnarray)) {
                    log("getPnnRecordnum  lac:" + lac + ", record.mOpllac1:" + record2.mOpllac1 + ", record.mOpllac2:" + record2.mOpllac2);
                    if (record2.mOpllac1 <= lac && lac <= record2.mOpllac2) {
                        log("record.getPnnRecordNum() = " + record2.getPnnRecordNum());
                        pnnRecordNum = record2.getPnnRecordNum();
                    }
                }
            }
        }
        log("No invalid pnn record match");
        return pnnRecordNum;
    }

    private boolean matchOplplmn(int[] oplplmn, int[] regplmn) {
        boolean match = true;
        if (regplmn == null || oplplmn == null) {
            return false;
        }
        if (regplmn.length != oplplmn.length) {
            log("regplmn length is not equal oplmn length");
            return false;
        }
        for (int i = 0; i < regplmn.length; i++) {
            if (oplplmn[i] == 13) {
                oplplmn[i] = regplmn[i];
            }
        }
        for (int i2 = 0; i2 < regplmn.length; i2++) {
            if (oplplmn[i2] != regplmn[i2]) {
                match = false;
                break;
            }
        }
        log("matchOplplmn match:" + match);
        return match;
    }

    private String plmnIgnoreDisplayRule(int phoneId, String mccmnc, String highPriorityPlmn) {
        int subId = getSubId(phoneId);
        if (SubscriptionManager.isValidSubscriptionId(subId)) {
            Resources res = SubscriptionManager.getResourcesForSubId(this.mContext, subId);
            String specialPlmn = res.getString(135004245);
            if (!TextUtils.isEmpty(specialPlmn)) {
                String[] specialPlmnInfo = specialPlmn.split("@");
                if (specialPlmnInfo.length == 2 && mccmnc.equals(specialPlmnInfo[0])) {
                    return specialPlmnInfo[1];
                }
            }
        }
        return TextUtils.isEmpty(highPriorityPlmn) ? "" : highPriorityPlmn;
    }

    private int getSubId(int phoneId) {
        int[] subIds = SubscriptionManager.getSubId(phoneId);
        if (subIds == null || subIds.length <= 0) {
            return -1;
        }
        int subId = subIds[0];
        return subId;
    }

    private Resources getResourcesForMccMnc(Context context, String mccmnc) {
        Configuration config = context.getResources().getConfiguration();
        Configuration newConfig = new Configuration();
        newConfig.setTo(config);
        try {
            newConfig.mcc = Integer.parseInt(mccmnc.substring(0, 3));
            newConfig.mnc = Integer.parseInt(mccmnc.substring(3));
            if (newConfig.mnc == 0) {
                newConfig.mnc = 65535;
            }
        } catch (NumberFormatException e) {
            log("getResourcesForMccMnc " + e);
        }
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        DisplayMetrics newMetrics = new DisplayMetrics();
        newMetrics.setTo(metrics);
        return new Resources(context.getResources().getAssets(), newMetrics, newConfig);
    }

    private String getLocaleOperatorName(String mccmnc) {
        if (mccmnc.matches("^[0-9]{5,6}$")) {
            Resources res = getResourcesForMccMnc(this.mContext, mccmnc);
            boolean preferLocaleName = res.getBoolean(134414351);
            String localeNameRes = res.getString(135004180);
            Log.d(LOG_TAG, "preferLocaleName = " + preferLocaleName);
            Log.d(LOG_TAG, "localeName = " + localeNameRes);
            if (preferLocaleName && !TextUtils.isEmpty(localeNameRes)) {
                return localeNameRes;
            }
        }
        return "";
    }

    private boolean isIgnoreOns(int phoneId) {
        Resources res;
        int subId = getSubId(phoneId);
        if (SubscriptionManager.isValidSubscriptionId(subId) && (res = SubscriptionManager.getResourcesForSubId(this.mContext, subId)) != null) {
            return res.getBoolean(134414347);
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void publish() {
        Log.d(LOG_TAG, "publish: " + this);
        ServiceManager.addService("ions_ex", this);
    }

    private void log(String s) {
        Log.d(LOG_TAG, s);
    }
}
