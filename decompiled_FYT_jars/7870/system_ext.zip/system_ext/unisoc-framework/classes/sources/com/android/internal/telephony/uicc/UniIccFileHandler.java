package com.android.internal.telephony.uicc;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.util.Log;
import android.util.SparseArray;
import com.android.internal.telephony.MobileNetworkUtils;
import com.android.unisoc.telephony.RadioInteractor;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntUnaryOperator;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public class UniIccFileHandler extends Handler implements UniIccConstants {
    protected static final int COMMAND_GET_RESPONSE = 192;
    protected static final int COMMAND_READ_BINARY = 176;
    protected static final int COMMAND_READ_RECORD = 178;
    protected static final int COMMAND_SEEK = 162;
    protected static final int COMMAND_UPDATE_BINARY = 214;
    protected static final int COMMAND_UPDATE_RECORD = 220;
    private static final boolean DBG = true;
    protected static final int EF_TYPE_CYCLIC = 3;
    protected static final int EF_TYPE_LINEAR_FIXED = 1;
    protected static final int EF_TYPE_TRANSPARENT = 0;
    protected static final int EVENT_GET_BINARY_SIZE_DONE = 1;
    protected static final int EVENT_GET_RECORD_SIZE_DONE = 3;
    protected static final int EVENT_READ_BINARY_DONE = 2;
    protected static final int EVENT_READ_RECORD_DONE = 4;
    protected static final int EVENT_UPDATE_BINARY_DONE = 5;
    protected static final int GET_RESPONSE_EF_IMG_SIZE_BYTES = 10;
    protected static final int GET_RESPONSE_EF_SIZE_BYTES = 15;
    private static final String LOG_TAG = "UniIccFileHandler";
    protected static final int READ_RECORD_MODE_ABSOLUTE = 4;
    protected static final int RESPONSE_DATA_FILE_ID_1 = 4;
    protected static final int RESPONSE_DATA_FILE_ID_2 = 5;
    protected static final int RESPONSE_DATA_FILE_SIZE_1 = 2;
    protected static final int RESPONSE_DATA_FILE_SIZE_2 = 3;
    protected static final int RESPONSE_DATA_FILE_TYPE = 6;
    protected static final int RESPONSE_DATA_RECORD_LENGTH = 14;
    protected static final int RESPONSE_DATA_STRUCTURE = 13;
    protected static final int TYPE_EF = 4;
    private Context mContext;
    private int mIccType;
    private int mPhoneId;
    private RadioInteractor mRadioInteractor;
    AtomicInteger sNextSerial = new AtomicInteger(0);
    SparseArray<Object> mRequestList = new SparseArray<>();
    Messenger mMessenger = new Messenger(this);

    public UniIccFileHandler(int type, Context context, int phoneId) {
        this.mIccType = type;
        this.mPhoneId = phoneId;
        this.mRadioInteractor = new RadioInteractor(context);
    }

    public void loadEFTransparent(int fileid, Message onLoaded) {
        String efPath = getEFPath(fileid);
        IccIoContext iccIoContext = new IccIoContext(1, fileid, efPath, onLoaded);
        int serial = getSerial(iccIoContext);
        Log.d(LOG_TAG, "loadEFTransparent iccIoContext = " + iccIoContext);
        this.mRadioInteractor.iccIOForApp(this.mMessenger, COMMAND_GET_RESPONSE, fileid, efPath, 0, 0, 15, (String) null, (String) null, (String) null, this.mPhoneId, serial);
    }

    public void loadEFLinearFixedAll(int fileid, Message onLoaded) {
        String efPath = getEFPath(fileid);
        IccIoContext iccIoContext = new IccIoContext(3, fileid, efPath, onLoaded);
        int serial = getSerial(iccIoContext);
        Log.d(LOG_TAG, "loadEFLinearFixedAll iccIoContext = " + iccIoContext);
        this.mRadioInteractor.iccIOForApp(this.mMessenger, COMMAND_GET_RESPONSE, fileid, efPath, 0, 0, 15, (String) null, (String) null, (String) null, this.mPhoneId, serial);
    }

    public void updateEFTransparent(int fileid, byte[] data, Message onComplete) {
        String efPath = getEFPath(fileid);
        IccIoContext iccIoContext = new IccIoContext(5, fileid, efPath, onComplete);
        int serial = getSerial(iccIoContext);
        Log.d(LOG_TAG, "updateEFTransparent iccIoContext = " + iccIoContext);
        this.mRadioInteractor.iccIOForApp(this.mMessenger, COMMAND_UPDATE_BINARY, fileid, efPath, 0, 0, data.length, IccUtils.bytesToHexString(data), (String) null, (String) null, this.mPhoneId, serial);
    }

    /* JADX WARN: Not initialized variable reg: 23, insn: 0x024e: MOVE (r9 I:??[OBJECT, ARRAY]) = (r23 I:??[OBJECT, ARRAY] A[D('path' java.lang.String)]), block:B:65:0x024e */
    @Override // android.os.Handler
    public void handleMessage(Message msg) {
        byte[] data;
        String path;
        int serial;
        logd("handleMessage Message = " + msg);
        Message response = null;
        IccIoContext iccIoContext = (IccIoContext) findAndRemoveMessageFromList(msg.arg1);
        logd("iccIoContext = " + iccIoContext.toString());
        try {
            try {
                try {
                    switch (iccIoContext.mWhat) {
                        case 1:
                            Bundle bundle = msg.getData();
                            data = bundle != null ? bundle.getByteArray("payload") : null;
                            int fileid = iccIoContext.mEfid;
                            path = iccIoContext.mPath;
                            response = iccIoContext.mOnLoaded;
                            UniIccIoResult uniIccIoresult = getUniIccIoResult(data);
                            if (processException(response, uniIccIoresult)) {
                                return;
                            }
                            byte[] data2 = uniIccIoresult.payload;
                            logd("data = " + IccUtils.bytesToHexString(data2));
                            if (4 != data2[6]) {
                                throw new UniIccFileTypeMismatch();
                            }
                            if (data2[13] != 0) {
                                throw new UniIccFileTypeMismatch();
                            }
                            int size = ((data2[2] & 255) << 8) + (data2[3] & 255);
                            iccIoContext.mWhat = 2;
                            serial = getSerial(iccIoContext);
                            this.mRadioInteractor.iccIOForApp(this.mMessenger, COMMAND_READ_BINARY, fileid, path, 0, 0, size, (String) null, (String) null, (String) null, this.mPhoneId, serial);
                            return;
                        case 2:
                        case MobileNetworkUtils.TelephonyManagerConstants.NETWORK_MODE_CDMA_NO_EVDO /* 5 */:
                            byte[] data3 = msg.getData().getByteArray("payload");
                            Message response2 = iccIoContext.mOnLoaded;
                            UniIccIoResult uniIccIoresult2 = getUniIccIoResult(data3);
                            if (processException(response2, uniIccIoresult2)) {
                                return;
                            }
                            byte[] data4 = uniIccIoresult2.payload;
                            logd("data = " + IccUtils.bytesToHexString(data4));
                            sendResult(response2, data4, null);
                            return;
                        case MobileNetworkUtils.TelephonyManagerConstants.NETWORK_MODE_GSM_UMTS /* 3 */:
                            Bundle bundle2 = msg.getData();
                            data = bundle2 != null ? bundle2.getByteArray("payload") : null;
                            response = iccIoContext.mOnLoaded;
                            UniIccIoResult uniIccIoresult3 = getUniIccIoResult(data);
                            if (processException(response, uniIccIoresult3)) {
                                logd("exception caught from EVENT_GET_RECORD_SIZE");
                                return;
                            }
                            path = iccIoContext.mPath;
                            byte[] data5 = uniIccIoresult3.payload;
                            logd("data = " + IccUtils.bytesToHexString(data5));
                            if (4 != data5[6]) {
                                throw new UniIccFileTypeMismatch();
                            }
                            if (1 != data5[13]) {
                                throw new UniIccFileTypeMismatch();
                            }
                            iccIoContext.mRecordSize = data5[14] & 255;
                            int size2 = ((data5[2] & 255) << 8) + (data5[3] & 255);
                            iccIoContext.mCountRecords = size2 / iccIoContext.mRecordSize;
                            iccIoContext.results = new ArrayList<>(iccIoContext.mCountRecords);
                            iccIoContext.mWhat = 4;
                            serial = getSerial(iccIoContext);
                            this.mRadioInteractor.iccIOForApp(this.mMessenger, COMMAND_READ_RECORD, iccIoContext.mEfid, path, iccIoContext.mRecordNum, 4, iccIoContext.mRecordSize, (String) null, (String) null, (String) null, this.mPhoneId, serial);
                            return;
                        case 4:
                            byte[] data6 = msg.getData().getByteArray("payload");
                            String path2 = iccIoContext.mPath;
                            response = iccIoContext.mOnLoaded;
                            UniIccIoResult uniIccIoresult4 = getUniIccIoResult(data6);
                            if (processException(response, uniIccIoresult4)) {
                                return;
                            }
                            byte[] data7 = uniIccIoresult4.payload;
                            logd("data = " + IccUtils.bytesToHexString(data7));
                            iccIoContext.results.add(data7);
                            iccIoContext.mRecordNum++;
                            if (iccIoContext.mRecordNum > iccIoContext.mCountRecords) {
                                sendResult(response, iccIoContext.results, null);
                                return;
                            }
                            if (path2 == null) {
                                path2 = getEFPath(iccIoContext.mEfid);
                            }
                            try {
                                this.mRadioInteractor.iccIOForApp(this.mMessenger, COMMAND_READ_RECORD, iccIoContext.mEfid, path2, iccIoContext.mRecordNum, 4, iccIoContext.mRecordSize, (String) null, (String) null, (String) null, this.mPhoneId, getSerial(iccIoContext));
                                return;
                            } catch (Exception e) {
                                exc = e;
                                loge("exc = " + exc);
                                if (response != null) {
                                    sendResult(response, null, exc);
                                    return;
                                } else {
                                    loge("uncaught exception = " + exc);
                                    return;
                                }
                            }
                        default:
                            return;
                    }
                } catch (Exception e2) {
                    exc = e2;
                }
            } catch (Exception e3) {
                exc = e3;
            }
        } catch (Exception e4) {
            exc = e4;
        }
    }

    private void sendResult(Message response, Object result, Throwable ex) {
        if (response == null) {
            return;
        }
        AsyncResult.forMessage(response, result, ex);
        response.sendToTarget();
    }

    private int getSerial(Object result) {
        int serial = this.sNextSerial.getAndUpdate(new IntUnaryOperator() { // from class: com.android.internal.telephony.uicc.UniIccFileHandler$$ExternalSyntheticLambda0
            @Override // java.util.function.IntUnaryOperator
            public final int applyAsInt(int i) {
                return UniIccFileHandler.lambda$getSerial$0(i);
            }
        });
        synchronized (this.mRequestList) {
            this.mRequestList.append(serial, result);
        }
        logd("getSerial = " + serial);
        return serial;
    }

    static /* synthetic */ int lambda$getSerial$0(int n) {
        return (n + 1) % Integer.MAX_VALUE;
    }

    private Object findAndRemoveMessageFromList(int serial) {
        Object userObj;
        synchronized (this.mRequestList) {
            userObj = this.mRequestList.get(serial);
            if (userObj != null) {
                this.mRequestList.remove(serial);
            }
        }
        return userObj;
    }

    private boolean processException(Message response, UniIccIoResult uniIccIoResult) {
        if (uniIccIoResult == null) {
            sendResult(response, null, new UniIccException("length wrong"));
            return true;
        }
        UniIccException iccException = uniIccIoResult.getException();
        if (iccException == null) {
            return false;
        }
        sendResult(response, null, iccException);
        return true;
    }

    private UniIccIoResult getUniIccIoResult(byte[] data) {
        if (data == null || data.length < 2) {
            return null;
        }
        int sw1 = data[data.length - 2] & 255;
        int sw2 = data[data.length - 1] & 255;
        byte[] payload = new byte[data.length - 2];
        System.arraycopy(data, 0, payload, 0, data.length - 2);
        UniIccIoResult result = new UniIccIoResult(sw1, sw2, payload);
        return result;
    }

    protected String getEFPath(int efid) {
        String path = null;
        switch (efid) {
            case UniIccConstants.EF_OPLNR /* 20232 */:
                return "3F007FFF5FC0";
            case UniIccConstants.EF_SPN_CPHS /* 28436 */:
            case UniIccConstants.EF_SPN_SHORT_CPHS /* 28440 */:
                return "3F007F20";
            case UniIccConstants.EF_PLMN_SEL /* 28464 */:
            case UniIccConstants.EF_SST /* 28472 */:
            case UniIccConstants.EF_PLMN_ACT /* 28512 */:
            case UniIccConstants.EF_AD /* 28589 */:
            case UniIccConstants.EF_ECC /* 28599 */:
            case UniIccConstants.EF_PNN /* 28613 */:
            case UniIccConstants.EF_OPL /* 28614 */:
            case UniIccConstants.EF_SPDI /* 28621 */:
            case UniIccConstants.EF_EHPLMN /* 28633 */:
            case UniIccConstants.EF_PS_DATA_OFF /* 28665 */:
                int i = this.mIccType;
                if (2 == i) {
                    path = "3F007FFF";
                } else if (1 == i) {
                    path = "3F007F20";
                }
                break;
        }
        logd(efid + " getEFPath, return " + path);
        return path;
    }

    static class IccIoContext {
        int mCountRecords;
        int mEfid;
        Message mOnLoaded;
        String mPath;
        int mRecordNum = 1;
        int mRecordSize;
        int mWhat;
        ArrayList<byte[]> results;

        IccIoContext(int what, int efid, String path, Message onLoaded) {
            this.mWhat = what;
            this.mEfid = efid;
            this.mPath = path;
            this.mOnLoaded = onLoaded;
        }

        public String toString() {
            return "IccIoContext:  mWhat" + this.mWhat + " mEfid" + this.mEfid + " mRecordNum=" + this.mRecordNum + " mOnLoaded=" + this.mOnLoaded + " mPath=" + this.mPath;
        }
    }

    private void logd(String s) {
        Log.d(LOG_TAG, "[UniIccFileHandler" + this.mPhoneId + "] " + s);
    }

    private void loge(String s) {
        Log.e(LOG_TAG, "[UniIccFileHandler" + this.mPhoneId + "] " + s);
    }
}
