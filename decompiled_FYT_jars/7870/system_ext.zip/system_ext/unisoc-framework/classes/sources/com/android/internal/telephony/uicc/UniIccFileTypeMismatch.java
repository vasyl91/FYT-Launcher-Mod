package com.android.internal.telephony.uicc;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public class UniIccFileTypeMismatch extends UniIccException {
    public UniIccFileTypeMismatch() {
    }

    public UniIccFileTypeMismatch(String s) {
        super(s);
    }
}
