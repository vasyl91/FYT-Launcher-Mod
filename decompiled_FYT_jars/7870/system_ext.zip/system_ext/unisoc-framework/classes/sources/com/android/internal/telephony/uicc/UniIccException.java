package com.android.internal.telephony.uicc;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public class UniIccException extends Exception {
    public UniIccException() {
    }

    public UniIccException(String s) {
        super(s);
    }
}
