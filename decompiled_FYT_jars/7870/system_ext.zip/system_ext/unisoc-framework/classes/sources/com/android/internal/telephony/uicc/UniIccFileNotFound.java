package com.android.internal.telephony.uicc;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\unisoc-framework\classes.dex */
public class UniIccFileNotFound extends UniIccException {
    UniIccFileNotFound() {
    }

    UniIccFileNotFound(String s) {
        super(s);
    }

    UniIccFileNotFound(int ef) {
        super("ICC EF Not Found 0x" + Integer.toHexString(ef));
    }
}
