package com.android.internal.telephony.uicc;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public interface UniIccConstants extends IccConstants {
    public static final String DF_ADFISIM = "7FFF";
    public static final int EF_CC = 20259;
    public static final int EF_DIR = 12032;
    public static final int EF_ECC = 28599;
    public static final int EF_ESNME = 28472;
    public static final int EF_LND = 28484;
    public static final int EF_PLMN_ACT = 28512;
    public static final int EF_PLMN_SEL = 28464;
    public static final int EF_PSC = 20258;
    public static final int EF_PUID = 20260;
    public static final int EF_SMSP = 28482;
}
