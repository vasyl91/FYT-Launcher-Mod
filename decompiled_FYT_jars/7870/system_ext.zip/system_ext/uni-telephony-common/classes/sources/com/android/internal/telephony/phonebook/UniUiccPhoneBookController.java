package com.android.internal.telephony.phonebook;

import android.os.RemoteException;
import android.os.ServiceManager;
import com.android.internal.telephony.IccPhoneBookInterfaceManager;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.PhoneFactory;
import com.android.internal.telephony.SubscriptionController;
import com.android.internal.telephony.UniIccPhoneBookInterfaceManager;
import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniUiccPhoneBookController extends IUniIccPhoneBook.Stub {
    private static final String TAG = "UiccPhoneBookController";

    /* JADX WARN: Multi-variable type inference failed */
    public UniUiccPhoneBookController() {
        if (ServiceManager.getService("uni_simphonebook") == null) {
            ServiceManager.addService("uni_simphonebook", this);
        }
    }

    private Phone getPhone(int subId) {
        int phoneId = SubscriptionController.getInstance().getPhoneId(subId);
        return PhoneFactory.getPhone(phoneId);
    }

    private boolean checkPermission(Phone phone) {
        if (phone == null) {
            return false;
        }
        int checkPermission = phone.getContext().checkCallingOrSelfPermission("android.permission.READ_CONTACTS");
        if (checkPermission == -1) {
            loge("check READ_CONTACTS permission fail");
            return false;
        }
        return true;
    }

    public List<UniAdnRecord> getAdnRecordsInEfForSubscriber(int subId, int efid) throws RemoteException {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getAdnRecordsInEfEx(efid);
        }
        loge("getAdnRecordsInEfEx iccPbkIntMgr is null");
        return null;
    }

    public int[] getAdnRecordsSizeForSubscriber(int subId, int efid) throws RemoteException {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getAdnRecordsSize(efid);
        }
        loge("getAdnRecordsSizeEx iccPbkIntMgr is null");
        return null;
    }

    public boolean updateAdnRecordsInEfBySearchForSubscriber(int subId, int efid, String oldTag, String oldPhoneNumber, String newTag, String newPhoneNumber, String pin2) throws RemoteException {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).updateAdnRecordsInEfBySearch(efid, oldTag, oldPhoneNumber, newTag, newPhoneNumber, pin2);
        }
        loge("updateAdnRecordsInEfBySearchEx iccPbkIntMgr is null");
        return false;
    }

    public int updateAdnRecordsInEfBySearchForSubscriberEx(int subId, int efid, String oldTag, String oldPhoneNumber, String[] oldEmailList, String oldAnr, String oldSne, String oldGrp, String newTag, String newPhoneNumber, String[] newEmailList, String newAnr, String newAas, String newSne, String newGrp, String newGas, String pin2) throws RemoteException {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).updateAdnRecordsInEfBySearch(efid, oldTag, oldPhoneNumber, oldEmailList, oldAnr, oldSne, oldGrp, newTag, newPhoneNumber, newEmailList, newAnr, newAas, newSne, newGrp, newGas, pin2);
        }
        loge("updateAdnRecordsInEfBySearch iccPbkIntMgr is null");
        return -1;
    }

    public int updateAdnRecordsInEfByIndexForSubscriber(int subId, int efid, String newTag, String newPhoneNumber, String[] newEmailList, String newAnr, String newAas, String newSne, String newGrp, String newGas, int index, String pin2) {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).updateAdnRecordsInEfByIndex(efid, newTag, newPhoneNumber, newEmailList, newAnr, newAas, newSne, newGrp, newGas, index, pin2);
        }
        loge("updateAdnRecordsInEfBySearch iccPbkIntMgr is null");
        return -1;
    }

    private IccPhoneBookInterfaceManager getIccPhoneBookInterfaceManager(int subId) {
        int phoneId = SubscriptionController.getInstance().getPhoneId(subId);
        try {
            return PhoneFactory.getPhone(phoneId).getIccPhoneBookInterfaceManager();
        } catch (ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
            return null;
        } catch (NullPointerException e2) {
            e2.printStackTrace();
            return null;
        }
    }

    private int getDefaultSubscription() {
        return PhoneFactory.getDefaultSubscription();
    }

    public int updateUsimGroupBySearchForSubscriber(int subId, String oldName, String newName) {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).updateUsimGroupBySearch(oldName, newName);
        }
        loge("updateUsimGroupBySearchForSubscriber iccPbkIntMgr is null");
        return -1;
    }

    public int updateUsimGroupByIndexForSubscriber(int subId, String newName, int groupId) {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).updateUsimGroupByIndex(newName, groupId);
        }
        loge("updateUsimGroupByIdForSubscriber iccPbkIntMgr is null");
        return -1;
    }

    public List<String> getGasInEfForSubscriber(int subId) {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getGasInEf();
        }
        loge("getGasInEfForSubscriber iccPbkIntMgr is null");
        return null;
    }

    public boolean isApplicationOnIcc(int type, int subId) {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).isApplicationOnIcc(type);
        }
        loge("isApplicationOnIcc iccPbkIntMgr is null");
        return false;
    }

    public int[] getEmailRecordsSize(int subId) throws RemoteException {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getEmailRecordsSize();
        }
        loge("getEmailRecordsSize iccPbkIntMgr is null");
        return null;
    }

    public int[] getAnrRecordsSize(int subId) throws RemoteException {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getAnrRecordsSize();
        }
        loge("getAnrRecordsSize iccPbkIntMgr is null");
        return null;
    }

    public int getAnrNum(int subId) throws RemoteException {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getAnrNum();
        }
        loge("getAnrNum iccPbkIntMgr is null");
        return 0;
    }

    public int getEmailNum(int subId) throws RemoteException {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getEmailNum();
        }
        loge("getEmailNum iccPbkIntMgr is null");
        return 0;
    }

    public int getGroupNum(int subId) throws RemoteException {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getGroupNum();
        }
        loge("getGroupNum iccPbkIntMgr is null");
        return 0;
    }

    public int getInsertIndex(int subId) {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getInsertIndex();
        }
        loge("getInsertIndex iccPbkIntMgr is null");
        return -1;
    }

    public int[] getAvalibleEmailCount(String name, String number, String[] emails, String anr, int[] emailNums, int subId) throws RemoteException {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getAvalibleEmailCount(name, number, emails, anr, emailNums);
        }
        loge("getAvalibleEmailCount iccPbkIntMgr is null");
        return null;
    }

    public int[] getAvalibleAnrCount(String name, String number, String[] emails, String anr, int[] anrNums, int subId) throws RemoteException {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getAvalibleAnrCount(name, number, emails, anr, anrNums);
        }
        loge("getAvalibleAnrCount iccPbkIntMgr is null");
        return null;
    }

    public int getEmailMaxLen(int subId) throws RemoteException {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getEmailMaxLen();
        }
        loge("getEmailMaxLen iccPbkIntMgr is null");
        return 0;
    }

    public int getPhoneNumMaxLen(int subId) throws RemoteException {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getPhoneNumMaxLen();
        }
        loge("getPhoneNumMaxLen iccPbkIntMgr is null");
        return 0;
    }

    public int getUsimGroupNameMaxLen(int subId) {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getUsimGroupNameMaxLen();
        }
        loge("getUsimGroupNameMaxLen iccPbkIntMgr is null");
        return 0;
    }

    public int[] getUsimGroupSize(int subId) {
        if (!checkPermission(getPhone(subId))) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            int[] usimGroupSize = ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getUsimGroupSize();
            return usimGroupSize;
        }
        loge("getUsimGroupSize iccPbkIntMgr is null");
        return null;
    }

    public List<String> getAasInEfForSubscriber(int subId) {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getAasInEf();
        }
        return null;
    }

    public int updateUsimAasBySearchForSubscriber(String oldName, String newName, int subId) {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr == null || !(iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return 0;
        }
        int usimAas = ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).updateUsimAasBySearch(oldName, newName);
        return usimAas;
    }

    public int updateUsimAasByIndexForSubscriber(String newName, int aasIndex, int subId) {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr == null || !(iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return 0;
        }
        int usimAas = ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).updateUsimAasByIndex(newName, aasIndex);
        return usimAas;
    }

    public int getSneSize(int subId) {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr == null || !(iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return 0;
        }
        int sneSize = ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getSneSize();
        return sneSize;
    }

    public int[] getSneLength(int subId) {
        IccPhoneBookInterfaceManager iccPbkIntMgr = getIccPhoneBookInterfaceManager(subId);
        if (iccPbkIntMgr != null && (iccPbkIntMgr instanceof UniIccPhoneBookInterfaceManager)) {
            return ((UniIccPhoneBookInterfaceManager) iccPbkIntMgr).getSneLength();
        }
        return null;
    }

    private void loge(String msg) {
        UniPhoneBookLog.e(TAG, msg);
    }

    private void logd(String msg) {
        UniPhoneBookLog.d(TAG, msg);
    }
}
