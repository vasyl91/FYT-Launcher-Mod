package com.android.internal.telephony.phonebook;

import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.MergeCursor;
import android.net.Uri;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.text.TextUtils;
import com.android.internal.telephony.AbsIccProvider;
import com.android.internal.telephony.uicc.UniIccConstants;
import com.android.internal.telephony.util.TelephonyUtils;
import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniIccProvider extends AbsIccProvider {
    private static final int AAS = 14;
    private static final int AAS_SUB = 15;
    private static final int ADN = 1;
    private static final int ADN_ALL = 7;
    private static final int ADN_SUB = 2;
    private static final String AUTHORITY = "icc";
    private static final String CONTENT_URI = "content://icc/";
    private static final int FDN = 3;
    private static final int FDN_S = 8;
    private static final int FDN_SUB = 4;
    private static final int FDN_S_SUB = 9;
    private static final int GAS = 10;
    private static final int GAS_SUB = 11;
    private static final int LND = 12;
    private static final int LND_SUB = 13;
    private static final int SDN = 5;
    private static final int SDN_SUB = 6;
    private static final int SNE_S = 16;
    private static final int SNE_S_SUB = 17;
    private static final String STR_EMAILS = "email";
    private static final String STR_NEW_NUMBER = "newNumber";
    private static final String STR_NEW_TAG = "newTag";
    private static final String STR_PIN2 = "pin2";
    private static final String STR_TAG = "tag";
    private static final String TAG = "UniIccProvider";
    private static final UriMatcher URL_MATCHER;
    private static final String WITH_EXCEPTION = "with_exception";
    private Context mContext;
    private SubscriptionManager mSubscriptionManager;
    private static final String STR_NUMBER = "number";
    private static final String STR_ANR = "anr";
    private static final String STR_AAS = "aas";
    private static final String STR_SNE = "sne";
    private static final String STR_GRP = "grp";
    private static final String STR_GAS = "gas";
    private static final String STR_INDEX = "index";
    private static final String[] ADDRESS_BOOK_COLUMN_NAMES = {"name", STR_NUMBER, "emails", STR_ANR, STR_AAS, STR_SNE, STR_GRP, STR_GAS, STR_INDEX, "_id"};
    private static final String[] FDN_S_COLUMN_NAMES = {"size"};
    private static final String[] SIM_GROUP_PROJECTION = {STR_GAS, STR_INDEX};
    private static final String[] SIM_AAS_PROJECTION = {STR_AAS, STR_INDEX};

    static {
        UriMatcher uriMatcher = new UriMatcher(-1);
        URL_MATCHER = uriMatcher;
        uriMatcher.addURI(AUTHORITY, "adn", 1);
        uriMatcher.addURI(AUTHORITY, "adn/subId/#", 2);
        uriMatcher.addURI(AUTHORITY, "fdn", 3);
        uriMatcher.addURI(AUTHORITY, "fdn/subId/#", 4);
        uriMatcher.addURI(AUTHORITY, "sdn", 5);
        uriMatcher.addURI(AUTHORITY, "sdn/subId/#", 6);
        uriMatcher.addURI(AUTHORITY, "fdn_s", 8);
        uriMatcher.addURI(AUTHORITY, "fdn_s/subId/#", 9);
        uriMatcher.addURI(AUTHORITY, STR_GAS, 10);
        uriMatcher.addURI(AUTHORITY, "gas/subId/#", 11);
        uriMatcher.addURI(AUTHORITY, "lnd", 12);
        uriMatcher.addURI(AUTHORITY, "lnd/subId/#", 13);
        uriMatcher.addURI(AUTHORITY, STR_AAS, 14);
        uriMatcher.addURI(AUTHORITY, "aas/subId/#", 15);
        uriMatcher.addURI(AUTHORITY, STR_SNE, 16);
        uriMatcher.addURI(AUTHORITY, "sne/subId/#", 17);
    }

    public UniIccProvider(Context context) {
        log(TAG);
        this.mContext = context;
        this.mSubscriptionManager = SubscriptionManager.from(context);
    }

    public Cursor query(Uri url, String[] projection, String selection, String[] selectionArgs, String sort) {
        log("query url: " + url + " selection: " + selection + " selectionArgs: " + selectionArgs + " sort: " + sort);
        switch (URL_MATCHER.match(url)) {
            case 1:
                return loadFromEf(28474, SubscriptionManager.getDefaultSubscriptionId());
            case 2:
                return loadFromEf(28474, getRequestSubId(url));
            case 3:
                return loadFromEf(28475, SubscriptionManager.getDefaultSubscriptionId());
            case 4:
                return loadFromEf(28475, getRequestSubId(url));
            case 5:
                return loadFromEf(28489, SubscriptionManager.getDefaultSubscriptionId());
            case 6:
                return loadFromEf(28489, getRequestSubId(url));
            case 7:
                return loadAllSimContacts(28474);
            case 8:
                return getEfSize(28475, SubscriptionManager.getDefaultSubscriptionId());
            case 9:
                return getEfSize(28475, getRequestSubId(url));
            case 10:
                return loadGas(SubscriptionManager.getDefaultSubscriptionId());
            case 11:
                return loadGas(getRequestSubId(url));
            case 12:
                return loadFromEf(UniIccConstants.EF_LND, SubscriptionManager.getDefaultSubscriptionId());
            case 13:
                return loadFromEf(UniIccConstants.EF_LND, getRequestSubId(url));
            case 14:
                return loadAas(SubscriptionManager.getDefaultSubscriptionId());
            case 15:
                return loadAas(getRequestSubId(url));
            case 16:
                return getSneSize(SubscriptionManager.getDefaultSubscriptionId());
            case 17:
                return getSneSize(getRequestSubId(url));
            default:
                throw new IllegalArgumentException("Unknown URL " + url);
        }
    }

    private Cursor loadAllSimContacts(int efType) {
        Cursor[] result;
        List<SubscriptionInfo> subInfoList = this.mSubscriptionManager.getActiveSubscriptionInfoList(false);
        if (subInfoList == null || subInfoList.size() == 0) {
            result = new Cursor[0];
        } else {
            int subIdCount = subInfoList.size();
            result = new Cursor[subIdCount];
            for (int i = 0; i < subIdCount; i++) {
                int subId = subInfoList.get(i).getSubscriptionId();
                result[i] = loadFromEf(efType, subId);
            }
        }
        return new MergeCursor(result);
    }

    public String getType(Uri url) {
        switch (URL_MATCHER.match(url)) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 14:
            case 15:
                return "vnd.android.cursor.dir/sim-contact";
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            default:
                throw new IllegalArgumentException("Unknown URL " + url);
        }
    }

    /* JADX WARN: Failed to apply debug info
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r34v0 ??, new type: android.net.Uri
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.applyDebugInfo(TypeUpdate.java:77)
    	at jadx.core.dex.visitors.debuginfo.DebugInfoApplyVisitor.applyDebugInfo(DebugInfoApplyVisitor.java:137)
    	at jadx.core.dex.visitors.debuginfo.DebugInfoApplyVisitor.applyDebugInfo(DebugInfoApplyVisitor.java:133)
    	at jadx.core.dex.visitors.debuginfo.DebugInfoApplyVisitor.searchAndApplyVarDebugInfo(DebugInfoApplyVisitor.java:75)
    	at jadx.core.dex.visitors.debuginfo.DebugInfoApplyVisitor.lambda$applyDebugInfo$0(DebugInfoApplyVisitor.java:68)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1597)
    	at jadx.core.dex.visitors.debuginfo.DebugInfoApplyVisitor.applyDebugInfo(DebugInfoApplyVisitor.java:68)
    	at jadx.core.dex.visitors.debuginfo.DebugInfoApplyVisitor.visit(DebugInfoApplyVisitor.java:55)
    Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
    	... 8 more
     */
    /* JADX WARN: Failed to calculate best type for var: r34v0 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r34v0 ??, new type: android.net.Uri
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1597)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
    	... 7 more
     */
    /* JADX WARN: Failed to set immutable type for var: r34v0 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r34v0 ??, new type: android.net.Uri
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.applyWithWiderIgnSame(TypeUpdate.java:73)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setImmutableType(TypeInferenceVisitor.java:111)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$1(TypeInferenceVisitor.java:102)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1597)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:102)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
    	... 6 more
     */
    /* JADX WARN: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r34v0 android.net.Uri, new type: android.net.Uri
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.applyWithWiderIgnSame(TypeUpdate.java:73)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.applyResolvedVars(TypeSearch.java:100)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:76)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.runMultiVariableSearch(FixTypesVisitor.java:119)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
    Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
    	... 5 more
     */
    public Uri insert(Uri uri, ContentValues contentValues) {
        int i;
        boolean z;
        String asString;
        boolean z2;
        boolean z3;
        int defaultSubscriptionId;
        String[] strArr;
        int iAddIccRecordToEf;
        boolean z4 = false;
        log("insert, uri:" + uri + " initialValues:" + contentValues);
        int iMatch = URL_MATCHER.match(uri);
        switch (iMatch) {
            case 1:
                i = 28474;
                z = false;
                asString = null;
                z2 = false;
                z3 = false;
                defaultSubscriptionId = SubscriptionManager.getDefaultSubscriptionId();
                break;
            case 2:
                i = 28474;
                z = false;
                asString = null;
                z2 = false;
                z3 = false;
                defaultSubscriptionId = getRequestSubId(uri);
                break;
            case 3:
                int defaultSubscriptionId2 = SubscriptionManager.getDefaultSubscriptionId();
                i = 28475;
                z = false;
                asString = contentValues.getAsString(STR_PIN2);
                z2 = false;
                z3 = true;
                defaultSubscriptionId = defaultSubscriptionId2;
                break;
            case 4:
                int requestSubId = getRequestSubId(uri);
                i = 28475;
                z = false;
                asString = contentValues.getAsString(STR_PIN2);
                z2 = false;
                z3 = true;
                defaultSubscriptionId = requestSubId;
                break;
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            default:
                throw new UnsupportedOperationException("Cannot insert into URL: " + uri);
            case 10:
                i = -1;
                z = true;
                asString = null;
                z2 = false;
                z3 = false;
                defaultSubscriptionId = SubscriptionManager.getDefaultSubscriptionId();
                break;
            case 11:
                i = -1;
                z = true;
                asString = null;
                z2 = false;
                z3 = false;
                defaultSubscriptionId = getRequestSubId(uri);
                break;
            case 12:
                i = 28484;
                z = false;
                asString = null;
                z2 = false;
                z3 = false;
                defaultSubscriptionId = SubscriptionManager.getDefaultSubscriptionId();
                break;
            case 13:
                i = 28484;
                z = false;
                asString = null;
                z2 = false;
                z3 = false;
                defaultSubscriptionId = getRequestSubId(uri);
                break;
            case 14:
                i = -1;
                z = false;
                asString = null;
                z2 = true;
                z3 = false;
                defaultSubscriptionId = SubscriptionManager.getDefaultSubscriptionId();
                break;
            case 15:
                i = -1;
                z = false;
                asString = null;
                z2 = true;
                z3 = false;
                defaultSubscriptionId = getRequestSubId(uri);
                break;
        }
        String asString2 = contentValues.getAsString(STR_TAG);
        String asString3 = contentValues.getAsString(STR_NUMBER);
        String asString4 = contentValues.getAsString(STR_EMAILS);
        if (asString4 == null) {
            strArr = null;
        } else {
            strArr = new String[]{asString4};
        }
        String asString5 = contentValues.getAsString(STR_ANR);
        String asString6 = contentValues.getAsString(STR_AAS);
        String asString7 = contentValues.getAsString(STR_SNE);
        String asString8 = contentValues.getAsString(STR_GRP);
        String asString9 = contentValues.getAsString(STR_GAS);
        String str = asString6 == null ? "" : asString6;
        if (TelephonyUtils.IS_DEBUGGABLE) {
            log("insert, tag:" + asString2 + ",  number:" + asString3 + ",  anr:" + asString5 + ",  aas:" + str + ",  sne:" + asString7 + ",  grp:" + asString8 + ",  gas:" + asString9 + ",  Email:" + (strArr == null ? "null" : strArr[0]) + ", efType = 0x" + (i != -1 ? Integer.toHexString(i).toUpperCase() : Integer.valueOf(i)));
        }
        if (z) {
            iAddIccRecordToEf = addUsimGroupBySearch(asString9, defaultSubscriptionId);
        } else if (z2) {
            iAddIccRecordToEf = addUsimAas(str, defaultSubscriptionId);
            if (iAddIccRecordToEf < 0) {
                if (iAddIccRecordToEf == -12) {
                    return Uri.parse("aas/aas_full");
                }
                if (iAddIccRecordToEf != -11) {
                    return null;
                }
                return Uri.parse("aas/over_aas_max_length");
            }
        } else {
            iAddIccRecordToEf = addIccRecordToEf(i, asString2, asString3, strArr, asString5, str, asString7, asString8, asString9, asString, defaultSubscriptionId);
        }
        if (z3 && iAddIccRecordToEf < 0) {
            log("fdn insert error =  " + iAddIccRecordToEf);
            z4 = true;
        } else if (iAddIccRecordToEf < 0) {
            int i2 = iAddIccRecordToEf;
            log("insert error =  " + i2);
            if (uri.getBooleanQueryParameter(WITH_EXCEPTION, r7)) {
                log("throw exception");
                throwException(i2);
                return null;
            }
            return null;
        }
        StringBuilder sb = new StringBuilder(CONTENT_URI);
        switch (iMatch) {
            case 1:
                sb.append("adn/");
                break;
            case 2:
                sb.append("adn/subId/");
                break;
            case 3:
                sb.append("fdn/");
                break;
            case 4:
                sb.append("fdn/subId/");
                break;
            case 10:
                sb.append("gas/");
                break;
            case 11:
                sb.append("gas/subId");
                break;
            case 12:
                sb.append("lnd/");
                break;
            case 13:
                sb.append("lnd/subId");
                break;
            case 14:
                sb.append("aas/");
                break;
            case 15:
                sb.append("aas/subId");
                break;
        }
        if (z3 && z4) {
            if (iAddIccRecordToEf == -4) {
                sb.append(iAddIccRecordToEf + "/over_fdn_name_max_length");
            } else if (iAddIccRecordToEf == -3) {
                sb.append(iAddIccRecordToEf + "/fdn_full");
            } else {
                return null;
            }
        } else {
            sb.append("/" + iAddIccRecordToEf);
        }
        Uri uri2 = Uri.parse(sb.toString());
        log("insert resultUri: " + uri2);
        if (uri2 != null) {
            this.mContext.getContentResolver().notifyChange(uri2, (ContentObserver) null, false);
        }
        return uri2;
    }

    private String normalizeValue(String inVal) {
        int len = inVal.length();
        if (len == 0) {
            log("len of input String is 0");
            return inVal;
        }
        if (inVal.charAt(0) != '\'' || inVal.charAt(len - 1) != '\'') {
            return inVal;
        }
        String retVal = inVal.substring(1, len - 1);
        return retVal;
    }

    public int delete(Uri url, String where, String[] whereArgs) {
        boolean isFdn;
        boolean isGas;
        boolean isAas;
        int efType;
        int subId;
        int i;
        int index;
        String pin2;
        String tag;
        String number;
        boolean success;
        log("delete, uri:" + url + " where:" + where + " whereArgs:" + whereArgs);
        int match = URL_MATCHER.match(url);
        switch (match) {
            case 1:
                int subId2 = SubscriptionManager.getDefaultSubscriptionId();
                isFdn = false;
                isGas = false;
                isAas = false;
                efType = 28474;
                subId = subId2;
                break;
            case 2:
                int subId3 = getRequestSubId(url);
                isFdn = false;
                isGas = false;
                isAas = false;
                efType = 28474;
                subId = subId3;
                break;
            case 3:
                int subId4 = SubscriptionManager.getDefaultSubscriptionId();
                isFdn = true;
                isGas = false;
                isAas = false;
                efType = 28475;
                subId = subId4;
                break;
            case 4:
                int subId5 = getRequestSubId(url);
                isFdn = true;
                isGas = false;
                isAas = false;
                efType = 28475;
                subId = subId5;
                break;
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 12:
            case 13:
            default:
                throw new UnsupportedOperationException("Cannot insert into URL: " + url);
            case 10:
                int subId6 = SubscriptionManager.getDefaultSubscriptionId();
                isFdn = false;
                isGas = true;
                isAas = false;
                efType = 28474;
                subId = subId6;
                break;
            case 11:
                int subId7 = getRequestSubId(url);
                isFdn = false;
                isGas = true;
                isAas = false;
                efType = 28474;
                subId = subId7;
                break;
            case 14:
                int subId8 = SubscriptionManager.getDefaultSubscriptionId();
                isFdn = false;
                isGas = false;
                isAas = true;
                efType = 28474;
                subId = subId8;
                break;
            case 15:
                int subId9 = getRequestSubId(url);
                isFdn = false;
                isGas = false;
                isAas = true;
                efType = 28474;
                subId = subId9;
                break;
        }
        String tag2 = null;
        String number2 = null;
        String[] emails = null;
        String val = null;
        int index2 = -1;
        if (isAas) {
            log("delete AAS");
            int index3 = Integer.parseInt(where);
            int result = updateUsimAasByIndex("", index3, subId);
            return result < 0 ? 0 : 1;
        }
        if (whereArgs == null || whereArgs.length == 0) {
            String[] tokens = where.split(" AND ");
            int n = tokens.length;
            while (true) {
                i = -1;
                n--;
                if (n >= 0) {
                    String tag3 = tag2;
                    String tag4 = tokens[n];
                    String number3 = number2;
                    String[] emails2 = emails;
                    log("parsing '" + tag4 + "'");
                    String[] pair = tag4.split("=", 2);
                    String pin3 = val;
                    if (pair.length != 2) {
                        log("resolve: bad whereClause parameter: " + tag4);
                        val = pin3;
                        tag2 = tag3;
                        number2 = number3;
                        emails = emails2;
                    } else {
                        String key = pair[0].trim();
                        String val2 = pair[1].trim();
                        if (STR_TAG.equals(key)) {
                            tag2 = normalizeValue(val2);
                            val = pin3;
                            number2 = number3;
                            emails = emails2;
                        } else if (STR_NUMBER.equals(key)) {
                            number2 = normalizeValue(val2);
                            val = pin3;
                            tag2 = tag3;
                            emails = emails2;
                        } else if (STR_EMAILS.equals(key)) {
                            emails = null;
                            val = pin3;
                            tag2 = tag3;
                            number2 = number3;
                        } else if (STR_PIN2.equals(key)) {
                            val = normalizeValue(val2);
                            tag2 = tag3;
                            number2 = number3;
                            emails = emails2;
                        } else if (!STR_INDEX.equals(key)) {
                            val = pin3;
                            tag2 = tag3;
                            number2 = number3;
                            emails = emails2;
                        } else {
                            index2 = Integer.valueOf(normalizeValue(val2)).intValue();
                            val = pin3;
                            tag2 = tag3;
                            number2 = number3;
                            emails = emails2;
                        }
                    }
                } else {
                    String pin4 = val;
                    index = index2;
                    pin2 = pin4;
                    tag = tag2;
                    number = number2;
                }
            }
        } else {
            String tag5 = whereArgs[0];
            String number4 = whereArgs[1];
            String pin5 = whereArgs[2];
            tag = tag5;
            number = number4;
            i = -1;
            pin2 = pin5;
            index = -1;
        }
        if (efType == 3 && TextUtils.isEmpty(pin2)) {
            return 0;
        }
        if (TelephonyUtils.IS_DEBUGGABLE) {
            log("delete tag: " + tag + ", number:" + number + ", index:" + index + ", efType: 0x" + Integer.toHexString(efType).toUpperCase());
        }
        if (isFdn) {
            if (-1 == deleteIccRecordFromEf(efType, tag, number, null, "", "", "", pin2, subId)) {
                success = false;
            } else {
                success = true;
            }
        } else {
            int index4 = index;
            String pin6 = pin2;
            String number5 = number;
            String tag6 = tag;
            int efType2 = efType;
            int i2 = i;
            int subId10 = subId;
            if (isGas) {
                int result2 = updateUsimGroupByIndex("", index4, subId10);
                boolean success2 = result2 >= 0;
                success = success2;
            } else if (index4 == i2) {
                log("the 3rd app will not use index");
                boolean success3 = deleteIccRecordFromEf(efType2, tag6, number5, null, pin6, subId10);
                success = success3;
            } else {
                int recIndex = deleteIccRecordFromEfByIndex(efType2, index4, pin6, subId10);
                if (recIndex < 0) {
                    success = false;
                } else {
                    success = true;
                }
            }
        }
        log("delete result: " + success);
        if (!success) {
            return 0;
        }
        this.mContext.getContentResolver().notifyChange(url, null);
        return 1;
    }

    public int update(Uri url, ContentValues values, String where, String[] whereArgs) {
        String pin2;
        int efType;
        boolean isFdn;
        boolean isGas;
        boolean isAas;
        int subId;
        String[] newemails;
        int i;
        int i2;
        Uri uri;
        UniIccProvider uniIccProvider;
        boolean success;
        log("update, uri:" + url + " where: " + where + " value: " + values + " whereArgs: " + whereArgs);
        int match = URL_MATCHER.match(url);
        switch (match) {
            case 1:
                int subId2 = SubscriptionManager.getDefaultSubscriptionId();
                pin2 = null;
                efType = 28474;
                isFdn = false;
                isGas = false;
                isAas = false;
                subId = subId2;
                break;
            case 2:
                int subId3 = getRequestSubId(url);
                pin2 = null;
                efType = 28474;
                isFdn = false;
                isGas = false;
                isAas = false;
                subId = subId3;
                break;
            case 3:
                int subId4 = SubscriptionManager.getDefaultSubscriptionId();
                String pin3 = values.getAsString(STR_PIN2);
                pin2 = pin3;
                efType = 28475;
                isFdn = true;
                isGas = false;
                isAas = false;
                subId = subId4;
                break;
            case 4:
                int subId5 = getRequestSubId(url);
                String pin4 = values.getAsString(STR_PIN2);
                pin2 = pin4;
                efType = 28475;
                isFdn = true;
                isGas = false;
                isAas = false;
                subId = subId5;
                break;
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 12:
            case 13:
            default:
                throw new UnsupportedOperationException("Cannot insert into URL: " + url);
            case 10:
                int subId6 = SubscriptionManager.getDefaultSubscriptionId();
                pin2 = null;
                efType = -1;
                isFdn = false;
                isGas = true;
                isAas = false;
                subId = subId6;
                break;
            case 11:
                int subId7 = getRequestSubId(url);
                pin2 = null;
                efType = -1;
                isFdn = false;
                isGas = true;
                isAas = false;
                subId = subId7;
                break;
            case 14:
                int subId8 = SubscriptionManager.getDefaultSubscriptionId();
                pin2 = null;
                efType = -1;
                isFdn = false;
                isGas = false;
                isAas = true;
                subId = subId8;
                break;
            case 15:
                int subId9 = getRequestSubId(url);
                pin2 = null;
                efType = -1;
                isFdn = false;
                isGas = false;
                isAas = true;
                subId = subId9;
                break;
        }
        String newTag = values.getAsString(STR_TAG);
        String newNumber = values.getAsString(STR_NUMBER);
        Integer index = values.getAsInteger(STR_INDEX);
        String newanr = values.getAsString(STR_ANR);
        String newaas = values.getAsString(STR_AAS);
        String newsne = values.getAsString(STR_SNE);
        String newgrp = values.getAsString(STR_GRP);
        String newgas = values.getAsString(STR_GAS);
        int subId10 = subId;
        String newEmail = values.getAsString(STR_EMAILS);
        if (newEmail == null) {
            newemails = null;
        } else {
            String[] newemails2 = {newEmail};
            newemails = newemails2;
        }
        String newaas2 = newaas == null ? "" : newaas;
        if (TelephonyUtils.IS_DEBUGGABLE) {
            log("update, new tag: " + newTag + ",  number:" + newNumber + ",  anr:" + newanr + ",  aas: " + newaas2 + ",  sne:" + newsne + ",  grp:" + newgrp + ",  gas :" + newgas + ",  email:" + newEmail + ",  index:" + index + ", efType = 0x" + (efType != -1 ? Integer.toHexString(efType).toUpperCase() : Integer.valueOf(efType)));
        }
        if (isFdn) {
            String tag = values.getAsString(STR_TAG);
            String number = values.getAsString(STR_NUMBER);
            i = 1;
            int recIndex = updateIccRecordInEf(efType, tag, number, null, "", "", "", values.getAsString(STR_NEW_TAG), values.getAsString(STR_NEW_NUMBER), null, "", "", "", "", "", pin2, subId10);
            if (recIndex < 0) {
                return recIndex;
            }
            success = true;
            uniIccProvider = this;
            uri = url;
            i2 = 0;
        } else {
            int efType2 = efType;
            String newaas3 = newaas2;
            i = 1;
            if (isGas) {
                int recIndex2 = updateUsimGroupByIndex(newgas, index.intValue(), subId10);
                if (recIndex2 < 0) {
                    if (url.getBooleanQueryParameter(WITH_EXCEPTION, false)) {
                        throwException(recIndex2);
                    }
                    success = false;
                    i2 = 0;
                    uri = url;
                    uniIccProvider = this;
                } else {
                    success = true;
                    i2 = 0;
                    uri = url;
                    uniIccProvider = this;
                }
            } else {
                if (isAas) {
                    return updateUsimAasByIndex(newaas3, index.intValue(), subId10) < 0 ? 0 : 1;
                }
                if (index == null) {
                    log("the 3rd app will not use index");
                    String tag2 = values.getAsString(STR_TAG);
                    String number2 = values.getAsString(STR_NUMBER);
                    success = updateIccRecordFromEf(efType2, tag2, number2, values.getAsString(STR_NEW_TAG), values.getAsString(STR_NEW_NUMBER), pin2, subId10);
                    uniIccProvider = this;
                    i2 = 0;
                    uri = url;
                } else {
                    i2 = 0;
                    int subId11 = index.intValue();
                    uri = url;
                    int recIndex3 = updateIccRecordInEfByIndex(efType2, newTag, newNumber, newemails, newanr, newaas3, newsne, newgrp, newgas, subId11, pin2, subId10);
                    if (recIndex3 < 0) {
                        if (!uri.getBooleanQueryParameter(WITH_EXCEPTION, false)) {
                            uniIccProvider = this;
                        } else {
                            uniIccProvider = this;
                            uniIccProvider.throwException(recIndex3);
                        }
                        success = false;
                    } else {
                        uniIccProvider = this;
                        i2 = 0;
                        success = true;
                    }
                }
            }
        }
        if (!success) {
            return i2;
        }
        uniIccProvider.mContext.getContentResolver().notifyChange(uri, null);
        return i;
    }

    private int getRequestSubId(Uri url) {
        try {
            return Integer.parseInt(url.getLastPathSegment());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Unknown URL " + url);
        }
    }

    private MatrixCursor loadFromEf(int efType, int subId) {
        List<UniAdnRecord> adnRecords = null;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                adnRecords = iccIpb.getAdnRecordsInEfForSubscriber(subId, efType);
            }
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
        }
        if (adnRecords != null) {
            int N = adnRecords.size();
            MatrixCursor cursor = new MatrixCursor(ADDRESS_BOOK_COLUMN_NAMES, N);
            log("adnRecords.size = " + N);
            for (int i = 0; i < N; i++) {
                loadRecord(adnRecords.get(i), cursor, i);
            }
            return cursor;
        }
        log("Cannot load ADN records efType = 0x" + Integer.toHexString(efType).toUpperCase() + ", subId=" + subId);
        return new MatrixCursor(ADDRESS_BOOK_COLUMN_NAMES);
    }

    private boolean deleteIccRecordFromEf(int efType, String name, String number, String[] emails, String pin2, int subId) {
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb == null) {
                return false;
            }
            boolean success = iccIpb.updateAdnRecordsInEfBySearchForSubscriber(subId, efType, name, number, "", "", pin2);
            return success;
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
            return false;
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
            return false;
        }
    }

    private int addIccRecordToEf(int efType, String name, String number, String[] emails, String anr, String aas, String sne, String grp, String gas, String pin2, int subId) {
        int retIndex = -1;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                retIndex = iccIpb.updateAdnRecordsInEfBySearchForSubscriberEx(subId, efType, "", "", (String[]) null, "", "", "", name, number, emails, anr, aas, sne, grp, gas, pin2);
            }
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
        }
        log("addIccRecordToEf: " + retIndex);
        return retIndex;
    }

    private int deleteIccRecordFromEf(int efType, String name, String number, String[] emails, String anr, String sne, String grp, String pin2, int subId) {
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb == null) {
                return -1;
            }
            int retIndex = iccIpb.updateAdnRecordsInEfBySearchForSubscriberEx(subId, efType, name, number, emails, anr, sne, grp, "", "", (String[]) null, "", "", "", "", "", pin2);
            return retIndex;
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
            return -1;
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
            return -1;
        }
    }

    private int deleteIccRecordFromEfByIndex(int efType, int index, String pin2, int subId) {
        int recIndex = -1;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                recIndex = iccIpb.updateAdnRecordsInEfByIndexForSubscriber(subId, efType, "", "", (String[]) null, "", "", "", "", "", index, pin2);
            }
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
        }
        if (recIndex < 0) {
        }
        return recIndex;
    }

    private boolean updateIccRecordFromEf(int efType, String oldName, String oldNumber, String newName, String newNumber, String pin2, int subId) {
        boolean success = false;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                success = iccIpb.updateAdnRecordsInEfBySearchForSubscriber(subId, efType, oldName, oldNumber, newName, newNumber, pin2);
            }
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
        }
        log("updateIccRecordInEf: " + success);
        return success;
    }

    private int updateIccRecordInEf(int efType, String oldName, String oldNumber, String[] oldEmailList, String oldAnr, String oldSne, String oldGrp, String newName, String newNumber, String[] newEmailList, String newAnr, String newAas, String newSne, String newGrp, String newGas, String pin2, int subId) {
        int retIndex = -1;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                retIndex = iccIpb.updateAdnRecordsInEfBySearchForSubscriberEx(subId, efType, oldName, oldNumber, oldEmailList, oldAnr, oldSne, oldGrp, newName, newNumber, newEmailList, newAnr, newAas, newSne, newGrp, newGas, pin2);
            }
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
        }
        log("updateIccRecordInEf: " + retIndex);
        return retIndex;
    }

    private int updateIccRecordInEfByIndex(int efType, String newName, String newNumber, String[] newEmailList, String newAnr, String newAas, String newSne, String newGrp, String newGas, int simIndex, String pin2, int subId) {
        int recIndex = -1;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                recIndex = iccIpb.updateAdnRecordsInEfByIndexForSubscriber(subId, efType, newName, newNumber, newEmailList, newAnr, newAas, newSne, newGrp, newGas, simIndex, pin2);
            }
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
        }
        log("updateIccRecordInEfByIndex: " + recIndex);
        return recIndex;
    }

    private void loadRecord(UniAdnRecord record, MatrixCursor cursor, int id) {
        if (!record.isEmpty()) {
            Object[] contact = new Object[ADDRESS_BOOK_COLUMN_NAMES.length];
            String alphaTag = record.getAlphaTag();
            String number = record.getNumber();
            String[] emails = record.getEmails();
            String anr = record.getAnr();
            String aas = record.getAas();
            String sne = record.getSne();
            String grp = record.getGrp();
            String gas = record.getGas();
            contact[0] = alphaTag;
            contact[1] = number;
            String sim_index = String.valueOf(record.getRecId());
            if (TelephonyUtils.IS_DEBUGGABLE) {
                log("loadRecord: " + alphaTag + ", " + number + "," + anr + ", " + aas + ", " + sne + ", " + grp + ", " + gas + ", sim_index = " + sim_index);
            }
            if (emails != null) {
                StringBuilder emailString = new StringBuilder();
                if (emails.length > 0) {
                    String email = emails[0];
                    emailString.append(email);
                }
                contact[2] = emailString.toString();
            }
            contact[3] = anr;
            contact[4] = aas;
            contact[5] = sne;
            contact[6] = grp;
            contact[7] = gas;
            contact[8] = sim_index;
            contact[9] = Integer.valueOf(id);
            cursor.addRow(contact);
        }
    }

    private MatrixCursor getEfSize(int efType, int subId) {
        int[] adnRecordSize = null;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                adnRecordSize = iccIpb.getAdnRecordsSizeForSubscriber(subId, efType);
            }
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
        }
        if (adnRecordSize != null) {
            MatrixCursor cursor = new MatrixCursor(FDN_S_COLUMN_NAMES, 1);
            Object[] size = {Integer.valueOf(adnRecordSize[2])};
            cursor.addRow(size);
            return cursor;
        }
        log("Cannot load ADN records");
        return new MatrixCursor(FDN_S_COLUMN_NAMES);
    }

    private MatrixCursor loadGas(int subId) {
        List<String> adnGas = null;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                adnGas = iccIpb.getGasInEfForSubscriber(subId);
            }
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
        }
        if (adnGas != null) {
            int N = adnGas.size();
            MatrixCursor cursor = new MatrixCursor(SIM_GROUP_PROJECTION, N);
            log("adnGas.size = " + N);
            for (int i = 0; i < N; i++) {
                if (!TextUtils.isEmpty(adnGas.get(i))) {
                    Object[] group = new Object[SIM_GROUP_PROJECTION.length];
                    group[0] = adnGas.get(i);
                    group[1] = Integer.valueOf(i + 1);
                    cursor.addRow(group);
                    log("loadGas: " + group[1] + ", " + group[0]);
                }
            }
            return cursor;
        }
        log("Cannot load Gas records");
        return new MatrixCursor(SIM_GROUP_PROJECTION);
    }

    private int addUsimGroupBySearch(String groupName, int subId) {
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb == null) {
                return -1;
            }
            int groupId = iccIpb.updateUsimGroupBySearchForSubscriber(subId, "", groupName);
            return groupId;
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
            return -1;
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
            return -1;
        }
    }

    private int updateUsimGroupByIndex(String newName, int groupId, int subId) {
        int result = -1;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                result = iccIpb.updateUsimGroupByIndexForSubscriber(subId, newName, groupId);
            }
        } catch (RemoteException ex) {
            log("RemoteException " + ex.toString());
        } catch (SecurityException ex2) {
            log("SecurityException " + ex2.toString());
        }
        boolean z = result >= 0;
        return result;
    }

    private void throwException(int errorCode) {
        switch (errorCode) {
            case -13:
                throw new IllegalStateException("over the length of anr phone number");
            case -12:
                throw new IllegalStateException("aas capacity full");
            case -11:
                throw new IllegalStateException("over the length of aas");
            case -10:
                throw new IllegalStateException("over the length of grp");
            case -9:
                throw new IllegalStateException("anr record capacity full");
            case -8:
                throw new IllegalStateException("group capacity full");
            case -7:
                throw new IllegalStateException("over the length of group name");
            case -6:
                throw new IllegalStateException("load adn failed");
            case -5:
                throw new IllegalStateException("over the length of phone number");
            case -4:
                throw new IllegalStateException("over the length of name ");
            case -3:
                throw new IllegalStateException("adn record capacity full");
            case -2:
                throw new IllegalStateException("email capacity full");
            case -1:
                throw new IllegalStateException("write record failed");
            default:
                return;
        }
    }

    private void log(String msg) {
        UniPhoneBookLog.d(TAG, msg);
    }

    private MatrixCursor loadAas(int subId) {
        List<String> adnAas = null;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                adnAas = iccIpb.getAasInEfForSubscriber(subId);
            }
        } catch (RemoteException e) {
        } catch (SecurityException ex) {
            log(ex.toString());
        }
        if (adnAas != null) {
            int N = adnAas.size();
            MatrixCursor cursor = new MatrixCursor(SIM_AAS_PROJECTION, N);
            log("adnAas.size = " + N);
            for (int i = 0; i < N; i++) {
                if (!TextUtils.isEmpty(adnAas.get(i))) {
                    Object[] aas = new Object[SIM_AAS_PROJECTION.length];
                    aas[0] = adnAas.get(i);
                    aas[1] = Integer.valueOf(i + 1);
                    cursor.addRow(aas);
                }
            }
            return cursor;
        }
        log("Cannot load Aas records");
        return new MatrixCursor(SIM_AAS_PROJECTION);
    }

    private int addUsimAas(String aas, int subId) {
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb == null) {
                return -1;
            }
            int aasIndex = iccIpb.updateUsimAasBySearchForSubscriber("", aas, subId);
            return aasIndex;
        } catch (RemoteException e) {
            return -1;
        } catch (SecurityException ex) {
            log(ex.toString());
            return -1;
        }
    }

    private int updateUsimAasByIndex(String newName, int aasIndex, int subId) {
        int result = -1;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                result = iccIpb.updateUsimAasByIndexForSubscriber(newName, aasIndex, subId);
            }
        } catch (RemoteException e) {
        } catch (SecurityException ex) {
            log(ex.toString());
        }
        boolean success = result >= 0;
        log("updateUsimAasByIndex: " + success);
        return result;
    }

    private MatrixCursor getSneSize(int subId) {
        int senSize = 0;
        try {
            IUniIccPhoneBook iccIpb = getIccPhoneBook();
            if (iccIpb != null) {
                senSize = iccIpb.getSneSize(subId);
            }
        } catch (RemoteException e) {
        } catch (SecurityException ex) {
            log(ex.toString());
        }
        MatrixCursor cursor = new MatrixCursor(new String[]{"size"});
        cursor.addRow(new Object[]{Integer.valueOf(senSize)});
        return cursor;
    }

    private IUniIccPhoneBook getIccPhoneBook() {
        return IUniIccPhoneBook.Stub.asInterface(ServiceManager.getService("uni_simphonebook"));
    }
}
