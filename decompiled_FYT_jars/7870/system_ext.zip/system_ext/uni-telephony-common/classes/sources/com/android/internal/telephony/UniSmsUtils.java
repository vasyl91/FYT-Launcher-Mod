package com.android.internal.telephony;

import android.R;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.RemoteException;
import android.os.SystemProperties;
import android.provider.Settings;
import android.telephony.SmsManagerEx;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniSmsUtils extends UniAbsSmsUtils {
    public static final int DONOTHING_IN_THAILAND = 10003;
    private static final String FDN_CONTENT_URI = "content://icc/fdn/subId/";
    private static final int FDN_NUMBER_COLUMN = 1;
    private static final String[] FDN_SELECT_PROJECTION = {"name", "number"};
    public static final int IS_TRUE_SIM_IN_THAILAND = 10000;
    private static final int MAX_SEND_RETRIES = 3;
    private static final String MIME_TYPE_NOKIA_BOOKMARKS = "application/x-wap-prov.browser-bookmarks";
    private static final String MIME_TYPE_NOKIA_SETTINGS = "application/x-wap-prov.browser-settings";
    private static final String MIME_TYPE_OMA = "application/vnd.wap.connectivity-wbxml";
    public static final int NOT_IN_THAILAND = 10002;
    public static final int NOT_TRUE_SIM_IN_THAILAND = 10001;
    private static final String OMACP_RECEIVER_ACTION = "com.unisoc.action.OMACP_RECEIVER";
    private static final String SEND_RETRIE_TIME = "message_send_retries";
    public static final String TAG = "UniSmsUtils";
    private boolean isInFdnListBool;
    private String smscStr;

    public UniSmsUtils() {
        Log.d("TAG", "UniSmsUtils create instance!");
    }

    public void sendOmacpBroadcast(Context context, Intent intent) {
        if (!checkMimeType(intent.getType())) {
            Log.d(TAG, "Ignore cause by mimetype error!");
            return;
        }
        Intent omacpIntent = new Intent(OMACP_RECEIVER_ACTION);
        omacpIntent.putExtra("mimeType", intent.getType());
        int subId = intent.getIntExtra("android.telephony.extra.SUBSCRIPTION_INDEX", -1);
        if (SubscriptionManager.isValidSubscriptionId(subId)) {
            SubscriptionManager.putSubscriptionIdExtra(omacpIntent, subId);
        }
        String address = intent.getStringExtra("address");
        if (address != null && address.length() > 0) {
            omacpIntent.putExtra("address", address);
        }
        omacpIntent.putExtra("data", intent.getByteArrayExtra("data"));
        omacpIntent.putExtra("header", intent.getByteArrayExtra("header"));
        omacpIntent.putExtra("pduType", intent.getIntExtra("pduType", -12345));
        omacpIntent.putExtra("contentTypeParameters", intent.getSerializableExtra("contentTypeParameters"));
        omacpIntent.setPackage("com.sprd.omacp");
        context.sendBroadcast(omacpIntent, "com.unisoc.permission.OMACP");
        Log.d(TAG, "Send Omacp Broadcast!");
    }

    private boolean checkMimeType(String mimeType) {
        if (TextUtils.isEmpty(mimeType)) {
            return false;
        }
        if (!mimeType.equals(MIME_TYPE_OMA) && !mimeType.equals(MIME_TYPE_NOKIA_SETTINGS) && !mimeType.equals(MIME_TYPE_NOKIA_BOOKMARKS)) {
            return false;
        }
        Log.d(TAG, "MimeType is " + mimeType + ", check pass!");
        return true;
    }

    public int getMaxSendRetries(Context context) {
        String retryKey = Settings.Global.getString(context.getContentResolver(), SEND_RETRIE_TIME);
        int retryTime = 3;
        if (retryKey != null) {
            try {
                retryTime = Integer.parseInt(retryKey);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        Log.d(TAG, "smsMaxRetries retryKey/retryTime is:" + retryKey + "/" + retryTime);
        return retryTime;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:13:0x0036 A[RETURN] */
    public int dispatchCarrierTrue(Context context, Phone phone, SmsMessageBase smsb) {
        if (!checktheOperatorIsThailand()) {
            return -1;
        }
        switch (judgeTrueSIM2(context, phone)) {
            case NOT_TRUE_SIM_IN_THAILAND /* 10001 */:
                SmsHeader smsHeader = smsb.getUserDataHeader();
                Log.d(TAG, "destination smsHeader: " + smsHeader);
                if (smsHeader != null) {
                    return 1;
                }
                return -1;
            case NOT_IN_THAILAND /* 10002 */:
                Log.d(TAG, "Received short message on device which doesn't support receiving SMS. Ignored.");
                return 1;
            default:
                return -1;
        }
    }

    public int carrierTureError(Context context, int error, Phone phone) {
        if (!checktheOperatorIsThailand()) {
            return error;
        }
        switch (judgeTrueSIM2(context, phone)) {
            case NOT_TRUE_SIM_IN_THAILAND /* 10001 */:
            case NOT_IN_THAILAND /* 10002 */:
                Log.d(TAG, "the number does not support sending sms");
                return 1;
            default:
                return error;
        }
    }

    private int judgeTrueSIM2(Context context, Phone phone) {
        if (phone.getPhoneId() == 0) {
            return DONOTHING_IN_THAILAND;
        }
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
        String mccMnc = telephonyManager.getSimOperatorNumericForPhone(1);
        if (mccMnc == null || "".equals(mccMnc)) {
            return DONOTHING_IN_THAILAND;
        }
        String mcc = mccMnc.substring(0, 3);
        String mnc = mccMnc.substring(3);
        Log.d(TAG, "PhoneId: " + phone.getPhoneId() + "; Mcc: " + mcc + "; Mnc: " + mnc);
        if (!"520".equals(mcc)) {
            return NOT_IN_THAILAND;
        }
        if ("00".equals(mnc) || "04".equals(mnc) || "99".equals(mnc)) {
            return 10000;
        }
        return NOT_TRUE_SIM_IN_THAILAND;
    }

    private boolean checktheOperatorIsThailand() {
        String operator = SystemProperties.get("ro.Thailand.operator");
        if (TextUtils.isEmpty(operator)) {
            operator = SystemProperties.get("ro.operator");
        }
        if (operator != null && operator.toLowerCase().equals("thailand_true")) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [com.android.internal.telephony.UniSmsUtils$1] */
    public void sendSmsOnFailFdn(final Context context, final String destAddress, final int subId) {
        new AsyncTask<Void, Void, Void>() { // from class: com.android.internal.telephony.UniSmsUtils.1
            /* JADX INFO: Access modifiers changed from: protected */
            @Override // android.os.AsyncTask
            public Void doInBackground(Void... params) {
                try {
                    UniSmsUtils.this.smscStr = SmsManagerEx.getDefault().getSmscForSubscriber(subId);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
                UniSmsUtils uniSmsUtils = UniSmsUtils.this;
                uniSmsUtils.isInFdnListBool = uniSmsUtils.isInFdnList(context, destAddress, subId);
                Log.d(UniSmsUtils.TAG, "onFailed: isInFdnListBool:" + UniSmsUtils.this.isInFdnListBool + " smscStr: " + UniSmsUtils.this.smscStr + "destAddress: " + destAddress);
                return null;
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // android.os.AsyncTask
            public void onPostExecute(Void result) {
                if (!TextUtils.isEmpty(UniSmsUtils.this.smscStr) && UniSmsUtils.this.isInFdnListBool) {
                    UniSmsUtils uniSmsUtils = UniSmsUtils.this;
                    uniSmsUtils.showFdnDialog(context, uniSmsUtils.smscStr);
                    Log.d(UniSmsUtils.TAG, "sms show smsc fdn_check_failure");
                    return;
                }
                UniSmsUtils.this.showFdnDialog(context, destAddress);
            }
        }.execute(null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isInFdnList(Context context, String number, int subId) {
        if (TextUtils.isEmpty(number)) {
            return false;
        }
        String formatNumber = number.replace(" ", "");
        Cursor cursor = context.getContentResolver().query(Uri.parse(FDN_CONTENT_URI + subId), FDN_SELECT_PROJECTION, null, null, null);
        while (cursor != null) {
            try {
                if (!cursor.moveToNext()) {
                    break;
                }
                String compareNumber = cursor.getString(1);
                if (compareNumber != null && compareNumber.equals(formatNumber)) {
                    if (cursor != null) {
                        cursor.close();
                    }
                    return true;
                }
            } catch (Throwable th) {
                if (cursor != null) {
                    cursor.close();
                }
                throw th;
            }
        }
        if (cursor != null) {
            cursor.close();
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showFdnDialog(Context context, String number) {
        Log.d(TAG, "showFdnDialog");
        AlertDialog builder = new AlertDialog.Builder(context).setMessage(context.getString(135004232, number)).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() { // from class: com.android.internal.telephony.UniSmsUtils.3
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }).setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.android.internal.telephony.UniSmsUtils.2
            @Override // android.content.DialogInterface.OnDismissListener
            public void onDismiss(DialogInterface dialog) {
                dialog.dismiss();
            }
        }).create();
        builder.getWindow().setType(2008);
        builder.show();
    }
}
