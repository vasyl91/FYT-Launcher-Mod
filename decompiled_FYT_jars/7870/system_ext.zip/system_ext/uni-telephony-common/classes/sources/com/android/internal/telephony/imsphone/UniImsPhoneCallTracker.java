package com.android.internal.telephony.imsphone;

import android.net.ConnectivityManager;
import android.os.AsyncResult;
import android.os.Bundle;
import android.os.Message;
import android.os.PersistableBundle;
import android.os.SystemProperties;
import android.provider.Settings;
import android.telecom.VideoProfile;
import android.telephony.PhoneNumberUtils;
import android.telephony.ServiceState;
import android.telephony.SubscriptionManager;
import android.telephony.UniCarrierConfigManager;
import android.telephony.emergency.EmergencyNumber;
import android.telephony.ims.ImsCallProfile;
import android.telephony.ims.ImsReasonInfo;
import android.text.TextUtils;
import android.util.Pair;
import com.android.ims.ImsCall;
import com.android.ims.ImsManager;
import com.android.internal.telephony.Call;
import com.android.internal.telephony.CallStateException;
import com.android.internal.telephony.Connection;
import com.android.internal.telephony.GsmCdmaCall;
import com.android.internal.telephony.GsmCdmaCallTracker;
import com.android.internal.telephony.GsmCdmaConnection;
import com.android.internal.telephony.GsmCdmaPhone;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.PhoneConstants;
import com.android.internal.telephony.PhoneFactory;
import com.android.internal.telephony.UUSInfo;
import com.android.internal.telephony.emergency.EmergencyNumberTracker;
import com.android.internal.telephony.uicc.IccCardApplicationStatus;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.uicc.UiccController;
import com.android.unisoc.telephony.RadioInteractor;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public final class UniImsPhoneCallTracker extends ImsPhoneCallTracker {
    public static final int EMC_DIAL_ON_CELLULAR = 2;
    public static final int EMC_DIAL_ON_UNKNOW = 0;
    public static final int EMC_DIAL_ON_VOWIFI = 1;
    public static final int EMC_NO_NEED_REDIAL = 4;
    private static final String EMC_SOURCE_PROP = "persist.radio.emc.source";
    private static final int EVENT_DIAL_PENDINGMO = 108;
    private static final int EVENT_EXTRA_BASE = 100;
    private static final int EVENT_HANGUP_PENDINGMO = 106;
    private static final int EVENT_HANGUP_PENGDING_CALL = 105;
    private static final int EVENT_RESUME_BACKGROUND = 107;
    private static final int EVENT_RETRY_TIMEOUT = 103;
    private static final int EVENT_RETRY_WIFI_E911_CALL = 102;
    private static final int EVENT_SERVICE_STATE_CHANGED = 101;
    private static final int EVENT_WIFI_E911_CALL_TIMEOUT = 104;
    static final String LOG_TAG = "UniImsPhoneCallTracker";
    private static final int TIMEOUT_HANGUP_PENDINGMO = 500;
    private static final int TIMEOUT_REDIAL_ECALL_ON_CELLULAR = 10000;
    public static final String VIDEO_STATE = "video_state";
    private int mEMCDialFlag;
    private ImsManager mImsManager;
    private ImsPhoneConnection mMergePeerConn;
    private ConcurrentHashMap<Integer, Message> mPendingActionsMap;
    private Call.SrvccState mSrvccState;
    private Object mSyncHold;
    private UniCarrierConfigManager mUniCarrierConfigManager;

    private interface SrvccPendingAction {
        public static final int EVENT_ACCEPT = 3;
        public static final int EVENT_CONFERENCE = 5;
        public static final int EVENT_DIAL = 1;
        public static final int EVENT_HANGUP = 2;
        public static final int EVENT_REJECT = 4;
        public static final int EVENT_SEND_DTMF = 7;
        public static final int EVENT_START_DTMF = 8;
        public static final int EVENT_STOP_DTMF = 9;
        public static final int EVENT_SWITCH_HOLD_ACTIVE = 6;
    }

    public UniImsPhoneCallTracker(ImsPhone phone, ImsPhoneCallTracker.ConnectorFactory factory) {
        super(phone, factory);
        this.mSyncHold = new Object();
        this.mSrvccState = Call.SrvccState.NONE;
        this.mPendingActionsMap = new ConcurrentHashMap<>();
        this.mEMCDialFlag = 0;
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.android.internal.telephony.CallStateException */
    /* JADX WARN: Multi-variable type inference failed */
    public void handleMessage(Message msg) {
        log("handleMessage what= " + msg.what);
        switch (msg.what) {
            case EVENT_SERVICE_STATE_CHANGED /* 101 */:
                Pair<ImsCall, ImsReasonInfo> callInfo = (Pair) ((AsyncResult) msg.obj).userObj;
                if (callInfo != null) {
                    removeMessages(EVENT_RETRY_TIMEOUT);
                    getPhone().getDefaultPhone().getServiceStateTracker().unregisterForNetworkAttached(this);
                    if (!reDialECall((ImsCall) callInfo.first, (ImsReasonInfo) callInfo.second, false)) {
                        sendCallStartFailedDisconnect((ImsCall) callInfo.first, (ImsReasonInfo) callInfo.second);
                    }
                    break;
                }
                break;
            case EVENT_RETRY_WIFI_E911_CALL /* 102 */:
                Pair<ImsCall, ImsReasonInfo> callInfo2 = (Pair) ((AsyncResult) msg.obj).userObj;
                if (callInfo2 != null) {
                    removeMessages(EVENT_WIFI_E911_CALL_TIMEOUT);
                    getPhone().getDefaultPhone().getServiceStateTracker().unregisterForNetworkAttached(this);
                    if (!reDialAsECallOnCellularNetwork((ImsCall) callInfo2.first, (ImsReasonInfo) callInfo2.second)) {
                        sendCallStartFailedDisconnect((ImsCall) callInfo2.first, (ImsReasonInfo) callInfo2.second);
                    }
                    break;
                }
                break;
            case EVENT_RETRY_TIMEOUT /* 103 */:
                Pair<ImsCall, ImsReasonInfo> callInfo3 = (Pair) msg.obj;
                getPhone().getDefaultPhone().getServiceStateTracker().unregisterForNetworkAttached(this);
                removeMessages(EVENT_SERVICE_STATE_CHANGED);
                sendCallStartFailedDisconnect((ImsCall) callInfo3.first, (ImsReasonInfo) callInfo3.second);
                break;
            case EVENT_WIFI_E911_CALL_TIMEOUT /* 104 */:
                Pair<ImsCall, ImsReasonInfo> callInfo4 = (Pair) msg.obj;
                getPhone().getDefaultPhone().getServiceStateTracker().unregisterForNetworkAttached(this);
                removeMessages(EVENT_RETRY_WIFI_E911_CALL);
                sendCallStartFailedDisconnect((ImsCall) callInfo4.first, (ImsReasonInfo) callInfo4.second);
                break;
            case EVENT_HANGUP_PENGDING_CALL /* 105 */:
                try {
                    GsmCdmaCallTracker gsmCdmaCT = getPhone().getDefaultPhone().getCallTracker();
                    if (msg.obj instanceof ImsPhoneConnection) {
                        GsmCdmaConnection gsmCdmaConnection = getGsmCdmaConnection((ImsPhoneConnection) msg.obj);
                        if (gsmCdmaConnection != null) {
                            gsmCdmaCT.hangup(gsmCdmaConnection);
                        } else {
                            log("handleMessage gsmCdmaConnection is null");
                        }
                    } else if (msg.obj instanceof ImsPhoneCall) {
                        GsmCdmaCall gsmCdmaCall = getGsmCdmaCall((ImsPhoneCall) msg.obj);
                        if (gsmCdmaCall != null) {
                            gsmCdmaCT.hangup(gsmCdmaCall);
                        } else {
                            log("handleMessage gsmCdmaCall is null");
                        }
                    }
                } catch (CallStateException e) {
                    log("handleMessage e:" + e);
                    return;
                }
                break;
            default:
                super.handleMessage(msg);
                break;
        }
    }

    public Connection dial(String dialString, ImsPhone.ImsDialArgs dialArgs) throws CallStateException {
        Bundle intentExtras = dialArgs.intentExtras;
        if (shouldPostPonedAction()) {
            Message m = new Message();
            m.what = 1;
            m.obj = dialString;
            m.setData(intentExtras);
            this.mPendingActionsMap.put(1, m);
            log("shouldPostPonedAction->dial.");
            return null;
        }
        log("dial-> intentExtras:" + intentExtras);
        setEccSourceProperty(dialString);
        return super.dial(dialString, dialArgs);
    }

    public boolean isConnectionMatched(GsmCdmaConnection gsmConnection, ImsPhoneConnection imsConnection) throws CallStateException {
        if (imsConnection.getImsCall() != null && imsConnection.getImsCall().getSession() != null && Integer.toString(gsmConnection.getGsmCdmaIndex()).equals(imsConnection.getImsCall().getSession().getCallId())) {
            return true;
        }
        return false;
    }

    public GsmCdmaConnection getMatchedConnection(ImsPhoneConnection imsPhoneConnection, GsmCdmaCall call) throws CallStateException {
        for (int i = 0; i < call.getConnections().size(); i++) {
            GsmCdmaConnection gsmCdmaConn = (GsmCdmaConnection) call.getConnections().get(i);
            if (isConnectionMatched(gsmCdmaConn, imsPhoneConnection)) {
                return gsmCdmaConn;
            }
        }
        return null;
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.android.internal.telephony.CallStateException */
    public GsmCdmaConnection getGsmCdmaConnection(ImsPhoneConnection imsPhoneConnection) throws CallStateException {
        log("getGsmCdmaConnection imsPhoneConnection:" + imsPhoneConnection);
        if (imsPhoneConnection == null) {
            return null;
        }
        GsmCdmaConnection gsmCdmaConn = null;
        try {
            GsmCdmaConnection gsmCdmaConn2 = getMatchedConnection(imsPhoneConnection, (GsmCdmaCall) getPhone().getDefaultPhone().getRingingCall());
            if (gsmCdmaConn2 != null) {
                return gsmCdmaConn2;
            }
            gsmCdmaConn = getMatchedConnection(imsPhoneConnection, (GsmCdmaCall) getPhone().getDefaultPhone().getForegroundCall());
            if (gsmCdmaConn != null) {
                return gsmCdmaConn;
            }
            gsmCdmaConn = getMatchedConnection(imsPhoneConnection, (GsmCdmaCall) getPhone().getDefaultPhone().getBackgroundCall());
            if (gsmCdmaConn != null) {
                return gsmCdmaConn;
            }
        } catch (CallStateException e) {
            log("getGsmCdmaConnection e:" + e);
        }
        return gsmCdmaConn;
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.android.internal.telephony.CallStateException */
    public GsmCdmaCall getGsmCdmaCall(ImsPhoneCall imsPhoneCall) {
        log("getGsmCdmaCall imsPhoneCall:" + imsPhoneCall);
        if (imsPhoneCall == null) {
            return null;
        }
        GsmCdmaCall ringingCall = (GsmCdmaCall) getPhone().getDefaultPhone().getRingingCall();
        GsmCdmaCall foregroundCall = (GsmCdmaCall) getPhone().getDefaultPhone().getForegroundCall();
        GsmCdmaCall backgroundCall = (GsmCdmaCall) getPhone().getDefaultPhone().getBackgroundCall();
        for (int i = 0; i < imsPhoneCall.getConnections().size(); i++) {
            ImsPhoneConnection imsPhoneConnection = (ImsPhoneConnection) imsPhoneCall.getConnections().get(i);
            try {
                GsmCdmaConnection gsmCdmaConn = getMatchedConnection(imsPhoneConnection, ringingCall);
                if (gsmCdmaConn != null) {
                    return ringingCall;
                }
                GsmCdmaConnection gsmCdmaConn2 = getMatchedConnection(imsPhoneConnection, foregroundCall);
                if (gsmCdmaConn2 != null) {
                    return foregroundCall;
                }
                GsmCdmaConnection gsmCdmaConn3 = getMatchedConnection(imsPhoneConnection, backgroundCall);
                if (gsmCdmaConn3 != null) {
                    return backgroundCall;
                }
            } catch (CallStateException e) {
                log("getGsmCdmaCall e:" + e);
            }
        }
        return null;
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.android.internal.telephony.CallStateException */
    public void hangup(ImsCall imsCall) throws CallStateException {
        if (imsCall == null) {
            throw new CallStateException("no ImsCall");
        }
        log("hangup imsCall " + imsCall);
        if (imsCall != null) {
            imsCall.terminate(501);
        }
        getPhone().notifyPreciseCallStateChanged();
    }

    public void notifySrvccState(Call.SrvccState state) {
        log("notifySrvccState->state:" + state);
        super.notifySrvccState(state);
        this.mSrvccState = state;
        if (state == Call.SrvccState.COMPLETED) {
            excutePendingActions();
        }
    }

    private boolean shouldPostPonedAction() {
        return this.mSrvccState == Call.SrvccState.STARTED;
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.android.internal.telephony.CallStateException */
    public void hangup(ImsPhoneConnection conn) throws CallStateException {
        if (shouldPostPonedAction()) {
            Message m = new Message();
            m.what = 2;
            m.obj = conn;
            this.mPendingActionsMap.put(2, m);
            log("shouldPostPonedAction->hangup.");
            return;
        }
        if (shoudHangupImsCall(conn)) {
            hangup(conn.getImsCall());
        } else {
            super.hangup(conn);
        }
    }

    public boolean shoudHangupImsCall(ImsPhoneConnection conn) {
        int activeCallCount = 0;
        List<Connection> l = conn.getCall().getConnections();
        if (l != null && l.size() < 2) {
            return false;
        }
        int s = l.size();
        for (int i = 0; i < s; i++) {
            if (l.get(i).getState() == Call.State.ACTIVE && !l.get(i).getCall().isMultiparty()) {
                activeCallCount++;
            }
        }
        if (activeCallCount < 2) {
            return false;
        }
        return true;
    }

    public void hangup(ImsPhoneCall call) throws CallStateException {
        if (shouldPostPonedAction()) {
            Message m = new Message();
            m.what = 2;
            m.obj = call;
            this.mPendingActionsMap.put(2, m);
            log("shouldPostPonedAction->hangup.");
            return;
        }
        super.hangup(call);
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.android.internal.telephony.CallStateException */
    public void acceptCall(int videoState) throws CallStateException {
        ImsPhoneConnection conn;
        int oldVideoState;
        if (shouldPostPonedAction()) {
            Message m = new Message();
            m.what = 3;
            m.arg1 = videoState;
            this.mPendingActionsMap.put(3, m);
            log("shouldPostPonedAction->acceptCall.");
            return;
        }
        if (this.mForegroundCall.getState().isAlive() && this.mBackgroundCall.getState().isAlive()) {
            throw new CallStateException("cannot accept call");
        }
        boolean shouldSendSessionModifyRequest = false;
        if (this.mRingingCall.getState() == Call.State.WAITING && this.mForegroundCall.getState().isAlive()) {
            ImsCall activeCall = this.mForegroundCall.getImsCall();
            ImsCall ringingCall = this.mRingingCall.getImsCall();
            if (this.mForegroundCall.hasConnections() && this.mRingingCall.hasConnections()) {
                boolean answeringWillDisconnect = shouldDisconnectActiveCallOnAnswerInternal(activeCall, ringingCall);
                shouldSendSessionModifyRequest = !answeringWillDisconnect;
            }
        }
        super.acceptCall(videoState);
        if (shouldSendSessionModifyRequest && (conn = findImsConnection(this.mRingingCall.getImsCall())) != null && (oldVideoState = conn.getVideoState()) != videoState && conn.getVideoProvider() != null) {
            log("Send session modify request when the second call is accepted ");
            conn.getVideoProvider().onSendSessionModifyRequest(new VideoProfile(oldVideoState), new VideoProfile(videoState));
        }
    }

    public void rejectCall() throws CallStateException {
        if (shouldPostPonedAction()) {
            Message m = new Message();
            m.what = 4;
            this.mPendingActionsMap.put(4, m);
            log("shouldPostPonedAction->rejectCall.");
            return;
        }
        super.rejectCall();
    }

    public void conference() {
        if (shouldPostPonedAction()) {
            Message m = new Message();
            m.what = 5;
            this.mPendingActionsMap.put(5, m);
            log("shouldPostPonedAction->conference.");
            return;
        }
        super.conference();
    }

    public void sendDtmf(char c, Message result) {
        if (shouldPostPonedAction()) {
            Message m = new Message();
            m.what = 7;
            AsyncResult ar = new AsyncResult(Character.valueOf(c), result, (Throwable) null);
            m.obj = ar;
            this.mPendingActionsMap.put(7, m);
            log("shouldPostPonedAction->sendDtmf.");
            return;
        }
        super.sendDtmf(c, result);
    }

    public void startDtmf(char c) {
        if (shouldPostPonedAction()) {
            Message m = new Message();
            m.what = 8;
            m.obj = Character.valueOf(c);
            this.mPendingActionsMap.put(8, m);
            log("shouldPostPonedAction->startDtmf.");
            return;
        }
        super.startDtmf(c);
    }

    public void stopDtmf() {
        super.stopDtmf();
        if (this.mForegroundCall.getImsCall() == null) {
            ImsCall imscall = this.mBackgroundCall.getImsCall();
            log("stopDtmf for hold call: " + imscall);
            if (imscall != null) {
                imscall.stopDtmf();
            }
        }
    }

    private void excutePendingActions() {
        log("excutePendingActions.");
        for (Message m : this.mPendingActionsMap.values()) {
            log("excutePendingActions->m.what:" + m.what);
            GsmCdmaCallTracker gsmCdmaCT = getPhone().getDefaultPhone().getCallTracker();
            try {
                switch (m.what) {
                    case 1:
                        Bundle intentExtras = m.peekData();
                        Connection dialconn = gsmCdmaCT.dialGsm((String) m.obj, (UUSInfo) null, intentExtras);
                        if (dialconn != null) {
                            getPhone().notifyUnknownConnection(dialconn);
                        }
                        break;
                    case 2:
                        Message msg = new Message();
                        msg.what = EVENT_HANGUP_PENGDING_CALL;
                        msg.obj = m.obj;
                        sendMessageDelayed(msg, 200L);
                        break;
                    case 3:
                        gsmCdmaCT.acceptCall();
                        break;
                    case 4:
                        gsmCdmaCT.rejectCall();
                        break;
                    case 5:
                        gsmCdmaCT.conference();
                        break;
                    case 6:
                        gsmCdmaCT.switchWaitingOrHoldingAndActive();
                        break;
                    case 7:
                        AsyncResult dtmfAR = (AsyncResult) m.obj;
                        getPhone().getDefaultPhone().sendDtmf(((Character) dtmfAR.userObj).charValue());
                        break;
                    case 8:
                        getPhone().getDefaultPhone().startDtmf(((Character) m.obj).charValue());
                        break;
                    case 9:
                        getPhone().getDefaultPhone().stopDtmf();
                        break;
                    default:
                        log("excutePendingActions->not support action->m.what:" + m.what);
                        break;
                }
            } catch (CallStateException e) {
            }
        }
    }

    public void addSrvccPendingEvent(Message m) {
        log("addSrvccPendingEvent:" + m.what);
        this.mPendingActionsMap.put(Integer.valueOf(m.what), m);
    }

    public int getDisconnectCauseFromReasonInfo(ImsReasonInfo reasonInfo, Call.State callState) {
        int code = maybeRemapReasonCode(reasonInfo);
        switch (code) {
            case 143:
            case 504:
            case 1404:
                return 16;
            case 339:
                return 44;
            case 502:
            case 510:
                return 2;
            default:
                return super.getDisconnectCauseFromReasonInfo(reasonInfo, callState);
        }
    }

    public void processImsIncomingCall(ImsCall imsCall) {
        if (getPendingMO() != null && imsCall != null) {
            imsCall.terminate(501);
        }
    }

    public void handleMergeComplete(ImsPhoneConnection peerConnection, ImsPhoneConnection conn) {
        if (peerConnection != null) {
            peerConnection.handleMergeComplete();
        }
        if (conn != null) {
            conn.handleMergeComplete();
        }
    }

    public void onImsCallMergeFailed(ImsCall call, ImsReasonInfo reasonInfo) {
        if (reasonInfo.mCode == 149) {
            Message m = new Message();
            m.what = 5;
            log("onCallHoldFailed->resume.");
            addSrvccPendingEvent(m);
        }
    }

    public boolean switchWaitingOrHoldingAndActive() throws CallStateException {
        if (shouldPostPonedAction()) {
            Message m = new Message();
            m.what = 6;
            this.mPendingActionsMap.put(6, m);
            log("switchWaitingOrHoldingAndActive postponed.");
            return true;
        }
        return false;
    }

    public void processImsCallStateChange(ImsCall imsCall, Call.State state, int cause, boolean ignoreState) {
        if (imsCall == null) {
            return;
        }
        ImsPhoneConnection conn = findImsConnection(imsCall);
        if (conn == null) {
            return;
        }
        super.processImsCallStateChange(imsCall, state, cause, ignoreState);
    }

    public void onImsCallHoldFailed(ImsCall imsCall, ImsReasonInfo reasonInfo) {
        if (reasonInfo.mCode == 149) {
            Message m = new Message();
            m.what = 6;
            log("onCallHoldFailed->hold.");
            addSrvccPendingEvent(m);
        }
    }

    public void onImsCallUpdated(ImsCall imsCall, ImsPhoneConnection conn, boolean isLocalTone) {
        if (conn == null || imsCall == null) {
            log("onImsCallUpdated->onholdtonestarted is null.");
            return;
        }
        if (!getOnHoldToneStarted() && isLocalTone && conn.getState() == Call.State.ACTIVE) {
            log("Unisoc start hold tone.");
            getPhone().startOnHoldTone(conn);
            setOnHoldToneStarted(true);
            setOnHoldToneId(System.identityHashCode(conn));
            return;
        }
        if (getOnHoldToneStarted() && !isLocalTone) {
            log("Unisoc stop hold tone.");
            stopOnHoldToneEx(conn);
            setOnHoldToneStarted(false);
        }
    }

    public void onImsCallResumeFailed(ImsCall imsCall, ImsReasonInfo reasonInfo) {
        if (reasonInfo.mCode == 149) {
            Message m = new Message();
            m.what = 6;
            log("onCallHoldFailed->resume.");
            addSrvccPendingEvent(m);
        }
    }

    private boolean getLteRadioCapability() {
        Phone phone = PhoneFactory.getPhone(getPhone().getPhoneId());
        if (phone == null) {
            return false;
        }
        int raf = phone.getRadioAccessFamily();
        return (raf & 4096) == 4096;
    }

    private boolean isUsimCard(int phoneId) {
        if (!SubscriptionManager.isValidPhoneId(phoneId)) {
            log("isUsimCard, Ignore invalid phoneId: " + phoneId);
            return false;
        }
        UiccCardApplication application = UiccController.getInstance().getUiccCardApplication(phoneId, 1);
        return application != null && application.getType() == IccCardApplicationStatus.AppType.APPTYPE_USIM;
    }

    public boolean onImsCallTerminated(ImsCall imsCall, ImsReasonInfo reasonInfo) {
        if (getPhone().getState() == PhoneConstants.State.IDLE) {
            GsmCdmaPhone gsmCdmaPhone = getPhone().getDefaultPhone();
            log("gsmCdmaPhone.getState() = " + gsmCdmaPhone.getState());
            if (gsmCdmaPhone.getState() != PhoneConstants.State.IDLE) {
                gsmCdmaPhone.mCT.sendEmptyMessage(2);
            }
        }
        resetEMCDialFlag();
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean onImsCallStartFailed(ImsCall imsCall, ImsReasonInfo reasonInfo) {
        ImsPhoneConnection conn;
        log("onImsCallStartFailedOrTerminated: imsCall: " + imsCall + " ImsReasonInfo: " + reasonInfo);
        if (reasonInfo.getCode() == 1514) {
            boolean isAirplaneModeOn = Settings.Global.getInt(getPhone().getContext().getContentResolver(), "airplane_mode_on", 0) > 0;
            log("onImsCallStartFailedOrTerminated: CODE_SIP_ALTERNATE_EMERGENCY_CALL");
            if (!isAirplaneModeOn && getPhone().getDefaultPhone().getServiceStateTracker().mSS != null && getPhone().getDefaultPhone().getServiceStateTracker().mSS.getState() != 0 && !getPhone().getDefaultPhone().getServiceStateTracker().mSS.isEmergencyOnly()) {
                reDialECall(imsCall, reasonInfo, true);
                setNoNeedRedial();
                return true;
            }
            ConnectivityManager mgr = (ConnectivityManager) getPhone().getContext().getSystemService("connectivity");
            if (isAirplaneModeOn) {
                mgr.setAirplaneMode(false);
            }
            Pair<ImsCall, ImsReasonInfo> callInfo = new Pair<>(imsCall, reasonInfo);
            getPhone().getDefaultPhone().getServiceStateTracker().registerForNetworkAttached(this, EVENT_RETRY_WIFI_E911_CALL, callInfo);
            sendMessageDelayed(obtainMessage(EVENT_WIFI_E911_CALL_TIMEOUT, callInfo), 10000L);
            return true;
        }
        if (reasonInfo.getCode() == 146) {
            if (getPendingMO() != null) {
                if (getPhone().getDefaultPhone().getServiceStateTracker().mSS.getState() == 3) {
                    reasonInfo.mCode = 1514;
                    log("onImsCallStartFailedOrTerminated: change to CODE_SIP_ALTERNATE_EMERGENCY_CALL");
                    sendCallStartFailedDisconnect(imsCall, reasonInfo);
                    return true;
                }
                if (ignoreCSRedial() && isInternationRoaming() && !isInEmergencyCall()) {
                    log("Should ignore cs redial.");
                    sendCallStartFailedDisconnect(imsCall, reasonInfo);
                    return true;
                }
            }
        } else if (reasonInfo.getCode() != 501 && isVowifiEnabled()) {
            if (hasEMCDialFlag(this.mEMCDialFlag, 4) || hasEMCDialFlag(this.mEMCDialFlag, 3)) {
                log("onImsCallStartFailedOrTerminated no need redial: " + this.mEMCDialFlag + ", getPendingMO() = " + getPendingMO());
                if (getPendingMO() == null) {
                    sendCallStartFailedDisconnect(imsCall, reasonInfo);
                } else {
                    setEMCDialFlag(0);
                }
                return false;
            }
            if (imsCall.isWifiCall()) {
                setEMCDialFlag(1);
                boolean reDialECallOnCellular = getCarrierValueForKey("retry_ecall_cellualr_network");
                log("onImsCallStartFailedOrTerminated reDialECallCellularNetwork: " + reDialECallOnCellular);
                if (reDialECallOnCellular) {
                    boolean isAirplaneModeOn2 = Settings.Global.getInt(getPhone().getContext().getContentResolver(), "airplane_mode_on", 0) > 0;
                    log("onImsCallStartFailedOrTerminated: isAirplaneModeOn = " + isAirplaneModeOn2);
                    ConnectivityManager mgr2 = (ConnectivityManager) getPhone().getContext().getSystemService("connectivity");
                    if (isAirplaneModeOn2) {
                        mgr2.setAirplaneMode(false);
                    }
                    Pair<ImsCall, ImsReasonInfo> callInfo2 = new Pair<>(imsCall, reasonInfo);
                    getPhone().getDefaultPhone().getServiceStateTracker().registerForNetworkAttached(this, EVENT_SERVICE_STATE_CHANGED, callInfo2);
                    sendMessageDelayed(obtainMessage(EVENT_RETRY_TIMEOUT, callInfo2), 10000L);
                    return true;
                }
            } else {
                setEMCDialFlag(2);
                boolean reDialECallOnVowifi = getCarrierValueForKey("retry_ecall_vowifi");
                log("onImsCallStartFailedOrTerminated reDialECallOnVowifi: " + reDialECallOnVowifi);
                if (reDialECallOnVowifi) {
                    reDialECall(imsCall, reasonInfo, true);
                    return true;
                }
            }
        } else if (getPhone().getState() == PhoneConstants.State.IDLE) {
            GsmCdmaPhone gsmCdmaPhone = getPhone().getDefaultPhone();
            log("gsmCdmaPhone.getState() = " + gsmCdmaPhone.getState());
            if (gsmCdmaPhone.getState() != PhoneConstants.State.IDLE) {
                gsmCdmaPhone.mCT.sendEmptyMessage(2);
            }
        }
        if (getPendingMO() != null || (conn = findImsConnection(imsCall)) == null || conn.isIncoming()) {
            return false;
        }
        int cause = getDisconnectCauseFromReasonInfo(reasonInfo, conn.getState());
        processImsCallStateChange(imsCall, Call.State.DISCONNECTED, cause, false);
        resetEMCDialFlag();
        return true;
    }

    private boolean reDialECall(ImsCall imsCall, ImsReasonInfo reasonInfo, boolean tryOnVowifi) {
        if (imsCall == null || imsCall.getCallProfile() == null || reasonInfo == null) {
            log("reDialECall: imsCall:" + imsCall + " reasonInfo: " + reasonInfo);
            return false;
        }
        ImsPhoneConnection oldConnection = findImsConnection(imsCall);
        if (oldConnection == null) {
            log("reDialECall: oldConnection == null!");
            sendCallStartFailedDisconnect(imsCall, reasonInfo);
            return false;
        }
        if (getPendingMO() != null) {
            detachPendingMO(this.mForegroundCall);
        }
        String reDialNum = oldConnection.getAddress();
        int videoState = oldConnection.getVideoState();
        String urn = reasonInfo.getExtraMessage();
        ImsCallProfile profile = imsCall.getCallProfile();
        if (!TextUtils.isEmpty(urn)) {
            profile.setCallExtra("AdditionalCallInfo", urn);
        }
        if (tryOnVowifi) {
            profile.setCallExtra("CallRadioTech", String.valueOf(18));
            setEMCDialFlag(1);
        } else {
            profile.setCallExtra("CallRadioTech", String.valueOf(14));
            setEMCDialFlag(2);
        }
        Bundle intentExtras = profile.mCallExtras;
        try {
            Connection newConnection = getPhone().getDefaultPhone().dial(reDialNum, new ImsPhone.ImsDialArgs.Builder().setVideoState(videoState).setIntentExtras(intentExtras).build());
            oldConnection.onOriginalConnectionReplaced(newConnection);
            return true;
        } catch (CallStateException e) {
            sendCallStartFailedDisconnect(imsCall, reasonInfo);
            return false;
        }
    }

    private boolean reDialAsECallOnCellularNetwork(ImsCall imsCall, ImsReasonInfo reasonInfo) {
        if (imsCall == null || reasonInfo == null || getPendingMO() == null) {
            log("reDialAsECallOnCellularNetwork: imsCall:" + imsCall + " reasonInfo: " + reasonInfo + "getPendingMO: " + getPendingMO());
            return false;
        }
        int category = 0;
        try {
            category = Integer.parseInt(reasonInfo.getExtraMessage());
        } catch (NumberFormatException e) {
            log("reDialAsECallOnCellularNetwork format number err");
        }
        ImsPhoneConnection conn = findImsConnection(imsCall);
        String urn = reasonInfo.getExtraMessage();
        if (conn == null) {
            return false;
        }
        String reDialNum = conn.getAddress();
        GsmCdmaPhone gsmCdmaPhone = getPhone().getDefaultPhone();
        detachPendingMO(this.mForegroundCall);
        if (urn != null && (urn.toLowerCase().contains("urn:service") || urn.contains("urn:service"))) {
            String urnCommand = "AT+WIFISYNC=" + String.valueOf(0) + ",\"" + urn + "\"";
            log("UrnCommand AT command is: " + urnCommand);
            RadioInteractor radioInteractor = new RadioInteractor(getPhone().getContext());
            radioInteractor.sendAtCmd(urnCommand, (String[]) null, getPhone().getPhoneId());
            try {
                Thread.sleep(200L);
            } catch (InterruptedException e2) {
            }
        }
        EmergencyNumber emergencyNumberInfo = new EmergencyNumber(reDialNum, "", "", category, new ArrayList(), 1, 1);
        gsmCdmaPhone.mCi.dial(reDialNum, true, emergencyNumberInfo, true, 0, (Message) null);
        setNoNeedRedial();
        updatePhoneStateEx();
        getPhone().notifyPreciseCallStateChanged();
        return true;
    }

    private boolean getCarrierValueForKey(String key) {
        boolean value = false;
        if (this.mUniCarrierConfigManager == null) {
            this.mUniCarrierConfigManager = new UniCarrierConfigManager(getPhone().getContext());
        }
        PersistableBundle config = this.mUniCarrierConfigManager.getConfigForSubId(getPhone().getSubId());
        if (config != null) {
            value = config.getBoolean(key);
        }
        log("getCarrierValueForKey : " + key + " value = " + value);
        return value;
    }

    private void setEccSourceProperty(String dialString) {
        String address = PhoneNumberUtils.extractNetworkPortionAlt(dialString);
        ImsPhone phone = getPhone();
        if (phone != null) {
            EmergencyNumberTracker tracker = phone.getEmergencyNumberTracker();
            if (tracker != null) {
                EmergencyNumber num = tracker.getEmergencyNumber(address);
                if (num != null) {
                    SystemProperties.set(EMC_SOURCE_PROP, Integer.toBinaryString(num.getEmergencyNumberSourceBitmask()));
                    return;
                } else {
                    log("setEccSourceProperty: emergency number is null ");
                    return;
                }
            }
            log("setEccSourceProperty: emergency number tracker is null");
            return;
        }
        log("setEccSourceProperty: phone is null");
    }

    public void sendCallStartFailedDisconnect(ImsCall imsCall, ImsReasonInfo reasonInfo) {
        resetEMCDialFlag();
        super.sendCallStartFailedDisconnect(imsCall, reasonInfo);
    }

    protected void setNoNeedRedial() {
        setEMCDialFlag(4);
    }

    private boolean hasEMCDialFlag(int eMCDialFlag, int dialFlag) {
        return (eMCDialFlag & dialFlag) == dialFlag;
    }

    private void setEMCDialFlag(int dialFlag) {
        this.mEMCDialFlag |= dialFlag;
    }

    private void resetEMCDialFlag() {
        if (this.mEMCDialFlag != 0) {
            this.mEMCDialFlag = 0;
        }
    }

    private boolean ignoreCSRedial() {
        UniCarrierConfigManager configManager = new UniCarrierConfigManager(getPhone().getContext());
        PersistableBundle config = configManager.getConfigForSubId(getPhone().getSubId());
        if (config == null) {
            return false;
        }
        boolean csRedial = config.getBoolean("carrier_support_cs_redial");
        if (csRedial) {
            return false;
        }
        log("ignoreCSRedial, Ignore CS redial.");
        return true;
    }

    private boolean isInternationRoaming() {
        ServiceState serviceState = getPhone().getDefaultPhone().getServiceStateTracker().getServiceState();
        if (serviceState == null) {
            return false;
        }
        log("isInternation, serviceState.getVoiceRoamingType =" + serviceState.getVoiceRoamingType());
        if (3 != serviceState.getVoiceRoamingType()) {
            return false;
        }
        return true;
    }
}
