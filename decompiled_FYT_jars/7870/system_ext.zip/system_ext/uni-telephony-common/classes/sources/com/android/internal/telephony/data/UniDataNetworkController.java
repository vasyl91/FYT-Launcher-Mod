package com.android.internal.telephony.data;

import android.content.AsyncQueryHandler;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncResult;
import android.os.Looper;
import android.os.SystemProperties;
import android.telephony.PrimarySubManager;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.UniGsmCdmaPhone;
import com.android.telephony.Rlog;
import com.android.unisoc.telephony.RadioInteractor;
import com.android.unisoc.telephony.RadioInteractorListener;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniDataNetworkController extends DataNetworkController {
    private static final String ACTION_FDN_LIST_CHANGED = "android.callsettings.action.FDN_LIST_CHANGED";
    private static final String ACTION_FDN_STATUS_CHANGED = "android.callsettings.action.FDN_STATUS_CHANGED";
    private static final String AP_VERSION = "persist.radio.apversion";
    private static final int EVENT_REEVALUATE_UNSATISFIED_NETWORK_REQUESTS = 5;
    private static final String FDN_CONTENT_PATH_WITH_SUB_ID = "content://icc/fdn/subId/";
    private static final String INTENT_EXTRA_SUB_ID = "subid";
    private static final String INTENT_KEY_ICC_STATE = "ss";
    private static final String INTENT_VALUE_ICC_READY = "READY";
    private static final String PS_REJECT_SATUS = "ril.data.ps.reject";
    private static final String SUBSCRIPTION_KEY = "subscription";
    private static final int VSIM_MIFI_VERSION = 1;
    private static final int VSIM_MOBILE_VERSION = 2;
    private final String LOG_TAG;
    private boolean hasNumber;
    private boolean mFdnEnable;
    private String mFdnNum;
    private boolean mIsSuspendData;
    private boolean mLastFdnEnable;
    private final SubscriptionManager.OnSubscriptionsChangedListener mOnSubscriptionsChangeListener;
    private Phone mPhone;
    private QueryHandler mQueryHandler;
    private RadioInteractor mRadioInteractor;
    private RadioInteractorListener mRadioInteractorListener;
    private BroadcastReceiver mReceiver;
    private ContentResolver mResolver;
    private SubscriptionManager mSubscriptionManager;
    private List<DataNetwork> mUniDataNetworkList;
    private UniDataPhoneManager mUniDataPhoneManager;
    private UniDataRetryManager mUniDataRetryManager;
    private UniDataSettingsManager mUniDataSettingsManager;
    private UniGsmCdmaPhone mUniPhone;
    private static final Uri FDN_CONTENT_URI = Uri.parse("content://icc/fdn");
    private static final String[] COLUMN_NAMES = {"name", "number"};

    public UniDataNetworkController(Phone phone, Looper looper) {
        super(phone, looper);
        this.mUniDataNetworkList = new ArrayList();
        this.mIsSuspendData = false;
        this.mReceiver = new BroadcastReceiver() { // from class: com.android.internal.telephony.data.UniDataNetworkController.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                UniDataNetworkController.this.log("onReceive action=" + action);
                if (action.equals(UniDataNetworkController.ACTION_FDN_STATUS_CHANGED)) {
                    int subId = intent.getIntExtra(UniDataNetworkController.INTENT_EXTRA_SUB_ID, -1);
                    if (subId == UniDataNetworkController.this.mPhone.getSubId()) {
                        UniDataNetworkController uniDataNetworkController = UniDataNetworkController.this;
                        uniDataNetworkController.mFdnEnable = uniDataNetworkController.getIccFdnEnabled();
                        UniDataNetworkController.this.log("onFdnChanged mLastFdnEnable = " + UniDataNetworkController.this.mLastFdnEnable + ", mFdnEnable = " + UniDataNetworkController.this.mFdnEnable);
                        if (UniDataNetworkController.this.mFdnEnable != UniDataNetworkController.this.mLastFdnEnable) {
                            UniDataNetworkController uniDataNetworkController2 = UniDataNetworkController.this;
                            uniDataNetworkController2.mLastFdnEnable = uniDataNetworkController2.mFdnEnable;
                            if (UniDataNetworkController.this.mFdnEnable) {
                                UniDataNetworkController.this.queryFdnList();
                                return;
                            } else {
                                UniDataNetworkController.this.mUniDataSettingsManager.setVendorDataEnabled(true);
                                return;
                            }
                        }
                        return;
                    }
                    return;
                }
                if (action.equals(UniDataNetworkController.ACTION_FDN_LIST_CHANGED)) {
                    int subId2 = intent.getIntExtra(UniDataNetworkController.INTENT_EXTRA_SUB_ID, -1);
                    if (subId2 == UniDataNetworkController.this.mPhone.getSubId()) {
                        UniDataNetworkController.this.queryFdnList();
                    }
                }
            }
        };
        SubscriptionManager.OnSubscriptionsChangedListener onSubscriptionsChangedListener = new SubscriptionManager.OnSubscriptionsChangedListener() { // from class: com.android.internal.telephony.data.UniDataNetworkController.2
            @Override // android.telephony.SubscriptionManager.OnSubscriptionsChangedListener
            public void onSubscriptionsChanged() {
                int[] subIds = SubscriptionManager.getSubId(UniDataNetworkController.this.mPhone.getPhoneId());
                if (subIds != null && subIds.length > 0 && SubscriptionManager.isValidSubscriptionId(subIds[0])) {
                    UniDataNetworkController.this.queryFdnEnabled();
                    if (UniDataNetworkController.this.isVsimProduct() >= 1) {
                        UniDataNetworkController.this.mRadioInteractor = new RadioInteractor(UniDataNetworkController.this.mPhone.getContext());
                        UniDataNetworkController.this.mRadioInteractor.listen(UniDataNetworkController.this.mRadioInteractorListener, 131072, false);
                        UniDataNetworkController.this.mRadioInteractor.listen(UniDataNetworkController.this.mRadioInteractorListener, 262144, false);
                    }
                }
            }
        };
        this.mOnSubscriptionsChangeListener = onSubscriptionsChangedListener;
        this.mPhone = phone;
        this.mUniPhone = (UniGsmCdmaPhone) phone;
        this.LOG_TAG = "Uni-DNC-" + this.mPhone.getPhoneId();
        this.mUniDataSettingsManager = (UniDataSettingsManager) getDataSettingsManager();
        this.mUniDataRetryManager = (UniDataRetryManager) getDataRetryManager();
        log("UniDataNetworkController created.");
        this.mUniDataPhoneManager = new UniDataPhoneManager(this.mPhone, this);
        SystemProperties.set(AP_VERSION, "13");
        this.mResolver = this.mPhone.getContext().getContentResolver();
        this.mSubscriptionManager = (SubscriptionManager) this.mPhone.getContext().getSystemService("telephony_subscription_service");
        if (isFndEnableSupport()) {
            this.mSubscriptionManager.addOnSubscriptionsChangedListener(onSubscriptionsChangedListener);
            IntentFilter filter = new IntentFilter();
            filter.addAction(ACTION_FDN_STATUS_CHANGED);
            filter.addAction(ACTION_FDN_LIST_CHANGED);
            this.mPhone.getContext().registerReceiver(this.mReceiver, filter, null, this.mPhone);
            this.mQueryHandler = new QueryHandler(this.mResolver);
            this.mFdnNum = getFndNumForData();
        }
        this.mRadioInteractorListener = getRadioInteractorListener(this.mPhone.getPhoneId());
    }

    protected boolean checkVendorDataAllowed() {
        if (this.mUniDataSettingsManager.getDeepSleepState()) {
            log("not allowed - deep sleep");
            return false;
        }
        if (getPsRejectProp()) {
            log("not allowed - PS is rejected");
            return false;
        }
        if (!this.mUniDataRetryManager.getRetryClearCodeEnabled()) {
            log("not allowed - data clear code retry");
            return false;
        }
        if (isFdnEnabled()) {
            log("not allowed - FDN is enable");
            return false;
        }
        if (isSuspended() && !this.mUniPhone.isVowifiConnected(this.mPhone.getPhoneId())) {
            log("not allowed - data is suspend");
            return false;
        }
        if (isDataRestrictBySimLock()) {
            log("not allowed - not in sim lock white list");
            return false;
        }
        if (this.mUniPhone.isOtherPhoneInCall()) {
            log("not allowed - other phone is in call");
            return false;
        }
        return true;
    }

    public void suspendData(boolean suspend) {
        log("suspendData suspend: " + suspend);
        this.mIsSuspendData = suspend;
        List<DataNetwork> dataNetworkList = getDataNetworkList();
        this.mUniDataNetworkList = dataNetworkList;
        for (DataNetwork dn : dataNetworkList) {
            if (dn.isConnected()) {
                log("dn.isConnected()");
                dn.sendSuspendMessage(this.mIsSuspendData);
            }
        }
        if (!suspend) {
            log("Now is not suspend, setup Data Evaluation");
            sendMessage(obtainMessage(5, DataEvaluation.DataEvaluationReason.VENDOR_SPECIFIC));
        }
    }

    public boolean isSuspended() {
        return this.mIsSuspendData;
    }

    private boolean getPsRejectProp() {
        String rejectStatus = TelephonyManager.getTelephonyProperty(this.mPhone.getPhoneId(), PS_REJECT_SATUS, "0");
        if (!"1".equals(rejectStatus)) {
            return false;
        }
        return true;
    }

    private boolean isFndEnableSupport() {
        boolean isSupport = Resources.getSystem().getBoolean(134414361);
        log("isFndEnableSupport = " + isSupport);
        return isSupport;
    }

    private String getFndNumForData() {
        String number = Resources.getSystem().getString(135004178);
        log("getFndNumForData = " + number);
        return number;
    }

    private Uri getFdnContentUri() {
        if (SubscriptionManager.isValidSubscriptionId(this.mPhone.getSubId())) {
            return Uri.parse(FDN_CONTENT_PATH_WITH_SUB_ID + this.mPhone.getSubId());
        }
        return FDN_CONTENT_URI;
    }

    private class QueryHandler extends AsyncQueryHandler {
        public QueryHandler(ContentResolver cr) {
            super(cr);
        }

        /* JADX WARN: Code duplicated, block: B:11:0x002a  */
        @Override // android.content.AsyncQueryHandler
        protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
            UniDataNetworkController.this.hasNumber = false;
            if (cursor != null) {
                try {
                    try {
                        cursor.moveToFirst();
                        do {
                            String number = cursor.getString(1);
                            if (number.equals(UniDataNetworkController.this.mFdnNum)) {
                                UniDataNetworkController.this.hasNumber = true;
                                break;
                            }
                        } while (cursor.moveToNext());
                        if (cursor != null) {
                            cursor.close();
                        }
                    } catch (Exception e) {
                        UniDataNetworkController.this.log("Exception thrown during hasSpeciaNumber e " + e);
                        if (cursor != null) {
                            cursor.close();
                        }
                    }
                } catch (Throwable th) {
                    if (cursor != null) {
                        cursor.close();
                    }
                    throw th;
                }
            }
            UniDataNetworkController uniDataNetworkController = UniDataNetworkController.this;
            uniDataNetworkController.mFdnEnable = uniDataNetworkController.getIccFdnEnabled();
            if (UniDataNetworkController.this.mFdnEnable) {
                if (UniDataNetworkController.this.hasNumber) {
                    UniDataNetworkController.this.mUniDataSettingsManager.setVendorDataEnabled(true);
                } else {
                    UniDataNetworkController.this.mUniDataSettingsManager.setVendorDataEnabled(false);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void queryFdnEnabled() {
        boolean iccFdnEnabled = getIccFdnEnabled();
        this.mFdnEnable = iccFdnEnabled;
        if (iccFdnEnabled) {
            queryFdnList();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void queryFdnList() {
        this.mQueryHandler.startQuery(0, null, getFdnContentUri(), COLUMN_NAMES, null, null, null);
    }

    public boolean isFdnEnabled() {
        return isFndEnableSupport() && getIccFdnEnabled() && !this.hasNumber;
    }

    public boolean getIccFdnEnabled() {
        return this.mPhone.getIccCard().getIccFdnEnabled();
    }

    private boolean isDataRestrictBySimLock() {
        PrimarySubManager primarySubMgr = PrimarySubManager.from(this.mPhone.getContext());
        if (primarySubMgr != null && primarySubMgr.isDataRestrictBySimLock(this.mPhone.getPhoneId())) {
            return true;
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int isVsimProduct() {
        return SystemProperties.getInt("persist.vendor.radio.vsim.product", 0);
    }

    private RadioInteractorListener getRadioInteractorListener(int phoneId) {
        return new RadioInteractorListener(phoneId) { // from class: com.android.internal.telephony.data.UniDataNetworkController.3
            public void onNetowrkErrorCodeChangedEvent(Object obj) {
                UniDataNetworkController.this.log("onNetowrkErrorCodeChangedEvent");
                AsyncResult ar = (AsyncResult) obj;
                if (ar.exception == null && ar.result != null) {
                    int[] cause = (int[]) ar.result;
                    if (cause.length == 3) {
                        Intent intent = new Intent("android.intent.action.NW_ERROR_CODE");
                        intent.putExtra("phoneId", UniDataNetworkController.this.mPhone.getPhoneId());
                        intent.putExtra("ReasonType", cause[0]);
                        intent.putExtra("Reason", cause[1]);
                        intent.putExtra("plmn", cause[2]);
                        UniDataNetworkController.this.mPhone.getContext().sendBroadcast(intent);
                    }
                }
            }

            public void onAvailableNetworksEvent(Object object) {
                UniDataNetworkController.this.log("onAvailableNetworksEvent");
                AsyncResult ar = (AsyncResult) object;
                if (ar.exception == null && ar.result != null) {
                    String[] ret = (String[]) ar.result;
                    Intent intent = new Intent("android.intent.action.INCREMENTAL_NW_SCAN_IND");
                    intent.putExtra("phoneId", UniDataNetworkController.this.mPhone.getPhoneId());
                    intent.putExtra("incr_nw_scan_data", ret);
                    UniDataNetworkController.this.mPhone.getContext().sendBroadcast(intent);
                }
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(String s) {
        Rlog.d(this.LOG_TAG, s);
    }
}
