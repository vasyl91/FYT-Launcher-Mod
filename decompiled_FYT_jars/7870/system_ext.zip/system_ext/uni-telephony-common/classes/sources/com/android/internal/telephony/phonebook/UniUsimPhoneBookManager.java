package com.android.internal.telephony.phonebook;

import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.telephony.PhoneNumberUtils;
import android.text.TextUtils;
import android.util.SparseArray;
import android.util.SparseIntArray;
import com.android.internal.telephony.gsm.SimTlv;
import com.android.internal.telephony.uicc.IccFileHandler;
import com.android.internal.telephony.uicc.IccUtils;
import com.android.internal.telephony.uicc.UniIccConstants;
import com.android.internal.telephony.uicc.UniUsimFileHandler;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniUsimPhoneBookManager extends Handler implements UniIccConstants {
    static final int ANR_BCD_NUMBER_LENGTH = 1;
    private static final int EVENT_AAS_LOAD_DONE = 6;
    private static final int EVENT_ANR_LOAD_DONE = 10;
    private static final int EVENT_ANR_RECORD_LOAD_DONE = 20;
    public static final int EVENT_EF_CC_LOAD_DONE = 12;
    private static final int EVENT_EF_PSC_LOAD_DONE = 17;
    private static final int EVENT_EF_PUID_LOAD_DONE = 15;
    private static final int EVENT_EMAIL_LOAD_DONE = 4;
    private static final int EVENT_GAS_LOAD_DONE = 9;
    private static final int EVENT_GET_RECORDS_COUNT = 19;
    private static final int EVENT_GRP_LOAD_DONE = 8;
    private static final int EVENT_IAP_LOAD_DONE = 3;
    private static final int EVENT_LOAD_EF_PBC_RECORD_DONE = 14;
    private static final int EVENT_PBR_LOAD_DONE = 1;
    private static final int EVENT_SNE_LOAD_DONE = 7;
    private static final int EVENT_SNE_RECORD_COUNT = 21;
    private static final int EVENT_UPDATE_CC_DONE = 18;
    private static final int EVENT_UPDATE_RECORD_DONE = 13;
    private static final int EVENT_UPDATE_UID_DONE = 16;
    private static final int EVENT_USIM_ADN_LOAD_DONE = 2;
    static final int FOOTER_SIZE_BYTES = 14;
    private static final byte INVALID_BYTE = -1;
    private static final int INVALID_SFI = -1;
    private static final String TAG = "UniUsimPhoneBookManager";
    public static final int USIM_EFAAS_TAG = 199;
    private static final int USIM_EFADN_TAG = 192;
    public static final int USIM_EFANR_TAG = 196;
    private static final int USIM_EFCCP1_TAG = 203;
    public static final int USIM_EFEMAIL_TAG = 202;
    private static final int USIM_EFEXT1_TAG = 194;
    public static final int USIM_EFGAS_TAG = 200;
    public static final int USIM_EFGRP_TAG = 198;
    private static final int USIM_EFIAP_TAG = 193;
    private static final int USIM_EFPBC_TAG = 197;
    public static final int USIM_EFSNE_TAG = 195;
    private static final int USIM_EFUID_TAG = 201;
    public static final int USIM_SUBJCET_AAS = 3;
    public static final int USIM_SUBJCET_ANR = 1;
    public static final int USIM_SUBJCET_EMAIL = 0;
    public static final int USIM_SUBJCET_GRP = 2;
    public static final int USIM_SUBJCET_SNE = 4;
    public static final int USIM_TYPE1_TAG = 168;
    public static final int USIM_TYPE2_TAG = 169;
    private static final int USIM_TYPE3_TAG = 170;
    private int changedCounter;
    private ArrayList<byte[]> mAasFileRecord;
    private UniAdnRecordCache mAdnCache;
    public int[] mAdnRecordSizeArray;
    private ArrayList<byte[]> mAnrFileRecord;
    private int[] mAnrRecordSizeArray;
    private ArrayList<byte[]> mEmailFileRecord;
    private int[] mEmailRecordSizeArray;
    private IccFileHandler mFh;
    private ArrayList<byte[]> mGasFileRecord;
    private ArrayList<byte[]> mGrpFileRecord;
    private ArrayList<byte[]> mIapFileRecord;
    private Object[] mIapFileRecordArray;
    private int[] mIapRecordSizeArray;
    private ArrayList<byte[]> mPbcFileRecord;
    public HashMap<Integer, int[]> mRecordsSize;
    private ArrayList<byte[]> mSneFileRecord;
    private Object mLock = new Object();
    private boolean mEmailPresentInIap = false;
    private int mEmailTagNumberInIap = 0;
    private int mSneEfSize = 0;
    private boolean mSnePresentInIap = false;
    private int mSneTagNumberInIap = 0;
    protected int[] sneRecordSize = new int[3];
    private boolean mRefreshCache = false;
    public int mAnrFileCount = 0;
    private int mDoneAdnCount = 0;
    public int mGrpCount = 0;
    private int[] mAdnRecordSize = null;
    private boolean mAnrPresentInIap = false;
    private boolean mIsPbrFileExisting = true;
    private boolean mIsContainAdnInPbr = true;
    private AtomicInteger mPendingIapLoads = new AtomicInteger(0);
    private AtomicInteger mPendingGrpLoads = new AtomicInteger(0);
    private AtomicInteger mPendingAnrLoads = new AtomicInteger(0);
    private AtomicInteger mPendingPbcLoads = new AtomicInteger(0);
    private AtomicBoolean mIsNotify = new AtomicBoolean(false);
    private LinkedList<SubjectIndexOfAdn> mAnrInfoFromPBR = new LinkedList<>();
    private LinkedList<SubjectIndexOfAdn> mEmailInfoFromPBR = new LinkedList<>();
    private LinkedList<SubjectIndexOfAdn> mAasInfoFromPBR = new LinkedList<>();
    private LinkedList<SubjectIndexOfAdn> mSneInfoFromPBR = new LinkedList<>();
    private int mMaxPbrNum = 4;
    private ArrayList<UniAdnRecord> mPhoneBookRecords = new ArrayList<>();
    private ArrayList<PbrRecord> mPbrRecords = null;
    private Boolean mIsPbrPresent = true;
    private ArrayList<String> mGasList = new ArrayList<>();
    private ArrayList<String> mAasList = new ArrayList<>();
    private SparseArray<ArrayList<String>> mEmailsForAdnRec = new SparseArray<>();
    private SparseIntArray mSfiEfidTable = new SparseIntArray();

    private class File {
        private final int mEfid;
        private final int mIndex;
        private final int mParentTag;
        private final int mSfi;

        File(int parentTag, int efid, int sfi, int index) {
            this.mParentTag = parentTag;
            this.mEfid = efid;
            this.mSfi = sfi;
            this.mIndex = index;
        }

        public int getParentTag() {
            return this.mParentTag;
        }

        public int getEfid() {
            return this.mEfid;
        }

        public int getSfi() {
            return this.mSfi;
        }

        public int getIndex() {
            return this.mIndex;
        }
    }

    public class SubjectIndexOfAdn {
        public int adnEfid;
        public int[] efids;
        public Map<Integer, ArrayList<byte[]>> record;
        public Map<Integer, Integer> recordNumInIap;
        public int[] type;
        Object[] usedSet;

        public SubjectIndexOfAdn() {
        }
    }

    public UniUsimPhoneBookManager(IccFileHandler fh, UniAdnRecordCache cache) {
        this.mFh = fh;
        this.mAdnCache = cache;
    }

    public void reset() {
        logd("UniUsimPhoneBookManager reset");
        this.mPhoneBookRecords.clear();
        this.mGasList.clear();
        this.mIapFileRecord = null;
        this.mEmailFileRecord = null;
        this.mPbrRecords = null;
        this.mIsPbrPresent = true;
        this.mRefreshCache = false;
        this.mAnrFileRecord = null;
        this.mGrpFileRecord = null;
        this.mGasFileRecord = null;
        this.mPbcFileRecord = null;
        this.mAdnRecordSize = null;
        this.mAnrFileCount = 0;
        this.mAnrInfoFromPBR = null;
        this.mEmailInfoFromPBR = null;
        this.mAasList.clear();
        this.mEmailsForAdnRec.clear();
        this.mSfiEfidTable.clear();
    }

    public ArrayList<UniAdnRecord> loadEfFilesFromUsimEx() {
        synchronized (this.mLock) {
            if (!this.mPhoneBookRecords.isEmpty()) {
                return this.mPhoneBookRecords;
            }
            if (!this.mIsPbrPresent.booleanValue()) {
                return null;
            }
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
            ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
            if (arrayList2 != null && arrayList2.size() != 0) {
                int numRecs = this.mPbrRecords.size();
                this.mIapFileRecordArray = new Object[numRecs];
                this.mAdnRecordSizeArray = new int[numRecs];
                this.mEmailRecordSizeArray = new int[numRecs];
                this.mIapRecordSizeArray = new int[numRecs];
                this.mAnrRecordSizeArray = new int[numRecs];
                this.mDoneAdnCount = 0;
                int[] totalSize = new int[3];
                for (int i = 0; i < numRecs; i++) {
                    logd("loadEfFilesFromUsim, the current record num is " + i);
                    if (isPbrFilesSpecial(i)) {
                        this.mIsPbrFileExisting = false;
                        logd("Special pbr in this card");
                        return null;
                    }
                    int offSet = totalSize[2];
                    int[] size = readAdnFileSizeAndWait(i);
                    if (size != null) {
                        totalSize[0] = size[0];
                        totalSize[1] = totalSize[1] + size[1];
                        totalSize[2] = totalSize[2] + size[2];
                    } else if (i == 0) {
                        logd("First pbr special in this card, adn size is null");
                        return null;
                    }
                    readAdnFileAndWait(i);
                    if (!this.mIsContainAdnInPbr) {
                        logd("First pbr special in this card, adn record abnormal");
                        return null;
                    }
                    readIapFile(i, offSet);
                    readEmailFileAndWait(i);
                    if (UniPhonebookUtils.isSupportOrange()) {
                        readSneFileAndWait(i);
                    }
                    readAnrFileAndWait(i, offSet);
                    readGrpFileAndWait(i, offSet);
                    updateAdnRecord(i);
                }
                CheckRepeatType2Ef();
                updateAdnRecordNum();
                updatePbcAndCc();
                return this.mPhoneBookRecords;
            }
            this.mIsPbrFileExisting = false;
            loge("Error: Pbr file is empty");
            return null;
        }
    }

    private void readPbrFileAndWait() {
        this.mFh.loadEFLinearFixedAll(20272, obtainMessage(1));
        try {
            this.mLock.wait();
        } catch (InterruptedException e) {
            loge("Interrupted Exception in readAdnFileAndWait");
        }
    }

    private void readEmailFileAndWait(int recNum) {
        File id;
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(recNum).mFileIds;
            if (files == null || files.size() == 0) {
                logd("email file is null or size is 0");
                return;
            }
            File email = files.get(USIM_EFEMAIL_TAG);
            if (email != null) {
                int emailEfid = email.getEfid();
                SubjectIndexOfAdn records = getSubjectIndex(0, recNum);
                if (records == null) {
                    logd("readEmailFileAndWait  records is null");
                    return;
                }
                if (this.mEmailPresentInIap && this.mIapFileRecord == null) {
                    loge("Error: IAP file is empty");
                    setSubjectIndex(0, recNum, null);
                    return;
                }
                for (int i = 0; i < recNum; i++) {
                    ArrayList<PbrRecord> arrayList3 = this.mPbrRecords;
                    if (arrayList3 != null && arrayList3.get(i) != null) {
                        try {
                            SparseArray<File> previousFileIds = this.mPbrRecords.get(i).mFileIds;
                            if (previousFileIds != null && (id = previousFileIds.get(USIM_EFEMAIL_TAG)) != null && id.getEfid() == emailEfid) {
                                logd("Skipped this EF_EMAIL which was loaded earlier");
                                return;
                            }
                        } catch (IndexOutOfBoundsException e) {
                            loge("readEmailFileAndWait IndexOutOfBoundsException");
                        }
                    } else {
                        return;
                    }
                }
                this.mFh.loadEFLinearFixedAll(emailEfid, obtainMessage(4));
                try {
                    this.mLock.wait();
                } catch (InterruptedException e2) {
                    loge("Interrupted Exception in readEmailFileAndWait");
                }
                if (this.mEmailFileRecord == null) {
                    loge("Error: Email file is empty");
                    setSubjectIndex(0, recNum, null);
                    return;
                }
                records.record = new HashMap();
                records.record.put(Integer.valueOf(emailEfid), this.mEmailFileRecord);
                setSubjectIndex(0, recNum, records);
                setSubjectUsedNum(0, recNum);
                if (email.getParentTag() == 169 && this.mIapFileRecord != null) {
                    buildType2EmailList(recNum, getSubjectIndex(0, recNum), emailEfid);
                } else {
                    buildType1EmailList(recNum);
                }
                this.mEmailFileRecord = null;
            }
        } catch (IndexOutOfBoundsException e3) {
            loge("readEmailFileAndWait IndexOutOfBoundsException");
        }
    }

    private void buildType1EmailList(int recNum) {
        int adnEfid;
        ArrayList<PbrRecord> arrayList = this.mPbrRecords;
        if (arrayList == null || arrayList.get(recNum) == null) {
            return;
        }
        try {
            int numRecs = this.mPbrRecords.get(recNum).mMasterFileRecordNum;
            for (int i = 0; i < numRecs; i++) {
                try {
                    ArrayList<byte[]> arrayList2 = this.mEmailFileRecord;
                    if (arrayList2 != null) {
                        byte[] emailRec = arrayList2.get(i);
                        if (emailRec.length < 2) {
                            logd("buildType1EmailList, emailRec is abnormal");
                        } else {
                            int sfi = emailRec[emailRec.length - 2];
                            int adnRecId = emailRec[emailRec.length + INVALID_SFI];
                            String email = readEmailRecord(i);
                            if (email != null && !email.equals("")) {
                                if (sfi == INVALID_SFI || this.mSfiEfidTable.get(sfi) == 0) {
                                    File file = (File) this.mPbrRecords.get(recNum).mFileIds.get(USIM_EFADN_TAG);
                                    if (file != null) {
                                        adnEfid = file.getEfid();
                                    }
                                } else {
                                    adnEfid = this.mSfiEfidTable.get(sfi);
                                }
                                int index = ((65535 & adnEfid) << 8) | ((adnRecId + INVALID_SFI) & 255);
                                ArrayList<String> emailList = this.mEmailsForAdnRec.get(index);
                                if (emailList == null) {
                                    emailList = new ArrayList<>();
                                }
                                logd("Adding email #" + i + " list to index 0x" + Integer.toHexString(index).toUpperCase());
                                emailList.add(email);
                                this.mEmailsForAdnRec.put(index, emailList);
                            }
                        }
                    } else {
                        logd("buildType1EmailList, mEmailFileRecord is null");
                        return;
                    }
                } catch (IndexOutOfBoundsException e) {
                    loge("Error: Improper ICC card: No email record for ADN, continuing");
                    return;
                }
            }
        } catch (IndexOutOfBoundsException e2) {
            loge("buildType1EmailList IndexOutOfBoundsException, recNum is " + recNum);
        }
    }

    /* JADX WARN: Code duplicated, block: B:51:0x0192  */
    private boolean buildType2EmailList(int recNum, SubjectIndexOfAdn emailInfo, int efid) {
        ArrayList<PbrRecord> arrayList = this.mPbrRecords;
        if (arrayList == null || arrayList.get(recNum) == null) {
            return false;
        }
        try {
            int numRecs = this.mPbrRecords.get(recNum).mMasterFileRecordNum;
            File adnFile = (File) this.mPbrRecords.get(recNum).mFileIds.get(USIM_EFADN_TAG);
            if (adnFile == null) {
                loge("Error: Improper ICC card: EF_ADN does not exist in PBR files");
                return false;
            }
            int adnEfid = adnFile.getEfid();
            this.mIapFileRecordArray[recNum] = this.mIapFileRecord;
            for (int i = 0; i < numRecs; i++) {
                if (emailInfo != null) {
                    if (emailInfo.efids == null || emailInfo.efids.length == 0) {
                        logd("getEmail emailInfo.efids == null || emailInfo.efids.length == 0");
                    } else {
                        try {
                            ArrayList<byte[]> arrayList2 = this.mIapFileRecord;
                            if (arrayList2 == null) {
                                try {
                                    loge("Error: mIapFileRecord is null");
                                    return false;
                                } catch (IndexOutOfBoundsException e) {
                                }
                            } else {
                                byte[] record = arrayList2.get(i);
                                int emailRecId = record[((File) this.mPbrRecords.get(recNum).mFileIds.get(USIM_EFEMAIL_TAG)).getIndex()];
                                int emailIndex = getUsedNumSetIndex(efid, emailInfo);
                                if (emailIndex != INVALID_SFI) {
                                    this.mEmailTagNumberInIap = emailInfo.recordNumInIap.get(Integer.valueOf(efid)).intValue();
                                    ArrayList<byte[]> arrayList3 = emailInfo.record.get(Integer.valueOf(efid));
                                    this.mEmailFileRecord = arrayList3;
                                    if (arrayList3 != null) {
                                        int recId = 255;
                                        try {
                                            recId = record[this.mEmailTagNumberInIap] & INVALID_BYTE;
                                        } catch (ArrayIndexOutOfBoundsException ex) {
                                            logd("ex :" + ex);
                                        }
                                        int recId2 = recId == 255 ? INVALID_SFI : recId;
                                        String email = readEmailRecord(emailRecId + INVALID_SFI);
                                        if (recId2 != INVALID_SFI) {
                                            if (TextUtils.isEmpty(email)) {
                                                setIapFileRecord(recNum, i, INVALID_BYTE, this.mEmailTagNumberInIap);
                                            } else {
                                                Set<Integer> set = (Set) emailInfo.usedSet[emailIndex];
                                                log("getType2Email size(0) = " + set.size() + ", emailIndex = " + emailIndex);
                                                set.add(new Integer(recId2));
                                                emailInfo.usedSet[emailIndex] = set;
                                                log("getType2Email size(1) = " + set.size());
                                                setSubjectIndex(0, recNum, emailInfo);
                                                if (email == null) {
                                                }
                                            }
                                        } else if (email == null && !email.equals("")) {
                                            int index = ((65535 & adnEfid) << 8) | (i & 255);
                                            ArrayList<String> emailList = this.mEmailsForAdnRec.get(index);
                                            if (emailList == null) {
                                                emailList = new ArrayList<>();
                                            }
                                            emailList.add(email);
                                            log("Adding email list to index 0x" + Integer.toHexString(index).toUpperCase());
                                            this.mEmailsForAdnRec.put(index, emailList);
                                        }
                                    }
                                }
                            }
                        } catch (IndexOutOfBoundsException e2) {
                        }
                        loge("Error: Improper ICC card: Corrupted EF_IAP");
                    }
                }
            }
            return true;
        } catch (IndexOutOfBoundsException e3) {
            loge("buildType2EmailList IndexOutOfBoundsException");
            return false;
        }
    }

    private void readIapFileAndWait(int efid) {
        this.mFh.loadEFLinearFixedAll(efid, obtainMessage(3));
        try {
            this.mLock.wait();
        } catch (InterruptedException e) {
            loge("Interrupted Exception in readIapFileAndWait");
        }
    }

    private String readEmailRecord(int recNum) {
        ArrayList<byte[]> arrayList = this.mEmailFileRecord;
        if (arrayList == null) {
            return null;
        }
        try {
            byte[] emailRec = arrayList.get(recNum);
            if (emailRec.length < 2) {
                logd("readEmailRecord, emailRec is abnormal");
                return null;
            }
            String email = IccUtils.adnStringFieldToString(emailRec, 0, emailRec.length - 2);
            return email;
        } catch (IndexOutOfBoundsException e) {
            return null;
        }
    }

    private void readAdnFileAndWait(int recNum) {
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            this.mIsPbrFileExisting = false;
            logd("Pbr file is empty, and set mIsPbrFileExisting false");
            return;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(recNum).mFileIds;
            if (files == null || files.size() == 0) {
                if (recNum == 0) {
                    this.mIsContainAdnInPbr = false;
                    return;
                }
                return;
            }
            int extEf = 0;
            if (files.get(USIM_EFEXT1_TAG) != null) {
                extEf = files.get(USIM_EFEXT1_TAG).getEfid();
            }
            if (files.get(USIM_EFADN_TAG) != null) {
                logd("readAdnFileAndWait: efid = " + files.get(USIM_EFADN_TAG).getEfid() + ", extEf =" + extEf);
                int previousSize = this.mPhoneBookRecords.size();
                this.mAdnCache.requestLoadAllAdnLike(files.get(USIM_EFADN_TAG).getEfid(), extEf, obtainMessage(2));
                try {
                    this.mLock.wait();
                } catch (InterruptedException e) {
                    loge("Interrupted Exception in readAdnFileAndWait");
                }
                if (recNum == 0 && this.mPhoneBookRecords.size() == previousSize) {
                    this.mIsContainAdnInPbr = false;
                }
                ArrayList<PbrRecord> arrayList3 = this.mPbrRecords;
                if (arrayList3 != null && arrayList3.get(recNum) != null) {
                    this.mPbrRecords.get(recNum).mMasterFileRecordNum = this.mPhoneBookRecords.size() - previousSize;
                    return;
                }
                return;
            }
            if (recNum == 0) {
                this.mIsContainAdnInPbr = false;
            }
        } catch (IndexOutOfBoundsException e2) {
            loge("readAdnFileAndWait IndexOutOfBoundsException");
        }
    }

    private void createPbrFile(ArrayList<byte[]> records) {
        if (records == null) {
            this.mPbrRecords = null;
            this.mIsPbrPresent = false;
            return;
        }
        this.mPbrRecords = new ArrayList<>();
        for (int i = 0; i < records.size() && i < this.mMaxPbrNum; i++) {
            if (records.get(i)[0] != INVALID_SFI) {
                this.mPbrRecords.add(new PbrRecord(records.get(i)));
            }
        }
        ArrayList<PbrRecord> extPbrRecords = new ArrayList<>();
        ArrayList<Integer> adnEfids = new ArrayList<>();
        for (PbrRecord record : this.mPbrRecords) {
            File file = (File) record.mFileIds.get(USIM_EFADN_TAG);
            if (file != null) {
                int efid = file.getEfid();
                if (adnEfids.contains(Integer.valueOf(efid))) {
                    extPbrRecords.add(record);
                } else {
                    adnEfids.add(Integer.valueOf(efid));
                    int sfi = file.getSfi();
                    if (sfi != INVALID_SFI) {
                        logd("sfi = " + sfi + ", efid = " + efid);
                        this.mSfiEfidTable.put(sfi, efid);
                    }
                }
            }
        }
        logd("mAdnEfids: " + adnEfids);
        if (extPbrRecords.size() > 0) {
            logd("extPbrRecords.size: " + extPbrRecords.size());
            this.mPbrRecords.removeAll(extPbrRecords);
        }
    }

    /* JADX WARN: Bottom block not found for handler: all -> 0x0330 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:287:? -> B:97:0x02e1). Please report as a decompilation issue!!! */
    @Override // android.os.Handler
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void handleMessage(Message msg) throws Throwable {
        ArrayList<byte[]> arrayList;
        ArrayList<byte[]> arrayList2;
        int puid;
        switch (msg.what) {
            case 1:
                AsyncResult ar = (AsyncResult) msg.obj;
                if (ar.exception == null) {
                    createPbrFile((ArrayList) ar.result);
                }
                synchronized (this.mLock) {
                    this.mLock.notify();
                    break;
                }
                return;
            case 2:
                AsyncResult ar2 = (AsyncResult) msg.obj;
                int size = 0;
                if (ar2 != null) {
                    if (((ArrayList) ar2.result) != null) {
                        size = ((ArrayList) ar2.result).size();
                    }
                    logd("EVENT_USIM_ADN_LOAD_DONE size is " + size + ", exception " + ar2.exception);
                    if (size > 0 && ar2.exception == null) {
                        this.mPhoneBookRecords.addAll((ArrayList) ar2.result);
                    }
                }
                synchronized (this.mLock) {
                    this.mLock.notify();
                    break;
                }
                return;
            case 3:
                AsyncResult ar3 = (AsyncResult) msg.obj;
                int index = msg.arg1;
                if (ar3.exception == null && (arrayList = this.mIapFileRecord) != null) {
                    arrayList.set(index, (byte[]) ar3.result);
                    logd("Loading USIM IAP records done, index is " + index);
                }
                this.mPendingIapLoads.decrementAndGet();
                if (this.mPendingIapLoads.get() == 0 && this.mIsNotify.get()) {
                    this.mIsNotify.set(false);
                    synchronized (this.mLock) {
                        this.mLock.notify();
                        break;
                    }
                    return;
                }
                return;
            case 4:
                AsyncResult ar4 = (AsyncResult) msg.obj;
                if (ar4.exception == null) {
                    if (this.mEmailFileRecord == null) {
                        this.mEmailFileRecord = new ArrayList<>();
                    }
                    this.mEmailFileRecord.addAll((ArrayList) ar4.result);
                    logd("Loading USIM Email records done, size is " + this.mEmailFileRecord.size());
                }
                synchronized (this.mLock) {
                    this.mLock.notify();
                    break;
                }
                return;
            case 5:
            case 11:
            default:
                return;
            case 6:
                logd("Loading USIM AAS records done");
                AsyncResult ar5 = (AsyncResult) msg.obj;
                if (ar5.exception == null) {
                    if (this.mAasFileRecord == null) {
                        this.mAasFileRecord = new ArrayList<>();
                    }
                    this.mAasFileRecord.clear();
                    this.mAasFileRecord.addAll((ArrayList) ar5.result);
                    logd("mAasFileRecord.size() is " + this.mAasFileRecord.size());
                }
                synchronized (this.mLock) {
                    this.mLock.notify();
                    break;
                }
                return;
            case 7:
                logd("Loading USIM SNE records done");
                AsyncResult ar6 = (AsyncResult) msg.obj;
                if (ar6.exception == null) {
                    if (this.mSneFileRecord == null) {
                        this.mSneFileRecord = new ArrayList<>();
                    }
                    this.mSneFileRecord.clear();
                    this.mSneFileRecord.addAll((ArrayList) ar6.result);
                    logd("mSneFileRecord.size() is " + this.mSneFileRecord.size());
                }
                synchronized (this.mLock) {
                    this.mLock.notify();
                    break;
                }
                return;
            case 8:
                AsyncResult ar7 = (AsyncResult) msg.obj;
                if (ar7.exception == null) {
                    if (this.mGrpFileRecord == null) {
                        this.mGrpFileRecord = new ArrayList<>();
                    }
                    int i = msg.arg2 + msg.arg1;
                    logd("Loading USIM Grp record done, i is " + i);
                    try {
                        this.mGrpFileRecord.set(i, (byte[]) ar7.result);
                    } catch (IndexOutOfBoundsException e) {
                        logd("IndexOutOfBoundsException readGrpFileAndWait");
                    }
                    break;
                }
                this.mPendingGrpLoads.decrementAndGet();
                if (this.mPendingGrpLoads.get() == 0 && this.mIsNotify.get()) {
                    this.mIsNotify.set(false);
                    synchronized (this.mLock) {
                        this.mLock.notify();
                        break;
                    }
                    logd("Loading USIM Grp records done notify");
                    return;
                }
                return;
            case 9:
                logd("Loading USIM Gas records done, mGasFileRecord: " + this.mGasFileRecord);
                AsyncResult ar8 = (AsyncResult) msg.obj;
                if (ar8.exception == null) {
                    ArrayList<byte[]> arrayList3 = new ArrayList<>();
                    this.mGasFileRecord = arrayList3;
                    arrayList3.addAll((ArrayList) ar8.result);
                    logd("Loading USIM Gas records done, size is " + this.mGasFileRecord.size());
                }
                synchronized (this.mLock) {
                    this.mLock.notify();
                    break;
                }
                return;
            case 10:
                AsyncResult ar9 = (AsyncResult) msg.obj;
                if (ar9.exception == null) {
                    if (this.mAnrFileRecord == null) {
                        this.mAnrFileRecord = new ArrayList<>();
                    }
                    this.mAnrFileRecord.addAll((ArrayList) ar9.result);
                }
                synchronized (this.mLock) {
                    this.mLock.notify();
                    break;
                }
                return;
            case 12:
                AsyncResult ar10 = (AsyncResult) msg.obj;
                byte[] data = (byte[]) ar10.result;
                int temp = msg.arg1;
                int isUpdateUid = msg.arg2;
                if (ar10.exception != null) {
                    logd("EVENT_EF_CC_LOAD_DONE has exception " + ar10.exception);
                    return;
                }
                logd("EVENT_EF_CC_LOAD_DONE data " + IccUtils.bytesToHexString(data));
                if (data == null) {
                    logd("EVENT_EF_CC_LOAD_DONE data is null");
                    return;
                }
                byte[] counter = new byte[2];
                int cc = (65280 & (data[0] << 8)) | (data[1] & INVALID_BYTE);
                this.changedCounter = cc;
                int cc2 = cc + temp;
                if (cc2 > 65535) {
                    counter[0] = 0;
                    counter[1] = 1;
                } else {
                    counter[1] = (byte) (cc2 & 255);
                    counter[0] = (byte) ((cc2 >> 8) & 255);
                }
                logd("EVENT_EF_CC_LOAD_DONE counter " + IccUtils.bytesToHexString(counter));
                if (isUpdateUid == 1) {
                    this.mFh.updateEFTransparent(UniIccConstants.EF_CC, counter, obtainMessage(18));
                    return;
                } else {
                    this.mFh.updateEFTransparent(UniIccConstants.EF_CC, counter, obtainMessage(13));
                    return;
                }
            case 13:
                AsyncResult ar11 = (AsyncResult) msg.obj;
                if (ar11.exception == null) {
                    logd("update_record_success");
                    return;
                }
                throw new RuntimeException("update EF records failed", ar11.exception);
            case 14:
                logd("Loading EVENT_LOAD_EF_PBC_RECORD_DONE, msg.arg1 = " + msg.arg1);
                AsyncResult ar12 = (AsyncResult) msg.obj;
                if (ar12.exception != null || (arrayList2 = this.mPbcFileRecord) == null) {
                    logd("Loading USIM PBC records failed");
                } else {
                    arrayList2.set(msg.arg1, (byte[]) ar12.result);
                    logd("Loading USIM PBC record done");
                }
                this.mPendingPbcLoads.decrementAndGet();
                if (this.mPendingPbcLoads.get() == 0 && this.mIsNotify.get()) {
                    this.mIsNotify.set(false);
                    synchronized (this.mLock) {
                        this.mLock.notify();
                        break;
                    }
                    logd("Loading USIM Pbc records done notify");
                    return;
                }
                return;
            case 15:
                AsyncResult ar13 = (AsyncResult) msg.obj;
                byte[] data2 = (byte[]) ar13.result;
                int recNum = msg.arg1;
                int recordNum = msg.arg2;
                if (ar13.exception != null) {
                    logd("EVENT_EF_PUID_LOAD_DONE has exception " + ar13.exception);
                    return;
                }
                byte[] uidData = new byte[2];
                byte[] newPuid = new byte[2];
                int puid2 = ((data2[0] << 8) & 65280) | (data2[1] & INVALID_BYTE);
                int i2 = this.changedCounter;
                int i3 = 16;
                int i4 = USIM_EFUID_TAG;
                if (i2 == 65535 || puid2 == 65535) {
                    synchronized (this.mLock) {
                        try {
                            this.mFh.loadEFTransparent(UniIccConstants.EF_PSC, 4, obtainMessage(17));
                        } catch (Throwable th) {
                            th = th;
                            while (true) {
                                throw th;
                            }
                        }
                        break;
                    }
                    int uid = 0;
                    int[] adnRecordSizeArray = getAdnRecordSizeArray();
                    int num = 0;
                    while (num < getNumRecs()) {
                        int i5 = 0;
                        while (i5 < adnRecordSizeArray[num]) {
                            int adnRecNum = i5;
                            for (int j = 0; j < num; j++) {
                                adnRecNum += adnRecordSizeArray[j];
                            }
                            if (adnRecNum >= this.mPhoneBookRecords.size()) {
                                puid = 16;
                            } else if (TextUtils.isEmpty(this.mPhoneBookRecords.get(adnRecNum).getAlphaTag()) && TextUtils.isEmpty(this.mPhoneBookRecords.get(adnRecNum).getNumber())) {
                                puid = 16;
                            } else {
                                int uid2 = uid + 1;
                                byte[] uidData2 = UniPhonebookUtils.intToBytes(uid2, 2);
                                synchronized (this.mLock) {
                                    try {
                                        puid = 16;
                                        try {
                                            this.mFh.updateEFLinearFixed(getEfIdByTag(num, i4), i5 + 1, uidData2, (String) null, obtainMessage(16, Integer.valueOf(INVALID_SFI)));
                                        } catch (Throwable th2) {
                                            th = th2;
                                            throw th;
                                        }
                                    } catch (Throwable th3) {
                                        th = th3;
                                        throw th;
                                    }
                                }
                                uid = uid2;
                            }
                            i5++;
                            i3 = puid;
                            puid2 = puid2;
                            i4 = USIM_EFUID_TAG;
                        }
                        num++;
                        puid2 = puid2;
                        i4 = USIM_EFUID_TAG;
                    }
                    byte[] newPuid2 = UniPhonebookUtils.intToBytes(uid, 2);
                    logd("update puid " + uid);
                    this.mFh.updateEFTransparent(UniIccConstants.EF_PUID, newPuid2, obtainMessage(13));
                    return;
                }
                uidData[1] = (byte) ((puid2 + 1) & 255);
                uidData[0] = (byte) (((puid2 + 1) >> 8) & 255);
                newPuid[0] = uidData[0];
                newPuid[1] = uidData[1];
                logd("updateEFPuid newPuid " + IccUtils.bytesToHexString(newPuid));
                synchronized (this.mLock) {
                    this.mFh.updateEFLinearFixed(getEfIdByTag(recNum, USIM_EFUID_TAG), recordNum, uidData, (String) null, obtainMessage(16, Integer.valueOf(puid2 + 1)));
                    break;
                }
                return;
            case 16:
                int puid1 = ((Integer) ((AsyncResult) msg.obj).userObj).intValue();
                logd("EVENT_UPDATE_UID_DONE newPuid " + puid1);
                if (puid1 != INVALID_SFI) {
                    this.mFh.updateEFTransparent(UniIccConstants.EF_PUID, UniPhonebookUtils.intToBytes(puid1, 2), obtainMessage(13));
                    return;
                }
                return;
            case 17:
                AsyncResult ar14 = (AsyncResult) msg.obj;
                byte[] data3 = (byte[]) ar14.result;
                if (ar14.exception != null) {
                    logd("EVENT_EF_PSC_LOAD_DONE has exception " + ar14.exception);
                    return;
                }
                logd("EVENT_EF_PSC_LOAD_DONE data " + IccUtils.bytesToHexString(data3));
                byte[] psc = new byte[4];
                int oldPsc = UniPhonebookUtils.bytesToInt(data3);
                if (oldPsc != INVALID_SFI) {
                    if (oldPsc == INVALID_SFI) {
                        psc = UniPhonebookUtils.intToBytes(1, 4);
                    } else {
                        psc = UniPhonebookUtils.intToBytes(oldPsc + 1, 4);
                    }
                }
                logd("update psc data " + IccUtils.bytesToHexString(psc));
                this.mFh.updateEFTransparent(UniIccConstants.EF_PSC, psc, obtainMessage(13));
                return;
            case 18:
                this.mFh.loadEFTransparent(UniIccConstants.EF_PUID, 2, obtainMessage(15));
                return;
            case EVENT_GET_RECORDS_COUNT /* 19 */:
                logd("Loading EVENT_GET_RECORDS_COUNT, Efid is " + msg.arg1);
                AsyncResult ar15 = (AsyncResult) msg.obj;
                synchronized (this.mLock) {
                    if (ar15.exception != null) {
                        logd("get EF record size failed, " + ar15.exception);
                    } else {
                        int[] recordSize = (int[]) ar15.result;
                        logd("EVENT_GET_RECORDS_COUNT, Size is " + Arrays.toString(recordSize));
                        if (this.mRecordsSize == null) {
                            this.mRecordsSize = new HashMap<>();
                        }
                        this.mRecordsSize.put(Integer.valueOf(msg.arg1), recordSize);
                    }
                    this.mLock.notify();
                    break;
                }
                return;
            case EVENT_ANR_RECORD_LOAD_DONE /* 20 */:
                AsyncResult ar16 = (AsyncResult) msg.obj;
                if (ar16.exception == null) {
                    logd("Loading USIM ANR record done, index is " + msg.arg1);
                    ArrayList<byte[]> arrayList4 = this.mAnrFileRecord;
                    if (arrayList4 != null) {
                        arrayList4.set(msg.arg1, (byte[]) ar16.result);
                    }
                }
                this.mPendingAnrLoads.decrementAndGet();
                if (this.mPendingAnrLoads.get() == 0 && this.mIsNotify.get()) {
                    this.mIsNotify.set(false);
                    synchronized (this.mLock) {
                        this.mLock.notify();
                        break;
                    }
                    logd("Loading USIM ANR records done notify");
                    return;
                }
                return;
        }
    }

    private class PbrRecord {
        private SparseArray<File> mFileIds = new SparseArray<>();
        private int mMasterFileRecordNum;

        PbrRecord(byte[] record) {
            if (IccUtils.bytesToHexString(record).startsWith("ffff")) {
                return;
            }
            SimTlv recTlv = new SimTlv(record, 0, record.length);
            parseTag(recTlv);
        }

        void parseTag(SimTlv tlv) {
            SubjectIndexOfAdn sneInfo;
            ArrayList<Integer> sneType;
            ArrayList<Integer> sneEfs;
            SubjectIndexOfAdn aasInfo;
            ArrayList<Integer> aasType;
            ArrayList<Integer> aasEfs;
            PbrRecord pbrRecord;
            ArrayList<Integer> emailEfs;
            SubjectIndexOfAdn anrInfo;
            SubjectIndexOfAdn aasInfo2;
            SubjectIndexOfAdn sneInfo2;
            ArrayList<Integer> sneEfs2 = new ArrayList<>();
            ArrayList<Integer> anrEfs = new ArrayList<>();
            ArrayList<Integer> aasType2 = new ArrayList<>();
            ArrayList<Integer> aasEfs2 = new ArrayList<>();
            new HashMap();
            SubjectIndexOfAdn sneInfo3 = UniUsimPhoneBookManager.this.new SubjectIndexOfAdn();
            sneInfo3.recordNumInIap = new HashMap();
            SubjectIndexOfAdn anrInfo2 = UniUsimPhoneBookManager.this.new SubjectIndexOfAdn();
            anrInfo2.recordNumInIap = new HashMap();
            ArrayList<Integer> anrEfs2 = new ArrayList<>();
            ArrayList<Integer> aasType3 = new ArrayList<>();
            SubjectIndexOfAdn anrInfo3 = UniUsimPhoneBookManager.this.new SubjectIndexOfAdn();
            anrInfo3.recordNumInIap = new HashMap();
            ArrayList<Integer> sneEfs3 = new ArrayList<>();
            ArrayList<Integer> emailType = new ArrayList<>();
            SubjectIndexOfAdn sneInfo4 = UniUsimPhoneBookManager.this.new SubjectIndexOfAdn();
            sneInfo4.recordNumInIap = new HashMap();
            while (true) {
                int tag = tlv.getTag();
                switch (tag) {
                    case UniUsimPhoneBookManager.USIM_TYPE1_TAG /* 168 */:
                    case UniUsimPhoneBookManager.USIM_TYPE2_TAG /* 169 */:
                    case UniUsimPhoneBookManager.USIM_TYPE3_TAG /* 170 */:
                        byte[] data = tlv.getData();
                        SimTlv tlvEfSfi = new SimTlv(data, 0, data.length);
                        sneInfo = sneInfo4;
                        sneType = emailType;
                        sneEfs = sneEfs3;
                        aasInfo = anrInfo3;
                        aasType = aasType3;
                        aasEfs = anrEfs2;
                        parseEfAndSFI(tlvEfSfi, tag, sneInfo3, anrInfo2, sneEfs2, anrEfs, aasType2, aasEfs2, aasInfo, aasEfs, aasType, sneInfo, sneEfs, sneType);
                        break;
                    default:
                        sneInfo = sneInfo4;
                        sneType = emailType;
                        sneEfs = sneEfs3;
                        aasInfo = anrInfo3;
                        aasType = aasType3;
                        aasEfs = anrEfs2;
                        break;
                }
                if (!tlv.nextObject()) {
                    if (sneEfs2.size() <= 0) {
                        pbrRecord = this;
                        emailEfs = sneEfs2;
                    } else {
                        sneInfo3.efids = new int[sneEfs2.size()];
                        sneInfo3.type = new int[sneEfs2.size()];
                        for (int i = 0; i < sneEfs2.size(); i++) {
                            ArrayList<Integer> emailEfs2 = sneEfs2;
                            sneInfo3.efids[i] = emailEfs2.get(i).intValue();
                            ArrayList<Integer> emailType2 = aasType2;
                            sneInfo3.type[i] = emailType2.get(i).intValue();
                        }
                        ArrayList<Integer> emailType3 = aasType2;
                        emailEfs = sneEfs2;
                        pbrRecord = this;
                        UniUsimPhoneBookManager.this.logd("parseTag email ef = " + emailEfs + ", types = " + emailType3);
                    }
                    if (anrEfs.size() <= 0) {
                        anrInfo = anrInfo2;
                    } else {
                        anrInfo = anrInfo2;
                        anrInfo.efids = new int[anrEfs.size()];
                        anrInfo.type = new int[anrEfs.size()];
                        for (int i2 = 0; i2 < anrEfs.size(); i2++) {
                            anrInfo.efids[i2] = anrEfs.get(i2).intValue();
                            ArrayList<Integer> anrType = aasEfs2;
                            anrInfo.type[i2] = anrType.get(i2).intValue();
                        }
                        ArrayList<Integer> anrType2 = aasEfs2;
                        UniUsimPhoneBookManager.this.logd("parseTag anr ef = " + anrEfs + ", types = " + anrType2);
                    }
                    if (aasEfs.size() <= 0) {
                        aasInfo2 = aasInfo;
                    } else {
                        aasInfo2 = aasInfo;
                        aasInfo2.efids = new int[aasEfs.size()];
                        aasInfo2.type = new int[aasEfs.size()];
                        for (int i3 = 0; i3 < aasEfs.size(); i3++) {
                            aasInfo2.efids[i3] = aasEfs.get(i3).intValue();
                            aasInfo2.type[i3] = aasType.get(i3).intValue();
                        }
                        UniUsimPhoneBookManager.this.logd("parseTag aas ef = " + aasEfs + ", types = " + aasType);
                    }
                    if (sneEfs.size() > 0) {
                        UniUsimPhoneBookManager.this.mSneEfSize = sneEfs.size();
                        sneInfo2 = sneInfo;
                        sneInfo2.efids = new int[sneEfs.size()];
                        sneInfo2.type = new int[sneEfs.size()];
                        for (int i4 = 0; i4 < sneEfs.size(); i4++) {
                            sneInfo2.efids[i4] = sneEfs.get(i4).intValue();
                            sneInfo2.type[i4] = sneType.get(i4).intValue();
                        }
                        UniUsimPhoneBookManager.this.logd("parseTag sne ef = " + sneEfs + ", types = " + sneType);
                    } else {
                        sneInfo2 = sneInfo;
                    }
                    if (UniUsimPhoneBookManager.this.mPhoneBookRecords != null && UniUsimPhoneBookManager.this.mPhoneBookRecords.isEmpty()) {
                        if (UniUsimPhoneBookManager.this.mAnrInfoFromPBR != null) {
                            UniUsimPhoneBookManager.this.mAnrInfoFromPBR.add(anrInfo);
                        }
                        if (UniUsimPhoneBookManager.this.mEmailInfoFromPBR != null) {
                            UniUsimPhoneBookManager.this.mEmailInfoFromPBR.add(sneInfo3);
                        }
                        if (UniPhonebookUtils.isSupportOrange() && UniUsimPhoneBookManager.this.mAasInfoFromPBR != null) {
                            UniUsimPhoneBookManager.this.mAasInfoFromPBR.add(aasInfo2);
                        }
                        if (UniPhonebookUtils.isSupportOrange() && UniUsimPhoneBookManager.this.mSneInfoFromPBR != null) {
                            UniUsimPhoneBookManager.this.mSneInfoFromPBR.add(sneInfo2);
                            UniUsimPhoneBookManager.this.logd("mSneInfoFromPBR.size() = " + UniUsimPhoneBookManager.this.mSneInfoFromPBR.size());
                            return;
                        }
                        return;
                    }
                    return;
                }
                SubjectIndexOfAdn emailInfo = sneInfo3;
                SubjectIndexOfAdn anrInfo4 = anrInfo2;
                ArrayList<Integer> anrType3 = aasEfs2;
                ArrayList<Integer> emailType4 = aasType2;
                anrEfs = anrEfs;
                sneInfo4 = sneInfo;
                anrEfs2 = aasEfs;
                sneInfo3 = emailInfo;
                aasEfs2 = anrType3;
                sneEfs3 = sneEfs;
                sneEfs2 = sneEfs2;
                anrInfo2 = anrInfo4;
                anrInfo3 = aasInfo;
                aasType3 = aasType;
                aasType2 = emailType4;
                emailType = sneType;
            }
        }

        void parseEfAndSFI(SimTlv tlv, int parentTag, SubjectIndexOfAdn emailInfo, SubjectIndexOfAdn anrInfo, ArrayList<Integer> emailEFS, ArrayList<Integer> anrEFS, ArrayList<Integer> emailTypes, ArrayList<Integer> anrTypes, SubjectIndexOfAdn aasInfo, ArrayList<Integer> aasEFS, ArrayList<Integer> aasTypes, SubjectIndexOfAdn sneInfo, ArrayList<Integer> sneEFS, ArrayList<Integer> sneTypes) {
            int sfi;
            boolean isNeedReadEmail = true;
            boolean isNeedReadAnr = true;
            boolean isNeedReadSne = true;
            int tagNumberWithinParentTag = 0;
            do {
                int tag = tlv.getTag();
                switch (tag) {
                    case UniUsimPhoneBookManager.USIM_EFADN_TAG /* 192 */:
                    case UniUsimPhoneBookManager.USIM_EFIAP_TAG /* 193 */:
                    case UniUsimPhoneBookManager.USIM_EFEXT1_TAG /* 194 */:
                    case UniUsimPhoneBookManager.USIM_EFSNE_TAG /* 195 */:
                    case UniUsimPhoneBookManager.USIM_EFANR_TAG /* 196 */:
                    case UniUsimPhoneBookManager.USIM_EFPBC_TAG /* 197 */:
                    case UniUsimPhoneBookManager.USIM_EFGRP_TAG /* 198 */:
                    case UniUsimPhoneBookManager.USIM_EFAAS_TAG /* 199 */:
                    case UniUsimPhoneBookManager.USIM_EFGAS_TAG /* 200 */:
                    case UniUsimPhoneBookManager.USIM_EFUID_TAG /* 201 */:
                    case UniUsimPhoneBookManager.USIM_EFEMAIL_TAG /* 202 */:
                    case UniUsimPhoneBookManager.USIM_EFCCP1_TAG /* 203 */:
                        byte[] data = tlv.getData();
                        if (data.length < 2 || data.length > 3) {
                            UniUsimPhoneBookManager.this.logd("Invalid TLV length: " + data.length);
                        } else {
                            if (data.length != 3) {
                                sfi = UniUsimPhoneBookManager.INVALID_SFI;
                            } else {
                                int sfi2 = data[2] & UniUsimPhoneBookManager.INVALID_BYTE;
                                sfi = sfi2;
                            }
                            int efid = ((data[0] & UniUsimPhoneBookManager.INVALID_BYTE) << 8) | (data[1] & UniUsimPhoneBookManager.INVALID_BYTE);
                            if (tag == UniUsimPhoneBookManager.USIM_EFADN_TAG) {
                                emailInfo.adnEfid = efid;
                                anrInfo.adnEfid = efid;
                                aasInfo.adnEfid = efid;
                                sneInfo.adnEfid = efid;
                            }
                            if (parentTag == 169 && tag == 202) {
                                UniUsimPhoneBookManager.this.mEmailPresentInIap = true;
                                UniUsimPhoneBookManager.this.mEmailTagNumberInIap = tagNumberWithinParentTag;
                            }
                            if (tag == 202 && isNeedReadEmail) {
                                UniUsimPhoneBookManager.this.logd("parseEf email  efid = " + Integer.toHexString(efid) + ", TAG = " + Integer.toHexString(parentTag) + ", tagNumberWithinParentTag = " + Integer.toHexString(tagNumberWithinParentTag));
                                if (parentTag == 169) {
                                    emailInfo.recordNumInIap.put(Integer.valueOf(efid), Integer.valueOf(tagNumberWithinParentTag));
                                }
                                emailEFS.add(Integer.valueOf(efid));
                                emailTypes.add(Integer.valueOf(parentTag));
                                isNeedReadEmail = false;
                            } else {
                                isNeedReadEmail = isNeedReadEmail;
                            }
                            if (tag == 196 && isNeedReadAnr) {
                                UniUsimPhoneBookManager.this.logd("parseEf ANR  efid = " + Integer.toHexString(efid) + ", TAG = " + Integer.toHexString(parentTag) + ", tagNumberWithinParentTag = " + Integer.toHexString(tagNumberWithinParentTag));
                                if (parentTag == 169) {
                                    UniUsimPhoneBookManager.this.mAnrPresentInIap = true;
                                    anrInfo.recordNumInIap.put(Integer.valueOf(efid), Integer.valueOf(tagNumberWithinParentTag));
                                }
                                anrEFS.add(Integer.valueOf(efid));
                                anrTypes.add(Integer.valueOf(parentTag));
                                isNeedReadAnr = false;
                            } else {
                                isNeedReadAnr = isNeedReadAnr;
                            }
                            if (tag == 199 && UniPhonebookUtils.isSupportOrange()) {
                                UniUsimPhoneBookManager.this.logd("parseEf   aas  efid " + Integer.toHexString(efid) + "  TAG  " + Integer.toHexString(parentTag) + "  tagNumberWithinParentTag " + Integer.toHexString(tagNumberWithinParentTag));
                                aasEFS.add(Integer.valueOf(efid));
                                aasTypes.add(Integer.valueOf(parentTag));
                            }
                            if (tag == 195 && UniPhonebookUtils.isSupportOrange() && isNeedReadSne) {
                                UniUsimPhoneBookManager.this.logd("parseEf sne  efid = " + Integer.toHexString(efid) + ", TAG = " + Integer.toHexString(parentTag) + ", tagNumberWithinParentTag = " + Integer.toHexString(tagNumberWithinParentTag));
                                if (parentTag == 169) {
                                    UniUsimPhoneBookManager.this.mSnePresentInIap = true;
                                    UniUsimPhoneBookManager.this.mSneTagNumberInIap = tagNumberWithinParentTag;
                                    sneInfo.recordNumInIap.put(Integer.valueOf(efid), Integer.valueOf(tagNumberWithinParentTag));
                                }
                                sneEFS.add(Integer.valueOf(efid));
                                sneTypes.add(Integer.valueOf(parentTag));
                                isNeedReadSne = false;
                            } else {
                                isNeedReadSne = isNeedReadSne;
                            }
                            UniUsimPhoneBookManager.this.logd("parseTag tag = " + tag + ", efid = " + efid);
                            if (this.mFileIds.get(tag) == null || (tag != 202 && tag != 196 && tag != 195)) {
                                this.mFileIds.put(tag, UniUsimPhoneBookManager.this.new File(parentTag, efid, sfi, tagNumberWithinParentTag));
                            } else {
                                UniUsimPhoneBookManager.this.logd("parseTag, tag already exist.");
                            }
                        }
                        break;
                    default:
                        isNeedReadEmail = isNeedReadEmail;
                        isNeedReadAnr = isNeedReadAnr;
                        isNeedReadSne = isNeedReadSne;
                        break;
                }
                isNeedReadEmail = isNeedReadEmail;
                isNeedReadAnr = isNeedReadAnr;
                isNeedReadSne = isNeedReadSne;
                tagNumberWithinParentTag++;
            } while (tlv.nextObject());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void logd(String msg) {
        UniPhoneBookLog.d(TAG, msg);
    }

    private void logi(String msg) {
        UniPhoneBookLog.d(TAG, msg);
    }

    private void log(String msg) {
        UniPhoneBookLog.d(this, msg);
    }

    private void loge(String msg) {
        UniPhoneBookLog.e(TAG, msg);
    }

    private String readAnrRecord(int recNum) {
        byte[] anr3Rec = null;
        String anr1 = null;
        String anr2 = null;
        ArrayList<byte[]> arrayList = this.mAnrFileRecord;
        if (arrayList == null) {
            return null;
        }
        int i = this.mAnrRecordSizeArray[0];
        int i2 = this.mAnrFileCount;
        int firstAnrFileRecordCount = i / i2;
        if (i2 == 1) {
            byte[] anr1Rec = arrayList.get(recNum);
            String anr = PhoneNumberUtils.calledPartyBCDToString(anr1Rec, 2, anr1Rec[2] & INVALID_BYTE);
            logd("readAnrRecord anr: " + anr);
            return anr;
        }
        if (recNum < firstAnrFileRecordCount) {
            try {
                byte[] anr1Rec2 = arrayList.get(recNum);
                byte[] anr2Rec = this.mAnrFileRecord.get(recNum + firstAnrFileRecordCount);
                if (this.mAnrFileCount > 2) {
                    anr3Rec = this.mAnrFileRecord.get((firstAnrFileRecordCount * 2) + recNum);
                }
                anr1 = PhoneNumberUtils.calledPartyBCDToString(anr1Rec2, 2, anr1Rec2[2] & INVALID_BYTE);
                anr2 = PhoneNumberUtils.calledPartyBCDToString(anr2Rec, 2, anr2Rec[2] & INVALID_BYTE);
                if (this.mAnrFileCount > 2) {
                    String anr3 = PhoneNumberUtils.calledPartyBCDToString(anr3Rec, 2, anr3Rec[2] & INVALID_BYTE);
                    String anr4 = anr1 + ";" + anr2 + ";" + anr3;
                    logd("readAnrRecord anr:" + anr4);
                    return anr4;
                }
            } catch (IndexOutOfBoundsException e) {
                return null;
            }
        } else if (recNum < firstAnrFileRecordCount || recNum >= arrayList.size() / this.mAnrFileCount) {
            logd("the total anr size is exceed mAnrFileRecord.size() " + this.mAnrFileRecord.size());
        } else {
            int size = this.mAnrFileRecord.size();
            int i3 = this.mAnrRecordSizeArray[0];
            int secondAnrFileRecordCount = (size - i3) / this.mAnrFileCount;
            try {
                int secondAnrfileread = i3 + (recNum % firstAnrFileRecordCount);
                byte[] anr1Rec3 = this.mAnrFileRecord.get(secondAnrfileread);
                byte[] anr2Rec2 = this.mAnrFileRecord.get(secondAnrfileread + secondAnrFileRecordCount);
                if (this.mAnrFileCount > 2) {
                    anr3Rec = this.mAnrFileRecord.get((secondAnrFileRecordCount * 2) + secondAnrfileread);
                }
                anr1 = PhoneNumberUtils.calledPartyBCDToString(anr1Rec3, 2, anr1Rec3[2] & INVALID_BYTE);
                anr2 = PhoneNumberUtils.calledPartyBCDToString(anr2Rec2, 2, anr2Rec2[2] & INVALID_BYTE);
                if (this.mAnrFileCount > 2) {
                    String anr5 = PhoneNumberUtils.calledPartyBCDToString(anr3Rec, 2, anr3Rec[2] & INVALID_BYTE);
                    String anr6 = anr1 + ";" + anr2 + ";" + anr5;
                    logd("readAnrRecord anr:" + anr6);
                    return anr6;
                }
            } catch (IndexOutOfBoundsException e2) {
                return null;
            }
        }
        String anr7 = anr1 + ";" + anr2;
        logd("readAnrRecord anr " + anr7);
        return anr7;
    }

    private void readIapFileAndWait(int efid, int recNum, int offSet) {
        int[] size;
        HashMap<Integer, int[]> map = this.mRecordsSize;
        if (map != null && map.containsKey(Integer.valueOf(efid))) {
            size = this.mRecordsSize.get(Integer.valueOf(efid));
        } else {
            size = readFileSizeAndWait(efid);
        }
        if (size == null || size.length < 3) {
            return;
        }
        if (this.mIapFileRecord == null) {
            this.mIapFileRecord = new ArrayList<>();
        }
        ArrayList<byte[]> fileRecord = initArraylist(size[0], size[2]);
        ArrayList<byte[]> arrayList = this.mIapFileRecord;
        if (arrayList != null) {
            arrayList.addAll(0, fileRecord);
            for (int i = offSet; i < this.mPhoneBookRecords.size() && i < size[2] + offSet; i++) {
                if (!TextUtils.isEmpty(this.mPhoneBookRecords.get(i).getAlphaTag()) || !TextUtils.isEmpty(this.mPhoneBookRecords.get(i).getNumber())) {
                    this.mPendingIapLoads.addAndGet(1);
                    IccFileHandler iccFileHandler = this.mFh;
                    if (iccFileHandler != null && (iccFileHandler instanceof UniUsimFileHandler)) {
                        ((UniUsimFileHandler) iccFileHandler).loadEFLinearFixed(efid, (i + 1) - offSet, size[0], obtainMessage(3, i - offSet, recNum));
                    }
                }
            }
            if (this.mPendingIapLoads.get() == 0) {
                this.mIsNotify.set(false);
                return;
            }
            this.mIsNotify.set(true);
            try {
                this.mLock.wait();
                return;
            } catch (InterruptedException e) {
                loge("Interrupted Exception in readIapFileAndWait");
                return;
            }
        }
        logd("readIapFileAndWait: mIapFileRecord is null");
    }

    public ArrayList<byte[]> getIapFileRecord(int recNum) {
        int efid = findEFIapInfo(recNum);
        if (efid < 0) {
            return null;
        }
        return (ArrayList) this.mIapFileRecordArray[recNum];
    }

    public int getNewSubjectNumber(int type, int num, int efid, int index, int adnNum, boolean isInIap) {
        logd("getNewSubjectNumber:  adnNum = " + adnNum + ", isInIap = " + isInIap + ", efid = " + efid + ", index = " + index);
        SubjectIndexOfAdn idx = getSubjectIndex(type, num);
        if (idx == null) {
            return INVALID_SFI;
        }
        if (idx.record == null || !idx.record.containsKey(Integer.valueOf(efid))) {
            logd("getNewSubjectNumber idx.record == null || !idx.record.containsKey(efid)");
            return INVALID_SFI;
        }
        int count = idx.record.get(Integer.valueOf(efid)).size();
        logd("getNewSubjectNumber: count = " + count);
        if (isInIap) {
            Set<Integer> set = (Set) idx.usedSet[index];
            for (int i = 1; i <= count; i++) {
                Integer subjectNum = new Integer(i);
                if (!set.contains(subjectNum)) {
                    int newSubjectNum = subjectNum.intValue();
                    logd("getNewSubjectNumber: subjectNum = " + subjectNum);
                    set.add(subjectNum);
                    idx.usedSet[index] = set;
                    setSubjectIndex(type, num, idx);
                    SetRepeatUsedNumSet(type, efid, set);
                    return newSubjectNum;
                }
            }
            return INVALID_SFI;
        }
        if (adnNum > count) {
            logd("adnNum > count");
            return INVALID_SFI;
        }
        return adnNum;
    }

    public void removeSubjectNumFromSet(int type, int num, int efid, int index, int anrNum) {
        Integer delNum = new Integer(anrNum);
        SubjectIndexOfAdn subject = getSubjectIndex(type, num);
        if (subject == null) {
            return;
        }
        subject.record.get(Integer.valueOf(efid)).size();
        Set<Integer> set = (Set) subject.usedSet[index];
        set.remove(delNum);
        logd("removeSubjectNumFromSet  delnum(1) = " + delNum);
        subject.usedSet[index] = set;
        setSubjectIndex(type, num, subject);
    }

    private int[] readAdnFileSizeAndWait(int recNum) {
        int[] recordSize;
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return null;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(recNum).mFileIds;
            if (files == null || files.size() == 0) {
                if (recNum == 0) {
                    this.mIsContainAdnInPbr = false;
                }
                return null;
            }
            if (files.get(USIM_EFADN_TAG) == null) {
                if (recNum == 0) {
                    this.mIsContainAdnInPbr = false;
                }
                return null;
            }
            int efid = files.get(USIM_EFADN_TAG).getEfid();
            HashMap<Integer, int[]> map = this.mRecordsSize;
            if (map != null && map.containsKey(Integer.valueOf(efid))) {
                int[] recordSize2 = this.mRecordsSize.get(Integer.valueOf(efid));
                recordSize = recordSize2;
            } else {
                recordSize = readFileSizeAndWait(efid);
            }
            if (recordSize == null || recordSize.length < 3 || recordSize[0] < 14) {
                if (recNum == 0) {
                    this.mIsContainAdnInPbr = false;
                }
                return null;
            }
            return recordSize;
        } catch (IndexOutOfBoundsException e) {
            loge("readAdnFileSizeAndWait IndexOutOfBoundsException");
            return null;
        }
    }

    private void readIapFile(int recNum, int offSet) {
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(recNum).mFileIds;
            if (files == null || files.size() == 0 || files.get(USIM_EFIAP_TAG) == null) {
                return;
            }
            logd("readIapFile mAnrPresentInIap = " + this.mAnrPresentInIap + ", mEmailPresentInIap = " + this.mEmailPresentInIap + ", mSnePresentInIap = " + this.mSnePresentInIap + ", offSet = " + offSet);
            if (this.mAnrPresentInIap || this.mEmailPresentInIap || this.mSnePresentInIap) {
                readIapFileAndWait(files.get(USIM_EFIAP_TAG).getEfid(), recNum, offSet);
            }
        } catch (IndexOutOfBoundsException e) {
            loge("readIapFile IndexOutOfBoundsException");
        }
    }

    public int[] readFileSizeAndWait(int efId) {
        synchronized (this.mLock) {
            this.mFh.getEFLinearRecordSize(efId, obtainMessage(EVENT_GET_RECORDS_COUNT, efId, 0));
            try {
                this.mLock.wait();
            } catch (InterruptedException e) {
                loge("Interrupted Exception in readAdnFileAndWait");
            }
        }
        HashMap<Integer, int[]> map = this.mRecordsSize;
        if (map == null) {
            return null;
        }
        int[] size = map.get(Integer.valueOf(efId));
        return size;
    }

    private SubjectIndexOfAdn getSubjectIndex(int type, int num) {
        LinkedList<SubjectIndexOfAdn> lst = null;
        switch (type) {
            case 0:
                lst = this.mEmailInfoFromPBR;
                break;
            case 1:
                lst = this.mAnrInfoFromPBR;
                break;
            case 3:
                lst = this.mAasInfoFromPBR;
                break;
            case 4:
                lst = this.mSneInfoFromPBR;
                break;
        }
        if (lst != null && lst.size() != 0) {
            SubjectIndexOfAdn index = lst.get(num);
            return index;
        }
        return null;
    }

    private void setSubjectIndex(int type, int num, SubjectIndexOfAdn subjectIndex) {
        switch (type) {
            case 0:
                LinkedList<SubjectIndexOfAdn> linkedList = this.mEmailInfoFromPBR;
                if (linkedList != null) {
                    linkedList.set(num, subjectIndex);
                    break;
                }
                break;
            case 1:
                LinkedList<SubjectIndexOfAdn> linkedList2 = this.mAnrInfoFromPBR;
                if (linkedList2 != null) {
                    linkedList2.set(num, subjectIndex);
                    break;
                }
                break;
            case 3:
                LinkedList<SubjectIndexOfAdn> linkedList3 = this.mAasInfoFromPBR;
                if (linkedList3 != null) {
                    linkedList3.set(num, subjectIndex);
                    break;
                }
                break;
            case 4:
                LinkedList<SubjectIndexOfAdn> linkedList4 = this.mSneInfoFromPBR;
                if (linkedList4 != null) {
                    linkedList4.set(num, subjectIndex);
                    break;
                }
                break;
        }
    }

    public Set<Integer> getUsedNumSet(Set<Integer> set1, Set<Integer> set2, int count) {
        for (int i = 1; i <= count; i++) {
            Integer subjectNum = new Integer(i);
            if (!set1.contains(subjectNum) && set2.contains(subjectNum)) {
                logd("getUsedNumSet  subjectNum(1) " + subjectNum);
                set1.add(subjectNum);
            }
        }
        return set1;
    }

    public Set<Integer> getRepeatUsedNumSet(LinkedList<SubjectIndexOfAdn> lst, int idx, int efid, Set<Integer> set, int count) {
        int num;
        Set<Integer> totalSet = set;
        for (int m = idx + 1; m < lst.size(); m++) {
            SubjectIndexOfAdn index = lst.get(m);
            if (index != null && (num = getUsedNumSetIndex(efid, index)) >= 0) {
                totalSet = getUsedNumSet((Set) index.usedSet[num], totalSet, count);
            }
        }
        return totalSet;
    }

    private void setSubjectUsedNum(int type, int num) {
        SubjectIndexOfAdn index = getSubjectIndex(type, num);
        if (index == null || index.efids == null) {
            return;
        }
        int size = index.efids.length;
        index.usedSet = new Object[size];
        for (int i = 0; i < size; i++) {
            index.usedSet[i] = new HashSet();
        }
        setSubjectIndex(type, num, index);
    }

    private void SetRepeatUsedNumSet(int type, int efid, Set<Integer> totalSet) {
        int num;
        LinkedList<SubjectIndexOfAdn> lst = null;
        switch (type) {
            case 0:
                lst = this.mEmailInfoFromPBR;
                break;
            case 1:
                lst = this.mAnrInfoFromPBR;
                break;
            case 3:
                lst = this.mAasInfoFromPBR;
                break;
            case 4:
                lst = this.mSneInfoFromPBR;
                break;
        }
        if (lst == null) {
            return;
        }
        for (int m = 0; m < lst.size(); m++) {
            SubjectIndexOfAdn index = lst.get(m);
            if (index != null && index.recordNumInIap != null && index.usedSet != null && (num = getUsedNumSetIndex(efid, index)) >= 0) {
                logd(" SetRepeatUsedNumSet efid = " + efid + ", num = " + num + ", totalSet.size = " + totalSet.size());
                index.usedSet[num] = totalSet;
                setSubjectIndex(type, m, index);
            }
        }
    }

    private void SetMapOfRepeatEfid(int type, int efid) {
        Set<Integer> set;
        LinkedList<SubjectIndexOfAdn> lst = null;
        Set<Integer> totalSet = new HashSet<>();
        switch (type) {
            case 0:
                lst = this.mEmailInfoFromPBR;
                break;
            case 1:
                lst = this.mAnrInfoFromPBR;
                break;
            case 3:
                lst = this.mAasInfoFromPBR;
                break;
            case 4:
                lst = this.mSneInfoFromPBR;
                break;
        }
        if (lst != null && lst.size() != 0) {
            for (int i = 0; i < lst.size(); i++) {
                SubjectIndexOfAdn index = lst.get(i);
                if (index != null && index.recordNumInIap != null && index.record != null && index.record.containsKey(Integer.valueOf(efid))) {
                    int count = index.record.get(Integer.valueOf(efid)).size();
                    logd("SetMapOfRepeatEfid count = " + count);
                    int num = getUsedNumSetIndex(efid, index);
                    if (num >= 0 && (set = (Set) index.usedSet[num]) != null) {
                        logd("SetMapOfRepeatEfid size = " + set.size());
                        totalSet = getUsedNumSet(totalSet, set, count);
                    }
                }
            }
        }
        if (totalSet != null) {
            logd("SetMapOfRepeatEfid  size " + totalSet.size());
        }
        SetRepeatUsedNumSet(type, efid, totalSet);
    }

    public int getEfIdByTag(int recordNum, int fileTag) {
        logd("getEfIdByTag, recordNum = " + recordNum + ", fileTag = " + fileTag);
        ArrayList<PbrRecord> arrayList = this.mPbrRecords;
        if (arrayList == null || arrayList.size() == 0) {
            loge("getEfIdByTag error, Pbr file is empty");
            return INVALID_SFI;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(recordNum).mFileIds;
            if (files == null || files.size() == 0) {
                loge("getEfIdByTag error, files is empty");
                return INVALID_SFI;
            }
            if (files.get(fileTag) != null) {
                return files.get(fileTag).getEfid();
            }
            return 0;
        } catch (IndexOutOfBoundsException e) {
            loge("getEfIdByTag IndexOutOfBoundsException");
            return INVALID_SFI;
        }
    }

    public int findEFEmailInfo(int index) {
        logd("findEFEmailInfo index = " + index);
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return INVALID_SFI;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(index).mFileIds;
            if (files == null || files.size() == 0) {
                logd("findEFEmailInfo fileIds is null or size is 0");
                return INVALID_SFI;
            }
            if (files.get(USIM_EFEMAIL_TAG) != null) {
                return files.get(USIM_EFEMAIL_TAG).getEfid();
            }
            return 0;
        } catch (IndexOutOfBoundsException e) {
            loge("findEFEmailInfo IndexOutOfBoundsException");
            return INVALID_SFI;
        }
    }

    public int findEFAnrInfo(int index) {
        logd("findEFAnrInfo index = " + index);
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return INVALID_SFI;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(index).mFileIds;
            if (files == null || files.size() == 0) {
                logd("findEFAnrInfo, files is null or size is 0");
                return INVALID_SFI;
            }
            if (files.get(USIM_EFANR_TAG) != null) {
                return files.get(USIM_EFANR_TAG).getEfid();
            }
            return 0;
        } catch (IndexOutOfBoundsException e) {
            loge("findEFAnrInfo IndexOutOfBoundsException");
            return INVALID_SFI;
        }
    }

    private String getType1Anr(int num, SubjectIndexOfAdn anrInfo, int adnNum, int efid, ArrayList<Integer> aasIndex) {
        ArrayList<byte[]> anrFileRecord = anrInfo.record.get(Integer.valueOf(efid));
        if (anrFileRecord == null || adnNum >= anrFileRecord.size()) {
            return "";
        }
        byte[] anrRec = anrFileRecord.get(adnNum);
        if (anrRec.length <= 1) {
            return "";
        }
        String anr = PhoneNumberUtils.calledPartyBCDToString(anrRec, 2, anrRec[1] & INVALID_BYTE);
        aasIndex.add(Integer.valueOf(anrRec[0]));
        return anr;
    }

    private String getType2Anr(int num, SubjectIndexOfAdn anrInfo, byte[] record, int adnNum, int efid, ArrayList<Integer> aasIndex) {
        int index;
        String anr = "";
        if (record == null || (index = getUsedNumSetIndex(efid, anrInfo)) == INVALID_SFI) {
            return "";
        }
        int anrTagNumberInIap = anrInfo.recordNumInIap.get(Integer.valueOf(efid)).intValue();
        ArrayList<byte[]> anrFileRecord = anrInfo.record.get(Integer.valueOf(efid));
        if (anrFileRecord == null || record.length <= anrTagNumberInIap) {
            return "";
        }
        int recNum = record[anrTagNumberInIap] & INVALID_BYTE;
        int recNum2 = recNum == 255 ? INVALID_SFI : recNum;
        if (recNum2 > 0 && recNum2 <= anrFileRecord.size()) {
            byte[] anrRec = anrFileRecord.get(recNum2 + INVALID_SFI);
            if (anrRec.length > 1) {
                anr = PhoneNumberUtils.calledPartyBCDToString(anrRec, 2, 255 & anrRec[1]);
                aasIndex.add(Integer.valueOf(anrRec[0]));
            }
            if (TextUtils.isEmpty(anr)) {
                logd("getAnrInIap anr is emtry");
                setIapFileRecord(num, adnNum, INVALID_BYTE, anrTagNumberInIap);
                return anr;
            }
            Set<Integer> set = (Set) anrInfo.usedSet[index];
            set.add(new Integer(recNum2));
            anrInfo.usedSet[index] = set;
            setSubjectIndex(1, num, anrInfo);
        }
        return anr;
    }

    private int getUsedNumSetIndex(int efid, SubjectIndexOfAdn index) {
        int count = INVALID_SFI;
        if (index != null && index.efids != null) {
            for (int k = 0; k < index.efids.length; k++) {
                if (index.type[k] == 169) {
                    count++;
                    if (index.efids[k] == efid) {
                        return count;
                    }
                }
            }
            return INVALID_SFI;
        }
        return INVALID_SFI;
    }

    public void setIapFileRecord(int recNum, int index, byte value, int numInIap) {
        ArrayList<byte[]> tmpIapFileRecord = (ArrayList) this.mIapFileRecordArray[recNum];
        byte[] record = tmpIapFileRecord.get(index);
        byte[] temp = new byte[record.length];
        for (int i = 0; i < temp.length; i++) {
            temp[i] = record[i];
        }
        temp[numInIap] = value;
        tmpIapFileRecord.set(index, temp);
        this.mIapFileRecordArray[recNum] = tmpIapFileRecord;
    }

    private String getAnr(int num, SubjectIndexOfAdn anrInfo, SubjectIndexOfAdn aasInfo, int index, byte[] record, int adnNum) {
        String anr;
        String anrGroup;
        String str;
        if (anrInfo.efids == null || anrInfo.efids.length == 0) {
            logd("getAnr anrInfo.efids == null || anrInfo.efids.length == 0");
            return null;
        }
        ArrayList<Integer> aasIndex = new ArrayList<>();
        String anrGroup2 = null;
        String anr2 = null;
        String aasGroup = null;
        String aas = null;
        for (int i = 0; i < anrInfo.efids.length; i++) {
            if (anrInfo.type[i] != 168) {
                anr = anr2;
            } else {
                String anr3 = getType1Anr(num, anrInfo, adnNum, anrInfo.efids[i], aasIndex);
                anr = anr3;
            }
            if (anrInfo.type[i] == 169 && anrInfo.recordNumInIap != null) {
                anr2 = getType2Anr(num, anrInfo, record, adnNum, anrInfo.efids[i], aasIndex);
            } else {
                anr2 = anr;
            }
            if (i < aasIndex.size() && UniPhonebookUtils.isSupportOrange()) {
                aas = getAas(aasInfo, aasIndex.get(i).intValue()) + "," + aasIndex.get(i);
            }
            if (i == 0) {
                anrGroup = anr2;
                str = aas;
            } else {
                anrGroup = anrGroup2 + ";" + anr2;
                str = aasGroup + ";" + aas;
            }
            anrGroup2 = anrGroup;
            aasGroup = str;
        }
        if (aasInfo != null && aasGroup != null && UniPhonebookUtils.isSupportOrange()) {
            setAas(index, aasGroup);
        }
        return anrGroup2;
    }

    private void setEmailandAnr(int adnNum, String[] emails, String anr) {
        UniAdnRecord rec = this.mPhoneBookRecords.size() > adnNum ? this.mPhoneBookRecords.get(adnNum) : null;
        if (rec == null && (emails != null || anr != null)) {
            rec = new UniAdnRecord("", "");
        }
        if (emails != null) {
            rec.setEmails(emails);
        }
        if (anr != null) {
            rec.setAnr(anr);
        }
        try {
            this.mPhoneBookRecords.set(adnNum, rec);
        } catch (IndexOutOfBoundsException e) {
            logd("setEmailandAnr IndexOutOfBoundsException");
        }
    }

    private void setAnrIapFileRecord(int num, int index, byte value, int numInIap) {
        log("setAnrIapFileRecord, num:" + num + ", index: " + index + ", value: " + ((int) value) + ", numInIap:" + numInIap);
        ArrayList<byte[]> tmpIapFileRecord = (ArrayList) this.mIapFileRecordArray[num];
        byte[] record = tmpIapFileRecord.get(index);
        record[numInIap] = value;
        tmpIapFileRecord.set(index, record);
        this.mIapFileRecordArray[num] = tmpIapFileRecord;
    }

    public int[] getAdnRecordSizeArray() {
        return this.mAdnRecordSizeArray;
    }

    public int getNumRecs() {
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
            ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
            if (arrayList2 != null && arrayList2.size() != 0) {
                return this.mPbrRecords.size();
            }
            loge("Error: Pbr file is empty");
            return 0;
        }
    }

    public int getAnrNum() {
        log("getAnrNum");
        return getFileSupportNum(1, this.mAnrPresentInIap);
    }

    private int getFileSupportNum(int type, boolean isPresentInIap) {
        int[] size;
        int[] efids = getSubjectEfids(type, 0);
        if (efids == null) {
            logd("getFileSupportNum: efids == null");
            return 0;
        }
        int num = efids.length;
        for (int i = 0; i < num; i++) {
            HashMap<Integer, int[]> map = this.mRecordsSize;
            if (map != null && map.containsKey(Integer.valueOf(efids[i]))) {
                size = this.mRecordsSize.get(Integer.valueOf(efids[i]));
            } else {
                size = readFileSizeAndWait(efids[i]);
            }
            if (size == null || size.length < 3) {
                logd("getFileSupportNum: get file size error");
                return 0;
            }
        }
        if (isPresentInIap && !isIapFileExist()) {
            logd("getFileSupportNum: iap file does not exist!");
            return 0;
        }
        logd("getFileSupportNum: " + num);
        return num;
    }

    private boolean isIapFileExist() {
        int[] recordSizeIap;
        int iapEfid = findEFIapInfo(0);
        logd("isIapFileExist: iapEfid = " + iapEfid);
        if (iapEfid <= 0) {
            logd("isIapFileExist: iap file does not exist");
            return false;
        }
        HashMap<Integer, int[]> map = this.mRecordsSize;
        if (map != null && map.containsKey(Integer.valueOf(iapEfid))) {
            recordSizeIap = this.mRecordsSize.get(Integer.valueOf(iapEfid));
        } else {
            recordSizeIap = readFileSizeAndWait(iapEfid);
        }
        if (recordSizeIap == null || recordSizeIap.length < 3) {
            logd("isIapFileExist: get file size error");
            return false;
        }
        return true;
    }

    public int getPhoneNumMaxLen() {
        return 40;
    }

    public int getEmailType() {
        return this.mEmailPresentInIap ? 2 : 1;
    }

    public int getEmailNum() {
        log("getEmailNum");
        return getFileSupportNum(0, this.mEmailPresentInIap);
    }

    public int[] getEmailRecordsSize() {
        int[] recordSizeEmail;
        Set<Integer> usedEfIds = new HashSet<>();
        int[] recordSizeTotal = new int[3];
        for (int num = 0; num < getNumRecs(); num++) {
            int efid = findEFEmailInfo(num);
            if (efid > 0 && !usedEfIds.contains(Integer.valueOf(efid))) {
                HashMap<Integer, int[]> map = this.mRecordsSize;
                if (map != null && map.containsKey(Integer.valueOf(efid))) {
                    recordSizeEmail = this.mRecordsSize.get(Integer.valueOf(efid));
                } else {
                    recordSizeEmail = readFileSizeAndWait(efid);
                }
                usedEfIds.add(Integer.valueOf(efid));
                if (recordSizeEmail != null && recordSizeEmail.length == 3) {
                    recordSizeTotal[0] = recordSizeEmail[0];
                    recordSizeTotal[1] = recordSizeTotal[1] + recordSizeEmail[1];
                    recordSizeTotal[2] = recordSizeTotal[2] + recordSizeEmail[2];
                }
            }
        }
        return recordSizeTotal;
    }

    public int getEmailMaxLen() {
        int[] recordSizeEmail;
        int efid = findEFEmailInfo(0);
        HashMap<Integer, int[]> map = this.mRecordsSize;
        if (map != null && map.containsKey(Integer.valueOf(efid))) {
            int[] recordSizeEmail2 = this.mRecordsSize.get(Integer.valueOf(efid));
            recordSizeEmail = recordSizeEmail2;
        } else {
            recordSizeEmail = readFileSizeAndWait(efid);
        }
        if (recordSizeEmail == null || recordSizeEmail.length == 0) {
            logd("getEmailMaxLen recordSizeEmail == null || recordSizeEmail.length == 0");
            return 0;
        }
        return recordSizeEmail[0] - 2;
    }

    public int getGroupNum() {
        int[] recordSizeGrp;
        SparseArray<File> files = null;
        ArrayList<PbrRecord> arrayList = this.mPbrRecords;
        if (arrayList == null || arrayList.size() == 0) {
            return 0;
        }
        try {
            files = this.mPbrRecords.get(0).mFileIds;
        } catch (IndexOutOfBoundsException e) {
            loge("getGroupNum, IndexOutOfBoundsException");
        }
        if (files == null || files.size() == 0 || files.get(USIM_EFGRP_TAG) == null) {
            return 0;
        }
        int grpEfid = files.get(USIM_EFGRP_TAG).getEfid();
        HashMap<Integer, int[]> map = this.mRecordsSize;
        if (map != null && map.containsKey(Integer.valueOf(grpEfid))) {
            recordSizeGrp = this.mRecordsSize.get(Integer.valueOf(grpEfid));
        } else {
            recordSizeGrp = readFileSizeAndWait(grpEfid);
        }
        if (recordSizeGrp == null || recordSizeGrp.length < 3) {
            logd("recordSizeGrp is null, getGroupNum is 0");
            return 0;
        }
        return 1;
    }

    public int[] getValidNumToMatch(UniAdnRecord adn, int type, int[] subjectNums) {
        int efid;
        for (int num = 0; num < getNumRecs() && (efid = findEFInfo(num)) > 0; num++) {
            logd("getEfIdToMatch ");
            loge("efid is " + efid);
            ArrayList<UniAdnRecord> oldAdnList = this.mAdnCache.getRecordsIfLoadedEx(efid);
            if (oldAdnList == null) {
                return null;
            }
            logd("getEfIdToMatch (2)");
            Iterator<UniAdnRecord> it = oldAdnList.iterator();
            int count = 1;
            while (it.hasNext()) {
                if (adn.isEqual(it.next())) {
                    logd("we got the index " + count);
                    int adnIndex = count;
                    int[] ret = getAvalibleSubjectCount(num, type, efid, adnIndex, subjectNums);
                    if (ret != null) {
                        return ret;
                    }
                }
                count++;
            }
        }
        return null;
    }

    private int getAvalibleAdnCount() {
        int count = 0;
        for (int i = 0; i < this.mPhoneBookRecords.size(); i++) {
            UniAdnRecord adnRecord = this.mPhoneBookRecords.get(i);
            if (adnRecord.isEmpty()) {
                count++;
            }
        }
        return count;
    }

    public int[] getAvalibleSubjectCount(int num, int type, int efid, int adnNum, int[] subjectNums) {
        int n = 0;
        logd("getAvalibleSubjectCount efid " + efid + ", num " + num + ", type " + type + ", adnNum " + adnNum + ", subjectNums " + subjectNums);
        SubjectIndexOfAdn index = getSubjectIndex(type, num);
        if (index == null) {
            return null;
        }
        int[] ret = new int[subjectNums.length];
        logd("getAvalibleSubjectCount adnEfid = " + index.adnEfid);
        if (index != null && index.adnEfid == efid && index.record != null && index.efids != null && index.type != null) {
            for (int j = 0; j < index.efids.length; j++) {
                logd("getAvalibleSubjectCount efid = " + index.efids[j]);
                for (int l = 0; l < subjectNums.length; l++) {
                    logd("getAvalibleSubjectCount efid = " + subjectNums[l]);
                    if (subjectNums[l] == 1 && index.record.containsKey(Integer.valueOf(index.efids[j])) && index.record.get(Integer.valueOf(index.efids[j])) != null) {
                        int count = index.record.get(Integer.valueOf(index.efids[j])).size();
                        if (index.type[j] == 168) {
                            ret[n] = getAvalibleAdnCount();
                            n++;
                            break;
                        }
                        if (index.type[j] == 169) {
                            int idx = getUsedNumSetIndex(index.efids[j], index);
                            logd("getAvalibleSubjectCount idx = " + idx);
                            if (idx >= 0) {
                                Set<Integer> usedSet = (Set) index.usedSet[idx];
                                int avalibleNum = count - usedSet.size();
                                ret[n] = avalibleNum;
                                n++;
                                break;
                            }
                        } else {
                            continue;
                        }
                    }
                }
            }
        }
        logd("getAvalibleSubjectCount  n " + n);
        if (n == 0) {
            return null;
        }
        for (int i : ret) {
            logd("getAvalibleSubjectCount  ret[] " + i);
        }
        return ret;
    }

    public int[] getAvalibleAnrCount(String name, String number, String[] emails, String anr, int[] anrNums) {
        UniAdnRecord adn = new UniAdnRecord(name, number, emails, anr, "", "", "", "");
        return getValidNumToMatch(adn, 1, anrNums);
    }

    public int[] getAvalibleEmailCount(String name, String number, String[] emails, String anr, int[] emailNums) {
        UniAdnRecord adn = new UniAdnRecord(name, number, emails, anr, "", "", "", "");
        return getValidNumToMatch(adn, 0, emailNums);
    }

    private String getGrp(int adnNum) {
        ArrayList<byte[]> arrayList = this.mGrpFileRecord;
        if (arrayList == null) {
            return null;
        }
        String retGrp = composeGrpString(arrayList.get(adnNum));
        return retGrp;
    }

    private String composeGrpString(byte[] data) {
        String groupInfo = null;
        this.mGrpCount = data.length;
        for (int i = 0; i < this.mGrpCount; i++) {
            int temp = data[i] & INVALID_BYTE;
            if (temp != 0 && temp != 255) {
                if (groupInfo == null) {
                    groupInfo = Integer.toString(temp);
                } else {
                    groupInfo = groupInfo + ";" + temp;
                }
            }
        }
        return groupInfo;
    }

    public int[] getSubjectEfids(int type, int num) {
        SubjectIndexOfAdn index = getSubjectIndex(type, num);
        if (index == null) {
            return null;
        }
        int[] result = index.efids;
        if (result != null) {
            logd("getSubjectEfids  length = " + result.length);
        }
        return result;
    }

    public int[][] getSubjectTagNumberInIap(int type, int num) {
        SubjectIndexOfAdn index = getSubjectIndex(type, num);
        boolean isInIap = false;
        if (index == null) {
            return null;
        }
        int[][] result = (int[][]) Array.newInstance((Class<?>) int.class, index.efids.length, 2);
        Map<Integer, Integer> anrTagMap = index.recordNumInIap;
        if (anrTagMap == null || anrTagMap.size() == 0) {
            logd("getSubjectTagNumberInIap recordNumInIap == null");
            return null;
        }
        for (int i = 0; i < index.efids.length; i++) {
            if (anrTagMap.containsKey(Integer.valueOf(index.efids[i]))) {
                result[i][1] = anrTagMap.get(Integer.valueOf(index.efids[i])).intValue();
                result[i][0] = index.efids[i];
                isInIap = true;
            }
        }
        if (!isInIap) {
            logd("getSubjectTagNumberInIap isInIap == false");
            return null;
        }
        return result;
    }

    public int[][] getAnrTagNumberInIap(int num) {
        int[][] result = (int[][]) Array.newInstance((Class<?>) int.class, this.mAnrInfoFromPBR.get(num).efids.length, 2);
        Map<Integer, Integer> anrTagMap = this.mAnrInfoFromPBR.get(num).recordNumInIap;
        for (int i = 0; i < this.mAnrInfoFromPBR.get(num).efids.length; i++) {
            result[i][0] = this.mAnrInfoFromPBR.get(num).efids[i];
            result[i][1] = anrTagMap.get(Integer.valueOf(this.mAnrInfoFromPBR.get(num).efids[i])).intValue();
        }
        return result;
    }

    public boolean isSubjectRecordInIap(int type, int num, int indexOfEfids) {
        SubjectIndexOfAdn index = getSubjectIndex(type, num);
        if (index == null) {
            return false;
        }
        if (index.type[indexOfEfids] == 169 && index.recordNumInIap.size() > 0) {
            return true;
        }
        int i = index.type[indexOfEfids];
        return false;
    }

    public int findEFInfo(int index) {
        loge("findEFInfo index " + index);
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return INVALID_SFI;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(index).mFileIds;
            if (files != null && files.size() != 0) {
                return files.get(USIM_EFADN_TAG) != null ? files.get(USIM_EFADN_TAG).getEfid() : INVALID_SFI;
            }
            loge("Error: files is empty");
            return INVALID_SFI;
        } catch (IndexOutOfBoundsException e) {
            loge("findEFInfo IndexOutOfBoundsException");
            return INVALID_SFI;
        }
    }

    public int findExtensionEFInfo(int index) {
        logd("findExtensionEFInfo index " + index);
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return INVALID_SFI;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(index).mFileIds;
            if (files == null || files.size() == 0) {
                loge("Error: files is empty");
                return INVALID_SFI;
            }
            logd("findExtensionEFInfo files " + files);
            if (files.get(USIM_EFEXT1_TAG) != null) {
                return files.get(USIM_EFEXT1_TAG).getEfid();
            }
            return 0;
        } catch (IndexOutOfBoundsException e) {
            loge("findExtensionEFInfo IndexOutOfBoundsException");
            return INVALID_SFI;
        }
    }

    public int findEFIapInfo(int index) {
        logd("findEFIapInfo index " + index);
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return INVALID_SFI;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(index).mFileIds;
            if (files == null || files.size() == 0) {
                logd("findEFIapInfo fileIds == null");
                return INVALID_SFI;
            }
            if (files.get(USIM_EFIAP_TAG) != null) {
                return files.get(USIM_EFIAP_TAG).getEfid();
            }
            return 0;
        } catch (IndexOutOfBoundsException e) {
            loge("findEFIapInfo IndexOutOfBoundsException");
            return INVALID_SFI;
        }
    }

    public int findEFGasInfo() {
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return INVALID_SFI;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(0).mFileIds;
            if (files == null || files.size() == 0) {
                logd("findEFGasInfo fileIds == null");
                return INVALID_SFI;
            }
            if (files.get(USIM_EFGAS_TAG) != null) {
                return files.get(USIM_EFGAS_TAG).getEfid();
            }
            return 0;
        } catch (IndexOutOfBoundsException e) {
            loge("findEFGasInfo IndexOutOfBoundsException");
            return INVALID_SFI;
        }
    }

    public void updateGasList(String groupName, int groupId) {
        if (!this.mGasList.isEmpty()) {
            this.mGasList.set(groupId + INVALID_SFI, groupName);
        }
    }

    private void readAnrFileAndWait(int recNum, int offSet) {
        int[] size;
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(recNum).mFileIds;
            if (files == null || files.size() == 0) {
                logd("readAnrFileAndWait  fileIds == null");
                return;
            }
            if (files.get(USIM_EFANR_TAG) != null) {
                int i = 1;
                SubjectIndexOfAdn records = getSubjectIndex(1, recNum);
                if (records == null) {
                    logd("readAnrFileAndWait  records == null ");
                    return;
                }
                records.record = new HashMap();
                if (records.efids == null || records.efids.length == 0) {
                    logd("readAnrFileAndWait  records.efids == null || records.efids.length == 0");
                    return;
                }
                this.mAnrFileCount = records.efids.length;
                int i2 = 0;
                while (i2 < this.mAnrFileCount) {
                    logd("readAnrFileAndWait type " + records.type[i2] + " offSet = " + offSet);
                    char c = 0;
                    if (records.type[i2] == 168) {
                        if (this.mAnrFileRecord == null) {
                            this.mAnrFileRecord = new ArrayList<>();
                        }
                        HashMap<Integer, int[]> map = this.mRecordsSize;
                        if (map != null && map.containsKey(Integer.valueOf(records.efids[i2]))) {
                            size = this.mRecordsSize.get(Integer.valueOf(records.efids[i2]));
                        } else {
                            int[] size2 = records.efids;
                            size = readFileSizeAndWait(size2[i2]);
                        }
                        if (size != null && size.length >= 3) {
                            ArrayList<byte[]> fileRecord = initArraylist(size[0], size[2]);
                            ArrayList<byte[]> arrayList3 = this.mAnrFileRecord;
                            if (arrayList3 == null) {
                                logd("readAnrFileAndWait, mAnrFileRecord is null");
                                return;
                            }
                            arrayList3.addAll(0, fileRecord);
                            int j = offSet;
                            for (char c2 = 2; j < this.mPhoneBookRecords.size() && j < size[c2] + offSet; c2 = 2) {
                                if (!TextUtils.isEmpty(this.mPhoneBookRecords.get(j).getAlphaTag()) || !TextUtils.isEmpty(this.mPhoneBookRecords.get(j).getNumber())) {
                                    this.mPendingAnrLoads.addAndGet(i);
                                    IccFileHandler iccFileHandler = this.mFh;
                                    if (iccFileHandler != null && (iccFileHandler instanceof UniUsimFileHandler)) {
                                        ((UniUsimFileHandler) iccFileHandler).loadEFLinearFixed(records.efids[i2], (j + 1) - offSet, size[c], obtainMessage(EVENT_ANR_RECORD_LOAD_DONE, j - offSet, recNum));
                                    }
                                }
                                j++;
                                i = 1;
                                c = 0;
                            }
                            if (this.mPendingAnrLoads.get() == 0) {
                                this.mIsNotify.set(false);
                            } else {
                                this.mIsNotify.set(true);
                                try {
                                    this.mLock.wait();
                                } catch (InterruptedException e) {
                                    loge("Interrupted Exception in readEmailFileAndWait");
                                }
                            }
                        } else {
                            return;
                        }
                    } else if (records.type[i2] == 169) {
                        this.mFh.loadEFLinearFixedAll(records.efids[i2], obtainMessage(10));
                        try {
                            this.mLock.wait();
                        } catch (InterruptedException e2) {
                            loge("Interrupted Exception in readEmailFileAndWait");
                        }
                    }
                    if (this.mAnrFileRecord == null) {
                        loge("Error: ANR file is empty");
                        records.efids[i2] = 0;
                    } else {
                        records.record.put(Integer.valueOf(records.efids[i2]), this.mAnrFileRecord);
                        this.mAnrFileRecord = null;
                    }
                    i2++;
                    i = 1;
                }
                handleReadFileResult(records);
                setSubjectIndex(1, recNum, records);
                setSubjectUsedNum(1, recNum);
            }
        } catch (IndexOutOfBoundsException e3) {
            loge("readAnrFileAndWait IndexOutOfBoundsException");
        }
    }

    private void handleReadFileResult(SubjectIndexOfAdn records) {
        ArrayList<Integer> efs = new ArrayList<>();
        if (records == null || records.efids == null) {
            logd("handleReadFileResult records == null || records.efids == null");
            return;
        }
        for (int i = 0; i < records.efids.length; i++) {
            if (records.efids[i] != 0) {
                efs.add(Integer.valueOf(records.efids[i]));
            } else if (records.recordNumInIap != null && records.recordNumInIap.containsKey(Integer.valueOf(records.efids[i]))) {
                records.recordNumInIap.remove(Integer.valueOf(records.efids[i]));
            }
        }
        int[] validEf = new int[efs.size()];
        for (int i2 = 0; i2 < efs.size(); i2++) {
            validEf[i2] = efs.get(i2).intValue();
        }
        records.efids = validEf;
    }

    private void readGrpFileAndWait(int recNum, int offSet) {
        int[] size;
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(recNum).mFileIds;
            if (files == null || files.size() == 0 || files.get(USIM_EFGRP_TAG) == null) {
                return;
            }
            int efId = files.get(USIM_EFGRP_TAG).getEfid();
            if (this.mGrpFileRecord == null) {
                this.mGrpFileRecord = new ArrayList<>();
            }
            HashMap<Integer, int[]> map = this.mRecordsSize;
            if (map != null && map.containsKey(Integer.valueOf(efId))) {
                size = this.mRecordsSize.get(Integer.valueOf(efId));
            } else {
                size = readFileSizeAndWait(efId);
            }
            logd("readGrpFileAndWait offSet " + offSet);
            if (size == null || size.length < 3) {
                logd("readGrpFileAndWait size is error");
                return;
            }
            ArrayList<byte[]> fileRecord = initArraylist(size[0], size[2]);
            ArrayList<byte[]> arrayList3 = this.mGrpFileRecord;
            if (arrayList3 != null && arrayList3.size() == offSet) {
                this.mGrpFileRecord.addAll(offSet, fileRecord);
                for (int i = offSet; i < this.mPhoneBookRecords.size() && i < size[2] + offSet; i++) {
                    if (!TextUtils.isEmpty(this.mPhoneBookRecords.get(i).getAlphaTag()) || !TextUtils.isEmpty(this.mPhoneBookRecords.get(i).getNumber())) {
                        this.mPendingGrpLoads.addAndGet(1);
                        IccFileHandler iccFileHandler = this.mFh;
                        if (iccFileHandler != null && (iccFileHandler instanceof UniUsimFileHandler)) {
                            ((UniUsimFileHandler) iccFileHandler).loadEFLinearFixed(efId, (i + 1) - offSet, size[0], obtainMessage(8, i - offSet, offSet));
                        }
                    }
                }
                if (this.mPendingGrpLoads.get() == 0) {
                    this.mIsNotify.set(false);
                    return;
                }
                this.mIsNotify.set(true);
                try {
                    this.mLock.wait();
                    return;
                } catch (InterruptedException e) {
                    loge("Interrupted Exception in readGrpFileAndWait");
                    return;
                }
            }
            logd("readGrpFileAndWait mGrpFileRecord is null");
        } catch (IndexOutOfBoundsException e2) {
            loge("readGrpFileAndWait IndexOutOfBoundsException");
        }
    }

    private void updateAdnRecord(int num) {
        SubjectIndexOfAdn aasInfo;
        SubjectIndexOfAdn sneInfo;
        int numIapRec;
        ArrayList<byte[]> arrayList;
        byte[] record;
        String[] strArr;
        byte[] record2;
        int i;
        int numAdnRecs = this.mPhoneBookRecords.size();
        if (numAdnRecs == 0) {
            logd("mPhoneBookRecords size is 0");
            return;
        }
        this.mAdnRecordSizeArray[num] = numAdnRecs;
        for (int i2 = 0; i2 < num; i2++) {
            int[] iArr = this.mAdnRecordSizeArray;
            iArr[num] = iArr[num] - iArr[i2];
        }
        int i3 = 0;
        SubjectIndexOfAdn emailInfo = getSubjectIndex(0, num);
        SubjectIndexOfAdn anrInfo = getSubjectIndex(1, num);
        if (UniPhonebookUtils.isSupportOrange()) {
            SubjectIndexOfAdn aasInfo2 = getSubjectIndex(3, num);
            SubjectIndexOfAdn sneInfo2 = getSubjectIndex(4, num);
            aasInfo = aasInfo2;
            sneInfo = sneInfo2;
        } else {
            aasInfo = null;
            sneInfo = null;
        }
        ArrayList<byte[]> arrayList2 = this.mIapFileRecord;
        if (arrayList2 != null) {
            int numIapRec2 = arrayList2.size();
            this.mIapFileRecordArray[num] = this.mIapFileRecord;
            this.mIapRecordSizeArray[num] = numIapRec2;
            int i4 = this.mDoneAdnCount;
            numIapRec = numAdnRecs - i4 > numIapRec2 ? numIapRec2 : numAdnRecs - i4;
        } else {
            int numIapRec3 = this.mDoneAdnCount;
            numIapRec = numAdnRecs - numIapRec3;
        }
        logd("updateAdnRecord, numIapRec " + numIapRec + " mDoneAdnCount " + this.mDoneAdnCount);
        int i5 = this.mDoneAdnCount;
        while (true) {
            int i6 = this.mDoneAdnCount;
            if (i5 >= i6 + numIapRec) {
                break;
            }
            ArrayList<byte[]> arrayList3 = this.mIapFileRecord;
            if (arrayList3 == null) {
                record = null;
            } else {
                try {
                    byte[] record3 = arrayList3.get(i5 - i6);
                    record = record3;
                } catch (IndexOutOfBoundsException e) {
                    loge("Improper ICC card, No IAP record for ADN, continuing");
                    arrayList = null;
                }
            }
            if (this.mEmailsForAdnRec != null) {
                try {
                    UniAdnRecord rec = this.mPhoneBookRecords.get(i5);
                    int adnEfid = rec.getEfid();
                    int adnRecId = rec.getRecId();
                    int index = ((adnRecId + INVALID_SFI) & 255) | ((65535 & adnEfid) << 8);
                    ArrayList<String> emailList = null;
                    try {
                        emailList = this.mEmailsForAdnRec.get(index);
                    } catch (IndexOutOfBoundsException e2) {
                        loge("Improper ICC card, No Email record for ADN, continuing");
                    }
                    if (emailList != null) {
                        String[] emails = new String[emailList.size()];
                        System.arraycopy(emailList.toArray(), 0, emails, 0, emailList.size());
                        strArr = null;
                        setEmailandAnr(i5, emails, null);
                    } else {
                        strArr = null;
                    }
                } catch (IndexOutOfBoundsException e3) {
                    loge("updateAdnRecord IndexOutOfBoundsException");
                    arrayList = null;
                }
            } else {
                strArr = null;
            }
            if (anrInfo == null) {
                record2 = record;
                i = i5;
            } else {
                String[] strArr2 = strArr;
                record2 = record;
                i = i5;
                String anr = getAnr(num, anrInfo, aasInfo, i5, record2, i5 - this.mDoneAdnCount);
                setEmailandAnr(i, strArr2, anr);
            }
            if (sneInfo != null && UniPhonebookUtils.isSupportOrange()) {
                String snes = getSne(num, sneInfo, record2, i - this.mDoneAdnCount);
                if (snes != null) {
                    setSne(i, snes);
                }
            }
            i5 = i + 1;
            numIapRec = numIapRec;
            anrInfo = anrInfo;
            emailInfo = emailInfo;
            i3 = 0;
            this.mIapFileRecord = arrayList;
            this.mDoneAdnCount += numAdnRecs;
        }
        arrayList = null;
        this.mIapFileRecord = arrayList;
        this.mDoneAdnCount += numAdnRecs;
    }

    private void CheckRepeatType2Ef() {
        ArrayList<Integer> efs = getType2Ef(0);
        for (int i = 0; i < efs.size(); i++) {
            SetMapOfRepeatEfid(0, efs.get(i).intValue());
        }
        ArrayList<Integer> efs2 = getType2Ef(1);
        for (int i2 = 0; i2 < efs2.size(); i2++) {
            SetMapOfRepeatEfid(1, efs2.get(i2).intValue());
        }
    }

    private ArrayList<Integer> getType2Ef(int type) {
        ArrayList<Integer> efs = new ArrayList<>();
        LinkedList<SubjectIndexOfAdn> lst = null;
        switch (type) {
            case 0:
                lst = this.mEmailInfoFromPBR;
                break;
            case 1:
                lst = this.mAnrInfoFromPBR;
                break;
            case 3:
                lst = this.mAasInfoFromPBR;
                break;
            case 4:
                lst = this.mSneInfoFromPBR;
                break;
        }
        if (lst != null && lst.size() != 0) {
            for (int i = 0; i < lst.size(); i++) {
                SubjectIndexOfAdn index = lst.get(i);
                if (index != null && index.efids != null && index.type != null) {
                    for (int j = 0; j < index.efids.length; j++) {
                        if (index.type[j] == 169) {
                            boolean isAdd = true;
                            for (int k = 0; k < efs.size(); k++) {
                                if (efs.get(k).intValue() == index.efids[j]) {
                                    isAdd = false;
                                }
                            }
                            if (isAdd) {
                                efs.add(Integer.valueOf(index.efids[j]));
                            }
                        }
                    }
                }
            }
        }
        logd("getType2Ef  type " + type + " efs " + efs);
        return efs;
    }

    private void setUsedNumOfEfid(int type, int idx, int efid, Object obj) {
        LinkedList<SubjectIndexOfAdn> lst = null;
        switch (type) {
            case 0:
                lst = this.mEmailInfoFromPBR;
                break;
            case 1:
                lst = this.mAnrInfoFromPBR;
                break;
        }
        if (lst != null && lst.size() != 0) {
            for (int i = 0; i < lst.size(); i++) {
                SubjectIndexOfAdn index = lst.get(i);
                if (index != null && index.efids != null) {
                    for (int j = 0; j < index.efids.length; j++) {
                        if (index.efids[j] == efid) {
                            index.usedSet[idx] = obj;
                            setSubjectIndex(type, i, index);
                            break;
                        }
                    }
                }
            }
        }
    }

    private void updateAdnRecordNum() {
        for (int i = 0; i < this.mPhoneBookRecords.size(); i++) {
            UniAdnRecord adn = this.mPhoneBookRecords.get(i);
            if (adn != null) {
                adn.setRecordNumber(i + 1);
                ArrayList<byte[]> arrayList = this.mGrpFileRecord;
                if (arrayList != null && i < arrayList.size()) {
                    adn.setGrp(getGrp(i));
                }
            }
        }
    }

    private void updatePbcAndCc() {
        int[] size;
        ArrayList<PbrRecord> arrayList = this.mPbrRecords;
        if (arrayList == null) {
            logd("updatePbcAndCc, mPbrRecords is null");
            return;
        }
        try {
            SparseArray<File> files = arrayList.get(0).mFileIds;
            if (files == null || files.size() == 0 || files.get(USIM_EFPBC_TAG) == null) {
                logd("files is null or size is 0 or files donot contain pbc");
                return;
            }
            int efPbcId = files.get(USIM_EFPBC_TAG).getEfid();
            logd(" USIM_EFPBC_TAG = 0x" + Integer.toHexString(efPbcId).toUpperCase());
            int changeCounter = 0;
            if (this.mPbcFileRecord == null) {
                this.mPbcFileRecord = new ArrayList<>();
            }
            HashMap<Integer, int[]> map = this.mRecordsSize;
            if (map != null && map.containsKey(Integer.valueOf(efPbcId))) {
                size = this.mRecordsSize.get(Integer.valueOf(efPbcId));
            } else {
                int[] size2 = readFileSizeAndWait(efPbcId);
                size = size2;
            }
            if (size != null && size.length >= 3) {
                ArrayList<byte[]> fileRecord = initArraylist(size[0], size[2]);
                ArrayList<byte[]> arrayList2 = this.mPbcFileRecord;
                if (arrayList2 != null) {
                    arrayList2.addAll(0, fileRecord);
                    for (int i = 0; i < this.mPbcFileRecord.size() && i < this.mPhoneBookRecords.size(); i++) {
                        if (!TextUtils.isEmpty(this.mPhoneBookRecords.get(i).getAlphaTag()) || !TextUtils.isEmpty(this.mPhoneBookRecords.get(i).getNumber())) {
                            this.mPendingPbcLoads.addAndGet(1);
                            IccFileHandler iccFileHandler = this.mFh;
                            if (iccFileHandler != null && (iccFileHandler instanceof UniUsimFileHandler)) {
                                ((UniUsimFileHandler) iccFileHandler).loadEFLinearFixed(efPbcId, i + 1, size[0], obtainMessage(14, i, 0));
                            }
                        }
                    }
                    if (this.mPendingPbcLoads.get() == 0) {
                        this.mIsNotify.set(false);
                    } else {
                        this.mIsNotify.set(true);
                        try {
                            this.mLock.wait();
                        } catch (InterruptedException e) {
                            loge("Interrupted Exception in updatePbcAndCc");
                        }
                    }
                    for (int i2 = 0; i2 < size[2]; i2++) {
                        ArrayList<byte[]> arrayList3 = this.mPbcFileRecord;
                        if (arrayList3 != null) {
                            byte[] temp = arrayList3.get(i2);
                            if (temp != null && temp.length > 0 && (temp[0] & INVALID_BYTE) == 1) {
                                byte[] data = {0, 0};
                                this.mFh.updateEFLinearFixed(efPbcId, i2 + 1, data, (String) null, obtainMessage(13));
                                changeCounter++;
                            }
                        } else {
                            logd("readIapFileAndWait: mPbcFileRecord is null");
                            return;
                        }
                    }
                    logd("update EFpbc end, changeCounter " + changeCounter);
                    if (changeCounter > 0) {
                        this.mFh.loadEFTransparent(UniIccConstants.EF_CC, 2, obtainMessage(12, changeCounter, 0));
                        return;
                    }
                    return;
                }
                logd("readIapFileAndWait: mPbcFileRecord is null");
            }
        } catch (IndexOutOfBoundsException e2) {
            loge("updatePbcAndCc IndexOutOfBoundsException");
        }
    }

    public ArrayList<String> loadGasFromUsim() {
        if (!this.mGasList.isEmpty()) {
            return this.mGasList;
        }
        if (this.mGasFileRecord == null) {
            readGasFileAndWait(0);
        }
        ArrayList<byte[]> arrayList = this.mGasFileRecord;
        if (arrayList != null) {
            int gasSize = arrayList.size();
            for (int i = 0; i < gasSize; i++) {
                ArrayList<byte[]> arrayList2 = this.mGasFileRecord;
                byte[] gasRec = arrayList2 != null ? arrayList2.get(i) : null;
                if (gasRec != null) {
                    this.mGasList.add(IccUtils.adnStringFieldToString(gasRec, 0, gasRec.length));
                }
            }
            logd("loadGasFromUsim mGasList: " + this.mGasList + ", Gas size: " + gasSize);
            return this.mGasList;
        }
        loge("Error: mGasFileRecord file is empty");
        return null;
    }

    private void readGasFileAndWait(int recNum) {
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            this.mIsPbrFileExisting = false;
            logd("Error: Pbr file is empty");
            return;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(recNum).mFileIds;
            if (files == null || files.size() == 0 || files.get(USIM_EFGAS_TAG) == null) {
                logd("files is null or size is 0 or files donot contain gas");
                return;
            }
            synchronized (this.mLock) {
                this.mFh.loadEFLinearFixedAll(files.get(USIM_EFGAS_TAG).getEfid(), obtainMessage(9));
                logd("readGasFileAndWait wait for notify");
                try {
                    this.mLock.wait();
                } catch (InterruptedException e) {
                    loge("Interrupted Exception in readGasFileAndWait");
                }
            }
        } catch (IndexOutOfBoundsException e2) {
            loge("readGasFileAndWait IndexOutOfBoundsException");
        }
    }

    public int[] getEmailRecordSizeArray() {
        return this.mEmailRecordSizeArray;
    }

    public int[] getIapRecordSizeArray() {
        return this.mIapRecordSizeArray;
    }

    public void setPhoneBookRecords(int index, UniAdnRecord adn) {
        this.mPhoneBookRecords.set(index, adn);
    }

    public int getPhoneBookRecordsNum() {
        return this.mPhoneBookRecords.size();
    }

    public synchronized int[] getAdnRecordsSize() {
        try {
            synchronized (this.mLock) {
                try {
                    int[] iArr = this.mAdnRecordSize;
                    if (iArr != null) {
                        return iArr;
                    }
                    ArrayList<PbrRecord> arrayList = this.mPbrRecords;
                    if (arrayList == null || arrayList.size() == 0) {
                        readPbrFileAndWait();
                    }
                    ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
                    if (arrayList2 != null && arrayList2.size() != 0) {
                        int numRecs = this.mPbrRecords.size();
                        this.mAdnRecordSize = new int[3];
                        for (int index = 0; index < 3; index++) {
                            this.mAdnRecordSize[index] = 0;
                        }
                        for (int i = 0; i < numRecs; i++) {
                            int[] size = readAdnFileSizeAndWait(i);
                            if (size != null) {
                                int[] iArr2 = this.mAdnRecordSize;
                                if (iArr2 != null) {
                                    int i2 = iArr2[0];
                                    if (i2 <= 0 || size[0] <= i2) {
                                        i2 = size[0];
                                    }
                                    iArr2[0] = i2;
                                    iArr2[1] = iArr2[1] + size[1];
                                    iArr2[2] = iArr2[2] + size[2];
                                } else {
                                    logd("getAdnRecordsSize mAdnRecordSize is null");
                                    return null;
                                }
                            } else if (i == 0) {
                                logd("getAdnRecordsSize size is null");
                                return null;
                            }
                        }
                        return this.mAdnRecordSize;
                    }
                    return null;
                } catch (Throwable th) {
                    th = th;
                    throw th;
                }
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }

    public int[] getEfFilesFromUsim() {
        int len = this.mPbrRecords.size();
        int[] efids = new int[len];
        for (int i = 0; i < len; i++) {
            try {
                SparseArray<File> files = this.mPbrRecords.get(i).mFileIds;
                efids[i] = files.get(USIM_EFADN_TAG).getEfid();
                logd("getEfFilesFromUsim " + efids[i]);
            } catch (IndexOutOfBoundsException e) {
                loge("getEfFilesFromUsim IndexOutOfBoundsException");
            }
        }
        return efids;
    }

    public boolean isPbrFileExisting() {
        logd("mIsPbrFileExisting " + this.mIsPbrFileExisting);
        return this.mIsPbrFileExisting;
    }

    public boolean isContainAdnInPbr() {
        logd("isContainAdnInPbr " + this.mIsContainAdnInPbr);
        return this.mIsContainAdnInPbr;
    }

    public HashMap<Integer, int[]> getRecordsSize() {
        return this.mRecordsSize;
    }

    public int getGrpCount() {
        return this.mGrpCount;
    }

    public ArrayList<String> loadAasFromUsim() {
        logd("loadAasFromUsim");
        if (!this.mAasList.isEmpty()) {
            return this.mAasList;
        }
        if (this.mAasFileRecord == null) {
            readAasFileAndWait(0);
        }
        ArrayList<byte[]> arrayList = this.mAasFileRecord;
        if (arrayList == null) {
            loge("Error: mAasFileRecord file is empty");
            return null;
        }
        int aasSize = arrayList.size();
        logd("getAas size " + aasSize);
        for (int i = 0; i < aasSize; i++) {
            byte[] aasRec = this.mAasFileRecord.get(i);
            this.mAasList.add(IccUtils.adnStringFieldToString(aasRec, 0, aasRec.length));
        }
        logd("loadAasFromUsim mAasList: " + this.mAasList);
        return this.mAasList;
    }

    public void readAasFileAndWait(int recNum) {
        logd("readAasFileAndWait recNum is " + recNum);
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(recNum).mFileIds;
            if (files == null || files.size() == 0) {
                logd("readAasFileAndWait  fileIds == null");
                return;
            }
            logd("readAasFileAndWait mAasInfoFromPBR !=null fileIds.size()  " + files.size());
            if (files.get(USIM_EFAAS_TAG) != null) {
                SubjectIndexOfAdn records = getSubjectIndex(3, recNum);
                if (records == null) {
                    logd("readAasFileAndWait, records is null");
                    return;
                }
                records.record = new HashMap();
                if (records.efids == null || records.efids.length == 0) {
                    logd("readAasFileAndWait  records.efids == null || records.efids.length == 0");
                    return;
                }
                synchronized (this.mLock) {
                    this.mFh.loadEFLinearFixedAll(records.efids[0], obtainMessage(6));
                    logd("readAasFileAndWait wait for notify");
                    try {
                        this.mLock.wait();
                    } catch (InterruptedException e) {
                        loge("Interrupted Exception in readAasFileAndWait");
                    }
                }
                if (this.mAasFileRecord == null) {
                    loge("Error: Aas file is empty");
                    records.efids[0] = 0;
                } else {
                    records.record.put(Integer.valueOf(records.efids[0]), this.mAasFileRecord);
                }
                handleReadFileResult(records);
                setSubjectIndex(3, recNum, records);
                setSubjectUsedNum(3, recNum);
            }
        } catch (IndexOutOfBoundsException e2) {
            loge("readAasFileAndWait IndexOutOfBoundsException");
        }
    }

    public int findEFAasInfo() {
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return INVALID_SFI;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(0).mFileIds;
            if (files == null || files.size() == 0) {
                logd("findEFAasInfo fileIds == null");
                return INVALID_SFI;
            }
            if (files.get(USIM_EFAAS_TAG) != null) {
                return files.get(USIM_EFAAS_TAG).getEfid();
            }
            return 0;
        } catch (IndexOutOfBoundsException e) {
            loge("findEFAasInfo IndexOutOfBoundsException");
            return INVALID_SFI;
        }
    }

    public void updateAasList(String aas, int aasIndex) {
        if (this.mAasList.isEmpty()) {
            return;
        }
        this.mAasList.set(aasIndex + INVALID_SFI, aas);
        for (String aasStr : this.mAasList) {
            logd("updateAasList aasStr== " + aasStr);
        }
    }

    private String getAas(SubjectIndexOfAdn aasInfo, int adnNum) {
        logd("getAas adnNum: " + adnNum);
        int adnNum2 = adnNum + INVALID_SFI;
        if (aasInfo == null) {
            return null;
        }
        if (aasInfo.efids == null || aasInfo.efids.length == 0) {
            logd("getAas aasInfo.efids == null || aasInfo.efids.length == 0");
            return null;
        }
        logd("aasInfo.efids is " + aasInfo.efids);
        String aas = getTypeAas(aasInfo, adnNum2, aasInfo.efids[0]);
        return aas;
    }

    private String getTypeAas(SubjectIndexOfAdn aasInfo, int adnNum, int efid) {
        if (aasInfo == null || aasInfo.record == null) {
            return null;
        }
        ArrayList<byte[]> arrayList = aasInfo.record.get(Integer.valueOf(efid));
        this.mAasFileRecord = arrayList;
        if (arrayList == null) {
            return null;
        }
        logd("getTypeAas size " + this.mAasFileRecord.size());
        String aas = readAasRecord(adnNum);
        logd("getTypeAas, aas " + aas);
        if (TextUtils.isEmpty(aas)) {
            return null;
        }
        return aas;
    }

    private String readAasRecord(int recNum) {
        try {
            byte[] aasRec = this.mAasFileRecord.get(recNum);
            String aas = IccUtils.adnStringFieldToString(aasRec, 0, aasRec.length);
            return aas;
        } catch (IndexOutOfBoundsException e) {
            loge("readAasRecord IndexOutOfBoundsException");
            return null;
        }
    }

    private void setAas(int adnNum, String aas) {
        logd("setAas, adnNum: " + adnNum);
        UniAdnRecord rec = this.mPhoneBookRecords.size() > adnNum ? this.mPhoneBookRecords.get(adnNum) : null;
        if (rec == null) {
            rec = new UniAdnRecord("", "");
        }
        rec.setAas(aas);
        logd("setAas, rec name: " + rec.getAlphaTag() + ", num: " + rec.getNumber() + ", aas = " + aas);
        try {
            this.mPhoneBookRecords.set(adnNum, rec);
        } catch (IndexOutOfBoundsException e) {
            logd("setEmailandAnr IndexOutOfBoundsException");
        }
    }

    private void readSneFileAndWait(int recNum) {
        File sne;
        logd("readSnelFileAndWait recNum = " + recNum);
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(recNum).mFileIds;
            if (files != null && files.size() != 0 && (sne = files.get(USIM_EFSNE_TAG)) != null) {
                int efid = sne.getEfid();
                logd("EF_SNE exists in PBR. efid = 0x" + Integer.toHexString(efid).toUpperCase());
                SubjectIndexOfAdn records = getSubjectIndex(4, recNum);
                if (records == null) {
                    logd("readSnelFileAndWait  records == null ");
                    return;
                }
                this.mFh.loadEFLinearFixedAll(efid, obtainMessage(7));
                try {
                    this.mLock.wait();
                } catch (InterruptedException e) {
                    loge("Interrupted Exception in readSneFileAndWait");
                }
                if (this.mSneFileRecord == null) {
                    loge("Error: sne file is empty");
                    setSubjectIndex(4, recNum, null);
                    return;
                }
                records.record = new HashMap();
                records.record.put(Integer.valueOf(efid), this.mSneFileRecord);
                logd("readSnelFileAndWait recNum " + recNum + "  mSneFileRecord  size " + this.mSneFileRecord.size());
                setSubjectIndex(4, recNum, records);
                setSubjectUsedNum(4, recNum);
                this.mSneFileRecord = null;
            }
        } catch (IndexOutOfBoundsException e2) {
            loge("readSneFileAndWait IndexOutOfBoundsException");
        }
    }

    private String getSne(int num, SubjectIndexOfAdn sneInfo, byte[] record, int adnNum) {
        logd("getSne sneNum " + adnNum + " num " + num);
        String sneGroup = null;
        String sne = null;
        if (sneInfo == null || sneInfo.record == null) {
            return null;
        }
        if (sneInfo.efids == null || sneInfo.efids.length == 0) {
            logd("getSne sneInfo.efids == null || sneInfo.efids.length == 0");
            return null;
        }
        for (int i = 0; i < sneInfo.efids.length; i++) {
            if (sneInfo.type[i] == 168) {
                sne = getType1Sne(num, sneInfo, adnNum, sneInfo.efids[i]);
            }
            if (sneInfo.type[i] == 169 && sneInfo.recordNumInIap != null) {
                sne = getType2Sne(num, sneInfo, record, adnNum, sneInfo.efids[i]);
            }
            if (i == 0) {
                sneGroup = sne;
            } else {
                sneGroup = sneGroup + ";" + sne;
            }
        }
        return sneGroup;
    }

    private String getType1Sne(int num, SubjectIndexOfAdn sneInfo, int adnNum, int efid) {
        ArrayList<byte[]> arrayList = sneInfo.record.get(Integer.valueOf(efid));
        this.mSneFileRecord = arrayList;
        if (arrayList == null) {
            return null;
        }
        logd("getType1Sne size " + this.mSneFileRecord.size());
        String snes = readSneRecord(adnNum);
        logd("getType1Sne, snes " + snes);
        if (TextUtils.isEmpty(snes)) {
            logd("getType1Sne, snes is null");
            return null;
        }
        return snes;
    }

    private String getType2Sne(int num, SubjectIndexOfAdn sneInfo, byte[] record, int adnNum, int efid) {
        int index;
        String snes = null;
        logd(" getType2Sne begin, sneInfo.recordNumInIap.size() " + sneInfo.recordNumInIap.size() + " adnNum " + adnNum + " efid " + efid);
        if (record == null || (index = getUsedNumSetIndex(efid, sneInfo)) == INVALID_SFI) {
            return null;
        }
        this.mSneTagNumberInIap = sneInfo.recordNumInIap.get(Integer.valueOf(efid)).intValue();
        ArrayList<byte[]> arrayList = sneInfo.record.get(Integer.valueOf(efid));
        this.mSneFileRecord = arrayList;
        if (arrayList == null) {
            return null;
        }
        int recNum = record[this.mSneTagNumberInIap] & INVALID_BYTE;
        int recNum2 = recNum == 255 ? INVALID_SFI : recNum;
        logd("getType2Sne  iap recNum == " + recNum2);
        if (recNum2 != INVALID_SFI) {
            snes = readSneRecord(recNum2 + INVALID_SFI);
            logd("getType2Sne, snes " + snes);
            if (TextUtils.isEmpty(snes)) {
                logd("getType2Sne, snes is null");
                setIapFileRecord(num, adnNum, INVALID_BYTE, this.mSneTagNumberInIap);
                return null;
            }
            Set<Integer> set = (Set) sneInfo.usedSet[index];
            logd("getType2Sne  size (0)" + set.size() + " index " + index);
            set.add(new Integer(recNum2));
            sneInfo.usedSet[index] = set;
            logd("getType2Sne  size (1)" + set.size());
            setSubjectIndex(4, num, sneInfo);
        }
        return snes;
    }

    private String readSneRecord(int recNum) {
        try {
            byte[] sneRec = this.mSneFileRecord.get(recNum);
            if (sneRec.length < 2) {
                logd("readSneRecord, sneRec is abnormal");
                return null;
            }
            String sne = IccUtils.adnStringFieldToString(sneRec, 0, sneRec.length - 2);
            return sne;
        } catch (IndexOutOfBoundsException e) {
            return null;
        }
    }

    private void setSne(int adnNum, String snes) {
        UniAdnRecord rec = this.mPhoneBookRecords.size() > adnNum ? this.mPhoneBookRecords.get(adnNum) : null;
        if (rec == null) {
            rec = new UniAdnRecord("", "");
        }
        rec.setSne(snes);
        try {
            this.mPhoneBookRecords.set(adnNum, rec);
        } catch (IndexOutOfBoundsException e) {
            logd("setSne IndexOutOfBoundsException");
        }
    }

    public int getSneSize() {
        return this.mSneEfSize;
    }

    public int[] getSneLength() {
        int[] sneSize;
        synchronized (this.mLock) {
            sneSize = readSneFileSizeAndWait();
        }
        return sneSize;
    }

    private int[] readSneFileSizeAndWait() {
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return null;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(0).mFileIds;
            if (files == null || files.size() == 0 || files.get(USIM_EFSNE_TAG) == null) {
                return null;
            }
            int efid = files.get(USIM_EFSNE_TAG).getEfid();
            HashMap<Integer, int[]> map = this.mRecordsSize;
            if (map != null && map.containsKey(Integer.valueOf(efid))) {
                int[] size = this.mRecordsSize.get(Integer.valueOf(efid));
                return size;
            }
            int[] size2 = readFileSizeAndWait(efid);
            return size2;
        } catch (IndexOutOfBoundsException e) {
            loge("readSneFileSizeAndWait IndexOutOfBoundsException");
            return null;
        }
    }

    public int findEFSneInfo(int index) {
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return INVALID_SFI;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(index).mFileIds;
            if (files == null || files.size() == 0) {
                logd("findEFSNEInfo  fileIds is null");
                return INVALID_SFI;
            }
            if (files.get(USIM_EFSNE_TAG) != null) {
                return files.get(USIM_EFSNE_TAG).getEfid();
            }
            return 0;
        } catch (IndexOutOfBoundsException e) {
            loge("findEFSneInfo IndexOutOfBoundsException");
            return INVALID_SFI;
        }
    }

    public void updateUidForAdn(int adnEf, int recNum, int adnIndex, UniAdnRecord adn) {
        if (!adn.isEmpty()) {
            if (getEfIdByTag(recNum, USIM_EFUID_TAG) <= 0) {
                logd("get EfUID failed,EFUID is not exist");
            } else {
                this.mFh.loadEFTransparent(UniIccConstants.EF_CC, 2, obtainMessage(12, 1, 1));
            }
        }
    }

    private boolean isPbrFilesSpecial(int recNum) {
        int[] result;
        if (recNum > 0) {
            logd("Not first Pbr file");
            return false;
        }
        synchronized (this.mLock) {
            ArrayList<PbrRecord> arrayList = this.mPbrRecords;
            if (arrayList == null || arrayList.size() == 0) {
                readPbrFileAndWait();
            }
        }
        ArrayList<PbrRecord> arrayList2 = this.mPbrRecords;
        if (arrayList2 == null || arrayList2.size() == 0) {
            loge("Error: Pbr file is empty");
            return true;
        }
        try {
            SparseArray<File> files = this.mPbrRecords.get(recNum).mFileIds;
            if (files == null || files.size() == 0) {
                return true;
            }
            return files.get(USIM_EFADN_TAG) == null && (result = this.mAdnCache.getEFAdnRecordSize()) != null && result.length > 2 && result[2] > 0;
        } catch (IndexOutOfBoundsException e) {
            loge("isPbrFilesSpecial IndexOutOfBoundsException");
            return true;
        }
    }

    private ArrayList<byte[]> initArraylist(int fileLength, int fileSize) {
        ArrayList<byte[]> fileRecord = new ArrayList<>();
        byte[] emptyValue = new byte[fileLength];
        for (byte b : emptyValue) {
        }
        for (int i = 0; i < fileSize; i++) {
            fileRecord.add(i, emptyValue);
        }
        return fileRecord;
    }
}
