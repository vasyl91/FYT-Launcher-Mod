package com.android.internal.telephony;

import android.os.AsyncResult;
import android.os.Bundle;
import android.os.Message;
import android.os.RemoteException;
import android.telephony.ims.ImsReasonInfo;
import android.telephony.ims.ImsSsInfo;
import android.util.Log;
import com.android.ims.ImsException;
import com.android.ims.internal.IImsUt;
import com.android.ims.internal.IImsUtEx;
import com.android.ims.internal.IImsUtListenerEx;
import com.android.ims.internal.ImsCallForwardInfoEx;
import com.android.ims.internal.ImsManagerEx;
import java.util.HashMap;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UtExProxy {
    private static final String LOG_TAG = "UtExProxy";
    private static UtExProxy mUtExProxy = null;
    private IImsUtEx mIImsUtEx;
    private Object mLockObj = new Object();
    private HashMap<Integer, Message> mPendingCmds = new HashMap<>();
    private final IImsUtListenerEx.Stub mImsUtListenerExBinder = new IImsUtListenerEx.Stub() { // from class: com.android.internal.telephony.UtExProxy.1
        public void utConfigurationUpdated(IImsUt ut, int id) {
            Integer key = Integer.valueOf(id);
            synchronized (UtExProxy.this.mLockObj) {
                UtExProxy utExProxy = UtExProxy.this;
                utExProxy.sendSuccessReport((Message) utExProxy.mPendingCmds.get(key));
                UtExProxy.this.mPendingCmds.remove(key);
            }
        }

        public void utConfigurationUpdateFailed(IImsUt ut, int id, ImsReasonInfo error) {
            Integer key = Integer.valueOf(id);
            synchronized (UtExProxy.this.mLockObj) {
                UtExProxy utExProxy = UtExProxy.this;
                utExProxy.sendFailureReport((Message) utExProxy.mPendingCmds.get(key), error);
                UtExProxy.this.mPendingCmds.remove(key);
            }
        }

        public void utConfigurationQueried(IImsUt ut, int id, Bundle ssInfo) {
            Integer key = Integer.valueOf(id);
            synchronized (UtExProxy.this.mLockObj) {
                UtExProxy utExProxy = UtExProxy.this;
                utExProxy.sendSuccessReport((Message) utExProxy.mPendingCmds.get(key), ssInfo);
                UtExProxy.this.mPendingCmds.remove(key);
            }
        }

        public void utConfigurationQueryFailed(IImsUt ut, int id, ImsReasonInfo error) {
            Integer key = Integer.valueOf(id);
            synchronized (UtExProxy.this.mLockObj) {
                UtExProxy utExProxy = UtExProxy.this;
                utExProxy.sendFailureReport((Message) utExProxy.mPendingCmds.get(key), error);
                UtExProxy.this.mPendingCmds.remove(key);
            }
        }

        public void utConfigurationCallBarringQueried(IImsUt ut, int id, ImsSsInfo[] cbInfo) {
            Integer key = Integer.valueOf(id);
            synchronized (UtExProxy.this.mLockObj) {
                UtExProxy utExProxy = UtExProxy.this;
                utExProxy.sendSuccessReport((Message) utExProxy.mPendingCmds.get(key), cbInfo);
                UtExProxy.this.mPendingCmds.remove(key);
            }
        }

        public void utConfigurationCallForwardQueried(IImsUt ut, int id, ImsCallForwardInfoEx[] cfInfo) {
            Integer key = Integer.valueOf(id);
            synchronized (UtExProxy.this.mLockObj) {
                UtExProxy utExProxy = UtExProxy.this;
                utExProxy.sendSuccessReport((Message) utExProxy.mPendingCmds.get(key), cfInfo);
                UtExProxy.this.mPendingCmds.remove(key);
            }
        }

        public void utConfigurationCallWaitingQueried(IImsUt ut, int id, ImsSsInfo[] cwInfo) {
            Integer key = Integer.valueOf(id);
            synchronized (UtExProxy.this.mLockObj) {
                UtExProxy utExProxy = UtExProxy.this;
                utExProxy.sendSuccessReport((Message) utExProxy.mPendingCmds.get(key), cwInfo);
                UtExProxy.this.mPendingCmds.remove(key);
            }
        }

        public void utConfigurationCallBarringFailed(int id, int[] result, int errorCode) {
            Integer key = Integer.valueOf(id);
            synchronized (UtExProxy.this.mLockObj) {
                UtExProxy utExProxy = UtExProxy.this;
                utExProxy.sendFailureReport((Message) utExProxy.mPendingCmds.get(key), result, errorCode);
                UtExProxy.this.mPendingCmds.remove(key);
            }
        }

        public void utConfigurationCallBarringResult(int id, int[] result) {
            Integer key = Integer.valueOf(id);
            synchronized (UtExProxy.this.mLockObj) {
                UtExProxy utExProxy = UtExProxy.this;
                utExProxy.sendSuccessReport((Message) utExProxy.mPendingCmds.get(key), result);
                UtExProxy.this.mPendingCmds.remove(key);
            }
        }
    };
    private int mPhoneId = 0;

    private UtExProxy() {
    }

    public static synchronized UtExProxy getInstance() {
        if (mUtExProxy == null) {
            mUtExProxy = new UtExProxy();
        }
        return mUtExProxy;
    }

    public void setPhoneId(int phoneId) {
        if (this.mPhoneId != phoneId) {
            this.mPhoneId = phoneId;
            this.mIImsUtEx = null;
        }
    }

    private IImsUtEx getIImsUtEx() {
        if (this.mIImsUtEx == null) {
            IImsUtEx iImsUtEx = ImsManagerEx.getIImsUtEx();
            this.mIImsUtEx = iImsUtEx;
            if (iImsUtEx != null) {
                try {
                    iImsUtEx.setListenerEx(this.mPhoneId, this.mImsUtListenerExBinder);
                } catch (RemoteException e) {
                }
            }
        }
        return this.mIImsUtEx;
    }

    public void setCallForwardingOption(int commandInterfaceCFAction, int commandInterfaceCFReason, int serviceClass, String dialingNumber, int timerSeconds, String ruleSet, Message result) {
        synchronized (this.mLockObj) {
            try {
                int id = getIImsUtEx().setCallForwardingOption(this.mPhoneId, commandInterfaceCFAction, commandInterfaceCFReason, serviceClass, dialingNumber, timerSeconds, ruleSet);
                if (id < 0) {
                    sendFailureReport(result, new ImsReasonInfo(802, 0));
                } else {
                    this.mPendingCmds.put(Integer.valueOf(id), result);
                }
            } catch (RemoteException e) {
                sendFailureReport(result, new ImsReasonInfo(802, 0));
            }
        }
    }

    public void getCallForwardingOption(int commandInterfaceCFReason, int serviceClass, String ruleSet, Message result) {
        synchronized (this.mLockObj) {
            try {
                int id = getIImsUtEx().getCallForwardingOption(this.mPhoneId, commandInterfaceCFReason, serviceClass, ruleSet);
                if (id < 0) {
                    sendFailureReport(result, new ImsReasonInfo(802, 0));
                } else {
                    this.mPendingCmds.put(Integer.valueOf(id), result);
                }
            } catch (RemoteException e) {
                sendFailureReport(result, new ImsReasonInfo(802, 0));
            }
        }
    }

    public void changeBarringPassword(String facility, String oldPwd, String newPwd, Message result) {
        synchronized (this.mLockObj) {
            try {
                int id = getIImsUtEx().changeBarringPassword(this.mPhoneId, facility, oldPwd, newPwd);
                if (id < 0) {
                    sendFailureReport(result, null, CommandException.Error.GENERIC_FAILURE.ordinal());
                } else {
                    this.mPendingCmds.put(Integer.valueOf(id), result);
                }
            } catch (RemoteException e) {
                sendFailureReport(result, new ImsReasonInfo(802, 0));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendFailureReport(Message result, ImsReasonInfo error) {
        String errorString;
        if (result == null || error == null) {
            return;
        }
        if (error.mExtraMessage == null) {
            errorString = new String("IMS UT exception");
        } else {
            errorString = new String(error.mExtraMessage);
        }
        AsyncResult.forMessage(result, (Object) null, getCommandException(new ImsException(errorString, error.mCode)));
        result.sendToTarget();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendSuccessReport(Message result) {
        if (result == null) {
            return;
        }
        AsyncResult.forMessage(result, (Object) null, (Throwable) null);
        result.sendToTarget();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendSuccessReport(Message result, Object ssInfo) {
        if (result == null) {
            return;
        }
        AsyncResult.forMessage(result, ssInfo, (Throwable) null);
        result.sendToTarget();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendFailureReport(Message result, Object ssInfo, int errorCode) {
        if (result == null) {
            return;
        }
        AsyncResult.forMessage(result, ssInfo, CommandException.fromRilErrno(errorCode));
        result.sendToTarget();
    }

    private CommandException getCommandException(Throwable e) {
        if (e instanceof ImsException) {
            CommandException ex = getCommandException(((ImsException) e).getCode(), e.getMessage());
            return ex;
        }
        Log.d(LOG_TAG, "getCommandException generic failure");
        CommandException ex2 = new CommandException(CommandException.Error.GENERIC_FAILURE);
        return ex2;
    }

    private CommandException getCommandException(int code, String errorString) {
        Log.d(LOG_TAG, "getCommandException code= " + code + ", errorString= " + errorString);
        CommandException.Error error = CommandException.Error.GENERIC_FAILURE;
        switch (code) {
            case 241:
                error = CommandException.Error.FDN_CHECK_FAILURE;
                break;
            case 801:
                error = CommandException.Error.REQUEST_NOT_SUPPORTED;
                break;
            case 802:
                error = CommandException.Error.RADIO_NOT_AVAILABLE;
                break;
            case 821:
                error = CommandException.Error.PASSWORD_INCORRECT;
                break;
        }
        return new CommandException(error, errorString);
    }
}
