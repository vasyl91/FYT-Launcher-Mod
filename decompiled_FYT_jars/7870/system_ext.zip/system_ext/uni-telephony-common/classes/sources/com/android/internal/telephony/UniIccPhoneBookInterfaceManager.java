package com.android.internal.telephony;

import android.os.AsyncResult;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.telephony.TelephonyManager;
import com.android.internal.telephony.phonebook.UniAdnRecord;
import com.android.internal.telephony.phonebook.UniAdnRecordCache;
import com.android.internal.telephony.phonebook.UniIccPBForOperationException;
import com.android.internal.telephony.phonebook.UniPhoneBookLog;
import com.android.internal.telephony.phonebook.UniUsimPhoneBookManager;
import com.android.internal.telephony.uicc.IccCardApplicationStatus;
import com.android.internal.telephony.uicc.IccFileHandler;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.RuimFileHandler;
import com.android.internal.telephony.uicc.RuimRecords;
import com.android.internal.telephony.uicc.SIMRecords;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.uicc.UiccController;
import com.android.internal.telephony.uicc.UiccPort;
import com.android.internal.telephony.uicc.UniRuimRecords;
import com.android.internal.telephony.uicc.UniSIMRecords;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniIccPhoneBookInterfaceManager extends IccPhoneBookInterfaceManager {
    private static final int EVENT_ICC_CHANGED = 100;
    private static final int EVENT_RECORDS_LOADED = 101;
    private static final String TAG = "UniIccPhoneBookIM";
    private final HashMap<Integer, UniRequest> mAllLoadRequest;
    private UpdateThreadHandler mBaseHandler;
    private CachePHBHandler mCachePHBHandler;
    private HandlerThread mCachePHBThread;
    private IccRecords mIccRecords;
    private boolean mIsPhonebookLoading;
    private Object mLockForReadSizes;
    private Phone mPhone;
    private int mPhoneId;
    private UiccCardApplication mUiccApplication;
    private UiccController mUiccController;
    private UiccPort mUiccPort;
    private UniAdnRecordCache mUniAdnCache;
    private HandlerThread mUpdateThread;

    private static final class UniRequest {
        Object mResult;
        AtomicBoolean mStatus;

        private UniRequest() {
            this.mStatus = new AtomicBoolean(false);
            this.mResult = null;
        }
    }

    public UniIccPhoneBookInterfaceManager(Phone phone) {
        super(phone);
        this.mPhoneId = -1;
        this.mIsPhonebookLoading = false;
        this.mLockForReadSizes = new Object();
        this.mIccRecords = null;
        this.mUiccApplication = null;
        this.mUiccPort = null;
        this.mAllLoadRequest = new HashMap<>();
        this.mPhone = phone;
        createUpdateThread();
        IccRecords r = this.mPhone.getIccRecords();
        if (r != null) {
            if (r instanceof RuimRecords) {
                IccRecords records3gpp = UiccController.getInstance().getIccRecords(phone.getPhoneId(), 1);
                this.mUniAdnCache = ((UniRuimRecords) (records3gpp != null ? records3gpp : r)).getUniAdnRecordCache();
            } else if (r instanceof SIMRecords) {
                this.mUniAdnCache = ((UniSIMRecords) r).getUniAdnRecordCache();
            }
        }
        this.mUiccController = UiccController.getInstance();
        registerForIccChanged(phone);
    }

    protected class UpdateThreadHandler extends Handler {
        public UpdateThreadHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            int simIndex;
            AsyncResult ar = (AsyncResult) msg.obj;
            UniRequest request = (UniRequest) ar.userObj;
            switch (msg.what) {
                case 1:
                    int[] recordSize = null;
                    if (ar.exception == null) {
                        recordSize = (int[]) ar.result;
                        UniIccPhoneBookInterfaceManager.this.log("EVENT_GET_SIZE_DONE Size: " + Arrays.toString(recordSize));
                    } else {
                        UniIccPhoneBookInterfaceManager.this.log("EVENT_GET_SIZE_DONE failed, ex: " + ar.exception);
                    }
                    notifyPending(request, recordSize);
                    break;
                case 2:
                    Object records = null;
                    if (ar.exception == null) {
                        UniIccPhoneBookInterfaceManager.this.log("EVENT_LOAD_DONE, msg.arg1 = " + msg.arg1);
                        records = (List) ar.result;
                    } else {
                        UniIccPhoneBookInterfaceManager.this.log("Cannot load ADN records");
                    }
                    notifyPending(request, records);
                    break;
                case 3:
                    boolean success = ar.exception == null;
                    if (success) {
                        simIndex = UniIccPhoneBookInterfaceManager.this.getInsertIndex();
                    } else {
                        UniIccPhoneBookInterfaceManager.this.log("EVENT_UPDATE_DONE failed; ex: " + ar.exception);
                        if (ar.exception instanceof UniIccPBForOperationException) {
                            simIndex = ar.exception.mErrorCode;
                        } else {
                            simIndex = -1;
                        }
                    }
                    UniIccPhoneBookInterfaceManager.this.log("EVENT_UPDATE_DONE simIndex: " + simIndex);
                    notifyPending(request, Integer.valueOf(simIndex));
                    break;
            }
        }

        private void notifyPending(UniRequest request, Object result) {
            if (request != null) {
                synchronized (request) {
                    request.mResult = result;
                    request.mStatus.set(true);
                    request.notifyAll();
                }
            }
        }
    }

    protected class CachePHBHandler extends Handler {
        public CachePHBHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case UniIccPhoneBookInterfaceManager.EVENT_ICC_CHANGED /* 100 */:
                    UniIccPhoneBookInterfaceManager.this.onUpdateIccAvailability();
                    return;
                case UniIccPhoneBookInterfaceManager.EVENT_RECORDS_LOADED /* 101 */:
                    UniIccPhoneBookInterfaceManager.this.mIsPhonebookLoading = true;
                    UniIccPhoneBookInterfaceManager.this.getAdnRecordsInEfEx(28474);
                    UniIccPhoneBookInterfaceManager.this.getAdnRecordsInEfEx(28489);
                    UniIccPhoneBookInterfaceManager.this.getGasInEf();
                    synchronized (UniIccPhoneBookInterfaceManager.this.mLockForReadSizes) {
                        UniIccPhoneBookInterfaceManager.this.mLockForReadSizes.notifyAll();
                        break;
                    }
                    UniIccPhoneBookInterfaceManager.this.mIsPhonebookLoading = false;
                    return;
                default:
                    return;
            }
        }
    }

    public void updateIccRecords(IccRecords iccRecords) {
        IccRecords records3gpp;
        super.updateIccRecords(iccRecords);
        log("updateIccRecords");
        if (iccRecords != null) {
            if (!(iccRecords instanceof RuimRecords)) {
                if (iccRecords instanceof SIMRecords) {
                    this.mUniAdnCache = ((UniSIMRecords) iccRecords).getUniAdnRecordCache();
                    return;
                }
                return;
            }
            TelephonyManager tm = new TelephonyManager(this.mPhone.getContext(), this.mPhone.getSubId());
            int phoneType = tm.getPhoneType();
            if (phoneType == 1) {
                records3gpp = UiccController.getInstance().getIccRecords(this.mPhone.getPhoneId(), 1);
            } else {
                records3gpp = UiccController.getInstance().getIccRecords(this.mPhone.getPhoneId(), 2);
            }
            if (records3gpp != null) {
                iccRecords = records3gpp;
            }
            this.mUniAdnCache = ((UniRuimRecords) iccRecords).getUniAdnRecordCache();
            return;
        }
        this.mUniAdnCache = null;
    }

    private int updateEfForIccType(int efid) {
        boolean isPbrFileExisting = false;
        boolean isContainAdnInPbr = false;
        UniAdnRecordCache uniAdnRecordCache = this.mUniAdnCache;
        if (uniAdnRecordCache != null && uniAdnRecordCache.getUniUsimPhoneBookManager() != null) {
            isPbrFileExisting = this.mUniAdnCache.getUniUsimPhoneBookManager().isPbrFileExisting();
            isContainAdnInPbr = this.mUniAdnCache.getUniUsimPhoneBookManager().isContainAdnInPbr();
        }
        log("updateEfForIccType: isPbrFileExisting : " + isPbrFileExisting + " isContainAdnInPbr: " + isContainAdnInPbr);
        if (efid == 28474 && isHasUsimApp() && isPbrFileExisting && isContainAdnInPbr) {
            return 20272;
        }
        return efid;
    }

    public List<UniAdnRecord> getAdnRecordsInEfEx(int efid) {
        UniRequest loadRequest;
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.READ_CONTACTS") != 0) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        int efid2 = updateEfForIccType(efid);
        log("getAdnRecordsInEFEx: efid = 0x" + Integer.toHexString(efid2).toUpperCase());
        checkThread();
        UniRequest loadRequest2 = this.mAllLoadRequest.get(Integer.valueOf(efid2));
        if (loadRequest2 != null) {
            loadRequest = loadRequest2;
        } else {
            UniRequest loadRequest3 = new UniRequest();
            this.mAllLoadRequest.put(Integer.valueOf(efid2), loadRequest3);
            loadRequest = loadRequest3;
        }
        synchronized (loadRequest) {
            Message response = this.mBaseHandler.obtainMessage(2, efid2, 0, loadRequest);
            loadRequest.mStatus.set(false);
            UniAdnRecordCache uniAdnRecordCache = this.mUniAdnCache;
            if (uniAdnRecordCache != null) {
                uniAdnRecordCache.requestLoadAllAdnLike(efid2, uniAdnRecordCache.extensionEfForEf(efid2), response);
                waitForResult(loadRequest);
            } else {
                log("Failure while trying to load from SIM due to uninitialised adncache");
            }
        }
        return (List) loadRequest.mResult;
    }

    public int[] getAdnRecordsSize(int efid) {
        log("getAdnRecordsSize efid = 0x" + Integer.toHexString(efid).toUpperCase());
        synchronized (this.mLockForReadSizes) {
            if (this.mIsPhonebookLoading) {
                try {
                    this.mLockForReadSizes.wait();
                } catch (InterruptedException e) {
                    log("Interrupted Exception in getAdnRecordsSize");
                }
            }
        }
        if (isHasUsimApp() && efid == 28474 && updateEfForIccType(efid) == 20272) {
            int[] size = getUsimAdnRecordsSize();
            if (size == null || size[0] == 0) {
                return getRecordsSize(efid);
            }
            return size;
        }
        return getRecordsSize(efid);
    }

    public int[] getRecordsSize(int efid) {
        UiccController uiccController;
        IccFileHandler iccFileHandler3gpp;
        log("getRecordsSize: efid = 0x" + Integer.toHexString(efid).toUpperCase());
        if (efid <= 0) {
            log("the efid is invalid");
            return null;
        }
        checkThread();
        UniRequest getSizeRequest = new UniRequest();
        synchronized (getSizeRequest) {
            Message response = this.mBaseHandler.obtainMessage(1, getSizeRequest);
            IccFileHandler fh = this.mPhone.getIccFileHandler();
            if (fh != null) {
                if ((fh instanceof RuimFileHandler) && (uiccController = this.mUiccController) != null && (iccFileHandler3gpp = uiccController.getIccFileHandler(this.mPhone.getPhoneId(), 1)) != null) {
                    fh = iccFileHandler3gpp;
                }
                log("fh = " + fh);
                fh.getEFLinearRecordSize(efid, response);
                waitForResult(getSizeRequest);
            }
        }
        return getSizeRequest.mResult == null ? new int[3] : (int[]) getSizeRequest.mResult;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean updateAdnRecordsInEfBySearch(int i, String str, String str2, String str3, String str4, String str5) throws Throwable {
        UniRequest uniRequest;
        UniRequest uniRequest2;
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.WRITE_CONTACTS") != 0) {
            throw new SecurityException("Requires android.permission.WRITE_CONTACTS permission");
        }
        log("updateAdnRecordsInEfBySearch: efid = 0x" + Integer.toHexString(i).toUpperCase() + " (" + str + "," + str2 + ")==> (" + str3 + "," + str4 + "), pin2=" + str5);
        int iUpdateEfForIccType = updateEfForIccType(i);
        log("updateAdnRecordsInEfBySearch: efid = 0x" + Integer.toHexString(iUpdateEfForIccType).toUpperCase());
        checkThread();
        UniRequest uniRequest3 = null;
        UniRequest uniRequest4 = new UniRequest();
        synchronized (uniRequest4) {
            try {
                try {
                    Message messageObtainMessage = this.mBaseHandler.obtainMessage(3, uniRequest4);
                    if (this.mUniAdnCache == null) {
                        uniRequest = uniRequest4;
                        log("Failure while trying to update by search due to uninitialised adncache");
                    } else if (iUpdateEfForIccType == 20272) {
                        try {
                            uniRequest2 = uniRequest4;
                            try {
                                this.mUniAdnCache.updateUSIMAdnBySearch(iUpdateEfForIccType, new UniAdnRecord(str, str2, (String[]) null, "", "", "", "", ""), new UniAdnRecord(str3, str4, (String[]) null, "", "", "", "", ""), str5, messageObtainMessage);
                                uniRequest = uniRequest2;
                                waitForResult(uniRequest);
                            } catch (Throwable th) {
                                th = th;
                                uniRequest3 = uniRequest2;
                                throw th;
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            uniRequest3 = uniRequest4;
                        }
                    } else {
                        uniRequest2 = uniRequest4;
                        try {
                            this.mUniAdnCache.updateAdnBySearchEx(iUpdateEfForIccType, new UniAdnRecord(str, str2), new UniAdnRecord(str3, str4), str5, messageObtainMessage);
                            uniRequest = uniRequest2;
                            waitForResult(uniRequest);
                        } catch (Throwable th3) {
                            th = th3;
                            uniRequest3 = uniRequest2;
                            throw th;
                        }
                    }
                    return ((Integer) uniRequest.mResult).intValue() > 0;
                } catch (Throwable th4) {
                    th = th4;
                }
            } catch (Throwable th5) {
                th = th5;
                uniRequest3 = uniRequest4;
            }
        }
    }

    public int updateAdnRecordsInEfBySearch(int efid, String oldTag, String oldPhoneNumber, String[] oldEmailList, String oldAnr, String oldSne, String oldGrp, String newTag, String newPhoneNumber, String[] newEmailList, String newAnr, String newAas, String newSne, String newGrp, String newGas, String pin2) throws Throwable {
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.WRITE_CONTACTS") == 0) {
            log("updateAdnRecordsInEfBySearchEx: efid = 0x" + Integer.toHexString(efid).toUpperCase() + " (" + newTag + "," + newPhoneNumber + "), pin2=" + pin2);
            int newid = updateEfForIccType(efid);
            log("updateAdnRecordsInEfBySearch: efid = 0x" + Integer.toHexString(efid).toUpperCase());
            checkThread();
            UniRequest updateRequest = new UniRequest();
            synchronized (updateRequest) {
                try {
                    try {
                        Message response = this.mBaseHandler.obtainMessage(3, updateRequest);
                        try {
                            if (this.mUniAdnCache == null) {
                                log("updateAdnRecordsInEfBySearchEx failed because mUniAdnCache is null");
                                return -1;
                            }
                            if (newid == 28484) {
                                log("insertLNDRecord: efid = 0x" + Integer.toHexString(efid).toUpperCase() + " (" + newTag + "," + newPhoneNumber + "), pin2=" + pin2);
                                UniAdnRecord oldAdn = new UniAdnRecord(oldTag, oldPhoneNumber);
                                UniAdnRecord newAdn = new UniAdnRecord(newTag, newPhoneNumber);
                                this.mUniAdnCache.insertLndBySearch(newid, oldAdn, newAdn, pin2, response);
                            } else if (newid == 20272) {
                                UniAdnRecord oldAdn2 = new UniAdnRecord(oldTag, oldPhoneNumber, oldEmailList, oldAnr, "", oldSne, oldGrp, "");
                                UniAdnRecord newAdn2 = new UniAdnRecord(newTag, newPhoneNumber, newEmailList, newAnr, newAas, newSne, newGrp, newGas);
                                this.mUniAdnCache.updateUSIMAdnBySearch(newid, oldAdn2, newAdn2, pin2, response);
                            } else {
                                UniAdnRecord oldAdn3 = new UniAdnRecord(oldTag, oldPhoneNumber);
                                UniAdnRecord newAdn3 = new UniAdnRecord(newTag, newPhoneNumber);
                                this.mUniAdnCache.updateAdnBySearchEx(newid, oldAdn3, newAdn3, pin2, response);
                            }
                            waitForResult(r8);
                            return ((Integer) updateRequest.mResult).intValue();
                        } catch (Throwable th) {
                            th = th;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                    }
                } catch (Throwable th3) {
                    th = th3;
                }
                throw th;
            }
        }
        throw new SecurityException("Requires android.permission.WRITE_CONTACTS permission");
    }

    public int updateAdnRecordsInEfByIndex(int efid, String newTag, String newPhoneNumber, String[] newEmailList, String newAnr, String newAas, String newSne, String newGrp, String newGas, int index, String pin2) throws Throwable {
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.WRITE_CONTACTS") == 0) {
            log("updateAdnRecordsInEfByIndexEx: efid = 0x" + Integer.toHexString(efid).toUpperCase() + " (" + newTag + "," + newPhoneNumber + "), index=" + index);
            int newid = updateEfForIccType(efid);
            log("updateAdnRecordsInEfByIndexEx: newid = 0x" + Integer.toHexString(newid).toUpperCase());
            checkThread();
            UniRequest updateRequest = new UniRequest();
            synchronized (updateRequest) {
                try {
                    try {
                        Message response = this.mBaseHandler.obtainMessage(3, updateRequest);
                        if (this.mUniAdnCache == null) {
                            try {
                                log("updateAdnRecordsInEfByIndexEx failed because mUniAdnCache is null");
                                return -1;
                            } catch (Throwable th) {
                                th = th;
                            }
                        } else {
                            if (newid == 20272) {
                                UniAdnRecord newAdn = new UniAdnRecord(newTag, newPhoneNumber, newEmailList, newAnr, newAas, newSne, newGrp, newGas);
                                this.mUniAdnCache.updateUSIMAdnByIndex(newid, index, newAdn, pin2, response);
                            } else {
                                UniAdnRecord newAdn2 = new UniAdnRecord(newTag, newPhoneNumber);
                                this.mUniAdnCache.updateAdnByIndexEx(newid, newAdn2, index, pin2, response);
                            }
                            waitForResult(r13);
                            return ((Integer) updateRequest.mResult).intValue();
                        }
                    } catch (Throwable th2) {
                        th = th2;
                    }
                } catch (Throwable th3) {
                    th = th3;
                }
                throw th;
            }
        }
        throw new SecurityException("Requires android.permission.WRITE_CONTACTS permission");
    }

    public synchronized List<String> getGasInEf() {
        log("getGasInEf");
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.READ_CONTACTS") != 0) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        if (!isHasUsimApp()) {
            log("Can not get gas from a sim card");
            return null;
        }
        UniAdnRecordCache uniAdnRecordCache = this.mUniAdnCache;
        if (uniAdnRecordCache == null) {
            log("getGasInEf failed because mUniAdnCache is null");
            return new ArrayList();
        }
        return uniAdnRecordCache.loadGasFromUsim();
    }

    public int updateUsimGroupBySearch(String oldName, String newName) {
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.WRITE_CONTACTS") != 0) {
            throw new SecurityException("Requires android.permission.WRITE_CONTACTS permission");
        }
        UniAdnRecordCache uniAdnRecordCache = this.mUniAdnCache;
        if (uniAdnRecordCache == null) {
            log("updateUsimGroupBySearchEx failed because mUniAdnCache is null");
            return -1;
        }
        return uniAdnRecordCache.updateGasBySearch(oldName, newName);
    }

    public int updateUsimGroupByIndex(String newName, int groupId) {
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.WRITE_CONTACTS") != 0) {
            throw new SecurityException("Requires android.permission.WRITE_CONTACTS permission");
        }
        UniAdnRecordCache uniAdnRecordCache = this.mUniAdnCache;
        if (uniAdnRecordCache == null) {
            log("updateUsimGroupById failed because mUniAdnCache is null");
            return -1;
        }
        return uniAdnRecordCache.updateGasByIndex(newName, groupId);
    }

    public boolean isApplicationOnIcc(int type) {
        IccCardApplicationStatus.AppType simType = IccCardApplicationStatus.AppType.APPTYPE_SIM;
        if ((IccCardApplicationStatus.AppType.values()[type] == simType && this.mPhone.getCurrentUiccAppType() == simType) || isHasUsimApp()) {
            return true;
        }
        return false;
    }

    private UniUsimPhoneBookManager getUniUsimPhoneBookManager() {
        if (this.mUniAdnCache != null && isHasUsimApp()) {
            return this.mUniAdnCache.getUniUsimPhoneBookManager();
        }
        return null;
    }

    private int[] getUsimAdnRecordsSize() {
        log("getUsimAdnRecordsSize");
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            return null;
        }
        return uniUsimPhoneBookManager.getAdnRecordsSize();
    }

    public int[] getEmailRecordsSize() {
        log("getEmailRecordsSize");
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            return null;
        }
        return uniUsimPhoneBookManager.getEmailRecordsSize();
    }

    public int[] getAnrRecordsSize() {
        log("getAnrRecordsSize");
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            return null;
        }
        int[] recordSizeTotal = new int[3];
        for (int num = 0; num < uniUsimPhoneBookManager.getNumRecs(); num++) {
            int efid = uniUsimPhoneBookManager.findEFAnrInfo(num);
            if (efid <= 0) {
                return null;
            }
            int[] recordSizeAnr = getRecordsSize(efid);
            recordSizeTotal[0] = recordSizeAnr[0];
            recordSizeTotal[1] = recordSizeTotal[1] + recordSizeAnr[1];
            recordSizeTotal[2] = recordSizeTotal[2] + recordSizeAnr[2];
        }
        return recordSizeTotal;
    }

    public int getEmailNum() {
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            return 0;
        }
        return uniUsimPhoneBookManager.getEmailNum();
    }

    public int getGroupNum() {
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            return 0;
        }
        return uniUsimPhoneBookManager.getGroupNum();
    }

    public int getAnrNum() {
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            return 0;
        }
        return uniUsimPhoneBookManager.getAnrNum();
    }

    public int getEmailMaxLen() {
        log("getEmailMaxLen");
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            return 0;
        }
        return uniUsimPhoneBookManager.getEmailMaxLen();
    }

    public int getPhoneNumMaxLen() {
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            return 40;
        }
        return uniUsimPhoneBookManager.getPhoneNumMaxLen();
    }

    public int getUsimGroupNameMaxLen() {
        log("getGroupNameMaxLen");
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            return -1;
        }
        int gasEfId = uniUsimPhoneBookManager.findEFGasInfo();
        int[] gasSize = getRecordsSize(gasEfId);
        if (gasSize == null) {
            return -1;
        }
        return gasSize[0];
    }

    public int[] getUsimGroupSize() {
        log("getUsimGroupSize");
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            log("uniUsimPhoneBookManager == null");
            return null;
        }
        int gasEfId = uniUsimPhoneBookManager.findEFGasInfo();
        int[] gasSize = getRecordsSize(gasEfId);
        return gasSize;
    }

    public int[] getAvalibleEmailCount(String name, String number, String[] emails, String anr, int[] emailNums) {
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            return null;
        }
        return uniUsimPhoneBookManager.getAvalibleEmailCount(name, number, emails, anr, emailNums);
    }

    public int[] getAvalibleAnrCount(String name, String number, String[] emails, String anr, int[] anrNums) {
        UniUsimPhoneBookManager uniUsimPhoneBookManager = getUniUsimPhoneBookManager();
        if (uniUsimPhoneBookManager == null) {
            return null;
        }
        return uniUsimPhoneBookManager.getAvalibleAnrCount(name, number, emails, anr, anrNums);
    }

    public int getInsertIndex() {
        UniAdnRecordCache uniAdnRecordCache = this.mUniAdnCache;
        if (uniAdnRecordCache == null) {
            log("getInsertIndex:adn cache is null");
            return -1;
        }
        return uniAdnRecordCache.getInsertId();
    }

    public synchronized List<String> getAasInEf() {
        log("getAasInEf");
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.READ_CONTACTS") != 0) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        if (!isHasUsimApp()) {
            log("Can not get aas from a sim card");
            return null;
        }
        UniAdnRecordCache uniAdnRecordCache = this.mUniAdnCache;
        if (uniAdnRecordCache == null) {
            log("getAasInEf failed because mUniAdnCache is null");
            return new ArrayList();
        }
        return uniAdnRecordCache.loadAasFromUsim();
    }

    public int updateUsimAasBySearch(String oldName, String newName) {
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.WRITE_CONTACTS") != 0) {
            throw new SecurityException("Requires android.permission.WRITE_CONTACTS permission");
        }
        UniAdnRecordCache uniAdnRecordCache = this.mUniAdnCache;
        if (uniAdnRecordCache == null) {
            log("updateUsimAasBySearch failed because mUniAdnCache is null");
            return -1;
        }
        return uniAdnRecordCache.updateAasBySearch(oldName, newName);
    }

    public int updateUsimAasByIndex(String newName, int aasIndex) {
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.WRITE_CONTACTS") != 0) {
            throw new SecurityException("Requires android.permission.WRITE_CONTACTS permission");
        }
        UniAdnRecordCache uniAdnRecordCache = this.mUniAdnCache;
        if (uniAdnRecordCache == null) {
            log("updateUsimAasByIndex failed because mUniAdnCache is null");
            return -1;
        }
        return uniAdnRecordCache.updateAasByIndex(newName, aasIndex);
    }

    public synchronized int getSneSize() {
        log("getSneSize");
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.READ_CONTACTS") != 0) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        if (!isHasUsimApp()) {
            log("Can not get sne size from a sim card");
            return 0;
        }
        UniAdnRecordCache uniAdnRecordCache = this.mUniAdnCache;
        if (uniAdnRecordCache == null) {
            log("getSneSize failed because mUniAdnCache is null");
            return 0;
        }
        return uniAdnRecordCache.getSneSize();
    }

    public int[] getSneLength() {
        if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.READ_CONTACTS") != 0) {
            throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
        }
        if (!isHasUsimApp()) {
            log("Can not get sne length from a sim card");
            return null;
        }
        UniAdnRecordCache uniAdnRecordCache = this.mUniAdnCache;
        if (uniAdnRecordCache == null) {
            log("getSneLength failed because mUniAdnCache is null");
            return null;
        }
        return uniAdnRecordCache.getSneLength();
    }

    private void createUpdateThread() {
        HandlerThread handlerThread = new HandlerThread("RunningState:Background");
        this.mUpdateThread = handlerThread;
        handlerThread.start();
        this.mBaseHandler = new UpdateThreadHandler(this.mUpdateThread.getLooper());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onUpdateIccAvailability() {
        int i;
        UiccController uiccController = this.mUiccController;
        if (uiccController == null || (i = this.mPhoneId) == -1) {
            return;
        }
        UiccPort newPort = uiccController.getUiccPort(i);
        UiccCardApplication newApp = null;
        IccRecords newRecords = null;
        if (newPort != null && (newApp = newPort.getApplication(1)) != null) {
            newRecords = newApp.getIccRecords();
        }
        if (this.mIccRecords != newRecords || this.mUiccApplication != newApp || this.mUiccPort != newPort) {
            log("Icc changed. Reregestering.");
            unregisterUiccCardEvents();
            this.mIccRecords = newRecords;
            this.mUiccPort = newPort;
            this.mUiccApplication = newApp;
            registerUiccCardEvents();
        }
    }

    private void registerUiccCardEvents() {
        IccRecords iccRecords = this.mIccRecords;
        if (iccRecords != null) {
            iccRecords.registerForRecordsLoaded(this.mCachePHBHandler, EVENT_RECORDS_LOADED, (Object) null);
        }
    }

    private void unregisterUiccCardEvents() {
        IccRecords iccRecords = this.mIccRecords;
        if (iccRecords != null) {
            iccRecords.unregisterForRecordsLoaded(this.mCachePHBHandler);
        }
    }

    private void registerForIccChanged(Phone phone) {
        this.mPhoneId = phone.getPhoneId();
        HandlerThread handlerThread = new HandlerThread("RunningState:Background");
        this.mCachePHBThread = handlerThread;
        handlerThread.start();
        CachePHBHandler cachePHBHandler = new CachePHBHandler(this.mCachePHBThread.getLooper());
        this.mCachePHBHandler = cachePHBHandler;
        UiccController uiccController = this.mUiccController;
        if (uiccController != null) {
            uiccController.registerForIccChanged(cachePHBHandler, EVENT_ICC_CHANGED, (Object) null);
        }
    }

    private boolean isHasUsimApp() {
        try {
            return this.mPhone.getUiccPort().getUiccProfile().isApplicationOnIcc(IccCardApplicationStatus.AppType.APPTYPE_USIM);
        } catch (NullPointerException e) {
            log("isHasUsimApp NullPointException : " + e);
            return false;
        }
    }

    private void waitForResult(UniRequest request) {
        synchronized (request) {
            while (!request.mStatus.get()) {
                try {
                    request.wait();
                } catch (InterruptedException e) {
                    log("interrupted while trying to update by search");
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(String msg) {
        UniPhoneBookLog.d(TAG, msg);
    }
}
