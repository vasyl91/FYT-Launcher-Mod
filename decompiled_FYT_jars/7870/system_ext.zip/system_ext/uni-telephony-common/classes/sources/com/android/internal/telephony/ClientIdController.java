package com.android.internal.telephony;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemProperties;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import com.android.internal.telephony.uicc.UiccController;
import com.android.telephony.Rlog;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class ClientIdController extends Handler {
    private static final int EVENT_INVALID = -1;
    private static final int EVENT_REBOOT = 3;
    private static final int EVENT_SIM_ABSENT = 2;
    private static final int EVENT_SIM_LOADED = 1;
    private static final String GSM_CLIENT_BASE = "gsm.client.base";
    private static final String OPERATOR_CLIENTID = "operator_clientid";
    private static final String RO_GOOGLE_CLIENT_BASE = "ro.com.google.clientidbase";
    private static final String TAG = "ClientIdController";
    private static ClientIdController mInstance;
    private Context mContext;
    private String mDefaultClientBase;

    private ClientIdController(Context context) {
        this.mContext = context;
        this.mDefaultClientBase = context.getString(135004216);
    }

    public static ClientIdController getInstance() {
        ClientIdController clientIdController;
        synchronized (ClientIdController.class) {
            clientIdController = mInstance;
            if (clientIdController == null) {
                throw new RuntimeException("ClientIdController.getInstance can't be called before make()");
            }
        }
        return clientIdController;
    }

    public static ClientIdController init(Context context) {
        Log.d(TAG, "init");
        synchronized (ClientIdController.class) {
            if (mInstance == null) {
                mInstance = new ClientIdController(context);
            } else {
                Log.wtf(TAG, "init() called multiple times!  mInstance = " + mInstance);
            }
        }
        return mInstance;
    }

    void updateInternalIccState(String simStatus) {
        Rlog.i(TAG, "updateInternalIccState to simStatus " + simStatus);
        int message = internalIccStateToMessage(simStatus);
        if (message != EVENT_INVALID) {
            sendMessage(obtainMessage(message));
        }
    }

    private int internalIccStateToMessage(String simStatus) {
        switch (simStatus) {
            case "ABSENT":
                return 2;
            case "LOADED":
                return 1;
            default:
                Rlog.i(TAG, "Ignoring simStatus: " + simStatus);
                return EVENT_INVALID;
        }
    }

    @Override // android.os.Handler
    public void handleMessage(Message msg) {
        String operatorClientId = Settings.Global.getString(this.mContext.getContentResolver(), OPERATOR_CLIENTID);
        if (!TextUtils.isEmpty(operatorClientId)) {
            Rlog.i(TAG, "has set operator client Id, set it to gsm prop");
            SystemProperties.set(GSM_CLIENT_BASE, operatorClientId);
        }
        switch (msg.what) {
            case 1:
                String mccMnc = UiccController.getInstance().getIccRecords(0, 1).getOperatorNumeric();
                if (TextUtils.isEmpty(mccMnc) || mccMnc.length() < 5 || mccMnc.length() > 6) {
                    Rlog.i(TAG, "mccmnc is invalid,  nothing to do mccmnc = " + mccMnc);
                } else {
                    String customClientId = getResourcesFromMccMnc(mccMnc.substring(0, 3), mccMnc.substring(3)).getString(135004246);
                    Rlog.e(TAG, "customClientId = " + customClientId);
                    if (TextUtils.isEmpty(customClientId)) {
                        Rlog.e(TAG, "customClientId from config is null retutn ");
                    } else {
                        String currentRoClientId = SystemProperties.get(RO_GOOGLE_CLIENT_BASE, "");
                        if (TextUtils.isEmpty(currentRoClientId)) {
                            Rlog.i(TAG, "has not set ro client, set it");
                            SystemProperties.set(GSM_CLIENT_BASE, customClientId);
                            if (!customClientId.equals(this.mDefaultClientBase)) {
                                Rlog.i(TAG, "Set custom value, no change it forever");
                                Settings.Global.putString(this.mContext.getContentResolver(), OPERATOR_CLIENTID, customClientId);
                            }
                        } else if (!customClientId.equals(this.mDefaultClientBase)) {
                            Rlog.i(TAG, "custom value, but has set client base, need reboot and reset");
                            AlertDialog dialog = new AlertDialog.Builder(this.mContext).setTitle(135004277).setMessage(135004276).create();
                            dialog.getWindow().setType(2003);
                            dialog.show();
                            sendMessageDelayed(obtainMessage(3), 3000L);
                        }
                    }
                }
                break;
            case 2:
                if (TextUtils.isEmpty(SystemProperties.get(RO_GOOGLE_CLIENT_BASE, ""))) {
                    Rlog.i(TAG, "Sim absent, has not set ro client, set it");
                    SystemProperties.set(GSM_CLIENT_BASE, this.mDefaultClientBase);
                }
                break;
            case 3:
                PowerManager pm = (PowerManager) this.mContext.getSystemService("power");
                pm.reboot("ClientId Reboot");
                break;
            default:
                Rlog.e(TAG, " Unknown Event " + msg.what);
                break;
        }
    }

    private Resources getResourcesFromMccMnc(String mcc, String mnc) {
        Rlog.e(TAG, "getResourcesFromMccMnc mcc =  " + mcc + " mnc = " + mnc);
        Configuration config = this.mContext.getResources().getConfiguration();
        Configuration newConfig = new Configuration();
        newConfig.setTo(config);
        newConfig.mcc = Integer.parseInt(mcc);
        newConfig.mnc = Integer.parseInt(mnc);
        if (newConfig.mnc == 0) {
            newConfig.mnc = 65535;
        }
        DisplayMetrics metrics = this.mContext.getResources().getDisplayMetrics();
        DisplayMetrics newMetrics = new DisplayMetrics();
        newMetrics.setTo(metrics);
        return new Resources(this.mContext.getResources().getAssets(), newMetrics, newConfig);
    }
}
