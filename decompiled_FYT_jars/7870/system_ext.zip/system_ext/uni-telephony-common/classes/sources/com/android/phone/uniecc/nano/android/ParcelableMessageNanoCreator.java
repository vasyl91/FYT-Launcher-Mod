package com.android.phone.uniecc.nano.android;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.android.phone.uniecc.nano.InvalidProtocolBufferNanoException;
import com.android.phone.uniecc.nano.MessageNano;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public final class ParcelableMessageNanoCreator<T extends MessageNano> implements Parcelable.Creator<T> {
    private static final String TAG = "PMNCreator";
    private final Class<T> mClazz;

    public ParcelableMessageNanoCreator(Class<T> clazz) {
        this.mClazz = clazz;
    }

    @Override // android.os.Parcelable.Creator
    public T createFromParcel(Parcel parcel) {
        String string = parcel.readString();
        byte[] bArrCreateByteArray = parcel.createByteArray();
        T t = null;
        try {
            t = (T) ((MessageNano) Class.forName(string, false, getClass().getClassLoader()).asSubclass(MessageNano.class).getConstructor(new Class[0]).newInstance(new Object[0]));
            MessageNano.mergeFrom(t, bArrCreateByteArray);
            return t;
        } catch (InvalidProtocolBufferNanoException e) {
            Log.e(TAG, "Exception trying to create proto from parcel", e);
            return t;
        } catch (ClassNotFoundException e2) {
            Log.e(TAG, "Exception trying to create proto from parcel", e2);
            return t;
        } catch (IllegalAccessException e3) {
            Log.e(TAG, "Exception trying to create proto from parcel", e3);
            return t;
        } catch (InstantiationException e4) {
            Log.e(TAG, "Exception trying to create proto from parcel", e4);
            return t;
        } catch (NoSuchMethodException e5) {
            Log.e(TAG, "Exception trying to create proto from parcel", e5);
            return t;
        } catch (InvocationTargetException e6) {
            Log.e(TAG, "Exception trying to create proto from parcel", e6);
            return t;
        }
    }

    @Override // android.os.Parcelable.Creator
    public T[] newArray(int i) {
        return (T[]) ((MessageNano[]) Array.newInstance((Class<?>) this.mClazz, i));
    }

    static <T extends MessageNano> void writeToParcel(Class<T> clazz, MessageNano message, Parcel out) {
        out.writeString(clazz.getName());
        out.writeByteArray(MessageNano.toByteArray(message));
    }
}
