package com.android.internal.telephony.uicc;

import com.android.internal.telephony.CommandsInterface;
import com.android.telephony.Rlog;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public final class UniCsimFileHandler extends IccFileHandler implements UniIccConstants {
    static final String LOG_TAG = "UniCsimFH";

    public UniCsimFileHandler(UiccCardApplication app, String aid, CommandsInterface ci) {
        super(app, aid, ci);
    }

    protected String getEFPath(int efid) {
        switch (efid) {
            case 20256:
            case 20257:
                return "3F007F105F3C";
            case 28450:
            case 28456:
            case UniIccConstants.EF_PLMN_SEL /* 28464 */:
            case 28466:
            case UniIccConstants.EF_ESNME /* 28472 */:
            case 28474:
            case 28475:
            case 28476:
            case 28480:
            case 28481:
            case UniIccConstants.EF_LND /* 28484 */:
            case 28493:
            case 28506:
                return "3F007FFF";
            default:
                String path = getCommonIccEFPath(efid);
                if (path == null) {
                    return "3F007F105F3A";
                }
                return path;
        }
    }

    protected void logd(String msg) {
        Rlog.d(LOG_TAG, msg);
    }

    protected void loge(String msg) {
        Rlog.e(LOG_TAG, msg);
    }
}
