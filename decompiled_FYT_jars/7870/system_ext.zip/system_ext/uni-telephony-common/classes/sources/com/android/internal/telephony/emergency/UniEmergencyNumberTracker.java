package com.android.internal.telephony.emergency;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.telephony.emergency.EmergencyNumber;
import android.text.TextUtils;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.LocaleTracker;
import com.android.internal.telephony.MccTable;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.ServiceStateTracker;
import com.android.phone.uniecc.nano.InvalidProtocolBufferNanoException;
import com.android.phone.uniecc.nano.UniProtobufEccData;
import com.android.unisoc.telephony.RadioInteractor;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.zip.GZIPInputStream;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniEmergencyNumberTracker extends EmergencyNumberTracker {
    private static final String ECCLIST_NO_CARD = "no_card";
    private static final String ECCLIST_WITH_CARD = "with_card";
    private static final int EVENT_SERVICE_STATE_CHANGED = 5;
    private static final String TAG = UniEmergencyNumberTracker.class.getSimpleName();
    private static final String UNI_EMERGENCY_NUMBER_DB_ASSETS_FILE = "unieccdata";
    private boolean hasMncFlag;
    int mAssetsDatabaseVersion;
    private CountryIsoConfig mCountryIsoConfig;
    private List<EmergencyNumber> mRadioEccListNotFromNetwork;
    private RadioInteractor mRadioInteractor;
    private TelephonyManager mTelephonyManager;
    private BroadcastReceiver mUniIntentReceiver;

    public UniEmergencyNumberTracker(Phone phone, CommandsInterface ci) {
        super(phone, ci);
        this.hasMncFlag = false;
        this.mAssetsDatabaseVersion = -1;
        this.mRadioEccListNotFromNetwork = new ArrayList();
        this.mUniIntentReceiver = new BroadcastReceiver() { // from class: com.android.internal.telephony.emergency.UniEmergencyNumberTracker.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if ("android.intent.action.SIM_STATE_CHANGED".equals(action)) {
                    int phoneId = UniEmergencyNumberTracker.this.mPhone.getPhoneId();
                    int intentPhoneId = intent.getIntExtra("phone", 0);
                    String simState = intent.getStringExtra("ss");
                    UniEmergencyNumberTracker.this.logd("ACTION_SIM_STATE_CHANGED: intentPhoneId: " + intentPhoneId + " phoneId: " + phoneId + " simState " + simState);
                    if (UniEmergencyNumberTracker.this.needInitDatabase(phoneId, intentPhoneId, simState)) {
                        if ("ABSENT".equals(simState)) {
                            UniEmergencyNumberTracker.this.removeEccListFromNetwork();
                        }
                        UniEmergencyNumberTracker.this.initializeDatabaseSimStateChange(simState);
                        return;
                    }
                    return;
                }
                if ("android.intent.action.AIRPLANE_MODE".equals(action) && intent.getBooleanExtra("state", false)) {
                    UniEmergencyNumberTracker.this.removeEccListFromNetwork();
                }
            }
        };
        init(phone.getContext());
        getTelephonyManager();
    }

    private void getTelephonyManager() {
        if (this.mTelephonyManager != null) {
            return;
        }
        this.mTelephonyManager = (TelephonyManager) this.mPhone.getContext().getSystemService("phone");
    }

    private void init(Context context) {
        IntentFilter filter = new IntentFilter("android.intent.action.SIM_STATE_CHANGED");
        filter.addAction("android.intent.action.AIRPLANE_MODE");
        context.registerReceiver(this.mUniIntentReceiver, filter);
        this.mCountryIsoConfig = new CountryIsoConfig(context);
        addRadiointeractor(context);
    }

    private void addRadiointeractor(final Context context) {
        ComponentName componentName = new ComponentName("com.android.unisoc.telephony.server", "com.android.unisoc.telephony.server.RadioInteractorService");
        context.bindService(new Intent().setComponent(componentName), new ServiceConnection() { // from class: com.android.internal.telephony.emergency.UniEmergencyNumberTracker.2
            @Override // android.content.ServiceConnection
            public void onServiceConnected(ComponentName name, IBinder service) {
                UniEmergencyNumberTracker.this.logd("on radioInteractor service connected");
                if (UniEmergencyNumberTracker.this.mRadioInteractor == null) {
                    UniEmergencyNumberTracker.this.mRadioInteractor = new RadioInteractor(context);
                }
                UniEmergencyNumberTracker.this.mRadioInteractor.updateRealEccList("", UniEmergencyNumberTracker.this.mPhone.getPhoneId());
                UniEmergencyNumberTracker.this.logd("addRadiointeractor " + UniEmergencyNumberTracker.this.mPhone.getPhoneId());
            }

            @Override // android.content.ServiceConnection
            public void onServiceDisconnected(ComponentName name) {
                UniEmergencyNumberTracker.this.logd("addRadiointeractor onServiceDisconnected");
            }
        }, 0);
    }

    /* JADX WARN: Code duplicated, block: B:94:0x01d5  */
    /* JADX WARN: Code duplicated, block: B:95:0x01f0  */
    protected void cacheEmergencyDatabaseByCountry(String countryIso) throws InvalidProtocolBufferNanoException, PackageManager.NameNotFoundException {
        RuntimeException runtimeException;
        int otaDatabaseVersion;
        UniProtobufEccData.AllInfo allEccMessages;
        int assetsDatabaseVersion;
        UniProtobufEccData.CountryInfo[] countryInfoArr;
        UniProtobufEccData.AllInfo allEccMessages2;
        int assetsDatabaseVersion2;
        if (!needLoadDataBaseEccList()) {
            return;
        }
        BufferedInputStream inputStream = null;
        int assetsDatabaseVersion3 = -1;
        List<EmergencyNumber> updatedAssetEmergencyNumberList = new ArrayList<>();
        List<EmergencyNumber> updatedAssetEmergencyNumberListWithMnc = new ArrayList<>();
        String mnc = getMnc(this.mPhone.getPhoneId());
        Context remoteContext = null;
        try {
            try {
                try {
                    remoteContext = this.mPhone.getContext().createPackageContext("com.unisoc.phone", 3);
                } catch (IOException e) {
                    ex = e;
                }
            } catch (PackageManager.NameNotFoundException e2) {
                e2.printStackTrace();
            }
            logd("remouteContext is: " + remoteContext);
            if (remoteContext == null) {
                if (0 != 0) {
                    try {
                        inputStream.close();
                        return;
                    } catch (RuntimeException rethrown) {
                        throw rethrown;
                    } catch (Exception e3) {
                        return;
                    }
                }
                return;
            }
            inputStream = new BufferedInputStream(remoteContext.getAssets().open(UNI_EMERGENCY_NUMBER_DB_ASSETS_FILE));
            UniProtobufEccData.AllInfo allEccMessages3 = UniProtobufEccData.AllInfo.parseFrom(readInputStreamToByteArray(new GZIPInputStream(inputStream)));
            try {
                assetsDatabaseVersion3 = allEccMessages3.revision;
                try {
                    this.mAssetsDatabaseVersion = assetsDatabaseVersion3;
                    logd(countryIso + " asset emergency database is loaded. Ver: " + assetsDatabaseVersion3 + " Phone Id: " + this.mPhone.getPhoneId());
                    UniProtobufEccData.CountryInfo[] countryInfoArr2 = allEccMessages3.countries;
                    int length = countryInfoArr2.length;
                    int i = 0;
                    while (i < length) {
                        UniProtobufEccData.CountryInfo countryEccInfo = countryInfoArr2[i];
                        if (countryEccInfo.isoCode.equals(countryIso.toUpperCase())) {
                            UniProtobufEccData.EccInfo[] eccInfoArr = countryEccInfo.eccs;
                            int length2 = eccInfoArr.length;
                            int i2 = 0;
                            while (i2 < length2) {
                                UniProtobufEccData.EccInfo eccInfo = eccInfoArr[i2];
                                UniProtobufEccData.CountryInfo[] countryInfoArr3 = countryInfoArr2;
                                EmergencyNumber emergencyNumFromEccInfo = convertEmergencyNumberFromUniEccInfo(eccInfo, countryIso);
                                allEccMessages = allEccMessages3;
                                if (emergencyNumFromEccInfo == null) {
                                    assetsDatabaseVersion = assetsDatabaseVersion3;
                                } else {
                                    assetsDatabaseVersion = assetsDatabaseVersion3;
                                    String trimedEccMnc = eccInfo.mnc.trim();
                                    if (trimedEccMnc.isEmpty()) {
                                        updatedAssetEmergencyNumberList.add(emergencyNumFromEccInfo);
                                    } else {
                                        String trimedEccMnc2 = eccInfo.mnc;
                                        if (trimedEccMnc2.equals(mnc)) {
                                            updatedAssetEmergencyNumberListWithMnc.add(emergencyNumFromEccInfo);
                                        }
                                    }
                                }
                                try {
                                    i2++;
                                    countryInfoArr2 = countryInfoArr3;
                                    allEccMessages3 = allEccMessages;
                                    assetsDatabaseVersion3 = assetsDatabaseVersion;
                                } catch (IOException e4) {
                                    ex = e4;
                                    assetsDatabaseVersion3 = assetsDatabaseVersion;
                                } catch (Throwable rethrown2) {
                                    runtimeException = rethrown2;
                                    if (inputStream == null) {
                                        throw runtimeException;
                                    }
                                    try {
                                        inputStream.close();
                                        throw runtimeException;
                                    } catch (RuntimeException rethrown3) {
                                        throw rethrown3;
                                    } catch (Exception e5) {
                                        throw runtimeException;
                                    }
                                }
                            }
                            countryInfoArr = countryInfoArr2;
                            allEccMessages2 = allEccMessages3;
                            assetsDatabaseVersion2 = assetsDatabaseVersion3;
                        } else {
                            countryInfoArr = countryInfoArr2;
                            allEccMessages2 = allEccMessages3;
                            assetsDatabaseVersion2 = assetsDatabaseVersion3;
                        }
                        i++;
                        countryInfoArr2 = countryInfoArr;
                        allEccMessages3 = allEccMessages2;
                        assetsDatabaseVersion3 = assetsDatabaseVersion2;
                    }
                    allEccMessages = allEccMessages3;
                    assetsDatabaseVersion = assetsDatabaseVersion3;
                    if (updatedAssetEmergencyNumberListWithMnc.size() > 0 || this.hasMncFlag) {
                        if (this.hasMncFlag) {
                            this.hasMncFlag = false;
                        }
                        logd(countryIso + " cacheEmergencyDatabaseByCountry: updatedAssetEmergencyNumberListWithMnc = " + updatedAssetEmergencyNumberListWithMnc);
                        updatedAssetEmergencyNumberList = updatedAssetEmergencyNumberListWithMnc;
                    }
                    EmergencyNumber.mergeSameNumbersInEmergencyNumberList(updatedAssetEmergencyNumberList);
                    this.mEmergencyNumberListFromAssetDatabase = updatedAssetEmergencyNumberList;
                    try {
                        inputStream.close();
                    } catch (RuntimeException rethrown4) {
                        throw rethrown4;
                    } catch (Exception e6) {
                    }
                    assetsDatabaseVersion3 = assetsDatabaseVersion;
                } catch (IOException e7) {
                    ex = e7;
                } catch (Throwable th) {
                    runtimeException = th;
                }
            } catch (IOException e8) {
                ex = e8;
            } catch (Throwable th2) {
                runtimeException = th2;
            }
            otaDatabaseVersion = cacheOtaEmergencyNumberDatabase();
            if (otaDatabaseVersion != -1 && assetsDatabaseVersion3 == -1) {
                loge("No database available. Phone Id: " + this.mPhone.getPhoneId());
                return;
            }
            if (assetsDatabaseVersion3 > otaDatabaseVersion) {
                logd("Using Asset Emergency database. Version: " + assetsDatabaseVersion3);
                this.mCurrentDatabaseVersion = assetsDatabaseVersion3;
                this.mEmergencyNumberListFromDatabase = updatedAssetEmergencyNumberList;
            } else {
                logd("Using Ota Emergency database. Version: " + otaDatabaseVersion);
            }
            logd("cacheEmergencyDatabaseByCountry mEmergencyNumberListFromDatabase: " + this.mEmergencyNumberListFromDatabase + " mEmergencyNumberListFromAssetDatabase: " + this.mEmergencyNumberListFromAssetDatabase);
            loge("Cache emergency database failure: " + ex);
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (RuntimeException rethrown5) {
                    throw rethrown5;
                } catch (Exception e9) {
                }
            }
            otaDatabaseVersion = cacheOtaEmergencyNumberDatabase();
            if (otaDatabaseVersion != -1) {
            }
            if (assetsDatabaseVersion3 > otaDatabaseVersion) {
                logd("Using Asset Emergency database. Version: " + assetsDatabaseVersion3);
                this.mCurrentDatabaseVersion = assetsDatabaseVersion3;
                this.mEmergencyNumberListFromDatabase = updatedAssetEmergencyNumberList;
            } else {
                logd("Using Ota Emergency database. Version: " + otaDatabaseVersion);
            }
            logd("cacheEmergencyDatabaseByCountry mEmergencyNumberListFromDatabase: " + this.mEmergencyNumberListFromDatabase + " mEmergencyNumberListFromAssetDatabase: " + this.mEmergencyNumberListFromAssetDatabase);
        } catch (Throwable th3) {
            runtimeException = th3;
        }
    }

    protected EmergencyNumber convertEmergencyNumberFromUniEccInfo(UniProtobufEccData.EccInfo eccInfo, String countryIso) {
        String phoneNumber = eccInfo.phoneNumber.trim();
        if (phoneNumber.isEmpty() || !isValidEccInfo(eccInfo)) {
            loge("convertEmergencyNumberFromUniEccInfo: return null!");
            return null;
        }
        int emergencyServiceCategoryBitmask = 0;
        for (int typeData : eccInfo.types) {
            emergencyServiceCategoryBitmask = EccTypeInfo.getBitmask(typeData, emergencyServiceCategoryBitmask);
        }
        return new EmergencyNumber(phoneNumber, countryIso, eccInfo.mnc, emergencyServiceCategoryBitmask, new ArrayList(), 16, eccInfo.routing);
    }

    protected void updateEmergencyNumberList() {
        mergeAssetAndOtaEmergencyNumberList();
        try {
            super.updateEmergencyNumberList();
        } catch (NullPointerException ex) {
            loge("updateEmergencyNumberList: " + ex);
        }
        this.mEmergencyNumberList = mergeSameNumbersInEmergencyNumberList(this.mEmergencyNumberList);
        if (!DBG) {
            for (EmergencyNumber num : this.mEmergencyNumberList) {
                logd("mEmergencyNumberList after merge " + num);
            }
        }
    }

    protected void updateRadioEmergencyNumberListAndNotify(List<EmergencyNumber> emergencyNumberListRadio) {
        Collections.sort(emergencyNumberListRadio);
        logd("updateRadioEmergencyNumberListAndNotify(): receiving " + emergencyNumberListRadio);
        if (!emergencyNumberListRadio.equals(this.mEmergencyNumberListFromRadio)) {
            try {
                EmergencyNumber.mergeSameNumbersInEmergencyNumberList(emergencyNumberListRadio);
                List<EmergencyNumber> resultRadioEmergencyNumberList = new ArrayList<>();
                List<EmergencyNumber> resultRadioEccListNotFromNetwork = new ArrayList<>();
                for (EmergencyNumber emergencyNumbertRadio : emergencyNumberListRadio) {
                    List<String> emergencyUrns = emergencyNumbertRadio.getEmergencyUrns();
                    if (emergencyUrns != null && !emergencyUrns.isEmpty() && (emergencyUrns.size() != 1 || !"".equals(emergencyUrns.get(0)))) {
                        resultRadioEmergencyNumberList.add(new EmergencyNumber(emergencyNumbertRadio.getNumber(), emergencyNumbertRadio.getCountryIso(), emergencyNumbertRadio.getMnc(), emergencyNumbertRadio.getEmergencyServiceCategoryBitmask(), emergencyUrns, emergencyNumbertRadio.getEmergencyNumberSourceBitmask(), 2));
                    } else {
                        resultRadioEmergencyNumberList.add(emergencyNumbertRadio);
                    }
                    if (emergencyNumbertRadio.getEmergencyNumberSourceBitmask() != 1) {
                        resultRadioEccListNotFromNetwork.add(emergencyNumbertRadio);
                    }
                }
                writeUpdatedEmergencyNumberListMetrics(resultRadioEmergencyNumberList);
                this.mEmergencyNumberListFromRadio = resultRadioEmergencyNumberList;
                this.mRadioEccListNotFromNetwork = resultRadioEccListNotFromNetwork;
                logd("mEmergencyNumberListFromRadio " + this.mEmergencyNumberListFromRadio);
                logd("mRadioEccListNotFromNetwork " + this.mRadioEccListNotFromNetwork);
                if (!DBG) {
                    this.mEmergencyNumberListRadioLocalLog.log("updateRadioEmergencyNumberList:" + resultRadioEmergencyNumberList);
                }
                updateEmergencyNumberList();
                if (!DBG) {
                    this.mEmergencyNumberListLocalLog.log("updateRadioEmergencyNumberListAndNotify:" + this.mEmergencyNumberList);
                }
                notifyEmergencyNumberList();
            } catch (NullPointerException ex) {
                loge("updateRadioEmergencyNumberListAndNotify() Phone already destroyed: " + ex + " EmergencyNumberList not notified");
            }
        }
    }

    private void mergeAssetAndOtaEmergencyNumberList() {
        if (this.mEmergencyNumberListFromAssetDatabase.isEmpty() || this.mEmergencyNumberListFromDatabase.isEmpty()) {
            logd("mergeAssetAndOtaEmergencyNumberList: " + this.mEmergencyNumberListFromAssetDatabase + " mEmergencyNumberListFromDatabase:" + this.mEmergencyNumberListFromDatabase);
            return;
        }
        logd("mergeAssetAndOtaEmergencyNumberList: " + this.mCurrentDatabaseVersion + " " + this.mAssetsDatabaseVersion);
        if (this.mCurrentDatabaseVersion > this.mAssetsDatabaseVersion) {
            Set<Integer> duplicatedEmergencyNumberPosition = new HashSet<>();
            List<EmergencyNumber> resultEmergencyNumberList = new ArrayList<>();
            for (EmergencyNumber otaNum : this.mEmergencyNumberListFromDatabase) {
                boolean needAdd = true;
                for (int i = 0; i < this.mEmergencyNumberListFromAssetDatabase.size(); i++) {
                    EmergencyNumber assetNum = (EmergencyNumber) this.mEmergencyNumberListFromAssetDatabase.get(i);
                    if (otaNum.getNumber().equals(assetNum.getNumber())) {
                        needAdd = false;
                        resultEmergencyNumberList.add(mergeOtaAndAssetNumber(otaNum, assetNum));
                        duplicatedEmergencyNumberPosition.add(Integer.valueOf(i));
                        break;
                    }
                }
                if (needAdd) {
                    resultEmergencyNumberList.add(otaNum);
                }
            }
            for (int i2 = this.mEmergencyNumberListFromAssetDatabase.size() - 1; i2 >= 0; i2--) {
                if (duplicatedEmergencyNumberPosition.contains(Integer.valueOf(i2))) {
                    this.mEmergencyNumberListFromAssetDatabase.remove(i2);
                }
            }
            Iterator it = this.mEmergencyNumberListFromAssetDatabase.iterator();
            while (it.hasNext()) {
                resultEmergencyNumberList.add((EmergencyNumber) it.next());
            }
            logd("asset ecc list: " + this.mEmergencyNumberListFromAssetDatabase);
            logd("ota ecc list: " + this.mEmergencyNumberListFromDatabase);
            logd("database ecc list: " + resultEmergencyNumberList);
            this.mEmergencyNumberListFromDatabase = resultEmergencyNumberList;
            return;
        }
        this.mEmergencyNumberListFromDatabase = this.mEmergencyNumberListFromAssetDatabase;
        logd("mergeAssetAndOtaEmergencyNumberList: mEmergencyNumberListFromAssetDatabase " + this.mEmergencyNumberListFromAssetDatabase);
    }

    private EmergencyNumber mergeOtaAndAssetNumber(EmergencyNumber otaNum, EmergencyNumber assetNum) {
        int emergencyCallRouting;
        String number = otaNum.getNumber();
        String countryIso = otaNum.getCountryIso();
        String mnc = otaNum.getMnc();
        int emergencyServiceCategoryBitmask = assetNum.getEmergencyServiceCategoryBitmask() | otaNum.getEmergencyServiceCategoryBitmask();
        List<String> emergencyUrns = otaNum.getEmergencyUrns();
        int emergencyNumberSourceBitmask = otaNum.getEmergencyNumberSourceBitmask();
        if (otaNum.getEmergencyCallRouting() != 0) {
            emergencyCallRouting = otaNum.getEmergencyCallRouting();
        } else {
            emergencyCallRouting = assetNum.getEmergencyCallRouting();
        }
        return new EmergencyNumber(number, countryIso, mnc, emergencyServiceCategoryBitmask, emergencyUrns, emergencyNumberSourceBitmask, emergencyCallRouting);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initializeDatabaseSimStateChange(String simState) {
        if (TextUtils.isEmpty(this.mCountryIso) && isAirplaneModeEnabled()) {
            this.mCountryIso = updateCountryIso(simState);
        }
        logd("initializeDatabaseSimStateChange: countryIso = " + this.mCountryIso);
        if (TextUtils.isEmpty(this.mCountryIso)) {
            return;
        }
        updateEmergencyNumberDatabaseCountryChange(this.mCountryIso);
    }

    private String getCountryIsoBySimOperatorNumeric() {
        String numeric = this.mTelephonyManager.getSimOperatorNumericForPhone(this.mPhone.getPhoneId());
        logd("getCountryIsoBySimOperatorNumeric: get country from operator numeric. numeric = " + numeric);
        return (!TextUtils.isEmpty(numeric) && numeric.length() >= 3) ? MccTable.countryCodeForMcc(numeric.substring(0, 3)) : "";
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:14:0x0031  */
    private String updateCountryIso(String simState) {
        ServiceStateTracker serviceStateTracker = this.mPhone.getServiceStateTracker();
        LocaleTracker localeTracker = serviceStateTracker.getLocaleTracker();
        switch (simState) {
            case "LOADED":
            case "LOCKED":
                String countryIso = getCountryIsoBySimOperatorNumeric().toLowerCase();
                logd("updateCountryIso: getCountryIsoBySimOperatorNumeric: " + countryIso);
                if (TextUtils.isEmpty(countryIso)) {
                    String iccId = this.mCountryIsoConfig.getIccId(this.mPhone.getPhoneId());
                    if (TextUtils.isEmpty(iccId)) {
                        return null;
                    }
                    String countryIso2 = this.mCountryIsoConfig.getCountryIsoByIccId(iccId);
                    logd("updateCountryIso: getCountryIsoByIccId: " + countryIso2);
                    return countryIso2;
                }
                return countryIso;
            case "ABSENT":
                String countryIso3 = localeTracker.getLastKnownCountryIso();
                logd("updateCountryIso: getLastCountryIso: " + countryIso3);
                return countryIso3;
            default:
                return null;
        }
    }

    private List<EmergencyNumber> mergeSameNumbersInEmergencyNumberList(List<EmergencyNumber> emergencyNumberList) {
        if (emergencyNumberList.isEmpty()) {
            return emergencyNumberList;
        }
        List<EmergencyNumber> resultEmergencyNumberList = new ArrayList<>();
        for (EmergencyNumber num : emergencyNumberList) {
            if (resultEmergencyNumberList.contains(num)) {
                logd("mergeSameNumbersInEmergencyNumberList remove duplicate " + num);
            } else if (num.getEmergencyNumberSourceBitmask() == 2) {
                if (num.getEmergencyServiceCategoryBitmask() >= 0 && num.getEmergencyServiceCategoryBitmask() <= 255) {
                    resultEmergencyNumberList.add(num);
                }
            } else {
                resultEmergencyNumberList.add(num);
            }
        }
        if (resultEmergencyNumberList.isEmpty()) {
            return resultEmergencyNumberList;
        }
        Set<EmergencyNumber> mergedEmergencyNumber = new HashSet<>();
        for (int i = 0; i < resultEmergencyNumberList.size(); i++) {
            if (!mergedEmergencyNumber.contains(resultEmergencyNumberList.get(i))) {
                for (int j = i + 1; j < resultEmergencyNumberList.size(); j++) {
                    if (areSameEmergencyNumbersWithDiffCategory(resultEmergencyNumberList.get(i), resultEmergencyNumberList.get(j))) {
                        logd("mergeSameNumbersInEmergencyNumberList Found unexpected duplicate numbers with differenct category: " + resultEmergencyNumberList.get(i) + " vs " + resultEmergencyNumberList.get(j));
                        resultEmergencyNumberList.set(i, mergeCategoryForSameEmergencyNumber(resultEmergencyNumberList.get(i), resultEmergencyNumberList.get(j)));
                        mergedEmergencyNumber.add(resultEmergencyNumberList.get(j));
                    }
                    if (EmergencyNumber.areSameEmergencyNumbers(resultEmergencyNumberList.get(i), resultEmergencyNumberList.get(j))) {
                        logd("mergeSameNumbersInEmergencyNumberList Found unexpected duplicate numbers: " + resultEmergencyNumberList.get(i) + " vs " + resultEmergencyNumberList.get(j));
                        resultEmergencyNumberList.set(i, EmergencyNumber.mergeSameEmergencyNumbers(resultEmergencyNumberList.get(i), resultEmergencyNumberList.get(j)));
                        mergedEmergencyNumber.add(resultEmergencyNumberList.get(j));
                    }
                }
            }
        }
        int i2 = 0;
        while (i2 < resultEmergencyNumberList.size()) {
            if (mergedEmergencyNumber.contains(resultEmergencyNumberList.get(i2))) {
                resultEmergencyNumberList.remove(i2);
                i2--;
            }
            i2++;
        }
        return resultEmergencyNumberList;
    }

    private boolean areSameEmergencyNumbersWithDiffCategory(EmergencyNumber first, EmergencyNumber second) {
        if (first.getNumber().equals(second.getNumber()) && first.getCountryIso().equals(second.getCountryIso()) && first.getMnc().equals(second.getMnc()) && first.getEmergencyNumberSourceBitmask() == second.getEmergencyNumberSourceBitmask() && first.getEmergencyUrns().equals(second.getEmergencyUrns()) && first.getEmergencyCallRouting() == second.getEmergencyCallRouting()) {
            return ((second.isFromSources(32) ^ first.isFromSources(32)) || first.getEmergencyServiceCategoryBitmask() == second.getEmergencyServiceCategoryBitmask()) ? false : true;
        }
        return false;
    }

    private EmergencyNumber mergeCategoryForSameEmergencyNumber(EmergencyNumber first, EmergencyNumber second) {
        if (areSameEmergencyNumbersWithDiffCategory(first, second)) {
            return new EmergencyNumber(first.getNumber(), first.getCountryIso(), first.getMnc(), second.getEmergencyServiceCategoryBitmask() | first.getEmergencyServiceCategoryBitmask(), first.getEmergencyUrns(), first.getEmergencyNumberSourceBitmask(), first.getEmergencyCallRouting());
        }
        return null;
    }

    private String getMnc(int phoneId) {
        if (this.mTelephonyManager == null) {
            getTelephonyManager();
        }
        TelephonyManager telephonyManager = this.mTelephonyManager;
        if (telephonyManager == null) {
            return null;
        }
        String mnc = null;
        String networkNumeric = telephonyManager.getNetworkOperatorForPhone(phoneId);
        if (!TextUtils.isEmpty(networkNumeric) && networkNumeric.length() > 3) {
            mnc = networkNumeric.substring(3);
        }
        if (TextUtils.isEmpty(mnc)) {
            String simNumeric = this.mTelephonyManager.getSimOperatorNumericForPhone(phoneId);
            if (!TextUtils.isEmpty(simNumeric) && simNumeric.length() > 3) {
                mnc = simNumeric.substring(3);
            }
        }
        logd("getMnc: mnc = " + mnc);
        return mnc;
    }

    private enum EccTypeInfo {
        Police(1, 1),
        Amulance(2, 2),
        Fire(3, 4),
        Marine(4, 8),
        Mountain(5, 16),
        MIEC(6, 32),
        AIEC(7, 64);

        public final int categoryBitmask;
        public final int eccinfoType;

        EccTypeInfo(int eccinfoType, int categoryBitmask) {
            this.eccinfoType = eccinfoType;
            this.categoryBitmask = categoryBitmask;
        }

        public static int getBitmask(int eccinfoType, int emergencyServiceCategoryBitmask) {
            boolean zeroBitmask = emergencyServiceCategoryBitmask == 0;
            for (EccTypeInfo typeInfo : values()) {
                if (typeInfo.eccinfoType == eccinfoType) {
                    return zeroBitmask ? typeInfo.categoryBitmask : typeInfo.categoryBitmask | emergencyServiceCategoryBitmask;
                }
            }
            return emergencyServiceCategoryBitmask;
        }
    }

    public EmergencyNumber getEmergencyNumber(String emergencyNumber) {
        String emergencyNumber2 = PhoneNumberUtils.stripSeparators(emergencyNumber);
        for (EmergencyNumber num : getEmergencyNumberList()) {
            if (num.getNumber().equals(emergencyNumber2)) {
                int routing = num.getEmergencyCallRouting();
                if (this.mTelephonyManager.getSimState(this.mPhone.getPhoneId()) != 5 || this.mPhone.getServiceState().isEmergencyOnly()) {
                    logd("getEmergencyNumber: set emergency routing");
                    routing = 1;
                }
                return new EmergencyNumber(num.getNumber(), num.getCountryIso(), num.getMnc(), num.getEmergencyServiceCategoryBitmask(), num.getEmergencyUrns(), num.getEmergencyNumberSourceBitmask(), routing);
            }
        }
        return null;
    }

    public void setIccId(String iccId) {
        CountryIsoConfig countryIsoConfig = this.mCountryIsoConfig;
        if (countryIsoConfig != null) {
            String countryIso = countryIsoConfig.getCountryIsoByIccId(iccId);
            logd("setIccId: getCountryIsoByIccId " + iccId + " countryIso " + countryIso);
            if (TextUtils.isEmpty(countryIso)) {
                return;
            }
            updateEmergencyNumberDatabaseCountryChange(countryIso);
        }
    }

    public void setSimOperatorNumeric(String numeric) {
        String mcc = null;
        String countryIso = "";
        if (!TextUtils.isEmpty(numeric)) {
            try {
                mcc = numeric.substring(0, 3);
                countryIso = MccTable.countryCodeForMcc(mcc);
            } catch (StringIndexOutOfBoundsException ex) {
                loge("setSimOperatorNumeric: Can't get country from operator numeric. mcc = " + mcc + ". ex=" + ex);
            }
        }
        logd("setSimOperatorNumeric: countryIso " + countryIso);
        updateEmergencyNumberDatabaseCountryChange(countryIso);
    }

    private boolean isValidEccInfo(UniProtobufEccData.EccInfo eccInfo) {
        String eccInfoCardFlag = eccInfo.cardFlag.trim();
        logd("isValidEccInfo: eccInfoCardFlag =  " + eccInfoCardFlag);
        if (!this.hasMncFlag && eccInfo.mnc.equals(getMnc(this.mPhone.getPhoneId()))) {
            this.hasMncFlag = true;
        }
        if (eccInfoCardFlag.isEmpty()) {
            return true;
        }
        int phoneId = this.mPhone.getPhoneId();
        int simState = this.mTelephonyManager.getSimState(phoneId);
        if (ECCLIST_NO_CARD.equals(eccInfoCardFlag) && simState == 1) {
            return true;
        }
        return ECCLIST_WITH_CARD.equals(eccInfoCardFlag) && simState != 1;
    }

    private boolean isAirplaneModeEnabled() {
        ServiceStateTracker serviceStateTracker = this.mPhone.getServiceStateTracker();
        if (serviceStateTracker == null || serviceStateTracker.getServiceState().getState() != 3) {
            return false;
        }
        return true;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:14:0x0028  */
    private static boolean isSimPlugState(String simState) {
        switch (simState) {
            case "LOADED":
            case "LOCKED":
            case "ABSENT":
                return true;
            default:
                return false;
        }
    }

    public String getCountryIso() {
        return this.mCountryIso;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void removeEccListFromNetwork() {
        boolean needRemove = !this.mRadioEccListNotFromNetwork.equals(this.mEmergencyNumberListFromRadio);
        logd("removeEccListFromNetwork: needRemove = " + needRemove);
        if (needRemove) {
            updateRadioEmergencyNumberListAndNotify(this.mRadioEccListNotFromNetwork);
        }
    }

    private boolean needLoadDataBaseEccList() {
        if (this.mTelephonyManager == null) {
            getTelephonyManager();
        }
        if (this.mTelephonyManager == null) {
            return false;
        }
        int phoneId = this.mPhone.getPhoneId();
        SubscriptionManager subscriptionManager = SubscriptionManager.from(this.mPhone.getContext());
        logd(" needLoadDataBaseEccList: phoneId = " + phoneId);
        if (!this.mTelephonyManager.hasIccCard(phoneId) && subscriptionManager != null && subscriptionManager.getActiveSubscriptionInfoCount() > 0) {
            logd(" needLoadDataBaseEccList: getActiveSubscriptionInfoCount() = " + subscriptionManager.getActiveSubscriptionInfoCount());
            if (!this.mEmergencyNumberListFromDatabase.isEmpty()) {
                this.mEmergencyNumberListFromDatabase.clear();
            }
            return false;
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean needInitDatabase(int phoneId, int intentPhoneId, String simState) {
        SubscriptionManager subscriptionManager;
        if (phoneId == intentPhoneId) {
            return isSimPlugState(simState);
        }
        if (this.mTelephonyManager == null) {
            getTelephonyManager();
        }
        if (this.mTelephonyManager == null) {
            return false;
        }
        logd(" needInitDatabase: mTelephonyManager.hasIccCard(phoneId) = " + this.mTelephonyManager.hasIccCard(phoneId));
        if ("LOADED".equals(simState)) {
            return !this.mTelephonyManager.hasIccCard(phoneId);
        }
        if (!"ABSENT".equals(simState) || (subscriptionManager = SubscriptionManager.from(this.mPhone.getContext())) == null) {
            return false;
        }
        logd(" needInitDatabase: getActiveSubscriptionInfoCount() = " + subscriptionManager.getActiveSubscriptionInfoCount());
        return subscriptionManager.getActiveSubscriptionInfoCount() == 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void logd(String str) {
        Rlog.d(TAG, "[" + this.mPhone.getPhoneId() + "] " + str);
    }

    private void loge(String str) {
        Rlog.e(TAG, "[" + this.mPhone.getPhoneId() + "] " + str);
    }
}
