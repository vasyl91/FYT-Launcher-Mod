package com.android.internal.telephony.data;

import android.app.ActivityManager;
import android.app.IActivityManager;
import android.app.IProcessObserver;
import android.app.TaskStackListener;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.INetworkAdapterService;
import android.net.INetworkReachableNotifier;
import android.net.NetworkAdapterManager;
import android.net.TrafficStats;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemProperties;
import android.telephony.NetworkRegistrationInfo;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.telephony.data.DataProfile;
import android.text.TextUtils;
import android.util.Log;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.PhoneConstants;
import com.android.internal.telephony.PhoneFactory;
import com.android.unisoc.telephony.RadioInteractor;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniDataStallRecoveryManager extends DataStallRecoveryManager {
    private static final long APP_DELAY_TIME = 60000;
    private static final long APP_GAP_TIME = 600000;
    private static final int APP_TOGGLE_TIMES = 2;
    private static final long DATA_STALL_DELAY_TIME = 600000;
    private static final boolean DBG = true;
    private static final int DELAY_GET_NETWORK_REACHABLE = 3000;
    private static final int MODE_APPLICATION = 4;
    private static final int MSG_INIT_REGISTER = 1001;
    private static final int MSG_PROCESS_TOPACTIVITY = 1002;
    private static final int MSG_STOP_TOGGLE = 1000;
    private static final String PERSIST_RADIO_DATA_RECOVERY = "persist.radio.dataconn.recovery";
    private static final String PERSIST_VENDOR_TELEPHONY_OPTIMIZATION = "persist.vendor.radio.tele.optimization";
    private static final int RECOVERY_ACTION_GET_DATA_CALL_LIST = 0;
    private static final int RECOVERY_ACTION_REREGITSTER = 3;
    private static final int RECOVERY_ACTION_RESTART_DATA = 2;
    private static final int RECOVERY_ACTION_RESTART_MODEM = 5;
    private static final int RECOVERY_ACTION_RESTART_RADIO = 4;
    private static final int RECOVERY_ACTION_TOGGLE_NR = 1;
    private static final int VENDOR_BASE = 1000;
    private static final int VENDOR_EVENT_DO_RECOVERY = 2;
    private static final int VENDOR_EVENT_DO_RECOVERY_RIGHTNOW = 1001;
    private static final Timer mAppTimer = new Timer();
    private static final Timer mDataStallTimer = new Timer();
    protected final String LOG_TAG;
    private final String PERMISSION_PACKAGENAME;
    private IActivityManager mAM;
    private String[] mActivities;
    private ActivityManager mActivityManager;
    private boolean mAllowedAppFG;
    private boolean mAppClosedNr;
    private TimerTask mAppTask;
    private String[] mBoostSupported;
    private boolean mClosedNr;
    private Context mContext;
    private DataStallRecoveryManager.DataStallRecoveryManagerCallback mDataStallRecoveryManagerCallback;
    private TimerTask mDataStallTask;
    private TxRxSum mDataStallTxRxSum;
    private int mDataState;
    private int mDefaultDataPhoneId;
    private final INetworkReachableNotifier mDoRecoveryCallback;
    private UpdateThreadHandler mHandler;
    private HandlerThread mHandlerThread;
    private boolean mIsScreenOn;
    private String mLastTopActivity;
    private NetworkAdapterManager mNetworkAdapterManager;
    private Phone mPhone;
    private IProcessObserver mProcessObserver;
    private RadioInteractor mRadioInteractor;
    private BroadcastReceiver mReceiver;
    private long mRxPackets;
    private long mSentSinceLastRecv;
    private boolean mStartDataStall;
    private boolean mStartDoRecovery;
    private boolean mStartMonitor;
    private boolean mStopToggle;
    private SubscriptionManager mSubscriptionManager;
    private final TaskStackListener mTaskStackListener;
    private TelephonyManager mTelephonyManager;
    private int mToggleTimes;
    private String mTopActivity;
    private long mTxPackets;
    private int mUniRecoveryAction;
    private final DataServiceManager mWwanDataServiceManager;

    public UniDataStallRecoveryManager(Phone phone, DataNetworkController dataNetworkController, DataServiceManager dataServiceManager, Looper looper, DataStallRecoveryManager.DataStallRecoveryManagerCallback callback) {
        super(phone, dataNetworkController, dataServiceManager, looper, callback);
        this.LOG_TAG = "UniDataStallRecoveryManager ";
        this.PERMISSION_PACKAGENAME = "com.google.android.permissioncontroller";
        this.mDefaultDataPhoneId = 0;
        this.mDataState = -1;
        this.mUniRecoveryAction = 0;
        this.mToggleTimes = 0;
        this.mIsScreenOn = false;
        this.mStartMonitor = false;
        this.mStartDataStall = false;
        this.mStartDoRecovery = false;
        this.mAllowedAppFG = false;
        this.mStopToggle = false;
        this.mClosedNr = false;
        this.mAppClosedNr = false;
        this.mTxPackets = 0L;
        this.mRxPackets = 0L;
        this.mLastTopActivity = "";
        this.mProcessObserver = null;
        this.mHandlerThread = null;
        this.mHandler = null;
        this.mDataStallTxRxSum = new TxRxSum(0L, 0L);
        this.mAppTask = null;
        this.mDataStallTask = null;
        this.mReceiver = new BroadcastReceiver() { // from class: com.android.internal.telephony.data.UniDataStallRecoveryManager.2
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                if (intent == null) {
                    return;
                }
                String action = intent.getAction();
                UniDataStallRecoveryManager.this.log("onReceive action: " + action);
                if ("android.intent.action.SCREEN_ON".equals(action)) {
                    UniDataStallRecoveryManager.this.mIsScreenOn = UniDataStallRecoveryManager.DBG;
                } else if ("android.intent.action.SCREEN_OFF".equals(action)) {
                    UniDataStallRecoveryManager.this.mIsScreenOn = false;
                }
            }
        };
        this.mTaskStackListener = new TaskStackListener() { // from class: com.android.internal.telephony.data.UniDataStallRecoveryManager.4
            public void onTaskStackChanged() {
                if (Log.isLoggable("UniDataStallRecoveryManager ", 3)) {
                    UniDataStallRecoveryManager.this.log("onTaskStackChanged");
                }
                UniDataStallRecoveryManager.this.mHandler.obtainMessage(UniDataStallRecoveryManager.MSG_PROCESS_TOPACTIVITY).sendToTarget();
            }
        };
        this.mDoRecoveryCallback = new INetworkReachableNotifier.Stub() { // from class: com.android.internal.telephony.data.UniDataStallRecoveryManager.5
            public void onNotifyNetworkReachable(boolean isReachable) {
                UniDataStallRecoveryManager.this.log("onNotifyNetworkReachable: isReachable = " + isReachable);
                UniDataStallRecoveryManager.this.removeMessages(1001);
                Message message = UniDataStallRecoveryManager.this.obtainMessage();
                message.what = 1001;
                message.obj = Boolean.valueOf(isReachable);
                UniDataStallRecoveryManager.this.sendMessage(message);
            }
        };
        this.mPhone = phone;
        this.mContext = phone.getContext();
        this.mDataStallRecoveryManagerCallback = callback;
        this.mWwanDataServiceManager = dataServiceManager;
        this.mNetworkAdapterManager = NetworkAdapterManager.getInstance();
        if (isSuperBoostSupport()) {
            dataNetworkController.registerDataNetworkControllerCallback(new DataNetworkController.DataNetworkControllerCallback(new Executor() { // from class: com.android.internal.telephony.data.UniDataStallRecoveryManager$$ExternalSyntheticLambda1
                @Override // java.util.concurrent.Executor
                public final void execute(Runnable runnable) {
                    this.f$0.post(runnable);
                }
            }) { // from class: com.android.internal.telephony.data.UniDataStallRecoveryManager.1
                public void onInternetDataNetworkConnected(List<DataProfile> dataProfiles) {
                    UniDataStallRecoveryManager.this.log("onInternetDataNetworkConnected()");
                    UniDataStallRecoveryManager.this.onDataNetworkConnected();
                }

                public void onInternetDataNetworkDisconnected() {
                    UniDataStallRecoveryManager.this.log("onInternetDataNetworkDisconnected()");
                    UniDataStallRecoveryManager.this.onDataNetworkDisconnected();
                }
            });
            this.mActivities = this.mContext.getResources().getStringArray(134283267);
            log("UniDataStallRecoveryManager.constructor");
            this.mIsScreenOn = isScreenOn();
            IntentFilter filter = new IntentFilter();
            filter.addAction("android.intent.action.SCREEN_ON");
            filter.addAction("android.intent.action.SCREEN_OFF");
            this.mContext.registerReceiver(this.mReceiver, filter);
            initThread();
        }
    }

    private boolean isScreenOn() {
        PowerManager pm = (PowerManager) this.mContext.getSystemService("power");
        if (pm != null) {
            return pm.isScreenOn();
        }
        return false;
    }

    private boolean isSuperBoostSupport() {
        return SystemProperties.getBoolean(PERSIST_VENDOR_TELEPHONY_OPTIMIZATION, false);
    }

    private void initThread() {
        HandlerThread handlerThread = new HandlerThread("AppGapTask");
        this.mHandlerThread = handlerThread;
        handlerThread.start();
        UpdateThreadHandler updateThreadHandler = new UpdateThreadHandler(this.mHandlerThread.getLooper());
        this.mHandler = updateThreadHandler;
        updateThreadHandler.obtainMessage(1001).sendToTarget();
    }

    protected class UpdateThreadHandler extends Handler {
        public UpdateThreadHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1000:
                    UniDataStallRecoveryManager.this.log("MSG_STOP_TOGGLE");
                    UniDataStallRecoveryManager.this.mStopToggle = false;
                    UniDataStallRecoveryManager.this.mToggleTimes = 0;
                    return;
                case 1001:
                    UniDataStallRecoveryManager uniDataStallRecoveryManager = UniDataStallRecoveryManager.this;
                    uniDataStallRecoveryManager.mActivityManager = (ActivityManager) uniDataStallRecoveryManager.mContext.getSystemService("activity");
                    UniDataStallRecoveryManager.this.registerProcessObserver();
                    UniDataStallRecoveryManager.this.mAM = ActivityManager.getService();
                    try {
                        UniDataStallRecoveryManager.this.mAM.registerTaskStackListener(UniDataStallRecoveryManager.this.mTaskStackListener);
                        return;
                    } catch (RemoteException e) {
                        UniDataStallRecoveryManager.this.log("Cannot register activity monitoring: " + e);
                        throw new RuntimeException(e);
                    }
                case UniDataStallRecoveryManager.MSG_PROCESS_TOPACTIVITY /* 1002 */:
                    if (Log.isLoggable("UniDataStallRecoveryManager ", 3)) {
                        UniDataStallRecoveryManager.this.log("MSG_PROCESS_TOPACTIVITY");
                    }
                    UniDataStallRecoveryManager.this.handleTopActivity();
                    return;
                default:
                    return;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDataNetworkConnected() {
        if (this.mStartDoRecovery || this.mStartDataStall) {
            return;
        }
        log("onDataNetworkConnected()");
        setUniRecoveryAction(1);
        startDataStall();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDataNetworkDisconnected() {
        if (this.mStartDoRecovery || !this.mStartDataStall) {
            return;
        }
        log("onDataNetworkDisconnected()");
        this.mStartDataStall = false;
        setUniRecoveryAction(1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setGapAppTimer() {
        log("setGapAppTimer");
        this.mStopToggle = DBG;
        UpdateThreadHandler updateThreadHandler = this.mHandler;
        updateThreadHandler.sendMessageDelayed(updateThreadHandler.obtainMessage(1000), 600000L);
    }

    private class AppTask extends TimerTask {
        private AppTask() {
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            if (!UniDataStallRecoveryManager.this.mAllowedAppFG || !UniDataStallRecoveryManager.this.shouldDoMonitor()) {
                return;
            }
            long curTxPackets = TrafficStats.getMobileTxPackets();
            long curRxPackets = TrafficStats.getMobileRxPackets();
            if (Log.isLoggable("UniDataStallRecoveryManager ", 3)) {
                UniDataStallRecoveryManager.this.log("mApp curTxPts: " + curTxPackets + ", curRxPts: " + curRxPackets);
            }
            long sent = curTxPackets - UniDataStallRecoveryManager.this.mTxPackets;
            long recv = curRxPackets - UniDataStallRecoveryManager.this.mRxPackets;
            UniDataStallRecoveryManager.this.mTxPackets = curTxPackets;
            UniDataStallRecoveryManager.this.mRxPackets = curRxPackets;
            UniDataStallRecoveryManager.this.log("mApp sent: " + sent + ", recv: " + recv);
            if (UniDataStallRecoveryManager.this.mStopToggle) {
                return;
            }
            if ((recv > 0 && sent / recv > 5) || recv == 0) {
                UniDataStallRecoveryManager.this.switchNR();
                UniDataStallRecoveryManager.this.mToggleTimes++;
                if (UniDataStallRecoveryManager.this.mToggleTimes >= 2) {
                    UniDataStallRecoveryManager.this.setGapAppTimer();
                }
            }
        }
    }

    private class DataStallTask extends TimerTask {
        private DataStallTask() {
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            if (!UniDataStallRecoveryManager.this.mAllowedAppFG && UniDataStallRecoveryManager.this.mIsScreenOn) {
                UniDataStallRecoveryManager.this.updateDataStallInfo();
            }
        }
    }

    private void startAppTask() {
        Timer timer;
        if (shouldDoMonitor() && (timer = mAppTimer) != null) {
            TimerTask timerTask = this.mAppTask;
            if (timerTask != null) {
                timerTask.cancel();
                this.mAppTask = null;
            }
            AppTask appTask = new AppTask();
            this.mAppTask = appTask;
            timer.schedule(appTask, APP_DELAY_TIME, APP_DELAY_TIME);
        }
    }

    private void startDataStallTask() {
        Timer timer;
        if (shouldDoMonitor() && (timer = mDataStallTimer) != null) {
            TimerTask timerTask = this.mDataStallTask;
            if (timerTask != null) {
                timerTask.cancel();
                this.mDataStallTask = null;
            }
            DataStallTask dataStallTask = new DataStallTask();
            this.mDataStallTask = dataStallTask;
            timer.schedule(dataStallTask, 600000L, 600000L);
            log("startDataStallTask");
        }
    }

    private boolean shouldMonitorActivity() {
        getSubscriptionManager();
        SubscriptionManager subscriptionManager = this.mSubscriptionManager;
        if (subscriptionManager != null) {
            this.mDefaultDataPhoneId = subscriptionManager.getDefaultDataPhoneId();
        }
        if (this.mPhone.getPhoneId() != this.mDefaultDataPhoneId) {
            return false;
        }
        return DBG;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean shouldDoMonitor() {
        getSubscriptionManager();
        SubscriptionManager subscriptionManager = this.mSubscriptionManager;
        if (subscriptionManager != null) {
            this.mDefaultDataPhoneId = subscriptionManager.getDefaultDataPhoneId();
        }
        if (this.mPhone.getPhoneId() != this.mDefaultDataPhoneId) {
            return false;
        }
        getTelephonyManager();
        TelephonyManager telephonyManager = this.mTelephonyManager;
        if (telephonyManager != null) {
            this.mDataState = telephonyManager.getDataState();
            if (Log.isLoggable("UniDataStallRecoveryManager ", 3)) {
                log("mDataState: " + this.mDataState);
            }
        }
        if (2 != this.mDataState) {
            return false;
        }
        return DBG;
    }

    private void startDataStall() {
        if (shouldDoMonitor()) {
            log("startDataStall");
            this.mStartDataStall = DBG;
            this.mDataStallTxRxSum.updateTotalTxRxSum();
            startDataStallTask();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void registerProcessObserver() {
        if (this.mProcessObserver == null) {
            try {
                IProcessObserver.Stub stub = new IProcessObserver.Stub() { // from class: com.android.internal.telephony.data.UniDataStallRecoveryManager.3
                    public void onForegroundActivitiesChanged(int pid, int uid, boolean fg) {
                        if (Log.isLoggable("UniDataStallRecoveryManager ", 3)) {
                            UniDataStallRecoveryManager.this.log("onForegroundActivitiesChanged pid: " + pid + ", uid: " + uid + ", fg: " + fg);
                        }
                        UniDataStallRecoveryManager.this.mHandler.obtainMessage(UniDataStallRecoveryManager.MSG_PROCESS_TOPACTIVITY).sendToTarget();
                    }

                    public void onForegroundServicesChanged(int pid, int uid, int serviceTypes) {
                    }

                    public void onProcessDied(int pid, int uid) {
                    }
                };
                log("Started to observe the foreground activity");
                this.mProcessObserver = stub;
                if (this.mActivityManager == null) {
                    return;
                }
                ActivityManager.getService().registerProcessObserver(this.mProcessObserver);
            } catch (RemoteException e) {
                log("Failed to register the process observer");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleTopActivity() {
        if (topActivityChanged()) {
            boolean isAllowedApp = curActivityInTop();
            if (isAllowedApp && !this.mStartMonitor && !this.mAllowedAppFG) {
                if (Log.isLoggable("UniDataStallRecoveryManager ", 3)) {
                    log("mTxPts: " + this.mTxPackets + ", mRxPts: " + this.mRxPackets);
                }
                calculateAppPackets();
                this.mStartMonitor = DBG;
                setUniRecoveryAction(1);
                this.mAllowedAppFG = DBG;
                this.mStartDataStall = false;
                return;
            }
            if (!isAllowedApp && this.mStartMonitor && this.mAllowedAppFG) {
                this.mStartMonitor = false;
                setUniRecoveryAction(1);
                this.mAllowedAppFG = false;
                startDataStall();
                if (this.mAppClosedNr) {
                    log("mAppClosedNr: true, setNrEnabled true");
                    setNrEnabled(DBG);
                    this.mAppClosedNr = false;
                }
            }
        }
    }

    private boolean topActivityChanged() {
        List<ActivityManager.RunningTaskInfo> runningTasks;
        ComponentName componentInfo;
        if (Log.isLoggable("UniDataStallRecoveryManager ", 3)) {
            log("topActivityChanged: ");
        }
        ActivityManager am = (ActivityManager) this.mContext.getSystemService("activity");
        if (am == null || (runningTasks = am.getRunningTasks(1)) == null || runningTasks.size() <= 0 || (componentInfo = runningTasks.get(0).topActivity) == null) {
            return false;
        }
        String topActivity = componentInfo.getClassName();
        if (Log.isLoggable("UniDataStallRecoveryManager ", 3)) {
            log("topActivity: " + topActivity + ", mLastTopActivity: " + this.mLastTopActivity);
        }
        if (topActivity.equals(this.mLastTopActivity)) {
            return false;
        }
        this.mLastTopActivity = topActivity;
        return DBG;
    }

    private boolean curActivityInTop() {
        boolean activated = false;
        String[] strArr = this.mActivities;
        if (strArr == null || strArr.length == 0) {
            return false;
        }
        if (Log.isLoggable("UniDataStallRecoveryManager ", 3)) {
            log("mLastTopActivity: " + this.mLastTopActivity);
        }
        if (TextUtils.isEmpty(this.mLastTopActivity)) {
            return false;
        }
        int i = 0;
        while (true) {
            String[] strArr2 = this.mActivities;
            if (i >= strArr2.length) {
                break;
            }
            if (this.mLastTopActivity.equals(strArr2[i])) {
                log("mTopActivity: " + this.mLastTopActivity);
                activated = DBG;
            }
            i++;
        }
        if (Log.isLoggable("UniDataStallRecoveryManager ", 3)) {
            log("activated : " + activated);
        }
        return activated;
    }

    private void calculateAppPackets() {
        if (shouldDoMonitor()) {
            this.mTxPackets = TrafficStats.getMobileTxPackets();
            this.mRxPackets = TrafficStats.getMobileRxPackets();
            startAppTask();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void switchNR() {
        log("switch NR network");
        if (isSaState() || isNsaState()) {
            setNrEnabled(false);
            this.mAppClosedNr = DBG;
        } else {
            setNrEnabled(DBG);
            this.mAppClosedNr = false;
        }
    }

    private void getTelephonyManager() {
        if (this.mTelephonyManager == null) {
            log("getTelephonyManager mPhone.getSubId(): " + this.mPhone.getSubId());
            this.mTelephonyManager = TelephonyManager.from(this.mContext).createForSubscriptionId(this.mPhone.getSubId());
        }
    }

    private void getSubscriptionManager() {
        if (this.mSubscriptionManager == null) {
            this.mSubscriptionManager = SubscriptionManager.from(this.mContext);
        }
    }

    private void getRadioInteractor() {
        if (this.mRadioInteractor == null) {
            this.mRadioInteractor = new RadioInteractor(this.mContext);
        }
    }

    private void doCustomRecovery() {
        getSubscriptionManager();
        SubscriptionManager subscriptionManager = this.mSubscriptionManager;
        if (subscriptionManager != null) {
            this.mDefaultDataPhoneId = subscriptionManager.getDefaultDataPhoneId();
        }
        if (this.mPhone.getPhoneId() != this.mDefaultDataPhoneId) {
            return;
        }
        log("doCustomRecovery");
        if (isRecoveryAlreadyStarted()) {
            log("DSRM isRecoveryAlreadyStarted");
            setUniRecoveryAction(1);
        } else {
            this.mStartDoRecovery = DBG;
            doUniRecovery();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateDataStallInfo() {
        if (shouldDoMonitor()) {
            TxRxSum preTxRxSum = new TxRxSum(this.mDataStallTxRxSum);
            this.mDataStallTxRxSum.updateTotalTxRxSum();
            log("updateDataStallInfo: preTxRxSum= " + preTxRxSum.toString() + ", mDataStallTxRxSum=" + this.mDataStallTxRxSum.toString());
            long sent = this.mDataStallTxRxSum.txPkts - preTxRxSum.txPkts;
            long received = this.mDataStallTxRxSum.rxPkts - preTxRxSum.rxPkts;
            if (sent > 0 && received > 0) {
                this.mSentSinceLastRecv = 0L;
            } else if (sent > 0 && received == 0) {
                if (isPhoneStateIdle()) {
                    this.mSentSinceLastRecv += sent;
                } else {
                    this.mSentSinceLastRecv = 0L;
                }
                log("updateDataStallInfo: sent=" + sent + " mSentSinceLastRecv=" + this.mSentSinceLastRecv);
            } else if (sent == 0 && received > 0) {
                this.mSentSinceLastRecv = 0L;
            }
            if (this.mSentSinceLastRecv == 0 && this.mUniRecoveryAction == 2 && this.mClosedNr) {
                log("updateDataStallInfo normal txrx, setNrEnabled true");
                setNrEnabled(DBG);
                this.mClosedNr = false;
            }
            if (this.mSentSinceLastRecv >= 10) {
                doCustomRecovery();
            }
        }
    }

    private boolean isPhoneStateIdle() {
        for (int i = 0; i < TelephonyManager.getDefault().getPhoneCount(); i++) {
            Phone phone = PhoneFactory.getPhone(i);
            if (phone != null && phone.getState() != PhoneConstants.State.IDLE) {
                log("isPhoneStateIdle: Voice call active on sub: " + i);
                return false;
            }
        }
        return DBG;
    }

    private static class TxRxSum {
        public long rxPkts;
        public long txPkts;

        public TxRxSum() {
            reset();
        }

        public TxRxSum(long txPkts, long rxPkts) {
            this.txPkts = txPkts;
            this.rxPkts = rxPkts;
        }

        public TxRxSum(TxRxSum sum) {
            this.txPkts = sum.txPkts;
            this.rxPkts = sum.rxPkts;
        }

        public void reset() {
            this.txPkts = -1L;
            this.rxPkts = -1L;
        }

        public String toString() {
            return "{txSum=" + this.txPkts + " rxSum=" + this.rxPkts + "}";
        }

        public void updateTotalTxRxSum() {
            this.txPkts = TrafficStats.getMobileTxPackets();
            this.rxPkts = TrafficStats.getMobileRxPackets();
        }
    }

    private void getDataCallList() {
        log("getDataCallList: request data call list");
        this.mWwanDataServiceManager.requestDataCallList((Message) null);
    }

    private void cleanUpDataNetwork() {
        log("cleanUpDataNetwork: notify clean up data network");
        this.mDataStallRecoveryManagerCallback.invokeFromExecutor(new Runnable() { // from class: com.android.internal.telephony.data.UniDataStallRecoveryManager$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m143xe14bd28f();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$cleanUpDataNetwork$0$com-android-internal-telephony-data-UniDataStallRecoveryManager, reason: not valid java name */
    /* synthetic */ void m143xe14bd28f() {
        this.mDataStallRecoveryManagerCallback.onDataStallReestablishInternet();
    }

    private void toggleNR() {
        log("toggleNR: toggle network");
        if (isSaState() || isNsaState()) {
            setNrEnabled(false);
            this.mClosedNr = DBG;
        } else {
            setNrEnabled(DBG);
            this.mClosedNr = false;
        }
    }

    private void reRegisterNetwork() {
        log("reRegisterNetwork: re-register");
        this.mPhone.getServiceStateTracker().reRegisterNetwork((Message) null);
    }

    private void powerOffRadio() {
        log("powerOffRadio: Restart radio");
        this.mPhone.getServiceStateTracker().powerOffRadioSafely();
    }

    private void rebootModem() {
        log("rebootModem: reboot modem");
        this.mPhone.rebootModem((Message) null);
    }

    private void doUniRecovery() {
        if (!shouldStopRecoveryAction(this.mUniRecoveryAction)) {
            switch (this.mUniRecoveryAction) {
                case 0:
                    log("doRecovery(): get data call list");
                    getDataCallList();
                    setUniRecoveryAction(1);
                    break;
                case 1:
                    log("doRecovery(): toggle network");
                    toggleNR();
                    setUniRecoveryAction(2);
                    break;
                case 2:
                    log("doRecovery(): cleanup all connections");
                    cleanUpDataNetwork();
                    setUniRecoveryAction(3);
                    break;
                case 3:
                    log("doRecovery(): reregister network");
                    reRegisterNetwork();
                    setUniRecoveryAction(4);
                    break;
                case 4:
                    log("doRecovery(): restarting radio");
                    powerOffRadio();
                    setUniRecoveryAction(5);
                    break;
                case 5:
                    log("doRecovery(): modem reset");
                    rebootModem();
                    setUniRecoveryAction(1);
                    break;
                default:
                    throw new RuntimeException("doRecovery: Invalid recoveryAction=" + this.mUniRecoveryAction);
            }
        }
        this.mSentSinceLastRecv = 0L;
    }

    private boolean isUniRecoveryAlreadyStarted() {
        log("isUniRecoveryAlreadyStarted: " + this.mUniRecoveryAction);
        if (this.mUniRecoveryAction != 1) {
            return DBG;
        }
        return false;
    }

    private boolean isRecoveryAlreadyStarted() {
        log("isRecoveryAlreadyStarted: " + getRecoveryAction());
        if (getRecoveryAction() != 0) {
            return DBG;
        }
        return false;
    }

    private boolean shouldStopRecoveryAction(int mUniRecoveryAction) {
        int maxAction = SystemProperties.getInt(PERSIST_RADIO_DATA_RECOVERY, 2);
        boolean mStopNextAction = mUniRecoveryAction > maxAction;
        log("shouldStopRecoveryAction: " + mStopNextAction);
        if (mStopNextAction) {
            setUniRecoveryAction(1);
        }
        return mStopNextAction;
    }

    public void setUniRecoveryAction(int action) {
        this.mUniRecoveryAction = action;
        if (Log.isLoggable("UniDataStallRecoveryManager ", 3)) {
            log("setUniRecoveryAction: " + this.mUniRecoveryAction);
        }
    }

    public int getUniRecoveryAction() {
        log("getUniRecoveryAction: " + this.mUniRecoveryAction);
        return this.mUniRecoveryAction;
    }

    private boolean isSaState() {
        getSubscriptionManager();
        SubscriptionManager subscriptionManager = this.mSubscriptionManager;
        if (subscriptionManager != null) {
            this.mDefaultDataPhoneId = subscriptionManager.getDefaultDataPhoneId();
        }
        if (SubscriptionManager.isValidPhoneId(this.mDefaultDataPhoneId)) {
            Phone phone = PhoneFactory.getPhone(this.mDefaultDataPhoneId);
            ServiceState ss = phone != null ? phone.getServiceState() : null;
            if (ss != null && ss.getDataRegState() == 0 && ss.getDataNetworkType() == 20) {
                return DBG;
            }
            return false;
        }
        return false;
    }

    private boolean isNsaState() {
        NetworkRegistrationInfo regInfo;
        getSubscriptionManager();
        SubscriptionManager subscriptionManager = this.mSubscriptionManager;
        if (subscriptionManager != null) {
            this.mDefaultDataPhoneId = subscriptionManager.getDefaultDataPhoneId();
        }
        if (SubscriptionManager.isValidPhoneId(this.mDefaultDataPhoneId)) {
            Phone phone = PhoneFactory.getPhone(this.mDefaultDataPhoneId);
            ServiceState ss = phone != null ? phone.getServiceState() : null;
            if (ss != null && ss.getDataRegState() == 0) {
                if ((ss.getDataNetworkType() == 13 || ss.getDataNetworkType() == 19) && (regInfo = ss.getNetworkRegistrationInfo(2, 1)) != null) {
                    if (regInfo.getNrState() == 3 || regInfo.getNrState() == 2) {
                        return DBG;
                    }
                    return false;
                }
                return false;
            }
            return false;
        }
        return false;
    }

    private void setNrEnabled(boolean nrEnable) {
        getSubscriptionManager();
        SubscriptionManager subscriptionManager = this.mSubscriptionManager;
        if (subscriptionManager != null) {
            this.mDefaultDataPhoneId = subscriptionManager.getDefaultDataPhoneId();
        }
        log("setNrEnabled: " + nrEnable + ", mDefaultDataPhoneId is " + this.mDefaultDataPhoneId);
        try {
            if (SubscriptionManager.isValidPhoneId(this.mDefaultDataPhoneId)) {
                getRadioInteractor();
                log("setNrEnabled: call mRadioInteractor.enableSmartNrSwitch ");
                this.mRadioInteractor.enableNrSwitch(this.mDefaultDataPhoneId, 4, nrEnable ? 1 : 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void handleMessage(Message msg) {
        log("handleMessage = " + msg);
        switch (msg.what) {
            case 2:
                boolean isReachable = getNetworkReachable();
                if (!isReachable) {
                    log("get network reachable fail, doRecovery");
                    super.handleMessage(msg);
                }
                break;
            case 1001:
                boolean isReachable2 = ((Boolean) msg.obj).booleanValue();
                unregisterNetworkReachableNotifier(this.mDoRecoveryCallback);
                if (!isReachable2) {
                    log("waiting for callback timeout or unreachable, doRecovery");
                    super.handleMessage(obtainMessage(2));
                }
                break;
            default:
                super.handleMessage(msg);
                break;
        }
    }

    private void registerNetworkReachableNotifier(INetworkReachableNotifier callback) {
        try {
            if (getNetworkAdapterService() != null) {
                getNetworkAdapterService().registerNetworkReachableNotifier(callback);
                log("registerNetworkReachableNotifier");
            }
        } catch (RemoteException e) {
            log("RemoteException happen in registerNetworkReachableNotifier!");
        } catch (RuntimeException e2) {
            log("RuntimeException happen in registerNetworkReachableNotifier!");
        }
    }

    private void unregisterNetworkReachableNotifier(INetworkReachableNotifier callback) {
        try {
            if (getNetworkAdapterService() != null) {
                getNetworkAdapterService().unregisterNetworkReachableNotifier(callback);
                log("unregisterNetworkReachableNotifier");
            }
        } catch (RemoteException e) {
            log("RemoteException happen in registerNetworkReachableNotifier!");
        } catch (RuntimeException e2) {
            log("RuntimeException happen in unregisterNetworkReachableNotifier!");
        }
    }

    private INetworkAdapterService getNetworkAdapterService() {
        return INetworkAdapterService.Stub.asInterface(ServiceManager.getService("network_adapter"));
    }

    private boolean getNetworkReachable() {
        try {
            NetworkAdapterManager networkAdapterManager = this.mNetworkAdapterManager;
            if (networkAdapterManager != null && networkAdapterManager.probeNetworkReachableActually()) {
                log("receive EVENT_DO_RECOVERY, waiting for onNotifyNetworkReachable");
                registerNetworkReachableNotifier(this.mDoRecoveryCallback);
                Message message = obtainMessage();
                message.what = 1001;
                message.obj = false;
                sendMessageDelayed(message, 3000L);
                return DBG;
            }
        } catch (RuntimeException e) {
            log("RuntimeException happen in getNetworkReachable!");
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(String s) {
        Rlog.d("UniDataStallRecoveryManager ", "[" + this.mPhone.getPhoneId() + "]" + s);
    }
}
