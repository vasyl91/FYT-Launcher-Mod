package com.android.internal.telephony;

import android.content.Context;
import android.os.Looper;
import android.util.SparseArray;
import com.android.ims.FeatureConnector;
import com.android.ims.ImsCall;
import com.android.ims.ImsManager;
import com.android.internal.telephony.data.DataNetworkController;
import com.android.internal.telephony.data.DataRetryManager;
import com.android.internal.telephony.data.DataServiceManager;
import com.android.internal.telephony.data.DataSettingsManager;
import com.android.internal.telephony.data.DataStallRecoveryManager;
import com.android.internal.telephony.data.UniDataNetworkController;
import com.android.internal.telephony.data.UniDataRetryManager;
import com.android.internal.telephony.data.UniDataSettingsManager;
import com.android.internal.telephony.data.UniDataStallRecoveryManager;
import com.android.internal.telephony.emergency.EmergencyNumberTracker;
import com.android.internal.telephony.emergency.UniEmergencyNumberTracker;
import com.android.internal.telephony.imsphone.ImsPhone;
import com.android.internal.telephony.imsphone.ImsPhoneCall;
import com.android.internal.telephony.imsphone.ImsPhoneCallTracker;
import com.android.internal.telephony.imsphone.ImsPhoneConnection;
import com.android.internal.telephony.imsphone.UniImsPhoneCallTracker;
import com.android.internal.telephony.imsphone.UniImsPhoneConnection;
import com.android.internal.telephony.phonebook.UniIccProvider;
import com.android.internal.telephony.phonebook.UniUiccPhoneBookController;
import com.android.internal.telephony.uicc.IccCardStatus;
import com.android.internal.telephony.uicc.IccFileHandler;
import com.android.internal.telephony.uicc.RuimRecords;
import com.android.internal.telephony.uicc.SIMRecords;
import com.android.internal.telephony.uicc.UiccCard;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.uicc.UiccProfile;
import com.android.internal.telephony.uicc.UniCsimFileHandler;
import com.android.internal.telephony.uicc.UniRuimRecords;
import com.android.internal.telephony.uicc.UniSIMFileHandler;
import com.android.internal.telephony.uicc.UniSIMRecords;
import com.android.internal.telephony.uicc.UniUiccProfile;
import com.android.internal.telephony.uicc.UniUiccSmsController;
import com.android.internal.telephony.uicc.UniUsimFileHandler;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniTelephonyComponentFactory extends TelephonyComponentFactory {
    private static final String TAG = "UniTelephonyComponentFactory";
    private static UniTelephonyComponentFactory sInstance;

    public UniTelephonyComponentFactory() {
        sInstance = this;
    }

    public static TelephonyComponentFactory getInstance() {
        if (sInstance == null) {
            sInstance = new UniTelephonyComponentFactory();
        }
        return sInstance;
    }

    public Phone makePhone(Context context, CommandsInterface ci, PhoneNotifier notifier, int phoneId, int precisePhoneType, TelephonyComponentFactory telephonyComponentFactory) {
        return new UniGsmCdmaPhone(context, ci, notifier, phoneId, precisePhoneType, telephonyComponentFactory);
    }

    public ImsPhoneConnection makeImsPhoneConnection(Phone phone, ImsCall imsCall, ImsPhoneCallTracker ct, ImsPhoneCall parent, boolean isUnknown) {
        return new UniImsPhoneConnection(phone, imsCall, ct, parent, isUnknown);
    }

    public ImsPhoneConnection makeImsPhoneConnection(Phone phone, String dialString, ImsPhoneCallTracker ct, ImsPhoneCall parent, boolean isEmergency, boolean isWpsCall) {
        return new UniImsPhoneConnection(phone, dialString, ct, parent, isEmergency, isWpsCall);
    }

    public ImsPhoneConnection makeImsPhoneConnection(Phone phone, String[] participantsToDial, ImsPhoneCallTracker ct, ImsPhoneCall parent, boolean isEmergency) {
        return new UniImsPhoneConnection(phone, participantsToDial, ct, parent, isEmergency);
    }

    public ImsPhoneCallTracker makeImsPhoneCallTracker(ImsPhone imsPhone) {
        return new UniImsPhoneCallTracker(imsPhone, new ImsPhoneCallTracker.ConnectorFactory() { // from class: com.android.internal.telephony.UniTelephonyComponentFactory$$ExternalSyntheticLambda0
            public final FeatureConnector create(Context context, int i, String str, FeatureConnector.Listener listener, Executor executor) {
                return ImsManager.getConnector(context, i, str, listener, executor);
            }
        });
    }

    public EmergencyNumberTracker makeEmergencyNumberTracker(Phone phone, CommandsInterface ci) {
        return new UniEmergencyNumberTracker(phone, ci);
    }

    public UiccProfile makeUiccProfile(Context context, CommandsInterface ci, IccCardStatus ics, int phoneId, UiccCard uiccCard, Object lock) {
        return new UniUiccProfile(context, ci, ics, phoneId, uiccCard, lock);
    }

    public SIMRecords makeSIMRecords(UiccCardApplication app, Context c, CommandsInterface ci) {
        return new UniSIMRecords(app, c, ci);
    }

    public SubscriptionInfoUpdater makeSubscriptionInfoUpdater(Looper looper, Context context, SubscriptionController sc) {
        return UniSubscriptionInfoUpdater.init(looper, context, sc);
    }

    public MultiSimSettingController initMultiSimSettingController(Context c, SubscriptionController sc) {
        return UniMultiSimSettingController.init(c, sc);
    }

    public SignalStrengthController makeSignalStrengthController(GsmCdmaPhone phone) {
        return new UniSignalStrengthController(phone);
    }

    public ServiceStateTracker makeServiceStateTracker(GsmCdmaPhone phone, CommandsInterface ci) {
        return new UniServiceStateTracker(phone, ci);
    }

    public DataSettingsManager makeDataSettingsManager(Phone phone, DataNetworkController dataNetworkController, Looper looper, DataSettingsManager.DataSettingsManagerCallback callback) {
        return new UniDataSettingsManager(phone, dataNetworkController, looper, callback);
    }

    public DataNetworkController makeDataNetworkController(Phone phone, Looper looper) {
        return new UniDataNetworkController(phone, looper);
    }

    public RuimRecords makeRuimRecords(UiccCardApplication app, Context c, CommandsInterface ci) {
        return new UniRuimRecords(app, c, ci);
    }

    public void makeUiccPhoneBookController() {
        new UniUiccPhoneBookController();
    }

    public IccPhoneBookInterfaceManager makeIccPhoneBookInterfaceManager(Phone phone) {
        return new UniIccPhoneBookInterfaceManager(phone);
    }

    public IccFileHandler makeSimFileHandler(UiccCardApplication app, String aid, CommandsInterface ci, Context c) {
        return new UniSIMFileHandler(app, aid, ci, c);
    }

    public IccFileHandler makeUsimFileHandler(UiccCardApplication app, String aid, CommandsInterface ci, Context c) {
        return new UniUsimFileHandler(app, aid, ci, c);
    }

    public IccFileHandler makeCsimFileHandler(UiccCardApplication app, String aid, CommandsInterface ci) {
        return new UniCsimFileHandler(app, aid, ci);
    }

    public AbsIccProvider makeIccProvider(Context c) {
        return new UniIccProvider(c);
    }

    public void makeUiccSmsController(Phone[] phone) {
        new UniUiccSmsController(phone);
    }

    public UniAbsSmsUtils makeUniAbsSmsUtils() {
        return new UniSmsUtils();
    }

    public DataRetryManager makeDataRetryManager(Phone phone, DataNetworkController dataNetworkController, SparseArray<DataServiceManager> dataServiceManagers, Looper looper, DataRetryManager.DataRetryManagerCallback callback) {
        return new UniDataRetryManager(phone, dataNetworkController, dataServiceManagers, looper, callback);
    }

    public DataStallRecoveryManager makeDataStallRecoveryManager(Phone phone, DataNetworkController dataNetworkController, DataServiceManager dataServiceManager, Looper looper, DataStallRecoveryManager.DataStallRecoveryManagerCallback callback) {
        return new UniDataStallRecoveryManager(phone, dataNetworkController, dataServiceManager, looper, callback);
    }
}
