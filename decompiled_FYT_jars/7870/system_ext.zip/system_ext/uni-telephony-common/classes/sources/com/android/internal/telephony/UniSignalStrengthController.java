package com.android.internal.telephony;

import android.os.AsyncResult;
import android.os.Message;
import android.telephony.NetworkRegistrationInfo;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniSignalStrengthController extends SignalStrengthController {
    private static final boolean DBG = false;
    private static final int EVENT_SERVICE_STATE_CHANGED = 11;
    private static final String TAG = "USSCtr";
    private SignalStrength mNewSignalStrength;
    private ServiceState mServiceState;

    /* JADX WARN: Multi-variable type inference failed */
    public UniSignalStrengthController(GsmCdmaPhone phone) {
        super(phone);
        this.mPhone.registerForServiceStateChanged(this, 11, (Object) null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void dispose() {
        super.dispose();
        this.mPhone.unregisterForServiceStateChanged(this);
    }

    public void handleMessage(Message msg) {
        switch (msg.what) {
            case 11:
                AsyncResult ar = (AsyncResult) msg.obj;
                if (ar.exception == null && ar.result != null) {
                    this.mServiceState = (ServiceState) ar.result;
                    onSignalStrengthResult(null);
                    break;
                }
                break;
            default:
                super.handleMessage(msg);
                break;
        }
    }

    protected boolean onSignalStrengthResult(AsyncResult ar) {
        if (ar != null) {
            if (ar.exception == null && ar.result != null) {
                this.mSignalStrength = (SignalStrength) ar.result;
                if (this.mPhone.getServiceStateTracker() != null) {
                    log("onSignalStrengthResult " + this.mSignalStrength);
                    this.mNewSignalStrength = this.mSignalStrength;
                    this.mSignalStrength.updateLevel(this.mCarrierConfig, this.mPhone.getServiceStateTracker().mSS);
                }
            } else {
                log("onSignalStrengthResult() Exception from RIL : " + ar.exception);
                this.mSignalStrength = new SignalStrength();
                this.mNewSignalStrength = new SignalStrength();
            }
        }
        ServiceState serviceState = this.mServiceState;
        if (serviceState != null) {
            NetworkRegistrationInfo psRegState = serviceState.getNetworkRegistrationInfo(2, 1);
            NetworkRegistrationInfo csRegState = this.mServiceState.getNetworkRegistrationInfo(1, 1);
            if (psRegState != null && !psRegState.isInService() && csRegState != null && !csRegState.isInService() && !this.mServiceState.isEmergencyOnly()) {
                log("onSignalStrengthResult show default ss");
                this.mSignalStrength = new SignalStrength();
            } else {
                log("onSignalStrengthResult show last");
                this.mSignalStrength = this.mNewSignalStrength;
            }
        }
        this.mSignalStrengthUpdatedTime = System.currentTimeMillis();
        boolean ssChanged = notifySignalStrength();
        return ssChanged;
    }

    protected void setSignalStrengthDefaultValues() {
        super.setSignalStrengthDefaultValues();
        this.mNewSignalStrength = new SignalStrength();
    }

    private static void log(String msg) {
    }
}
