package com.android.internal.telephony.data;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.NetworkInfo;
import android.os.AsyncResult;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.telephony.Rlog;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.data.ApnSetting;
import android.telephony.data.DataProfile;
import android.text.TextUtils;
import android.util.ArraySet;
import android.util.Pair;
import android.util.SparseArray;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.Phone;
import com.android.unisoc.telephony.RadioInteractor;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public final class UniDataRetryManager extends DataRetryManager {
    private static final String ACTION_REPORT_ERRLOG = "com.sprd.intent.action.COMMLOG_REPORTED";
    private static final int DATA_SETUP_EXCEPTION_EVENT_ID = 1;
    private static final int DATA_SETUP_EXCEPTION_SCENE_ID = 257;
    private static final boolean DBG = true;
    private static final int EVENT_DATA_RAT_CHANGED = 1001;
    private static final int EVENT_DATA_SETUP_RETRY = 1002;
    private static final int EVENT_RADIO_OFF_OR_NOT_AVAILABLE = 1004;
    private static final int EVENT_RADIO_ON = 1003;
    private static final String INTENT_RETRY_CLEAR_CODE = "com.android.internal.telephony.data-retry-clear-code";
    private static final String INTENT_RETRY_FROM_FAILURE = "com.android.internal.telephony.data-retry-from-failure";
    private static final String INTENT_RETRY_FROM_FAILURE_ALARM_EXTRA_TYPE = "retry_from_faliure_alarm_extra_type";
    private static final int MAX_RETRY = 3;
    private static final int PROTOCOL_IP = 0;
    private static final int PROTOCOL_IPV4V6 = 2;
    private static final int PROTOCOL_IPV6 = 1;
    private static final String RETRY_CLEAR_CODE = "clear_code_retry";
    private static final int VENDOR_BASE = 1000;
    protected final String LOG_TAG;
    private AlarmManager mAlarmManager;
    private AtomicInteger mClearCodeLatch;
    private int mCurrentSubId;
    public DataRetryManager.DataSetupRetryEntry mDataSetupRetryEntry;
    private int mFailCount;
    private boolean mIsWifiConnected;
    private final SubscriptionManager.OnSubscriptionsChangedListener mOnSubscriptionsChangeListener;
    private Phone mPhone;
    private int mPreFailcause;
    private BroadcastReceiver mReceiver;
    private ClearCodeRetryController mRetryController;
    private PendingIntent mRetryIntent;
    private CommandsInterface mRil;
    private DataSettingsManager.DataSettingsManagerCallback mSettingsCallback;
    private SubscriptionManager mSubscriptionManager;
    private Set<DataRetryManager.DataRetryManagerCallback> mUniDataRetryManagerCallbacks;

    public UniDataRetryManager(Phone phone, DataNetworkController dataNetworkController, SparseArray<DataServiceManager> dataServiceManagers, Looper looper, DataRetryManager.DataRetryManagerCallback dataRetryManagerCallback) {
        super(phone, dataNetworkController, dataServiceManagers, looper, dataRetryManagerCallback);
        this.LOG_TAG = "UniDataRetryManager: ";
        this.mFailCount = 0;
        this.mPreFailcause = 0;
        this.mIsWifiConnected = false;
        this.mClearCodeLatch = new AtomicInteger(0);
        this.mRetryIntent = null;
        this.mUniDataRetryManagerCallbacks = new ArraySet();
        this.mReceiver = new BroadcastReceiver() { // from class: com.android.internal.telephony.data.UniDataRetryManager.3
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                UniDataRetryManager.this.log("onReceive action=" + action);
                if (action.startsWith(UniDataRetryManager.INTENT_RETRY_CLEAR_CODE)) {
                    UniDataRetryManager.this.log("Retry for clear code");
                    UniDataRetryManager.this.onActionIntentRetryClearCode(intent);
                    return;
                }
                if (action.startsWith(UniDataRetryManager.INTENT_RETRY_FROM_FAILURE)) {
                    UniDataRetryManager.this.log("Retry from previous failure");
                    UniDataRetryManager.this.onActionIntentRetryFromFailure(intent);
                    return;
                }
                if (action.equals("android.net.wifi.STATE_CHANGE")) {
                    NetworkInfo networkInfo = (NetworkInfo) intent.getParcelableExtra("networkInfo");
                    boolean connected = (networkInfo == null || !networkInfo.isConnected()) ? false : UniDataRetryManager.DBG;
                    UniDataRetryManager.this.log("NETWORK_STATE_CHANGED_ACTION: old= " + UniDataRetryManager.this.mIsWifiConnected + " new= " + connected);
                    if (UniDataRetryManager.this.mFailCount > 0 && UniDataRetryManager.this.mIsWifiConnected && !connected && UniDataRetryManager.this.mRetryController != null) {
                        UniDataRetryManager.this.mRetryController.restartForChanged("WifiDisconnected");
                    }
                    UniDataRetryManager.this.mIsWifiConnected = connected;
                }
            }
        };
        SubscriptionManager.OnSubscriptionsChangedListener onSubscriptionsChangedListener = new SubscriptionManager.OnSubscriptionsChangedListener() { // from class: com.android.internal.telephony.data.UniDataRetryManager.4
            @Override // android.telephony.SubscriptionManager.OnSubscriptionsChangedListener
            public void onSubscriptionsChanged() {
                SubscriptionInfo subInfo = SubscriptionManager.from(UniDataRetryManager.this.mPhone.getContext()).getActiveSubscriptionInfo(UniDataRetryManager.this.mPhone.getSubId());
                String currentMccmnc = null;
                if (subInfo != null && subInfo.getMccString() != null && subInfo.getMncString() != null) {
                    currentMccmnc = subInfo.getMccString() + subInfo.getMncString();
                }
                UniDataRetryManager.this.log("mCurrentSubId: " + UniDataRetryManager.this.mCurrentSubId + ", mPhone.getSubId: " + UniDataRetryManager.this.mPhone.getSubId() + ", currentMccmnc: " + currentMccmnc);
                if (TextUtils.isEmpty(currentMccmnc) || UniDataRetryManager.this.mCurrentSubId == UniDataRetryManager.this.mPhone.getSubId()) {
                    return;
                }
                UniDataRetryManager uniDataRetryManager = UniDataRetryManager.this;
                uniDataRetryManager.mCurrentSubId = uniDataRetryManager.mPhone.getSubId();
                if (UniDataRetryManager.this.mRetryController != null && UniDataRetryManager.this.mRetryController.supportSpecialClearCode()) {
                    UniDataRetryManager.this.log("onSubscriptionsChanged registerRadioInteractor");
                    UniDataRetryManager.this.mRetryController.registerRadioInteractor();
                    UniDataRetryManager.this.registerClearCodeEvents();
                }
            }
        };
        this.mOnSubscriptionsChangeListener = onSubscriptionsChangedListener;
        this.mPhone = phone;
        this.mRil = phone.mCi;
        this.mCurrentSubId = this.mPhone.getSubId();
        log("UniDataRetryManager.constructor");
        this.mUniDataRetryManagerCallbacks.add(dataRetryManagerCallback);
        this.mRetryController = new ClearCodeRetryController(this.mPhone, this);
        this.mAlarmManager = (AlarmManager) this.mPhone.getContext().getSystemService("alarm");
        SubscriptionManager subscriptionManager = (SubscriptionManager) this.mPhone.getContext().getSystemService("telephony_subscription_service");
        this.mSubscriptionManager = subscriptionManager;
        subscriptionManager.addOnSubscriptionsChangedListener(onSubscriptionsChangedListener);
        IntentFilter filter = new IntentFilter();
        filter.addAction(INTENT_RETRY_CLEAR_CODE);
        filter.addAction(INTENT_RETRY_FROM_FAILURE);
        filter.addAction("android.net.wifi.STATE_CHANGE");
        this.mPhone.getContext().registerReceiver(this.mReceiver, filter, null, this.mPhone);
        dataNetworkController.registerDataNetworkControllerCallback(new DataNetworkController.DataNetworkControllerCallback(new Executor() { // from class: com.android.internal.telephony.data.UniDataRetryManager$$ExternalSyntheticLambda2
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f$0.post(runnable);
            }
        }) { // from class: com.android.internal.telephony.data.UniDataRetryManager.1
            public void onInternetDataNetworkConnected(List<DataProfile> dataProfiles) {
                UniDataRetryManager.this.onDataNetworkConnected();
                UniDataRetryManager.this.log("onDataNetworkConnected()");
            }
        });
        this.mSettingsCallback = new DataSettingsManager.DataSettingsManagerCallback(new Executor() { // from class: com.android.internal.telephony.data.UniDataRetryManager$$ExternalSyntheticLambda2
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                this.f$0.post(runnable);
            }
        }) { // from class: com.android.internal.telephony.data.UniDataRetryManager.2
            public void onDataEnabledChanged(boolean enabled, int reason, String callingPackage) {
                UniDataRetryManager.this.onDataSettingsEnabledChanged(enabled, reason);
            }
        };
        dataNetworkController.getDataSettingsManager().registerCallback(this.mSettingsCallback);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void registerClearCodeEvents() {
        log("registerClearCodeEvents()");
        this.mRil.registerForOn(this, EVENT_RADIO_ON, (Object) null);
        this.mRil.registerForOffOrNotAvailable(this, EVENT_RADIO_OFF_OR_NOT_AVAILABLE, (Object) null);
        this.mPhone.getServiceStateTracker().registerForDataRegStateOrRatChanged(1, this, EVENT_DATA_RAT_CHANGED, (Object) null);
    }

    public void handleMessage(Message msg) {
        switch (msg.what) {
            case EVENT_DATA_RAT_CHANGED /* 1001 */:
                log("EVENT_DATA_RAT_CHANGED: ");
                if (this.mRetryController != null) {
                    AsyncResult ar = (AsyncResult) msg.obj;
                    Pair<Integer, Integer> drsRatPair = (Pair) ar.result;
                    this.mRetryController.handleDataServiceChange(((Integer) drsRatPair.second).intValue(), ((Integer) drsRatPair.first).intValue());
                    log("EVENT_DATA_RAT_CHANGED: drsRatPair.second: " + drsRatPair.second + ",drsRatPair.first: " + drsRatPair.first);
                }
                break;
            case EVENT_DATA_SETUP_RETRY /* 1002 */:
                log("EVENT_DATA_SETUP_RETRY: ");
                Set<DataRetryManager.DataRetryManagerCallback> set = this.mUniDataRetryManagerCallbacks;
                if (set != null && this.mDataSetupRetryEntry != null) {
                    set.forEach(new Consumer() { // from class: com.android.internal.telephony.data.UniDataRetryManager$$ExternalSyntheticLambda0
                        @Override // java.util.function.Consumer
                        public final void accept(Object obj) {
                            this.f$0.m95xf0c59c82((DataRetryManager.DataRetryManagerCallback) obj);
                        }
                    });
                    log("EVENT_DATA_SETUP_RETRY: onDataNetworkSetupRetry");
                    break;
                }
                break;
            case EVENT_RADIO_ON /* 1003 */:
                log("EVENT_RADIO_ON: ");
                ClearCodeRetryController clearCodeRetryController = this.mRetryController;
                if (clearCodeRetryController != null) {
                    clearCodeRetryController.handleRadioOn();
                }
                break;
            case EVENT_RADIO_OFF_OR_NOT_AVAILABLE /* 1004 */:
                log("EVENT_RADIO_OFF_OR_NOT_AVAILABLE: ");
                onRadioOffOrNotAvailable();
                break;
            default:
                log("default msg = " + msg.what);
                super.handleMessage(msg);
                break;
        }
    }

    /* JADX INFO: renamed from: lambda$handleMessage$1$com-android-internal-telephony-data-UniDataRetryManager, reason: not valid java name */
    /* synthetic */ void m95xf0c59c82(final DataRetryManager.DataRetryManagerCallback callback) {
        callback.invokeFromExecutor(new Runnable() { // from class: com.android.internal.telephony.data.UniDataRetryManager$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m94xcb319381(callback);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$handleMessage$0$com-android-internal-telephony-data-UniDataRetryManager, reason: not valid java name */
    /* synthetic */ void m94xcb319381(DataRetryManager.DataRetryManagerCallback callback) {
        callback.onDataNetworkSetupRetry(this.mDataSetupRetryEntry);
    }

    public void evaluateDataSetupRetry(DataProfile dataProfile, int transport, DataNetworkController.NetworkRequestList requestList, int cause, long retryDelayMillis) {
        this.mDataSetupRetryEntry = new DataRetryManager.DataSetupRetryEntry.Builder().setRetryDelay(retryDelayMillis).setSetupRetryType(1).setNetworkRequestList(requestList).setDataProfile(dataProfile).setTransport(transport).build();
        log("evaluateDataSetupRetry() cause: " + cause);
        sendErrorReport(dataProfile, cause);
        switch (cause) {
            case 29:
            case 33:
                ClearCodeRetryController clearCodeRetryController = this.mRetryController;
                if (clearCodeRetryController != null && clearCodeRetryController.supportSpecialClearCode()) {
                    handleSpecialClearCode(cause);
                } else {
                    log("super evaluateDataSetupRetry");
                    super.evaluateDataSetupRetry(dataProfile, transport, requestList, cause, retryDelayMillis);
                }
                break;
            default:
                log("super.evaluateDataSetupRetry");
                super.evaluateDataSetupRetry(dataProfile, transport, requestList, cause, retryDelayMillis);
                break;
        }
    }

    private void sendErrorReport(DataProfile dataProfile, int cause) {
        ApnSetting apnSetting = dataProfile.getApnSetting();
        RadioInteractor radioInteractor = new RadioInteractor(this.mPhone.getContext());
        String cpInfo = radioInteractor.getExceptionEvents(1, DATA_SETUP_EXCEPTION_SCENE_ID, 0, 0, this.mPhone.getPhoneId());
        if (cpInfo != null && apnSetting != null) {
            Intent intent = new Intent(ACTION_REPORT_ERRLOG);
            intent.putExtra("FaultId", 1);
            intent.putExtra("SceneId", DATA_SETUP_EXCEPTION_SCENE_ID);
            intent.putExtra("ErrorCode", cause);
            intent.putExtra("Type", ApnSetting.getApnTypesStringFromBitmask(apnSetting.getApnTypeBitmask()));
            intent.putExtra("Carrier", apnSetting.getEntryName());
            intent.putExtra("Apn", apnSetting.getApnName());
            intent.putExtra("Proxy", apnSetting.getProxyAddressAsString());
            intent.putExtra("Port", apnSetting.getProxyPort());
            intent.putExtra("Mmsc", apnSetting.getMmsc());
            intent.putExtra("MmsProxy", apnSetting.getMmsProxyAddressAsString());
            intent.putExtra("User", apnSetting.getUser());
            intent.putExtra("AuthType", apnSetting.getAuthType());
            intent.putExtra("Numeric", apnSetting.getOperatorNumeric());
            intent.putExtra("Protocol", getStringProtocol(apnSetting.getProtocol()));
            intent.putExtra("RoamingProtocol", getStringProtocol(apnSetting.getRoamingProtocol()));
            intent.putExtra("Mtu", apnSetting.getMtuV4());
            intent.putExtra("State", 65535);
            intent.putExtra("SimIndex", this.mPhone.getPhoneId());
            intent.putExtra("CpInfo", cpInfo);
            this.mPhone.getContext().sendBroadcast(intent);
            log("sendErrorReport end");
        }
    }

    private String getStringProtocol(int index) {
        log("getStringProtocol index=" + index);
        switch (index) {
            case 0:
                return "IPV4";
            case 1:
                return "IPV6";
            case 2:
                return "IPV4V6";
            default:
                return "invalid Protocol type";
        }
    }

    protected void handleSpecialClearCode(int cause) {
        this.mPreFailcause = cause;
        this.mFailCount++;
        log("[ClearCode] mFailCount=" + this.mFailCount);
        if ((this.mRetryController.isNonVolteClearCode() || this.mRetryController.isVolteClearCode()) && this.mFailCount < 3) {
            log("[ClearCode] next retry");
            int delay = ClearCodeRetryController.RETRY_DELAY_LONG;
            if (this.mRetryController.isNonVolteClearCode() && this.mPhone.getServiceState().getRilVoiceRadioTechnology() == 14) {
                delay = 10000;
            }
            log("[ClearCode] retry connect APN delay=" + delay);
            startAlarmForRetryClearCode(delay);
            return;
        }
        log("[ClearCode] process fail");
        if (this.mPhone.getServiceState().getRilVoiceRadioTechnology() == 14) {
            log("[ClearCode] In 4G, switch to 3G");
            this.mRetryController.switchTo3G();
        } else {
            log("[ClearCode] All retry attempts failed, show user notification");
            this.mRetryController.userNotification(cause);
            startAlarmForRetryFromFailure(ClearCodeRetryController.RETRY_FROM_FAILURE_DELAY);
        }
        cancelReconnectAlarms();
    }

    private void startAlarmForRetryClearCode(int delay) {
        Intent intent = new Intent(INTENT_RETRY_CLEAR_CODE);
        intent.addFlags(268435456);
        int subId = SubscriptionManager.getDefaultDataSubscriptionId();
        intent.putExtra("subscription", subId);
        log("startAlarmForRetryClearCode: delay=" + delay + " action=" + intent.getAction());
        this.mClearCodeLatch.set(1);
        PendingIntent alarmIntent = PendingIntent.getBroadcast(this.mPhone.getContext(), 0, intent, 201326592);
        this.mRetryIntent = alarmIntent;
        this.mAlarmManager.setExact(2, SystemClock.elapsedRealtime() + ((long) delay), alarmIntent);
    }

    private void startAlarmForRetryFromFailure(int delay) {
        Intent intent = new Intent(INTENT_RETRY_FROM_FAILURE);
        intent.addFlags(268435456);
        log("startAlarmForRetryFromFailure: delay=" + delay + " action=" + intent.getAction());
        PendingIntent alarmIntent = PendingIntent.getBroadcast(this.mPhone.getContext(), 0, intent, 201326592);
        this.mRetryIntent = alarmIntent;
        this.mAlarmManager.setExact(2, SystemClock.elapsedRealtime() + ((long) delay), alarmIntent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onActionIntentRetryClearCode(Intent intent) {
        this.mClearCodeLatch.set(0);
        int phoneSubId = this.mPhone.getSubId();
        int currSubId = intent.getIntExtra("subscription", -1);
        log("onActionIntentRetryClearCode: currSubId = " + currSubId + " phoneSubId=" + phoneSubId);
        if (!SubscriptionManager.isValidSubscriptionId(currSubId) || currSubId != phoneSubId) {
            log("receive retry alarm but subId incorrect, ignore");
        } else {
            log("onActionIntentRetryClearCode: sendMessage = EVENT_DATA_SETUP_RETRY");
            sendMessage(obtainMessage(EVENT_DATA_SETUP_RETRY));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onActionIntentRetryFromFailure(Intent intent) {
        this.mRetryIntent = null;
        log("onActionIntentRetryFromFailure:");
        ClearCodeRetryController clearCodeRetryController = this.mRetryController;
        if (clearCodeRetryController != null) {
            clearCodeRetryController.restartCycle("retryfailure");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDataNetworkConnected() {
        ClearCodeRetryController clearCodeRetryController = this.mRetryController;
        if (clearCodeRetryController != null && clearCodeRetryController.supportSpecialClearCode()) {
            log("onDataNetworkConnected()");
            this.mPreFailcause = 0;
            this.mFailCount = 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDataSettingsEnabledChanged(boolean enabled, int reason) {
        ClearCodeRetryController clearCodeRetryController = this.mRetryController;
        if (clearCodeRetryController != null && clearCodeRetryController.isVolteClearCode()) {
            log("onDataEnabledChanged enabled = " + enabled + "reason = " + reason);
            if (this.mFailCount > 0 && reason == 0 && enabled) {
                this.mRetryController.restartForChanged("DataEnableOn");
            }
        }
    }

    private void onRadioOffOrNotAvailable() {
        log("onRadioOffOrNotAvailable()");
        ClearCodeRetryController clearCodeRetryController = this.mRetryController;
        if (clearCodeRetryController != null && clearCodeRetryController.isSpecialCode(this.mPreFailcause)) {
            this.mRetryController.notifyRadioOffOrNotAvailable();
            stopFailRetryAlarm();
        }
    }

    public void dataSetupRetry() {
        sendMessage(obtainMessage(EVENT_DATA_SETUP_RETRY));
    }

    public void stopFailRetryAlarm() {
        log("stopFailRetryAlarm()");
        PendingIntent pendingIntent = this.mRetryIntent;
        if (pendingIntent != null) {
            this.mAlarmManager.cancel(pendingIntent);
            this.mRetryIntent = null;
        }
    }

    public void clearPreFailCause() {
        log("clearPreFailCause()");
        this.mPreFailcause = 0;
        this.mFailCount = 0;
        this.mClearCodeLatch.set(0);
    }

    public int getFailCount() {
        return this.mFailCount;
    }

    public boolean getRetryClearCodeEnabled() {
        ClearCodeRetryController clearCodeRetryController = this.mRetryController;
        if (clearCodeRetryController == null || !clearCodeRetryController.isSpecialCode(this.mPreFailcause)) {
            return DBG;
        }
        boolean isMaxReryCountReached = ((this.mRetryController.isNonVolteClearCode() || this.mRetryController.isVolteClearCode()) && this.mFailCount >= 3) ? DBG : false;
        if (isMaxReryCountReached || this.mClearCodeLatch.get() > 0) {
            return false;
        }
        return DBG;
    }

    public void cancelReconnectAlarms() {
        removeMessages(EVENT_DATA_SETUP_RETRY);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(String s) {
        Rlog.d("UniDataRetryManager: ", "[" + this.mPhone.getPhoneId() + "]" + s);
    }
}
