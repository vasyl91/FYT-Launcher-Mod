package com.android.phone.uniecc.nano;

import java.io.IOException;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public interface UniProtobufEccData {

    public static final class EccInfo extends ExtendableMessageNano<EccInfo> {
        private static volatile EccInfo[] _emptyArray;
        public String cardFlag;
        public String mnc;
        public String phoneNumber;
        public int routing;
        public int[] types;

        public interface Type {
            public static final int AIEC = 7;
            public static final int AMBULANCE = 2;
            public static final int FIRE = 3;
            public static final int MARINE = 4;
            public static final int MIEC = 6;
            public static final int MOUNTAIN = 5;
            public static final int POLICE = 1;
            public static final int TYPE_UNSPECIFIED = 0;
        }

        public static EccInfo[] emptyArray() {
            if (_emptyArray == null) {
                synchronized (InternalNano.LAZY_INIT_LOCK) {
                    if (_emptyArray == null) {
                        _emptyArray = new EccInfo[0];
                    }
                }
            }
            return _emptyArray;
        }

        public EccInfo() {
            clear();
        }

        public EccInfo clear() {
            this.phoneNumber = "";
            this.types = WireFormatNano.EMPTY_INT_ARRAY;
            this.routing = 0;
            this.mnc = "";
            this.cardFlag = "";
            this.unknownFieldData = null;
            this.cachedSize = -1;
            return this;
        }

        @Override // com.android.phone.uniecc.nano.ExtendableMessageNano, com.android.phone.uniecc.nano.MessageNano
        public void writeTo(CodedOutputByteBufferNano output) throws IOException {
            if (!this.phoneNumber.equals("")) {
                output.writeString(1, this.phoneNumber);
            }
            int[] iArr = this.types;
            if (iArr != null && iArr.length > 0) {
                int dataSize = 0;
                int i = 0;
                while (true) {
                    int[] iArr2 = this.types;
                    if (i >= iArr2.length) {
                        break;
                    }
                    int element = iArr2[i];
                    dataSize += CodedOutputByteBufferNano.computeInt32SizeNoTag(element);
                    i++;
                }
                output.writeRawVarint32(18);
                output.writeRawVarint32(dataSize);
                int i2 = 0;
                while (true) {
                    int[] iArr3 = this.types;
                    if (i2 >= iArr3.length) {
                        break;
                    }
                    output.writeRawVarint32(iArr3[i2]);
                    i2++;
                }
            }
            int dataSize2 = this.routing;
            if (dataSize2 != 0) {
                output.writeInt32(3, dataSize2);
            }
            if (!this.mnc.equals("")) {
                output.writeString(4, this.mnc);
            }
            if (!this.cardFlag.equals("")) {
                output.writeString(5, this.cardFlag);
            }
            super.writeTo(output);
        }

        @Override // com.android.phone.uniecc.nano.ExtendableMessageNano, com.android.phone.uniecc.nano.MessageNano
        protected int computeSerializedSize() {
            int size = super.computeSerializedSize();
            if (!this.phoneNumber.equals("")) {
                size += CodedOutputByteBufferNano.computeStringSize(1, this.phoneNumber);
            }
            int[] iArr = this.types;
            if (iArr != null && iArr.length > 0) {
                int dataSize = 0;
                int i = 0;
                while (true) {
                    int[] iArr2 = this.types;
                    if (i >= iArr2.length) {
                        break;
                    }
                    int element = iArr2[i];
                    dataSize += CodedOutputByteBufferNano.computeInt32SizeNoTag(element);
                    i++;
                }
                size = size + dataSize + 1 + CodedOutputByteBufferNano.computeRawVarint32Size(dataSize);
            }
            int dataSize2 = this.routing;
            if (dataSize2 != 0) {
                size += CodedOutputByteBufferNano.computeInt32Size(3, dataSize2);
            }
            if (!this.mnc.equals("")) {
                size += CodedOutputByteBufferNano.computeStringSize(4, this.mnc);
            }
            if (!this.cardFlag.equals("")) {
                return size + CodedOutputByteBufferNano.computeStringSize(5, this.cardFlag);
            }
            return size;
        }

        @Override // com.android.phone.uniecc.nano.MessageNano
        public EccInfo mergeFrom(CodedInputByteBufferNano input) throws IOException {
            while (true) {
                int tag = input.readTag();
                switch (tag) {
                    case 0:
                        return this;
                    case 10:
                        this.phoneNumber = input.readString();
                        break;
                    case 16:
                        int length = WireFormatNano.getRepeatedFieldArrayLength(input, 16);
                        int[] validValues = new int[length];
                        int validCount = 0;
                        for (int i = 0; i < length; i++) {
                            if (i != 0) {
                                input.readTag();
                            }
                            int value = input.readInt32();
                            switch (value) {
                                case 0:
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                case 5:
                                case 6:
                                case 7:
                                    validValues[validCount] = value;
                                    validCount++;
                                    break;
                            }
                        }
                        if (validCount != 0) {
                            int[] iArr = this.types;
                            int i2 = iArr == null ? 0 : iArr.length;
                            if (i2 == 0 && validCount == validValues.length) {
                                this.types = validValues;
                            } else {
                                int[] newArray = new int[i2 + validCount];
                                if (i2 != 0) {
                                    System.arraycopy(iArr, 0, newArray, 0, i2);
                                }
                                System.arraycopy(validValues, 0, newArray, i2, validCount);
                                this.types = newArray;
                            }
                        }
                        break;
                    case 18:
                        int bytes = input.readRawVarint32();
                        int limit = input.pushLimit(bytes);
                        int arrayLength = 0;
                        int startPos = input.getPosition();
                        while (input.getBytesUntilLimit() > 0) {
                            switch (input.readInt32()) {
                                case 0:
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                case 5:
                                case 6:
                                case 7:
                                    arrayLength++;
                                    break;
                            }
                        }
                        if (arrayLength != 0) {
                            input.rewindToPosition(startPos);
                            int[] iArr2 = this.types;
                            int i3 = iArr2 == null ? 0 : iArr2.length;
                            int[] newArray2 = new int[i3 + arrayLength];
                            if (i3 != 0) {
                                System.arraycopy(iArr2, 0, newArray2, 0, i3);
                            }
                            while (input.getBytesUntilLimit() > 0) {
                                int value2 = input.readInt32();
                                switch (value2) {
                                    case 0:
                                    case 1:
                                    case 2:
                                    case 3:
                                    case 4:
                                    case 5:
                                    case 6:
                                    case 7:
                                        newArray2[i3] = value2;
                                        i3++;
                                        break;
                                }
                            }
                            this.types = newArray2;
                        }
                        input.popLimit(limit);
                        break;
                    case 24:
                        this.routing = input.readInt32();
                        break;
                    case 34:
                        this.mnc = input.readString();
                        break;
                    case 42:
                        this.cardFlag = input.readString();
                        break;
                    default:
                        if (!storeUnknownField(input, tag)) {
                            return this;
                        }
                        break;
                        break;
                }
            }
        }

        public static EccInfo parseFrom(byte[] data) throws InvalidProtocolBufferNanoException {
            return (EccInfo) MessageNano.mergeFrom(new EccInfo(), data);
        }

        public static EccInfo parseFrom(CodedInputByteBufferNano input) throws IOException {
            return new EccInfo().mergeFrom(input);
        }
    }

    public static final class CountryInfo extends ExtendableMessageNano<CountryInfo> {
        private static volatile CountryInfo[] _emptyArray;
        public String eccFallback;
        public EccInfo[] eccs;
        public String isoCode;

        public static CountryInfo[] emptyArray() {
            if (_emptyArray == null) {
                synchronized (InternalNano.LAZY_INIT_LOCK) {
                    if (_emptyArray == null) {
                        _emptyArray = new CountryInfo[0];
                    }
                }
            }
            return _emptyArray;
        }

        public CountryInfo() {
            clear();
        }

        public CountryInfo clear() {
            this.isoCode = "";
            this.eccs = EccInfo.emptyArray();
            this.eccFallback = "";
            this.unknownFieldData = null;
            this.cachedSize = -1;
            return this;
        }

        @Override // com.android.phone.uniecc.nano.ExtendableMessageNano, com.android.phone.uniecc.nano.MessageNano
        public void writeTo(CodedOutputByteBufferNano output) throws IOException {
            if (!this.isoCode.equals("")) {
                output.writeString(1, this.isoCode);
            }
            EccInfo[] eccInfoArr = this.eccs;
            if (eccInfoArr != null && eccInfoArr.length > 0) {
                int i = 0;
                while (true) {
                    EccInfo[] eccInfoArr2 = this.eccs;
                    if (i >= eccInfoArr2.length) {
                        break;
                    }
                    EccInfo element = eccInfoArr2[i];
                    if (element != null) {
                        output.writeMessage(2, element);
                    }
                    i++;
                }
            }
            if (!this.eccFallback.equals("")) {
                output.writeString(3, this.eccFallback);
            }
            super.writeTo(output);
        }

        @Override // com.android.phone.uniecc.nano.ExtendableMessageNano, com.android.phone.uniecc.nano.MessageNano
        protected int computeSerializedSize() {
            int size = super.computeSerializedSize();
            if (!this.isoCode.equals("")) {
                size += CodedOutputByteBufferNano.computeStringSize(1, this.isoCode);
            }
            EccInfo[] eccInfoArr = this.eccs;
            if (eccInfoArr != null && eccInfoArr.length > 0) {
                int i = 0;
                while (true) {
                    EccInfo[] eccInfoArr2 = this.eccs;
                    if (i >= eccInfoArr2.length) {
                        break;
                    }
                    EccInfo element = eccInfoArr2[i];
                    if (element != null) {
                        size += CodedOutputByteBufferNano.computeMessageSize(2, element);
                    }
                    i++;
                }
            }
            if (!this.eccFallback.equals("")) {
                return size + CodedOutputByteBufferNano.computeStringSize(3, this.eccFallback);
            }
            return size;
        }

        @Override // com.android.phone.uniecc.nano.MessageNano
        public CountryInfo mergeFrom(CodedInputByteBufferNano input) throws IOException {
            while (true) {
                int tag = input.readTag();
                switch (tag) {
                    case 0:
                        return this;
                    case 10:
                        this.isoCode = input.readString();
                        break;
                    case 18:
                        int arrayLength = WireFormatNano.getRepeatedFieldArrayLength(input, 18);
                        EccInfo[] eccInfoArr = this.eccs;
                        int i = eccInfoArr == null ? 0 : eccInfoArr.length;
                        EccInfo[] newArray = new EccInfo[i + arrayLength];
                        if (i != 0) {
                            System.arraycopy(eccInfoArr, 0, newArray, 0, i);
                        }
                        while (i < newArray.length - 1) {
                            newArray[i] = new EccInfo();
                            input.readMessage(newArray[i]);
                            input.readTag();
                            i++;
                        }
                        newArray[i] = new EccInfo();
                        input.readMessage(newArray[i]);
                        this.eccs = newArray;
                        break;
                    case 26:
                        this.eccFallback = input.readString();
                        break;
                    default:
                        if (!storeUnknownField(input, tag)) {
                            return this;
                        }
                        break;
                        break;
                }
            }
        }

        public static CountryInfo parseFrom(byte[] data) throws InvalidProtocolBufferNanoException {
            return (CountryInfo) MessageNano.mergeFrom(new CountryInfo(), data);
        }

        public static CountryInfo parseFrom(CodedInputByteBufferNano input) throws IOException {
            return new CountryInfo().mergeFrom(input);
        }
    }

    public static final class AllInfo extends ExtendableMessageNano<AllInfo> {
        private static volatile AllInfo[] _emptyArray;
        public CountryInfo[] countries;
        public int revision;

        public static AllInfo[] emptyArray() {
            if (_emptyArray == null) {
                synchronized (InternalNano.LAZY_INIT_LOCK) {
                    if (_emptyArray == null) {
                        _emptyArray = new AllInfo[0];
                    }
                }
            }
            return _emptyArray;
        }

        public AllInfo() {
            clear();
        }

        public AllInfo clear() {
            this.revision = 0;
            this.countries = CountryInfo.emptyArray();
            this.unknownFieldData = null;
            this.cachedSize = -1;
            return this;
        }

        @Override // com.android.phone.uniecc.nano.ExtendableMessageNano, com.android.phone.uniecc.nano.MessageNano
        public void writeTo(CodedOutputByteBufferNano output) throws IOException {
            int i = this.revision;
            if (i != 0) {
                output.writeInt32(1, i);
            }
            CountryInfo[] countryInfoArr = this.countries;
            if (countryInfoArr != null && countryInfoArr.length > 0) {
                int i2 = 0;
                while (true) {
                    CountryInfo[] countryInfoArr2 = this.countries;
                    if (i2 >= countryInfoArr2.length) {
                        break;
                    }
                    CountryInfo element = countryInfoArr2[i2];
                    if (element != null) {
                        output.writeMessage(2, element);
                    }
                    i2++;
                }
            }
            super.writeTo(output);
        }

        @Override // com.android.phone.uniecc.nano.ExtendableMessageNano, com.android.phone.uniecc.nano.MessageNano
        protected int computeSerializedSize() {
            int size = super.computeSerializedSize();
            int i = this.revision;
            if (i != 0) {
                size += CodedOutputByteBufferNano.computeInt32Size(1, i);
            }
            CountryInfo[] countryInfoArr = this.countries;
            if (countryInfoArr != null && countryInfoArr.length > 0) {
                int i2 = 0;
                while (true) {
                    CountryInfo[] countryInfoArr2 = this.countries;
                    if (i2 >= countryInfoArr2.length) {
                        break;
                    }
                    CountryInfo element = countryInfoArr2[i2];
                    if (element != null) {
                        size += CodedOutputByteBufferNano.computeMessageSize(2, element);
                    }
                    i2++;
                }
            }
            return size;
        }

        @Override // com.android.phone.uniecc.nano.MessageNano
        public AllInfo mergeFrom(CodedInputByteBufferNano input) throws IOException {
            while (true) {
                int tag = input.readTag();
                switch (tag) {
                    case 0:
                        return this;
                    case 8:
                        int arrayLength = input.readInt32();
                        this.revision = arrayLength;
                        break;
                    case 18:
                        int arrayLength2 = WireFormatNano.getRepeatedFieldArrayLength(input, 18);
                        CountryInfo[] countryInfoArr = this.countries;
                        int i = countryInfoArr == null ? 0 : countryInfoArr.length;
                        CountryInfo[] newArray = new CountryInfo[i + arrayLength2];
                        if (i != 0) {
                            System.arraycopy(countryInfoArr, 0, newArray, 0, i);
                        }
                        while (i < newArray.length - 1) {
                            newArray[i] = new CountryInfo();
                            input.readMessage(newArray[i]);
                            input.readTag();
                            i++;
                        }
                        newArray[i] = new CountryInfo();
                        input.readMessage(newArray[i]);
                        this.countries = newArray;
                        break;
                    default:
                        if (!storeUnknownField(input, tag)) {
                            return this;
                        }
                        break;
                        break;
                }
            }
        }

        public static AllInfo parseFrom(byte[] data) throws InvalidProtocolBufferNanoException {
            return (AllInfo) MessageNano.mergeFrom(new AllInfo(), data);
        }

        public static AllInfo parseFrom(CodedInputByteBufferNano input) throws IOException {
            return new AllInfo().mergeFrom(input);
        }
    }
}
