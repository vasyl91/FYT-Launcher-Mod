package com.android.internal.telephony.data;

import android.telephony.PhoneStateListener;
import android.telephony.Rlog;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.PhoneFactory;
import com.android.internal.telephony.UniGsmCdmaPhone;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
class UniDataPhoneManager {
    private static final String TAG = "UniDataPhoneManager";
    private int[] mAvailableTransports;
    private int mCurrentSubId;
    private final SubscriptionManager.OnSubscriptionsChangedListener mOnSubscriptionsChangeListener;
    private Phone mPhone;
    private PhoneCallStateListener mPhoneCallStateListener;
    private SubscriptionManager mSubscriptionManager;
    private UniDataNetworkController mUniDataNetworkController;
    private UniGsmCdmaPhone mUniPhone;
    private int mMaxActivePhones = 1;
    private int mPhoneState = 0;

    public UniDataPhoneManager(Phone phone, UniDataNetworkController uniDnc) {
        SubscriptionManager.OnSubscriptionsChangedListener onSubscriptionsChangedListener = new SubscriptionManager.OnSubscriptionsChangedListener() { // from class: com.android.internal.telephony.data.UniDataPhoneManager.1
            @Override // android.telephony.SubscriptionManager.OnSubscriptionsChangedListener
            public void onSubscriptionsChanged() {
                if (UniDataPhoneManager.this.mCurrentSubId != UniDataPhoneManager.this.mPhone.getSubId()) {
                    UniDataPhoneManager.this.log("onSubscriptionsChanged subId: " + UniDataPhoneManager.this.mCurrentSubId + " to: " + UniDataPhoneManager.this.mPhone.getSubId());
                    UniDataPhoneManager uniDataPhoneManager = UniDataPhoneManager.this;
                    uniDataPhoneManager.mCurrentSubId = uniDataPhoneManager.mPhone.getSubId();
                    UniDataPhoneManager.this.mPhoneCallStateListener.listen(UniDataPhoneManager.this.mCurrentSubId);
                    if (!SubscriptionManager.isValidSubscriptionId(UniDataPhoneManager.this.mCurrentSubId)) {
                        UniDataPhoneManager.this.suspendOtherPhone(false);
                    }
                }
            }
        };
        this.mOnSubscriptionsChangeListener = onSubscriptionsChangedListener;
        this.mPhone = phone;
        this.mUniPhone = (UniGsmCdmaPhone) phone;
        this.mUniDataNetworkController = uniDnc;
        this.mCurrentSubId = phone.getSubId();
        PhoneCallStateListener phoneCallStateListener = new PhoneCallStateListener();
        this.mPhoneCallStateListener = phoneCallStateListener;
        phoneCallStateListener.listen(this.mCurrentSubId);
        SubscriptionManager subscriptionManager = (SubscriptionManager) this.mPhone.getContext().getSystemService("telephony_subscription_service");
        this.mSubscriptionManager = subscriptionManager;
        subscriptionManager.addOnSubscriptionsChangedListener(onSubscriptionsChangedListener);
    }

    public void dispose() {
        SubscriptionManager.OnSubscriptionsChangedListener onSubscriptionsChangedListener;
        SubscriptionManager subscriptionManager = this.mSubscriptionManager;
        if (subscriptionManager != null && (onSubscriptionsChangedListener = this.mOnSubscriptionsChangeListener) != null) {
            subscriptionManager.removeOnSubscriptionsChangedListener(onSubscriptionsChangedListener);
        }
    }

    private class PhoneCallStateListener extends PhoneStateListener {
        public PhoneCallStateListener() {
        }

        @Override // android.telephony.PhoneStateListener
        public void onCallStateChanged(int state, String incomingNumber) {
            UniDataPhoneManager.this.log("onCallStateChanged: state = " + state + " ,mPhoneState = " + UniDataPhoneManager.this.mPhoneState);
            boolean isVowifiConnected = false;
            for (Phone p : PhoneFactory.getPhones()) {
                if (p != null && UniDataPhoneManager.this.mUniPhone.isVowifiConnected(p.getPhoneId())) {
                    isVowifiConnected = true;
                    UniDataPhoneManager.this.log("onCallStateChanged: vowifi connected in phone " + p.getPhoneId());
                }
            }
            if (SubscriptionManager.isValidPhoneId(UniDataPhoneManager.this.mPhone.getPhoneId())) {
                if (state != 0 && !isVowifiConnected && UniDataPhoneManager.this.mPhoneState == 0) {
                    UniDataPhoneManager.this.log("phone" + UniDataPhoneManager.this.mPhone.getPhoneId() + " call start");
                    UniDataPhoneManager.this.suspendOtherPhone(true);
                } else if (state == 0) {
                    UniDataPhoneManager.this.log("phone" + UniDataPhoneManager.this.mPhone.getPhoneId() + " call end");
                    UniDataPhoneManager.this.suspendOtherPhone(false);
                }
                UniDataPhoneManager.this.mPhoneState = state;
            }
        }

        public void listen(int subId) {
            TelephonyManager tm = TelephonyManager.from(UniDataPhoneManager.this.mPhone.getContext()).createForSubscriptionId(subId);
            if (!SubscriptionManager.isValidSubscriptionId(subId)) {
                tm.listen(this, 0);
            } else {
                UniDataPhoneManager.this.log("PhoneCallStateListener: listen subId = " + subId);
                tm.listen(this, 32);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void suspendOtherPhone(boolean needSuspend) {
        UniDataNetworkController dnc;
        for (Phone p : PhoneFactory.getPhones()) {
            if (this.mMaxActivePhones <= 1 && p != null && p.getPhoneId() != this.mPhone.getPhoneId() && (dnc = (UniDataNetworkController) p.getDataNetworkController()) != null) {
                String logStr = needSuspend ? "suspendData " : "resumeData ";
                log(logStr + "for phone[" + p.getPhoneId() + "]");
                dnc.suspendData(needSuspend);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(String logStr) {
        String logTag = "UniDataPhoneManager[" + this.mPhone.getPhoneId() + "]";
        Rlog.d(logTag, logStr);
    }
}
