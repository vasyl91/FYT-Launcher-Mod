package com.android.internal.telephony.gsm;

import android.R;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.AsyncResult;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.os.PersistableBundle;
import android.os.ResultReceiver;
import android.telephony.CarrierConfigManager;
import android.telephony.PhoneNumberUtils;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.BidiFormatter;
import android.text.SpannableStringBuilder;
import android.text.TextDirectionHeuristics;
import android.text.TextUtils;
import com.android.internal.telephony.CallForwardInfo;
import com.android.internal.telephony.CallStateException;
import com.android.internal.telephony.CommandException;
import com.android.internal.telephony.GsmCdmaPhone;
import com.android.internal.telephony.MmiCode;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.uicc.IccCardApplicationStatus;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.util.ArrayUtils;
import com.android.telephony.Rlog;
import com.android.unisoc.telephony.RadioInteractor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public final class UniGsmMmiCode extends Handler implements MmiCode {
    static final String ACTION_ACTIVATE = "*";
    static final String ACTION_DEACTIVATE = "#";
    static final String ACTION_ERASURE = "##";
    static final String ACTION_INTERROGATE = "*#";
    static final String ACTION_REGISTER = "**";
    static final int CLIP_DISABLE = 0;
    static final int CLIP_ENABLE = 1;
    static final char END_OF_USSD_COMMAND = '#';
    static final int EVENT_GET_CLIR_COMPLETE = 2;
    static final int EVENT_GET_CNAP_COMPLETE = 8;
    static final int EVENT_QUERY_CF_COMPLETE = 3;
    static final int EVENT_QUERY_COLP_COMPLETE = 9;
    static final int EVENT_QUERY_COLR_COMPLETE = 10;
    static final int EVENT_QUERY_COMPLETE = 5;
    static final int EVENT_SET_CFF_COMPLETE = 6;
    static final int EVENT_SET_COMPLETE = 1;
    static final int EVENT_UPDATE_CLIP_COMPLETE = 11;
    static final int EVENT_USSD_CANCEL_COMPLETE = 7;
    static final int EVENT_USSD_COMPLETE = 4;
    static final String LOG_TAG = "UniGsmMmiCode";
    static final int MATCH_GROUP_ACTION = 2;
    static final int MATCH_GROUP_DIALING_NUMBER = 12;
    static final int MATCH_GROUP_POUND_STRING = 1;
    static final int MATCH_GROUP_PWD_CONFIRM = 11;
    static final int MATCH_GROUP_SERVICE_CODE = 3;
    static final int MATCH_GROUP_SIA = 5;
    static final int MATCH_GROUP_SIB = 7;
    static final int MATCH_GROUP_SIC = 9;
    static final int MAX_LENGTH_SHORT_CODE = 2;
    private static final int MIN_REMAINTIMES = 0;
    static final int QUERY_LI_RESPONSE_DISABLE = 0;
    static final int QUERY_LI_RESPONSE_ENABLE = 1;
    static final int QUERY_LI_RESPONSE_ERROR = -1;
    private static final String REFRESH_VIDEO_CF_NOTIFICATION_ACTION = "android.intent.action.REFRESH_VIDEO_CF_NOTIFICATION";
    static final String SC_BAIC = "35";
    static final String SC_BAICr = "351";
    static final String SC_BAOC = "33";
    static final String SC_BAOIC = "331";
    static final String SC_BAOICxH = "332";
    static final String SC_BA_ALL = "330";
    static final String SC_BA_MO = "333";
    static final String SC_BA_MT = "353";
    static final String SC_CFB = "67";
    static final String SC_CFNR = "62";
    static final String SC_CFNRy = "61";
    static final String SC_CFU = "21";
    static final String SC_CF_All = "002";
    static final String SC_CF_All_Conditional = "004";
    static final String SC_CLIP = "30";
    static final String SC_CLIR = "31";
    static final String SC_CNAP = "300";
    static final String SC_COLP = "76";
    static final String SC_COLR = "77";
    static final String SC_PIN = "04";
    static final String SC_PIN2 = "042";
    static final String SC_PUK = "05";
    static final String SC_PUK2 = "052";
    static final String SC_PWD = "03";
    static final String SC_WAIT = "43";
    static final int UNLOCK_PIN = 0;
    static final int UNLOCK_PIN2 = 1;
    static final int UNLOCK_PUK = 2;
    static final int UNLOCK_PUK2 = 3;
    private static final String VIDEO_CF_STATUS = "video_cf_status";
    private static final String VIDEO_CF_SUB_ID = "video_cf_flag_with_subid";
    private static String[] sTwoDigitNumberPattern;
    String mAction;
    private ResultReceiver mCallbackReceiver;
    Context mContext;
    public String mDialingNumber;
    IccRecords mIccRecords;
    private boolean mIsCallFwdReg;
    private boolean mIsNetworkInitiatedUSSD;
    private boolean mIsPendingUSSD;
    private boolean mIsSsInfo;
    private boolean mIsUssdRequest;
    CharSequence mMessage;
    private Messenger mMessenger;
    GsmCdmaPhone mPhone;
    String mPoundString;
    String mPwd;
    private RadioInteractor mRi;
    String mSc;
    String mSia;
    String mSib;
    String mSic;
    MmiCode.State mState;
    UiccCardApplication mUiccApplication;
    private static final String[] PROP_SIM_PIN_PUK_REMAINTIMES = {"vendor.sim.pin.remaintimes", "vendor.sim.pin2.remaintimes", "vendor.sim.puk.remaintimes", "vendor.sim.puk2.remaintimes"};
    static Pattern sPatternSuppService = Pattern.compile("((\\*|#|\\*#|\\*\\*|##)(\\d{2,3})(\\*([^*#]*)(\\*([^*#]*)(\\*([^*#]*)(\\*([^*#]*))?)?)?)?#)(.*)");

    public static UniGsmMmiCode newFromDialString(String dialString, GsmCdmaPhone phone, UiccCardApplication app) {
        return newFromDialString(dialString, phone, app, null);
    }

    public static UniGsmMmiCode newFromDialString(String dialString, GsmCdmaPhone phone, UiccCardApplication app, ResultReceiver wrappedCallback) {
        UniGsmMmiCode ret = null;
        if ((phone.getServiceState().getVoiceRoaming() && phone.supportsConversionOfCdmaCallerIdMmiCodesWhileRoaming()) || (isEmergencyNumber(phone, dialString) && isCarrierSupportCallerIdVerticalServiceCodes(phone))) {
            dialString = convertCdmaMmiCodesTo3gppMmiCodes(dialString);
        }
        Matcher m = sPatternSuppService.matcher(dialString);
        if (m.matches()) {
            ret = new UniGsmMmiCode(phone, app);
            ret.mPoundString = makeEmptyNull(m.group(1));
            ret.mAction = makeEmptyNull(m.group(2));
            ret.mSc = makeEmptyNull(m.group(3));
            ret.mSia = makeEmptyNull(m.group(5));
            ret.mSib = makeEmptyNull(m.group(7));
            ret.mSic = makeEmptyNull(m.group(9));
            ret.mPwd = makeEmptyNull(m.group(11));
            String strMakeEmptyNull = makeEmptyNull(m.group(12));
            ret.mDialingNumber = strMakeEmptyNull;
            if (strMakeEmptyNull != null && strMakeEmptyNull.endsWith(ACTION_DEACTIVATE) && dialString.endsWith(ACTION_DEACTIVATE)) {
                ret = new UniGsmMmiCode(phone, app);
                ret.mPoundString = dialString;
            } else if (ret.isFacToDial()) {
                ret = null;
            }
        } else if (dialString.endsWith(ACTION_DEACTIVATE)) {
            ret = new UniGsmMmiCode(phone, app);
            ret.mPoundString = dialString;
        } else if (isTwoDigitShortCode(phone.getContext(), phone.getSubId(), dialString)) {
            ret = null;
        } else if (isShortCode(dialString, phone)) {
            ret = new UniGsmMmiCode(phone, app);
            ret.mDialingNumber = dialString;
        }
        if (ret != null) {
            ret.mCallbackReceiver = wrappedCallback;
        }
        return ret;
    }

    private static String convertCdmaMmiCodesTo3gppMmiCodes(String dialString) {
        Matcher m = sPatternCdmaMmiCodeWhileRoaming.matcher(dialString);
        if (m.matches()) {
            String serviceCode = makeEmptyNull(m.group(1));
            String prefix = m.group(2);
            String number = makeEmptyNull(m.group(3));
            if (serviceCode.equals(SC_CFB) && number != null) {
                return "#31#" + prefix + number;
            }
            if (serviceCode.equals("82") && number != null) {
                return "*31#" + prefix + number;
            }
            return dialString;
        }
        return dialString;
    }

    public static UniGsmMmiCode newNetworkInitiatedUssd(String ussdMessage, boolean isUssdRequest, GsmCdmaPhone phone, UiccCardApplication app) {
        UniGsmMmiCode ret = new UniGsmMmiCode(phone, app);
        ret.mMessage = ussdMessage;
        ret.mIsUssdRequest = isUssdRequest;
        ret.mIsNetworkInitiatedUSSD = true;
        if (isUssdRequest) {
            ret.mIsPendingUSSD = true;
            ret.mState = MmiCode.State.PENDING;
        } else {
            ret.mState = MmiCode.State.COMPLETE;
        }
        return ret;
    }

    public static UniGsmMmiCode newFromUssdUserInput(String ussdMessge, GsmCdmaPhone phone, UiccCardApplication app) {
        UniGsmMmiCode ret = new UniGsmMmiCode(phone, app);
        ret.mMessage = ussdMessge;
        ret.mState = MmiCode.State.PENDING;
        ret.mIsPendingUSSD = true;
        return ret;
    }

    public void processSsData(AsyncResult data) {
        Rlog.d(LOG_TAG, "In processSsData");
        this.mIsSsInfo = true;
        try {
            SsData ssData = (SsData) data.result;
            parseSsData(ssData);
        } catch (ClassCastException ex) {
            Rlog.e(LOG_TAG, "Class Cast Exception in parsing SS Data : " + ex);
        } catch (NullPointerException ex2) {
            Rlog.e(LOG_TAG, "Null Pointer Exception in parsing SS Data : " + ex2);
        }
    }

    void parseSsData(SsData ssData) {
        CommandException ex = CommandException.fromRilErrno(ssData.result);
        this.mSc = getScStringFromScType(ssData.serviceType);
        this.mAction = getActionStringFromReqType(ssData.requestType);
        Rlog.d(LOG_TAG, "parseSsData msc = " + this.mSc + ", action = " + this.mAction + ", ex = " + ex);
        switch (AnonymousClass2.$SwitchMap$com$android$internal$telephony$gsm$SsData$RequestType[ssData.requestType.ordinal()]) {
            case 1:
            case 2:
            case 3:
            case 4:
                if (ssData.result == 0 && ssData.serviceType.isTypeUnConditional()) {
                    boolean cffEnabled = (ssData.requestType == SsData.RequestType.SS_ACTIVATION || ssData.requestType == SsData.RequestType.SS_REGISTRATION) && isServiceClassVoiceorNone(ssData.serviceClass);
                    Rlog.d(LOG_TAG, "setVoiceCallForwardingFlag cffEnabled: " + cffEnabled);
                    this.mPhone.setVoiceCallForwardingFlag(1, cffEnabled, (String) null);
                }
                onSetComplete(null, new AsyncResult((Object) null, ssData.cfInfo, ex));
                break;
            case 5:
                if (ssData.serviceType.isTypeClir()) {
                    Rlog.d(LOG_TAG, "CLIR INTERROGATION");
                    onGetClirComplete(new AsyncResult((Object) null, ssData.ssInfo, ex));
                } else if (ssData.serviceType.isTypeCF()) {
                    Rlog.d(LOG_TAG, "CALL FORWARD INTERROGATION");
                    onQueryCfComplete(new AsyncResult((Object) null, ssData.cfInfo, ex));
                } else {
                    onQueryComplete(new AsyncResult((Object) null, ssData.ssInfo, ex));
                }
                break;
            default:
                Rlog.e(LOG_TAG, "Invaid requestType in SSData : " + ssData.requestType);
                break;
        }
    }

    /* JADX INFO: renamed from: com.android.internal.telephony.gsm.UniGsmMmiCode$2, reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$com$android$internal$telephony$gsm$SsData$RequestType;
        static final /* synthetic */ int[] $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType;

        static {
            int[] iArr = new int[SsData.ServiceType.values().length];
            $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType = iArr;
            try {
                iArr[SsData.ServiceType.SS_CFU.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_CF_BUSY.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_CF_NO_REPLY.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_CF_NOT_REACHABLE.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_CF_ALL.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_CF_ALL_CONDITIONAL.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_CLIP.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_CLIR.ordinal()] = 8;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_WAIT.ordinal()] = 9;
            } catch (NoSuchFieldError e9) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_BAOC.ordinal()] = 10;
            } catch (NoSuchFieldError e10) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_BAOIC.ordinal()] = 11;
            } catch (NoSuchFieldError e11) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_BAOIC_EXC_HOME.ordinal()] = 12;
            } catch (NoSuchFieldError e12) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_BAIC.ordinal()] = 13;
            } catch (NoSuchFieldError e13) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_BAIC_ROAMING.ordinal()] = 14;
            } catch (NoSuchFieldError e14) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_ALL_BARRING.ordinal()] = 15;
            } catch (NoSuchFieldError e15) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_OUTGOING_BARRING.ordinal()] = 16;
            } catch (NoSuchFieldError e16) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[SsData.ServiceType.SS_INCOMING_BARRING.ordinal()] = 17;
            } catch (NoSuchFieldError e17) {
            }
            int[] iArr2 = new int[SsData.RequestType.values().length];
            $SwitchMap$com$android$internal$telephony$gsm$SsData$RequestType = iArr2;
            try {
                iArr2[SsData.RequestType.SS_ACTIVATION.ordinal()] = 1;
            } catch (NoSuchFieldError e18) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$RequestType[SsData.RequestType.SS_DEACTIVATION.ordinal()] = 2;
            } catch (NoSuchFieldError e19) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$RequestType[SsData.RequestType.SS_REGISTRATION.ordinal()] = 3;
            } catch (NoSuchFieldError e20) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$RequestType[SsData.RequestType.SS_ERASURE.ordinal()] = 4;
            } catch (NoSuchFieldError e21) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$gsm$SsData$RequestType[SsData.RequestType.SS_INTERROGATION.ordinal()] = 5;
            } catch (NoSuchFieldError e22) {
            }
        }
    }

    private String getScStringFromScType(SsData.ServiceType sType) {
        switch (AnonymousClass2.$SwitchMap$com$android$internal$telephony$gsm$SsData$ServiceType[sType.ordinal()]) {
            case 1:
                return SC_CFU;
            case 2:
                return SC_CFB;
            case 3:
                return SC_CFNRy;
            case 4:
                return SC_CFNR;
            case 5:
                return SC_CF_All;
            case 6:
                return SC_CF_All_Conditional;
            case 7:
                return SC_CLIP;
            case 8:
                return SC_CLIR;
            case 9:
                return SC_WAIT;
            case 10:
                return SC_BAOC;
            case 11:
                return SC_BAOIC;
            case 12:
                return SC_BAOICxH;
            case 13:
                return SC_BAIC;
            case 14:
                return SC_BAICr;
            case 15:
                return SC_BA_ALL;
            case 16:
                return SC_BA_MO;
            case 17:
                return SC_BA_MT;
            default:
                return "";
        }
    }

    private String getActionStringFromReqType(SsData.RequestType rType) {
        switch (AnonymousClass2.$SwitchMap$com$android$internal$telephony$gsm$SsData$RequestType[rType.ordinal()]) {
            case 1:
                return ACTION_ACTIVATE;
            case 2:
                return ACTION_DEACTIVATE;
            case 3:
                return ACTION_REGISTER;
            case 4:
                return ACTION_ERASURE;
            case 5:
                return ACTION_INTERROGATE;
            default:
                return "";
        }
    }

    private boolean isServiceClassVoiceorNone(int serviceClass) {
        return (serviceClass & 1) != 0 || serviceClass == 0;
    }

    private static String makeEmptyNull(String s) {
        if (s == null || s.length() != 0) {
            return s;
        }
        return null;
    }

    private static boolean isEmptyOrNull(CharSequence s) {
        return s == null || s.length() == 0;
    }

    private static int scToCallForwardReason(String sc) {
        if (sc == null) {
            throw new RuntimeException("invalid call forward sc");
        }
        if (sc.equals(SC_CF_All)) {
            return 4;
        }
        if (sc.equals(SC_CFU)) {
            return 0;
        }
        if (sc.equals(SC_CFB)) {
            return 1;
        }
        if (sc.equals(SC_CFNR)) {
            return 3;
        }
        if (sc.equals(SC_CFNRy)) {
            return 2;
        }
        if (sc.equals(SC_CF_All_Conditional)) {
            return 5;
        }
        throw new RuntimeException("invalid call forward sc");
    }

    private static int siToServiceClass(String si) {
        if (si == null || si.length() == 0) {
            return 0;
        }
        int serviceCode = Integer.parseInt(si, 10);
        switch (serviceCode) {
            case 10:
                return 13;
            case 11:
                return 1;
            case 12:
                return 12;
            case 13:
                return 4;
            case 16:
                return 8;
            case 19:
                return 5;
            case 20:
                return 48;
            case 21:
                return 160;
            case 22:
                return 80;
            case 24:
                return 16;
            case 25:
                return 32;
            case 26:
                return 17;
            case 99:
                return 64;
            default:
                throw new RuntimeException("unsupported MMI service code " + si);
        }
    }

    private static int siToTime(String si) {
        if (si == null || si.length() == 0) {
            return 0;
        }
        return Integer.parseInt(si, 10);
    }

    static boolean isServiceCodeCallForwarding(String sc) {
        return sc != null && (sc.equals(SC_CFU) || sc.equals(SC_CFB) || sc.equals(SC_CFNRy) || sc.equals(SC_CFNR) || sc.equals(SC_CF_All) || sc.equals(SC_CF_All_Conditional));
    }

    static boolean isServiceCodeCallBarring(String sc) {
        String[] barringMMI;
        Resources resource = Resources.getSystem();
        if (sc != null && (barringMMI = resource.getStringArray(R.array.config_bg_current_drain_threshold_to_restricted_bucket)) != null) {
            for (String match : barringMMI) {
                if (sc.equals(match)) {
                    return true;
                }
            }
        }
        return false;
    }

    static String scToBarringFacility(String sc) {
        if (sc == null) {
            throw new RuntimeException("invalid call barring sc");
        }
        if (sc.equals(SC_BAOC)) {
            return "AO";
        }
        if (sc.equals(SC_BAOIC)) {
            return "OI";
        }
        if (sc.equals(SC_BAOICxH)) {
            return "OX";
        }
        if (sc.equals(SC_BAIC)) {
            return "AI";
        }
        if (sc.equals(SC_BAICr)) {
            return "IR";
        }
        if (sc.equals(SC_BA_ALL)) {
            return "AB";
        }
        if (sc.equals(SC_BA_MO)) {
            return "AG";
        }
        if (sc.equals(SC_BA_MT)) {
            return "AC";
        }
        throw new RuntimeException("invalid call barring sc");
    }

    public UniGsmMmiCode(GsmCdmaPhone phone, UiccCardApplication app) {
        super(phone.getHandler().getLooper());
        this.mState = MmiCode.State.PENDING;
        this.mIsSsInfo = false;
        this.mPhone = phone;
        this.mContext = phone.getContext();
        this.mUiccApplication = app;
        if (app != null) {
            this.mIccRecords = app.getIccRecords();
        }
        this.mRi = new RadioInteractor(this.mContext);
        this.mMessenger = new Messenger(new Handler() { // from class: com.android.internal.telephony.gsm.UniGsmMmiCode.1
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                Rlog.d(UniGsmMmiCode.LOG_TAG, "handleMessage : msg.what= " + msg.what);
                Bundle bundle = msg.getData();
                switch (msg.what) {
                    case 8:
                    case 9:
                    case 10:
                        if (bundle != null) {
                            UniGsmMmiCode.this.onQueryLiComplete(bundle);
                            break;
                        }
                        break;
                    case 11:
                        if (bundle != null) {
                            UniGsmMmiCode.this.onSetClipComplete(bundle);
                            break;
                        }
                        break;
                }
            }
        });
    }

    public MmiCode.State getState() {
        return this.mState;
    }

    public CharSequence getMessage() {
        return this.mMessage;
    }

    public Phone getPhone() {
        return this.mPhone;
    }

    public void cancel() {
        if (this.mState == MmiCode.State.COMPLETE || this.mState == MmiCode.State.FAILED) {
            return;
        }
        this.mState = MmiCode.State.CANCELLED;
        if (this.mIsPendingUSSD) {
            this.mPhone.mCi.cancelPendingUssd(obtainMessage(7, this));
        } else {
            this.mPhone.onMMIDone(this);
        }
    }

    public boolean isCancelable() {
        return this.mIsPendingUSSD;
    }

    public boolean isNetworkInitiatedUssd() {
        return this.mIsNetworkInitiatedUSSD;
    }

    boolean isMMI() {
        return this.mPoundString != null;
    }

    boolean isShortCode() {
        String str;
        return this.mPoundString == null && (str = this.mDialingNumber) != null && str.length() <= 2;
    }

    public String getDialString() {
        return this.mPoundString;
    }

    public static boolean isTwoDigitShortCode(Context context, int subId, String dialString) {
        Rlog.d(LOG_TAG, "isTwoDigitShortCode");
        if (dialString == null || dialString.length() > 2) {
            return false;
        }
        if (sTwoDigitNumberPattern == null) {
            sTwoDigitNumberPattern = getTwoDigitNumberPattern(context, subId);
        }
        for (String dialnumber : sTwoDigitNumberPattern) {
            Rlog.d(LOG_TAG, "Two Digit Number Pattern " + dialnumber);
            if (dialString.equals(dialnumber)) {
                Rlog.d(LOG_TAG, "Two Digit Number Pattern -true");
                return true;
            }
        }
        Rlog.d(LOG_TAG, "Two Digit Number Pattern -false");
        return false;
    }

    private static String[] getTwoDigitNumberPattern(Context context, int subId) {
        PersistableBundle bundle;
        Rlog.d(LOG_TAG, "Get two digit number pattern: subId=" + subId);
        String[] twoDigitNumberPattern = null;
        CarrierConfigManager configManager = (CarrierConfigManager) context.getSystemService("carrier_config");
        if (configManager != null && (bundle = configManager.getConfigForSubId(subId)) != null) {
            Rlog.d(LOG_TAG, "Two Digit Number Pattern from carrir config");
            twoDigitNumberPattern = bundle.getStringArray("mmi_two_digit_number_pattern_string_array");
        }
        if (twoDigitNumberPattern == null) {
            return new String[0];
        }
        return twoDigitNumberPattern;
    }

    private static boolean isShortCode(String dialString, GsmCdmaPhone phone) {
        if (dialString == null || dialString.length() == 0 || isEmergencyNumber(phone, dialString)) {
            return false;
        }
        return isShortCodeUSSD(dialString, phone);
    }

    private static boolean isShortCodeUSSD(String dialString, GsmCdmaPhone phone) {
        return (dialString == null || dialString.length() > 2 || (!phone.isInCall() && dialString.length() == 2 && dialString.charAt(0) == '1')) ? false : true;
    }

    public boolean isPinPukCommand() {
        String str = this.mSc;
        return str != null && (str.equals(SC_PIN) || this.mSc.equals(SC_PIN2) || this.mSc.equals(SC_PUK) || this.mSc.equals(SC_PUK2));
    }

    public boolean isTemporaryModeCLIR() {
        String str = this.mSc;
        return str != null && str.equals(SC_CLIR) && this.mDialingNumber != null && (isActivate() || isDeactivate());
    }

    public static boolean isEmergencyNumber(Phone phone, String dialString) {
        try {
            TelephonyManager tm = (TelephonyManager) phone.getContext().getSystemService(TelephonyManager.class);
            return tm.isEmergencyNumber(dialString);
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static boolean isCarrierSupportCallerIdVerticalServiceCodes(Phone phone) {
        CarrierConfigManager configManager = (CarrierConfigManager) phone.getContext().getSystemService(CarrierConfigManager.class);
        PersistableBundle b = null;
        if (configManager != null) {
            b = configManager.getConfigForSubId(phone.getSubId());
        }
        if (b == null) {
            return false;
        }
        return b.getBoolean("carrier_supports_caller_id_vertical_service_codes_bool");
    }

    public int getCLIRMode() {
        String str = this.mSc;
        if (str != null && str.equals(SC_CLIR)) {
            if (isActivate()) {
                return 2;
            }
            if (isDeactivate()) {
                return 1;
            }
            return 0;
        }
        return 0;
    }

    private boolean isFacToDial() {
        CarrierConfigManager configManager = (CarrierConfigManager) this.mPhone.getContext().getSystemService("carrier_config");
        PersistableBundle b = configManager.getConfigForSubId(this.mPhone.getSubId());
        if (b != null) {
            String[] dialFacList = b.getStringArray("feature_access_codes_string_array");
            if (!ArrayUtils.isEmpty(dialFacList)) {
                for (String fac : dialFacList) {
                    if (fac.equals(this.mSc)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    boolean isActivate() {
        String str = this.mAction;
        return str != null && str.equals(ACTION_ACTIVATE);
    }

    boolean isDeactivate() {
        String str = this.mAction;
        return str != null && str.equals(ACTION_DEACTIVATE);
    }

    boolean isInterrogate() {
        String str = this.mAction;
        return str != null && str.equals(ACTION_INTERROGATE);
    }

    boolean isRegister() {
        String str = this.mAction;
        return str != null && str.equals(ACTION_REGISTER);
    }

    boolean isErasure() {
        String str = this.mAction;
        return str != null && str.equals(ACTION_ERASURE);
    }

    public boolean isPendingUSSD() {
        return this.mIsPendingUSSD;
    }

    public boolean isUssdRequest() {
        return this.mIsUssdRequest;
    }

    public boolean isSsInfo() {
        return this.mIsSsInfo;
    }

    public static boolean isVoiceUnconditionalForwarding(int reason, int serviceClass) {
        return (reason == 0 || reason == 4) && ((serviceClass & 1) != 0 || serviceClass == 0);
    }

    public void processCode() throws CallStateException {
        UiccCardApplication uiccCardApplication;
        String facility;
        int cfAction;
        try {
            if (isShortCode()) {
                Rlog.d(LOG_TAG, "processCode: isShortCode");
                sendUssd(this.mDialingNumber);
            } else {
                if (this.mDialingNumber != null) {
                    throw new RuntimeException("Invalid or Unsupported MMI Code");
                }
                String str = this.mSc;
                if (str != null && str.equals(SC_CLIP)) {
                    Rlog.d(LOG_TAG, "processCode: is CLIP");
                    if (isInterrogate()) {
                        this.mPhone.mCi.queryCLIP(obtainMessage(5, this));
                    } else {
                        if (!isActivate() && !isDeactivate()) {
                            throw new RuntimeException("Invalid or Unsupported MMI Code");
                        }
                        RadioInteractor radioInteractor = this.mRi;
                        if (radioInteractor == null) {
                            throw new RuntimeException("RadioInteractor is null");
                        }
                        radioInteractor.updateCLIP(isActivate() ? 1 : 0, this.mMessenger, 11, this.mPhone.getPhoneId());
                    }
                } else {
                    String str2 = this.mSc;
                    if (str2 != null && str2.equals(SC_CLIR)) {
                        Rlog.d(LOG_TAG, "processCode: is CLIR");
                        if (isActivate() && !this.mPhone.isClirActivationAndDeactivationPrevented()) {
                            this.mPhone.mCi.setCLIR(1, obtainMessage(1, this));
                        } else if (isDeactivate() && !this.mPhone.isClirActivationAndDeactivationPrevented()) {
                            this.mPhone.mCi.setCLIR(2, obtainMessage(1, this));
                        } else if (isInterrogate()) {
                            this.mPhone.mCi.getCLIR(obtainMessage(2, this));
                        } else {
                            throw new RuntimeException("Invalid or Unsupported MMI Code");
                        }
                    } else {
                        String str3 = this.mSc;
                        if (str3 != null && str3.equals(SC_COLP)) {
                            Rlog.d(LOG_TAG, "processCode: is COLP");
                            if (isInterrogate()) {
                                RadioInteractor radioInteractor2 = this.mRi;
                                if (radioInteractor2 == null) {
                                    throw new RuntimeException("RadioInteractor is null");
                                }
                                radioInteractor2.queryCOLP(this.mMessenger, 9, this.mPhone.getPhoneId());
                            } else {
                                throw new RuntimeException("Invalid or Unsupported MMI Code");
                            }
                        } else {
                            String str4 = this.mSc;
                            if (str4 != null && str4.equals(SC_COLR)) {
                                Rlog.d(LOG_TAG, "processCode: is COLR");
                                if (isInterrogate()) {
                                    RadioInteractor radioInteractor3 = this.mRi;
                                    if (radioInteractor3 == null) {
                                        throw new RuntimeException("RadioInteractor is null");
                                    }
                                    radioInteractor3.queryCOLR(this.mMessenger, 10, this.mPhone.getPhoneId());
                                } else {
                                    throw new RuntimeException("Invalid or Unsupported MMI Code");
                                }
                            } else {
                                String str5 = this.mSc;
                                if (str5 != null && str5.equals(SC_CNAP)) {
                                    Rlog.d(LOG_TAG, "processCode: is CNAP");
                                    if (isInterrogate()) {
                                        RadioInteractor radioInteractor4 = this.mRi;
                                        if (radioInteractor4 == null) {
                                            throw new RuntimeException("RadioInteractor is null");
                                        }
                                        radioInteractor4.getCNAP(this.mMessenger, 8, this.mPhone.getPhoneId());
                                    } else {
                                        throw new RuntimeException("Invalid or Unsupported MMI Code");
                                    }
                                } else if (isServiceCodeCallForwarding(this.mSc)) {
                                    Rlog.d(LOG_TAG, "processCode: is CF");
                                    String dialingNumber = this.mSia;
                                    int serviceClass = siToServiceClass(this.mSib);
                                    int reason = scToCallForwardReason(this.mSc);
                                    int time = siToTime(this.mSic);
                                    if (isInterrogate()) {
                                        this.mPhone.mCi.queryCallForwardStatus(reason, serviceClass, dialingNumber, obtainMessage(3, this));
                                    } else {
                                        if (isActivate()) {
                                            if (isEmptyOrNull(dialingNumber)) {
                                                this.mIsCallFwdReg = false;
                                                cfAction = 1;
                                            } else {
                                                this.mIsCallFwdReg = true;
                                                cfAction = 3;
                                            }
                                        } else if (isDeactivate()) {
                                            cfAction = 0;
                                        } else if (isRegister()) {
                                            cfAction = 3;
                                        } else if (isErasure()) {
                                            cfAction = 4;
                                        } else {
                                            throw new RuntimeException("invalid action");
                                        }
                                        int isEnableDesired = (cfAction == 1 || cfAction == 3) ? 1 : 0;
                                        Rlog.d(LOG_TAG, "processCode: is CF setCallForward");
                                        this.mPhone.mCi.setCallForward(cfAction, reason, serviceClass, dialingNumber, time, obtainMessage(6, isVoiceUnconditionalForwarding(reason, serviceClass) ? 1 : 0, isEnableDesired, this));
                                    }
                                } else if (isServiceCodeCallBarring(this.mSc)) {
                                    String password = this.mSia;
                                    int serviceClass2 = siToServiceClass(this.mSib);
                                    String facility2 = scToBarringFacility(this.mSc);
                                    if (isInterrogate()) {
                                        this.mPhone.mCi.queryFacilityLock(facility2, password, serviceClass2, obtainMessage(5, this));
                                    } else {
                                        if (!isActivate() && !isDeactivate()) {
                                            throw new RuntimeException("Invalid or Unsupported MMI Code");
                                        }
                                        this.mPhone.mCi.setFacilityLock(facility2, isActivate(), password, serviceClass2, obtainMessage(1, this));
                                    }
                                } else {
                                    String str6 = this.mSc;
                                    if (str6 == null || !str6.equals(SC_PWD)) {
                                        String str7 = this.mSc;
                                        if (str7 != null && str7.equals(SC_WAIT)) {
                                            int serviceClass3 = siToServiceClass(this.mSia);
                                            if (isActivate() || isDeactivate()) {
                                                this.mPhone.mCi.setCallWaiting(isActivate(), serviceClass3, obtainMessage(1, this));
                                            } else if (isInterrogate()) {
                                                this.mPhone.mCi.queryCallWaiting(serviceClass3, obtainMessage(5, this));
                                            } else {
                                                throw new RuntimeException("Invalid or Unsupported MMI Code");
                                            }
                                        } else if (isPinPukCommand()) {
                                            String oldPinOrPuk = this.mSia;
                                            String newPinOrPuk = this.mSib;
                                            int pinLen = newPinOrPuk.length();
                                            if (isRegister()) {
                                                if (newPinOrPuk.equals(this.mSic)) {
                                                    if (pinLen < 4 || pinLen > 8) {
                                                        handlePasswordError(R.string.fp_power_button_bp_title);
                                                    } else if (this.mSc.equals(SC_PIN) && (uiccCardApplication = this.mUiccApplication) != null && uiccCardApplication.getState() == IccCardApplicationStatus.AppState.APPSTATE_PUK) {
                                                        handlePasswordError(R.string.lockscreen_storage_locked);
                                                    } else if (this.mUiccApplication != null) {
                                                        Rlog.d(LOG_TAG, "processCode: process mmi service code using UiccApp sc=" + this.mSc);
                                                        if (this.mSc.equals(SC_PIN)) {
                                                            if (oldPinOrPuk.length() >= 4 && oldPinOrPuk.length() <= 8) {
                                                                if (this.mUiccApplication.getIccLockEnabled() || this.mUiccApplication.getState() == IccCardApplicationStatus.AppState.APPSTATE_PIN) {
                                                                    this.mUiccApplication.changeIccLockPassword(oldPinOrPuk, newPinOrPuk, obtainMessage(1, this));
                                                                } else {
                                                                    handlePasswordError(R.string.default_sms_application);
                                                                }
                                                            }
                                                            handlePasswordError(R.string.fp_power_button_bp_title);
                                                            return;
                                                        }
                                                        if (this.mSc.equals(SC_PIN2)) {
                                                            if (oldPinOrPuk.length() >= 4 && oldPinOrPuk.length() <= 8) {
                                                                this.mUiccApplication.changeIccFdnPassword(oldPinOrPuk, newPinOrPuk, obtainMessage(1, this));
                                                            }
                                                            handlePasswordError(R.string.fp_power_button_bp_title);
                                                            return;
                                                        }
                                                        if (this.mSc.equals(SC_PUK)) {
                                                            if (oldPinOrPuk.length() != 8) {
                                                                handlePasswordError(R.string.fp_power_button_enrollment_button_text);
                                                                return;
                                                            }
                                                            this.mUiccApplication.supplyPuk(oldPinOrPuk, newPinOrPuk, obtainMessage(1, this));
                                                        } else if (this.mSc.equals(SC_PUK2)) {
                                                            if (oldPinOrPuk.length() != 8) {
                                                                handlePasswordError(135004257);
                                                                return;
                                                            }
                                                            this.mUiccApplication.supplyPuk2(oldPinOrPuk, newPinOrPuk, obtainMessage(1, this));
                                                        } else {
                                                            throw new RuntimeException("uicc unsupported service code=" + this.mSc);
                                                        }
                                                    } else {
                                                        throw new RuntimeException("No application mUiccApplicaiton is null");
                                                    }
                                                } else if (this.mSc.equals(SC_PIN)) {
                                                    handlePasswordError(R.string.lockscreen_glogin_forgot_pattern);
                                                } else if (this.mSc.equals(SC_PIN2)) {
                                                    handlePasswordError(135004242);
                                                } else if (this.mSc.equals(SC_PUK)) {
                                                    handlePasswordError(135004243);
                                                } else if (this.mSc.equals(SC_PUK2)) {
                                                    handlePasswordError(135004244);
                                                }
                                            } else {
                                                throw new RuntimeException("Ivalid register/action=" + this.mAction);
                                            }
                                        } else {
                                            if (this.mPoundString == null) {
                                                Rlog.d(LOG_TAG, "processCode: Invalid or Unsupported MMI Code");
                                                throw new RuntimeException("Invalid or Unsupported MMI Code");
                                            }
                                            if (getResourcesForSubId().getBoolean(R.bool.config_allowStartActivityForLongPressOnPowerInSetup)) {
                                                int ussd_method = getIntCarrierConfig("carrier_ussd_method_int");
                                                if (ussd_method != 3) {
                                                    sendUssd(this.mPoundString);
                                                } else {
                                                    throw new RuntimeException("The USSD request is not allowed over CS");
                                                }
                                            } else {
                                                sendUssd(this.mPoundString);
                                            }
                                        }
                                    } else {
                                        String oldPwd = this.mSib;
                                        String newPwd = this.mSic;
                                        if (!isActivate() && !isRegister()) {
                                            throw new RuntimeException("Invalid or Unsupported MMI Code");
                                        }
                                        this.mAction = ACTION_REGISTER;
                                        String facility3 = this.mSia;
                                        if (facility3 == null) {
                                            facility = "AB";
                                        } else {
                                            facility = scToBarringFacility(facility3);
                                        }
                                        if (newPwd.equals(this.mPwd)) {
                                            this.mPhone.mCi.changeBarringPassword(facility, oldPwd, newPwd, obtainMessage(1, this));
                                        } else {
                                            handlePasswordError(R.string.mediasize_na_ansi_d);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (RuntimeException exc) {
            this.mState = MmiCode.State.FAILED;
            this.mMessage = this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long);
            Rlog.d(LOG_TAG, "processCode: RuntimeException=" + exc);
            this.mPhone.onMMIDone(this);
        }
    }

    private void handlePasswordError(int res) {
        this.mState = MmiCode.State.FAILED;
        StringBuilder sb = new StringBuilder(getScString());
        sb.append("\n");
        sb.append(this.mContext.getText(res));
        this.mMessage = sb;
        this.mPhone.onMMIDone(this);
    }

    public void onUssdFinished(String ussdMessage, boolean isUssdRequest) {
        if (this.mState == MmiCode.State.PENDING) {
            if (TextUtils.isEmpty(ussdMessage)) {
                Rlog.d(LOG_TAG, "onUssdFinished: no network provided message; using default.");
                this.mMessage = this.mContext.getText(R.string.lockscreen_missing_sim_instructions);
            } else {
                this.mMessage = ussdMessage;
            }
            this.mIsUssdRequest = isUssdRequest;
            if (!isUssdRequest) {
                this.mState = MmiCode.State.COMPLETE;
            }
            Rlog.d(LOG_TAG, "onUssdFinished: ussdMessage=" + ussdMessage);
            this.mPhone.onMMIDone(this);
        }
    }

    public void onUssdFinishedError() {
        if (this.mState == MmiCode.State.PENDING) {
            this.mState = MmiCode.State.FAILED;
            if (TextUtils.isEmpty(this.mMessage)) {
                this.mMessage = this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long);
            }
            Rlog.d(LOG_TAG, "onUssdFinishedError");
            this.mPhone.onMMIDone(this);
        }
    }

    public void onUssdRelease() {
        if (this.mState == MmiCode.State.PENDING) {
            this.mState = MmiCode.State.COMPLETE;
            this.mMessage = null;
            Rlog.d(LOG_TAG, "onUssdRelease");
            this.mPhone.onMMIDone(this);
        }
    }

    public void sendUssd(String ussdMessage) {
        this.mIsPendingUSSD = true;
        this.mPhone.mCi.sendUSSD(ussdMessage, obtainMessage(4, this));
    }

    @Override // android.os.Handler
    public void handleMessage(Message msg) {
        switch (msg.what) {
            case 1:
                AsyncResult ar = (AsyncResult) msg.obj;
                onSetComplete(msg, ar);
                break;
            case 2:
                AsyncResult ar2 = (AsyncResult) msg.obj;
                onGetClirComplete(ar2);
                break;
            case 3:
                AsyncResult ar3 = (AsyncResult) msg.obj;
                onQueryCfComplete(ar3);
                break;
            case 4:
                AsyncResult ar4 = (AsyncResult) msg.obj;
                if (ar4.exception != null) {
                    this.mState = MmiCode.State.FAILED;
                    this.mMessage = getErrorMessage(ar4);
                    this.mPhone.onMMIDone(this);
                }
                break;
            case 5:
                AsyncResult ar5 = (AsyncResult) msg.obj;
                onQueryComplete(ar5);
                break;
            case 6:
                AsyncResult ar6 = (AsyncResult) msg.obj;
                if (ar6.exception == null && msg.arg1 == 1) {
                    boolean cffEnabled = msg.arg2 == 1;
                    this.mPhone.setVoiceCallForwardingFlag(1, cffEnabled, this.mDialingNumber);
                }
                if (ar6.exception == null && (isErasure() || isDeactivate())) {
                    Rlog.d(LOG_TAG, "erase video call forward sc : " + this.mSc);
                    if (SC_CFU.equals(this.mSc) || SC_CF_All.equals(this.mSc)) {
                        dismissVideoCFNotification();
                    }
                }
                onSetComplete(msg, ar6);
                break;
            case 7:
                this.mPhone.onMMIDone(this);
                break;
        }
    }

    private CharSequence getErrorMessage(AsyncResult ar) {
        if (ar.exception instanceof CommandException) {
            CommandException.Error err = ar.exception.getCommandError();
            if (err == CommandException.Error.FDN_CHECK_FAILURE) {
                Rlog.i(LOG_TAG, "FDN_CHECK_FAILURE");
                return this.mContext.getText(R.string.lockscreen_missing_sim_message_short);
            }
            if (err == CommandException.Error.USSD_MODIFIED_TO_DIAL) {
                Rlog.i(LOG_TAG, "USSD_MODIFIED_TO_DIAL");
                return this.mContext.getText(R.string.policydesc_disableKeyguardFeatures);
            }
            if (err == CommandException.Error.USSD_MODIFIED_TO_SS) {
                Rlog.i(LOG_TAG, "USSD_MODIFIED_TO_SS");
                return this.mContext.getText(R.string.policydesc_expirePassword);
            }
            if (err == CommandException.Error.USSD_MODIFIED_TO_USSD) {
                Rlog.i(LOG_TAG, "USSD_MODIFIED_TO_USSD");
                return this.mContext.getText(R.string.policydesc_forceLock);
            }
            if (err == CommandException.Error.SS_MODIFIED_TO_DIAL) {
                Rlog.i(LOG_TAG, "SS_MODIFIED_TO_DIAL");
                return this.mContext.getText(R.string.phoneTypeWorkPager);
            }
            if (err == CommandException.Error.SS_MODIFIED_TO_USSD) {
                Rlog.i(LOG_TAG, "SS_MODIFIED_TO_USSD");
                return this.mContext.getText(R.string.policydesc_disableCamera);
            }
            if (err == CommandException.Error.SS_MODIFIED_TO_SS) {
                Rlog.i(LOG_TAG, "SS_MODIFIED_TO_SS");
                return this.mContext.getText(R.string.pin_target);
            }
            if (err == CommandException.Error.OEM_ERROR_1) {
                Rlog.i(LOG_TAG, "OEM_ERROR_1 USSD_MODIFIED_TO_DIAL_VIDEO");
                return this.mContext.getText(R.string.policydesc_encryptedStorage);
            }
        }
        return this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long);
    }

    private CharSequence getScString() {
        String str = this.mSc;
        if (str != null) {
            if (isServiceCodeCallBarring(str)) {
                return this.mContext.getText(R.string.config_systemWearHealthService);
            }
            if (isServiceCodeCallForwarding(this.mSc)) {
                return getCfType(this.mSc);
            }
            if (this.mSc.equals(SC_CLIP)) {
                return this.mContext.getText(R.string.config_systemVendorIntelligence);
            }
            if (this.mSc.equals(SC_CLIR)) {
                return this.mContext.getText(R.string.BaMmi);
            }
            if (this.mSc.equals(SC_PWD)) {
                return this.mContext.getText(R.string.PERSOSUBSTATE_SIM_SPN_ERROR);
            }
            if (this.mSc.equals(SC_WAIT)) {
                return this.mContext.getText(R.string.CfMmi);
            }
            if (isPinPukCommand()) {
                if (this.mSc.equals(SC_PIN)) {
                    return this.mContext.getText(R.string.PERSOSUBSTATE_SIM_SPN_ENTRY);
                }
                if (this.mSc.equals(SC_PIN2)) {
                    return this.mContext.getText(135004160);
                }
                if (this.mSc.equals(SC_PUK)) {
                    return this.mContext.getText(135004162);
                }
                if (this.mSc.equals(SC_PUK2)) {
                    return this.mContext.getText(135004161);
                }
                return "";
            }
            if (this.mSc.equals(SC_COLP)) {
                return this.mContext.getText(R.string.CLIRDefaultOnNextCallOn);
            }
            if (this.mSc.equals(SC_COLR)) {
                return this.mContext.getText(R.string.CLIRPermanent);
            }
            return "";
        }
        return "";
    }

    private void onSetComplete(Message msg, AsyncResult ar) {
        StringBuilder sb = new StringBuilder(getScString());
        sb.append("\n");
        if (ar.exception != null) {
            this.mState = MmiCode.State.FAILED;
            if (ar.exception instanceof CommandException) {
                CommandException.Error err = ar.exception.getCommandError();
                if (err == CommandException.Error.PASSWORD_INCORRECT) {
                    if (isPinPukCommand()) {
                        int type = 0;
                        if (this.mSc.equals(SC_PUK)) {
                            sb.append(this.mContext.getText(R.string.biometric_not_recognized));
                            type = 2;
                        } else if (this.mSc.equals(SC_PUK2)) {
                            sb.append(this.mContext.getText(135004169));
                            type = 3;
                        } else if (this.mSc.equals(SC_PIN)) {
                            sb.append(this.mContext.getText(R.string.biometric_face_not_recognized));
                            type = 0;
                        } else if (this.mSc.equals(SC_PIN2)) {
                            sb.append(this.mContext.getText(135004168));
                            type = 1;
                        }
                        int attemptsRemaining = getRemainTimes(this.mContext, type, this.mPhone.getPhoneId());
                        if (attemptsRemaining <= 0) {
                            Rlog.d(LOG_TAG, "onSetComplete: PUK locked, cancel as lock screen will handle this");
                            this.mState = MmiCode.State.CANCELLED;
                            if (attemptsRemaining == 0 && (type == 0 || type == 1 || type == 2 || type == 3)) {
                                this.mState = MmiCode.State.FAILED;
                                sb = new StringBuilder(getScString());
                                sb.append("\n");
                                if (type == 0) {
                                    sb.append(this.mContext.getText(R.string.lockscreen_storage_locked));
                                } else if (type == 1) {
                                    sb.append(this.mContext.getText(R.string.lockscreen_too_many_failed_attempts_countdown));
                                } else {
                                    sb.append(this.mContext.getText(135004237));
                                }
                            }
                        } else if (attemptsRemaining > 0) {
                            Rlog.d(LOG_TAG, "onSetComplete: attemptsRemaining=" + attemptsRemaining);
                            sb.append(this.mContext.getResources().getQuantityString(R.plurals.pinpuk_attempts, attemptsRemaining, Integer.valueOf(attemptsRemaining)));
                        }
                    } else {
                        sb.append(this.mContext.getText(R.string.mediasize_na_ansi_d));
                    }
                } else if (err == CommandException.Error.SIM_PUK2) {
                    sb.append(this.mContext.getText(R.string.biometric_face_not_recognized));
                    sb.append("\n");
                    sb.append(this.mContext.getText(R.string.lockscreen_too_many_failed_attempts_countdown));
                } else if (err == CommandException.Error.REQUEST_NOT_SUPPORTED) {
                    if (this.mSc.equals(SC_PIN)) {
                        sb.append(this.mContext.getText(R.string.default_sms_application));
                    }
                } else if (err == CommandException.Error.FDN_CHECK_FAILURE) {
                    Rlog.i(LOG_TAG, "FDN_CHECK_FAILURE");
                    sb.append(this.mContext.getText(R.string.lockscreen_missing_sim_message_short));
                } else if (err == CommandException.Error.MODEM_ERR && isServiceCodeCallForwarding(this.mSc) && this.mPhone.getServiceState().getVoiceRoaming() && !this.mPhone.supports3gppCallForwardingWhileRoaming()) {
                    sb.append(this.mContext.getText(R.string.lockscreen_missing_sim_message));
                } else {
                    sb.append(getErrorMessage(ar));
                }
            } else {
                sb.append(this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long));
            }
        } else if (isActivate()) {
            this.mState = MmiCode.State.COMPLETE;
            if (this.mIsCallFwdReg) {
                sb.append(this.mContext.getText(R.string.permlab_readCalendar));
            } else {
                sb.append(this.mContext.getText(R.string.permlab_processOutgoingCalls));
            }
            if (this.mSc.equals(SC_CLIR)) {
                this.mPhone.saveClirSetting(1);
            }
        } else if (isDeactivate()) {
            this.mState = MmiCode.State.COMPLETE;
            sb.append(this.mContext.getText(R.string.permlab_preferredPaymentInfo));
            if (this.mSc.equals(SC_CLIR)) {
                this.mPhone.saveClirSetting(2);
            }
        } else if (isRegister()) {
            this.mState = MmiCode.State.COMPLETE;
            sb.append(this.mContext.getText(R.string.permlab_readCalendar));
        } else if (isErasure()) {
            this.mState = MmiCode.State.COMPLETE;
            sb.append(this.mContext.getText(R.string.permlab_ranging));
        } else {
            this.mState = MmiCode.State.FAILED;
            sb.append(this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long));
        }
        this.mMessage = sb;
        Rlog.d(LOG_TAG, "onSetComplete mmi=" + this);
        this.mPhone.onMMIDone(this);
    }

    private void onGetClirComplete(AsyncResult ar) {
        StringBuilder sb = new StringBuilder(getScString());
        sb.append("\n");
        if (ar.exception != null) {
            this.mState = MmiCode.State.FAILED;
            sb.append(getErrorMessage(ar));
        } else {
            int[] clirArgs = (int[]) ar.result;
            switch (clirArgs[1]) {
                case 0:
                    sb.append(this.mContext.getText(R.string.permlab_readBasicPhoneState));
                    this.mState = MmiCode.State.COMPLETE;
                    break;
                case 1:
                    sb.append(this.mContext.getText(R.string.config_defaultWallet));
                    this.mState = MmiCode.State.COMPLETE;
                    break;
                case 2:
                    sb.append(this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long));
                    this.mState = MmiCode.State.FAILED;
                    break;
                case 3:
                    switch (clirArgs[0]) {
                        case 1:
                            sb.append(this.mContext.getText(R.string.config_defaultRetailDemo));
                            break;
                        case 2:
                            sb.append(this.mContext.getText(R.string.config_systemCallStreaming));
                            break;
                        default:
                            sb.append(this.mContext.getText(R.string.config_defaultRetailDemo));
                            break;
                    }
                    this.mState = MmiCode.State.COMPLETE;
                    break;
                case 4:
                    switch (clirArgs[0]) {
                        case 1:
                            sb.append(this.mContext.getText(R.string.config_systemFinancedDeviceController));
                            break;
                        case 2:
                            sb.append(this.mContext.getText(R.string.config_defaultNotes));
                            break;
                        default:
                            sb.append(this.mContext.getText(R.string.config_defaultNotes));
                            break;
                    }
                    this.mState = MmiCode.State.COMPLETE;
                    break;
            }
        }
        this.mMessage = sb;
        Rlog.d(LOG_TAG, "onGetClirComplete: mmi=" + this);
        this.mPhone.onMMIDone(this);
    }

    private CharSequence serviceClassToCFString(int serviceClass) {
        switch (serviceClass) {
            case 1:
                return this.mContext.getText(R.string.permlab_postNotification);
            case 2:
                return this.mContext.getText(R.string.permlab_modifyAudioSettings);
            case 4:
                return this.mContext.getText(R.string.permlab_nfc);
            case 8:
                return this.mContext.getText(R.string.permlab_persistentActivity);
            case 16:
                return this.mContext.getText(R.string.permlab_nearby_wifi_devices);
            case 32:
                return this.mContext.getText(R.string.permlab_modifyNetworkAccounting);
            case 64:
                return this.mContext.getText(R.string.permlab_observeCompanionDevicePresence);
            case 128:
                return this.mContext.getText(R.string.permlab_nfcTransactionEvent);
            default:
                return null;
        }
    }

    private CharSequence makeCFQueryResultMessage(CallForwardInfo info, int serviceClassMask) {
        CharSequence template;
        String[] sources = {"{0}", "{1}", "{2}"};
        CharSequence[] destinations = new CharSequence[3];
        boolean needTimeTemplate = info.reason == 2;
        if (info.status == 1) {
            if (needTimeTemplate) {
                template = this.mContext.getText(R.string.color_inversion_feature_name);
            } else {
                template = this.mContext.getText(R.string.color_correction_feature_name);
            }
        } else if (info.status == 0 && isEmptyOrNull(info.number)) {
            template = this.mContext.getText(R.string.common_last_name_prefixes);
        } else if (needTimeTemplate) {
            template = this.mContext.getText(R.string.common_name_conjunctions);
        } else {
            template = this.mContext.getText(R.string.common_name);
        }
        destinations[0] = serviceClassToCFString(info.serviceClass & serviceClassMask);
        destinations[1] = formatLtr(PhoneNumberUtils.stringFromStringAndTOA(info.number, info.toa));
        destinations[2] = Integer.toString(info.timeSeconds);
        if (info.reason == 0 && (info.serviceClass & serviceClassMask) == 1) {
            boolean cffEnabled = info.status == 1;
            this.mPhone.setVoiceCallForwardingFlag(1, cffEnabled, info.number);
        }
        return TextUtils.replace(template, sources, destinations);
    }

    private String formatLtr(String str) {
        BidiFormatter fmt = BidiFormatter.getInstance();
        return str == null ? str : fmt.unicodeWrap(str, TextDirectionHeuristics.LTR, true);
    }

    private void onQueryCfComplete(AsyncResult ar) {
        StringBuilder sb = new StringBuilder(getScString());
        sb.append("\n");
        if (ar.exception != null) {
            this.mState = MmiCode.State.FAILED;
            sb.append(getErrorMessage(ar));
        } else {
            CallForwardInfo[] infos = (CallForwardInfo[]) ar.result;
            if (infos == null || infos.length == 0) {
                sb.append(this.mContext.getText(R.string.permlab_preferredPaymentInfo));
                this.mPhone.setVoiceCallForwardingFlag(1, false, (String) null);
            } else {
                SpannableStringBuilder tb = new SpannableStringBuilder();
                for (int serviceClassMask = 1; serviceClassMask <= 128; serviceClassMask <<= 1) {
                    int s = infos.length;
                    for (int i = 0; i < s; i++) {
                        if ((infos[i].serviceClass & serviceClassMask) != 0) {
                            tb.append(makeCFQueryResultMessage(infos[i], serviceClassMask));
                            tb.append((CharSequence) "\n");
                        }
                    }
                }
                sb.append((CharSequence) tb);
            }
            this.mState = MmiCode.State.COMPLETE;
        }
        this.mMessage = sb;
        Rlog.d(LOG_TAG, "onQueryCfComplete: mmi=" + this);
        this.mPhone.onMMIDone(this);
    }

    private void onQueryComplete(AsyncResult ar) {
        StringBuilder sb = new StringBuilder(getScString());
        sb.append("\n");
        if (ar.exception != null) {
            this.mState = MmiCode.State.FAILED;
            sb.append(getErrorMessage(ar));
        } else {
            int[] ints = (int[]) ar.result;
            if (ints.length != 0) {
                if (ints[0] == 0) {
                    sb.append(this.mContext.getText(R.string.permlab_preferredPaymentInfo));
                } else if (this.mSc.equals(SC_WAIT)) {
                    sb.append(createQueryCallWaitingResultMessage(ints[1]));
                } else if (isServiceCodeCallBarring(this.mSc)) {
                    sb.append(createQueryCallBarringResultMessage(ints[0]));
                } else if (ints[0] == 1) {
                    sb.append(this.mContext.getText(R.string.permlab_processOutgoingCalls));
                } else {
                    sb.append(this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long));
                }
            } else {
                sb.append(this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long));
            }
            this.mState = MmiCode.State.COMPLETE;
        }
        this.mMessage = sb;
        Rlog.d(LOG_TAG, "onQueryComplete: mmi=" + this);
        this.mPhone.onMMIDone(this);
    }

    private CharSequence createQueryCallWaitingResultMessage(int serviceClass) {
        StringBuilder sb = new StringBuilder(this.mContext.getText(R.string.permlab_queryAllPackages));
        for (int classMask = 1; classMask <= 128; classMask <<= 1) {
            if ((classMask & serviceClass) != 0) {
                sb.append("\n");
                sb.append(serviceClassToCFString(classMask & serviceClass));
            }
        }
        return sb;
    }

    private CharSequence createQueryCallBarringResultMessage(int serviceClass) {
        StringBuilder sb = new StringBuilder(this.mContext.getText(R.string.permlab_queryAllPackages));
        for (int classMask = 1; classMask <= 128; classMask <<= 1) {
            if ((classMask & serviceClass) != 0) {
                sb.append("\n");
                sb.append(serviceClassToCFString(classMask & serviceClass));
            }
        }
        return sb;
    }

    private int getIntCarrierConfig(String key) {
        CarrierConfigManager ConfigManager = (CarrierConfigManager) this.mContext.getSystemService(CarrierConfigManager.class);
        PersistableBundle b = null;
        if (ConfigManager != null) {
            b = ConfigManager.getConfigForSubId(this.mPhone.getSubId());
        }
        if (b != null) {
            return b.getInt(key);
        }
        return CarrierConfigManager.getDefaultConfig().getInt(key);
    }

    public ResultReceiver getUssdCallbackReceiver() {
        return this.mCallbackReceiver;
    }

    @Override // android.os.Handler
    public String toString() {
        StringBuilder sb = new StringBuilder("UniGsmMmiCode {");
        sb.append("State=" + getState());
        if (this.mAction != null) {
            sb.append(" action=" + this.mAction);
        }
        if (this.mSc != null) {
            sb.append(" sc=" + this.mSc);
        }
        if (this.mSia != null) {
            sb.append(" sia=" + Rlog.pii(LOG_TAG, this.mSia));
        }
        if (this.mSib != null) {
            sb.append(" sib=" + Rlog.pii(LOG_TAG, this.mSib));
        }
        if (this.mSic != null) {
            sb.append(" sic=" + Rlog.pii(LOG_TAG, this.mSic));
        }
        if (this.mPoundString != null) {
            sb.append(" poundString=" + Rlog.pii(LOG_TAG, this.mPoundString));
        }
        if (this.mDialingNumber != null) {
            sb.append(" dialingNumber=" + Rlog.pii(LOG_TAG, this.mDialingNumber));
        }
        if (this.mPwd != null) {
            sb.append(" pwd=" + Rlog.pii(LOG_TAG, this.mPwd));
        }
        if (this.mCallbackReceiver != null) {
            sb.append(" hasReceiver");
        }
        sb.append("}");
        return sb.toString();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onQueryLiComplete(Bundle bundle) {
        StringBuilder sb = new StringBuilder(getScString());
        sb.append("\n");
        int result = bundle.getInt("result");
        Rlog.i(LOG_TAG, "onQueryLiComplete result :" + result);
        if (QUERY_LI_RESPONSE_ERROR == result) {
            this.mState = MmiCode.State.FAILED;
            sb.append(this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long));
        } else {
            if (result == 0) {
                sb.append(this.mContext.getText(R.string.permlab_preferredPaymentInfo));
            } else if (1 != result) {
                sb.append(this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long));
            } else {
                sb.append(this.mContext.getText(R.string.permlab_processOutgoingCalls));
            }
            this.mState = MmiCode.State.COMPLETE;
        }
        this.mMessage = sb;
        this.mPhone.onMMIDone(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onSetClipComplete(Bundle bundle) {
        StringBuilder sb = new StringBuilder(getScString());
        sb.append("\n");
        boolean exception = bundle.getBoolean("hasException");
        Rlog.i(LOG_TAG, "onSetClipComplete exception :" + exception);
        if (exception) {
            this.mState = MmiCode.State.FAILED;
            sb.append(this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long));
        } else {
            if (isDeactivate()) {
                sb.append(this.mContext.getText(R.string.permlab_preferredPaymentInfo));
            } else if (!isActivate()) {
                sb.append(this.mContext.getText(R.string.lockscreen_missing_sim_instructions_long));
            } else {
                sb.append(this.mContext.getText(R.string.permlab_processOutgoingCalls));
            }
            this.mState = MmiCode.State.COMPLETE;
        }
        this.mMessage = sb;
        this.mPhone.onMMIDone(this);
    }

    public static UniGsmMmiCode newNetworkInitiatedUssdError(String ussdMessage, boolean isUssdRequest, GsmCdmaPhone phone, UiccCardApplication app) {
        UniGsmMmiCode ret = new UniGsmMmiCode(phone, app);
        if (TextUtils.isEmpty(ussdMessage)) {
            ret.mMessage = ret.mContext.getText(R.string.lockscreen_missing_sim_instructions_long);
        } else {
            ret.mMessage = ussdMessage;
        }
        ret.mIsUssdRequest = isUssdRequest;
        ret.mState = MmiCode.State.FAILED;
        return ret;
    }

    private CharSequence getCfType(String sc) {
        int resId = R.string.config_systemDependencyInstaller;
        boolean needShowCfType = getResourcesForSubId().getBoolean(134414338);
        Rlog.i(LOG_TAG, "getScString needShowCfType " + needShowCfType);
        if (needShowCfType) {
            switch (sc) {
                case "21":
                    resId = 135004174;
                    break;
                case "67":
                    resId = 135004171;
                    break;
                case "61":
                    resId = 135004173;
                    break;
                case "62":
                    resId = 135004172;
                    break;
            }
        }
        return this.mContext.getText(resId);
    }

    private int getRemainTimes(Context context, int type, int phoneId) {
        String remainTimesProperty = null;
        if (type >= 0) {
            String[] strArr = PROP_SIM_PIN_PUK_REMAINTIMES;
            if (type < strArr.length) {
                remainTimesProperty = strArr[type];
            }
        }
        if (TextUtils.isEmpty(remainTimesProperty)) {
            return 0;
        }
        TelephonyManager.from(context);
        String propertyValue = TelephonyManager.getTelephonyProperty(phoneId, remainTimesProperty, "");
        if (TextUtils.isEmpty(propertyValue)) {
            return 0;
        }
        try {
            int remainTimes = Integer.valueOf(propertyValue).intValue();
            return remainTimes;
        } catch (NumberFormatException e) {
            Rlog.e(LOG_TAG, "number format exception in getRemainTimes : " + e);
            return 0;
        }
    }

    private void dismissVideoCFNotification() {
        if (this.mContext != null) {
            Intent intent = new Intent(REFRESH_VIDEO_CF_NOTIFICATION_ACTION);
            intent.putExtra(VIDEO_CF_STATUS, false);
            intent.putExtra(VIDEO_CF_SUB_ID, this.mPhone.getSubId());
            intent.setPackage("com.android.phone");
            this.mContext.sendBroadcast(intent);
            Rlog.d(LOG_TAG, "refresh notification for video cf subid : " + this.mPhone.getSubId() + "; enable : false");
        }
    }

    Resources getResourcesForSubId() {
        return SubscriptionManager.getResourcesForSubId(this.mContext, this.mPhone.getSubId());
    }
}
