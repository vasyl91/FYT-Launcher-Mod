package com.android.internal.telephony.uicc;

import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.ServiceManager;
import android.telephony.Rlog;
import android.util.Log;
import com.android.internal.telephony.ISmsEx;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.PhoneFactory;
import com.android.internal.telephony.SubscriptionController;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniUiccSmsController extends ISmsEx.Stub {
    private static final String TAG = "UniUiccSmsController";
    private static final String UNISOC_SMS_COMMON_PERMISSION = "com.unisoc.permisson.SMS_COMMON";
    private Phone[] mPhone;

    /* JADX WARN: Multi-variable type inference failed */
    public UniUiccSmsController(Phone[] phone) {
        if (ServiceManager.getService("ismsEx") == null) {
            ServiceManager.addService("ismsEx", this);
        }
        this.mPhone = phone;
    }

    private boolean checkPermission(Phone phone) {
        if (phone == null) {
            return false;
        }
        int checkPermission = phone.getContext().checkCallingOrSelfPermission(UNISOC_SMS_COMMON_PERMISSION);
        if (checkPermission == -1) {
            Rlog.d(TAG, "check permission fail!");
            return false;
        }
        return true;
    }

    private Phone getPhone(int subId) {
        int phoneId = SubscriptionController.getInstance().getPhoneId(subId);
        return PhoneFactory.getPhone(phoneId);
    }

    public String getSmscForSubscriber(int subId) {
        Phone phone = getPhone(subId);
        if (!checkPermission(phone)) {
            return null;
        }
        GetSetSMSC getSMSC = new GetSetSMSC(phone, null);
        getSMSC.start();
        return getSMSC.getSmsc();
    }

    public boolean setSmscForSubscriber(int subId, String smscAddr) {
        Phone phone = getPhone(subId);
        if (!checkPermission(phone)) {
            return false;
        }
        GetSetSMSC setSMSC = new GetSetSMSC(phone, smscAddr);
        setSMSC.start();
        return setSMSC.setSmsc();
    }

    private static class GetSetSMSC extends Thread {
        private static final int QUERY_SMSC_DONE = 100;
        private static final int UPDATE_SMSC_DONE = 101;
        private Handler mHandler;
        private final Phone mPhone;
        private String mResult;
        private final String mSmscStr;
        private boolean mDone = false;
        private boolean bResult = false;

        public GetSetSMSC(Phone phone, String SmscStr) {
            this.mPhone = phone;
            this.mSmscStr = SmscStr;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            Looper.prepare();
            synchronized (this) {
                this.mHandler = new Handler() { // from class: com.android.internal.telephony.uicc.UniUiccSmsController.GetSetSMSC.1
                    @Override // android.os.Handler
                    public void handleMessage(Message msg) {
                        AsyncResult ar = (AsyncResult) msg.obj;
                        switch (msg.what) {
                            case GetSetSMSC.QUERY_SMSC_DONE /* 100 */:
                                synchronized (GetSetSMSC.this) {
                                    if (ar.exception == null) {
                                        GetSetSMSC.this.mResult = (String) ar.result;
                                    } else {
                                        GetSetSMSC.this.mResult = "refresh error";
                                    }
                                    Log.d(UniUiccSmsController.TAG, "[GetSetSMSC] mResult: " + GetSetSMSC.this.mResult);
                                    GetSetSMSC.this.mDone = true;
                                    GetSetSMSC.this.notifyAll();
                                    break;
                                }
                                getLooper().quit();
                                return;
                            case GetSetSMSC.UPDATE_SMSC_DONE /* 101 */:
                                synchronized (GetSetSMSC.this) {
                                    GetSetSMSC.this.bResult = ar.exception == null;
                                    Log.d(UniUiccSmsController.TAG, "[GetSetSMSC] bResult: " + GetSetSMSC.this.bResult);
                                    GetSetSMSC.this.mDone = true;
                                    GetSetSMSC.this.notifyAll();
                                    break;
                                }
                                getLooper().quit();
                                return;
                            default:
                                return;
                        }
                    }
                };
                notifyAll();
            }
            Looper.loop();
        }

        synchronized String getSmsc() {
            Handler handler;
            while (true) {
                handler = this.mHandler;
                if (handler != null) {
                    break;
                }
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                throw th;
            }
            this.mPhone.getSmscAddress(handler.obtainMessage(QUERY_SMSC_DONE));
            while (!this.mDone) {
                try {
                    Log.d(UniUiccSmsController.TAG, "[GetSetSMSC] wait get for done");
                    wait();
                } catch (InterruptedException e2) {
                    Thread.currentThread().interrupt();
                }
            }
            Log.d(UniUiccSmsController.TAG, "[GetSetSMSC] getSmsc: " + this.mResult);
            return this.mResult;
        }

        synchronized boolean setSmsc() {
            Handler handler;
            while (true) {
                handler = this.mHandler;
                if (handler != null) {
                    break;
                }
                try {
                    wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                throw th;
            }
            this.mPhone.setSmscAddress(this.mSmscStr, handler.obtainMessage(UPDATE_SMSC_DONE));
            while (!this.mDone) {
                try {
                    Log.d(UniUiccSmsController.TAG, "[GetSetSMSC] wait set for done");
                    wait();
                } catch (InterruptedException e2) {
                    Thread.currentThread().interrupt();
                }
            }
            Log.d(UniUiccSmsController.TAG, "[GetSetSMSC] set done. result= " + this.bResult);
            return this.bResult;
        }
    }
}
