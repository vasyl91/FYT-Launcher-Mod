package com.android.internal.telephony.uicc;

import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.telephony.Rlog;
import com.android.internal.telephony.phonebook.UniAdnRecord;
import com.android.internal.telephony.phonebook.UniIccPBForOperationException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniAdnRecordLoader extends Handler {
    static final int EVENT_ADN_LOAD_ALL_DONE = 3;
    static final int EVENT_ADN_LOAD_DONE = 1;
    static final int EVENT_EF_CYCLIC_LINEAR_RECORD_SIZE_DONE = 18;
    static final int EVENT_EF_LINEAR_RECORD_SIZE_DONE = 4;
    static final int EVENT_EF_PBR_SNE_LINEAR_RECORD_SIZE_DONE = 9;
    static final int EVENT_EXT_LOAD_ALL_DONE = 20;
    static final int EVENT_EXT_RECORD_LOAD_DONE = 2;
    static final int EVENT_GET_SIZE_DONE = 21;
    static final int EVENT_UPDATE_AAS_RECORD_DONE = 14;
    static final int EVENT_UPDATE_ANR_RECORD_DONE = 10;
    static final int EVENT_UPDATE_EXT_RECORD_DONE = 19;
    static final int EVENT_UPDATE_RECORD_DONE = 5;
    static final int EVENT_UPDATE_SNE_RECORD_DONE = 15;
    static final String TAG = "UniAdnRecordLoader";
    int mAdnNum;
    ArrayList<UniAdnRecord> mAdns;
    int mEf;
    int mExtensionEF;
    private IccFileHandler mFh;
    int mFileCount;
    int mIapEF;
    byte[] mIapRec;
    protected final Object mLock;
    int mPendingExtLoads;
    String mPin2;
    int mRecordNumber;
    int[] mRecordSize;
    Object mResult;
    Message mUserResponse;
    ArrayList<Integer> sneEfIndex;
    ArrayList<Integer> sneEfids;
    ArrayList<Integer> sneNums;

    public UniAdnRecordLoader(IccFileHandler fh) {
        super(Looper.getMainLooper());
        this.mLock = new Object();
        this.mFh = fh;
    }

    private String getEFPath(int efid) {
        if (efid == 28474) {
            return "3F007F10";
        }
        return null;
    }

    public void loadFromEF(int ef, int extensionEF, int recordNumber, Message response) {
        this.mEf = ef;
        this.mExtensionEF = extensionEF;
        this.mRecordNumber = recordNumber;
        this.mUserResponse = response;
        this.mFh.loadEFLinearFixed(ef, getEFPath(ef), recordNumber, obtainMessage(1));
    }

    public void loadAllFromEF(int ef, int extensionEF, Message response) {
        this.mEf = ef;
        this.mExtensionEF = extensionEF;
        this.mUserResponse = response;
        this.mFh.loadEFLinearFixedAll(ef, getEFPath(ef), obtainMessage(3));
    }

    public void updateEF(UniAdnRecord adn, int ef, int extensionEF, int recordNumber, String pin2, Message response) {
        this.mEf = ef;
        this.mExtensionEF = extensionEF;
        this.mRecordNumber = recordNumber;
        this.mUserResponse = response;
        this.mPin2 = pin2;
        this.mFh.getEFLinearRecordSize(ef, getEFPath(ef), obtainMessage(4, adn));
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.android.internal.telephony.phonebook.UniIccPBForOperationException */
    @Override // android.os.Handler
    public void handleMessage(Message msg) {
        IccException iccException;
        try {
            try {
                switch (msg.what) {
                    case 1:
                        AsyncResult ar = (AsyncResult) msg.obj;
                        byte[] data = (byte[]) ar.result;
                        if (ar.exception != null) {
                            throw new UniIccPBForOperationException(-6, "adn load failed", ar.exception);
                        }
                        logd("ADN EF: 0x" + Integer.toHexString(this.mEf) + ":" + this.mRecordNumber + "\n" + IccUtils.bytesToHexString(data));
                        UniAdnRecord adn = new UniAdnRecord(this.mEf, this.mRecordNumber, data);
                        this.mResult = adn;
                        if (adn.hasExtendedRecord()) {
                            this.mPendingExtLoads = 1;
                            this.mFh.loadEFLinearFixed(this.mExtensionEF, adn.mExtRecord, obtainMessage(2, adn));
                        }
                        break;
                        break;
                    case 2:
                        AsyncResult ar2 = (AsyncResult) msg.obj;
                        byte[] data2 = (byte[]) ar2.result;
                        UniAdnRecord adn2 = (UniAdnRecord) ar2.userObj;
                        if (ar2.exception == null) {
                            logd("ADN extension EF: 0x" + Integer.toHexString(this.mExtensionEF) + ", extRecord:" + adn2.mExtRecord + "\n" + IccUtils.bytesToHexString(data2));
                            adn2.appendExtRecord(data2);
                        } else {
                            loge("Failed to read ext record. Clear the number now.");
                            adn2.setNumber("");
                        }
                        this.mPendingExtLoads--;
                        break;
                    case 3:
                        AsyncResult ar3 = (AsyncResult) msg.obj;
                        ArrayList<byte[]> datas = (ArrayList) ar3.result;
                        if (ar3.exception != null) {
                            throw new RuntimeException("load failed", ar3.exception);
                        }
                        ArrayList<UniAdnRecord> arrayList = new ArrayList<>(datas.size());
                        this.mAdns = arrayList;
                        this.mResult = arrayList;
                        this.mPendingExtLoads = 0;
                        int s = datas.size();
                        for (int i = 0; i < s; i++) {
                            UniAdnRecord adn3 = new UniAdnRecord(this.mEf, i + 1, datas.get(i));
                            this.mAdns.add(adn3);
                            if (adn3.hasExtendedRecord()) {
                                this.mPendingExtLoads++;
                                this.mFh.loadEFLinearFixed(this.mExtensionEF, adn3.mExtRecord, obtainMessage(2, adn3));
                            }
                        }
                        break;
                        break;
                    case 4:
                        AsyncResult ar4 = (AsyncResult) msg.obj;
                        UniAdnRecord adn4 = (UniAdnRecord) ar4.userObj;
                        if (ar4.exception != null) {
                            throw new UniIccPBForOperationException(-1, "get EF record size failed", ar4.exception);
                        }
                        int[] recordSize = (int[]) ar4.result;
                        if (recordSize.length != 3 || this.mRecordNumber > recordSize[2]) {
                            throw new UniIccPBForOperationException(-1, "get wrong EF record size format", ar4.exception);
                        }
                        try {
                            byte[] data3 = adn4.buildAdnString(recordSize[0]);
                            logd("EVENT_EF_LINEAR_RECORD_SIZE_DONE, ef:0x" + Integer.toHexString(this.mEf) + ", recordNumber = " + this.mRecordNumber + ", adn.ext = " + adn4.mExtRecord);
                            if (data3 == null) {
                                throw new RuntimeException("wrong ADN format", ar4.exception);
                            }
                            this.mFh.updateEFLinearFixed(this.mEf, this.mRecordNumber, data3, this.mPin2, obtainMessage(5));
                            this.mPendingExtLoads = 1;
                        } catch (UniIccPBForOperationException e) {
                            throw e;
                        }
                        break;
                        break;
                    case 5:
                        AsyncResult ar5 = (AsyncResult) msg.obj;
                        IccIoResult result = (IccIoResult) ar5.result;
                        if (ar5.exception != null) {
                            throw new RuntimeException("update EF adn record failed", ar5.exception);
                        }
                        if (result != null && (iccException = result.getException()) != null) {
                            throw new RuntimeException("update EF adn record failed for sw", iccException);
                        }
                        this.mPendingExtLoads = 0;
                        this.mResult = null;
                        break;
                        break;
                    case 6:
                    case 7:
                    case 8:
                    case 11:
                    case 12:
                    case 13:
                    case 16:
                    case 17:
                    default:
                        super.handleMessage(msg);
                        return;
                    case 9:
                        AsyncResult ar6 = (AsyncResult) msg.obj;
                        UniAdnRecord adn5 = (UniAdnRecord) ar6.userObj;
                        if (ar6.exception != null) {
                            throw new UniIccPBForOperationException(-1, "get EF record size failed", ar6.exception);
                        }
                        int[] recordSize2 = (int[]) ar6.result;
                        if (recordSize2.length != 3) {
                            throw new UniIccPBForOperationException(-1, "get wrong EF record size format", ar6.exception);
                        }
                        int fileCount = 0;
                        int size = this.sneEfids.size();
                        for (int i2 = 0; i2 < size; i2++) {
                            if (this.sneEfids.get(i2).intValue() != 0 && this.sneNums.get(i2).intValue() != 0) {
                                fileCount++;
                                byte[] data4 = adn5.buildSneString(recordSize2[0], this.sneEfIndex.get(i2).intValue(), this.mEf, this.mAdnNum);
                                if (data4 == null) {
                                    throw new UniIccPBForOperationException(-1, "wrong SNE format", ar6.exception);
                                }
                                this.mFh.updateEFLinearFixed(this.sneEfids.get(i2).intValue(), this.sneNums.get(i2).intValue(), data4, this.mPin2, obtainMessage(15));
                            }
                        }
                        this.mPendingExtLoads = 1;
                        break;
                        break;
                    case 10:
                        AsyncResult ar7 = (AsyncResult) msg.obj;
                        if (ar7.exception != null) {
                            throw new UniIccPBForOperationException(-1, "update EF Anr record failed", ar7.exception);
                        }
                        loge("EVENT_UPDATE_ANR_RECORD_DONE, fileCount = " + this.mFileCount);
                        this.mPendingExtLoads = 0;
                        this.mResult = null;
                        int i3 = this.mFileCount - 1;
                        this.mFileCount = i3;
                        if (i3 != 0) {
                            return;
                        }
                        break;
                        break;
                    case 14:
                        AsyncResult ar8 = (AsyncResult) msg.obj;
                        if (ar8.exception != null) {
                            throw new UniIccPBForOperationException(-1, "update EF adn record failed", ar8.exception);
                        }
                        this.mPendingExtLoads = 0;
                        break;
                        break;
                    case 15:
                        AsyncResult ar9 = (AsyncResult) msg.obj;
                        if (ar9.exception != null) {
                            throw new UniIccPBForOperationException(-1, "update EF adn record failed", ar9.exception);
                        }
                        this.mPendingExtLoads = 0;
                        break;
                        break;
                    case 18:
                        AsyncResult ar10 = (AsyncResult) msg.obj;
                        UniAdnRecord adn6 = (UniAdnRecord) ar10.userObj;
                        if (ar10.exception != null) {
                            throw new UniIccPBForOperationException(-1, "get EF record size failed", ar10.exception);
                        }
                        int[] CyclicrecordSize = (int[]) ar10.result;
                        if (CyclicrecordSize.length != 3 || this.mRecordNumber > CyclicrecordSize[2]) {
                            throw new UniIccPBForOperationException(-1, "get wrong EF record size format", ar10.exception);
                        }
                        try {
                            byte[] data5 = adn6.buildAdnString(CyclicrecordSize[0]);
                            logi("EVENT_EF_CYCLIC_LINEAR_RECORD_SIZE_DONE recordNumber = " + this.mRecordNumber);
                            IccFileHandler iccFileHandler = this.mFh;
                            if (iccFileHandler != null && (iccFileHandler instanceof UniSIMFileHandler)) {
                                ((UniSIMFileHandler) iccFileHandler).updateEFCYCLICLinearFixed(this.mEf, this.mRecordNumber, data5, this.mPin2, obtainMessage(5));
                            } else if (iccFileHandler != null && (iccFileHandler instanceof UniUsimFileHandler)) {
                                ((UniUsimFileHandler) iccFileHandler).updateEFCYCLICLinearFixed(this.mEf, this.mRecordNumber, data5, this.mPin2, obtainMessage(5));
                            }
                            this.mPendingExtLoads = 1;
                        } catch (UniIccPBForOperationException e2) {
                            throw e2;
                        }
                        break;
                        break;
                    case EVENT_UPDATE_EXT_RECORD_DONE /* 19 */:
                        AsyncResult ar11 = (AsyncResult) msg.obj;
                        this.mExtensionEF = msg.arg1;
                        int index = msg.arg2;
                        logd("EVENT_UPDATE_EXT_RECORD_DONE extensionEF = " + this.mExtensionEF + ", index = " + index);
                        if (ar11.exception != null) {
                            throw new UniIccPBForOperationException(-1, "update EF ext record failed", ar11.exception);
                        }
                        this.mResult = ar11.userObj;
                        this.mPendingExtLoads = 0;
                        break;
                        break;
                    case EVENT_EXT_LOAD_ALL_DONE /* 20 */:
                        AsyncResult ar12 = (AsyncResult) msg.obj;
                        ArrayList<byte[]> extDatas = (ArrayList) ar12.result;
                        if (ar12.exception != null) {
                            throw new UniIccPBForOperationException(-6, "load all ext failed", ar12.exception);
                        }
                        this.mResult = extDatas;
                        break;
                        break;
                    case EVENT_GET_SIZE_DONE /* 21 */:
                        AsyncResult ar13 = (AsyncResult) msg.obj;
                        synchronized (this.mLock) {
                            if (ar13.exception == null) {
                                this.mRecordSize = (int[]) ar13.result;
                                logd("GET_RECORD_SIZE Size: " + Arrays.toString(this.mRecordSize));
                            }
                            notifyPending(ar13);
                            break;
                        }
                        break;
                }
                Message message = this.mUserResponse;
                if (message != null && this.mPendingExtLoads == 0) {
                    AsyncResult.forMessage(message).result = this.mResult;
                    this.mUserResponse.sendToTarget();
                    this.mUserResponse = null;
                }
            } catch (Exception e3) {
                e3.printStackTrace();
                UniIccPBForOperationException exc = new UniIccPBForOperationException(-1, e3.getMessage());
                Message message2 = this.mUserResponse;
                if (message2 != null) {
                    AsyncResult.forMessage(message2).exception = exc;
                    this.mUserResponse.sendToTarget();
                    this.mUserResponse = null;
                }
            }
        } catch (UniIccPBForOperationException exc2) {
            Message message3 = this.mUserResponse;
            if (message3 != null) {
                AsyncResult.forMessage(message3).exception = exc2;
                this.mUserResponse.sendToTarget();
                this.mUserResponse = null;
            }
        }
    }

    public void loadAllExtFromEF(int ef, int extensionEF, Message response) {
        this.mEf = ef;
        this.mExtensionEF = extensionEF;
        this.mUserResponse = response;
        this.mFh.loadEFLinearFixedAll(extensionEF, obtainMessage(EVENT_EXT_LOAD_ALL_DONE, ef, extensionEF));
    }

    public void updateEFGrpToUsim(int grpEfId, int recordNum, byte[] data, String pin2) {
        this.mFh.updateEFLinearFixed(grpEfId, recordNum, data, pin2, obtainMessage(5));
    }

    public void updateEFCyclic(UniAdnRecord adn, int ef, int extensionEF, int recordNumber, String pin2, Message response) {
        this.mEf = ef;
        this.mExtensionEF = extensionEF;
        this.mRecordNumber = recordNumber;
        this.mUserResponse = response;
        this.mPin2 = pin2;
        this.mFh.getEFLinearRecordSize(ef, obtainMessage(18, adn));
    }

    public void updateEFEmailToUsim(UniAdnRecord adn, ArrayList<Integer> emailEfids, ArrayList<Integer> emailNums, int efid, int adnNum, ArrayList<Integer> emailEfIndex, String pin2, Message response, int[] size) {
        logi("updateEFEmailToUsim: emailEfids = " + emailEfids + ", emailNums = " + emailNums + ", emailEfIndex = " + emailEfIndex);
        this.mUserResponse = response;
        this.mFileCount = 0;
        if (size == null) {
            throw new UniIccPBForOperationException(-1, "size is null");
        }
        int count = emailEfids.size();
        for (int i = 0; i < count; i++) {
            if (emailEfids.get(i).intValue() != 0 && emailNums.get(i).intValue() != 0) {
                this.mFileCount++;
                byte[] data = adn.buildEmailString(size[0], emailEfIndex.get(i).intValue(), this.mEf, adnNum);
                if (data == null) {
                    throw new UniIccPBForOperationException(-1, "wrong email format");
                }
                this.mFh.updateEFLinearFixed(emailEfids.get(i).intValue(), emailNums.get(i).intValue(), data, pin2, obtainMessage(5));
            }
        }
        this.mPendingExtLoads = 1;
    }

    public void updateEFAnrToUsim(UniAdnRecord adn, ArrayList<Integer> anrefids, int efid, int adnNum, ArrayList<Integer> anrNums, ArrayList<Integer> anrEfIndex, String pin2, Message response, int[] size, int aasIndex) {
        this.mUserResponse = response;
        loge("anrfids = " + anrefids + ", anrefids.size = " + anrefids.size() + ", ADNefid = ef:" + this.mEf);
        this.mFileCount = 0;
        if (size == null) {
            throw new UniIccPBForOperationException(-1, "size is null");
        }
        int count = anrefids.size();
        for (int i = 0; i < count; i++) {
            if (anrefids.get(i).intValue() != 0 && anrNums.get(i).intValue() != 0) {
                this.mFileCount++;
                byte[] data = adn.buildAnrString(size[0], anrEfIndex.get(i).intValue(), this.mEf, adnNum, aasIndex);
                this.mFh.updateEFLinearFixed(anrefids.get(i).intValue(), anrNums.get(i).intValue(), data, pin2, obtainMessage(10));
            }
        }
        this.mPendingExtLoads = 1;
    }

    public void updateEFIapToUsim(UniAdnRecord adn, int iapEF, int adnNum, byte[] record, String pin2, Message response, int[] size) {
        byte[] data;
        this.mIapEF = iapEF;
        this.mAdnNum = adnNum;
        this.mIapRec = record;
        this.mUserResponse = response;
        this.mPin2 = pin2;
        if (record != null) {
            data = this.mIapRec;
        } else {
            if (size == null) {
                throw new UniIccPBForOperationException(-1, "size is null");
            }
            data = adn.buildIapString(size[0], 255);
        }
        if (data == null) {
            throw new UniIccPBForOperationException(-1, "wrong Iap format");
        }
        this.mFh.updateEFLinearFixed(iapEF, adnNum, data, pin2, obtainMessage(5));
        this.mPendingExtLoads = 1;
    }

    public void updateExtEF(UniAdnRecord adn, int ef, int extensionEF, int recordNumber, String pin2, Message response) {
        this.mEf = ef;
        this.mExtensionEF = extensionEF;
        this.mRecordNumber = recordNumber;
        this.mUserResponse = response;
        this.mPin2 = pin2;
        byte[] extData = adn.buildExtString();
        this.mPendingExtLoads = 1;
        this.mFh.updateEFLinearFixed(extensionEF, recordNumber, extData, pin2, obtainMessage(EVENT_UPDATE_EXT_RECORD_DONE, extensionEF, recordNumber, extData));
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.android.internal.telephony.phonebook.UniIccPBForOperationException */
    public void updateEFAdnToUsim(UniAdnRecord adn, int ef, int extensionEF, int recordNumber, String pin2, Message response, int[] size) throws UniIccPBForOperationException {
        logd("updateEFAdnToUsim recordNumber = " + recordNumber);
        this.mUserResponse = response;
        if (size == null) {
            throw new UniIccPBForOperationException(-1, "size is null");
        }
        try {
            byte[] data = adn.buildAdnString(size[0]);
            this.mFh.updateEFLinearFixed(ef, recordNumber, data, pin2, obtainMessage(5));
            this.mPendingExtLoads = 1;
        } catch (UniIccPBForOperationException e) {
            Message message = this.mUserResponse;
            if (message != null) {
                AsyncResult.forMessage(message).exception = e;
                this.mUserResponse.sendToTarget();
                this.mUserResponse = null;
            }
        }
    }

    public void updateEFGasToUsim(int gasEfId, int recordNum, byte[] data, String pin2) {
        this.mFh.updateEFLinearFixed(gasEfId, recordNum, data, pin2, obtainMessage(5));
    }

    public int[] getRecordsSize(int efid) {
        if (efid <= 0) {
            logd("the efid is invalid");
            return null;
        }
        synchronized (this.mLock) {
            this.mRecordSize = new int[3];
            AtomicBoolean status = new AtomicBoolean(false);
            Message response = obtainMessage(EVENT_GET_SIZE_DONE, status);
            this.mFh.getEFLinearRecordSize(efid, response);
            waitForResult(status);
        }
        return this.mRecordSize;
    }

    protected void waitForResult(AtomicBoolean status) {
        while (!status.get()) {
            try {
                this.mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to update by search");
            }
        }
    }

    private void notifyPending(AsyncResult ar) {
        if (ar.userObj == null) {
            return;
        }
        AtomicBoolean status = (AtomicBoolean) ar.userObj;
        status.set(true);
        this.mLock.notifyAll();
    }

    public void updateEFSneToUsim(UniAdnRecord adn, ArrayList<Integer> sneEfids, ArrayList<Integer> sneNums, int efid, int adnNum, ArrayList<Integer> sneEfIndex, String pin2, Message response) {
        this.sneEfids = sneEfids;
        this.sneNums = sneNums;
        this.mEf = efid;
        this.mAdnNum = adnNum;
        this.sneEfIndex = sneEfIndex;
        this.mUserResponse = response;
        this.mPin2 = pin2;
        this.mFh.getEFLinearRecordSize(sneEfids.get(0).intValue(), obtainMessage(9, adn));
    }

    private void logd(String msg) {
        Rlog.d(TAG, msg);
    }

    private void loge(String msg) {
        Rlog.e(TAG, msg);
    }

    private void logi(String msg) {
        Rlog.i(TAG, msg);
    }
}
