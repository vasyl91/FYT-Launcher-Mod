package com.android.internal.telephony;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.telephony.SubscriptionInfo;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import com.android.telephony.Rlog;
import com.android.unisoc.telephony.RadioInteractor;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniTeleUtils {
    private static final String ACTION_REPORT_ERRLOG = "com.sprd.intent.action.COMMLOG_REPORTED";
    private static final String LOG_TAG = "UniTeleUtils";
    private static final String PERMISSION_RECEIVE_ERRLOG = "com.android.permission.RECEIVE_SPRD_COMMLOG";
    private static final int SIM_EXCEPTION = 5;
    private static final int SIM_SETUP_EXCEPTION_EVENT_ID = 6;
    private static final int SIM_SETUP_EXCEPTION_SCENE_ID = 1537;

    public static String translateOperatorName(Context context, String numericPlmn, String oldName) {
        if (TextUtils.isEmpty(numericPlmn) || ("46697".equals(numericPlmn) && ("GT 4G R".equals(oldName) || "GT R".equals(oldName)))) {
            Log.d(LOG_TAG, " Not translated GT operator name");
            return oldName;
        }
        Log.d(LOG_TAG, " translateOperatorName: old name= " + oldName);
        Resources res = getResourcesForMccMnc(context, numericPlmn);
        boolean preferLocaleName = res.getBoolean(134414351);
        String localeName = res.getString(135004180);
        Log.d(LOG_TAG, "preferLocaleName = " + preferLocaleName);
        Log.d(LOG_TAG, "localeName = " + localeName);
        if (preferLocaleName && !TextUtils.isEmpty(localeName)) {
            return localeName;
        }
        Log.d(LOG_TAG, "translateOperatorName not found: numeric plmn = " + numericPlmn + " oldName = " + oldName);
        return oldName;
    }

    private static Resources getResourcesForMccMnc(Context context, String mccmnc) {
        Configuration config = context.getResources().getConfiguration();
        Configuration newConfig = new Configuration();
        newConfig.setTo(config);
        if (mccmnc.length() >= 4) {
            try {
                newConfig.mcc = Integer.parseInt(mccmnc.substring(0, 3));
                newConfig.mnc = Integer.parseInt(mccmnc.substring(3));
                if (newConfig.mnc == 0) {
                    newConfig.mnc = 65535;
                }
            } catch (NumberFormatException e) {
                Log.d(LOG_TAG, "getResourcesForMccMnc " + e);
            }
        }
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        DisplayMetrics newMetrics = new DisplayMetrics();
        newMetrics.setTo(metrics);
        return new Resources(context.getResources().getAssets(), newMetrics, newConfig);
    }

    public static void sendErrReport(Context context, int phoneId, int command, int efid, String path, int p1, int p2, int p3, String data, String pin, String aid, String exception) {
        RadioInteractor radiointeractor = new RadioInteractor(context);
        String cpInfo = radiointeractor.getExceptionEvents(6, SIM_SETUP_EXCEPTION_SCENE_ID, 0, 0, phoneId);
        try {
            Intent intent = new Intent(ACTION_REPORT_ERRLOG);
            intent.putExtra("FaultId", 6);
            intent.putExtra("SceneId", SIM_SETUP_EXCEPTION_SCENE_ID);
            try {
                intent.putExtra("SimIndex", phoneId);
                try {
                    intent.putExtra("Command", command);
                    try {
                        intent.putExtra("Efid", efid);
                        try {
                            intent.putExtra("Path", path);
                            try {
                                intent.putExtra("P1", p1);
                                try {
                                    intent.putExtra("P2", p2);
                                    try {
                                        intent.putExtra("P3", p3);
                                        try {
                                            intent.putExtra("Data", data);
                                            try {
                                                intent.putExtra("Pin", pin);
                                                try {
                                                    intent.putExtra("Aid", aid);
                                                    try {
                                                        intent.putExtra("Exception", exception);
                                                        intent.putExtra("CPInfo", cpInfo);
                                                        intent.addFlags(16777216);
                                                        context.sendBroadcast(intent);
                                                    } catch (Exception e) {
                                                        e = e;
                                                        Log.e(LOG_TAG, "sprd commlog sim sendErrReport", e);
                                                    }
                                                } catch (Exception e2) {
                                                    e = e2;
                                                    Log.e(LOG_TAG, "sprd commlog sim sendErrReport", e);
                                                }
                                            } catch (Exception e3) {
                                                e = e3;
                                                Log.e(LOG_TAG, "sprd commlog sim sendErrReport", e);
                                            }
                                        } catch (Exception e4) {
                                            e = e4;
                                            Log.e(LOG_TAG, "sprd commlog sim sendErrReport", e);
                                        }
                                    } catch (Exception e5) {
                                        e = e5;
                                        Log.e(LOG_TAG, "sprd commlog sim sendErrReport", e);
                                    }
                                } catch (Exception e6) {
                                    e = e6;
                                    Log.e(LOG_TAG, "sprd commlog sim sendErrReport", e);
                                }
                            } catch (Exception e7) {
                                e = e7;
                                Log.e(LOG_TAG, "sprd commlog sim sendErrReport", e);
                            }
                        } catch (Exception e8) {
                            e = e8;
                            Log.e(LOG_TAG, "sprd commlog sim sendErrReport", e);
                        }
                    } catch (Exception e9) {
                        e = e9;
                        Log.e(LOG_TAG, "sprd commlog sim sendErrReport", e);
                    }
                } catch (Exception e10) {
                    e = e10;
                    Log.e(LOG_TAG, "sprd commlog sim sendErrReport", e);
                }
            } catch (Exception e11) {
                e = e11;
                Log.e(LOG_TAG, "sprd commlog sim sendErrReport", e);
            }
        } catch (Exception e12) {
            e = e12;
        }
    }

    public static int getRegStateFromAidlRegState(int halRegState) {
        switch (halRegState) {
            case 0:
            case 10:
                return 0;
            case 1:
                return 1;
            case 2:
            case 12:
                return 2;
            case 3:
            case 13:
                return 3;
            case 4:
            case 14:
                return 4;
            case 5:
                return 5;
            case 6:
            case 7:
            case 8:
            case 9:
            case 11:
            default:
                return 0;
        }
    }

    public static boolean isEmergencyOnly(int halRegState) {
        switch (halRegState) {
            case 10:
            case 12:
            case 13:
            case 14:
                return true;
            case 11:
            default:
                return false;
        }
    }

    public static List<Integer> getAvailableServices(int regState, int domain, boolean emergencyOnly) {
        List<Integer> availableServices = new ArrayList<>();
        if (!emergencyOnly) {
            if (regState == 5 || regState == 1) {
                if (domain == 2) {
                    availableServices.add(2);
                } else if (domain == 1) {
                    availableServices.add(1);
                    availableServices.add(3);
                    availableServices.add(4);
                }
            }
        } else {
            availableServices.add(5);
        }
        return availableServices;
    }

    public static String getIccidForLogging(String iccid) {
        if (Rlog.isLoggable(LOG_TAG, 2)) {
            return iccid;
        }
        return SubscriptionInfo.givePrintableIccid(iccid);
    }
}
