package com.android.internal.telephony.data;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.provider.Settings;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.ArraySet;
import com.android.internal.telephony.GlobalSettingsHelper;
import com.android.internal.telephony.MultiSimSettingController;
import com.android.internal.telephony.Phone;
import com.android.telephony.Rlog;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniDataSettingsManager extends DataSettingsManager {
    private static final int DATA_KEEP_ALIVE_DURATION = 1800000;
    private static final int DATA_KEEP_ALIVE_DURATION_DEBUG = 120000;
    private static final String DEBUG_TEST = "persist.radio.alwaysonline.debug";
    private static final String INTENT_CLEANUP_DATA_ALARM = "com.sprd.telephony.data-cleanup";
    private static final int NATIONAL_ROAMING_TYPE_ALL_NETWORKS = 1;
    private static final int NATIONAL_ROAMING_TYPE_DISABLED = 0;
    private static final int NATIONAL_ROAMING_TYPE_NATIONAL_ROAMING_ONLY = 2;
    private boolean DEBUG;
    private final String LOG_TAG;
    private AlarmManager mAlarmManager;
    private boolean mAlwaysOnline;
    private boolean mCharging;
    private PendingIntent mCleaupAlarmIntent;
    private DataNetworkController mDataNetworkController;
    private boolean mDeepSleep;
    private final Handler mHandler;
    private boolean mIsScreenOn;
    private boolean mIsVendorDataEnabled;
    private MobileDataAlwaysOnlineObserver mMobileDataAlwaysOnlineObserver;
    private boolean mNetworkShared;
    private final SubscriptionManager.OnSubscriptionsChangedListener mOnSubscriptionsChangeListener;
    private Phone mPhone;
    private BroadcastReceiver mReceiver;
    private ContentResolver mResolver;
    private int mSubId;
    private SubscriptionManager mSubscriptionManager;
    private final Set<DataSettingsManager.DataSettingsManagerCallback> mUniDataSettingsManagerCallbacks;
    private final Map<Integer, Boolean> mVendorDataEnabledSettings;

    /* JADX WARN: Multi-variable type inference failed */
    public UniDataSettingsManager(Phone phone, DataNetworkController dataNetworkController, Looper looper, DataSettingsManager.DataSettingsManagerCallback callback) {
        super(phone, dataNetworkController, looper, callback);
        this.mCleaupAlarmIntent = null;
        ArrayMap arrayMap = new ArrayMap();
        this.mVendorDataEnabledSettings = arrayMap;
        this.mUniDataSettingsManagerCallbacks = new ArraySet();
        this.mDeepSleep = false;
        this.mAlwaysOnline = true;
        this.mIsScreenOn = true;
        this.mCharging = false;
        this.mNetworkShared = false;
        this.DEBUG = SystemProperties.getBoolean(DEBUG_TEST, false);
        SubscriptionManager.OnSubscriptionsChangedListener onSubscriptionsChangedListener = new SubscriptionManager.OnSubscriptionsChangedListener() { // from class: com.android.internal.telephony.data.UniDataSettingsManager.1
            @Override // android.telephony.SubscriptionManager.OnSubscriptionsChangedListener
            public void onSubscriptionsChanged() {
                int subId = UniDataSettingsManager.this.mPhone.getSubId();
                if (SubscriptionManager.isValidSubscriptionId(subId) && UniDataSettingsManager.this.mSubId != subId) {
                    UniDataSettingsManager uniDataSettingsManager = UniDataSettingsManager.this;
                    uniDataSettingsManager.mAlwaysOnline = GlobalSettingsHelper.getInt(uniDataSettingsManager.mPhone.getContext(), "mobile_data_always_online", subId, 1) == 1;
                    if (UniDataSettingsManager.this.mMobileDataAlwaysOnlineObserver != null) {
                        UniDataSettingsManager.this.mMobileDataAlwaysOnlineObserver.unregister();
                    }
                    UniDataSettingsManager uniDataSettingsManager2 = UniDataSettingsManager.this;
                    UniDataSettingsManager uniDataSettingsManager3 = UniDataSettingsManager.this;
                    uniDataSettingsManager2.mMobileDataAlwaysOnlineObserver = uniDataSettingsManager3.new MobileDataAlwaysOnlineObserver(uniDataSettingsManager3.mPhone.getContext(), UniDataSettingsManager.this.mHandler);
                    UniDataSettingsManager.this.mMobileDataAlwaysOnlineObserver.register(subId);
                    UniDataSettingsManager.this.mSubId = subId;
                }
            }
        };
        this.mOnSubscriptionsChangeListener = onSubscriptionsChangedListener;
        this.mReceiver = new BroadcastReceiver() { // from class: com.android.internal.telephony.data.UniDataSettingsManager.2
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                UniDataSettingsManager.this.log("onReceive action = " + action);
                if (TextUtils.equals(action, "android.intent.action.SCREEN_ON")) {
                    UniDataSettingsManager.this.onScreenOn();
                    return;
                }
                if (TextUtils.equals(action, "android.intent.action.SCREEN_OFF")) {
                    UniDataSettingsManager.this.onScreenOff();
                    return;
                }
                if (TextUtils.equals(action, "android.net.conn.TETHER_STATE_CHANGED")) {
                    ArrayList<String> tetheredIf = intent.getStringArrayListExtra("tetherArray");
                    UniDataSettingsManager.this.onNetworkShared((tetheredIf == null || tetheredIf.isEmpty()) ? false : true);
                } else if (TextUtils.equals(action, "android.intent.action.BATTERY_CHANGED")) {
                    boolean charging = intent.getIntExtra("plugged", 0) != 0;
                    UniDataSettingsManager.this.onBatteryChanged(charging);
                } else if (TextUtils.equals(action, UniDataSettingsManager.INTENT_CLEANUP_DATA_ALARM)) {
                    UniDataSettingsManager.this.onActionIntentCleanupData();
                }
            }
        };
        this.mPhone = phone;
        this.LOG_TAG = "Uni-DSMGR-" + this.mPhone.getPhoneId();
        this.mDataNetworkController = dataNetworkController;
        this.mHandler = this;
        registerUniDataSettingsManagerCallback(callback);
        arrayMap.put(5, true);
        this.mSubscriptionManager = (SubscriptionManager) this.mPhone.getContext().getSystemService("telephony_subscription_service");
        this.mResolver = this.mPhone.getContext().getContentResolver();
        this.mSubscriptionManager.addOnSubscriptionsChangedListener(onSubscriptionsChangedListener);
        this.mAlarmManager = (AlarmManager) this.mPhone.getContext().getSystemService("alarm");
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.SCREEN_ON");
        filter.addAction("android.intent.action.SCREEN_OFF");
        filter.addAction("android.net.conn.TETHER_STATE_CHANGED");
        filter.addAction("android.intent.action.BATTERY_CHANGED");
        filter.addAction(INTENT_CLEANUP_DATA_ALARM);
        this.mPhone.getContext().registerReceiver(this.mReceiver, filter, null, this.mPhone);
        log("UniDataSettingsManager created.");
    }

    public void handleMessage(Message msg) {
        super.handleMessage(msg);
    }

    public boolean isDataEnabled(int apnType) {
        boolean isDataEnabled = super.isDataEnabled(apnType);
        boolean zBooleanValue = this.mVendorDataEnabledSettings.get(5).booleanValue();
        this.mIsVendorDataEnabled = zBooleanValue;
        return isDataEnabled && zBooleanValue;
    }

    public void setVendorDataEnabled(boolean enabled) {
        if (this.mVendorDataEnabledSettings.get(5).booleanValue() != enabled) {
            log("VendorDataEnabled changed to " + enabled);
            this.mVendorDataEnabledSettings.put(5, Boolean.valueOf(enabled));
            updateDataEnabledAndNotify(5);
        }
    }

    public class MobileDataAlwaysOnlineObserver extends ContentObserver {
        public MobileDataAlwaysOnlineObserver(Context context, Handler handler) {
            super(null);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange) {
            boolean alwaysOnline = GlobalSettingsHelper.getInt(UniDataSettingsManager.this.mPhone.getContext(), "mobile_data_always_online", UniDataSettingsManager.this.mPhone.getSubId(), 1) == 1;
            UniDataSettingsManager.this.log("onChange: alwaysOnline = " + alwaysOnline);
            if (UniDataSettingsManager.this.mAlwaysOnline != alwaysOnline) {
                if (alwaysOnline) {
                    UniDataSettingsManager.this.cancelAlarmForDeepSleep();
                    if (UniDataSettingsManager.this.mDeepSleep) {
                        UniDataSettingsManager.this.mDeepSleep = false;
                    }
                } else if (!UniDataSettingsManager.this.mIsScreenOn && !UniDataSettingsManager.this.mCharging) {
                    UniDataSettingsManager.this.startAlarmForDeepSleep();
                }
                UniDataSettingsManager.this.mAlwaysOnline = alwaysOnline;
            }
        }

        public void register(int subId) {
            if (TelephonyManager.getDefault().getSimCount() == 1) {
                UniDataSettingsManager.this.mResolver.registerContentObserver(Settings.Global.getUriFor("mobile_data_always_online"), true, this);
            } else {
                UniDataSettingsManager.this.mResolver.registerContentObserver(Settings.Global.getUriFor("mobile_data_always_online" + subId), true, this);
            }
        }

        public void unregister() {
            UniDataSettingsManager.this.mResolver.unregisterContentObserver(this);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startAlarmForDeepSleep() {
        Intent intent = new Intent(INTENT_CLEANUP_DATA_ALARM);
        this.mCleaupAlarmIntent = PendingIntent.getBroadcast(this.mPhone.getContext(), 0, intent, 201326592);
        int delay = getDataKeepAliveDuration(this.DEBUG ? DATA_KEEP_ALIVE_DURATION_DEBUG : DATA_KEEP_ALIVE_DURATION);
        log("startAlarmForDeepSleep delay=" + delay);
        this.mAlarmManager.setExact(2, SystemClock.elapsedRealtime() + ((long) delay), this.mCleaupAlarmIntent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void cancelAlarmForDeepSleep() {
        if (this.mCleaupAlarmIntent != null) {
            log("cancelAlarmForDeepSleep");
            this.mAlarmManager.cancel(this.mCleaupAlarmIntent);
            this.mCleaupAlarmIntent = null;
        }
    }

    private int getDataKeepAliveDuration(int defValue) {
        int delayTime = defValue;
        String delay = SubscriptionManager.getResourcesForSubId(this.mPhone.getContext(), this.mPhone.getSubId()).getString(135004215);
        if (!TextUtils.isEmpty(delay)) {
            delayTime = Integer.parseInt(delay);
        }
        log("delay " + delayTime + " before tearing down data");
        return delayTime;
    }

    private void cleanUpDataForDeepSleep() {
        if (!this.mNetworkShared && !this.mCharging) {
            cleanupData();
            this.mDeepSleep = true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onScreenOn() {
        this.mIsScreenOn = true;
        cancelAlarmForDeepSleep();
        if (this.mDeepSleep) {
            this.mDeepSleep = false;
            setupData();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onScreenOff() {
        this.mIsScreenOn = false;
        if (!this.mAlwaysOnline && !this.mCharging) {
            startAlarmForDeepSleep();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onBatteryChanged(boolean charging) {
        if (charging != this.mCharging) {
            this.mCharging = charging;
            if (charging) {
                cancelAlarmForDeepSleep();
            } else if (!this.mIsScreenOn && !this.mAlwaysOnline) {
                startAlarmForDeepSleep();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onNetworkShared(boolean shared) {
        this.mNetworkShared = shared;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onActionIntentCleanupData() {
        cleanUpDataForDeepSleep();
    }

    private void setupData() {
        setVendorDataEnabled(true);
    }

    private void cleanupData() {
        setVendorDataEnabled(false);
    }

    public boolean getDeepSleepState() {
        return this.mDeepSleep;
    }

    public boolean isDataRoamingEnabled() {
        boolean z;
        boolean zIsDefaultDataRoamingEnabled = isDefaultDataRoamingEnabled();
        if (this.mPhone.getContext().getResources().getBoolean(134414378)) {
            int i = GlobalSettingsHelper.getInt(this.mPhone.getContext(), "data_roaming", this.mSubId, zIsDefaultDataRoamingEnabled ? 1 : 0);
            switch (i) {
                case 1:
                    z = true;
                    break;
                case 2:
                    z = true;
                    if (this.mPhone.getServiceState().getDataRoamingType() != 2) {
                        z = false;
                    }
                    break;
                default:
                    z = false;
                    break;
            }
            log("dataRoaming = " + i + " ,isDataRoamingEnabled = " + z);
            return z;
        }
        return super.isDataRoamingEnabled();
    }

    public void setDataRoamingEnabled(final boolean enabled) {
        if (this.mPhone.getContext().getResources().getBoolean(134414378)) {
            if (!enabled) {
                GlobalSettingsHelper.setInt(this.mPhone.getContext(), "data_roaming", this.mSubId, 0);
            }
            MultiSimSettingController.getInstance().notifyRoamingDataEnabled(this.mSubId, enabled);
            this.mUniDataSettingsManagerCallbacks.forEach(new Consumer() { // from class: com.android.internal.telephony.data.UniDataSettingsManager$$ExternalSyntheticLambda1
                @Override // java.util.function.Consumer
                public final void accept(Object obj) {
                    DataSettingsManager.DataSettingsManagerCallback dataSettingsManagerCallback = (DataSettingsManager.DataSettingsManagerCallback) obj;
                    dataSettingsManagerCallback.invokeFromExecutor(new Runnable() { // from class: com.android.internal.telephony.data.UniDataSettingsManager$$ExternalSyntheticLambda0
                        @Override // java.lang.Runnable
                        public final void run() {
                            dataSettingsManagerCallback.onDataRoamingEnabledChanged(z);
                        }
                    });
                }
            });
            return;
        }
        super.setDataRoamingEnabled(enabled);
    }

    private void registerUniDataSettingsManagerCallback(DataSettingsManager.DataSettingsManagerCallback callback) {
        this.mUniDataSettingsManagerCallbacks.add(callback);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(String s) {
        Rlog.d(this.LOG_TAG, s);
    }
}
