package com.android.internal.telephony;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PersistableBundle;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.ServiceManager;
import android.os.UserHandle;
import android.preference.PreferenceManager;
import android.service.carrier.CarrierIdentifier;
import android.service.carrier.ICarrierService;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.telephony.UniCarrierConfigManager;
import android.text.TextUtils;
import android.util.LocalLog;
import android.util.Log;
import com.android.internal.util.ArrayUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniCarrierConfigLoader extends IUniCarrierConfigLoader.Stub {
    private static final int BIND_TIMEOUT_MILLIS = 30000;
    private static final int EVENT_BIND_DEFAULT_TIMEOUT = 10;
    private static final int EVENT_BIND_FEATUR_CONFIG_TIMEOUT = 27;
    private static final int EVENT_CHECK_SYSTEM_UPDATE = 12;
    private static final int EVENT_CLEAR_CONFIG = 0;
    private static final int EVENT_CONNECTED_TO_CARRIER = 4;
    private static final int EVENT_CONNECTED_TO_DEFAULT = 3;
    private static final int EVENT_CONNECTED_TO_DEFAULT_FOR_FEATURE_CONFIG = 24;
    private static final int EVENT_DO_FETCH_DEFAULT = 7;
    private static final int EVENT_DO_FETCH_DEFAULT_FOR_FEATURE_CONFIG = 23;
    private static final int EVENT_FETCH_DEFAULT_DONE = 5;
    private static final int EVENT_FETCH_DEFAULT_FOR_FEATURE_CONFIG_DONE = 25;
    private static final int EVENT_FETCH_DEFAULT_FOR_FEATURE_CONFIG_TIMEOUT = 26;
    private static final int EVENT_FETCH_DEFAULT_TIMEOUT = 14;
    private static final int EVENT_MULTI_SIM_CONFIG_CHANGED = 17;
    private static final int EVENT_PACKAGE_CHANGED = 9;
    private static final int EVENT_SUBSCRIPTION_INFO_UPDATED = 16;
    private static final int EVENT_SYSTEM_UNLOCKED = 13;
    private static final int FEATURE_PHONE_ID = -100;
    private static final String KEY_FINGERPRINT = "build_fingerprint";
    private static final String KEY_VERSION = "__carrier_config_package_version__";
    private static final String LOG_TAG = "UniCarrierConfigLoader";
    private static final String OVERRIDE_PACKAGE_ADDITION = "-override";
    private static final String SUB_PACKAGE_ADDITION = "-sub";
    private static final String VENDOR_PACKAGE_ADDITION = "-vendor";
    private static UniCarrierConfigLoader sInstance;
    private final BroadcastReceiver mBootReceiver;
    private PersistableBundle[] mConfigFromDefaultApp;
    private Context mContext;
    private boolean mDeviceShuttingDown = false;
    private PersistableBundle mFeatureConfigFromDefaultApp;
    private boolean mFeatureServiceBound;
    private CarrierServiceConnection mFeatureServiceConnection;
    private final Handler mHandler;
    private boolean mHasFeatureSentConfigChanged;
    private boolean[] mHasSentConfigChange;
    private PersistableBundle[] mOverrideConfigs;
    private final BroadcastReceiver mPackageReceiver;
    private PersistableBundle[] mPersistentOverrideConfigs;
    private final String mPlatformCarrierConfigPackage;
    private boolean[] mServiceBound;
    private CarrierServiceConnection[] mServiceConnection;
    private final LocalLog mUniCarrierConfigLoadingLog;

    private class ConfigHandler extends Handler {
        private ConfigHandler() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            final int phoneId = msg.arg1;
            UniCarrierConfigLoader.this.logdWithLocalLog("mHandler: " + msg.what + " phoneId: " + phoneId);
            if (!SubscriptionManager.isValidPhoneId(phoneId) && msg.what != 17 && msg.what != UniCarrierConfigLoader.EVENT_DO_FETCH_DEFAULT_FOR_FEATURE_CONFIG && msg.what != UniCarrierConfigLoader.EVENT_CONNECTED_TO_DEFAULT_FOR_FEATURE_CONFIG && msg.what != UniCarrierConfigLoader.EVENT_FETCH_DEFAULT_FOR_FEATURE_CONFIG_DONE && msg.what != UniCarrierConfigLoader.EVENT_FETCH_DEFAULT_FOR_FEATURE_CONFIG_TIMEOUT && msg.what != UniCarrierConfigLoader.EVENT_BIND_FEATUR_CONFIG_TIMEOUT) {
            }
            switch (msg.what) {
                case 0:
                    UniCarrierConfigLoader.this.clearConfigForPhone(phoneId, true);
                    break;
                case 3:
                    removeMessages(10);
                    final CarrierServiceConnection conn = (CarrierServiceConnection) msg.obj;
                    if (UniCarrierConfigLoader.this.mServiceConnection[phoneId] != conn || conn.service == null) {
                        UniCarrierConfigLoader uniCarrierConfigLoader = UniCarrierConfigLoader.this;
                        uniCarrierConfigLoader.unbindIfBound(uniCarrierConfigLoader.mContext, conn, phoneId);
                    } else {
                        final CarrierIdentifier carrierId = UniCarrierConfigLoader.this.getCarrierIdentifierForPhoneId(phoneId);
                        ResultReceiver resultReceiver = new ResultReceiver(this) { // from class: com.android.internal.telephony.UniCarrierConfigLoader.ConfigHandler.1
                            @Override // android.os.ResultReceiver
                            public void onReceiveResult(int resultCode, Bundle resultData) {
                                UniCarrierConfigLoader.this.unbindIfBound(UniCarrierConfigLoader.this.mContext, conn, phoneId);
                                if (UniCarrierConfigLoader.this.mServiceConnection[phoneId] != conn) {
                                    UniCarrierConfigLoader.this.loge("Received response for stale request.");
                                    return;
                                }
                                ConfigHandler.this.removeMessages(14);
                                if (resultCode == 1 || resultData == null) {
                                    UniCarrierConfigLoader.this.loge("Failed to get carrier config");
                                    UniCarrierConfigLoader.this.broadcastConfigChangedIntent(phoneId);
                                    return;
                                }
                                PersistableBundle config = (PersistableBundle) resultData.getParcelable("config_bundle");
                                UniCarrierConfigLoader.this.saveConfigToXml(UniCarrierConfigLoader.this.mPlatformCarrierConfigPackage, UniCarrierConfigLoader.SUB_PACKAGE_ADDITION, phoneId, carrierId, config);
                                PersistableBundle[] persistableBundleArr = UniCarrierConfigLoader.this.mConfigFromDefaultApp;
                                int i = phoneId;
                                persistableBundleArr[i] = config;
                                ConfigHandler configHandler = ConfigHandler.this;
                                configHandler.sendMessage(configHandler.obtainMessage(5, i, -1));
                            }
                        };
                        try {
                            ICarrierService carrierService = ICarrierService.Stub.asInterface(conn.service);
                            carrierService.getCarrierConfig(phoneId, carrierId, resultReceiver);
                            UniCarrierConfigLoader.this.logdWithLocalLog("Fetch config for default app: " + UniCarrierConfigLoader.this.mPlatformCarrierConfigPackage + " carrierid: " + carrierId.toString());
                            sendMessageDelayed(obtainMessage(14, phoneId, -1), 30000L);
                        } catch (RemoteException e) {
                            UniCarrierConfigLoader.this.loge("Failed to get carrier config from default app: " + UniCarrierConfigLoader.this.mPlatformCarrierConfigPackage + " err: " + e.toString());
                            UniCarrierConfigLoader uniCarrierConfigLoader2 = UniCarrierConfigLoader.this;
                            uniCarrierConfigLoader2.unbindIfBound(uniCarrierConfigLoader2.mContext, conn, phoneId);
                            return;
                        }
                    }
                    break;
                case 5:
                    if (msg.getData().getBoolean("loaded_from_xml", false) || UniCarrierConfigLoader.this.mServiceConnection[phoneId] != null) {
                        UniCarrierConfigLoader.this.broadcastConfigChangedIntent(phoneId);
                    }
                    break;
                case 7:
                    UniCarrierConfigLoader uniCarrierConfigLoader3 = UniCarrierConfigLoader.this;
                    PersistableBundle config = uniCarrierConfigLoader3.restoreConfigFromXml(uniCarrierConfigLoader3.mPlatformCarrierConfigPackage, UniCarrierConfigLoader.OVERRIDE_PACKAGE_ADDITION, phoneId);
                    if (config != null) {
                        UniCarrierConfigLoader.this.log("Loaded persistent override config from XML. package=" + UniCarrierConfigLoader.this.mPlatformCarrierConfigPackage + " phoneId=" + phoneId);
                        UniCarrierConfigLoader.this.mPersistentOverrideConfigs[phoneId] = config;
                    }
                    if (SubscriptionManager.getSimStateForSlotIndex(phoneId) != 10) {
                        UniCarrierConfigLoader.this.log(" SIM card not loaded");
                    } else {
                        UniCarrierConfigLoader uniCarrierConfigLoader4 = UniCarrierConfigLoader.this;
                        PersistableBundle config2 = uniCarrierConfigLoader4.restoreConfigFromXml(uniCarrierConfigLoader4.mPlatformCarrierConfigPackage, UniCarrierConfigLoader.SUB_PACKAGE_ADDITION, phoneId);
                        if (config2 != null) {
                            UniCarrierConfigLoader.this.log("Loaded config from XML. package=" + UniCarrierConfigLoader.this.mPlatformCarrierConfigPackage + " phoneId=" + phoneId);
                            UniCarrierConfigLoader.this.mConfigFromDefaultApp[phoneId] = config2;
                            Message newMsg = obtainMessage(5, phoneId, -1);
                            newMsg.getData().putBoolean("loaded_from_xml", true);
                            UniCarrierConfigLoader.this.mHandler.sendMessage(newMsg);
                        } else {
                            UniCarrierConfigLoader uniCarrierConfigLoader5 = UniCarrierConfigLoader.this;
                            if (uniCarrierConfigLoader5.bindToConfigPackage(uniCarrierConfigLoader5.mPlatformCarrierConfigPackage, phoneId, 3)) {
                                sendMessageDelayed(obtainMessage(10, phoneId, -1), 30000L);
                            } else {
                                UniCarrierConfigLoader.this.broadcastConfigChangedIntent(phoneId);
                                UniCarrierConfigLoader.this.loge("binding to default app: " + UniCarrierConfigLoader.this.mPlatformCarrierConfigPackage + " fails");
                            }
                        }
                    }
                    break;
                case 9:
                    String carrierPackageName = (String) msg.obj;
                    if (UniCarrierConfigLoader.this.clearCachedConfigForPackage(carrierPackageName)) {
                        int numPhones = TelephonyManager.from(UniCarrierConfigLoader.this.mContext).getActiveModemCount();
                        for (int i = 0; i < numPhones; i++) {
                            UniCarrierConfigLoader.this.logdWithLocalLog("Package changed: " + carrierPackageName + ", phone=" + i);
                            UniCarrierConfigLoader.this.updateConfigForPhoneId(i);
                        }
                    }
                    break;
                case 10:
                case 14:
                    UniCarrierConfigLoader.this.loge("Bind/fetch time out from " + UniCarrierConfigLoader.this.mPlatformCarrierConfigPackage);
                    removeMessages(14);
                    if (UniCarrierConfigLoader.this.mServiceConnection[phoneId] != null) {
                        UniCarrierConfigLoader uniCarrierConfigLoader6 = UniCarrierConfigLoader.this;
                        uniCarrierConfigLoader6.unbindIfBound(uniCarrierConfigLoader6.mContext, UniCarrierConfigLoader.this.mServiceConnection[phoneId], phoneId);
                        UniCarrierConfigLoader.this.broadcastConfigChangedIntent(phoneId);
                    }
                    UniCarrierConfigLoader.this.broadcastConfigChangedIntent(phoneId);
                    break;
                case 12:
                    SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(UniCarrierConfigLoader.this.mContext);
                    String lastFingerprint = sharedPrefs.getString(UniCarrierConfigLoader.KEY_FINGERPRINT, null);
                    if (!Build.FINGERPRINT.equals(lastFingerprint)) {
                        UniCarrierConfigLoader.this.log("Build fingerprint changed. old: " + lastFingerprint + " new: " + Build.FINGERPRINT);
                        UniCarrierConfigLoader.this.clearCachedConfigForPackage(null);
                        sharedPrefs.edit().putString(UniCarrierConfigLoader.KEY_FINGERPRINT, Build.FINGERPRINT).apply();
                    }
                    break;
                case 13:
                    for (int i2 = 0; i2 < TelephonyManager.from(UniCarrierConfigLoader.this.mContext).getActiveModemCount(); i2++) {
                        if (UniCarrierConfigLoader.this.mHasSentConfigChange[i2]) {
                            UniCarrierConfigLoader.this.logdWithLocalLog("System unlocked");
                            UniCarrierConfigLoader.this.updateConfigForPhoneId(i2);
                        }
                    }
                    if (UniCarrierConfigLoader.this.mHasFeatureSentConfigChanged) {
                        UniCarrierConfigLoader.this.updateFeatureConfigs();
                    }
                    break;
                case 16:
                    UniCarrierConfigLoader.this.broadcastConfigChangedIntent(phoneId);
                    break;
                case 17:
                    UniCarrierConfigLoader.this.onMultiSimConfigChanged();
                    break;
                case UniCarrierConfigLoader.EVENT_DO_FETCH_DEFAULT_FOR_FEATURE_CONFIG /* 23 */:
                    UniCarrierConfigLoader.this.fetchDefaultConfig(msg);
                    break;
                case UniCarrierConfigLoader.EVENT_CONNECTED_TO_DEFAULT_FOR_FEATURE_CONFIG /* 24 */:
                    UniCarrierConfigLoader.this.connectToDefaultApp(msg);
                    break;
                case UniCarrierConfigLoader.EVENT_FETCH_DEFAULT_FOR_FEATURE_CONFIG_DONE /* 25 */:
                    if (msg.getData().getBoolean("loaded_from_xml", false) || UniCarrierConfigLoader.this.mFeatureServiceConnection != null) {
                        UniCarrierConfigLoader.this.broadcastConfigChangedIntent(phoneId, false);
                    }
                    break;
                case UniCarrierConfigLoader.EVENT_FETCH_DEFAULT_FOR_FEATURE_CONFIG_TIMEOUT /* 26 */:
                    UniCarrierConfigLoader.this.mContext.unbindService(UniCarrierConfigLoader.this.mFeatureServiceConnection);
                    removeMessages(UniCarrierConfigLoader.EVENT_FETCH_DEFAULT_FOR_FEATURE_CONFIG_TIMEOUT);
                    UniCarrierConfigLoader.this.broadcastConfigChangedIntent(phoneId, false);
                    break;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private UniCarrierConfigLoader(Context context) {
        ConfigLoaderBroadcastReceiver configLoaderBroadcastReceiver = new ConfigLoaderBroadcastReceiver();
        this.mBootReceiver = configLoaderBroadcastReceiver;
        ConfigLoaderBroadcastReceiver configLoaderBroadcastReceiver2 = new ConfigLoaderBroadcastReceiver();
        this.mPackageReceiver = configLoaderBroadcastReceiver2;
        this.mUniCarrierConfigLoadingLog = new LocalLog(100);
        this.mContext = context;
        this.mPlatformCarrierConfigPackage = context.getString(135004255);
        ConfigHandler configHandler = new ConfigHandler();
        this.mHandler = configHandler;
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.BOOT_COMPLETED");
        intentFilter.addAction("android.intent.action.ACTION_SHUTDOWN");
        intentFilter.addAction("android.intent.action.SIM_STATE_CHANGED");
        intentFilter.addAction("android.telephony.action.MULTI_SIM_CONFIG_CHANGED");
        context.registerReceiver(configLoaderBroadcastReceiver, intentFilter);
        IntentFilter intentFilter2 = new IntentFilter();
        intentFilter2.addAction("android.intent.action.PACKAGE_ADDED");
        intentFilter2.addAction("android.intent.action.PACKAGE_REMOVED");
        intentFilter2.addAction("android.intent.action.PACKAGE_REPLACED");
        intentFilter2.addDataScheme("package");
        context.registerReceiver(configLoaderBroadcastReceiver2, intentFilter2);
        int supportedModemCount = TelephonyManager.from(context).getSupportedModemCount();
        this.mConfigFromDefaultApp = new PersistableBundle[supportedModemCount];
        this.mOverrideConfigs = new PersistableBundle[supportedModemCount];
        this.mServiceConnection = new CarrierServiceConnection[supportedModemCount];
        this.mPersistentOverrideConfigs = new PersistableBundle[supportedModemCount];
        this.mHasSentConfigChange = new boolean[supportedModemCount];
        this.mServiceBound = new boolean[supportedModemCount];
        ServiceManager.addService("uni_carrierconfig", this);
        updateFeatureConfigs();
        log("UniCarrierConfigLoader has started");
        configHandler.sendEmptyMessage(12);
    }

    static UniCarrierConfigLoader init(Context context) {
        UniCarrierConfigLoader uniCarrierConfigLoader;
        synchronized (UniCarrierConfigLoader.class) {
            if (sInstance == null) {
                sInstance = new UniCarrierConfigLoader(context);
            } else {
                Log.wtf(LOG_TAG, "init() called multiple times!  sInstance = " + sInstance);
            }
            uniCarrierConfigLoader = sInstance;
        }
        return uniCarrierConfigLoader;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void broadcastConfigChangedIntent(int phoneId) {
        broadcastConfigChangedIntent(phoneId, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void broadcastConfigChangedIntent(int phoneId, boolean addSubIdExtra) {
        Intent intent = new Intent("android.telephony.action.UNI_CARRIER_CONFIG_CHANGED");
        intent.addFlags(335544320);
        int simCardState = 0;
        int simApplicationState = 0;
        int[] subIds = SubscriptionManager.getSubId(phoneId);
        if (!ArrayUtils.isEmpty(subIds)) {
            TelephonyManager telMgr = TelephonyManager.from(this.mContext).createForSubscriptionId(subIds[0]);
            simApplicationState = telMgr.getSimApplicationState();
            simCardState = telMgr.getSimCardState();
        }
        if (addSubIdExtra && simApplicationState != 0 && simApplicationState != 6) {
            SubscriptionManager.putPhoneIdAndSubIdExtra(intent, phoneId);
            intent.putExtra("android.telephony.extra.SPECIFIC_CARRIER_ID", getSpecificCarrierIdForPhoneId(phoneId));
            intent.putExtra("android.telephony.extra.CARRIER_ID", getCarrierIdForPhoneId(phoneId));
        }
        if (phoneId == FEATURE_PHONE_ID) {
            intent.putExtra("carrier_changed_type", UniCarrierConfigManager.CONFIG_FEATURE);
        } else {
            intent.putExtra("carrier_changed_type", UniCarrierConfigManager.CONFIG_SUBINFO);
        }
        intent.putExtra("android.telephony.extra.SLOT_INDEX", phoneId);
        this.mContext.sendBroadcastAsUser(intent, UserHandle.ALL);
        if (subIds == null || subIds.length <= 0) {
            log("Broadcast UNI_CARRIER_CONFIG_CHANGED for phone " + phoneId);
        } else {
            log("Broadcast UNI_CARRIER_CONFIG_CHANGED for phone " + phoneId + ", subId=" + subIds[0]);
        }
        if (phoneId == FEATURE_PHONE_ID) {
            this.mHasFeatureSentConfigChanged = true;
        } else if (simApplicationState == 10 || simCardState == 1) {
            this.mHasSentConfigChange[phoneId] = true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean bindToConfigPackage(String pkgName, int phoneId, int eventId) {
        logdWithLocalLog("Binding to " + pkgName + " for phone " + phoneId);
        Intent carrierService = new Intent("android.service.carrier.CarrierService");
        carrierService.setPackage(pkgName);
        this.mServiceConnection[phoneId] = new CarrierServiceConnection(phoneId, pkgName, eventId);
        try {
            if (!this.mContext.bindService(carrierService, this.mServiceConnection[phoneId], 1)) {
                return false;
            }
            this.mServiceBound[phoneId] = true;
            return true;
        } catch (SecurityException e) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateConfigForPhoneId(int phoneId, String simState) {
        this.mContext.enforceCallingOrSelfPermission("android.permission.MODIFY_PHONE_STATE", null);
        log("update config for phoneId: " + phoneId + " simState: " + simState);
        if (!SubscriptionManager.isValidPhoneId(phoneId)) {
        }
        switch (simState) {
            case "ABSENT":
            case "CARD_IO_ERROR":
            case "CARD_RESTRICTED":
            case "UNKNOWN":
            case "NOT_READY":
                Handler handler = this.mHandler;
                handler.sendMessage(handler.obtainMessage(0, phoneId, -1));
                break;
            case "LOADED":
                updateConfigForPhoneId(phoneId);
                break;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public CarrierIdentifier getCarrierIdentifierForPhoneId(int phoneId) {
        String mcc;
        String mnc;
        String imsi;
        String gid1;
        String gid2;
        String spn = TelephonyManager.from(this.mContext).getSimOperatorNameForPhone(phoneId);
        int carrierId = getCarrierIdForPhoneId(phoneId);
        int specificCarrierId = getSpecificCarrierIdForPhoneId(phoneId);
        String simOperator = TelephonyManager.from(this.mContext).getSimOperatorNumericForPhone(phoneId);
        if (simOperator == null || simOperator.length() < 3) {
            mcc = "";
            mnc = "";
        } else {
            String mcc2 = simOperator.substring(0, 3);
            String mnc2 = simOperator.substring(3);
            mcc = mcc2;
            mnc = mnc2;
        }
        Phone phone = PhoneFactory.getPhone(phoneId);
        if (phone == null) {
            imsi = "";
            gid1 = "";
            gid2 = "";
        } else {
            String imsi2 = phone.getSubscriberId();
            String gid3 = phone.getGroupIdLevel1();
            String gid4 = phone.getGroupIdLevel2();
            imsi = imsi2;
            gid1 = gid3;
            gid2 = gid4;
        }
        return new CarrierIdentifier(mcc, mnc, spn, imsi, gid1, gid2, carrierId, specificCarrierId);
    }

    private int getSubId(int phoneId) {
        int[] subIds = SubscriptionManager.getSubId(phoneId);
        if (subIds == null) {
            return -1;
        }
        int subId = subIds[0];
        return subId;
    }

    private String getCarrierPackageForPhoneId(int phoneId) {
        List<String> carrierPackageNames = TelephonyManager.from(this.mContext).getCarrierPackageNamesForIntentAndPhone(new Intent("android.service.carrier.CarrierService"), phoneId);
        if (carrierPackageNames != null && carrierPackageNames.size() > 0) {
            return carrierPackageNames.get(0);
        }
        return null;
    }

    private String getIccIdForPhoneId(int phoneId) {
        if (!SubscriptionManager.isValidPhoneId(phoneId)) {
            return "";
        }
        SubscriptionManager subscriptionManager = SubscriptionManager.from(this.mContext);
        SubscriptionInfo subInfo = subscriptionManager.getActiveSubscriptionInfo(getSubId(phoneId));
        return subInfo == null ? "" : subInfo.getIccId();
    }

    private int getSpecificCarrierIdForPhoneId(int phoneId) {
        int subId = getSubId(phoneId);
        if (!SubscriptionManager.isValidSubscriptionId(subId)) {
            return -1;
        }
        TelephonyManager telephonyManager = new TelephonyManager(this.mContext, subId);
        return telephonyManager.getSimSpecificCarrierId();
    }

    private int getCarrierIdForPhoneId(int phoneId) {
        int subId = getSubId(phoneId);
        if (!SubscriptionManager.isValidSubscriptionId(subId)) {
            return -1;
        }
        TelephonyManager telephonyManager = new TelephonyManager(this.mContext, subId);
        return telephonyManager.getSimCarrierId();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void saveConfigToXml(String packageName, String extraString, int phoneId, CarrierIdentifier carrierId, PersistableBundle config) {
        if (SubscriptionManager.getSimStateForSlotIndex(phoneId) != 10 && TextUtils.equals(extraString, SUB_PACKAGE_ADDITION)) {
            loge("Skip save config because SIM records are not loaded.");
            return;
        }
        String iccid = getIccIdForPhoneId(phoneId);
        int cid = getSpecificCarrierIdForPhoneId(phoneId);
        if (packageName == null || (iccid == null && TextUtils.equals(extraString, SUB_PACKAGE_ADDITION))) {
            loge("Cannot save config with null packageName or iccid.");
            return;
        }
        if (config == null || config.isEmpty()) {
            return;
        }
        String version = getPackageVersion(packageName);
        if (version == null) {
            loge("Failed to get package version for: " + packageName);
            return;
        }
        logdWithLocalLog("Save config to xml, packagename: " + packageName + " phoneId: " + phoneId);
        try {
            FileOutputStream outFile = new FileOutputStream(new File(this.mContext.getFilesDir(), getFilenameForConfig(packageName, extraString, iccid, cid)));
            config.putString(KEY_VERSION, version);
            config.writeToStream(outFile);
            outFile.flush();
            outFile.close();
        } catch (IOException e) {
            loge(e.toString());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public PersistableBundle restoreConfigFromXml(String packageName, String extraString, int phoneId) {
        String version = getPackageVersion(packageName);
        if (version == null) {
            loge("Failed to get package version for: " + packageName);
            return null;
        }
        if (SubscriptionManager.getSimStateForSlotIndex(phoneId) != 10 && TextUtils.equals(extraString, SUB_PACKAGE_ADDITION)) {
            loge("Skip restoring config because SIM records are not yet loaded.");
            return null;
        }
        String iccid = getIccIdForPhoneId(phoneId);
        int cid = getSpecificCarrierIdForPhoneId(phoneId);
        if (packageName == null || (iccid == null && TextUtils.equals(extraString, SUB_PACKAGE_ADDITION))) {
            loge("Cannot restore config with null packageName or iccid.");
            return null;
        }
        PersistableBundle restoredBundle = null;
        File file = null;
        try {
            file = new File(this.mContext.getFilesDir(), getFilenameForConfig(packageName, extraString, iccid, cid));
            FileInputStream inFile = new FileInputStream(file);
            restoredBundle = PersistableBundle.readFromStream(inFile);
            String savedVersion = restoredBundle.getString(KEY_VERSION);
            restoredBundle.remove(KEY_VERSION);
            if (!version.equals(savedVersion)) {
                loge("Saved version mismatch: " + version + " vs " + savedVersion);
                restoredBundle = null;
            }
            inFile.close();
        } catch (FileNotFoundException e) {
            if (file != null) {
                log("File not found: " + file.getPath());
            }
        } catch (IOException e2) {
            loge(e2.toString());
        }
        return restoredBundle;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean clearCachedConfigForPackage(final String packageName) {
        File dir = this.mContext.getFilesDir();
        File[] packageFiles = dir.listFiles(new FilenameFilter() { // from class: com.android.internal.telephony.UniCarrierConfigLoader.1
            @Override // java.io.FilenameFilter
            public boolean accept(File dir2, String filename) {
                if (packageName != null) {
                    return filename.startsWith("carrierconfig-" + packageName + "-");
                }
                return filename.startsWith("carrierconfig-");
            }
        });
        if (packageFiles == null || packageFiles.length < 1) {
            return false;
        }
        for (File f : packageFiles) {
            log("Deleting " + f.getName());
            f.delete();
        }
        return true;
    }

    private String getFilenameForConfig(String packageName, String extraString, String iccid, int cid) {
        return "carrierconfig-" + packageName + extraString + "-" + iccid + "-" + cid + ".xml";
    }

    private String getPackageVersion(String packageName) {
        try {
            PackageInfo info = this.mContext.getPackageManager().getPackageInfo(packageName, 0);
            return Long.toString(info.getLongVersionCode());
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateConfigForPhoneId(int phoneId) {
        Handler handler = this.mHandler;
        handler.sendMessage(handler.obtainMessage(7, phoneId, -1));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onMultiSimConfigChanged() {
        for (int i = TelephonyManager.from(this.mContext).getActiveModemCount(); i < this.mConfigFromDefaultApp.length; i++) {
            clearConfigForPhone(i, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void clearConfigForPhone(int phoneId, boolean sendBroadcast) {
        if (this.mDeviceShuttingDown) {
            return;
        }
        this.mConfigFromDefaultApp[phoneId] = null;
        this.mServiceConnection[phoneId] = null;
        this.mHasSentConfigChange[phoneId] = false;
        if (sendBroadcast) {
            broadcastConfigChangedIntent(phoneId, false);
        }
    }

    public PersistableBundle getConfigForSubId(int subId, String callingPackage) {
        return getConfigForSubIdWithFeature(subId, callingPackage, null);
    }

    public PersistableBundle getConfigForSubIdWithFeature(int subId, String callingPackage, String callingFeatureId) {
        if (!TelephonyPermissions.checkCallingOrSelfReadPhoneState(this.mContext, subId, callingPackage, callingFeatureId, "getCarrierConfig")) {
            return new PersistableBundle();
        }
        int phoneId = SubscriptionManager.getPhoneId(subId);
        if (subId == Integer.MAX_VALUE) {
            phoneId = 0;
        }
        PersistableBundle retConfig = UniCarrierConfigManager.getDefaultConfig();
        if (SubscriptionManager.isValidPhoneId(phoneId)) {
            PersistableBundle config = this.mConfigFromDefaultApp[phoneId];
            if (config != null) {
                retConfig.putAll(config);
                retConfig.putBoolean("carrier_config_applied_bool", true);
            }
            PersistableBundle config2 = this.mFeatureConfigFromDefaultApp;
            if (config2 != null) {
                retConfig.putBoolean("carrier_config_applied_bool", true);
                retConfig.putAll(config2);
            }
            PersistableBundle config3 = this.mPersistentOverrideConfigs[phoneId];
            if (config3 != null) {
                retConfig.putAll(config3);
                retConfig.putBoolean("carrier_config_applied_bool", true);
            }
            PersistableBundle config4 = this.mOverrideConfigs[phoneId];
            if (config4 != null) {
                retConfig.putAll(config4);
                retConfig.putBoolean("carrier_config_applied_bool", true);
            }
        }
        return retConfig;
    }

    public void overrideConfig(int subscriptionId, PersistableBundle overrides, boolean persistent) {
        this.mContext.enforceCallingOrSelfPermission("android.permission.MODIFY_PHONE_STATE", null);
        int phoneId = SubscriptionManager.getPhoneId(subscriptionId);
        if (!SubscriptionManager.isValidPhoneId(phoneId)) {
            log("Ignore invalid phoneId: " + phoneId + " for subId: " + subscriptionId);
            return;
        }
        overrideConfig(this.mOverrideConfigs, phoneId, overrides);
        if (persistent) {
            overrideConfig(this.mPersistentOverrideConfigs, phoneId, overrides);
            if (overrides != null) {
                CarrierIdentifier carrierId = getCarrierIdentifierForPhoneId(phoneId);
                saveConfigToXml(this.mPlatformCarrierConfigPackage, OVERRIDE_PACKAGE_ADDITION, phoneId, carrierId, this.mPersistentOverrideConfigs[phoneId]);
            } else {
                String iccid = getIccIdForPhoneId(phoneId);
                int cid = getSpecificCarrierIdForPhoneId(phoneId);
                String fileName = getFilenameForConfig(this.mPlatformCarrierConfigPackage, OVERRIDE_PACKAGE_ADDITION, iccid, cid);
                File fileToDelete = new File(this.mContext.getFilesDir(), fileName);
                fileToDelete.delete();
            }
        }
        broadcastConfigChangedIntent(phoneId);
    }

    private void overrideConfig(PersistableBundle[] currentOverrides, int phoneId, PersistableBundle overrides) {
        if (overrides == null) {
            currentOverrides[phoneId] = new PersistableBundle();
        } else if (currentOverrides[phoneId] == null) {
            currentOverrides[phoneId] = overrides;
        } else {
            currentOverrides[phoneId].putAll(overrides);
        }
        broadcastConfigChangedIntent(phoneId);
    }

    private class CarrierServiceConnection implements ServiceConnection {
        final int eventId;
        final int phoneId;
        final String pkgName;
        IBinder service;

        CarrierServiceConnection(int phoneId, String pkgName, int eventId) {
            this.phoneId = phoneId;
            this.pkgName = pkgName;
            this.eventId = eventId;
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName name, IBinder service) {
            UniCarrierConfigLoader.this.log("Connected to config app: " + name.flattenToShortString());
            this.service = service;
            UniCarrierConfigLoader.this.mHandler.sendMessage(UniCarrierConfigLoader.this.mHandler.obtainMessage(this.eventId, this.phoneId, -1, this));
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName name) {
            UniCarrierConfigLoader.this.log("Disconnected from config app: " + name.flattenToShortString());
            this.service = null;
        }

        @Override // android.content.ServiceConnection
        public void onBindingDied(ComponentName name) {
            UniCarrierConfigLoader.this.log("Binding died from config app: " + name.flattenToShortString());
            this.service = null;
        }

        @Override // android.content.ServiceConnection
        public void onNullBinding(ComponentName name) {
            UniCarrierConfigLoader.this.log("Null binding from config app: " + name.flattenToShortString());
            this.service = null;
        }
    }

    private class ConfigLoaderBroadcastReceiver extends BroadcastReceiver {
        private ConfigLoaderBroadcastReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.intent.action.SIM_STATE_CHANGED".equals(action)) {
                int slotId = intent.getIntExtra("phone", -1);
                String simStatus = intent.getStringExtra("ss");
                UniCarrierConfigLoader.this.updateConfigForPhoneId(slotId, simStatus);
                return;
            }
            if ("android.telephony.action.MULTI_SIM_CONFIG_CHANGED".equals(action)) {
                UniCarrierConfigLoader.this.mHandler.sendMessage(UniCarrierConfigLoader.this.mHandler.obtainMessage(17, null));
                return;
            }
            byte b = 0;
            boolean replace = intent.getBooleanExtra("android.intent.extra.REPLACING", false);
            if (!replace || "android.intent.action.PACKAGE_REPLACED".equals(action)) {
                switch (action.hashCode()) {
                    case -810471698:
                        b = !action.equals("android.intent.action.PACKAGE_REPLACED") ? (byte) -1 : (byte) 4;
                        break;
                    case 525384130:
                        b = !action.equals("android.intent.action.PACKAGE_REMOVED") ? (byte) -1 : (byte) 3;
                        break;
                    case 798292259:
                        if (!action.equals("android.intent.action.BOOT_COMPLETED")) {
                            b = -1;
                        }
                        break;
                    case 1544582882:
                        b = !action.equals("android.intent.action.PACKAGE_ADDED") ? (byte) -1 : (byte) 2;
                        break;
                    case 1947666138:
                        b = !action.equals("android.intent.action.ACTION_SHUTDOWN") ? (byte) -1 : (byte) 1;
                        break;
                    default:
                        b = -1;
                        break;
                }
                switch (b) {
                    case 0:
                        UniCarrierConfigLoader.this.mHandler.sendMessage(UniCarrierConfigLoader.this.mHandler.obtainMessage(13, null));
                        break;
                    case 1:
                        UniCarrierConfigLoader.this.mDeviceShuttingDown = true;
                        break;
                    case 2:
                    case 3:
                    case 4:
                        int uid = intent.getIntExtra("android.intent.extra.UID", -1);
                        String packageName = UniCarrierConfigLoader.this.mContext.getPackageManager().getNameForUid(uid);
                        if (packageName != null) {
                            UniCarrierConfigLoader.this.mHandler.sendMessage(UniCarrierConfigLoader.this.mHandler.obtainMessage(9, packageName));
                        }
                        break;
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(String msg) {
        Log.d(LOG_TAG, msg);
    }

    private void log(String msg, Throwable tr) {
        Log.d(LOG_TAG, msg, tr);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void logdWithLocalLog(String msg) {
        Log.d(LOG_TAG, msg);
        this.mUniCarrierConfigLoadingLog.log(msg);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loge(String msg) {
        Log.e(LOG_TAG, msg);
        this.mUniCarrierConfigLoadingLog.log(msg);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateFeatureConfigs() {
        log("update feature configs");
        this.mContext.enforceCallingOrSelfPermission("android.permission.MODIFY_PHONE_STATE", null);
        Handler handler = this.mHandler;
        handler.sendMessage(handler.obtainMessage(EVENT_DO_FETCH_DEFAULT_FOR_FEATURE_CONFIG, FEATURE_PHONE_ID, -1));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fetchDefaultConfig(Message msg) {
        log("Loaded config carrier feature");
        int phoneId = msg.arg1;
        PersistableBundle config = restoreConfigFromXml(this.mPlatformCarrierConfigPackage, VENDOR_PACKAGE_ADDITION, FEATURE_PHONE_ID);
        if (config != null) {
            log("Loaded config from XML[" + msg.what + "]. package=" + this.mPlatformCarrierConfigPackage + " phoneId=" + phoneId);
            this.mFeatureConfigFromDefaultApp = config;
            Message newMsg = this.mHandler.obtainMessage(EVENT_FETCH_DEFAULT_FOR_FEATURE_CONFIG_DONE, phoneId, -1);
            newMsg.getData().putBoolean("loaded_from_xml", true);
            this.mHandler.sendMessage(newMsg);
            return;
        }
        if (bindToConfigPackageForFeature(this.mPlatformCarrierConfigPackage, phoneId, EVENT_CONNECTED_TO_DEFAULT_FOR_FEATURE_CONFIG)) {
            Handler handler = this.mHandler;
            handler.sendMessageDelayed(handler.obtainMessage(EVENT_BIND_FEATUR_CONFIG_TIMEOUT, phoneId, -1), 30000L);
        } else {
            broadcastConfigChangedIntent(phoneId, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void connectToDefaultApp(Message msg) {
        this.mHandler.removeMessages(EVENT_BIND_FEATUR_CONFIG_TIMEOUT);
        final int phoneId = msg.arg1;
        final CarrierServiceConnection conn = (CarrierServiceConnection) msg.obj;
        if (this.mFeatureServiceConnection != conn || conn.service == null) {
            unbindIfBound(this.mContext, conn);
            return;
        }
        final CarrierIdentifier carrierIdentifier = getCarrierIdentifierForPhoneId(-1);
        ResultReceiver resultReceiver = new ResultReceiver(this.mHandler) { // from class: com.android.internal.telephony.UniCarrierConfigLoader.2
            @Override // android.os.ResultReceiver
            public void onReceiveResult(int resultCode, Bundle resultData) {
                UniCarrierConfigLoader.this.log("feature carrier config onbind");
                UniCarrierConfigLoader uniCarrierConfigLoader = UniCarrierConfigLoader.this;
                uniCarrierConfigLoader.unbindIfBound(uniCarrierConfigLoader.mContext, conn);
                UniCarrierConfigLoader.this.mHandler.removeMessages(UniCarrierConfigLoader.EVENT_FETCH_DEFAULT_FOR_FEATURE_CONFIG_TIMEOUT);
                if (UniCarrierConfigLoader.this.mFeatureServiceConnection != conn) {
                    UniCarrierConfigLoader.this.loge("Received response for stale request.");
                    return;
                }
                if (resultCode == 1 || resultData == null) {
                    UniCarrierConfigLoader.this.log("Failed to get carrier config");
                    UniCarrierConfigLoader.this.broadcastConfigChangedIntent(phoneId, false);
                    return;
                }
                PersistableBundle config = (PersistableBundle) resultData.getParcelable("config_bundle");
                UniCarrierConfigLoader uniCarrierConfigLoader2 = UniCarrierConfigLoader.this;
                uniCarrierConfigLoader2.saveConfigToXml(uniCarrierConfigLoader2.mPlatformCarrierConfigPackage, UniCarrierConfigLoader.VENDOR_PACKAGE_ADDITION, UniCarrierConfigLoader.FEATURE_PHONE_ID, carrierIdentifier, config);
                UniCarrierConfigLoader.this.mFeatureConfigFromDefaultApp = config;
                UniCarrierConfigLoader.this.mHandler.sendMessage(UniCarrierConfigLoader.this.mHandler.obtainMessage(UniCarrierConfigLoader.EVENT_FETCH_DEFAULT_FOR_FEATURE_CONFIG_DONE, phoneId, -1));
            }
        };
        try {
            ICarrierService carrierService = ICarrierService.Stub.asInterface(conn.service);
            carrierService.getCarrierConfig(phoneId, carrierIdentifier, resultReceiver);
            Handler handler = this.mHandler;
            handler.sendMessageDelayed(handler.obtainMessage(EVENT_FETCH_DEFAULT_FOR_FEATURE_CONFIG_TIMEOUT, phoneId, -1), 30000L);
        } catch (RemoteException e) {
            unbindIfBound(this.mContext, conn);
        }
    }

    private boolean bindToConfigPackageForFeature(String pkgName, int phoneId, int eventId) {
        logdWithLocalLog("Binding to " + pkgName + " for phone " + phoneId);
        Intent carrierService = new Intent("android.service.carrier.CarrierService");
        carrierService.setPackage(pkgName);
        CarrierServiceConnection carrierServiceConnection = new CarrierServiceConnection(phoneId, pkgName, eventId);
        this.mFeatureServiceConnection = carrierServiceConnection;
        try {
            if (!this.mContext.bindService(carrierService, carrierServiceConnection, 1)) {
                return false;
            }
            this.mFeatureServiceBound = true;
            return true;
        } catch (SecurityException e) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void unbindIfBound(Context context, CarrierServiceConnection conn, int phoneId) {
        boolean[] zArr = this.mServiceBound;
        if (zArr[phoneId]) {
            zArr[phoneId] = false;
            context.unbindService(conn);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void unbindIfBound(Context context, CarrierServiceConnection conn) {
        if (this.mFeatureServiceBound) {
            this.mFeatureServiceBound = false;
            context.unbindService(conn);
        }
    }
}
