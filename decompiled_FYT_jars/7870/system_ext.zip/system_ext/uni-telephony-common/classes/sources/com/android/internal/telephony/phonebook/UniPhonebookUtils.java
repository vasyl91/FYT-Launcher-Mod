package com.android.internal.telephony.phonebook;

import android.content.res.Resources;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniPhonebookUtils {
    private static final String TAG = "UniPhonebookUtils";

    public static int bytesToInt(byte[] data) {
        if (data == null) {
            return -1;
        }
        int value = 0;
        for (int i = 0; i < data.length; i++) {
            value |= (data[i] & 255) << (((data.length - i) - 1) * 8);
        }
        return value;
    }

    public static byte[] intToBytes(int value, int len) {
        byte[] data = new byte[len];
        for (int i = 0; i < len; i++) {
            data[i] = (byte) ((value >> (((len - i) - 1) * 8)) & 255);
        }
        return data;
    }

    public static boolean isSupportOrange() {
        boolean isSupportOrange = Resources.getSystem().getBoolean(134414363);
        return isSupportOrange;
    }

    private static void logd(String msg) {
        UniPhoneBookLog.d(TAG, msg);
    }
}
