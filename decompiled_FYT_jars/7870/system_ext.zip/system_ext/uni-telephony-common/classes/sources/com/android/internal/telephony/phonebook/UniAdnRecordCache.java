package com.android.internal.telephony.phonebook;

import android.content.res.Resources;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.SparseArray;
import com.android.internal.telephony.EncodeException;
import com.android.internal.telephony.UniGsmAlphabet;
import com.android.internal.telephony.uicc.IccFileHandler;
import com.android.internal.telephony.uicc.UniAdnRecordLoader;
import com.android.internal.telephony.uicc.UniIccConstants;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniAdnRecordCache extends Handler implements UniIccConstants {
    static final int EVENT_LOAD_ALL_ADN_LIKE_DONE = 1;
    static final int EVENT_LOAD_ALL_EXT_LIKE_DONE = 6;
    static final int EVENT_UPDATE_ADN_DONE = 2;
    static final int EVENT_UPDATE_ANR_DONE = 5;
    static final int EVENT_UPDATE_CYCLIC_DONE = 4;
    static final int EVENT_UPDATE_EXT_DONE = 7;
    static final int EVENT_UPDATE_SNE_DONE = 8;
    static final int EVENT_UPDATE_USIM_ADN_DONE = 3;
    private static String TAG = "UniAdnRecordCache";
    public IccFileHandler mFh;
    private UniUsimPhoneBookManager mUniUsimPhoneBookManager;
    public boolean mAlreadyReset = false;
    public int mInsertId = -1;
    SparseArray<Message> mUserWriteResponse = new SparseArray<>();
    SparseArray<ArrayList<Message>> mAdnLikeWaiters = new SparseArray<>();
    SparseArray<ArrayList<UniAdnRecord>> mAdnLikeFiles = new SparseArray<>();
    SparseArray<ArrayList<byte[]>> mExtLikeFiles = new SparseArray<>();

    public UniAdnRecordCache(IccFileHandler fh) {
        this.mFh = fh;
        this.mUniUsimPhoneBookManager = new UniUsimPhoneBookManager(this.mFh, this);
    }

    public void reset() {
        logd("reset adnLikeFiles");
        this.mAlreadyReset = true;
        this.mExtLikeFiles.clear();
        this.mAdnLikeFiles.clear();
        this.mUniUsimPhoneBookManager.reset();
        clearWaiters();
        clearUserWriters();
    }

    public void resetWithFileUpdate() {
        logd("reset adnLikeFiles FileUpdate");
        this.mExtLikeFiles.clear();
        this.mAdnLikeFiles.clear();
        this.mUniUsimPhoneBookManager.reset();
        clearWaiters();
        clearUserWriters();
    }

    private void clearWaiters() {
        int size = this.mAdnLikeWaiters.size();
        for (int i = 0; i < size; i++) {
            ArrayList<Message> waiters = this.mAdnLikeWaiters.valueAt(i);
            AsyncResult ar = new AsyncResult((Object) null, (Object) null, new RuntimeException("AdnCache reset"));
            notifyWaiters(waiters, ar);
        }
        this.mAdnLikeWaiters.clear();
    }

    private void clearUserWriters() {
        int size = this.mUserWriteResponse.size();
        for (int i = 0; i < size; i++) {
            sendErrorResponse(this.mUserWriteResponse.valueAt(i), "AdnCace reset");
        }
        this.mUserWriteResponse.clear();
    }

    public ArrayList<UniAdnRecord> getRecordsIfLoadedEx(int efid) {
        return this.mAdnLikeFiles.get(efid);
    }

    public int extensionEfForEf(int efid) {
        switch (efid) {
            case 20272:
                return 0;
            case 28474:
            case UniIccConstants.EF_LND /* 28484 */:
                return 28490;
            case 28475:
                return 28491;
            case 28480:
                return 28490;
            case 28489:
                return 28492;
            case 28615:
                return 28616;
            default:
                return -1;
        }
    }

    private void sendErrorResponse(Message response, int errCode, String errString) {
        if (response != null) {
            AsyncResult.forMessage(response).exception = new UniIccPBForOperationException(errCode, errString);
            response.sendToTarget();
        }
    }

    private void sendErrorResponse(Message response, String errString) {
        if (response != null) {
            Exception e = new RuntimeException(errString);
            AsyncResult.forMessage(response).exception = e;
            response.sendToTarget();
        }
    }

    public void updateAdnByIndexEx(int efid, UniAdnRecord newAdn, int recordIndex, String pin2, Message response) {
        int i;
        byte extIndex;
        int extensionEF = extensionEfForEf(efid);
        if (extensionEF < 0) {
            sendErrorResponse(response, -1, "EF is not known ADN-like EF:0x" + Integer.toHexString(efid).toUpperCase());
            return;
        }
        Message pendingResponse = this.mUserWriteResponse.get(efid);
        if (pendingResponse != null) {
            sendErrorResponse(response, -1, "Have pending update for EF:0x" + Integer.toHexString(efid).toUpperCase());
            return;
        }
        this.mInsertId = recordIndex;
        ArrayList<UniAdnRecord> oldAdnList = getRecordsIfLoadedEx(efid);
        if (oldAdnList == null) {
            sendErrorResponse(response, -1, "Adn list not exist for EF:0x" + Integer.toHexString(efid).toUpperCase());
            return;
        }
        this.mUserWriteResponse.put(efid, response);
        UniAdnRecord oldAdn = oldAdnList.get(recordIndex - 1);
        logd("oldAdn extRecord = " + oldAdn.mExtRecord);
        if (newAdn.extRecordIsNeeded()) {
            if (oldAdn.mExtRecord != 255) {
                byte extIndex2 = (byte) oldAdn.mExtRecord;
                extIndex = extIndex2;
            } else {
                byte extIndex3 = getAvailableExtIndex(extensionEF, efid);
                extIndex = extIndex3;
            }
            logd("extIndex = " + ((int) extIndex));
            if (extIndex == -1) {
                logd("ext list full");
                this.mUserWriteResponse.delete(efid);
                sendErrorResponse(response, -5, "ext list full");
                return;
            } else {
                newAdn.mExtRecord = extIndex;
                i = 255;
                new UniAdnRecordLoader(this.mFh).updateExtEF(newAdn, efid, extensionEF, extIndex, pin2, obtainMessage(7, extensionEF, extIndex));
            }
        } else {
            i = 255;
            if (oldAdn.mExtRecord != 255) {
                logd("need to clear extRecord = " + oldAdn.mExtRecord);
                new UniAdnRecordLoader(this.mFh).updateExtEF(newAdn, efid, extensionEF, oldAdn.mExtRecord, pin2, obtainMessage(7, extensionEF, oldAdn.mExtRecord));
            }
        }
        oldAdn.mExtRecord = i;
        new UniAdnRecordLoader(this.mFh).updateEF(newAdn, efid, extensionEF, recordIndex, pin2, obtainMessage(2, efid, recordIndex, newAdn));
    }

    public void updateAdnBySearchEx(int efid, UniAdnRecord oldAdn, UniAdnRecord newAdn, String pin2, Message response) {
        int index;
        int i;
        byte extIndex;
        int extensionEF = extensionEfForEf(efid);
        if (extensionEF < 0) {
            sendErrorResponse(response, -1, "EF is not known ADN-like EF:0x" + Integer.toHexString(efid).toUpperCase());
            return;
        }
        ArrayList<UniAdnRecord> oldAdnList = getRecordsIfLoadedEx(efid);
        if (oldAdnList == null) {
            sendErrorResponse(response, -1, "Adn list not exist for EF:0x" + Integer.toHexString(efid).toUpperCase());
            return;
        }
        Iterator<UniAdnRecord> it = oldAdnList.iterator();
        int count = 1;
        while (true) {
            if (!it.hasNext()) {
                index = -1;
                break;
            } else {
                if (oldAdn.isEqual(it.next())) {
                    int index2 = count;
                    this.mInsertId = index2;
                    index = index2;
                    break;
                }
                count++;
            }
        }
        if (index == -1) {
            sendErrorResponse(response, -3, "Adn record don't exist for " + oldAdn);
            return;
        }
        Message pendingResponse = this.mUserWriteResponse.get(efid);
        if (pendingResponse != null) {
            sendErrorResponse(response, -1, "Have pending update for EF:0x" + Integer.toHexString(efid).toUpperCase());
            return;
        }
        this.mUserWriteResponse.put(efid, response);
        oldAdn.mExtRecord = oldAdnList.get(index - 1).mExtRecord;
        logd("oldAdn extRecord = " + oldAdn.mExtRecord);
        if (newAdn.extRecordIsNeeded()) {
            if (oldAdn.mExtRecord != 255) {
                byte extIndex2 = (byte) oldAdn.mExtRecord;
                extIndex = extIndex2;
            } else {
                byte extIndex3 = getAvailableExtIndex(extensionEF, efid);
                extIndex = extIndex3;
            }
            logd("extIndex = " + ((int) extIndex));
            if (extIndex == -1) {
                logd("ext list full");
                this.mUserWriteResponse.delete(efid);
                sendErrorResponse(response, -5, "ext list full");
                return;
            } else {
                newAdn.mExtRecord = extIndex;
                i = 255;
                new UniAdnRecordLoader(this.mFh).updateExtEF(newAdn, efid, extensionEF, extIndex, pin2, obtainMessage(7, extensionEF, extIndex));
            }
        } else {
            i = 255;
            if (oldAdn.mExtRecord != 255) {
                logd("need to clear extRecord " + oldAdn.mExtRecord);
                new UniAdnRecordLoader(this.mFh).updateExtEF(newAdn, efid, extensionEF, oldAdn.mExtRecord, pin2, obtainMessage(7, extensionEF, oldAdn.mExtRecord));
            }
        }
        oldAdn.mExtRecord = i;
        new UniAdnRecordLoader(this.mFh).updateEF(newAdn, efid, extensionEF, index, pin2, obtainMessage(2, efid, index, newAdn));
    }

    public void requestLoadAllAdnLike(int efid, int extensionEf, Message response) {
        ArrayList<UniAdnRecord> result;
        if (this.mAlreadyReset) {
            if (response != null) {
                AsyncResult.forMessage(response).result = null;
                response.sendToTarget();
            }
            logd("Have already reset");
            return;
        }
        if (efid == 20272) {
            result = this.mUniUsimPhoneBookManager.loadEfFilesFromUsimEx();
        } else {
            result = getRecordsIfLoadedEx(efid);
            if (result != null && result.size() == 0) {
                result = null;
            }
        }
        if (efid == 20272 && result == null) {
            efid = 28474;
            extensionEf = extensionEfForEf(28474);
            logd("pbr is empty,read adn");
            result = getRecordsIfLoadedEx(28474);
            if (result != null && result.size() == 0) {
                result = null;
            }
        }
        if (result != null) {
            if (response != null) {
                AsyncResult.forMessage(response).result = result;
                response.sendToTarget();
            }
            logd("Have already loaded ef: " + efid);
            return;
        }
        ArrayList<Message> waiters = this.mAdnLikeWaiters.get(efid);
        if (waiters != null) {
            waiters.add(response);
            logd("Already started loading this efid: " + efid);
            return;
        }
        ArrayList<Message> waiters2 = new ArrayList<>();
        waiters2.add(response);
        this.mAdnLikeWaiters.put(efid, waiters2);
        if (extensionEf < 0) {
            if (response != null) {
                AsyncResult.forMessage(response).exception = new RuntimeException("EF is not known ADN-like EF:0x" + Integer.toHexString(efid).toUpperCase());
                response.sendToTarget();
            }
            logi("extensionEf < 0");
            return;
        }
        logi("requestLoadAllAdnLike efid:0x" + Integer.toHexString(efid).toUpperCase());
        new UniAdnRecordLoader(this.mFh).loadAllExtFromEF(efid, extensionEf, obtainMessage(6, efid, extensionEf));
    }

    private void notifyWaiters(ArrayList<Message> waiters, AsyncResult ar) {
        if (waiters == null) {
            return;
        }
        int s = waiters.size();
        for (int i = 0; i < s; i++) {
            Message waiter = waiters.get(i);
            AsyncResult.forMessage(waiter, ar.result, ar.exception);
            waiter.sendToTarget();
        }
    }

    private int[] getRecordsSizeByEf(int efId) {
        if (this.mUniUsimPhoneBookManager.getRecordsSize() != null && this.mUniUsimPhoneBookManager.getRecordsSize().containsKey(Integer.valueOf(efId))) {
            int[] size = this.mUniUsimPhoneBookManager.getRecordsSize().get(Integer.valueOf(efId));
            return size;
        }
        int[] size2 = this.mUniUsimPhoneBookManager.readFileSizeAndWait(efId);
        return size2;
    }

    private boolean isCleanRecord(int num, int type, UniAdnRecord oldAdn, UniAdnRecord newAdn, int index) {
        String str1;
        String str2;
        String aas1;
        String aas2;
        UniAdnRecordCache uniAdnRecordCache = this;
        String[] strArr1 = uniAdnRecordCache.getSubjectString(type, oldAdn);
        String[] strArr2 = uniAdnRecordCache.getSubjectString(type, newAdn);
        String[] aasArr1 = uniAdnRecordCache.getSubjectAasString(type, oldAdn);
        String[] aasArr2 = uniAdnRecordCache.getSubjectAasString(type, newAdn);
        int oldCount = strArr1 != null ? strArr1.length : 0;
        int newCount = strArr2 != null ? strArr2.length : 0;
        uniAdnRecordCache.logd("isCleanRecord oldCount = " + oldCount + ", newCount = " + newCount);
        int[] efids = uniAdnRecordCache.mUniUsimPhoneBookManager.getSubjectEfids(type, num);
        if (efids == null) {
            return false;
        }
        int count = efids.length;
        uniAdnRecordCache.logd("isCleanRecord count = " + count);
        int i = 0;
        while (i < count) {
            if (i < oldCount && strArr1[i] != null) {
                str1 = strArr1[i];
            } else {
                str1 = "";
            }
            if (i < newCount && strArr2[i] != null) {
                str2 = strArr2[i];
            } else {
                str2 = "";
            }
            if (i < oldCount && aasArr1 != null && i < aasArr1.length && aasArr1[i] != null) {
                aas1 = aasArr1[i];
            } else {
                aas1 = "";
            }
            if (i < newCount && aasArr2 != null && i < aasArr2.length && aasArr2[i] != null) {
                aas2 = aasArr2[i];
            } else {
                aas2 = "";
            }
            int oldCount2 = oldCount;
            uniAdnRecordCache.logd("isCleanRecord: aas1 = " + aas1 + ", aas2 = " + aas2);
            if (index != i || ((str1.trim().equals(str2.trim()) && aas1.trim().equals(aas2.trim())) || !TextUtils.isEmpty(str2))) {
                i++;
                uniAdnRecordCache = this;
                oldCount = oldCount2;
            } else {
                return true;
            }
        }
        return false;
    }

    public ArrayList<String> loadGasFromUsim() {
        if (this.mAlreadyReset) {
            return null;
        }
        return this.mUniUsimPhoneBookManager.loadGasFromUsim();
    }

    public void removedRecordsIfLoaded(int efid) {
        this.mAdnLikeFiles.remove(efid);
    }

    private boolean compareSubject(int type, UniAdnRecord oldAdn, UniAdnRecord newAdn) {
        switch (type) {
            case 0:
                boolean isEqual = oldAdn.stringCompareEmails(oldAdn.mEmails, newAdn.mEmails);
                return isEqual;
            case 1:
                logd("USIM_SUBJCET_ANR oldAdn.aas == " + oldAdn.mAas + ", newAdn.aas == " + newAdn.mAas);
                boolean isEqual2 = oldAdn.stringCompareAnr(oldAdn.mAnr, newAdn.mAnr) && oldAdn.stringCompareAnr(oldAdn.mAas, newAdn.mAas);
                return isEqual2;
            case 2:
                logd("oldAdn.mGrp == " + oldAdn.mGrp + ", newAdn.mGrp == " + newAdn.mGrp);
                boolean isEqual3 = oldAdn.stringCompareAnr(oldAdn.mGrp, newAdn.mGrp);
                return isEqual3;
            case 3:
                logd("oldAdn.aas == " + oldAdn.mAas + ", newAdn.aas == " + newAdn.mAas);
                boolean isEqual4 = oldAdn.stringCompareAnr(oldAdn.mAas, newAdn.mAas);
                return isEqual4;
            case 4:
                logd("oldAdn.mSne == " + oldAdn.mSne + ", newAdn.mSne == " + newAdn.mSne);
                boolean isEqual5 = oldAdn.stringCompareAnr(oldAdn.mSne, newAdn.mSne);
                return isEqual5;
            default:
                return true;
        }
    }

    private String[] getAnrNumGroup(String anr) {
        logd("getAnrNumGroup anr = " + anr);
        if (TextUtils.isEmpty(anr)) {
            return null;
        }
        String[] pair = anr.split(";");
        return pair;
    }

    private String[] getSubjectString(int type, UniAdnRecord adn) {
        switch (type) {
            case 0:
                String[] s1 = adn.mEmails;
                return s1;
            case 1:
                String[] s2 = getAnrNumGroup(adn.mAnr);
                return s2;
            case 2:
            default:
                return null;
            case 3:
                String[] s3 = {adn.mAas};
                return s3;
            case 4:
                String[] s4 = {adn.mSne};
                return s4;
        }
    }

    private int[] getUpdateSubjectFlag(int num, int type, UniAdnRecord oldAdn, UniAdnRecord newAdn, int[] efids) {
        int newCount = 0;
        if (efids == null) {
            return null;
        }
        String[] strArr1 = getSubjectString(type, oldAdn);
        String[] strArr2 = getSubjectString(type, newAdn);
        String[] aasArr1 = getSubjectAasString(type, oldAdn);
        String[] aasArr2 = getSubjectAasString(type, newAdn);
        int oldCount = strArr1 != null ? strArr1.length : 0;
        if (strArr2 != null) {
            newCount = strArr2.length;
        }
        logd("getUpdateSubjectFlag oldCount = " + oldCount + " newCount = " + newCount);
        int count = efids.length;
        int[] flag = new int[count];
        logd("getUpdateSubjectFlag count = " + count);
        for (int i = 0; i < count; i++) {
            String str1 = "";
            String str2 = "";
            String aas1 = "";
            String aas2 = "";
            if (i < oldCount && strArr1[i] != null) {
                str1 = strArr1[i];
            }
            if (i < newCount && strArr2[i] != null) {
                str2 = strArr2[i];
            }
            if (i < oldCount && aasArr1 != null && i < aasArr1.length && aasArr1[i] != null) {
                aas1 = aasArr1[i];
            }
            if (i < newCount && aasArr2 != null && i < aasArr2.length && aasArr2[i] != null) {
                aas2 = aasArr2[i];
            }
            flag[i] = (str1.trim().equals(str2.trim()) && aas1.trim().equals(aas2.trim())) ? 0 : 1;
            logd("getUpdateSubjectFlag flag[i] = " + flag[i]);
        }
        return flag;
    }

    private int updateSubjectOfAdn(int type, int num, UniAdnRecordLoader uniAdnRecordLoader, int adnNum, int index, int efid, UniAdnRecord oldAdn, UniAdnRecord newAdn, int iapEF, String pin2, Object obj) {
        int m;
        int[] subjectNum;
        int i;
        int m2;
        int i2;
        ArrayList<Integer> subjectNums;
        int i3;
        int i4;
        int i5 = type;
        int i6 = num;
        int i7 = adnNum;
        int i8 = index;
        int[] efids = this.mUniUsimPhoneBookManager.getSubjectEfids(i5, i6);
        logd("Begin : updateSubjectOfAdn, file type = " + i5 + ", pbrNum = " + i6 + ", adnNum = " + i7 + ", index = " + i8);
        if (compareSubject(i5, oldAdn, newAdn)) {
            return 0;
        }
        int i9 = 0;
        int[] updateSubjectFlag = getUpdateSubjectFlag(num, type, oldAdn, newAdn, efids);
        ArrayList<Integer> subjectEfids = new ArrayList<>();
        ArrayList<Integer> subjectNums2 = new ArrayList<>();
        if (updateSubjectFlag == null || efids == null) {
            return 0;
        }
        if (efids.length == 0) {
            return 0;
        }
        int[][] anrTagMap = this.mUniUsimPhoneBookManager.getSubjectTagNumberInIap(i5, i6);
        int[] subjectNum2 = new int[efids.length];
        int m3 = 0;
        int n = 0;
        while (m3 < efids.length) {
            subjectEfids.add(Integer.valueOf(efids[m3]));
            if (updateSubjectFlag[m3] == 0) {
                logd("updateSubjectFlag[" + m3 + "] = 0");
                subjectNums2.add(Integer.valueOf(i9));
                n++;
                m = m3;
                subjectNum = subjectNum2;
                subjectNums = subjectNums2;
                i = i8;
                m2 = i7;
                i2 = i9;
                efids = efids;
            } else {
                if (this.mUniUsimPhoneBookManager.isSubjectRecordInIap(i5, i6, m3)) {
                    logd("updateSubjectOfAdn in iap");
                    try {
                        ArrayList<byte[]> mIapFileRecord = this.mUniUsimPhoneBookManager.getIapFileRecord(i6);
                        if (mIapFileRecord != null) {
                            byte[] record = mIapFileRecord.get(i8 - 1);
                            if (anrTagMap == null) {
                                logd("anrTagMap is null");
                                return -1;
                            }
                            if (record == null) {
                                logd("record is null");
                                return -1;
                            }
                            if (anrTagMap[m3][1] >= record.length) {
                                logd("anrTagMap[m][1] Error");
                                return -1;
                            }
                            logd("subjectNumberInIap = " + anrTagMap[m3][1]);
                            subjectNum2[m3] = record[anrTagMap[m3][1]] & 255;
                            logd("subjectNumber = " + subjectNum2[m3]);
                            subjectNum2[m3] = subjectNum2[m3] == 255 ? -1 : subjectNum2[m3];
                            logd("subjectNum[m] = " + subjectNum2[m3]);
                            if (subjectNum2[m3] < 1) {
                                i4 = i9;
                                subjectNum2[m3] = this.mUniUsimPhoneBookManager.getNewSubjectNumber(type, num, anrTagMap[m3][i4], n, index, true);
                                if (subjectNum2[m3] == -1) {
                                    logd("updateSubjectOfAdn is full");
                                    return -1;
                                }
                            } else {
                                i4 = i9;
                            }
                            logd("updateSubjectOfAdn subjectNum[m] = " + subjectNum2[m3]);
                            if (subjectNum2[m3] == -1) {
                                logd("file capacity full");
                                return -1;
                            }
                            subjectNums2.add(Integer.valueOf(subjectNum2[m3]));
                            i2 = i4;
                            m = m3;
                            subjectNum = subjectNum2;
                            ArrayList<Integer> subjectNums3 = subjectNums2;
                            ArrayList<Integer> subjectEfids2 = subjectEfids;
                            if (isCleanRecord(num, type, oldAdn, newAdn, m)) {
                                logd("clean anrTagMap[m][0] = " + Integer.toHexString(anrTagMap[m][i2]));
                                this.mUniUsimPhoneBookManager.removeSubjectNumFromSet(type, num, anrTagMap[m][i2], n, subjectNum[m]);
                                i = index;
                                this.mUniUsimPhoneBookManager.setIapFileRecord(i6, i - 1, (byte) -1, anrTagMap[m][1]);
                                record[anrTagMap[m][1]] = -1;
                            } else {
                                i = index;
                                logd("anrTagMap[m][0] = " + Integer.toHexString(anrTagMap[m][i2]));
                                this.mUniUsimPhoneBookManager.setIapFileRecord(i6, i - 1, (byte) (subjectNum[m] & 255), anrTagMap[m][1]);
                                r10[anrTagMap[m][1]] = (byte) (subjectNum[m] & 255);
                            }
                            if (anrTagMap[m][i2] <= 0) {
                                m2 = adnNum;
                            } else {
                                m2 = adnNum;
                                logd("begin to update IAP ---IAP recordId = " + m2 + ", iapEF = " + Integer.toHexString(iapEF).toUpperCase());
                                UniAdnRecordLoader uniAdnRecordLoader2 = new UniAdnRecordLoader(this.mFh);
                                uniAdnRecordLoader2.updateEFIapToUsim(newAdn, iapEF, index, r10, pin2, null, getRecordsSizeByEf(iapEF));
                            }
                            n++;
                            subjectEfids = subjectEfids2;
                            subjectNums = subjectNums3;
                        } else {
                            i3 = -1;
                            try {
                                logd("updateSubjectOfAdn mIapFileRecord == null ");
                                return -1;
                            } catch (IndexOutOfBoundsException e) {
                            }
                        }
                    } catch (IndexOutOfBoundsException e2) {
                        i3 = -1;
                    }
                    logd("Error: Improper ICC card: No IAP record for ADN, continuing");
                    return i3;
                }
                m = m3;
                subjectNum = subjectNum2;
                i = i8;
                m2 = i7;
                i2 = i9;
                efids = efids;
                subjectNums = subjectNums2;
                if (this.mUniUsimPhoneBookManager.getNewSubjectNumber(type, num, efids[m], 0, index, false) != i) {
                    logd("updateSubjectOfAdn fail to get  new subject ");
                    return -1;
                }
                subjectNums.add(Integer.valueOf(index));
            }
            i5 = type;
            i6 = num;
            i8 = i;
            i7 = m2;
            m3 = m + 1;
            efids = efids;
            i9 = i2;
            subjectNums2 = subjectNums;
            subjectNum2 = subjectNum;
        }
        ArrayList<Integer> subjectNums4 = subjectNums2;
        int i10 = i9;
        logd(" END :updateSubjectOfAdn  updateSubjectOfAdn efids is = " + subjectEfids + ", subjectNums = " + subjectNums4);
        int i11 = 0;
        while (i11 < subjectEfids.size()) {
            if (subjectNums4.get(i11).intValue() != 0) {
                ArrayList<Integer> toUpdateNums = new ArrayList<>();
                ArrayList<Integer> toUpdateIndex = new ArrayList<>();
                ArrayList<Integer> toUpdateEfids = new ArrayList<>();
                toUpdateEfids.add(subjectEfids.get(i11));
                toUpdateIndex.add(Integer.valueOf(i11));
                toUpdateNums.add(subjectNums4.get(i11));
                UniAdnRecordLoader uniAdnRecordLoader3 = new UniAdnRecordLoader(this.mFh);
                if (type == 0) {
                    uniAdnRecordLoader3.updateEFEmailToUsim(newAdn, toUpdateEfids, toUpdateNums, efid, index, toUpdateIndex, pin2, null, getRecordsSizeByEf(toUpdateEfids.get(i10).intValue()));
                }
                if (type == 4 && UniPhonebookUtils.isSupportOrange()) {
                    uniAdnRecordLoader3.updateEFSneToUsim(newAdn, toUpdateEfids, toUpdateNums, efid, index, toUpdateIndex, pin2, null);
                }
                if (type == 1) {
                    int[] data = null;
                    if (obj != null) {
                        data = (int[]) obj;
                    }
                    int aasIndex = (data == null || i11 >= data.length) ? i10 : data[i11];
                    logd("aasIndex = " + aasIndex);
                    try {
                        uniAdnRecordLoader3.updateEFAnrToUsim(newAdn, toUpdateEfids, efid, index, toUpdateNums, toUpdateIndex, pin2, null, getRecordsSizeByEf(toUpdateEfids.get(i10).intValue()), aasIndex);
                    } catch (UniIccPBForOperationException e3) {
                        return -2;
                    }
                } else {
                    continue;
                }
            }
            i11++;
        }
        logd("updateSubjectOfAdn done");
        return 1;
    }

    private void updateGrpOfAdn(UniAdnRecordLoader uniAdnRecordLoader, int index, int recNum, UniAdnRecord oldAdn, UniAdnRecord newAdn, String pin2, int efid, Message response) {
        if (compareSubject(2, oldAdn, newAdn)) {
            return;
        }
        String grp = newAdn.getGrp();
        byte[] data = new byte[this.mUniUsimPhoneBookManager.getGrpCount()];
        for (int i = 0; i < data.length; i++) {
            data[i] = 0;
        }
        if (!TextUtils.isEmpty(grp)) {
            String[] groups = grp.split(";");
            if (groups.length > data.length) {
                logd("one adn can only add " + data.length + " groups");
                this.mUserWriteResponse.delete(efid);
                sendErrorResponse(response, -10, "over the length of grp");
                return;
            } else {
                for (int i2 = 0; i2 < groups.length && i2 < data.length; i2++) {
                    int groupId = Integer.valueOf(groups[i2]).intValue();
                    data[i2] = (byte) groupId;
                }
            }
        }
        int grpEfId = this.mUniUsimPhoneBookManager.getEfIdByTag(recNum, UniUsimPhoneBookManager.USIM_EFGRP_TAG);
        uniAdnRecordLoader.updateEFGrpToUsim(grpEfId, index, data, pin2);
    }

    private byte findEmptyExt(ArrayList<byte[]> extList) {
        if (extList == null) {
            logd("extList is not existed ");
            return (byte) -1;
        }
        byte count = 1;
        Iterator<byte[]> it = extList.iterator();
        while (it.hasNext()) {
            if (-1 == it.next()[0]) {
                logd("we got the index " + ((int) count));
                return count;
            }
            count = (byte) (count + 1);
        }
        logd("find no empty ext");
        return (byte) -1;
    }

    private ArrayList<Integer> getUsedExtRecordIndex(int efid) {
        ArrayList<Integer> usedIndex = new ArrayList<>();
        ArrayList<UniAdnRecord> adnList = getRecordsIfLoadedEx(efid);
        if (adnList == null) {
            return null;
        }
        Iterator<UniAdnRecord> it = adnList.iterator();
        while (it.hasNext()) {
            int index = it.next().mExtRecord;
            if (index != 255 && index != 0 && !usedIndex.contains(Integer.valueOf(index))) {
                usedIndex.add(Integer.valueOf(index));
            }
        }
        logd("usedIndex = " + usedIndex);
        return usedIndex;
    }

    private byte getAvailableExtIndex(int extEfId, int efid) {
        logd("getAvailableExtIndex:extEfId = " + extEfId);
        ArrayList<byte[]> extList = this.mExtLikeFiles.get(extEfId);
        byte[] emptyExtRecord = new byte[13];
        for (int i = 0; i < emptyExtRecord.length; i++) {
            emptyExtRecord[i] = -1;
        }
        byte index = findEmptyExt(extList);
        logd("index& 0xff = " + (index & 255));
        if ((index & 255) == 255) {
            ArrayList<Integer> usedExtIndexs = getUsedExtRecordIndex(efid);
            logd("usedExtIndex = " + usedExtIndexs);
            if (usedExtIndexs == null || extList == null) {
                logd("extList is not existed");
                return (byte) -1;
            }
            int extListSize = extList.size();
            for (int i2 = 0; i2 < extListSize; i2++) {
                boolean isUsed = false;
                Iterator<Integer> it = usedExtIndexs.iterator();
                while (it.hasNext()) {
                    if (i2 + 1 == it.next().intValue()) {
                        isUsed = true;
                        break;
                    }
                }
                if (!isUsed) {
                    logd("set emptyRecord : " + (i2 + 1));
                    this.mExtLikeFiles.get(extEfId).set(i2, emptyExtRecord);
                }
            }
            return findEmptyExt(this.mExtLikeFiles.get(extEfId));
        }
        return index;
    }

    public synchronized void updateUSIMAdnBySearch(int efid, UniAdnRecord oldAdn, UniAdnRecord newAdn, String pin2, Message response) throws Throwable {
        Message message;
        UniAdnRecordCache uniAdnRecordCache;
        boolean find_index;
        int index;
        int efid2;
        int num;
        UniAdnRecord oldAdn2;
        int extensionEF;
        boolean emailInFirstPbrFull;
        int extensionEF2;
        UniAdnRecord oldAdn3;
        int i;
        int extensionEF3;
        byte extIndex;
        UniAdnRecordCache uniAdnRecordCache2 = this;
        Message message2 = response;
        synchronized (this) {
            try {
                uniAdnRecordCache2.logd("updateUSIMAdnBySearch efid:0x" + Integer.toHexString(efid).toUpperCase());
                boolean emailInFirstPbrFull2 = false;
                int num2 = 0;
                int recNum = -1;
                UniAdnRecord oldAdn4 = oldAdn;
                while (true) {
                    if (num2 >= uniAdnRecordCache2.mUniUsimPhoneBookManager.getNumRecs()) {
                        message = message2;
                        uniAdnRecordCache = uniAdnRecordCache2;
                        break;
                    }
                    recNum = -1;
                    int efid3 = uniAdnRecordCache2.mUniUsimPhoneBookManager.findEFInfo(num2);
                    int extensionEF4 = uniAdnRecordCache2.mUniUsimPhoneBookManager.findExtensionEFInfo(num2);
                    int iapEF = uniAdnRecordCache2.mUniUsimPhoneBookManager.findEFIapInfo(num2);
                    uniAdnRecordCache2.logd("efid:0x" + Integer.toHexString(efid3).toUpperCase() + ", extensionEF:0x" + Integer.toHexString(extensionEF4).toUpperCase() + ", iapEF:0x" + Integer.toHexString(iapEF).toUpperCase());
                    if (efid3 >= 0 && extensionEF4 >= 0) {
                        uniAdnRecordCache2.logd("updateUSIMAdnBySearch (1)");
                        ArrayList<UniAdnRecord> oldAdnList = uniAdnRecordCache2.getRecordsIfLoadedEx(efid3);
                        if (oldAdnList == null) {
                            if (num2 != uniAdnRecordCache2.mUniUsimPhoneBookManager.getNumRecs() - 1) {
                                efid2 = efid3;
                                num = num2;
                                message = message2;
                                uniAdnRecordCache = uniAdnRecordCache2;
                                oldAdn2 = oldAdn4;
                                extensionEF = extensionEF4;
                            } else {
                                uniAdnRecordCache2.sendErrorResponse(message2, -1, "Adn list not exist for EF:0x" + Integer.toHexString(efid3).toUpperCase());
                                return;
                            }
                        } else {
                            uniAdnRecordCache2.logd("updateUSIMAdnBySearch (2)");
                            int count = 1;
                            Iterator<UniAdnRecord> it = oldAdnList.iterator();
                            while (true) {
                                if (!it.hasNext()) {
                                    find_index = false;
                                    index = -1;
                                    break;
                                } else {
                                    if (oldAdn4.isEqual(it.next())) {
                                        uniAdnRecordCache2.logd("we got the index " + count);
                                        int index2 = count;
                                        uniAdnRecordCache2.mInsertId = index2;
                                        find_index = true;
                                        index = index2;
                                        break;
                                    }
                                    count++;
                                }
                            }
                            if (find_index) {
                                int recNum2 = num2;
                                for (int i2 = 0; i2 < num2; i2++) {
                                    uniAdnRecordCache2.mInsertId += uniAdnRecordCache2.mUniUsimPhoneBookManager.getAdnRecordSizeArray()[i2];
                                }
                                uniAdnRecordCache2.logd("updateUSIMAdnBySearch (3) mInsertId = " + uniAdnRecordCache2.mInsertId);
                                UniAdnRecord oldAdn5 = oldAdnList.get(index - 1);
                                if (!uniAdnRecordCache2.checkAnrLength(newAdn)) {
                                    uniAdnRecordCache2.logd("[updateUSIMAdnBySearch] Max length of dailing mNumber is 20");
                                    uniAdnRecordCache2.sendErrorResponse(message2, -13, "Anr number too long");
                                    return;
                                }
                                Message pendingResponse = uniAdnRecordCache2.mUserWriteResponse.get(efid3);
                                if (pendingResponse != null) {
                                    uniAdnRecordCache2.sendErrorResponse(message2, -1, "Have pending update for EF:0x" + Integer.toHexString(efid3).toUpperCase());
                                    return;
                                }
                                uniAdnRecordCache2.mUserWriteResponse.put(efid3, message2);
                                UniAdnRecordLoader uniAdnRecordLoader = new UniAdnRecordLoader(uniAdnRecordCache2.mFh);
                                int index3 = index;
                                num = num2;
                                int updateEmailResult = updateSubjectOfAdn(0, recNum2, uniAdnRecordLoader, uniAdnRecordCache2.mInsertId, index, efid3, oldAdn5, newAdn, iapEF, pin2, null);
                                uniAdnRecordCache2.logd("updateEmailResult = " + updateEmailResult);
                                if (updateEmailResult == -1) {
                                    efid2 = efid3;
                                    uniAdnRecordCache2.mUserWriteResponse.delete(efid2);
                                    if (recNum2 == uniAdnRecordCache2.mUniUsimPhoneBookManager.getNumRecs() - 1) {
                                        uniAdnRecordCache2.sendErrorResponse(message2, -2, "Email capacity full");
                                        return;
                                    }
                                    uniAdnRecordCache2.logd("in the first pbr,no subject found, search in the second pbr");
                                    oldAdn2 = oldAdn5;
                                    emailInFirstPbrFull2 = true;
                                    message = message2;
                                    uniAdnRecordCache = uniAdnRecordCache2;
                                    extensionEF = extensionEF4;
                                    recNum = index3;
                                } else {
                                    efid2 = efid3;
                                    int[] aasIndex = null;
                                    if (UniPhonebookUtils.isSupportOrange()) {
                                        newAdn.mAas = newAdn.mAas == null ? "" : newAdn.mAas;
                                        ArrayList<String> aasArr = loadAasFromUsim();
                                        uniAdnRecordCache2.logd("aasArr = " + aasArr + ", newAdn.mAas = " + newAdn.mAas);
                                        if (aasArr != null && newAdn.mAas != null) {
                                            String[] aas = newAdn.mAas.split(";");
                                            aasIndex = new int[aas.length];
                                            for (int i3 = 0; i3 < aas.length; i3++) {
                                                aasIndex[i3] = aasArr.indexOf(aas[i3].toString()) + 1;
                                                uniAdnRecordCache2.logd("aasIndex = " + aasIndex[i3]);
                                            }
                                        }
                                    }
                                    message = message2;
                                    uniAdnRecordCache = uniAdnRecordCache2;
                                    int updateAnrResult = updateSubjectOfAdn(1, recNum2, uniAdnRecordLoader, uniAdnRecordCache2.mInsertId, index3, efid2, oldAdn5, newAdn, iapEF, pin2, aasIndex);
                                    uniAdnRecordCache.logd("updateAnrResult = " + updateAnrResult);
                                    if (updateAnrResult < 0) {
                                        uniAdnRecordCache.mUserWriteResponse.delete(efid2);
                                        if (recNum2 == uniAdnRecordCache.mUniUsimPhoneBookManager.getNumRecs() - 1) {
                                            uniAdnRecordCache.logd("update anr failed");
                                            if (updateAnrResult == -1) {
                                                uniAdnRecordCache.sendErrorResponse(message, -9, "Anr capacity full");
                                            } else {
                                                uniAdnRecordCache.sendErrorResponse(message, -13, "Anr number too long");
                                            }
                                            return;
                                        }
                                        uniAdnRecordCache.logd("in the first pbr,no subject found, search in the second pbr");
                                        oldAdn2 = oldAdn5;
                                        emailInFirstPbrFull2 = false;
                                        extensionEF = extensionEF4;
                                        recNum = index3;
                                    } else {
                                        if (UniPhonebookUtils.isSupportOrange()) {
                                            int updateSneResult = updateSubjectOfAdn(4, recNum2, uniAdnRecordLoader, uniAdnRecordCache.mInsertId, index3, efid2, oldAdn5, newAdn, iapEF, pin2, null);
                                            uniAdnRecordCache.logd("updateSneResult = " + updateSneResult);
                                            if (updateSneResult < 0) {
                                                uniAdnRecordCache.logd("update sne failed");
                                                uniAdnRecordCache.mUserWriteResponse.delete(efid2);
                                                uniAdnRecordCache.sendErrorResponse(message, -1, "sne capacity full");
                                                return;
                                            }
                                        }
                                        updateGrpOfAdn(uniAdnRecordLoader, index3, recNum2, oldAdn5, newAdn, pin2, efid2, response);
                                        if (newAdn.extRecordIsNeeded()) {
                                            uniAdnRecordCache.logd("oldAdn extIndex = " + oldAdn5.mExtRecord);
                                            if (oldAdn5.mExtRecord != 255) {
                                                byte extIndex2 = (byte) oldAdn5.mExtRecord;
                                                extIndex = extIndex2;
                                                extensionEF3 = extensionEF4;
                                            } else {
                                                extensionEF3 = extensionEF4;
                                                byte extIndex3 = uniAdnRecordCache.getAvailableExtIndex(extensionEF3, efid2);
                                                extIndex = extIndex3;
                                            }
                                            uniAdnRecordCache.logd("extIndex = " + ((int) extIndex));
                                            if (extIndex == -1) {
                                                uniAdnRecordCache.logd("ext list full");
                                                uniAdnRecordCache.mUserWriteResponse.delete(efid2);
                                                uniAdnRecordCache.sendErrorResponse(message, -5, "ext list full");
                                                return;
                                            } else {
                                                newAdn.mExtRecord = extIndex;
                                                int extensionEF5 = extensionEF3;
                                                oldAdn3 = oldAdn5;
                                                emailInFirstPbrFull = false;
                                                extensionEF2 = extensionEF5;
                                                i = 255;
                                                new UniAdnRecordLoader(uniAdnRecordCache.mFh).updateExtEF(newAdn, efid2, extensionEF5, extIndex, pin2, uniAdnRecordCache.obtainMessage(7, extensionEF3, extIndex));
                                            }
                                        } else {
                                            emailInFirstPbrFull = false;
                                            extensionEF2 = extensionEF4;
                                            oldAdn3 = oldAdn5;
                                            i = 255;
                                            if (oldAdn3.mExtRecord != 255) {
                                                uniAdnRecordCache.logd("need to clear extRecord " + oldAdn3.mExtRecord);
                                                new UniAdnRecordLoader(uniAdnRecordCache.mFh).updateExtEF(newAdn, efid2, extensionEF2, oldAdn3.mExtRecord, pin2, uniAdnRecordCache.obtainMessage(7, extensionEF2, oldAdn3.mExtRecord));
                                            }
                                        }
                                        oldAdn3.mExtRecord = i;
                                        recNum = index3;
                                        new UniAdnRecordLoader(uniAdnRecordCache.mFh).updateEFAdnToUsim(newAdn, efid2, extensionEF2, index3, pin2, uniAdnRecordCache.obtainMessage(3, efid2, index3, newAdn), uniAdnRecordCache.getRecordsSizeByEf(efid2));
                                        emailInFirstPbrFull2 = emailInFirstPbrFull;
                                        oldAdn4 = oldAdn3;
                                        break;
                                    }
                                }
                            } else {
                                efid2 = efid3;
                                recNum = index;
                                num = num2;
                                message = message2;
                                uniAdnRecordCache = uniAdnRecordCache2;
                                oldAdn2 = oldAdn4;
                                extensionEF = extensionEF4;
                            }
                        }
                        try {
                            num2 = num + 1;
                            uniAdnRecordCache2 = uniAdnRecordCache;
                            message2 = message;
                            oldAdn4 = oldAdn2;
                        } catch (Throwable th) {
                            th = th;
                            throw th;
                        }
                    }
                    uniAdnRecordCache2.sendErrorResponse(message2, -1, "EF is not known ADN-like EF: efid:0x" + Integer.toHexString(efid3).toUpperCase());
                    return;
                }
                if (recNum == -1) {
                    if (emailInFirstPbrFull2) {
                        uniAdnRecordCache.sendErrorResponse(message, -2, "Email capacity full");
                    } else {
                        uniAdnRecordCache.sendErrorResponse(message, -3, "Adn record don't exist for " + oldAdn4);
                    }
                }
                uniAdnRecordCache.logd("updateUSIMAdnBySearch finish");
            } catch (Throwable th2) {
                th = th2;
            }
        }
    }

    public void insertLndBySearch(int efid, UniAdnRecord oldLnd, UniAdnRecord newLnd, String pin2, Message response) {
        int extensionEF = extensionEfForEf(efid);
        logd("insertLndBySearch:efid = 0x" + Integer.toHexString(efid).toUpperCase() + " extensionEF = 0x" + Integer.toHexString(extensionEF).toUpperCase());
        if (extensionEF < 0) {
            sendErrorResponse(response, -1, "EF is not known LND-like EF:0x" + Integer.toHexString(efid).toUpperCase());
            return;
        }
        removedRecordsIfLoaded(efid);
        Message pendingResponse = this.mUserWriteResponse.get(efid);
        if (pendingResponse != null) {
            sendErrorResponse(response, -1, "Have pending update for EF:0x" + Integer.toHexString(efid).toUpperCase());
        } else {
            this.mUserWriteResponse.put(efid, response);
            new UniAdnRecordLoader(this.mFh).updateEFCyclic(newLnd, efid, extensionEF, 0, pin2, obtainMessage(4, efid, 0, newLnd));
        }
    }

    private byte[] gasToByte(String gas, int recordSize) {
        byte[] gasByte = new byte[recordSize];
        for (int i = 0; i < recordSize; i++) {
            gasByte[i] = -1;
        }
        if (!TextUtils.isEmpty(gas)) {
            try {
                byte[] data = UniGsmAlphabet.stringToGsmAlphaSS(gas);
                System.arraycopy(data, 0, gasByte, 0, data.length);
            } catch (EncodeException e) {
                try {
                    byte[] data2 = gas.getBytes("utf-16be");
                    System.arraycopy(data2, 0, gasByte, 1, data2.length);
                    gasByte[0] = -128;
                } catch (UnsupportedEncodingException e2) {
                    logd("gas convert byte exception");
                } catch (ArrayIndexOutOfBoundsException e3) {
                    logd("over the length of group name");
                    return null;
                }
            } catch (ArrayIndexOutOfBoundsException e4) {
                logd("over the length of group name");
                return null;
            }
        }
        return gasByte;
    }

    public int updateGasBySearch(String oldGas, String newGas) {
        ArrayList<String> oldGasList = this.mUniUsimPhoneBookManager.loadGasFromUsim();
        if (oldGasList == null) {
            logd("Gas list not exist");
            return -1;
        }
        int index = -1;
        int count = 1;
        Iterator<String> it = oldGasList.iterator();
        while (it.hasNext()) {
            if (oldGas.equals(it.next())) {
                index = count;
                break;
            }
            count++;
        }
        if (index == -1) {
            logd("Gas record don't exist for " + oldGas);
            return -8;
        }
        int gasEfId = this.mUniUsimPhoneBookManager.findEFGasInfo();
        int[] gasSize = getRecordsSizeByEf(gasEfId);
        if (gasSize == null) {
            return -1;
        }
        byte[] data = gasToByte(newGas, gasSize[0]);
        if (data == null) {
            logd("data == null");
            return -7;
        }
        new UniAdnRecordLoader(this.mFh).updateEFGasToUsim(gasEfId, index, data, null);
        this.mUniUsimPhoneBookManager.updateGasList(newGas, index);
        return index;
    }

    public int updateGasByIndex(String newGas, int groupId) {
        int gasEfId = this.mUniUsimPhoneBookManager.findEFGasInfo();
        int[] gasSize = getRecordsSizeByEf(gasEfId);
        if (gasSize == null) {
            return -1;
        }
        byte[] data = gasToByte(newGas, gasSize[0]);
        if (data == null) {
            logd("data == null");
            return -7;
        }
        new UniAdnRecordLoader(this.mFh).updateEFGasToUsim(gasEfId, groupId, data, null);
        this.mUniUsimPhoneBookManager.updateGasList(newGas, groupId);
        return groupId;
    }

    /* JADX WARN: Code duplicated, block: B:56:0x0280 A[Catch: all -> 0x0462, TryCatch #1 {all -> 0x0462, blocks: (B:5:0x000d, B:7:0x0049, B:10:0x0059, B:13:0x007d, B:16:0x009c, B:20:0x0107, B:22:0x010e, B:26:0x0130, B:28:0x0175, B:31:0x0181, B:33:0x018d, B:36:0x01ad, B:38:0x01c0, B:42:0x01c9, B:44:0x01f3, B:46:0x01f7, B:47:0x0204, B:49:0x0209, B:54:0x025a, B:56:0x0280, B:58:0x028f, B:59:0x0297, B:63:0x02a4, B:41:0x01c7, B:14:0x008b), top: B:111:0x000d }] */
    /* JADX WARN: Code duplicated, block: B:58:0x028f A[Catch: all -> 0x0462, TryCatch #1 {all -> 0x0462, blocks: (B:5:0x000d, B:7:0x0049, B:10:0x0059, B:13:0x007d, B:16:0x009c, B:20:0x0107, B:22:0x010e, B:26:0x0130, B:28:0x0175, B:31:0x0181, B:33:0x018d, B:36:0x01ad, B:38:0x01c0, B:42:0x01c9, B:44:0x01f3, B:46:0x01f7, B:47:0x0204, B:49:0x0209, B:54:0x025a, B:56:0x0280, B:58:0x028f, B:59:0x0297, B:63:0x02a4, B:41:0x01c7, B:14:0x008b), top: B:111:0x000d }] */
    /* JADX WARN: Code duplicated, block: B:59:0x0297 A[Catch: all -> 0x0462, TRY_LEAVE, TryCatch #1 {all -> 0x0462, blocks: (B:5:0x000d, B:7:0x0049, B:10:0x0059, B:13:0x007d, B:16:0x009c, B:20:0x0107, B:22:0x010e, B:26:0x0130, B:28:0x0175, B:31:0x0181, B:33:0x018d, B:36:0x01ad, B:38:0x01c0, B:42:0x01c9, B:44:0x01f3, B:46:0x01f7, B:47:0x0204, B:49:0x0209, B:54:0x025a, B:56:0x0280, B:58:0x028f, B:59:0x0297, B:63:0x02a4, B:41:0x01c7, B:14:0x008b), top: B:111:0x000d }] */
    /* JADX WARN: Code duplicated, block: B:62:0x02a0  */
    /* JADX WARN: Code duplicated, block: B:67:0x02c3 A[Catch: all -> 0x0460, TRY_LEAVE, TryCatch #0 {all -> 0x0460, blocks: (B:101:0x0459, B:97:0x0421, B:65:0x02bd, B:67:0x02c3, B:70:0x02d5, B:72:0x02db, B:74:0x030d, B:78:0x032f, B:80:0x033b, B:82:0x035a, B:84:0x0367, B:86:0x037f, B:89:0x0391, B:93:0x03f1, B:83:0x0360, B:90:0x03b3, B:92:0x03c0), top: B:110:0x0047 }] */
    /* JADX WARN: Code duplicated, block: B:70:0x02d5 A[Catch: all -> 0x0460, TRY_ENTER, TryCatch #0 {all -> 0x0460, blocks: (B:101:0x0459, B:97:0x0421, B:65:0x02bd, B:67:0x02c3, B:70:0x02d5, B:72:0x02db, B:74:0x030d, B:78:0x032f, B:80:0x033b, B:82:0x035a, B:84:0x0367, B:86:0x037f, B:89:0x0391, B:93:0x03f1, B:83:0x0360, B:90:0x03b3, B:92:0x03c0), top: B:110:0x0047 }] */
    /* JADX WARN: Code duplicated, block: B:72:0x02db A[Catch: all -> 0x0460, TryCatch #0 {all -> 0x0460, blocks: (B:101:0x0459, B:97:0x0421, B:65:0x02bd, B:67:0x02c3, B:70:0x02d5, B:72:0x02db, B:74:0x030d, B:78:0x032f, B:80:0x033b, B:82:0x035a, B:84:0x0367, B:86:0x037f, B:89:0x0391, B:93:0x03f1, B:83:0x0360, B:90:0x03b3, B:92:0x03c0), top: B:110:0x0047 }] */
    /* JADX WARN: Code duplicated, block: B:74:0x030d A[Catch: all -> 0x0460, TRY_LEAVE, TryCatch #0 {all -> 0x0460, blocks: (B:101:0x0459, B:97:0x0421, B:65:0x02bd, B:67:0x02c3, B:70:0x02d5, B:72:0x02db, B:74:0x030d, B:78:0x032f, B:80:0x033b, B:82:0x035a, B:84:0x0367, B:86:0x037f, B:89:0x0391, B:93:0x03f1, B:83:0x0360, B:90:0x03b3, B:92:0x03c0), top: B:110:0x0047 }] */
    /* JADX WARN: Code duplicated, block: B:80:0x033b A[Catch: all -> 0x0460, TryCatch #0 {all -> 0x0460, blocks: (B:101:0x0459, B:97:0x0421, B:65:0x02bd, B:67:0x02c3, B:70:0x02d5, B:72:0x02db, B:74:0x030d, B:78:0x032f, B:80:0x033b, B:82:0x035a, B:84:0x0367, B:86:0x037f, B:89:0x0391, B:93:0x03f1, B:83:0x0360, B:90:0x03b3, B:92:0x03c0), top: B:110:0x0047 }] */
    /* JADX WARN: Code duplicated, block: B:82:0x035a A[Catch: all -> 0x0460, TryCatch #0 {all -> 0x0460, blocks: (B:101:0x0459, B:97:0x0421, B:65:0x02bd, B:67:0x02c3, B:70:0x02d5, B:72:0x02db, B:74:0x030d, B:78:0x032f, B:80:0x033b, B:82:0x035a, B:84:0x0367, B:86:0x037f, B:89:0x0391, B:93:0x03f1, B:83:0x0360, B:90:0x03b3, B:92:0x03c0), top: B:110:0x0047 }] */
    /* JADX WARN: Code duplicated, block: B:83:0x0360 A[Catch: all -> 0x0460, TryCatch #0 {all -> 0x0460, blocks: (B:101:0x0459, B:97:0x0421, B:65:0x02bd, B:67:0x02c3, B:70:0x02d5, B:72:0x02db, B:74:0x030d, B:78:0x032f, B:80:0x033b, B:82:0x035a, B:84:0x0367, B:86:0x037f, B:89:0x0391, B:93:0x03f1, B:83:0x0360, B:90:0x03b3, B:92:0x03c0), top: B:110:0x0047 }] */
    /* JADX WARN: Code duplicated, block: B:86:0x037f A[Catch: all -> 0x0460, TRY_LEAVE, TryCatch #0 {all -> 0x0460, blocks: (B:101:0x0459, B:97:0x0421, B:65:0x02bd, B:67:0x02c3, B:70:0x02d5, B:72:0x02db, B:74:0x030d, B:78:0x032f, B:80:0x033b, B:82:0x035a, B:84:0x0367, B:86:0x037f, B:89:0x0391, B:93:0x03f1, B:83:0x0360, B:90:0x03b3, B:92:0x03c0), top: B:110:0x0047 }] */
    /* JADX WARN: Code duplicated, block: B:89:0x0391 A[Catch: all -> 0x0460, TRY_ENTER, TryCatch #0 {all -> 0x0460, blocks: (B:101:0x0459, B:97:0x0421, B:65:0x02bd, B:67:0x02c3, B:70:0x02d5, B:72:0x02db, B:74:0x030d, B:78:0x032f, B:80:0x033b, B:82:0x035a, B:84:0x0367, B:86:0x037f, B:89:0x0391, B:93:0x03f1, B:83:0x0360, B:90:0x03b3, B:92:0x03c0), top: B:110:0x0047 }] */
    /* JADX WARN: Code duplicated, block: B:90:0x03b3 A[Catch: all -> 0x0460, TryCatch #0 {all -> 0x0460, blocks: (B:101:0x0459, B:97:0x0421, B:65:0x02bd, B:67:0x02c3, B:70:0x02d5, B:72:0x02db, B:74:0x030d, B:78:0x032f, B:80:0x033b, B:82:0x035a, B:84:0x0367, B:86:0x037f, B:89:0x0391, B:93:0x03f1, B:83:0x0360, B:90:0x03b3, B:92:0x03c0), top: B:110:0x0047 }] */
    /* JADX WARN: Code duplicated, block: B:92:0x03c0 A[Catch: all -> 0x0460, TryCatch #0 {all -> 0x0460, blocks: (B:101:0x0459, B:97:0x0421, B:65:0x02bd, B:67:0x02c3, B:70:0x02d5, B:72:0x02db, B:74:0x030d, B:78:0x032f, B:80:0x033b, B:82:0x035a, B:84:0x0367, B:86:0x037f, B:89:0x0391, B:93:0x03f1, B:83:0x0360, B:90:0x03b3, B:92:0x03c0), top: B:110:0x0047 }] */
    public synchronized void updateUSIMAdnByIndex(int efid, int simIndex, UniAdnRecord newAdn, String pin2, Message response) throws Throwable {
        int recNum;
        int baseNum;
        Object aasIndex;
        UniAdnRecord oldAdn;
        int recNum2;
        int updateAnrResult;
        int updateEmailResult;
        int extensionEF;
        UniAdnRecord oldAdn2;
        int updateAnrResult2;
        int extensionEF2;
        byte extIndex;
        int updateSneResult;
        try {
            int pbrRecNum = this.mUniUsimPhoneBookManager.getNumRecs();
            logd("updateUSIMAdnByIndex efid = 0x" + Integer.toHexString(efid).toUpperCase() + ", RecsNum = " + pbrRecNum + ", simIndex = " + simIndex);
            try {
                if (simIndex < 0 || simIndex > this.mUniUsimPhoneBookManager.getPhoneBookRecordsNum()) {
                    sendErrorResponse(response, -1, "the sim index is invalid");
                    return;
                }
                int baseNum2 = this.mUniUsimPhoneBookManager.getAdnRecordSizeArray()[0];
                logd("baseNum = " + baseNum2);
                int i = 0;
                while (true) {
                    if (i >= pbrRecNum) {
                        recNum = 0;
                        baseNum = baseNum2;
                        break;
                    } else {
                        if (simIndex <= baseNum2) {
                            int recNum3 = i;
                            recNum = recNum3;
                            baseNum = baseNum2 - this.mUniUsimPhoneBookManager.getAdnRecordSizeArray()[i];
                            break;
                        }
                        baseNum2 += this.mUniUsimPhoneBookManager.getAdnRecordSizeArray()[i + 1];
                        i++;
                    }
                }
                int adnIndex = simIndex - baseNum;
                this.mInsertId = simIndex;
                int efid2 = this.mUniUsimPhoneBookManager.findEFInfo(recNum);
                int extensionEF3 = this.mUniUsimPhoneBookManager.findExtensionEFInfo(recNum);
                int iapEF = this.mUniUsimPhoneBookManager.findEFIapInfo(recNum);
                logd("adn efid:0x" + Integer.toHexString(efid2).toUpperCase() + ", extensionEF:0x" + Integer.toHexString(extensionEF3).toUpperCase() + ", iapEF:0x" + Integer.toHexString(iapEF).toUpperCase());
                if (efid2 < 0 || extensionEF3 < 0) {
                    sendErrorResponse(response, -1, "EF is not known ADN-like EF: efid:0x" + Integer.toHexString(efid2).toUpperCase() + ", extensionEF:0x" + Integer.toHexString(extensionEF3).toUpperCase());
                    return;
                }
                ArrayList<UniAdnRecord> oldAdnList = getRecordsIfLoadedEx(efid2);
                if (oldAdnList == null) {
                    sendErrorResponse(response, -1, "Adn list not exist for EF:0x" + Integer.toHexString(efid2).toUpperCase());
                    return;
                }
                UniAdnRecord oldAdn3 = oldAdnList.get(adnIndex - 1);
                logd("recNum: " + recNum + ", adnIndex:" + adnIndex + ", mInsertId:" + this.mInsertId + ", oldAdn:" + oldAdn3);
                if (!checkAnrLength(newAdn)) {
                    logd("[updateUSIMAdnByIndex] Max length of dailing mNumber is 20");
                    sendErrorResponse(response, -13, "Anr number too long");
                    return;
                }
                Message pendingResponse = this.mUserWriteResponse.get(efid2);
                if (pendingResponse != null) {
                    sendErrorResponse(response, -1, "Have pending update for EF:0x" + Integer.toHexString(efid2).toUpperCase());
                    return;
                }
                this.mUserWriteResponse.put(efid2, response);
                UniAdnRecordLoader uniAdnRecordLoader = new UniAdnRecordLoader(this.mFh);
                if (UniPhonebookUtils.isSupportOrange()) {
                    newAdn.mAas = newAdn.mAas == null ? "" : newAdn.mAas;
                    ArrayList<String> aasArr = loadAasFromUsim();
                    logd("aasArr = " + aasArr + ", newAdn.mAas = " + newAdn.mAas);
                    if (aasArr != null && newAdn.mAas != null) {
                        String[] aas = newAdn.mAas.split(";");
                        int[] aasIndex2 = new int[aas.length];
                        int i2 = 0;
                        while (true) {
                            oldAdn3 = oldAdn3;
                            if (i2 >= aas.length) {
                                break;
                            }
                            aasIndex2[i2] = aasArr.indexOf(aas[i2].toString()) + 1;
                            logd("aas[" + i2 + "] = " + aas[i2] + ", aasIndex = " + aasIndex2[i2]);
                            i2++;
                            oldAdn3 = oldAdn3;
                            aasArr = aasArr;
                        }
                        aasIndex = aasIndex2;
                    }
                    oldAdn = oldAdn3;
                    recNum2 = recNum;
                    updateAnrResult = updateSubjectOfAdn(1, recNum, uniAdnRecordLoader, this.mInsertId, adnIndex, efid2, oldAdn, newAdn, iapEF, pin2, aasIndex);
                    if (updateAnrResult < 0) {
                        logd("update anr failed");
                        this.mUserWriteResponse.delete(efid2);
                        if (updateAnrResult == -1) {
                            sendErrorResponse(response, -9, "Anr capacity full");
                        } else {
                            sendErrorResponse(response, -13, "Anr number too long");
                        }
                        return;
                    }
                    updateEmailResult = updateSubjectOfAdn(0, recNum2, uniAdnRecordLoader, this.mInsertId, adnIndex, efid2, oldAdn, newAdn, iapEF, pin2, null);
                    if (updateEmailResult < 0) {
                        logd("update email failed");
                        this.mUserWriteResponse.delete(efid2);
                        sendErrorResponse(response, -2, "Email capacity full");
                        return;
                    }
                    if (UniPhonebookUtils.isSupportOrange()) {
                        updateSneResult = updateSubjectOfAdn(4, recNum2, uniAdnRecordLoader, this.mInsertId, adnIndex, efid2, oldAdn, newAdn, iapEF, pin2, null);
                        logd("updateSneResult = " + updateSneResult);
                        if (updateSneResult < 0) {
                            logd("update sne failed");
                            this.mUserWriteResponse.delete(efid2);
                            sendErrorResponse(response, -1, "Sne capacity full");
                            return;
                        }
                    }
                    updateGrpOfAdn(uniAdnRecordLoader, adnIndex, recNum2, oldAdn, newAdn, pin2, efid2, response);
                    if (newAdn.extRecordIsNeeded()) {
                        logd("oldAdn extIndex = " + oldAdn.mExtRecord);
                        if (oldAdn.mExtRecord != 255) {
                            extIndex = (byte) oldAdn.mExtRecord;
                            extensionEF2 = extensionEF3;
                        } else {
                            extensionEF2 = extensionEF3;
                            extIndex = getAvailableExtIndex(extensionEF2, efid2);
                        }
                        logd("got extIndex = " + ((int) extIndex));
                        if (extIndex == -1) {
                            logd("ext list full");
                            this.mUserWriteResponse.delete(efid2);
                            sendErrorResponse(response, -5, "ext list full");
                            return;
                        } else {
                            newAdn.mExtRecord = extIndex;
                            extensionEF = extensionEF2;
                            oldAdn2 = oldAdn;
                            updateAnrResult2 = 255;
                            new UniAdnRecordLoader(this.mFh).updateExtEF(newAdn, efid2, extensionEF, extIndex, pin2, obtainMessage(7, extensionEF2, extIndex));
                        }
                    } else {
                        extensionEF = extensionEF3;
                        oldAdn2 = oldAdn;
                        updateAnrResult2 = 255;
                        if (oldAdn2.mExtRecord != 255) {
                            logd("need to clear extRecord " + oldAdn2.mExtRecord);
                            new UniAdnRecordLoader(this.mFh).updateExtEF(newAdn, efid2, extensionEF, oldAdn2.mExtRecord, pin2, obtainMessage(7, extensionEF, oldAdn2.mExtRecord));
                        }
                    }
                    oldAdn2.mExtRecord = updateAnrResult2;
                    new UniAdnRecordLoader(this.mFh).updateEFAdnToUsim(newAdn, efid2, extensionEF, adnIndex, pin2, obtainMessage(3, efid2, adnIndex, newAdn), getRecordsSizeByEf(efid2));
                    logd("updateUSIMAdnByIndex  finish");
                }
                aasIndex = null;
                oldAdn = oldAdn3;
                recNum2 = recNum;
                updateAnrResult = updateSubjectOfAdn(1, recNum, uniAdnRecordLoader, this.mInsertId, adnIndex, efid2, oldAdn, newAdn, iapEF, pin2, aasIndex);
                if (updateAnrResult < 0) {
                    logd("update anr failed");
                    this.mUserWriteResponse.delete(efid2);
                    if (updateAnrResult == -1) {
                        sendErrorResponse(response, -9, "Anr capacity full");
                    } else {
                        sendErrorResponse(response, -13, "Anr number too long");
                    }
                    return;
                }
                updateEmailResult = updateSubjectOfAdn(0, recNum2, uniAdnRecordLoader, this.mInsertId, adnIndex, efid2, oldAdn, newAdn, iapEF, pin2, null);
                if (updateEmailResult < 0) {
                    logd("update email failed");
                    this.mUserWriteResponse.delete(efid2);
                    sendErrorResponse(response, -2, "Email capacity full");
                    return;
                }
                if (UniPhonebookUtils.isSupportOrange()) {
                    updateSneResult = updateSubjectOfAdn(4, recNum2, uniAdnRecordLoader, this.mInsertId, adnIndex, efid2, oldAdn, newAdn, iapEF, pin2, null);
                    logd("updateSneResult = " + updateSneResult);
                    if (updateSneResult < 0) {
                        logd("update sne failed");
                        this.mUserWriteResponse.delete(efid2);
                        sendErrorResponse(response, -1, "Sne capacity full");
                        return;
                    }
                }
                updateGrpOfAdn(uniAdnRecordLoader, adnIndex, recNum2, oldAdn, newAdn, pin2, efid2, response);
                if (newAdn.extRecordIsNeeded()) {
                    logd("oldAdn extIndex = " + oldAdn.mExtRecord);
                    if (oldAdn.mExtRecord != 255) {
                        extIndex = (byte) oldAdn.mExtRecord;
                        extensionEF2 = extensionEF3;
                    } else {
                        extensionEF2 = extensionEF3;
                        extIndex = getAvailableExtIndex(extensionEF2, efid2);
                    }
                    logd("got extIndex = " + ((int) extIndex));
                    if (extIndex == -1) {
                        logd("ext list full");
                        this.mUserWriteResponse.delete(efid2);
                        sendErrorResponse(response, -5, "ext list full");
                        return;
                    } else {
                        newAdn.mExtRecord = extIndex;
                        extensionEF = extensionEF2;
                        oldAdn2 = oldAdn;
                        updateAnrResult2 = 255;
                        new UniAdnRecordLoader(this.mFh).updateExtEF(newAdn, efid2, extensionEF, extIndex, pin2, obtainMessage(7, extensionEF2, extIndex));
                    }
                } else {
                    extensionEF = extensionEF3;
                    oldAdn2 = oldAdn;
                    updateAnrResult2 = 255;
                    if (oldAdn2.mExtRecord != 255) {
                        logd("need to clear extRecord " + oldAdn2.mExtRecord);
                        new UniAdnRecordLoader(this.mFh).updateExtEF(newAdn, efid2, extensionEF, oldAdn2.mExtRecord, pin2, obtainMessage(7, extensionEF, oldAdn2.mExtRecord));
                    }
                }
                oldAdn2.mExtRecord = updateAnrResult2;
                new UniAdnRecordLoader(this.mFh).updateEFAdnToUsim(newAdn, efid2, extensionEF, adnIndex, pin2, obtainMessage(3, efid2, adnIndex, newAdn), getRecordsSizeByEf(efid2));
                logd("updateUSIMAdnByIndex  finish");
            } catch (Throwable th) {
                th = th;
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }

    public int getAdnIndex(int efid, UniAdnRecord oldAdn) {
        ArrayList<UniAdnRecord> oldAdnList = getRecordsIfLoadedEx(efid);
        logi("getAdnIndex efid = " + efid);
        if (oldAdnList == null) {
            return -1;
        }
        logi("updateAdnBySearch (2)");
        int count = 1;
        Iterator<UniAdnRecord> it = oldAdnList.iterator();
        while (it.hasNext()) {
            if (oldAdn.isEqual(it.next())) {
                int index = count;
                return index;
            }
            count++;
        }
        return -1;
    }

    public UniUsimPhoneBookManager getUniUsimPhoneBookManager() {
        return this.mUniUsimPhoneBookManager;
    }

    public int getAdnLikeSize() {
        return this.mAdnLikeFiles.size();
    }

    public int getInsertId() {
        return this.mInsertId;
    }

    @Override // android.os.Handler
    public void handleMessage(Message msg) {
        switch (msg.what) {
            case 1:
                AsyncResult ar = (AsyncResult) msg.obj;
                int efid = msg.arg1;
                int extensionEf = msg.arg2;
                ArrayList<Message> waiters = this.mAdnLikeWaiters.get(efid);
                this.mAdnLikeWaiters.delete(efid);
                if (ar.exception == null) {
                    ArrayList<UniAdnRecord> adns = (ArrayList) ar.result;
                    for (UniAdnRecord uniAdnRecord : adns) {
                        if (uniAdnRecord.hasExtendedRecord() && uniAdnRecord.extRecord4DisplayIsNeeded()) {
                            logd("adn.extRecord = " + uniAdnRecord.mExtRecord);
                            if (this.mExtLikeFiles.get(extensionEf) != null && uniAdnRecord.mExtRecord <= this.mExtLikeFiles.get(extensionEf).size()) {
                                uniAdnRecord.appendExtRecord(this.mExtLikeFiles.get(extensionEf).get(uniAdnRecord.mExtRecord - 1));
                            }
                        }
                    }
                    this.mAdnLikeFiles.put(efid, (ArrayList) ar.result);
                }
                logd("EVENT_LOAD_ALL_ADN_LIKE_DONE:efid = " + efid + ", ar.exception = " + ar.exception);
                if (waiters != null) {
                    notifyWaiters(waiters, ar);
                }
                break;
            case 2:
                AsyncResult ar2 = (AsyncResult) msg.obj;
                int efid2 = msg.arg1;
                int index = msg.arg2;
                UniAdnRecord adn = (UniAdnRecord) ar2.userObj;
                logd("UniAdnRecordCache:EVENT_UPDATE_ADN_DONE:mInsertId = " + this.mInsertId);
                if (ar2.exception == null && this.mAdnLikeFiles.get(efid2) != null) {
                    adn.setRecordNumber(this.mInsertId);
                    logd("EVENT_UPDATE_ADN_DONE:adn.extRecord = " + adn.mExtRecord);
                    this.mAdnLikeFiles.get(efid2).set(index - 1, adn);
                }
                logi("efid 0x" + Integer.toHexString(efid2).toUpperCase());
                Message response = this.mUserWriteResponse.get(efid2);
                logi("response = " + response + ", index = " + index);
                this.mUserWriteResponse.delete(efid2);
                if (response != null) {
                    AsyncResult.forMessage(response, Integer.valueOf(index), ar2.exception);
                    logi("response = " + response + ", index = " + index + ", target = " + response.getTarget());
                    response.sendToTarget();
                } else {
                    logd("EVENT_UPDATE_ADN_DONE response is null efid:" + efid2);
                }
                break;
            case 3:
                logi("EVENT_UPDATE_USIM_ADN_DONE");
                AsyncResult ar3 = (AsyncResult) msg.obj;
                int efid3 = msg.arg1;
                int index2 = msg.arg2;
                UniAdnRecord adn2 = (UniAdnRecord) ar3.userObj;
                int recNum = -1;
                for (int num = 0; num < this.mUniUsimPhoneBookManager.getNumRecs(); num++) {
                    int adnEF = this.mUniUsimPhoneBookManager.findEFInfo(num);
                    if (efid3 == adnEF) {
                        recNum = num;
                    }
                }
                int[] mAdnRecordSizeArray = this.mUniUsimPhoneBookManager.getAdnRecordSizeArray();
                if (recNum != -1) {
                    int adnRecNum = index2 - 1;
                    for (int i = 0; i < recNum; i++) {
                        adnRecNum += mAdnRecordSizeArray[i];
                    }
                    logd("EVENT_UPDATE_USIM_ADN_DONE:mInsertId = " + this.mInsertId + ", adnRecNum = " + adnRecNum + ", adn.extrecord = " + adn2.mExtRecord);
                    if (ar3.exception == null && this.mAdnLikeFiles.get(efid3) != null) {
                        adn2.setRecordNumber(this.mInsertId);
                        this.mUniUsimPhoneBookManager.setPhoneBookRecords(adnRecNum, adn2);
                        this.mAdnLikeFiles.get(efid3).set(index2 - 1, adn2);
                        if (Resources.getSystem().getBoolean(134414367)) {
                            this.mUniUsimPhoneBookManager.updateUidForAdn(efid3, recNum, adnRecNum, adn2);
                        }
                    } else {
                        loge(" fail to Update Usim Adn");
                    }
                    Message response2 = this.mUserWriteResponse.get(efid3);
                    this.mUserWriteResponse.delete(efid3);
                    if (response2 != null) {
                        AsyncResult.forMessage(response2, (Object) null, ar3.exception);
                        response2.sendToTarget();
                    }
                    logi("EVENT_UPDATE_USIM_ADN_DONE finish");
                    break;
                }
                break;
            case 4:
                AsyncResult ar4 = (AsyncResult) msg.obj;
                int efid4 = msg.arg1;
                int index3 = msg.arg2;
                this.mInsertId = 1;
                logi("efid:0x " + Integer.toHexString(efid4).toUpperCase() + ", mInsertId = " + this.mInsertId + ", index = " + index3);
                if (ar4.exception != null) {
                    logi("ar.exception != null");
                }
                Message response3 = this.mUserWriteResponse.get(efid4);
                this.mUserWriteResponse.delete(efid4);
                if (response3 != null) {
                    AsyncResult.forMessage(response3, Integer.valueOf(index3), ar4.exception);
                    logi("response = " + response3 + ", target = " + response3.getTarget());
                    response3.sendToTarget();
                } else {
                    logd("EVENT_UPDATE_CYCLIC_DONE response is null efid:" + efid4);
                }
                break;
            case 6:
                AsyncResult ar5 = (AsyncResult) msg.obj;
                int efid5 = msg.arg1;
                int extensionEf2 = msg.arg2;
                if (ar5.exception == null) {
                    this.mExtLikeFiles.put(extensionEf2, (ArrayList) ar5.result);
                }
                new UniAdnRecordLoader(this.mFh).loadAllFromEF(efid5, extensionEf2, obtainMessage(1, efid5, extensionEf2));
                break;
            case 7:
                AsyncResult ar6 = (AsyncResult) msg.obj;
                int extensionEf3 = msg.arg1;
                int index4 = msg.arg2;
                byte[] extData = (byte[]) ar6.result;
                logd("EVENT_UPDATE_EXT_DONE index = " + index4 + ", extData = " + extData);
                if (ar6.exception == null && this.mExtLikeFiles.get(extensionEf3) != null && extData != null) {
                    if (index4 > 0 && index4 <= this.mExtLikeFiles.get(extensionEf3).size()) {
                        this.mExtLikeFiles.get(extensionEf3).set(index4 - 1, extData);
                        break;
                    }
                } else {
                    logd("EVENT_UPDATE_EXT_DONE failed:" + ar6.exception);
                    break;
                }
                break;
            case 8:
                AsyncResult ar7 = (AsyncResult) msg.obj;
                int efid6 = msg.arg1;
                logd("EVENT_UPDATE_SNE_DONE exception:" + ar7.exception + " efid:0x" + Integer.toHexString(efid6).toUpperCase());
                if (ar7.exception != null) {
                    Message response4 = this.mUserWriteResponse.get(efid6);
                    this.mUserWriteResponse.delete(efid6);
                    if (response4 != null) {
                        AsyncResult.forMessage(response4, (Object) null, ar7.exception);
                        response4.sendToTarget();
                    } else {
                        logd("EVENT_UPDATE_SNE_DONE response is null efid:0x" + Integer.toHexString(efid6).toUpperCase());
                    }
                }
                break;
        }
    }

    public ArrayList<String> loadAasFromUsim() {
        return this.mUniUsimPhoneBookManager.loadAasFromUsim();
    }

    public int updateAasBySearch(String oldAas, String newAas) {
        ArrayList<String> oldAasList = this.mUniUsimPhoneBookManager.loadAasFromUsim();
        if (oldAasList == null) {
            logd("Aas list not exist");
            return -1;
        }
        int index = -1;
        int count = 1;
        Iterator<String> it = oldAasList.iterator();
        while (it.hasNext()) {
            if (oldAas.equals(it.next())) {
                index = count;
                break;
            }
            count++;
        }
        if (index == -1) {
            logd("Aas record don't exist for " + oldAas);
            return -12;
        }
        int aasEfId = this.mUniUsimPhoneBookManager.findEFAasInfo();
        logd("Aas aasEfId == " + aasEfId);
        int[] aasSize = getRecordsSizeByEf(aasEfId);
        if (aasSize == null) {
            return -1;
        }
        byte[] data = gasToByte(newAas, aasSize[0]);
        if (data == null) {
            logd("data == null");
            return -11;
        }
        new UniAdnRecordLoader(this.mFh).updateEFGasToUsim(aasEfId, index, data, null);
        this.mUniUsimPhoneBookManager.updateAasList(newAas, index);
        return index;
    }

    public int updateAasByIndex(String newAas, int aasIndex) {
        int aasEfId = this.mUniUsimPhoneBookManager.findEFAasInfo();
        int[] aasSize = getRecordsSizeByEf(aasEfId);
        if (aasSize == null) {
            return -1;
        }
        byte[] data = gasToByte(newAas, aasSize[0]);
        if (data == null) {
            logd("data == null");
            return -11;
        }
        new UniAdnRecordLoader(this.mFh).updateEFGasToUsim(aasEfId, aasIndex, data, null);
        this.mUniUsimPhoneBookManager.updateAasList(newAas, aasIndex);
        return aasIndex;
    }

    private String[] getSubjectAasString(int type, UniAdnRecord adn) {
        switch (type) {
            case 1:
                String[] s1 = getAnrNumGroup(adn.mAas);
                return s1;
            default:
                return null;
        }
    }

    public int getSneSize() {
        return this.mUniUsimPhoneBookManager.getSneSize();
    }

    public int[] getSneLength() {
        return this.mUniUsimPhoneBookManager.getSneLength();
    }

    public int[] getEFAdnRecordSize() {
        return new UniAdnRecordLoader(this.mFh).getRecordsSize(28474);
    }

    private boolean checkAnrLength(UniAdnRecord newAdn) {
        String[] ret = null;
        if (!TextUtils.isEmpty(newAdn.mAnr)) {
            ret = (newAdn.mAnr + "1").split(";");
            ret[ret.length - 1] = ret[ret.length - 1].substring(0, ret[ret.length - 1].length() - 1);
        }
        if (ret == null) {
            return true;
        }
        for (String anr : ret) {
            logd("checkAnrLength anr = " + anr);
            if (anr.length() > 20) {
                return false;
            }
        }
        return true;
    }

    private void logd(String msg) {
        UniPhoneBookLog.d(TAG, msg);
    }

    private void logi(String msg) {
        UniPhoneBookLog.i(TAG, msg);
    }

    private void loge(String msg) {
        UniPhoneBookLog.e(TAG, msg);
    }
}
