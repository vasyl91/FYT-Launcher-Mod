package com.android.internal.telephony.data;

import android.R;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.telephony.SubscriptionManager;
import android.text.TextUtils;
import com.android.internal.telephony.Phone;
import com.android.unisoc.telephony.RadioInteractor;
import com.android.unisoc.telephony.RadioInteractorListener;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class ClearCodeRetryController extends Handler {
    private static final int EVENT_DATA_SETUP_RETRY = 2002;
    private static final int EVENT_RADIO_OFF_OR_NOT_AVAILABLE = 2008;
    private static final int EVENT_RAU_SUCCESS = 2001;
    private static final int EVENT_SERVICE_STATE_CHANGED = 2017;
    private static final int IDLE = 0;
    private static final int MAX_PDN_REJ_TIMES = 3;
    private static final int MAX_PDN_REJ_TIMES_FOR_VOLTE = 1;
    private static final String NON_VOLTE_CLEAR_CODE = "non-volte";
    public static final int RETRY_DELAY_LONG = 45000;
    public static final int RETRY_DELAY_SHORT = 10000;
    public static final int RETRY_FROM_FAILURE_DELAY = 7200000;
    private static final int SWITCHING_TO_3G = 1;
    private static final int SWITCHING_TO_4G = 2;
    private static final int SWITCH_TIMEOUT = 40000;
    private static final String TAG = "ClearCode";
    private static final int VENDOR_BASE = 2000;
    private static final String VOLTE_CLEAR_CODE = "volte";
    private UniDataRetryManager mDrm;
    private Phone mPhone;
    private RadioInteractorListener mRadioInteractorListener;
    private RadioInteractor mRi;
    private int mState = 0;
    private boolean mLteDisabled = false;
    private String mClearCodeConfig = null;

    public ClearCodeRetryController(Phone phone, UniDataRetryManager Drm) {
        this.mPhone = phone;
        this.mDrm = Drm;
        log("ClearCodeRetryController.constructor");
    }

    public void dispose() {
        log("ClearCodeRetryController.dispose()");
        this.mPhone.mCi.unregisterForOn(this);
    }

    @Override // android.os.Handler
    public void handleMessage(Message msg) {
        switch (msg.what) {
            case EVENT_RAU_SUCCESS /* 2001 */:
                log("EVENT_RAU_SUCCESS");
                onDataConnectionRau();
                break;
            case EVENT_DATA_SETUP_RETRY /* 2002 */:
                log("EVENT_DATA_SETUP_RETRY");
                this.mDrm.dataSetupRetry();
                break;
            case EVENT_RADIO_OFF_OR_NOT_AVAILABLE /* 2008 */:
                log("EVENT_RADIO_OFF_OR_NOT_AVAILABLE");
                this.mDrm.clearPreFailCause();
                this.mState = 0;
                break;
            case EVENT_SERVICE_STATE_CHANGED /* 2017 */:
                log("EVENT_SERVICE_STATE_CHANGED");
                AsyncResult ar = (AsyncResult) msg.obj;
                if (ar.exception == null && ar.result != null) {
                    ServiceState state = (ServiceState) ar.result;
                    log("EVENT_SERVICE_STATE_CHANGED state: " + state.toString());
                    int voiceNetType = state.getVoiceNetworkType();
                    int voiceRegState = state.getVoiceRegState();
                    log("onServiceStateChanged voiceNetType=" + voiceNetType + " voiceRegState=" + voiceRegState);
                    handleVoiceServiceChange(voiceNetType, voiceRegState);
                    break;
                }
                break;
        }
    }

    public void handleRadioOn() {
        log("EVENT_RADIO_ON");
        this.mDrm.clearPreFailCause();
        this.mState = 0;
        if (this.mLteDisabled || ((isNonVolteClearCode() && this.mDrm.getFailCount() >= 3) || (isVolteClearCode() && this.mDrm.getFailCount() >= 1))) {
            enableLte(true);
        }
        if (isVolteClearCode()) {
            this.mDrm.stopFailRetryAlarm();
        }
    }

    public void notifyRadioOffOrNotAvailable() {
        sendMessage(obtainMessage(EVENT_RADIO_OFF_OR_NOT_AVAILABLE));
    }

    public void switchTo3G() {
        log("Start switching to 3G...");
        dataConnectionAttach(false);
        enableLte(false);
        this.mState = 1;
        this.mPhone.registerForServiceStateChanged(this, EVENT_SERVICE_STATE_CHANGED, (Object) null);
        log("switching to 3G registerForServiceStateChanged");
    }

    public void handleDataServiceChange(int rat, int regState) {
        log("Data RAT=" + rat + ", regState=" + regState + ", mState = " + this.mState);
        int i = this.mState;
        if (i == 1) {
            if (rat != 14 && regState == 0) {
                log("3G in service, clearPreFailCause");
                this.mDrm.clearPreFailCause();
                this.mState = 0;
                return;
            }
            return;
        }
        if (i == 2 && rat == 14 && regState == 0) {
            log("4G in service, clearPreFailCause");
            this.mDrm.clearPreFailCause();
            this.mState = 0;
            removeMessages(EVENT_DATA_SETUP_RETRY);
        }
    }

    public void handleVoiceServiceChange(int rat, int regState) {
        log("handleVoiceServiceChange ");
        if (rat != 13 && regState == 0) {
            log("Voice registerd on " + rat + ", switching to 3G completed");
            dataConnectionAttach(true);
            this.mPhone.unregisterForServiceStateChanged(this);
        }
    }

    public void restartForChanged(String reason) {
        log("restartForChanged ");
        restartCycle(reason);
        this.mDrm.stopFailRetryAlarm();
    }

    private void onDataConnectionRau() {
        restartForChanged("RoutingAreaUpdate");
    }

    public void restartCycle(Object obj) {
        log("restartCycle: " + obj + ", mLteDisabled = " + this.mLteDisabled + ", mDrm.getFailCount = " + this.mDrm.getFailCount());
        this.mState = 0;
        this.mDrm.clearPreFailCause();
        if (this.mLteDisabled || ((isNonVolteClearCode() && this.mDrm.getFailCount() >= 3) || (isVolteClearCode() && this.mDrm.getFailCount() >= 1))) {
            enableLte(true);
            this.mState = 2;
            log("sendMessageDelayed : EVENT_DATA_SETUP_RETRY");
            sendMessageDelayed(obtainMessage(EVENT_DATA_SETUP_RETRY), 40000L);
            return;
        }
        log("sendMessage : EVENT_DATA_SETUP_RETRY");
        sendMessage(obtainMessage(EVENT_DATA_SETUP_RETRY));
    }

    private void enableLte(boolean enable) {
        log("enableLte : enable " + enable);
        this.mLteDisabled = !enable;
        RadioInteractor radioInteractor = this.mRi;
        if (radioInteractor == null) {
            return;
        }
        radioInteractor.setLteEnabled(enable, this.mPhone.getPhoneId());
    }

    private void dataConnectionAttach(boolean attach) {
        log("dataConnectionAttach : attach " + attach);
        RadioInteractor radioInteractor = this.mRi;
        if (radioInteractor == null) {
            return;
        }
        radioInteractor.attachDataConn(attach, this.mPhone.getPhoneId());
    }

    public boolean supportSpecialClearCode() {
        return isVolteClearCode() || isNonVolteClearCode();
    }

    public boolean isVolteClearCode() {
        if (isGetResourceForClearCode() && VOLTE_CLEAR_CODE.equals(this.mClearCodeConfig)) {
            return true;
        }
        return false;
    }

    public boolean isNonVolteClearCode() {
        if (isGetResourceForClearCode() && NON_VOLTE_CLEAR_CODE.equals(this.mClearCodeConfig)) {
            return true;
        }
        return false;
    }

    private boolean isGetResourceForClearCode() {
        this.mClearCodeConfig = SubscriptionManager.getResourcesForSubId(this.mPhone.getContext(), this.mPhone.getSubId()).getString(135004177);
        if (SubscriptionManager.isValidSubscriptionId(this.mPhone.getSubId()) && !TextUtils.isEmpty(this.mClearCodeConfig)) {
            return true;
        }
        return false;
    }

    public boolean isSpecialCode(int fc) {
        if (supportSpecialClearCode()) {
            return fc == 29 || fc == 33;
        }
        return false;
    }

    public void userNotification(int cause) {
        int res = -1;
        if (cause == 29) {
            res = 135004231;
        } else if (cause == 33) {
            res = 135004230;
        }
        if (res == -1) {
            return;
        }
        AlertDialog errorDialog = new AlertDialog.Builder(this.mPhone.getContext(), 5).setMessage(res).setPositiveButton(R.string.ok, (DialogInterface.OnClickListener) null).create();
        errorDialog.getWindow().setType(EVENT_RADIO_OFF_OR_NOT_AVAILABLE);
        errorDialog.setCanceledOnTouchOutside(false);
        if (errorDialog != null) {
            errorDialog.show();
        }
    }

    public void registerRadioInteractor() {
        if (this.mRi != null) {
            return;
        }
        this.mRi = new RadioInteractor(this.mPhone.getContext());
        this.mRadioInteractorListener = new RadioInteractorListener(this.mPhone.getPhoneId()) { // from class: com.android.internal.telephony.data.ClearCodeRetryController.1
            public void onRauSuccessEvent() {
                ClearCodeRetryController.this.sendEmptyMessage(ClearCodeRetryController.EVENT_RAU_SUCCESS);
            }
        };
        this.mRi.enableRauNotify(this.mPhone.getPhoneId());
        log("enableRauNotify() done");
        this.mRi.listen(this.mRadioInteractorListener, 4096, true);
    }

    private void log(String s) {
        Rlog.d(TAG, "[" + this.mPhone.getPhoneId() + "]" + s);
    }
}
