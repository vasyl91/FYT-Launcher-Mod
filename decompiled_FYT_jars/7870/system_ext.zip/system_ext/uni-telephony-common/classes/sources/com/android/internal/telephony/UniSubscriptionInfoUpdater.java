package com.android.internal.telephony;

import android.content.ContentValues;
import android.content.Context;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.telephony.Rlog;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import com.android.internal.telephony.uicc.IccUtils;
import com.android.internal.telephony.uicc.UiccCard;
import com.android.internal.telephony.uicc.UiccController;
import com.android.internal.telephony.uicc.UiccPort;
import com.android.internal.telephony.uicc.UiccSlot;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniSubscriptionInfoUpdater extends SubscriptionInfoUpdater {
    private static final boolean DBG = true;
    private static final int EVENT_SIM_IMSI = 11;
    private static final String ICCID_STRING_FOR_NO_SIM = "";
    private static final String LOG_TAG = "UniSubscriptionInfoUpdater";
    private static ClientIdController mClientIdController;
    protected boolean[] mIsRecordUpdateRequired;
    private SubscriptionManager mSubscriptionManager;
    private static Context sContext = null;
    private static boolean sIsSubInfoInitialized = false;
    private static final int SUPPORTED_MODEM_COUNT = TelephonyManager.getDefault().getSupportedModemCount();
    protected static UniSubscriptionInfoUpdater sInstance = null;

    static UniSubscriptionInfoUpdater init(Looper looper, Context context, SubscriptionController sc) {
        UniSubscriptionInfoUpdater uniSubscriptionInfoUpdater;
        synchronized (UniSubscriptionInfoUpdater.class) {
            if (sInstance == null) {
                sInstance = new UniSubscriptionInfoUpdater(looper, context, sc);
            } else {
                Log.wtf(LOG_TAG, "init() called multiple times!  sInstance = " + sInstance);
            }
            uniSubscriptionInfoUpdater = sInstance;
        }
        return uniSubscriptionInfoUpdater;
    }

    public static UniSubscriptionInfoUpdater getInstance() {
        if (sInstance == null) {
            Log.wtf(LOG_TAG, "getInstance null");
        }
        return sInstance;
    }

    private UniSubscriptionInfoUpdater(Looper looper, Context context, SubscriptionController sc) {
        super(looper, context, sc);
        this.mSubscriptionManager = null;
        sContext = context;
        this.mIsRecordUpdateRequired = new boolean[SUPPORTED_MODEM_COUNT];
        this.mSubscriptionManager = SubscriptionManager.from(context);
        for (int index = 0; index < SUPPORTED_MODEM_COUNT; index++) {
            this.mIsRecordUpdateRequired[index] = DBG;
        }
        if (context.getResources().getBoolean(134414344)) {
            mClientIdController = ClientIdController.init(context);
        }
    }

    public void updateInternalIccState(String simStatus, String reason, int phoneId) {
        ClientIdController clientIdController;
        super.updateInternalIccState(simStatus, reason, phoneId);
        if (phoneId == 0 && (clientIdController = mClientIdController) != null) {
            clientIdController.updateInternalIccState(simStatus);
        }
    }

    public void handleMessage(Message msg) {
        logd("handleMessage msg.what : " + msg.what);
        switch (msg.what) {
            case 11:
                handleIMSIReady(msg.arg1);
                break;
            default:
                super.handleMessage(msg);
                break;
        }
    }

    protected void handleIMSIReady(int phoneId) {
        List<Integer> cardIds = new ArrayList<>();
        logd("handleImsiReady: phoneId: " + phoneId);
        if (sIccId[phoneId] != null && sIccId[phoneId].equals(ICCID_STRING_FOR_NO_SIM)) {
            logd(" SIM" + (phoneId + 1) + " hot plug in");
            sIccId[phoneId] = null;
        }
        UiccCard uiccCard = UiccController.getInstance().getUiccCard(phoneId);
        if (uiccCard == null) {
            logd("handleImsiReady: uiccCard null");
            return;
        }
        UiccPort uiccPort = uiccCard.getUiccPortForPhone(phoneId);
        if (uiccPort == null) {
            logd("handleImsiReady: uiccPort null");
            return;
        }
        String iccId = uiccPort.getIccId();
        if (TextUtils.isEmpty(iccId)) {
            logd("handleImsiReady: IccID null");
            return;
        }
        sIccId[phoneId] = IccUtils.stripTrailingFs(iccId);
        updateSubscriptionInfoByIccId(phoneId, DBG);
        cardIds.add(Integer.valueOf(getCardIdFromPhoneId(phoneId)));
        updateEmbeddedSubscriptions(cardIds, new SubscriptionInfoUpdater.UpdateEmbeddedSubsCallback() { // from class: com.android.internal.telephony.UniSubscriptionInfoUpdater$$ExternalSyntheticLambda0
            public final void run(boolean z) {
                UniSubscriptionInfoUpdater.lambda$handleIMSIReady$0(z);
            }
        });
        broadcastSimStateChanged(phoneId, "IMSI", null);
    }

    static /* synthetic */ void lambda$handleIMSIReady$0(boolean hasChanges) {
        if (hasChanges) {
            SubscriptionController.getInstance().notifySubscriptionInfoChanged();
        }
    }

    protected synchronized void updateSubscriptionInfoByIccId(int phoneId, boolean updateEmbeddedSubs) {
        logd("updateSubscriptionInfoByIccId mIsRecordUpdateRequired[phoneId] : " + this.mIsRecordUpdateRequired[phoneId] + "for phoneId : " + phoneId);
        if (this.mIsRecordUpdateRequired[phoneId]) {
            logd("updateSubscriptionInfoByIccId:+ Start - phoneId: " + phoneId);
            if (!SubscriptionManager.isValidPhoneId(phoneId)) {
                logd("[updateSubscriptionInfoByIccId]- invalid phoneId=" + phoneId);
                return;
            }
            logd("updateSubscriptionInfoByIccId: removing subscription info record: phoneId " + phoneId);
            SubscriptionController.getInstance().clearSubInfoRecord(phoneId);
            boolean isSameIccId = false;
            if (!ICCID_STRING_FOR_NO_SIM.equals(sIccId[phoneId]) && sIccId[phoneId] != null) {
                for (int i = 0; i < SUPPORTED_MODEM_COUNT; i++) {
                    if (i != phoneId && TextUtils.equals(sIccId[i], sIccId[phoneId])) {
                        this.mSubscriptionManager.addSubscriptionInfoRecord(sIccId[i] + Integer.toString(phoneId), phoneId);
                        sIccId[phoneId] = sIccId[i] + Integer.toString(phoneId);
                        isSameIccId = DBG;
                        logd("SUB" + (i + 1) + " has invalid IccId");
                    }
                }
                if (!isSameIccId) {
                    logd("updateSubscriptionInfoByIccId: adding subscription info record: iccid: " + UniTeleUtils.getIccidForLogging(sIccId[phoneId]) + " phoneId:" + phoneId);
                    this.mSubscriptionManager.addSubscriptionInfoRecord(sIccId[phoneId], phoneId);
                    SubscriptionInfo info = SubscriptionController.getInstance().getSubInfoForIccId(sIccId[phoneId]);
                    if (!TextUtils.isEmpty(info.getMccString()) && !TextUtils.isEmpty(info.getMncString())) {
                        String operator = info.getMccString() + info.getMncString();
                        String simOperator = Settings.Global.getString(sContext.getContentResolver(), "mobile_icc_operator_numeric" + phoneId);
                        logd("addSubInfo operator " + operator + " simOperator " + simOperator);
                        Settings.Global.putString(sContext.getContentResolver(), "mobile_icc_operator_numeric" + phoneId, operator);
                        sContext.getContentResolver().notifyChange(Settings.Global.getUriFor("mobile_icc_operator_numeric" + phoneId), null, DBG, -1);
                    }
                }
            }
            List<SubscriptionInfo> subInfos = SubscriptionController.getInstance().getSubInfoUsingSlotIndexPrivileged(phoneId);
            if (subInfos != null) {
                boolean changed = false;
                for (int i2 = 0; i2 < subInfos.size(); i2++) {
                    SubscriptionInfo temp = subInfos.get(i2);
                    ContentValues value = new ContentValues(1);
                    String msisdn = TelephonyManager.getDefault().getLine1Number(temp.getSubscriptionId());
                    if (!TextUtils.equals(msisdn, temp.getNumber())) {
                        value.put("number", msisdn);
                        sContext.getContentResolver().update(SubscriptionManager.getUriForSubscriptionId(temp.getSubscriptionId()), value, null, null);
                        changed = DBG;
                    }
                }
                if (changed) {
                    SubscriptionController.getInstance().refreshCachedActiveSubscriptionInfoList();
                }
            }
            if (isAllIccIdQueryDone()) {
                setSubInfoInitialized();
            }
            UiccController uiccController = UiccController.getInstance();
            UiccSlot[] uiccSlots = uiccController.getUiccSlots();
            if (uiccSlots != null && updateEmbeddedSubs) {
                List<Integer> cardIds = new ArrayList<>();
                for (UiccSlot uiccSlot : uiccSlots) {
                    if (uiccSlot != null && uiccSlot.getUiccCard() != null) {
                        int cardId = uiccController.convertToPublicCardId(uiccSlot.getUiccCard().getCardId());
                        cardIds.add(Integer.valueOf(cardId));
                    }
                }
                updateEmbeddedSubscriptions(cardIds, new SubscriptionInfoUpdater.UpdateEmbeddedSubsCallback() { // from class: com.android.internal.telephony.UniSubscriptionInfoUpdater$$ExternalSyntheticLambda1
                    public final void run(boolean z) {
                        UniSubscriptionInfoUpdater.lambda$updateSubscriptionInfoByIccId$1(z);
                    }
                });
            }
            SubscriptionController.getInstance().notifySubscriptionInfoChanged();
            logd("updateSubscriptionInfoByIccId: SubscriptionInfo update complete");
        } else {
            Rlog.d(LOG_TAG, "Ignoring subscription update event " + phoneId);
            this.mIsRecordUpdateRequired[phoneId] = DBG;
        }
    }

    static /* synthetic */ void lambda$updateSubscriptionInfoByIccId$1(boolean hasChanges) {
        if (hasChanges) {
            SubscriptionController.getInstance().notifySubscriptionInfoChanged();
        }
        logd("updateSubscriptionInfoByIccId: SubscriptionInfo update complete");
    }

    private static void setSubInfoInitialized() {
        if (!sIsSubInfoInitialized) {
            logd("SubInfo Initialized");
            sIsSubInfoInitialized = DBG;
            SubscriptionController.getInstance().notifySubInfoReady();
            MultiSimSettingController.getInstance().notifyAllSubscriptionLoaded();
        }
    }

    public static boolean isSubInfoInitialized() {
        return sIsSubInfoInitialized;
    }

    private static void logd(String message) {
        Rlog.d(LOG_TAG, message);
    }
}
