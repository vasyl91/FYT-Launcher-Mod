package com.android.internal.telephony.uicc;

import android.R;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.os.Registrant;
import android.os.RegistrantList;
import android.os.SystemProperties;
import android.provider.Settings;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import android.telephony.SubscriptionInfo;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.MccTable;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.PhoneFactory;
import com.android.internal.telephony.PhoneLogController;
import com.android.internal.telephony.gsm.SimTlv;
import com.android.internal.telephony.phonebook.UniAdnRecord;
import com.android.internal.telephony.phonebook.UniAdnRecordCache;
import com.android.unisoc.telephony.RadioInteractor;
import com.android.unisoc.telephony.iccIOFileControl.ExUniIccIoResult;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniSIMRecords extends SIMRecords {
    private static final int CFIS_ADN_CAPABILITY_ID_OFFSET = 14;
    private static final int CFIS_ADN_EXTENSION_ID_OFFSET = 15;
    private static final int CFIS_BCD_NUMBER_LENGTH_OFFSET = 2;
    private static final int CFIS_TON_NPI_OFFSET = 3;
    private static final int CPHS_SST_MBN_ENABLED = 48;
    private static final int CPHS_SST_MBN_MASK = 48;
    private static final int EVENT_APP_LOCKED = 258;
    private static final int EVENT_APP_NETWORK_LOCKED = 259;
    private static final int EVENT_GET_AD_DONE = 9;
    private static final int EVENT_GET_ALL_ICC_FILE = 500;
    private static final int EVENT_GET_CFF_DONE = 24;
    private static final int EVENT_GET_CFIS_DONE = 32;
    private static final int EVENT_GET_CPHS_MAILBOX_DONE = 11;
    private static final int EVENT_GET_CSP_CPHS_DONE = 33;
    private static final int EVENT_GET_EHPLMN_DONE = 40;
    private static final int EVENT_GET_EXTENDED_ICCID_DONE = 1000;
    private static final int EVENT_GET_FPLMN_DONE = 41;
    private static final int EVENT_GET_GID1_DONE = 34;
    private static final int EVENT_GET_GID2_DONE = 36;
    private static final int EVENT_GET_HPLMN_W_ACT_DONE = 39;
    private static final int EVENT_GET_ICCID_DONE = 4;
    private static final int EVENT_GET_IMSI_DONE = 3;
    private static final int EVENT_GET_INFO_CPHS_DONE = 26;
    private static final int EVENT_GET_MBDN_DONE = 6;
    private static final int EVENT_GET_MBI_DONE = 5;
    private static final int EVENT_GET_MSISDN_DONE = 10;
    private static final int EVENT_GET_MWIS_DONE = 7;
    private static final int EVENT_GET_PNN_DONE = 15;
    private static final int EVENT_GET_SPDI_DONE = 13;
    private static final int EVENT_GET_SPN_DONE = 12;
    private static final int EVENT_GET_SST_DONE = 17;
    private static final int EVENT_GET_VOICE_MAIL_INDICATOR_CPHS_DONE = 8;
    private static final int EVENT_SET_CPHS_MAILBOX_DONE = 25;
    private static final int EVENT_SET_MBDN_DONE = 20;
    private static final int EVENT_UPDATE_DONE = 14;
    static final int IMSI = 65535;
    protected static final String LOG_TAG = "UniSIMRecords";
    protected static final int RESPONSE_DATA_FILE_SIZE_1 = 2;
    protected static final int RESPONSE_DATA_FILE_SIZE_2 = 3;
    protected static final int RESPONSE_DATA_RECORD_LENGTH = 14;
    private static final int SIM_RECORD_EVENT_BASE = 0;
    private static final int SYSTEM_EVENT_BASE = 256;
    private static boolean mDealAllSimFiles;
    private static boolean mFetchAllSimFilesOnce = SystemProperties.getBoolean("persist.radio.sim.allfile", false);
    private int mCallForwardingStatus;
    private byte[] mCphsInfo;
    boolean mCspPlmnEnabled;
    byte[] mEfCPHS_MWI;
    byte[] mEfCff;
    byte[] mEfCfis;
    byte[] mEfLi;
    byte[] mEfMWIS;
    byte[] mEfPl;
    ExUniIccIoResult[] mExUniIccIoResult_list;
    protected boolean mNonKeyRecordsLoaded;
    protected Phone mPhone;
    protected int mPhoneId;
    private RadioInteractor mRadioInteractor;
    protected RoamingBroker mRb;
    protected RegistrantList mRecordsKeyInfoLoadedRegistrants;
    private GetSpnFsmState mSpnState;
    public UniAdnRecordCache mUniAdnCache;
    UniUsimServiceTable mUsimServiceTable;
    UniVoiceMailConstants mVmConfig;

    private enum GetSpnFsmState {
        IDLE,
        INIT,
        READ_SPN_3GPP,
        READ_SPN_CPHS,
        READ_SPN_SHORT_CPHS
    }

    public UniSIMRecords(UiccCardApplication app, Context c, CommandsInterface ci) {
        super(app, c, ci);
        this.mRecordsKeyInfoLoadedRegistrants = new RegistrantList();
        this.mCallForwardingStatus = -1;
        this.mEfLi = null;
        this.mEfPl = null;
        this.mEfCfis = null;
        this.mEfCff = null;
        this.mCphsInfo = null;
        this.mRadioInteractor = new RadioInteractor(this.mContext);
        this.mEfMWIS = null;
        this.mEfCPHS_MWI = null;
        this.mCspPlmnEnabled = true;
        this.mRb = null;
        this.mNonKeyRecordsLoaded = false;
        this.mVmConfig = new UniVoiceMailConstants();
        int phoneId = this.mParentApp.getPhoneId();
        this.mPhoneId = phoneId;
        this.mPhone = PhoneFactory.getPhone(phoneId);
        if (!isWifiOnly() && !isDataOnly()) {
            this.mRb = RoamingBroker.getInstance();
        }
        this.mUniAdnCache = new UniAdnRecordCache(this.mFh);
    }

    public void setVoiceMailNumber(String alphaTag, String voiceNumber, Message onComplete) {
        if (this.mDestroyed.get()) {
            return;
        }
        if (this.mIsVoiceMailFixed) {
            AsyncResult.forMessage(onComplete).exception = new IccVmFixedException("Voicemail number is fixed by operator");
            onComplete.sendToTarget();
            return;
        }
        this.mNewVoiceMailNum = voiceNumber;
        this.mNewVoiceMailTag = alphaTag;
        UniAdnRecord adn = new UniAdnRecord(this.mNewVoiceMailTag, this.mNewVoiceMailNum);
        if (this.mMailboxIndex != 0 && this.mMailboxIndex != 255) {
            new UniAdnRecordLoader(this.mFh).updateEF(adn, 28615, 28616, this.mMailboxIndex, null, obtainMessage(EVENT_SET_MBDN_DONE, onComplete));
        } else {
            if (isCphsMailboxEnabled()) {
                new UniAdnRecordLoader(this.mFh).updateEF(adn, 28439, 28490, 1, null, obtainMessage(EVENT_SET_CPHS_MAILBOX_DONE, onComplete));
                return;
            }
            AsyncResult.forMessage(onComplete).exception = new IccVmNotSupportedException("Update SIM voice mailbox error");
            onComplete.sendToTarget();
        }
    }

    public void handleMessage(Message msg) {
        boolean isRecordLoadResponse = false;
        if (this.mDestroyed.get()) {
            loge("Received message " + msg + "[" + msg.what + "]  while being destroyed. Ignoring.");
            return;
        }
        switch (msg.what) {
            case 4:
                isRecordLoadResponse = true;
                AsyncResult ar = (AsyncResult) msg.obj;
                byte[] data = (byte[]) ar.result;
                if (ar.exception != null) {
                    log("Get iccid occur exception, set default value");
                    this.mFullIccId = String.format("%020d", 0);
                    String uiccSlotIccid = getExtraIccId();
                    if (!TextUtils.isEmpty(uiccSlotIccid) && !uiccSlotIccid.matches("(F|f){20}")) {
                        this.mFullIccId = uiccSlotIccid;
                    }
                    this.mIccId = this.mFullIccId;
                } else {
                    this.mFullIccId = IccUtils.bchToString(data, 0, data.length);
                    if (this.mFullIccId.matches("(F|f){20}")) {
                        this.mFullIccId = String.format("%020d", 0);
                    }
                    this.mIccId = this.mFullIccId;
                    RoamingBroker roamingBroker = this.mRb;
                    if (roamingBroker != null) {
                        roamingBroker.updateIccIds(this.mPhoneId, this.mIccId);
                    }
                    log("iccid: " + SubscriptionInfo.givePrintableIccid(this.mFullIccId));
                }
                break;
            case 10:
                isRecordLoadResponse = true;
                AsyncResult ar2 = (AsyncResult) msg.obj;
                if (ar2.exception != null) {
                    log("Invalid or missing EF[MSISDN]");
                } else {
                    UniAdnRecord adn = (UniAdnRecord) ar2.result;
                    this.mMsisdn = adn.getNumber();
                    this.mMsisdnTag = adn.getAlphaTag();
                    log("MSISDN: " + Rlog.pii(LOG_TAG, this.mMsisdn));
                }
                break;
            case 12:
                isRecordLoadResponse = true;
                getSpnFsm(false, (AsyncResult) msg.obj);
                break;
            case EVENT_GET_INFO_CPHS_DONE /* 26 */:
                isRecordLoadResponse = true;
                AsyncResult ar3 = (AsyncResult) msg.obj;
                if (ar3.exception == null) {
                    this.mCphsInfo = (byte[]) ar3.result;
                    log("iCPHS: " + IccUtils.bytesToHexString(this.mCphsInfo));
                }
                break;
            case EVENT_GET_CFIS_DONE /* 32 */:
                isRecordLoadResponse = true;
                AsyncResult ar4 = (AsyncResult) msg.obj;
                byte[] data2 = (byte[]) ar4.result;
                if (ar4.exception != null) {
                    this.mEfCfis = null;
                } else {
                    log("EF_CFIS: " + IccUtils.bytesToHexString(data2));
                    this.mEfCfis = data2;
                }
                break;
            case EVENT_APP_LOCKED /* 258 */:
                this.mLockedRecordsReqReason = 1;
                onLocked(msg.what);
                break;
            case EVENT_APP_NETWORK_LOCKED /* 259 */:
                this.mLockedRecordsReqReason = 2;
                onLocked(msg.what);
                break;
            case EVENT_GET_ALL_ICC_FILE /* 500 */:
                log("[ALL SIM FILES] handle EVENT_GET_ALL_ICC_FILE");
                AsyncResult ar5 = (AsyncResult) msg.obj;
                this.mExUniIccIoResult_list = (ExUniIccIoResult[]) ar5.result;
                if (ar5.exception != null) {
                    log("EVENT_GET_ALL_ICC_FILE ar.exception :" + ar5.exception);
                    log("EVENT_GET_ALL_ICC_FILE exception, call fetchSimRecords Original.");
                    mDealAllSimFiles = false;
                    fetchSimRecords();
                } else {
                    onAllFileObtained();
                }
                break;
            case EVENT_GET_EXTENDED_ICCID_DONE /* 1000 */:
                isRecordLoadResponse = true;
                this.mFullIccId = (String) msg.obj;
                if (!TextUtils.isEmpty(this.mFullIccId) && this.mFullIccId.matches("(F|f){20}")) {
                    this.mFullIccId = String.format("%020d", 0);
                }
                this.mIccId = this.mFullIccId;
                RoamingBroker roamingBroker2 = this.mRb;
                if (roamingBroker2 != null) {
                    roamingBroker2.updateIccIds(this.mPhoneId, this.mIccId);
                }
                log("extend iccid: " + SubscriptionInfo.givePrintableIccid(this.mFullIccId));
                break;
            default:
                super.handleMessage(msg);
                break;
        }
        if (isRecordLoadResponse) {
            log("onRecordLoaded !!");
            onRecordLoaded();
        }
    }

    public void registerForKeyInfoRecordsLoaded(Handler h, int what, Object obj) {
        Registrant r = new Registrant(h, what, obj);
        this.mRecordsKeyInfoLoadedRegistrants.add(r);
    }

    public void unregisterForKeyInfoRecordsLoaded(Handler h) {
        this.mRecordsKeyInfoLoadedRegistrants.remove(h);
    }

    protected boolean getKeyInfoRecordsLoaded() {
        return this.mRecordsToLoad == 0 && !this.mNonKeyRecordsLoaded && this.mRecordsRequested;
    }

    private void onLocked(int msg) {
        this.mNonKeyRecordsLoaded = false;
        log("only fetch EF_LI, EF_PL and EF_ICCID in locked state");
        super.onLocked();
    }

    public void onReady() {
        fetchSimRecordsEnter();
    }

    protected void fetchSimRecordsEnter() {
        log("fetchSimRecords");
        if (mFetchAllSimFilesOnce) {
            fetchSimRecordsEx();
        } else {
            fetchSimRecords();
        }
    }

    protected void fetchSimRecordsEx() {
        log("[iccIOForAllFile] fetchSimRecordsEx ");
        mDealAllSimFiles = true;
        int phoneId = this.mParentApp.getPhoneId();
        this.mRadioInteractor.iccIOForAllFile(phoneId, obtainMessage(EVENT_GET_ALL_ICC_FILE));
    }

    private void onAllFileObtained() {
        log("[iccIOForAllFile] handle IMSI");
        dealWithSimFile(IMSI, getSimFileContent(IMSI));
        if (!mDealAllSimFiles) {
            return;
        }
        dealWithSimFile(28589, getSimFileContent(28589));
        dealWithSimFile(12258, getSimFileContent(12258));
        dealWithSimFile(28613, getSimFileContent(28613));
        dealWithSimFile(28478, getSimFileContent(28478));
        dealWithSimFile(28479, getSimFileContent(28479));
        getSpnFsmEx(true, null);
        log("[iccIOForAllFile] Key info has loaded");
        updateSimNumeric();
        this.mRecordsKeyInfoLoadedRegistrants.notifyRegistrants();
        dealWithSimFile(28480, getSimFileContent(28480));
        dealWithSimFile(28617, getSimFileContent(28617));
        dealWithSimFile(28618, getSimFileContent(28618));
        dealWithSimFile(28433, getSimFileContent(28433));
        dealWithSimFile(28619, getSimFileContent(28619));
        dealWithSimFile(28435, getSimFileContent(28435));
        dealWithSimFile(28621, getSimFileContent(28621));
        dealWithSimFile(UniIccConstants.EF_ESNME, getSimFileContent(UniIccConstants.EF_ESNME));
        dealWithSimFile(28438, getSimFileContent(28438));
        dealWithSimFile(28437, getSimFileContent(28437));
        dealWithSimFile(28514, getSimFileContent(28514));
        dealWithSimFile(28633, getSimFileContent(28633));
        dealWithSimFile(28539, getSimFileContent(28539));
        if (this.mParentApp.getType() == IccCardApplicationStatus.AppType.APPTYPE_USIM) {
            dealWithSimFile(28421, getSimFileContent(28421));
            dealWithSimFile(12037, getSimFileContent(12037));
        }
        dealWithSimFile(28476, getSimFileContent(28476));
        log("[iccIOForAllFile] deal with all sim files done.");
        onRecordLoadedEx();
    }

    protected void onRecordLoadedEx() {
        log("[iccIOForAllFile] onRecordLoadedEx.");
        this.mRecordsToLoad = 0;
        this.mRecordsRequested = true;
        if (getRecordsLoaded()) {
            onAllRecordsLoaded();
            return;
        }
        if (getLockedRecordsLoaded() || getNetworkLockedRecordsLoaded()) {
            onLockedAllRecordsLoaded();
        } else if (this.mRecordsToLoad < 0) {
            loge("recordsToLoad <0, programmer error suspected");
            this.mRecordsToLoad = 0;
        }
    }

    protected void fetchSimRecords() {
        this.mRecordsRequested = true;
        log("fetchSimRecords " + this.mRecordsToLoad);
        if (!this.mNonKeyRecordsLoaded) {
            this.mCi.getIMSIForApp(this.mParentApp.getAid(), obtainMessage(3));
            this.mRecordsToLoad++;
            this.mFh.loadEFTransparent(28589, obtainMessage(9));
            this.mRecordsToLoad++;
            sendMessage(obtainMessage(EVENT_GET_EXTENDED_ICCID_DONE, getExtraIccId()));
            this.mRecordsToLoad++;
            getSpnFsm(true, null);
            this.mFh.loadEFLinearFixedAll(28613, obtainMessage(15));
            this.mRecordsToLoad++;
            this.mFh.loadEFTransparent(28478, obtainMessage(EVENT_GET_GID1_DONE));
            this.mRecordsToLoad++;
            this.mFh.loadEFTransparent(28479, obtainMessage(EVENT_GET_GID2_DONE));
            this.mRecordsToLoad++;
        } else {
            new UniAdnRecordLoader(this.mFh).loadFromEF(28480, getExtFromEf(28480), 1, obtainMessage(10));
            this.mRecordsToLoad++;
            this.mFh.loadEFLinearFixed(28617, 1, obtainMessage(5));
            this.mRecordsToLoad++;
            this.mFh.loadEFLinearFixed(28618, 1, obtainMessage(7));
            this.mRecordsToLoad++;
            this.mFh.loadEFTransparent(28433, obtainMessage(8));
            this.mRecordsToLoad++;
            loadCallForwardingRecords();
            this.mFh.loadEFTransparent(28621, obtainMessage(13));
            this.mRecordsToLoad++;
            this.mFh.loadEFTransparent(UniIccConstants.EF_ESNME, obtainMessage(17));
            this.mRecordsToLoad++;
            this.mFh.loadEFTransparent(28438, obtainMessage(EVENT_GET_INFO_CPHS_DONE));
            this.mRecordsToLoad++;
            this.mFh.loadEFTransparent(28437, obtainMessage(EVENT_GET_CSP_CPHS_DONE));
            this.mRecordsToLoad++;
            this.mFh.loadEFTransparent(28514, obtainMessage(EVENT_GET_HPLMN_W_ACT_DONE));
            this.mRecordsToLoad++;
            this.mFh.loadEFTransparent(28633, obtainMessage(EVENT_GET_EHPLMN_DONE));
            this.mRecordsToLoad++;
            this.mFh.loadEFTransparent(28539, obtainMessage(EVENT_GET_FPLMN_DONE, 1238272, -1));
            this.mRecordsToLoad++;
            loadEfLiAndEfPl();
            this.mFh.getEFLinearRecordSize(28476, obtainMessage(28));
            this.mRecordsToLoad++;
        }
        log("fetchSimRecords " + this.mRecordsToLoad + " requested: " + this.mRecordsRequested);
    }

    private void dealWithSimFile(int efid, byte[] data) {
        if (mDealAllSimFiles) {
            switch (efid) {
                case 12037:
                    log("[dealWithSimFile] EF_PL LOADED");
                    if (data != null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    } else {
                        this.mEfLi = data;
                        log("[dealWithSimFile] EF_LI=" + IccUtils.bytesToHexString(this.mEfLi));
                        return;
                    }
                case 12258:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    } else {
                        if (data.length != 0) {
                            this.mFullIccId = IccUtils.bchToString(data, 0, data.length);
                            this.mIccId = this.mFullIccId;
                            log("[dealWithSimFile] iccid: " + SubscriptionInfo.givePrintableIccid(this.mFullIccId));
                            return;
                        }
                        return;
                    }
                case 28421:
                    IccRecords.IccRecordLoaded recordLoaded = new EfUsimLiLoaded();
                    log(recordLoaded.getEfName() + " LOADED");
                    if (data != null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    } else {
                        this.mEfLi = data;
                        log("[dealWithSimFile] EF_LI=" + IccUtils.bytesToHexString(this.mEfLi));
                        return;
                    }
                case 28433:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    } else {
                        log("[dealWithSimFile] EF_CPHS_MWI: " + IccUtils.bytesToHexString(data));
                        this.mEfCPHS_MWI = data;
                        return;
                    }
                case 28435:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        this.mEfCff = null;
                        return;
                    } else {
                        log("[dealWithSimFile] EF_CFF_CPHS: " + IccUtils.bytesToHexString(data));
                        this.mEfCff = data;
                        return;
                    }
                case 28436:
                case 28440:
                case 28486:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    } else {
                        log("[dealWithSimFile] SPN dealWithSimFile efid: " + efid);
                        getSpnFsmEx(false, data);
                        return;
                    }
                case 28437:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    } else {
                        log("[dealWithSimFile] EF_CSP: " + IccUtils.bytesToHexString(data));
                        handleEfCspData(data);
                        return;
                    }
                case 28438:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    } else {
                        this.mCphsInfo = data;
                        log("[dealWithSimFile] iCPHS: " + IccUtils.bytesToHexString(this.mCphsInfo));
                        return;
                    }
                case 28439:
                case 28615:
                    this.mVoiceMailNum = null;
                    this.mVoiceMailTag = null;
                    if (data == null) {
                        log("[dealWithSimFile] Invalid or missing EF" + (efid == 28439 ? "[MAILBOX]" : "[MBDN]"));
                        if (efid == 28615) {
                            dealWithSimFile(28439, getSimFileContent(28439));
                            return;
                        }
                        return;
                    }
                    AdnRecord adn = new AdnRecord(data);
                    log("[dealWithSimFile] VM: " + adn + (efid == 28439 ? " EF[MAILBOX]" : " EF[MBDN]"));
                    if (adn.isEmpty() && efid == 28615) {
                        dealWithSimFile(28439, getSimFileContent(28439));
                        return;
                    } else {
                        this.mVoiceMailNum = adn.getNumber();
                        this.mVoiceMailTag = adn.getAlphaTag();
                        return;
                    }
                case UniIccConstants.EF_ESNME /* 28472 */:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    } else {
                        this.mUsimServiceTable = new UniUsimServiceTable(data);
                        log("[dealWithSimFile] SST: " + this.mUsimServiceTable);
                        return;
                    }
                case 28476:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    }
                    try {
                        int[] recordSize = getRecordSize(data);
                        this.mSmsCountOnIcc = recordSize[2];
                        log("[dealWithSimFile] EVENT_GET_SMS_RECORD_SIZE_DONE Size " + recordSize[0] + " total " + recordSize[1] + " record " + recordSize[2]);
                        return;
                    } catch (ArrayIndexOutOfBoundsException exc) {
                        this.mSmsCountOnIcc = -1;
                        loge("[dealWithSimFile] ArrayIndexOutOfBoundsException in EVENT_GET_SMS_RECORD_SIZE_DONE: " + exc.toString());
                        return;
                    }
                case 28478:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    } else {
                        this.mGid1 = IccUtils.bytesToHexString(data);
                        log("[dealWithSimFile] GID1: " + this.mGid1);
                        return;
                    }
                case 28479:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    } else {
                        this.mGid2 = IccUtils.bytesToHexString(data);
                        log("[dealWithSimFile] GID2: " + this.mGid2);
                        return;
                    }
                case 28480:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    }
                    AdnRecord adn2 = new AdnRecord(data);
                    this.mMsisdn = adn2.getNumber();
                    this.mMsisdnTag = adn2.getAlphaTag();
                    log("[dealWithSimFile] MSISDN: " + Rlog.pii(LOG_TAG, this.mMsisdn));
                    return;
                case 28514:
                    if (data == null) {
                        loge("[dealWithSimFile] Failed getting Home PLMN with Access Tech Records");
                        return;
                    }
                    log("[dealWithSimFile] Received a PlmnActRecord, raw=" + IccUtils.bytesToHexString(data));
                    this.mHplmnActRecords = PlmnActRecord.getRecords(data);
                    log("[dealWithSimFile] HplmnActRecord[]=" + Arrays.toString(this.mHplmnActRecords));
                    return;
                case 28539:
                    if (data == null) {
                        loge("[dealWithSimFile] Failed getting Forbidden PLMNs, data is null.");
                        return;
                    } else {
                        this.mFplmns = parseBcdPlmnList(data, "Forbidden");
                        return;
                    }
                case 28589:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    }
                    log("[dealWithSimFile] EF_AD: " + IccUtils.bytesToHexString(data));
                    this.mMncLength = 0;
                    try {
                        Boolean isInTestMode = false;
                        if (!isInTestMode.booleanValue()) {
                            if (data.length < 3) {
                                log("Corrupt AD data on SIM");
                                return;
                            }
                            if (data.length == 3) {
                                log("MNC length not present in EF_AD");
                                return;
                            }
                            int len = data[3] & 15;
                            if (len == 2 || len == 3) {
                                this.mMncLength = len;
                            } else {
                                log("Received invalid or unset MNC Length=" + len);
                            }
                        }
                        return;
                    } finally {
                        updateOperatorPlmn();
                    }
                case 28613:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    }
                    SimTlv tlv = new SimTlv(data, 0, data.length);
                    while (tlv.isValidObject()) {
                        if (tlv.getTag() == 67 && tlv.getData().length != 0) {
                            this.mPnnHomeName = IccUtils.networkNameToString(tlv.getData(), 0, tlv.getData().length);
                            log("[dealWithSimFile] PNN: " + this.mPnnHomeName);
                            return;
                        }
                        tlv.nextObject();
                    }
                    return;
                case 28617:
                    boolean isValidMbdn = false;
                    if (data != null && data.length != 0) {
                        log("[dealWithSimFile] EF_MBI: " + IccUtils.bytesToHexString(data));
                        this.mMailboxIndex = data[0] & 255;
                        if (this.mMailboxIndex != 0 && this.mMailboxIndex != 255) {
                            log("Got valid mailbox number for MBDN");
                            isValidMbdn = true;
                        }
                    }
                    if (isValidMbdn) {
                        dealWithSimFile(28615, getSimFileContent(28615));
                        return;
                    } else {
                        dealWithSimFile(28439, getSimFileContent(28439));
                        return;
                    }
                case 28618:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    }
                    log("[dealWithSimFile] EF_MWIS : " + IccUtils.bytesToHexString(data));
                    if (data.length == 0 || (data[0] & 255) != 255) {
                        this.mEfMWIS = data;
                        return;
                    } else {
                        log("SIMRecords: Uninitialized record MWIS");
                        return;
                    }
                case 28619:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        this.mEfCfis = null;
                        return;
                    } else {
                        log("[dealWithSimFile] EF_CFIS: " + IccUtils.bytesToHexString(data));
                        this.mEfCfis = data;
                        return;
                    }
                case 28621:
                    if (data == null) {
                        log("dealWithSimFile efid: " + efid + ", data is null. ");
                        return;
                    } else {
                        parseEfSpdi(data);
                        return;
                    }
                case 28633:
                    if (data == null) {
                        loge("[dealWithSimFile] Failed getting Equivalent Home PLMNs. ");
                        return;
                    } else {
                        this.mEhplmns = parseBcdPlmnList(data, "Equivalent Home");
                        return;
                    }
                case IMSI /* 65535 */:
                    if (data != null) {
                        log("[dealWithSimFile] imsi obtained, go to setImsi");
                        setImsi(new String(data));
                        return;
                    } else {
                        log("dealWithSimFile efid: " + efid + ", IMSI data is null, call fetchSimRecords Original");
                        mDealAllSimFiles = false;
                        fetchSimRecords();
                        return;
                    }
                default:
                    return;
            }
        }
    }

    private int[] getRecordSize(byte[] data) {
        int[] recordSize = new int[3];
        recordSize[0] = data[14] & 255;
        recordSize[1] = getDataFileSize(data);
        recordSize[2] = recordSize[1] / recordSize[0];
        return recordSize;
    }

    private static int getDataFileSize(byte[] data) {
        return ((data[2] & 255) << 8) + (data[3] & 255);
    }

    private void parseEfSpdi(byte[] data) {
        SimTlv tlv = new SimTlv(data, 0, data.length);
        byte[] plmnEntries = null;
        while (tlv.isValidObject()) {
            if (tlv.getTag() == 163) {
                tlv = new SimTlv(tlv.getData(), 0, tlv.getData().length);
            }
            if (tlv.getTag() != 128) {
                tlv.nextObject();
            } else {
                plmnEntries = tlv.getData();
                break;
            }
        }
        if (plmnEntries == null) {
            return;
        }
        List<String> tmpSpdi = new ArrayList<>(plmnEntries.length / 3);
        for (int i = 0; i + 2 < plmnEntries.length; i += 3) {
            String plmnCode = IccUtils.bcdPlmnToString(plmnEntries, i);
            if (!TextUtils.isEmpty(plmnCode)) {
                log("EF_SPDI PLMN: " + plmnCode);
                tmpSpdi.add(plmnCode);
            }
        }
        int i2 = tmpSpdi.size();
        this.mSpdi = (String[]) tmpSpdi.toArray(new String[i2]);
    }

    private void handleEfCspData(byte[] data) {
        int usedCspGroups = data.length / 2;
        this.mCspPlmnEnabled = true;
        for (int i = 0; i < usedCspGroups; i++) {
            if (data[i * 2] == -64) {
                log("[CSP] found ValueAddedServicesGroup, value " + ((int) data[(i * 2) + 1]));
                if ((data[(i * 2) + 1] & 128) == 128) {
                    this.mCspPlmnEnabled = true;
                    return;
                }
                this.mCspPlmnEnabled = false;
                log("[CSP] Set Automatic Network Selection");
                this.mNetworkSelectionModeAutomaticRegistrants.notifyRegistrants();
                return;
            }
        }
        log("[CSP] Value Added Service Group (0xC0), not found!");
    }

    private String[] parseBcdPlmnList(byte[] data, String description) {
        log("Received " + description + " PLMNs, raw=" + IccUtils.bytesToHexString(data));
        if (data.length == 0 || data.length % 3 != 0) {
            loge("Received invalid " + description + " PLMN list");
            return null;
        }
        int numPlmns = data.length / 3;
        int numValidPlmns = 0;
        String[] parsed = new String[numPlmns];
        for (int i = 0; i < numPlmns; i++) {
            parsed[numValidPlmns] = IccUtils.bcdPlmnToString(data, i * 3);
            if (!TextUtils.isEmpty(parsed[numValidPlmns])) {
                numValidPlmns++;
            }
        }
        String[] ret = (String[]) Arrays.copyOf(parsed, numValidPlmns);
        if (PhoneLogController.SIM_DEBUG) {
            logv(description + " PLMNs: " + Arrays.toString(ret));
        }
        return ret;
    }

    private byte[] getSimFileContent(int efidNeed) {
        IccIoResult iccIoResult;
        if (this.mExUniIccIoResult_list == null) {
            return null;
        }
        int i = 0;
        while (true) {
            ExUniIccIoResult[] exUniIccIoResultArr = this.mExUniIccIoResult_list;
            if (i < exUniIccIoResultArr.length) {
                ExUniIccIoResult exUniIccIoResult = exUniIccIoResultArr[i];
                int efid = exUniIccIoResult.getEfid();
                if (efid == IMSI) {
                    iccIoResult = new IccIoResult(exUniIccIoResult.getSW1(), exUniIccIoResult.getSW2(), exUniIccIoResult.getSimResponse().getBytes());
                } else {
                    iccIoResult = new IccIoResult(exUniIccIoResult.getSW1(), exUniIccIoResult.getSW2(), IccUtils.hexStringToBytes(exUniIccIoResult.getSimResponse()));
                }
                if (iccIoResult.getException() == null) {
                    byte[] data = iccIoResult.payload;
                    if (efid == efidNeed) {
                        log("getSimFileContent efid:" + efid + "; efidNeed: " + efidNeed + ", data : " + IccUtils.bytesToHexString(data));
                        return data;
                    }
                }
                i++;
            } else {
                log("getSimFileContent efidNeed: " + efidNeed + "; data :return null ");
                return null;
            }
        }
    }

    private void getSpnFsmEx(boolean start, byte[] data) {
        if (start) {
            if (this.mSpnState == GetSpnFsmState.READ_SPN_3GPP || this.mSpnState == GetSpnFsmState.READ_SPN_CPHS || this.mSpnState == GetSpnFsmState.READ_SPN_SHORT_CPHS || this.mSpnState == GetSpnFsmState.INIT) {
                this.mSpnState = GetSpnFsmState.INIT;
            }
            this.mSpnState = GetSpnFsmState.INIT;
        }
        switch (AnonymousClass1.$SwitchMap$com$android$internal$telephony$uicc$UniSIMRecords$GetSpnFsmState[this.mSpnState.ordinal()]) {
            case 1:
                setServiceProviderName(null);
                this.mSpnState = GetSpnFsmState.READ_SPN_3GPP;
                dealWithSimFile(28486, getSimFileContent(28486));
                break;
            case 2:
                if (data != null && data.length >= 1) {
                    this.mCarrierNameDisplayCondition = convertSpnDisplayConditionToBitmask(data[0] & 255);
                    setServiceProviderName(IccUtils.adnStringFieldToString(data, 1, data.length - 1));
                    String spn = getServiceProviderName();
                    if (spn == null || spn.length() == 0) {
                        this.mSpnState = GetSpnFsmState.READ_SPN_CPHS;
                    } else {
                        log("[iccIOForAllFile] Load EF_SPN: " + spn + " carrierNameDisplayCondition: " + this.mCarrierNameDisplayCondition);
                        this.mTelephonyManager.setSimOperatorNameForPhone(this.mParentApp.getPhoneId(), spn);
                        this.mSpnState = GetSpnFsmState.IDLE;
                    }
                } else {
                    this.mSpnState = GetSpnFsmState.READ_SPN_CPHS;
                }
                if (this.mSpnState == GetSpnFsmState.READ_SPN_CPHS) {
                    this.mCarrierNameDisplayCondition = 0;
                    dealWithSimFile(28436, getSimFileContent(28436));
                }
                break;
            case 3:
                if (data != null && data.length > 0) {
                    setServiceProviderName(IccUtils.adnStringFieldToString(data, 0, data.length));
                    String spn2 = getServiceProviderName();
                    if (spn2 == null || spn2.length() == 0) {
                        this.mSpnState = GetSpnFsmState.READ_SPN_SHORT_CPHS;
                    } else {
                        this.mCarrierNameDisplayCondition = 0;
                        log("[iccIOForAllFile] Load EF_SPN_CPHS: " + spn2);
                        this.mTelephonyManager.setSimOperatorNameForPhone(this.mParentApp.getPhoneId(), spn2);
                        this.mSpnState = GetSpnFsmState.IDLE;
                    }
                } else {
                    this.mSpnState = GetSpnFsmState.READ_SPN_SHORT_CPHS;
                }
                if (this.mSpnState == GetSpnFsmState.READ_SPN_SHORT_CPHS) {
                    dealWithSimFile(28440, getSimFileContent(28440));
                }
                break;
            case 4:
                if (data != null && data.length > 0) {
                    setServiceProviderName(IccUtils.adnStringFieldToString(data, 0, data.length));
                    String spn3 = getServiceProviderName();
                    if (spn3 == null || spn3.length() == 0) {
                        log("[iccIOForAllFile] No SPN loaded in either CHPS or 3GPP");
                    } else {
                        this.mCarrierNameDisplayCondition = 0;
                        log("[iccIOForAllFile] Load EF_SPN_SHORT_CPHS: " + spn3);
                        this.mTelephonyManager.setSimOperatorNameForPhone(this.mParentApp.getPhoneId(), spn3);
                    }
                } else {
                    setServiceProviderName(null);
                    log("[iccIOForAllFile] No SPN loaded in either CHPS or 3GPP");
                }
                this.mSpnState = GetSpnFsmState.IDLE;
                break;
            default:
                this.mSpnState = GetSpnFsmState.IDLE;
                break;
        }
    }

    /* JADX INFO: renamed from: com.android.internal.telephony.uicc.UniSIMRecords$1, reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$android$internal$telephony$uicc$UniSIMRecords$GetSpnFsmState;

        static {
            int[] iArr = new int[GetSpnFsmState.values().length];
            $SwitchMap$com$android$internal$telephony$uicc$UniSIMRecords$GetSpnFsmState = iArr;
            try {
                iArr[GetSpnFsmState.INIT.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$uicc$UniSIMRecords$GetSpnFsmState[GetSpnFsmState.READ_SPN_3GPP.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$uicc$UniSIMRecords$GetSpnFsmState[GetSpnFsmState.READ_SPN_CPHS.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$uicc$UniSIMRecords$GetSpnFsmState[GetSpnFsmState.READ_SPN_SHORT_CPHS.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
        }
    }

    private void getSpnFsm(boolean start, AsyncResult ar) {
        if (start) {
            if (this.mSpnState == GetSpnFsmState.READ_SPN_3GPP || this.mSpnState == GetSpnFsmState.READ_SPN_CPHS || this.mSpnState == GetSpnFsmState.READ_SPN_SHORT_CPHS || this.mSpnState == GetSpnFsmState.INIT) {
                this.mSpnState = GetSpnFsmState.INIT;
            }
            this.mSpnState = GetSpnFsmState.INIT;
        }
        switch (AnonymousClass1.$SwitchMap$com$android$internal$telephony$uicc$UniSIMRecords$GetSpnFsmState[this.mSpnState.ordinal()]) {
            case 1:
                setServiceProviderName(null);
                this.mFh.loadEFTransparent(28486, obtainMessage(12));
                this.mRecordsToLoad++;
                this.mSpnState = GetSpnFsmState.READ_SPN_3GPP;
                break;
            case 2:
                if (ar != null && ar.exception == null) {
                    byte[] data = (byte[]) ar.result;
                    if (data != null && data.length >= 1) {
                        this.mCarrierNameDisplayCondition = convertSpnDisplayConditionToBitmask(data[0] & 255);
                        setServiceProviderName(IccUtils.adnStringFieldToString(data, 1, data.length - 1));
                    }
                    String spn = getServiceProviderName();
                    if (spn == null || spn.length() == 0) {
                        this.mSpnState = GetSpnFsmState.READ_SPN_CPHS;
                    } else {
                        log("Load EF_SPN: " + spn + " carrierNameDisplayCondition: " + this.mCarrierNameDisplayCondition);
                        this.mTelephonyManager.setSimOperatorNameForPhone(this.mParentApp.getPhoneId(), spn);
                        this.mSpnState = GetSpnFsmState.IDLE;
                    }
                } else {
                    this.mSpnState = GetSpnFsmState.READ_SPN_CPHS;
                }
                if (this.mSpnState == GetSpnFsmState.READ_SPN_CPHS) {
                    this.mFh.loadEFTransparent(28436, obtainMessage(12));
                    this.mRecordsToLoad++;
                    this.mCarrierNameDisplayCondition = 0;
                }
                break;
            case 3:
                if (ar != null && ar.exception == null) {
                    byte[] data2 = (byte[]) ar.result;
                    if (data2 != null && data2.length > 0) {
                        setServiceProviderName(IccUtils.adnStringFieldToString(data2, 0, data2.length));
                    }
                    String spn2 = getServiceProviderName();
                    if (spn2 == null || spn2.length() == 0) {
                        this.mSpnState = GetSpnFsmState.READ_SPN_SHORT_CPHS;
                    } else {
                        this.mCarrierNameDisplayCondition = 0;
                        log("Load EF_SPN_CPHS: " + spn2);
                        this.mTelephonyManager.setSimOperatorNameForPhone(this.mParentApp.getPhoneId(), spn2);
                        this.mSpnState = GetSpnFsmState.IDLE;
                    }
                } else {
                    this.mSpnState = GetSpnFsmState.READ_SPN_SHORT_CPHS;
                }
                if (this.mSpnState == GetSpnFsmState.READ_SPN_SHORT_CPHS) {
                    this.mFh.loadEFTransparent(28440, obtainMessage(12));
                    this.mRecordsToLoad++;
                }
                break;
            case 4:
                if (ar != null && ar.exception == null) {
                    byte[] data3 = (byte[]) ar.result;
                    if (data3 != null && data3.length > 0) {
                        setServiceProviderName(IccUtils.adnStringFieldToString(data3, 0, data3.length));
                    }
                    String spn3 = getServiceProviderName();
                    if (spn3 == null || spn3.length() == 0) {
                        log("No SPN loaded in either CHPS or 3GPP");
                    } else {
                        this.mCarrierNameDisplayCondition = 0;
                        log("Load EF_SPN_SHORT_CPHS: " + spn3);
                        this.mTelephonyManager.setSimOperatorNameForPhone(this.mParentApp.getPhoneId(), spn3);
                    }
                } else {
                    setServiceProviderName(null);
                    log("No SPN loaded in either CHPS or 3GPP");
                }
                this.mSpnState = GetSpnFsmState.IDLE;
                break;
            default:
                this.mSpnState = GetSpnFsmState.IDLE;
                break;
        }
    }

    private int getExtFromEf(int ef) {
        switch (ef) {
            case 28480:
                if (this.mParentApp.getType() == IccCardApplicationStatus.AppType.APPTYPE_USIM) {
                    return 28494;
                }
                return 28490;
            default:
                return 28490;
        }
    }

    private String getExtraIccId() {
        UiccPort uiccPort;
        UiccController uiccContrller = UiccController.getInstance();
        UiccCard uiccCard = uiccContrller.getUiccCard(this.mParentApp.getPhoneId());
        if (uiccCard != null && (uiccPort = uiccCard.getUiccPortForPhone(this.mParentApp.getPhoneId())) != null) {
            return uiccPort.getIccId();
        }
        return null;
    }

    private void loadCallForwardingRecords() {
        this.mRecordsRequested = true;
        this.mFh.loadEFLinearFixed(28619, 1, obtainMessage(EVENT_GET_CFIS_DONE));
        this.mRecordsToLoad++;
        this.mFh.loadEFTransparent(28435, obtainMessage(EVENT_GET_CFF_DONE));
        this.mRecordsToLoad++;
    }

    private void loadEfLiAndEfPl() {
        if (this.mParentApp.getType() == IccCardApplicationStatus.AppType.APPTYPE_USIM) {
            this.mFh.loadEFTransparent(28421, obtainMessage(100, new EfUsimLiLoaded()));
            this.mRecordsToLoad++;
            this.mFh.loadEFTransparent(12037, obtainMessage(100, new EfPlLoaded()));
            this.mRecordsToLoad++;
        }
    }

    protected class EfPlLoaded implements IccRecords.IccRecordLoaded {
        protected EfPlLoaded() {
        }

        public String getEfName() {
            return "EF_PL";
        }

        public void onRecordLoaded(AsyncResult ar) {
            UniSIMRecords.this.mEfPl = (byte[]) ar.result;
            UniSIMRecords.this.log("EF_PL=" + IccUtils.bytesToHexString(UniSIMRecords.this.mEfPl));
        }
    }

    protected class EfUsimLiLoaded implements IccRecords.IccRecordLoaded {
        protected EfUsimLiLoaded() {
        }

        public String getEfName() {
            return "EF_LI";
        }

        public void onRecordLoaded(AsyncResult ar) {
            UniSIMRecords.this.mEfLi = (byte[]) ar.result;
            UniSIMRecords.this.log("EF_LI=" + IccUtils.bytesToHexString(UniSIMRecords.this.mEfLi));
        }
    }

    protected void resetRecords() {
        super.resetRecords();
        this.mNonKeyRecordsLoaded = false;
    }

    protected void onRecordLoaded() {
        this.mRecordsToLoad--;
        log("onRecordLoaded " + this.mRecordsToLoad + " requested: " + this.mRecordsRequested);
        if (getKeyInfoRecordsLoaded()) {
            log("Key info has loaded");
            updateSimNumeric();
            this.mRecordsKeyInfoLoadedRegistrants.notifyRegistrants();
            this.mNonKeyRecordsLoaded = true;
            fetchSimRecords();
            return;
        }
        if (getRecordsLoaded()) {
            onAllRecordsLoaded();
            this.mNonKeyRecordsLoaded = false;
        } else if (getLockedRecordsLoaded() || getNetworkLockedRecordsLoaded()) {
            onLockedAllRecordsLoaded();
        } else if (this.mRecordsToLoad < 0) {
            loge("recordsToLoad <0, programmer error suspected");
            this.mRecordsToLoad = 0;
        }
    }

    private void setSimLanguageFromEF() {
        Resources resource = Resources.getSystem();
        if (resource.getBoolean(R.bool.config_lowPowerStandbySupported)) {
            setSimLanguage(this.mEfLi, this.mEfPl);
        } else {
            log("Not using EF LI/EF PL");
        }
    }

    public int getVoiceCallForwardingFlag() {
        return this.mCallForwardingStatus;
    }

    public void setVoiceCallForwardingFlag(int line, boolean enable, String dialNumber) {
        int i;
        if (!this.mDestroyed.get() && line == 1) {
            if (enable) {
                i = 1;
            } else {
                i = 0;
            }
            this.mCallForwardingStatus = i;
            this.mRecordsEventsRegistrants.notifyResult(1);
            try {
                if (validEfCfis(this.mEfCfis)) {
                    if (enable) {
                        byte[] bArr = this.mEfCfis;
                        bArr[1] = (byte) (bArr[1] | 1);
                    } else {
                        byte[] bArr2 = this.mEfCfis;
                        bArr2[1] = (byte) (bArr2[1] & 254);
                    }
                    log("setVoiceCallForwardingFlag: enable=" + enable + " mEfCfis=" + IccUtils.bytesToHexString(this.mEfCfis));
                    if (enable && !TextUtils.isEmpty(dialNumber)) {
                        logv("EF_CFIS: updating cf number, " + Rlog.pii(LOG_TAG, dialNumber));
                        byte[] bcdNumber = PhoneNumberUtils.numberToCalledPartyBCD(dialNumber, 1);
                        System.arraycopy(bcdNumber, 0, this.mEfCfis, 3, bcdNumber.length);
                        byte[] bArr3 = this.mEfCfis;
                        bArr3[2] = (byte) bcdNumber.length;
                        bArr3[14] = -1;
                        bArr3[15] = -1;
                    }
                    this.mFh.updateEFLinearFixed(28619, 1, this.mEfCfis, (String) null, obtainMessage(14, 28619));
                } else {
                    log("setVoiceCallForwardingFlag: ignoring enable=" + enable + " invalid mEfCfis=" + IccUtils.bytesToHexString(this.mEfCfis));
                }
                byte[] bArr4 = this.mEfCff;
                if (bArr4 != null) {
                    if (enable) {
                        bArr4[0] = (byte) ((bArr4[0] & 240) | 10);
                    } else {
                        bArr4[0] = (byte) ((bArr4[0] & 240) | 5);
                    }
                    this.mFh.updateEFTransparent(28435, this.mEfCff, obtainMessage(14, 28435));
                }
            } catch (ArrayIndexOutOfBoundsException ex) {
                logw("Error saving call forwarding flag to SIM. Probably malformed SIM record", ex);
            }
        }
    }

    private void setVoiceCallForwardingFlagFromSimRecords() {
        if (validEfCfis(this.mEfCfis)) {
            this.mCallForwardingStatus = this.mEfCfis[1] & 1;
            log("EF_CFIS: callForwardingEnabled=" + this.mCallForwardingStatus);
            return;
        }
        byte[] bArr = this.mEfCff;
        if (bArr != null) {
            this.mCallForwardingStatus = (bArr[0] & 15) != 10 ? 0 : 1;
            log("EF_CFF: callForwardingEnabled=" + this.mCallForwardingStatus);
        } else {
            this.mCallForwardingStatus = -1;
            log("EF_CFIS and EF_CFF not valid. callForwardingEnabled=" + this.mCallForwardingStatus);
        }
    }

    private boolean validEfCfis(byte[] data) {
        if (data != null) {
            if (data[0] < 1 || data[0] > 4) {
                logw("MSP byte: " + ((int) data[0]) + " is not between 1 and 4", null);
            }
            for (byte b : data) {
                if (b != -1) {
                    return true;
                }
            }
        }
        return false;
    }

    private void setVoiceMailByCountry(String spn) {
        if (!this.mDestroyed.get() && this.mVmConfig.containsCarrier(spn)) {
            this.mIsVoiceMailFixed = true;
            this.mVoiceMailNum = this.mVmConfig.getVoiceMailNumber(spn);
            this.mVoiceMailTag = this.mVmConfig.getVoiceMailTag(spn);
        }
    }

    private void onLockedAllRecordsLoaded() {
        setSimLanguageFromEF();
        setVoiceCallForwardingFlagFromSimRecords();
        if (this.mLockedRecordsReqReason == 1) {
            this.mLockedRecordsLoadedRegistrants.notifyRegistrants(new AsyncResult((Object) null, (Object) null, (Throwable) null));
        } else if (this.mLockedRecordsReqReason == 2) {
            this.mNetworkLockedRecordsLoadedRegistrants.notifyRegistrants(new AsyncResult((Object) null, (Object) null, (Throwable) null));
        } else {
            loge("onLockedAllRecordsLoaded: unexpected mLockedRecordsReqReason " + this.mLockedRecordsReqReason);
        }
    }

    private boolean isAirplaneModeOn(Context context) {
        return Settings.Global.getInt(context.getContentResolver(), "airplane_mode_on", 0) != 0;
    }

    private Resources getResourcesForMccMnc(String mccmnc) {
        Configuration config = this.mContext.getResources().getConfiguration();
        Configuration newConfig = new Configuration();
        newConfig.setTo(config);
        if (mccmnc.length() >= 4) {
            try {
                newConfig.mcc = Integer.parseInt(mccmnc.substring(0, 3));
                newConfig.mnc = Integer.parseInt(mccmnc.substring(3));
                if (newConfig.mnc == 0) {
                    newConfig.mnc = IMSI;
                }
            } catch (NumberFormatException e) {
                log("getResourcesForMccMnc " + e);
            }
        }
        DisplayMetrics metrics = this.mContext.getResources().getDisplayMetrics();
        DisplayMetrics newMetrics = new DisplayMetrics();
        newMetrics.setTo(metrics);
        return new Resources(this.mContext.getResources().getAssets(), newMetrics, newConfig);
    }

    private boolean isRoamingBrokerTelus(String operator) {
        if (TextUtils.isEmpty(operator)) {
            return false;
        }
        Resources res = getResourcesForMccMnc(operator);
        return res.getBoolean(134414352);
    }

    private void resetImsiforRoamingBroker(String operator) {
        if (!TextUtils.isEmpty(this.mImsi) && this.mRb != null && this.mImsi.length() >= 6 && this.mRb.getStateforBroker(this.mPhoneId) && !TextUtils.isEmpty(operator)) {
            String lastImsi = this.mImsi.substring(6, this.mImsi.length());
            this.mImsi = operator + lastImsi;
            log("[resetImsiforRoamingBroker]IMSI: " + this.mImsi.substring(0, 6) + " for RoamingBroker");
            updateOperatorPlmn();
            this.mImsiReadyRegistrants.notifyRegistrants();
        }
    }

    private void updateSimNumeric() {
        RoamingBroker roamingBroker;
        RoamingBroker roamingBroker2;
        RoamingBroker roamingBroker3;
        String operator = getOperatorNumeric();
        if (!TextUtils.isEmpty(operator) && (roamingBroker3 = this.mRb) != null) {
            roamingBroker3.updateMccMncs(this.mPhoneId, operator);
        }
        boolean isRefreshtoTelus = isRoamingBrokerTelus(operator);
        String oldOperator = "";
        RoamingBroker roamingBroker4 = this.mRb;
        if (roamingBroker4 != null) {
            oldOperator = roamingBroker4.getOriginalValue(this.mPhoneId);
            log("operator = " + operator + ", oldOperator = " + oldOperator + ", isRoamingBroker = " + this.mRb.getStateforBroker(this.mPhoneId));
        }
        if (!isRefreshtoTelus) {
            resetImsiforRoamingBroker(oldOperator);
        }
        if (!TextUtils.isEmpty(operator) && ((roamingBroker2 = this.mRb) == null || (roamingBroker2 != null && !roamingBroker2.getStateforBroker(this.mPhoneId)))) {
            log("onAllRecordsLoaded set 'gsm.sim.operator.numeric' to operator='" + operator + "'");
            this.mTelephonyManager.setSimOperatorNumericForPhone(this.mParentApp.getPhoneId(), operator);
            Phone phone = this.mPhone;
            if (phone != null && phone.mCi.getRadioState() == 0 && !isAirplaneModeOn(this.mContext)) {
                log("restart radio");
                this.mPhone.setRadioPower(true);
            }
        } else if (!TextUtils.isEmpty(operator) && (roamingBroker = this.mRb) != null && roamingBroker.getStateforBroker(this.mPhoneId) && !TextUtils.isEmpty(oldOperator)) {
            if (!isRefreshtoTelus) {
                this.mTelephonyManager.setSimOperatorNumericForPhone(this.mPhoneId, oldOperator);
            } else if (this.mPhone != null) {
                log("turn off radio");
                this.mPhone.setRadioPower(false);
            }
        } else {
            log("onAllRecordsLoaded empty 'gsm.sim.operator.numeric' skipping");
        }
        if (!TextUtils.isEmpty(operator)) {
            String simOperator = Settings.Global.getString(this.mContext.getContentResolver(), "mobile_icc_operator_numeric" + this.mParentApp.getPhoneId());
            log("updateSimNumeric operator " + operator + " simOperator " + simOperator);
            if ((!TextUtils.isEmpty(simOperator) && !simOperator.equals(operator)) || TextUtils.isEmpty(simOperator)) {
                Settings.Global.putString(this.mContext.getContentResolver(), "mobile_icc_operator_numeric" + this.mParentApp.getPhoneId(), operator);
                this.mContext.getContentResolver().notifyChange(Settings.Global.getUriFor("mobile_icc_operator_numeric" + this.mParentApp.getPhoneId()), null, true, -1);
            }
        }
        String imsi = getIMSI();
        if (!TextUtils.isEmpty(imsi) && imsi.length() >= 3) {
            log("onAllRecordsLoaded set mcc imsi" + (PhoneLogController.SIM_DEBUG ? "=" + imsi : ""));
            this.mTelephonyManager.setSimCountryIsoForPhone(this.mParentApp.getPhoneId(), MccTable.countryCodeForMcc(imsi.substring(0, 3)));
        } else {
            log("onAllRecordsLoaded empty imsi skipping setting mcc");
        }
    }

    protected void onAllRecordsLoaded() {
        log("record load complete");
        setSimLanguageFromEF();
        setVoiceCallForwardingFlagFromSimRecords();
        setVoiceMailByCountry(getOperatorNumeric());
        this.mLoaded.set(true);
        this.mRecordsLoadedRegistrants.notifyRegistrants(new AsyncResult((Object) null, (Object) null, (Throwable) null));
    }

    public UniAdnRecordCache getUniAdnRecordCache() {
        return this.mUniAdnCache;
    }

    protected void handleFileUpdate(int efid) {
        this.mUniAdnCache.resetWithFileUpdate();
        super.handleFileUpdate(efid);
    }

    public void dispose() {
        super.dispose();
        this.mUniAdnCache.reset();
    }

    private boolean isCphsMailboxEnabled() {
        byte[] bArr = this.mCphsInfo;
        return bArr != null && (bArr[1] & 48) == 48;
    }

    private boolean isWifiOnly() {
        return SystemProperties.get("ro.boot.product.hardware.sku", "").contains("wifionly");
    }

    private boolean isDataOnly() {
        return SystemProperties.get("ro.boot.product.hardware.sku", "").contains("dataonly");
    }

    protected void log(String s) {
        if (this.mParentApp != null) {
            Rlog.d(LOG_TAG, "[SIMRecords-" + this.mParentApp.getPhoneId() + "] " + s);
        } else {
            Rlog.d(LOG_TAG, "[SIMRecords] " + s);
        }
    }
}
