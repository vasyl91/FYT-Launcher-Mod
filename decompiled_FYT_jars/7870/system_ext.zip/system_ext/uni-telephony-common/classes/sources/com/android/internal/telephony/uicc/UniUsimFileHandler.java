package com.android.internal.telephony.uicc;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Message;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.UniTeleUtils;
import com.android.telephony.Rlog;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniUsimFileHandler extends IccFileHandler implements UniIccConstants {
    protected static final int EVENT_READ_EF_LINEAR_RECORD_DONE = 1001;
    private static final int FILE_HANDLER_EVENT_BASE = 1000;
    protected static final int READ_RECORD_MODE_CYCLIC = 3;
    protected static final byte RESPONSE_DATA_FCP_FLAG = 0;
    protected static final byte RESPONSE_DATA_FILE_DES_FLAG = 2;
    protected static final byte RESPONSE_DATA_FILE_DES_LEN_FLAG = 3;
    protected static final byte RESPONSE_DATA_FILE_RECORD_COUNT_FLAG = 8;
    protected static final byte RESPONSE_DATA_FILE_RECORD_LEN_1 = 6;
    protected static final byte RESPONSE_DATA_FILE_RECORD_LEN_2 = 7;
    protected static final String TAG = "UniUsimFileHandler";
    protected static final byte TYPE_FCP = 98;
    protected static final byte TYPE_FCP_SIZE = -128;
    protected static final byte TYPE_FILE_DES = -126;
    protected static final byte TYPE_FILE_DES_LEN = 5;
    private static final int USIM_DATA_OFFSET_2 = 2;
    private static final int USIM_DATA_OFFSET_3 = 3;
    private static final byte USIM_RECORD_COUNT = 6;
    private static final byte USIM_RECORD_SIZE_1 = 4;
    private static final byte USIM_RECORD_SIZE_2 = 5;
    private CommandsInterface mCi;
    private Context mContext;
    private final int[] mDualMapFile;
    private Map<Integer, String> mDualMapFileList;
    private ArrayList<Integer> mFileList;

    static class IccIoContext {
        int mCountRecords;
        int mEfid;
        boolean mLoadAll;
        Message mOnLoaded;
        String mPath;
        int mRecordNum;
        int mRecordSize;
        ArrayList<byte[]> results;

        IccIoContext(int efid, String path, Message onLoaded) {
            this.mEfid = efid;
            this.mPath = path;
            this.mOnLoaded = onLoaded;
            this.mRecordNum = 1;
            this.mLoadAll = true;
        }

        IccIoContext(int efid, int recordNum, Message onLoaded) {
            this.mEfid = efid;
            this.mRecordNum = recordNum;
            this.mOnLoaded = onLoaded;
            this.mLoadAll = false;
            this.mPath = null;
        }

        IccIoContext(int efid, int recordNum, String path, Message onLoaded) {
            this.mEfid = efid;
            this.mRecordNum = recordNum;
            this.mPath = path;
            this.mOnLoaded = onLoaded;
            this.mLoadAll = false;
        }

        public String toString() {
            return "IccIoContext:  mEfid" + this.mEfid + " mRecordNum=" + this.mRecordNum + " mOnLoaded=" + this.mOnLoaded + " mPath=" + this.mPath;
        }
    }

    public UniUsimFileHandler(UiccCardApplication app, String aid, CommandsInterface ci, Context c) {
        super(app, aid, ci);
        this.mDualMapFile = new int[]{28476, 20272, 28489, 28492};
        this.mCi = ci;
        this.mContext = c;
        initDualMapFileSet();
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.android.internal.telephony.uicc.IccFileTypeMismatch */
    /* JADX WARN: Code duplicated, block: B:153:0x03b0 A[Catch: Exception -> 0x0472, TRY_ENTER, TRY_LEAVE, TryCatch #5 {Exception -> 0x0472, blocks: (B:144:0x0393, B:153:0x03b0), top: B:255:0x0393 }] */
    /* JADX WARN: Code duplicated, block: B:155:0x03b8 A[Catch: Exception -> 0x03aa, TRY_ENTER, TRY_LEAVE, TryCatch #3 {Exception -> 0x03aa, blocks: (B:148:0x03a3, B:155:0x03b8), top: B:252:0x03a3 }] */
    /* JADX WARN: Code duplicated, block: B:164:0x03e3  */
    /* JADX WARN: Code duplicated, block: B:167:0x03e9 A[Catch: Exception -> 0x046a, TRY_LEAVE, TryCatch #2 {Exception -> 0x046a, blocks: (B:165:0x03e5, B:167:0x03e9, B:177:0x0400, B:183:0x042f), top: B:250:0x03e5 }] */
    /* JADX WARN: Code duplicated, block: B:179:0x041c A[Catch: Exception -> 0x03f9, TRY_ENTER, TryCatch #21 {Exception -> 0x03f9, blocks: (B:160:0x03d5, B:169:0x03ed, B:172:0x03f3, B:173:0x03f8, B:179:0x041c, B:181:0x0427), top: B:281:0x03bc }] */
    /* JADX WARN: Code duplicated, block: B:181:0x0427 A[Catch: Exception -> 0x03f9, TRY_LEAVE, TryCatch #21 {Exception -> 0x03f9, blocks: (B:160:0x03d5, B:169:0x03ed, B:172:0x03f3, B:173:0x03f8, B:179:0x041c, B:181:0x0427), top: B:281:0x03bc }] */
    /* JADX WARN: Code duplicated, block: B:186:0x045c A[Catch: Exception -> 0x0464, TryCatch #10 {Exception -> 0x0464, blocks: (B:185:0x0444, B:186:0x045c, B:187:0x0463), top: B:261:0x03e7 }] */
    /* JADX WARN: Code duplicated, block: B:259:0x03be A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:74:0x01c5 A[Catch: Exception -> 0x0232, TRY_ENTER, TRY_LEAVE, TryCatch #6 {Exception -> 0x0232, blocks: (B:65:0x01ac, B:79:0x01d3, B:74:0x01c5), top: B:257:0x01ac }] */
    /* JADX WARN: Code duplicated, block: B:76:0x01cd A[Catch: Exception -> 0x01bf, TRY_ENTER, TRY_LEAVE, TryCatch #18 {Exception -> 0x01bf, blocks: (B:69:0x01b8, B:76:0x01cd), top: B:275:0x01b8 }] */
    /* JADX WARN: Code duplicated, block: B:79:0x01d3 A[Catch: Exception -> 0x0232, TRY_ENTER, TRY_LEAVE, TryCatch #6 {Exception -> 0x0232, blocks: (B:65:0x01ac, B:79:0x01d3, B:74:0x01c5), top: B:257:0x01ac }] */
    /* JADX WARN: Code duplicated, block: B:82:0x01ed A[Catch: Exception -> 0x022d, TryCatch #1 {Exception -> 0x022d, blocks: (B:81:0x01e9, B:82:0x01ed, B:84:0x01f3, B:86:0x01f7, B:90:0x01fe, B:92:0x0227, B:93:0x022c), top: B:249:0x01d1 }] */
    /* JADX WARN: Code duplicated, block: B:84:0x01f3 A[Catch: Exception -> 0x022d, TryCatch #1 {Exception -> 0x022d, blocks: (B:81:0x01e9, B:82:0x01ed, B:84:0x01f3, B:86:0x01f7, B:90:0x01fe, B:92:0x0227, B:93:0x022c), top: B:249:0x01d1 }] */
    /* JADX WARN: Code duplicated, block: B:86:0x01f7 A[Catch: Exception -> 0x022d, TryCatch #1 {Exception -> 0x022d, blocks: (B:81:0x01e9, B:82:0x01ed, B:84:0x01f3, B:86:0x01f7, B:90:0x01fe, B:92:0x0227, B:93:0x022c), top: B:249:0x01d1 }] */
    /* JADX WARN: Code duplicated, block: B:88:0x01fc  */
    /* JADX WARN: Code duplicated, block: B:89:0x01fd  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Not initialized variable reg: 20, insn: 0x0110: MOVE (r1 I:??[OBJECT, ARRAY]) = (r20 I:??[OBJECT, ARRAY] A[D('response' android.os.Message)]), block:B:42:0x0110 */
    /* JADX WARN: Not initialized variable reg: 22, insn: 0x0566: MOVE (r13 I:??[OBJECT, ARRAY] A[D('response' android.os.Message)]) = (r22 I:??[OBJECT, ARRAY] A[D('data' byte[])]), block:B:233:0x0565 */
    /* JADX WARN: Not initialized variable reg: 22, insn: 0x056a: MOVE (r13 I:??[OBJECT, ARRAY]) = (r22 I:??[OBJECT, ARRAY] A[D('data' byte[])]), block:B:235:0x056a */
    /* JADX WARN: Type inference failed for: r16v1 */
    /* JADX WARN: Type inference failed for: r1v0 */
    /* JADX WARN: Type inference failed for: r1v1, types: [android.os.Message] */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v2 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v3 */
    /* JADX WARN: Type inference failed for: r1v4 */
    /* JADX WARN: Type inference failed for: r1v46 */
    /* JADX WARN: Type inference failed for: r1v48 */
    /* JADX WARN: Type inference failed for: r1v56 */
    /* JADX WARN: Type inference failed for: r1v58 */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r1v60 */
    /* JADX WARN: Type inference failed for: r1v61 */
    /* JADX WARN: Type inference failed for: r1v62 */
    /* JADX WARN: Type inference failed for: r1v64 */
    /* JADX WARN: Type inference failed for: r1v65 */
    /* JADX WARN: Type inference failed for: r1v69 */
    /* JADX WARN: Type inference failed for: r1v70, types: [android.os.Message] */
    /* JADX WARN: Type inference failed for: r1v71, types: [android.os.Message] */
    /* JADX WARN: Type inference failed for: r1v72 */
    /* JADX WARN: Type inference failed for: r1v73 */
    /* JADX WARN: Type inference failed for: r1v74 */
    /* JADX WARN: Type inference failed for: r1v75 */
    /* JADX WARN: Type inference failed for: r37v0, types: [com.android.internal.telephony.uicc.IccFileHandler, com.android.internal.telephony.uicc.UniUsimFileHandler] */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v1 */
    /* JADX WARN: Type inference failed for: r4v52 */
    /* JADX WARN: Type inference failed for: r4v53 */
    /* JADX WARN: Type inference failed for: r4v9 */
    public void handleMessage(Message message) throws IccFileTypeMismatch {
        Message message2;
        int i;
        Object obj;
        Object obj2;
        ?? r1 = 0;
        r1 = 0;
        r1 = 0;
        r1 = 0;
        Message message3 = null;
        int i2 = message.arg2;
        try {
            ?? r4 = 1;
            try {
                try {
                    try {
                        try {
                            switch (message.what) {
                                case 4:
                                    obj = null;
                                    AsyncResult asyncResult = (AsyncResult) message.obj;
                                    Message message4 = (Message) asyncResult.userObj;
                                    IccIoResult iccIoResult = (IccIoResult) asyncResult.result;
                                    if (asyncResult.exception != null) {
                                        loge("ar.exception = " + asyncResult.exception);
                                        sendResult(message4, null, asyncResult.exception);
                                        int i3 = message.arg1;
                                        String eFPath = getEFPath(i3);
                                        sendErrReport(192, i3, eFPath, 0, 0, 15, null, null, asyncResult.exception.toString());
                                        message3 = null;
                                        r4 = eFPath;
                                        return;
                                    }
                                    IccException exception = iccIoResult.getException();
                                    int i4 = message.arg1;
                                    if (exception == null || !loadFileAgain(i4, i2, message.what, message4)) {
                                        super.handleMessage(message);
                                        return;
                                    } else {
                                        logd("load again return");
                                        return;
                                    }
                                case 5:
                                    obj = null;
                                    AsyncResult asyncResult2 = (AsyncResult) message.obj;
                                    Message message5 = (Message) asyncResult2.userObj;
                                    IccIoResult iccIoResult2 = (IccIoResult) asyncResult2.result;
                                    if (asyncResult2.exception == null) {
                                        IccException exception2 = iccIoResult2.getException();
                                        if (exception2 != null) {
                                            sendResult(message5, null, exception2);
                                        } else {
                                            sendResult(message5, iccIoResult2.payload, null);
                                        }
                                        return;
                                    }
                                    sendResult(message5, null, asyncResult2.exception);
                                    int i5 = message.arg1;
                                    String eFPath2 = getEFPath(i5);
                                    sendErrReport(176, i5, eFPath2, 0, 0, message.arg2, null, null, asyncResult2.exception.toString());
                                    message3 = null;
                                    r4 = eFPath2;
                                    return;
                                case 6:
                                case 11:
                                    AsyncResult asyncResult3 = (AsyncResult) message.obj;
                                    IccIoContext iccIoContext = (IccIoContext) asyncResult3.userObj;
                                    IccIoResult iccIoResult3 = (IccIoResult) asyncResult3.result;
                                    Message message6 = iccIoContext.mOnLoaded;
                                    try {
                                        if (asyncResult3.exception == null) {
                                            try {
                                                byte[] bArr = iccIoResult3.payload;
                                                try {
                                                    String eFPath3 = iccIoContext.mPath;
                                                    int i6 = iccIoContext.mEfid;
                                                    IccException exception3 = iccIoResult3.getException();
                                                    if (exception3 == null) {
                                                        if (i6 == 20272) {
                                                            try {
                                                                if (!isDataValid(bArr)) {
                                                                    if (loadFileAgain(i6, i2, message.what, iccIoContext)) {
                                                                        logd("load again return");
                                                                        return;
                                                                    }
                                                                }
                                                            } catch (Exception e) {
                                                                e = e;
                                                                r1 = message6;
                                                            }
                                                            break;
                                                        }
                                                        if (exception3 == null) {
                                                            loge("iccException = " + exception3);
                                                            sendResult(message6, null, exception3);
                                                            return;
                                                        }
                                                        if (4 == bArr[6]) {
                                                            throw new IccFileTypeMismatch();
                                                        }
                                                        if (1 != bArr[13]) {
                                                            throw new IccFileTypeMismatch();
                                                        }
                                                        iccIoContext.mRecordSize = bArr[14] & 255;
                                                        iccIoContext.mCountRecords = (((bArr[2] & 255) << 8) + (bArr[3] & 255)) / iccIoContext.mRecordSize;
                                                        if (iccIoContext.mLoadAll) {
                                                            iccIoContext.results = new ArrayList<>(iccIoContext.mCountRecords);
                                                        }
                                                        if (eFPath3 == null) {
                                                            eFPath3 = getEFPath(iccIoContext.mEfid);
                                                        }
                                                        this.mCi.iccIOForApp(178, iccIoContext.mEfid, eFPath3, iccIoContext.mRecordNum, 4, iccIoContext.mRecordSize, (String) null, (String) null, ((UniUsimFileHandler) this).mAid, obtainMessage(7, iccIoContext));
                                                        return;
                                                    }
                                                    if (loadFileAgain(i6, i2, message.what, iccIoContext)) {
                                                        logd("load again return");
                                                        return;
                                                    }
                                                    try {
                                                        if (exception3 == null) {
                                                            try {
                                                                try {
                                                                    if (4 == bArr[6]) {
                                                                        throw new IccFileTypeMismatch();
                                                                    }
                                                                    if (1 != bArr[13] && 3 != bArr[13]) {
                                                                        throw new IccFileTypeMismatch();
                                                                    }
                                                                    iccIoContext.mRecordSize = bArr[14] & 255;
                                                                    iccIoContext.mCountRecords = (((bArr[2] & 255) << 8) + (bArr[3] & 255)) / iccIoContext.mRecordSize;
                                                                    if (iccIoContext.mLoadAll) {
                                                                        iccIoContext.results = new ArrayList<>(iccIoContext.mCountRecords);
                                                                    }
                                                                    if (eFPath3 == null) {
                                                                        eFPath3 = getEFPath(iccIoContext.mEfid);
                                                                    }
                                                                    this.mCi.iccIOForApp(178, iccIoContext.mEfid, eFPath3, iccIoContext.mRecordNum, 4, iccIoContext.mRecordSize, (String) null, (String) null, ((UniUsimFileHandler) this).mAid, obtainMessage(7, iccIoContext));
                                                                    return;
                                                                } catch (Exception e2) {
                                                                    e = e2;
                                                                    r1 = message6;
                                                                }
                                                            } catch (Exception e3) {
                                                                e = e3;
                                                                r1 = message6;
                                                            }
                                                        } else {
                                                            try {
                                                                loge("iccException = " + exception3);
                                                                sendResult(message6, null, exception3);
                                                                return;
                                                            } catch (Exception e4) {
                                                                e = e4;
                                                                r1 = message6;
                                                            }
                                                        }
                                                    } catch (Exception e5) {
                                                        e = e5;
                                                        r1 = "iccException = ";
                                                    }
                                                } catch (Exception e6) {
                                                    e = e6;
                                                    r1 = message6;
                                                }
                                            } catch (Exception e7) {
                                                e = e7;
                                                r1 = message6;
                                            }
                                        } else {
                                            try {
                                                loge("ar.exception = " + asyncResult3.exception);
                                                sendResult(message6, null, asyncResult3.exception);
                                                try {
                                                    sendErrReport(192, iccIoContext.mEfid, iccIoContext.mPath, 0, 0, 15, null, null, asyncResult3.exception.toString());
                                                    return;
                                                } catch (Exception e8) {
                                                    e = e8;
                                                    r1 = message6;
                                                }
                                            } catch (Exception e9) {
                                                e = e9;
                                                r1 = message6;
                                            }
                                        }
                                    } catch (Exception e10) {
                                        e = e10;
                                        r1 = message6;
                                    }
                                    break;
                                case 7:
                                    AsyncResult asyncResult4 = (AsyncResult) message.obj;
                                    IccIoContext iccIoContext2 = (IccIoContext) asyncResult4.userObj;
                                    IccIoResult iccIoResult4 = (IccIoResult) asyncResult4.result;
                                    r1 = iccIoContext2.mOnLoaded;
                                    if (asyncResult4.exception == null) {
                                        IccException exception4 = iccIoResult4.getException();
                                        if (exception4 == null) {
                                            if (iccIoContext2.mLoadAll) {
                                                iccIoContext2.results.add(iccIoResult4.payload);
                                                iccIoContext2.mRecordNum++;
                                                if (iccIoContext2.mRecordNum <= iccIoContext2.mCountRecords) {
                                                    try {
                                                        this.mCi.iccIO(178, iccIoContext2.mEfid, getEFPath(iccIoContext2.mEfid), iccIoContext2.mRecordNum, 4, iccIoContext2.mRecordSize, (String) null, (String) null, obtainMessage(7, 0, i2, iccIoContext2));
                                                        return;
                                                    } catch (Exception e11) {
                                                        e = e11;
                                                    }
                                                } else {
                                                    sendResult(r1, iccIoContext2.results, null);
                                                }
                                            } else {
                                                sendResult(r1, iccIoResult4.payload, null);
                                            }
                                            break;
                                        } else {
                                            logd("iccException=" + exception4);
                                            if (!iccIoContext2.mLoadAll || iccIoContext2.results == null || iccIoContext2.results.size() <= 0) {
                                                sendResult(r1, null, exception4);
                                            } else {
                                                sendResult(r1, iccIoContext2.results, null);
                                            }
                                        }
                                    } else {
                                        logd("ar.exception=" + asyncResult4.exception);
                                        sendResult(r1, null, asyncResult4.exception);
                                    }
                                    return;
                                case 8:
                                    try {
                                        AsyncResult asyncResult5 = (AsyncResult) message.obj;
                                        IccIoContext iccIoContext3 = (IccIoContext) asyncResult5.userObj;
                                        IccIoResult iccIoResult5 = (IccIoResult) asyncResult5.result;
                                        Message message7 = iccIoContext3.mOnLoaded;
                                        try {
                                            if (asyncResult5.exception == null) {
                                                try {
                                                    byte[] bArr2 = iccIoResult5.payload;
                                                    try {
                                                        int i7 = iccIoContext3.mEfid;
                                                        IccException exception5 = iccIoResult5.getException();
                                                        if (exception5 == null) {
                                                            if (i7 == 20272) {
                                                                try {
                                                                    if (!isDataValid(bArr2)) {
                                                                        if (loadFileAgain(i7, i2, message.what, iccIoContext3)) {
                                                                            logd("load again return");
                                                                            return;
                                                                        }
                                                                    }
                                                                } catch (Exception e12) {
                                                                    e = e12;
                                                                    r1 = message7;
                                                                }
                                                                break;
                                                            }
                                                            if (exception5 != null) {
                                                                message2 = message7;
                                                                if (4 == bArr2[6]) {
                                                                    if (1 != bArr2[13]) {
                                                                        i = 3;
                                                                        if (3 == bArr2[13]) {
                                                                        }
                                                                    } else {
                                                                        i = 3;
                                                                    }
                                                                    int[] iArr = new int[i];
                                                                    iArr[0] = bArr2[14] & 255;
                                                                    iArr[1] = ((bArr2[2] & 255) << 8) + (bArr2[3] & 255);
                                                                    iArr[2] = iArr[1] / iArr[0];
                                                                    sendResult(message2, iArr, null);
                                                                }
                                                                throw new IccFileTypeMismatch();
                                                            }
                                                            loge("iccException = " + exception5);
                                                            message2 = message7;
                                                            sendResult(message2, null, exception5);
                                                            return;
                                                        }
                                                        if (loadFileAgain(i7, i2, message.what, iccIoContext3)) {
                                                            logd("load again return");
                                                            return;
                                                        }
                                                        try {
                                                            if (exception5 != null) {
                                                                message2 = message7;
                                                                if (4 == bArr2[6]) {
                                                                    if (1 != bArr2[13]) {
                                                                        i = 3;
                                                                        if (3 == bArr2[13]) {
                                                                        }
                                                                    } else {
                                                                        i = 3;
                                                                    }
                                                                    int[] iArr2 = new int[i];
                                                                    iArr2[0] = bArr2[14] & 255;
                                                                    iArr2[1] = ((bArr2[2] & 255) << 8) + (bArr2[3] & 255);
                                                                    iArr2[2] = iArr2[1] / iArr2[0];
                                                                    sendResult(message2, iArr2, null);
                                                                }
                                                                throw new IccFileTypeMismatch();
                                                            }
                                                            loge("iccException = " + exception5);
                                                            message2 = message7;
                                                            sendResult(message2, null, exception5);
                                                            return;
                                                        } catch (Exception e13) {
                                                            e = e13;
                                                            r1 = "iccException = ";
                                                        }
                                                    } catch (Exception e14) {
                                                        e = e14;
                                                        r1 = message7;
                                                    }
                                                } catch (Exception e15) {
                                                    e = e15;
                                                    r1 = message7;
                                                }
                                            } else {
                                                try {
                                                    loge("ar.exception = " + asyncResult5.exception);
                                                    try {
                                                        sendResult(message7, null, asyncResult5.exception);
                                                        try {
                                                            sendErrReport(192, iccIoContext3.mEfid, iccIoContext3.mPath, 0, 0, 15, null, null, asyncResult5.exception.toString());
                                                            return;
                                                        } catch (Exception e16) {
                                                            e = e16;
                                                            r1 = message7;
                                                        }
                                                    } catch (Exception e17) {
                                                        e = e17;
                                                        r1 = message7;
                                                    }
                                                } catch (Exception e18) {
                                                    e = e18;
                                                }
                                            }
                                        } catch (Exception e19) {
                                            e = e19;
                                            r1 = message7;
                                        }
                                    } catch (Exception e20) {
                                        e = e20;
                                    }
                                    break;
                                case 9:
                                    AsyncResult asyncResult6 = (AsyncResult) message.obj;
                                    IccIoContext iccIoContext4 = (IccIoContext) asyncResult6.userObj;
                                    IccIoResult iccIoResult6 = (IccIoResult) asyncResult6.result;
                                    r1 = iccIoContext4.mOnLoaded;
                                    try {
                                        if (asyncResult6.exception != null) {
                                            logd("EVENT_READ_IMG_DONE ar fail");
                                            sendResult(r1, null, asyncResult6.exception);
                                            return;
                                        }
                                        IccException exception6 = iccIoResult6.getException();
                                        if (exception6 != null) {
                                            logd("EVENT_READ_IMG_DONE icc fail");
                                            sendResult(r1, null, exception6);
                                            return;
                                        }
                                        byte[] bArr3 = iccIoResult6.payload;
                                        int i8 = iccIoContext4.mEfid;
                                        int i9 = iccIoContext4.mRecordNum;
                                        try {
                                            if (4 != bArr3[6]) {
                                                throw new IccFileTypeMismatch();
                                            }
                                            if (1 != bArr3[13]) {
                                                throw new IccFileTypeMismatch();
                                            }
                                            iccIoContext4.mRecordSize = bArr3[14] & 255;
                                            iccIoContext4.mCountRecords = (((bArr3[2] & 255) << 8) + (bArr3[3] & 255)) / iccIoContext4.mRecordSize;
                                            if (iccIoContext4.mLoadAll) {
                                                iccIoContext4.results = new ArrayList<>(iccIoContext4.mCountRecords);
                                            }
                                            this.mCi.iccIO(178, iccIoContext4.mEfid, getEFPath(iccIoContext4.mEfid), iccIoContext4.mRecordNum, 4, iccIoContext4.mRecordSize, (String) null, (String) null, obtainMessage(7, iccIoContext4));
                                            return;
                                        } catch (Exception e21) {
                                            e = e21;
                                            r1 = obj2;
                                        }
                                    } catch (Exception e22) {
                                        e = e22;
                                    }
                                    break;
                                case 10:
                                    AsyncResult asyncResult7 = (AsyncResult) message.obj;
                                    Message message8 = (Message) asyncResult7.userObj;
                                    IccIoResult iccIoResult7 = (IccIoResult) asyncResult7.result;
                                    if (iccIoResult7.getException() != null) {
                                        sendResult(message8, iccIoResult7.payload, asyncResult7.exception);
                                        return;
                                    } else {
                                        sendResult(message8, iccIoResult7.payload, null);
                                        return;
                                    }
                                case EVENT_READ_EF_LINEAR_RECORD_DONE /* 1001 */:
                                    AsyncResult asyncResult8 = (AsyncResult) message.obj;
                                    IccIoResult iccIoResult8 = (IccIoResult) asyncResult8.result;
                                    Message message9 = (Message) asyncResult8.userObj;
                                    if (processException(message9, (AsyncResult) message.obj)) {
                                        return;
                                    }
                                    sendResult(message9, iccIoResult8.payload, null);
                                    return;
                                default:
                                    super.handleMessage(message);
                                    return;
                            }
                        } catch (Exception e23) {
                            e = e23;
                        }
                    } catch (Exception e24) {
                        e = e24;
                    }
                } catch (Exception e25) {
                    e = e25;
                    r1 = 0;
                }
            } catch (Exception e26) {
                e = e26;
                r1 = message3;
            }
        } catch (Exception e27) {
            e = e27;
        }
        e.printStackTrace();
        if (r1 == 0 || r1.getTarget() == null) {
            loge("uncaught exception" + e);
        } else {
            sendResult(r1, null, e);
        }
    }

    public void loadEFLinearFixed(int fileid, int recordNum, Message onLoaded) {
        loadEFLinearFixed(fileid, getEFPath(fileid), recordNum, onLoaded);
    }

    public void loadEFLinearFixed(int fileid, String path, int recordNum, Message onLoaded) {
        String efPath = path == null ? getEFPath(fileid) : path;
        Message response = obtainMessage(6, new IccIoContext(fileid, recordNum, efPath, onLoaded));
        this.mCi.iccIOForApp(192, fileid, efPath, 0, 0, 15, (String) null, (String) null, this.mAid, response);
    }

    public void loadEFLinearFixed(int fileid, int recordNum, int recordSize, Message onLoaded) {
        Message response = obtainMessage(EVENT_READ_EF_LINEAR_RECORD_DONE, fileid, recordNum, onLoaded);
        this.mCi.iccIOForApp(178, fileid, getEFPath(fileid), recordNum, 4, recordSize, (String) null, (String) null, this.mAid, response);
    }

    public void loadEFLinearFixedAll(int fileid, Message onLoaded) {
        loadEFLinearFixedAll(fileid, getEFPath(fileid), onLoaded);
    }

    public void loadEFLinearFixedAll(int fileid, String path, Message onLoaded) {
        String efPath = path == null ? getEFPath(fileid) : path;
        Message response = obtainMessage(6, new IccIoContext(fileid, efPath, onLoaded));
        this.mCi.iccIOForApp(192, fileid, efPath, 0, 0, 15, (String) null, (String) null, this.mAid, response);
    }

    public void loadEFImgLinearFixed(int recordNum, Message onLoaded) {
        Message response = obtainMessage(11, new IccIoContext(20256, recordNum, onLoaded));
        this.mCi.iccIOForApp(192, 20256, getEFPath(20256), recordNum, 4, 10, (String) null, (String) null, this.mAid, response);
    }

    public void getEFLinearRecordSize(int fileid, Message onLoaded) {
        getEFLinearRecordSize(fileid, getEFPath(fileid), onLoaded);
    }

    public void getEFLinearRecordSize(int fileid, String path, Message onLoaded) {
        String efPath = path == null ? getEFPath(fileid) : path;
        Message response = obtainMessage(8, new IccIoContext(fileid, efPath, onLoaded));
        this.mCi.iccIOForApp(192, fileid, efPath, 0, 0, 15, (String) null, (String) null, this.mAid, response);
    }

    public void updateEFCYCLICLinearFixed(int fileid, int recordNum, byte[] data, String pin2, Message onComplete) {
        this.mCi.iccIO(220, fileid, getEFPath(fileid), recordNum, 3, data.length, IccUtils.bytesToHexString(data), pin2, onComplete);
    }

    public void sendErrReport(int command, int efid, String path, int p1, int p2, int p3, String data, String pin, String exception) {
        UniTeleUtils.sendErrReport(this.mContext, this.mParentApp.getPhoneId(), command, efid, path, p1, p2, p3, data, pin, this.mAid, exception);
    }

    protected String getEFPath(int efid) {
        String path = getEfPathFromList(efid);
        if (path != null) {
            return path;
        }
        switch (efid) {
            case UniIccConstants.EF_DIR /* 12032 */:
                return "3F00";
            case 20272:
                Map<Integer, String> map = this.mDualMapFileList;
                return map != null ? map.get(20272) : "3F007F105F3A";
            case 28421:
            case 28465:
            case 28478:
            case 28479:
            case 28480:
            case UniIccConstants.EF_PLMN_ACT /* 28512 */:
            case 28513:
            case 28514:
            case 28539:
            case 28633:
            case 28636:
                return "3F007FFF";
            case 28433:
            case 28435:
            case 28436:
            case 28437:
            case 28438:
            case 28439:
            case 28440:
                return "3F007F20";
            case UniIccConstants.EF_ESNME /* 28472 */:
            case 28486:
            case 28494:
            case 28589:
            case UniIccConstants.EF_ECC /* 28599 */:
            case 28613:
            case 28614:
            case 28615:
            case 28616:
            case 28617:
            case 28618:
            case 28619:
            case 28621:
                return "3F007FFF";
            case 28475:
            case 28491:
                return "3F007FFF";
            case 28476:
                return "3F007FFF";
            default:
                String path2 = getCommonIccEFPath(efid);
                if (path2 == null) {
                    Map<Integer, String> map2 = this.mDualMapFileList;
                    return map2 != null ? map2.get(20272) : "3F007F105F3A";
                }
                return path2;
        }
    }

    protected String getCommonIccEFPath(int efid) {
        switch (efid) {
            case 12037:
            case 12258:
                return "3F00";
            case 20256:
                return "3F007F105F50";
            case 20272:
                return "3F007F105F3A";
            case 28474:
            case 28475:
            case 28480:
            case UniIccConstants.EF_LND /* 28484 */:
            case 28489:
            case 28490:
            case 28491:
            case 28492:
            case 28645:
                return "3F007F10";
            default:
                return null;
        }
    }

    protected String getEFPathofUsim(int efid) {
        String pathSecond;
        String oldPath = getEFPath(efid);
        String pathLast = "";
        if (oldPath.length() < 8) {
            return null;
        }
        String pathFirst = oldPath.substring(0, 4);
        String pathSecond2 = oldPath.substring(4, 8);
        if (oldPath.length() > 8) {
            pathLast = oldPath.substring(8, oldPath.length());
        }
        logd("getEFPathofUsim false , try again pathFirst " + pathFirst + ", pathSecond " + pathSecond2 + ", pathLast " + pathLast + ", efid: " + efid);
        if (pathSecond2.equals(UniIccConstants.DF_ADFISIM)) {
            pathSecond = "7F10";
        } else {
            if (!pathSecond2.equals("7F10")) {
                return null;
            }
            pathSecond = UniIccConstants.DF_ADFISIM;
        }
        String newPath = pathFirst + pathSecond + pathLast;
        UpdatePathOfDualMapFile(efid, newPath);
        return newPath;
    }

    protected void finalize() throws Throwable {
        super.finalize();
        logd("UsimFileHandler finalized");
    }

    protected void logd(String msg) {
        Rlog.d(TAG, msg);
    }

    protected void loge(String msg) {
        Rlog.e(TAG, msg);
    }

    private void initDualMapFileSet() {
        this.mDualMapFileList = new HashMap();
        this.mFileList = new ArrayList<>();
        this.mDualMapFileList.put(Integer.valueOf(this.mDualMapFile[0]), "3F007FFF");
        this.mDualMapFileList.put(Integer.valueOf(this.mDualMapFile[1]), "3F007F105F3A");
        this.mDualMapFileList.put(Integer.valueOf(this.mDualMapFile[2]), "3F007FFF");
        this.mDualMapFileList.put(Integer.valueOf(this.mDualMapFile[3]), "3F007FFF");
    }

    private void clearDualMapFileSet() {
        if (this.mFileList != null) {
            this.mFileList = null;
        }
        Map<Integer, String> map = this.mDualMapFileList;
        if (map != null) {
            map.clear();
            this.mDualMapFileList = null;
        }
    }

    private void UpdatePathOfDualMapFile(int efid, String path) {
        Map<Integer, String> map = this.mDualMapFileList;
        if (map != null) {
            map.put(Integer.valueOf(efid), path);
        }
    }

    public void dispose() {
        super.dispose();
        clearDualMapFileSet();
    }

    private boolean isDualMapFile(int fileId) {
        Map<Integer, String> map = this.mDualMapFileList;
        return map != null && map.containsKey(Integer.valueOf(fileId));
    }

    private boolean isFinishLoadFile(int fileId, int pathNum) {
        logd("isFinishLoadFile  fileId: " + fileId + ", pathNum: " + pathNum);
        return (isDualMapFile(fileId) && pathNum != 1 && pathNum == 0) ? false : true;
    }

    private boolean loadFileAgain(int fileId, int pathNum, int event, Object obj) {
        String newPath;
        if (isFinishLoadFile(fileId, pathNum) || (newPath = getEFPathofUsim(fileId)) == null) {
            return false;
        }
        ((IccIoContext) obj).mPath = newPath;
        Message response = obtainMessage(event, fileId, 1, obj);
        logd("isFinishLoadFile  try again newPath   " + newPath);
        this.mCi.iccIO(192, fileId, newPath, 0, 0, 15, (String) null, (String) null, response);
        return true;
    }

    private String getEfPathFromList(int efid) {
        Map<Integer, String> map = this.mDualMapFileList;
        if (map == null) {
            return null;
        }
        if (map.containsKey(Integer.valueOf(efid))) {
            String path = this.mDualMapFileList.get(Integer.valueOf(efid));
            if (path != null) {
                return path;
            }
        }
        if (this.mFileList == null) {
            return null;
        }
        for (int i = 0; i < this.mFileList.size(); i++) {
            if (this.mFileList.get(i).intValue() == efid) {
                String path2 = this.mDualMapFileList.get(20272);
                if (path2 != null) {
                    return path2;
                }
            }
        }
        return null;
    }

    protected void logbyte(byte[] data) {
        new String();
        for (byte b : data) {
            String test = Integer.toHexString(b & 255);
            if (test.length() == 1) {
                String str = '0' + test;
            }
        }
    }

    protected boolean isDataValid(byte[] data) {
        for (byte b : data) {
            if (b != -1) {
                return true;
            }
        }
        return false;
    }

    private void sendResult(Message response, Object result, Throwable ex) {
        if (response == null) {
            return;
        }
        AsyncResult.forMessage(response, result, ex);
        response.sendToTarget();
    }

    private boolean processException(Message response, AsyncResult ar) {
        IccIoResult result = (IccIoResult) ar.result;
        if (ar.exception != null) {
            sendResult(response, null, ar.exception);
            return true;
        }
        IccException iccException = result.getException();
        if (iccException == null) {
            return false;
        }
        sendResult(response, null, iccException);
        return true;
    }
}
