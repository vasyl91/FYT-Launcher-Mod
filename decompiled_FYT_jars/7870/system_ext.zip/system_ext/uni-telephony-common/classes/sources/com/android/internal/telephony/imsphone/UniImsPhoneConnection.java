package com.android.internal.telephony.imsphone;

import android.telephony.Rlog;
import com.android.ims.ImsCall;
import com.android.internal.telephony.Call;
import com.android.internal.telephony.Phone;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniImsPhoneConnection extends ImsPhoneConnection {
    public static final String LOG_TAG = "UniImsPhoneConnection";

    public UniImsPhoneConnection(Phone phone, ImsCall imsCall, ImsPhoneCallTracker ct, ImsPhoneCall parent, boolean isUnknown) {
        super(phone, imsCall, ct, parent, isUnknown);
    }

    public UniImsPhoneConnection(Phone phone, String dialString, ImsPhoneCallTracker ct, ImsPhoneCall parent, boolean isEmergency, boolean isWpsCall) {
        super(phone, dialString, ct, parent, isEmergency, isWpsCall);
    }

    public UniImsPhoneConnection(Phone phone, String[] participantsToDial, ImsPhoneCallTracker ct, ImsPhoneCall parent, boolean isEmergency) {
        super(phone, participantsToDial, ct, parent, isEmergency);
    }

    public boolean onDisconnect(int cause) {
        Rlog.d(LOG_TAG, "onDisconnect: cause=" + cause + " mCause=" + this.mCause);
        if (this.mCause != 3 || cause == 16) {
            this.mCause = cause;
        }
        return onDisconnect();
    }

    public boolean update(ImsCall imsCall, Call.State state) {
        boolean updateParent = false;
        if (state == Call.State.ACTIVE && (getCall().getState().isRinging() || getCall() == getOwner().mBackgroundCall)) {
            updateParent = true;
        }
        return super.update(imsCall, state) || updateParent;
    }
}
