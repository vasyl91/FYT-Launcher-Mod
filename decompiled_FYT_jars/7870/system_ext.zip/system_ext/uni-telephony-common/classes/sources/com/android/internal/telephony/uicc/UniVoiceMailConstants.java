package com.android.internal.telephony.uicc;

import android.os.Environment;
import android.util.Xml;
import com.android.internal.telephony.util.XmlUtils;
import com.android.telephony.Rlog;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
class UniVoiceMailConstants {
    static final String LOG_TAG = "VoiceMailConstants";
    static final int NAME = 0;
    static final int NUMBER = 1;
    static final String PARTNER_VOICEMAIL_PATH = "etc/voicemail-conf.xml";
    static final int SIZE = 3;
    static final int TAG = 2;
    private HashMap<String, String[]> CarrierVmMap = new HashMap<>();

    UniVoiceMailConstants() {
        loadVoiceMail();
    }

    boolean containsCarrier(String carrier) {
        return this.CarrierVmMap.containsKey(carrier);
    }

    String getCarrierName(String carrier) {
        String[] data = this.CarrierVmMap.get(carrier);
        return data[0];
    }

    String getVoiceMailNumber(String carrier) {
        String[] data = this.CarrierVmMap.get(carrier);
        return data[1];
    }

    String getVoiceMailTag(String carrier) {
        String[] data = this.CarrierVmMap.get(carrier);
        return data[2];
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v0, types: [java.io.File] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.io.FileReader, java.io.Reader] */
    private void loadVoiceMail() {
        FileReader rootDirectory = Environment.getRootDirectory();
        File vmFile = new File((File) rootDirectory, PARTNER_VOICEMAIL_PATH);
        try {
            try {
                try {
                    rootDirectory = new FileReader(vmFile);
                    try {
                        try {
                            XmlPullParser xmlPullParserNewPullParser = Xml.newPullParser();
                            xmlPullParserNewPullParser.setInput(rootDirectory);
                            XmlUtils.beginDocument(xmlPullParserNewPullParser, "voicemail");
                            while (true) {
                                XmlUtils.nextElement(xmlPullParserNewPullParser);
                                String name = xmlPullParserNewPullParser.getName();
                                if (!"voicemail".equals(name)) {
                                    break;
                                }
                                String numeric = xmlPullParserNewPullParser.getAttributeValue(null, "numeric");
                                String[] data = {xmlPullParserNewPullParser.getAttributeValue(null, "carrier"), xmlPullParserNewPullParser.getAttributeValue(null, "vmnumber"), xmlPullParserNewPullParser.getAttributeValue(null, "vmtag")};
                                this.CarrierVmMap.put(numeric, data);
                            }
                            rootDirectory.close();
                        } catch (XmlPullParserException e) {
                            Rlog.w(LOG_TAG, "Exception in Voicemail parser " + e);
                            rootDirectory.close();
                        }
                    } catch (IOException e2) {
                        Rlog.w(LOG_TAG, "Exception in Voicemail parser " + e2);
                        rootDirectory.close();
                    }
                } catch (FileNotFoundException e3) {
                    Rlog.w(LOG_TAG, "Can't open " + Environment.getRootDirectory() + "/" + PARTNER_VOICEMAIL_PATH);
                }
            } catch (Throwable th) {
                try {
                    rootDirectory.close();
                } catch (IOException e4) {
                }
                throw th;
            }
        } catch (IOException e5) {
        }
    }
}
