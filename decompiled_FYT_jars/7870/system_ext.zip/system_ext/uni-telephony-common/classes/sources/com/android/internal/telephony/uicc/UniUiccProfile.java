package com.android.internal.telephony.uicc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.os.PersistableBundle;
import android.os.SystemProperties;
import android.telephony.CarrierConfigManager;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.text.TextUtils;
import com.android.internal.telephony.CarrierServiceBindHelper;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.PhoneFactory;
import com.android.internal.telephony.SubscriptionController;
import com.android.internal.telephony.UniTeleUtils;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniUiccProfile extends UiccProfile {
    protected static final boolean DBG = SystemProperties.get("ro.build.type").equalsIgnoreCase("userdebug");
    private static final int EVENT_ICC_RECORD_KEY_INFO_LOADED_DONE = 18;
    private static final int EVENT_ICC_RECORD_LOADED_DONE = 160;
    private static final int EVENT_LOCALE_CHANGED = 17;
    protected static final String LOG_TAG = "UniUiccProfile";
    private final BroadcastReceiver mBroadcastReceiver;
    private CarrierServiceBindHelper mCarrierServiceBindHelper;
    private Context mContext;
    private int mCurrentAppType;
    public final Handler mHandler;
    private int mPhoneId;

    /* JADX INFO: Access modifiers changed from: private */
    public void handleCarierIdUpdate() {
        log("handle carrier id");
        if (PhoneFactory.getPhone(this.mPhoneId) != null) {
            PhoneFactory.getPhone(this.mPhoneId).resolveSubscriptionCarrierId("LOADED");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleCarierServicesUpdate() {
        log("handle carrier service update");
        if (PhoneFactory.getPhone(this.mPhoneId) != null) {
            CarrierConfigManager configManager = new CarrierConfigManager(PhoneFactory.getPhone(this.mPhoneId).getContext());
            configManager.updateConfigForPhoneId(this.mPhoneId, "LOADED");
            this.mCarrierServiceBindHelper.updateForPhoneId(this.mPhoneId, "LOADED");
        }
    }

    private void registerAppEvent() {
        UniSIMRecords ir;
        UiccCardApplication app = getApplication(this.mCurrentAppType);
        if (app != null && (ir = app.getIccRecords()) != null) {
            log("registerUiccCardEvents: registering for EVENT_ICC_RECORD_KEY_INFO_LOADED_DONE");
            ir.registerForKeyInfoRecordsLoaded(this.mHandler, 18, null);
            if (DBG) {
                log("registerUiccCardEvents: registering for EVENT_ICC_RECORD_LOADED_DONE");
            }
            ir.registerForRecordsLoaded(this.mHandler, EVENT_ICC_RECORD_LOADED_DONE, null);
        }
    }

    private void unregisterAppEvent() {
        UniSIMRecords ir;
        UiccCardApplication app = getApplication(this.mCurrentAppType);
        if (app != null && (ir = app.getIccRecords()) != null) {
            ir.unregisterForKeyInfoRecordsLoaded(this.mHandler);
        }
    }

    public void setVoiceRadioTech(int radioTech) {
        log("Setting radio tech " + ServiceState.rilRadioTechnologyToString(radioTech));
        unregisterAppEvent();
        registerAppEvent();
        super.setVoiceRadioTech(radioTech);
    }

    public void update(Context c, CommandsInterface ci, IccCardStatus ics) {
        super.update(c, ci, ics);
        unregisterAppEvent();
        registerAppEvent();
    }

    public UniUiccProfile(Context c, CommandsInterface ci, IccCardStatus ics, int phoneId, UiccCard uiccCard, Object lock) {
        super(c, ci, ics, phoneId, uiccCard, lock);
        this.mCurrentAppType = 1;
        BroadcastReceiver broadcastReceiver = new BroadcastReceiver() { // from class: com.android.internal.telephony.uicc.UniUiccProfile.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals("android.intent.action.LOCALE_CHANGED")) {
                    UniUiccProfile.this.mHandler.sendMessage(UniUiccProfile.this.mHandler.obtainMessage(17));
                }
            }
        };
        this.mBroadcastReceiver = broadcastReceiver;
        this.mHandler = new Handler() { // from class: com.android.internal.telephony.uicc.UniUiccProfile.2
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 17:
                        UniUiccProfile.this.handleCarrierNameOverride();
                        break;
                    case 18:
                        UniUiccProfile.log("notifyIccRecordKeyInfoLoaded mPhoneId : " + UniUiccProfile.this.mPhoneId);
                        UniUiccProfile.this.handleCarierIdUpdate();
                        break;
                    case UniUiccProfile.EVENT_ICC_RECORD_LOADED_DONE /* 160 */:
                        UniUiccProfile.log("notifyIccRecordLoaded mPhoneId : " + UniUiccProfile.this.mPhoneId);
                        UniUiccProfile.this.handleCarierServicesUpdate();
                        break;
                    default:
                        super.handleMessage(msg);
                        break;
                }
            }
        };
        this.mPhoneId = phoneId;
        this.mContext = c;
        IntentFilter intentfilter = new IntentFilter();
        intentfilter.addAction("android.intent.action.LOCALE_CHANGED");
        c.registerReceiver(broadcastReceiver, intentfilter);
        this.mCarrierServiceBindHelper = new CarrierServiceBindHelper(this.mContext);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void log(String msg) {
        if (DBG) {
            Rlog.d(LOG_TAG, msg);
        }
    }

    private static void loge(String msg) {
        if (DBG) {
            Rlog.e(LOG_TAG, msg);
        }
    }

    public void dispose() {
        if (DBG) {
            log("Disposing UniUiccProfile");
        }
        super.dispose();
        this.mContext.unregisterReceiver(this.mBroadcastReceiver);
        this.mCarrierServiceBindHelper.unRegisterUserUnlockedReceiver();
    }

    protected void handleCarrierNameOverride() {
        Phone phone;
        log("handleCarrierNameOverride");
        SubscriptionController subCon = SubscriptionController.getInstance();
        int subId = subCon.getSubIdUsingPhoneId(this.mPhoneId);
        if (subId == -1) {
            loge("subId not valid for Phone " + this.mPhoneId);
            return;
        }
        CarrierConfigManager configLoader = (CarrierConfigManager) this.mContext.getSystemService("carrier_config");
        if (configLoader == null) {
            loge("Failed to load a Carrier Config");
            return;
        }
        PersistableBundle config = configLoader.getConfigForSubId(subId);
        boolean preferCcName = config.getBoolean("carrier_name_override_bool", false);
        String ccName = config.getString("carrier_name_string");
        String newCarrierName = null;
        String currSpn = getServiceProviderName();
        int nameSource = 1;
        if (preferCcName || (TextUtils.isEmpty(currSpn) && !TextUtils.isEmpty(ccName))) {
            newCarrierName = ccName;
            nameSource = 3;
        } else if (TextUtils.isEmpty(currSpn) && (phone = PhoneFactory.getPhone(this.mPhoneId)) != null) {
            newCarrierName = phone.getCarrierName();
            nameSource = 0;
        }
        if (!TextUtils.isEmpty(newCarrierName)) {
            this.mTelephonyManager.setSimOperatorNameForPhone(this.mPhoneId, newCarrierName);
            this.mOperatorBrandOverrideRegistrants.notifyRegistrants();
        }
        String simOperatorName = this.mTelephonyManager.getSimOperatorNameForPhone(this.mPhoneId);
        String updateSimOperatorName = UniTeleUtils.translateOperatorName(this.mContext, this.mTelephonyManager.getSimOperatorNumericForPhone(this.mPhoneId), simOperatorName);
        if (!preferCcName && !updateSimOperatorName.equals(simOperatorName)) {
            this.mTelephonyManager.setSimOperatorNameForPhone(this.mPhoneId, updateSimOperatorName);
        }
        updateCarrierNameForSubscription(subCon, subId, nameSource);
    }
}
