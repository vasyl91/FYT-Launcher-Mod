package com.android.internal.telephony.uicc;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Message;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.phonebook.UniAdnRecordCache;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniRuimRecords extends RuimRecords {
    private static final int EVENT_GET_CDMA_SUBSCRIPTION_DONE = 10;
    private static final int EVENT_GET_ICCID_DONE = 5;
    private String mMeid;
    public UniAdnRecordCache mUniAdnCache;

    public UniRuimRecords(UiccCardApplication app, Context c, CommandsInterface ci) {
        super(app, c, ci);
        this.mUniAdnCache = new UniAdnRecordCache(this.mFh);
    }

    public void onRefresh(boolean fileChanged, int[] fileList) {
        if (fileChanged) {
            fetchRuimRecords();
        }
    }

    public void onReady() {
        fetchRuimRecords();
        this.mCi.getCDMASubscription(obtainMessage(10));
    }

    public void handleMessage(Message msg) {
        boolean isRecordLoadResponse = false;
        try {
            if (this.mDestroyed.get()) {
                loge("Received message " + msg + "[" + msg.what + "] while being destroyed. Ignoring.");
                return;
            }
            try {
                switch (msg.what) {
                    case 5:
                        isRecordLoadResponse = true;
                        AsyncResult ar = (AsyncResult) msg.obj;
                        byte[] data = (byte[]) ar.result;
                        if (ar.exception == null) {
                            this.mFullIccId = IccUtils.bchToString(data, 0, data.length);
                            if (this.mFullIccId.matches("(F|f){20}")) {
                                this.mFullIccId = String.format("%020d", 0);
                            }
                            this.mIccId = this.mFullIccId;
                        }
                        break;
                    default:
                        super.handleMessage(msg);
                        break;
                }
            } catch (RuntimeException exc) {
                log("Exception parsing RUIM record: " + exc);
            }
        } finally {
            if (0 != 0) {
                onRecordLoaded();
            }
        }
    }

    protected void fetchRuimRecords() {
        super.fetchRuimRecords();
        log("fetchRuimRecords " + this.mRecordsToLoad);
        this.mFh.loadEFTransparent(UniIccConstants.EF_ESNME, 8, obtainMessage(100, new EfCsimMeidLoaded()));
        this.mRecordsToLoad++;
    }

    private class EfCsimMeidLoaded implements IccRecords.IccRecordLoaded {
        private EfCsimMeidLoaded() {
        }

        public String getEfName() {
            return "EF_ESNME";
        }

        public void onRecordLoaded(AsyncResult ar) {
            UniRuimRecords.this.onGetCSimMeidDone(ar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onGetCSimMeidDone(AsyncResult ar) {
        byte[] data = (byte[]) ar.result;
        String hexStr = IccUtils.bytesToHexString(data);
        String meid = "";
        if (hexStr != null && hexStr.length() == 16) {
            for (int i = 0; i < 7; i++) {
                meid = meid + hexStr.charAt(14 - (i * 2)) + "" + hexStr.charAt(15 - (i * 2));
            }
        } else {
            loge("Fail to get MEID on CSIM.");
        }
        this.mMeid = meid;
    }

    public String getMeid() {
        return this.mMeid;
    }

    public UniAdnRecordCache getUniAdnRecordCache() {
        return this.mUniAdnCache;
    }

    protected void handleFileUpdate(int efid) {
        this.mUniAdnCache.resetWithFileUpdate();
        this.mLoaded.set(false);
        this.mAdnCache.reset();
        fetchRuimRecords();
    }

    public void dispose() {
        this.mUniAdnCache.reset();
        super.dispose();
    }
}
