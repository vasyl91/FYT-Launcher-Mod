package com.android.internal.telephony.emergency;

import android.content.Context;
import android.os.Environment;
import android.telephony.Rlog;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.text.TextUtils;
import android.util.Log;
import android.util.Xml;
import com.android.i18n.phonenumbers.PhoneNumberUtil;
import com.android.internal.util.XmlUtils;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class CountryIsoConfig {
    static final String COUNTRYISO_LIST_PATH = "etc/countryIso-conf.xml";
    public static String KEY_ICCISSUEID = "iccIssueId";
    public static String KEY_ISO = "countryIso";
    private static final String TAG = "CountryIsoConfig";
    private Context mContext;
    Map<String, String> mCountryIsoMap = new HashMap();

    public CountryIsoConfig(Context context) {
        this.mContext = context;
        loadPrebuiltConfig();
    }

    public boolean containsIccId(String iccId) {
        if (this.mCountryIsoMap.containsKey(iccId)) {
            return true;
        }
        return false;
    }

    public String getCountryIso(String iccId) {
        return this.mCountryIsoMap.get(iccId);
    }

    private void loadPrebuiltConfig() {
        if (this.mCountryIsoMap.size() > 0) {
            return;
        }
        File countryIsoFile = new File(Environment.getProductDirectory(), COUNTRYISO_LIST_PATH);
        try {
            FileReader countryIsotReader = new FileReader(countryIsoFile);
            try {
                XmlPullParser parser = Xml.newPullParser();
                parser.setInput(countryIsotReader);
                XmlUtils.beginDocument(parser, "countryIsoByIccIssueId");
                while (true) {
                    XmlUtils.nextElement(parser);
                    String name = parser.getName();
                    if ("countryIsoByIccIssueId".equals(name)) {
                        String iccId = parser.getAttributeValue(null, KEY_ICCISSUEID);
                        String countryIso = parser.getAttributeValue(null, KEY_ISO);
                        this.mCountryIsoMap.put(iccId, countryIso);
                    } else {
                        countryIsotReader.close();
                        return;
                    }
                }
            } catch (IOException e) {
                Rlog.w(TAG, "Exception in country-conf parser " + e);
            } catch (IndexOutOfBoundsException e2) {
                Rlog.w(TAG, "Exception in country-conf parser " + e2);
            } catch (XmlPullParserException e3) {
                Rlog.w(TAG, "Exception in country-conf parser " + e3);
            }
        } catch (FileNotFoundException e4) {
            Rlog.w(TAG, "Can not open " + countryIsoFile.getAbsolutePath());
        }
    }

    public String getIccId(int phoneId) {
        Context context = this.mContext;
        if (context == null) {
            return null;
        }
        SubscriptionManager sm = SubscriptionManager.from(context);
        SubscriptionInfo subInfo = sm.getActiveSubscriptionInfoForSimSlotIndex(phoneId);
        if (subInfo == null || SubscriptionManager.getSimStateForSlotIndex(phoneId) == 10) {
            return null;
        }
        return subInfo.getIccId();
    }

    public String getCountryIsoByIccId(String iccId) {
        if (iccId == null) {
            return "";
        }
        List<String> regionCodes = new ArrayList<>();
        String oneDigitsCountryCode = iccId.length() >= 3 ? iccId.substring(2, 3) : "";
        try {
            regionCodes = PhoneNumberUtil.getInstance().getRegionCodesForCountryCode(Integer.parseInt(oneDigitsCountryCode));
        } catch (NumberFormatException e) {
            Log.e(TAG, "getCountryIsoByIccId: Can't get region codes from iccId, e= " + e);
        }
        if (regionCodes.size() == 0) {
            String twoDigitsCountryCode = iccId.length() >= 4 ? iccId.substring(2, 4) : "";
            try {
                regionCodes = PhoneNumberUtil.getInstance().getRegionCodesForCountryCode(Integer.parseInt(twoDigitsCountryCode));
            } catch (NumberFormatException e2) {
                Log.e(TAG, "getCountryIsoByIccId: Can't get region codes from iccId, e= " + e2);
            }
        }
        if (regionCodes.size() == 0) {
            String threeDigitsCountryCode = iccId.length() >= 5 ? iccId.substring(2, 5) : "";
            try {
                regionCodes = PhoneNumberUtil.getInstance().getRegionCodesForCountryCode(Integer.parseInt(threeDigitsCountryCode));
            } catch (NumberFormatException e3) {
                Log.e(TAG, "getCountryIsoByIccId: Can't get region codes from iccId, e= " + e3);
            }
        }
        if (regionCodes.size() == 1) {
            return regionCodes.get(0);
        }
        if (regionCodes.size() <= 1) {
            return "";
        }
        String sixDigitsIccIssueId = iccId.length() >= 6 ? iccId.substring(0, 6) : "";
        String iso = getCountryIsoByIccIssueId(sixDigitsIccIssueId);
        if (TextUtils.isEmpty(iso)) {
            String sevenDigitsIccIssueId = iccId.length() >= 7 ? iccId.substring(0, 7) : "";
            iso = getCountryIsoByIccIssueId(sevenDigitsIccIssueId);
        }
        if (!TextUtils.isEmpty(iso)) {
            return iso;
        }
        return regionCodes.get(0);
    }

    private String getCountryIsoByIccIssueId(String iccIssueId) {
        if (TextUtils.isEmpty(iccIssueId) || !this.mCountryIsoMap.containsKey(iccIssueId)) {
            return "";
        }
        return this.mCountryIsoMap.get(iccIssueId);
    }
}
