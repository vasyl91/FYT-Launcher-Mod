package com.android.internal.telephony;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.os.ParcelUuid;
import android.os.SystemProperties;
import android.provider.Settings;
import android.telephony.CarrierConfigManager;
import android.telephony.PrimarySubManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.telephony.euicc.EuiccManager;
import android.util.Log;
import com.android.internal.telephony.data.DataSettingsManager;
import com.android.internal.telephony.uicc.UiccCard;
import com.android.internal.telephony.uicc.UiccController;
import com.android.internal.telephony.util.ArrayUtils;
import com.android.unisoc.telephony.RadioInteractor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniMultiSimSettingController extends MultiSimSettingController implements SimStateTracker.OnSimStateChangedListener {
    private static final String DATA_ENABLED_STATE_PROP = "gsm.data.setenabled";
    private static final boolean DBG = true;
    private static final int EVENT_ALL_SUBSCRIPTIONS_LOADED = 3;
    private static final int EVENT_CARRIER_CONFIG_CHANGED = 7;
    private static final int EVENT_MULTI_SIM_CONFIG_CHANGED = 8;
    private static final int EVENT_SUBSCRIPTION_INFO_CHANGED = 4;
    private static final String ICC_ID = "primary_sub_icc_id";
    public static final String ICC_ID_PREFS_NAME = "msms.info.iccid";
    private static final int LIST_DATA = 1;
    private static final int LIST_SMS = 3;
    private static final int LIST_VOICE = 2;
    private static final String LOG_TAG = "UniMultiSimSettingController";
    private static final String PREFS_DEFSUBID_INFO = "prefs.defaultxsubid.info";
    private static final int PRIMARY_SUB_INITIALIZED = 6;
    private static final int PRIMARY_SUB_NO_CHANGE = 0;
    private static final int PRIMARY_SUB_NO_SELECTED_BY_USER = 8;
    private static final int PRIMARY_SUB_SELECTED_BY_USER = 7;
    private static final String SMS_POSITION = "1";
    private static final String VOICE_POSITION = "0";
    private int mCallbacksCount;
    private int[] mCarrierConfigLoadedSubIds;
    private final Context mContext;
    private boolean mInit;
    private final BroadcastReceiver mIntentReceiver;
    private boolean mIsIccChanged;
    private boolean mIsPrefSetbefore;
    private boolean mNeedPopUpSimSettings;
    private List<Integer> mPrimarySubList;
    private PrimarySubManager mPrimarySubManager;
    private RadioInteractor mRadioInteractor;
    private ContentObserver mSetupWizardCompleteObserver;
    private SimStateTracker mSimStateTracker;
    private final SubscriptionController mSubController;
    private boolean mSubInfoInitialized;
    private final SubscriptionManager mSubscriptionManager;
    private List<UiccCard> mUiccCards;
    private UiccController mUiccController;

    /* JADX INFO: Access modifiers changed from: private */
    interface UpdateDefaultAction {
        void update(int i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public UniMultiSimSettingController(Context context, SubscriptionController sc) {
        super(context, sc);
        this.mInit = DBG;
        this.mPrimarySubList = new ArrayList();
        this.mIsPrefSetbefore = false;
        this.mUiccCards = new ArrayList();
        BroadcastReceiver broadcastReceiver = new BroadcastReceiver() { // from class: com.android.internal.telephony.UniMultiSimSettingController.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context2, Intent intent) {
                if ("android.telephony.action.CARRIER_CONFIG_CHANGED".equals(intent.getAction())) {
                    int phoneId = intent.getIntExtra("android.telephony.extra.SLOT_INDEX", -1);
                    int subId = intent.getIntExtra("android.telephony.extra.SUBSCRIPTION_INDEX", -1);
                    UniMultiSimSettingController.this.notifyCarrierConfigChanged(phoneId, subId);
                }
            }
        };
        this.mIntentReceiver = broadcastReceiver;
        this.mSetupWizardCompleteObserver = new ContentObserver(new Handler()) { // from class: com.android.internal.telephony.UniMultiSimSettingController.2
            @Override // android.database.ContentObserver
            public void onChange(boolean selfChange) {
                super.onChange(selfChange);
                UniMultiSimSettingController.this.log("mSetupWizardCompleteObserver : isDeviceProvisioned = " + UniMultiSimSettingController.this.isDeviceProvisioned());
                if (UniMultiSimSettingController.this.isDeviceProvisioned() && UniMultiSimSettingController.this.mNeedPopUpSimSettings) {
                    UniMultiSimSettingController.this.sendSubChangeNotificationIfNeeded(7);
                    UniMultiSimSettingController.this.mNeedPopUpSimSettings = false;
                }
            }
        };
        this.mSimStateTracker = SimStateTracker.init(context);
        this.mContext = context;
        this.mSubController = sc;
        int phoneCount = ((TelephonyManager) context.getSystemService("phone")).getSupportedModemCount();
        int[] iArr = new int[phoneCount];
        this.mCarrierConfigLoadedSubIds = iArr;
        Arrays.fill(iArr, -1);
        PhoneConfigurationManager.registerForMultiSimConfigChange(this, 8, (Object) null);
        context.registerReceiver(broadcastReceiver, new IntentFilter("android.telephony.action.CARRIER_CONFIG_CHANGED"));
        context.getContentResolver().registerContentObserver(Settings.Global.getUriFor("device_provisioned"), false, this.mSetupWizardCompleteObserver);
        this.mPrimarySubManager = PrimarySubManager.from(context);
        this.mSimStateTracker.addOnSimStateChangedListener(this);
        UniCarrierConfigLoader.init(context);
        this.mSubscriptionManager = new SubscriptionManager(context);
        this.mRadioInteractor = new RadioInteractor(context);
        this.mUiccController = UiccController.getInstance();
    }

    public static MultiSimSettingController init(Context context, SubscriptionController sc) {
        MultiSimSettingController multiSimSettingController;
        synchronized (UniMultiSimSettingController.class) {
            if (sInstance == null) {
                sInstance = new UniMultiSimSettingController(context, sc);
            } else {
                Log.wtf(LOG_TAG, "init() called multiple times!  sInstance = " + sInstance);
            }
            multiSimSettingController = sInstance;
        }
        return multiSimSettingController;
    }

    private static class DataSettingsControllerCallback extends DataSettingsManager.DataSettingsManagerCallback {
        private final Phone mPhone;

        DataSettingsControllerCallback(Phone phone, Executor executor) {
            super(executor);
            this.mPhone = phone;
        }

        public void onDataEnabledChanged(boolean enabled, int reason, String callingPackage) {
            int subId = this.mPhone.getSubId();
            if (SubscriptionManager.isValidSubscriptionId(subId) && reason == 0 && !UniMultiSimSettingController.getInstance().mContext.getOpPackageName().equals(callingPackage)) {
                UniMultiSimSettingController.getInstance().notifyUserDataEnabled(this.mPhone.getSubId(), enabled);
            }
        }

        public void onDataRoamingEnabledChanged(boolean enabled) {
            int subId = this.mPhone.getSubId();
            if (SubscriptionManager.isValidSubscriptionId(subId)) {
                UniMultiSimSettingController.getInstance().notifyRoamingDataEnabled(this.mPhone.getSubId(), enabled);
            }
        }
    }

    public static UniMultiSimSettingController getInstance() {
        return (UniMultiSimSettingController) sInstance;
    }

    public void notifySubscriptionInfoChanged() {
        obtainMessage(4).sendToTarget();
    }

    public void notifyCarrierConfigChanged(int phoneId, int subId) {
        obtainMessage(7, phoneId, subId).sendToTarget();
    }

    public void notifyAllSubscriptionLoaded() {
        obtainMessage(3).sendToTarget();
    }

    public void handleMessage(Message msg) {
        switch (msg.what) {
            case 3:
                onAllSubscriptionsLoaded();
                break;
            case 4:
                onSubscriptionsChanged();
                break;
            case 5:
            case 6:
            default:
                super.handleMessage(msg);
                break;
            case 7:
                int activeModems = msg.arg1;
                int subId = msg.arg2;
                onCarrierConfigChanged(activeModems, subId);
                break;
            case 8:
                int activeModems2 = ((Integer) ((AsyncResult) msg.obj).result).intValue();
                onMultiSimConfigChanged(activeModems2);
                break;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void onMultiSimConfigChanged(int activeModems) {
        int phoneId = activeModems;
        while (true) {
            int[] iArr = this.mCarrierConfigLoadedSubIds;
            if (phoneId >= iArr.length) {
                break;
            }
            iArr[phoneId] = -1;
            phoneId++;
        }
        for (Phone phone : PhoneFactory.getPhones()) {
            phone.mCi.registerForRadioStateChanged(this, 9, (Object) null);
        }
        registerDataSettingsControllerCallbackAsNeeded();
    }

    private void onSubscriptionsChanged() {
        log("onSubscriptionsChanged");
        reEvaluateAll();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void onAllSubscriptionsLoaded() {
        log("onAllSubscriptionsLoaded: mSubInfoInitialized=" + this.mSubInfoInitialized);
        if (!this.mSubInfoInitialized) {
            this.mSubInfoInitialized = DBG;
            for (Phone phone : PhoneFactory.getPhones()) {
                phone.mCi.registerForRadioStateChanged(this, 9, (Object) null);
            }
            reEvaluateAll();
        }
        registerDataSettingsControllerCallbackAsNeeded();
    }

    private void onCarrierConfigChanged(int phoneId, int subId) {
        CarrierConfigManager cm;
        log("onCarrierConfigChanged phoneId " + phoneId + " subId " + subId);
        if (!SubscriptionManager.isValidPhoneId(phoneId)) {
            log("Carrier config change with invalid phoneId " + phoneId);
            return;
        }
        if (subId == -1) {
            int[] subIds = this.mSubController.getSubId(phoneId);
            if (!ArrayUtils.isEmpty(subIds) && (cm = (CarrierConfigManager) this.mContext.getSystemService("carrier_config")) != null && cm.getConfigForSubId(subIds[0]) != null) {
                log("onCarrierConfigChanged with invalid subId while subd " + subIds[0] + " is active and its config is loaded");
                subId = subIds[0];
            }
        }
        this.mCarrierConfigLoadedSubIds[phoneId] = subId;
        reEvaluateAll();
    }

    private void reEvaluateAll() {
        if (isReadyToReevaluate()) {
            updateDefaults();
            disableDataForNonDefaultNonOpportunisticSubscriptions();
            deactivateGroupedOpportunisticSubscriptionIfNeeded();
        }
    }

    private void setDefaultXSubIdtoPreference(String pref, String position, int subId) {
        SharedPreferences sp = this.mContext.getSharedPreferences(pref, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt(position, subId);
        editor.commit();
        log("set default" + (position.equals(VOICE_POSITION) ? "voice" : "sms") + "SubId[" + subId + "] to Preference");
    }

    private int getDefaultXSubIdfromPreference(String pref, String position) {
        SharedPreferences sp = this.mContext.getSharedPreferences(pref, 0);
        int defaultXSubId = sp.getInt(position, -1);
        return defaultXSubId;
    }

    protected void updateDefaults() {
        int restrictPhoneId;
        log("updateDefaults");
        if (isReadyToReevaluate()) {
            List<SubscriptionInfo> activeSubInfos = this.mSubController.getActiveSubscriptionInfoList(this.mContext.getOpPackageName(), this.mContext.getAttributionTag());
            if (!ArrayUtils.isEmpty(activeSubInfos)) {
                this.mIsPrefSetbefore = false;
            }
            if (ArrayUtils.isEmpty(activeSubInfos)) {
                this.mPrimarySubList.clear();
                if (!this.mIsPrefSetbefore) {
                    int oldValuesforDefaultVoice = SubscriptionManager.getDefaultVoiceSubscriptionId();
                    setDefaultXSubIdtoPreference(PREFS_DEFSUBID_INFO, VOICE_POSITION, oldValuesforDefaultVoice);
                    int oldValuesforDefaultSms = SubscriptionManager.getDefaultSmsSubscriptionId();
                    setDefaultXSubIdtoPreference(PREFS_DEFSUBID_INFO, SMS_POSITION, oldValuesforDefaultSms);
                    this.mIsPrefSetbefore = DBG;
                }
                this.mSubController.setDefaultVoiceSubId(-1);
                this.mSubController.setDefaultSmsSubId(-1);
                log("[updateDefaultValues] No active sub. Setting default to INVALID sub.");
                return;
            }
            int change = updatePrimarySubListAndGetChangeType(activeSubInfos);
            int activeModemCount = ((TelephonyManager) this.mContext.getSystemService("phone")).getSupportedModemCount();
            log("[updateDefaultValues] change: " + change);
            if (activeModemCount == 1) {
                int subId = this.mPrimarySubList.get(0).intValue();
                log("[updateDefaultValues] to only primary sub " + subId);
                this.mSubController.setDefaultDataSubId(subId);
                this.mSubController.setDefaultVoiceSubId(subId);
                this.mSubController.setDefaultSmsSubId(subId);
                return;
            }
            List<UiccCard> uiccCards = new ArrayList<>();
            if (this.mUiccController != null) {
                for (int i = 0; i < activeModemCount; i++) {
                    UiccCard card = this.mUiccController.getUiccCard(i);
                    if (card != null) {
                        uiccCards.add(card);
                    }
                }
            }
            this.mUiccCards = uiccCards;
            if (uiccCards.size() < activeSubInfos.size()) {
                log("[updateDefaultValues] there are cards not ready to set default cards, so return.");
                return;
            }
            if (this.mIsIccChanged) {
                autoSetDefaultVoiceSubId();
                autoSetDefaultSmsSubId();
            }
            if (change == 0) {
                this.mIsIccChanged = false;
                return;
            }
            int primarySubId = this.mSubController.getSubIdUsingPhoneId(this.mPrimarySubManager.getPreferredPrimaryCard());
            log("[updateDefaultValues] primarySubId =" + primarySubId);
            if (this.mPrimarySubManager.isRestrictPreference(1) && (restrictPhoneId = this.mPrimarySubManager.getRestrictPreferencePhoneId(1)) > -1) {
                log("[onSetPrimaryCardPrepared] DM need restrict data subId");
                primarySubId = this.mSubController.getSubIdUsingPhoneId(restrictPhoneId);
            }
            updateDefaultValue(this.mPrimarySubList, change, primarySubId, new UpdateDefaultAction() { // from class: com.android.internal.telephony.UniMultiSimSettingController$$ExternalSyntheticLambda2
                @Override // com.android.internal.telephony.UniMultiSimSettingController.UpdateDefaultAction
                public final void update(int i2) {
                    this.f$0.m40xda1fa379(i2);
                }
            });
            Resources res = Resources.getSystem();
            if (res.getBoolean(134414377)) {
                setRestrictedNetworkType();
            }
            if (isDeviceProvisioned()) {
                sendSubChangeNotificationIfNeeded(change);
            } else if (change == 7) {
                log("Device is not provisioned, pop up data dialog later.");
                this.mNeedPopUpSimSettings = DBG;
            }
        }
    }

    /* JADX INFO: renamed from: lambda$updateDefaults$0$com-android-internal-telephony-UniMultiSimSettingController, reason: not valid java name */
    /* synthetic */ void m40xda1fa379(int newValue) {
        this.mSubController.setDefaultDataSubId(newValue);
    }

    private boolean isActiveSubIdforSetDefaultXSubId(int subId) {
        if (this.mSubscriptionManager.isActiveSubscriptionId(subId) && !isSimStateLocked(subId)) {
            return DBG;
        }
        return false;
    }

    private int getSimStateforSubId(int subId) {
        if (!SubscriptionManager.isValidSubscriptionId(subId)) {
            return 0;
        }
        int slotId = SubscriptionManager.getSlotIndex(subId);
        if (SubscriptionManager.isValidSlotIndex(slotId)) {
            return this.mSimStateTracker.getSimState(slotId);
        }
        return 0;
    }

    private boolean isSimStateLocked(int subId) {
        int simState = getSimStateforSubId(subId);
        if (simState == 2 || simState == 3) {
            return DBG;
        }
        return false;
    }

    private boolean isAnySimStateLocked() {
        int[] subIds = this.mSubscriptionManager.getActiveSubscriptionIdList();
        if (subIds == null || subIds.length <= 0) {
            return false;
        }
        for (int i : subIds) {
            if (isSimStateLocked(i)) {
                return DBG;
            }
        }
        return false;
    }

    private void autoSetDefaultVoiceSubId() {
        List<SubscriptionInfo> activeSubInfoList = getActiveSubInfoList();
        List<SubscriptionInfo> subInfoList = this.mSubController.getActiveSubscriptionInfoList(this.mContext.getBasePackageName());
        if (this.mPrimarySubManager.isRestrictPreference(2)) {
            int targetVoicePhoneId = this.mPrimarySubManager.getRestrictPreferencePhoneId(2);
            log("DM restric targetVoicePhoneId : " + targetVoicePhoneId);
            if (targetVoicePhoneId > -1) {
                int restrictDefaultVoiceSubId = this.mSubController.getSubIdUsingPhoneId(targetVoicePhoneId);
                this.mSubController.setDefaultVoiceSubId(restrictDefaultVoiceSubId);
            }
        }
        int defaultVoiceSubId = SubscriptionManager.getDefaultVoiceSubscriptionId();
        int preDefaultVoiceSubId = getDefaultXSubIdfromPreference(PREFS_DEFSUBID_INFO, VOICE_POSITION);
        log("[autoSetDefaultVoiceSubId] preDefaultVoiceSubId = " + preDefaultVoiceSubId);
        if (isActiveSubIdforSetDefaultXSubId(defaultVoiceSubId)) {
            return;
        }
        if (this.mSubscriptionManager.isActiveSubscriptionId(preDefaultVoiceSubId)) {
            log("[autoSetDefaultVoiceSubId] set preDefaultVoiceSubId for voice");
            this.mSubController.setDefaultVoiceSubId(preDefaultVoiceSubId);
            return;
        }
        log("autoSetDefaultVoiceSubId defaultVoiceSubId = " + defaultVoiceSubId);
        if (subInfoList != null && subInfoList.size() > 0) {
            int targetDefaultVoiceSubId = activeSubInfoList.size() > 0 ? activeSubInfoList.get(0).getSubscriptionId() : subInfoList.get(0).getSubscriptionId();
            this.mSubController.setDefaultVoiceSubId(targetDefaultVoiceSubId);
            if (activeSubInfoList.size() > 1) {
                log("set Invalid subId for voice");
                this.mSubController.setDefaultVoiceSubId(-1);
            } else if (isAnySimStateLocked()) {
                log("[autoSetDefaultVoiceSubId] reset defaultVoiceSubId because of locked state");
                this.mSubController.setDefaultVoiceSubId(defaultVoiceSubId);
            }
            log("[autoSetDefaultPhones]: targetDefaultVoiceSubId= " + targetDefaultVoiceSubId);
        }
    }

    private void autoSetDefaultSmsSubId() {
        List<SubscriptionInfo> activeSubInfoList = getActiveSubInfoList();
        List<SubscriptionInfo> subInfoList = this.mSubController.getActiveSubscriptionInfoList(this.mContext.getBasePackageName());
        int defaultSmsSubId = SubscriptionManager.getDefaultSmsSubscriptionId();
        if (this.mPrimarySubManager.isRestrictPreference(3)) {
            int targetSmsPhoneId = this.mPrimarySubManager.getRestrictPreferencePhoneId(3);
            log("DM restric targetSmsPhoneId : " + targetSmsPhoneId);
            if (targetSmsPhoneId > -1) {
                defaultSmsSubId = this.mSubController.getSubIdUsingPhoneId(targetSmsPhoneId);
                this.mSubController.setDefaultSmsSubId(defaultSmsSubId);
            }
        }
        int preDefaultSmsSubId = getDefaultXSubIdfromPreference(PREFS_DEFSUBID_INFO, SMS_POSITION);
        log("[autoSetDefaultVoiceSubId] preDefaultSmsSubId = " + preDefaultSmsSubId);
        if (isActiveSubIdforSetDefaultXSubId(defaultSmsSubId)) {
            return;
        }
        if (this.mSubscriptionManager.isActiveSubscriptionId(preDefaultSmsSubId)) {
            log("[autoSetDefaultSmsSubId] set preDefaultSmsSubId for sms");
            this.mSubController.setDefaultSmsSubId(preDefaultSmsSubId);
            return;
        }
        if (subInfoList != null && subInfoList.size() > 0) {
            if (defaultSmsSubId == -1 && activeSubInfoList.size() > 1) {
                return;
            }
            int targetDefaultSmsSubId = activeSubInfoList.size() > 0 ? activeSubInfoList.get(0).getSubscriptionId() : subInfoList.get(0).getSubscriptionId();
            if (activeSubInfoList.size() > 1) {
                log("set Invalid subId for Sms");
                this.mSubController.setDefaultSmsSubId(-1);
            } else if (!isAnySimStateLocked()) {
                this.mSubController.setDefaultSmsSubId(targetDefaultSmsSubId);
            }
            log("[autoSetDefaultPhones]: targetDefaultSmsSubId= " + targetDefaultSmsSubId);
        }
    }

    private boolean updateDefaultValue(List<Integer> primarySubList, int changeType, int newValue, UpdateDefaultAction action) {
        int oldValue = this.mSubController.getDefaultDataSubId();
        boolean forceAutoSetPrimarySub = Resources.getSystem().getBoolean(134414370);
        if (Resources.getSystem().getBoolean(134414357)) {
            forceAutoSetPrimarySub = DBG;
        }
        if (newValue == -1) {
            return false;
        }
        if (this.mSubController.isActiveSubId(oldValue, this.mContext.getBasePackageName(), this.mContext.getAttributionTag()) && !isDeviceProvisioned() && !forceAutoSetPrimarySub && changeType == 7) {
            log("in SetupWizard mode,default data sub is valid,not set again");
            return DBG;
        }
        int currentDefaultDataSubId = this.mSubController.getDefaultDataSubId();
        int currentSysDefaultDataSubId = SystemProperties.getInt("persist.radio.data.subid", this.mSubController.getDefaultDataSubId());
        log("[updateDefaultValues] currentDefaultDataSubId = " + currentDefaultDataSubId + "currentSysDefaultDataSubId = " + currentSysDefaultDataSubId);
        if (currentDefaultDataSubId != currentSysDefaultDataSubId) {
            log("currentDefaultDataSubId is not equal to currentSysDefaultDataSubId, reset the data card");
            action.update(currentSysDefaultDataSubId);
            return SubscriptionManager.isValidSubscriptionId(currentSysDefaultDataSubId);
        }
        if (changeType != 6 && this.mIsIccChanged && this.mSubscriptionManager.isActiveSubscriptionId(currentDefaultDataSubId) && !forceSetPrimarySubForSubsidy(SubscriptionManager.getPhoneId(currentDefaultDataSubId))) {
            log("no need to set defaultdatasubid");
        } else if ((oldValue != newValue && forceAutoSetPrimarySub && changeType == 8) || !this.mSubController.isActiveSubId(oldValue, this.mContext.getBasePackageName(), this.mContext.getAttributionTag()) || changeType == 7) {
            log("[updateDefaultValue: subId] from " + oldValue + " to " + newValue);
            action.update(newValue);
        }
        int currentValue = this.mSubController.getDefaultDataSubId();
        int defaultDataPhoneId = SubscriptionManager.getPhoneId(currentValue);
        ProxyController proxyController = ProxyController.getInstance();
        if (proxyController != null && SubscriptionManager.isValidPhoneId(defaultDataPhoneId) && SubscriptionManager.isValidSubscriptionId(currentValue)) {
            int raf = proxyController.getRadioAccessFamily(defaultDataPhoneId);
            int maxRaf = proxyController.getMaxRafSupported();
            if (raf != maxRaf) {
                log("reset default data to " + currentValue);
                action.update(currentValue);
            }
        }
        return SubscriptionManager.isValidSubscriptionId(currentValue);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendSubChangeNotificationIfNeeded(int change) {
        if (change == 7) {
            log("[sendSubChangeNotificationIfNeeded] PRIMARY_SUB_SELECTED_BY_USER");
            Intent intent = new Intent();
            intent.setAction("android.telephony.action.PRIMARY_SUBSCRIPTION_LIST_CHANGED");
            intent.setClassName("com.android.settings", "com.android.settings.sim.SimSelectNotification");
            intent.addFlags(268435456);
            intent.putExtra("android.telephony.extra.DEFAULT_SUBSCRIPTION_SELECT_TYPE", 1);
            this.mContext.sendBroadcast(intent);
        }
    }

    private int updatePrimarySubListAndGetChangeType(List<SubscriptionInfo> activeSubList) {
        List<Integer> prevPrimarySubList = this.mPrimarySubList;
        this.mPrimarySubList = (List) activeSubList.stream().filter(new Predicate() { // from class: com.android.internal.telephony.UniMultiSimSettingController$$ExternalSyntheticLambda0
            @Override // java.util.function.Predicate
            public final boolean test(Object obj) {
                return UniMultiSimSettingController.lambda$updatePrimarySubListAndGetChangeType$1((SubscriptionInfo) obj);
            }
        }).map(new Function() { // from class: com.android.internal.telephony.UniMultiSimSettingController$$ExternalSyntheticLambda1
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return Integer.valueOf(((SubscriptionInfo) obj).getSubscriptionId());
            }
        }).collect(Collectors.toList());
        if (this.mInit) {
            this.mInit = false;
            if (this.mIsIccChanged) {
                return this.mPrimarySubManager.isNeedPopupPrimaryCardSettingPrompt() ? 7 : 8;
            }
            return 6;
        }
        int defaultDataPhoneId = SubscriptionManager.getPhoneId(this.mSubController.getDefaultDataSubId());
        log("[updatePrimarySubListAndGetChangeType] defaultDataPhoneId = " + defaultDataPhoneId);
        if (this.mPrimarySubList.size() != prevPrimarySubList.size() || !SubscriptionManager.isValidPhoneId(defaultDataPhoneId)) {
            return 8;
        }
        if (!forceSetPrimarySubForSubsidy(defaultDataPhoneId)) {
            return 0;
        }
        log("[updatePrimarySubListAndGetChangeType] ignore the selected data sub for subsidylock");
        return 8;
    }

    static /* synthetic */ boolean lambda$updatePrimarySubListAndGetChangeType$1(SubscriptionInfo info) {
        return info.isOpportunistic() ^ DBG;
    }

    private boolean forceSetPrimarySubForSubsidy(int defaultDataPhoneId) {
        RadioInteractor radioInteractor;
        if (!Resources.getSystem().getBoolean(134414357) || (radioInteractor = this.mRadioInteractor) == null || radioInteractor.getSubsidyLockStatus(0) != 1 || !SubscriptionManager.isValidPhoneId(defaultDataPhoneId) || this.mPrimarySubManager.isOperatorCardForSubsidy(defaultDataPhoneId) || defaultDataPhoneId == this.mPrimarySubManager.getPreferredPrimaryCard()) {
            return false;
        }
        log("force set primary sub according to icc config for subsidylock");
        return DBG;
    }

    private void setRestrictedNetworkType() {
        int phoneCount = ((TelephonyManager) this.mContext.getSystemService("phone")).getSupportedModemCount();
        for (int i = 0; i < phoneCount; i++) {
            int restrictedPhoneId = getRestrictedPhoneId(i);
            int restrictedSubId = this.mSubController.getSubIdUsingPhoneId(restrictedPhoneId);
            if (SubscriptionManager.isValidSubscriptionId(restrictedSubId)) {
                final long restrictedNetworkType = this.mPrimarySubManager.getRestrictedNetworkTypeBitMask(restrictedPhoneId);
                log("restrictedNetworkType = " + restrictedNetworkType);
                if (restrictedNetworkType >= 0) {
                    final TelephonyManager tm = new TelephonyManager(this.mContext, restrictedSubId);
                    long allowedNetworkType = tm.getAllowedNetworkTypes();
                    log("[setRestrictedNetworkType]  allowedNetworkTypes = " + allowedNetworkType + ",restrictedNetworkType=" + restrictedNetworkType);
                    if (restrictedNetworkType != allowedNetworkType) {
                        new Thread(new Runnable() { // from class: com.android.internal.telephony.UniMultiSimSettingController$$ExternalSyntheticLambda4
                            @Override // java.lang.Runnable
                            public final void run() {
                                tm.setAllowedNetworkTypes(restrictedNetworkType);
                            }
                        }).start();
                    }
                } else {
                    int subId = this.mSubController.getSubIdUsingPhoneId(i);
                    log("subId = " + subId);
                    if (SubscriptionManager.isValidSubscriptionId(subId)) {
                        setMaxRafAllowedNetworkTypes(this.mContext, subId);
                    }
                }
            }
            if (restrictedPhoneId != i) {
                log(" no restrict card");
                int subscriptionId = this.mSubController.getSubIdUsingPhoneId(i);
                if (SubscriptionManager.isValidSubscriptionId(subscriptionId)) {
                    long restrictedNetworkType2 = this.mPrimarySubManager.getRestrictedNetworkTypeBitMask(i);
                    log("restrictedNetworkType = " + restrictedNetworkType2);
                    if (restrictedNetworkType2 < 0) {
                        setMaxRafAllowedNetworkTypes(this.mContext, subscriptionId);
                    }
                }
            }
        }
    }

    private void resetNetworkTypesIfNeeded(boolean resetForSimLock, int phoneId) {
        if (resetForSimLock) {
            log("reset network type");
            int subscriptionId = this.mSubController.getSubIdUsingPhoneId(phoneId);
            if (SubscriptionManager.isValidSubscriptionId(subscriptionId)) {
                long restrictedNetworkType = this.mPrimarySubManager.getRestrictedNetworkTypeBitMask(phoneId);
                log("restrictedNetworkType = " + restrictedNetworkType);
                if (restrictedNetworkType < 0 || (restrictedNetworkType > 0 && resetForSimLock)) {
                    setMaxRafAllowedNetworkTypes(this.mContext, subscriptionId);
                }
            }
        }
    }

    private void setRestrictedNetworkTypeForSimLock() {
        PrimarySubManager primarySubManager;
        TelephonyManager teleMgr = (TelephonyManager) this.mContext.getSystemService("phone");
        int phoneCount = teleMgr.getSupportedModemCount();
        boolean mtnSimLockConfig = this.mContext.getResources().getBoolean(134414381) && !this.mPrimarySubManager.supportSimLockV4();
        boolean setRestrictedForMtn = teleMgr.hasIccCard(0) && teleMgr.hasIccCard(1) && this.mPrimarySubManager.isWhiteListCard(0) && !this.mPrimarySubManager.isWhiteListCard(1);
        boolean orangeSimLockConfig = this.mContext.getResources().getBoolean(134414382);
        int restrictedNetPhoneIdForOra = -1;
        if (orangeSimLockConfig && (primarySubManager = this.mPrimarySubManager) != null) {
            restrictedNetPhoneIdForOra = primarySubManager.getRestrictedNetTypePhoneId();
        }
        log("setRestrictedNetworkTypeForSimLock: M* sim lock config = " + mtnSimLockConfig + ", restricted network type? " + setRestrictedForMtn + "; O* simlock config = " + orangeSimLockConfig + ", restricted network mode phoneId = " + restrictedNetPhoneIdForOra);
        for (int i = 0; i < phoneCount; i++) {
            int subId = this.mSubController.getSubIdUsingPhoneId(i);
            if (SubscriptionManager.isValidSubscriptionId(subId)) {
                final long restrictedNetworkType = this.mPrimarySubManager.getRestrictedNetworkTypeBitMask(i);
                log("restrictedNetworkType = " + restrictedNetworkType);
                if (restrictedNetworkType >= 0 && ((mtnSimLockConfig && setRestrictedForMtn) || orangeSimLockConfig)) {
                    final TelephonyManager tm = new TelephonyManager(this.mContext, subId);
                    long allowedNetworkType = tm.getAllowedNetworkTypes();
                    log("[setRestrictedNetworkTypeForSimLock]  allowedNetworkTypes = " + allowedNetworkType + ",restrictedNetworkType=" + restrictedNetworkType);
                    if (restrictedNetworkType != allowedNetworkType) {
                        new Thread(new Runnable() { // from class: com.android.internal.telephony.UniMultiSimSettingController$$ExternalSyntheticLambda3
                            @Override // java.lang.Runnable
                            public final void run() {
                                tm.setAllowedNetworkTypes(restrictedNetworkType);
                            }
                        }).start();
                    }
                }
            }
            boolean resetForSimLock = ((!mtnSimLockConfig || setRestrictedForMtn) && (!orangeSimLockConfig || SubscriptionManager.isValidPhoneId(restrictedNetPhoneIdForOra))) ? false : DBG;
            resetNetworkTypesIfNeeded(resetForSimLock, i);
        }
    }

    private void setMaxRafAllowedNetworkTypes(Context mContext, int subId) {
        ProxyController proxyController;
        final TelephonyManager teleManager = new TelephonyManager(mContext, subId);
        long allowedNetworkTypes = teleManager.getAllowedNetworkTypes();
        log("allowedNetworkTypes = " + allowedNetworkTypes);
        if (allowedNetworkTypes < 0 || (proxyController = ProxyController.getInstance()) == null) {
            return;
        }
        final int maxRaf = proxyController.getMaxRafSupported();
        log("[setRestrictedNetworkType] reset allowedRaf = " + allowedNetworkTypes + ",maxRaf = " + maxRaf);
        if (allowedNetworkTypes < maxRaf) {
            new Thread(new Runnable() { // from class: com.android.internal.telephony.UniMultiSimSettingController$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    teleManager.setAllowedNetworkTypes(maxRaf);
                }
            }).start();
        }
    }

    private int getRestrictedPhoneId(int phoneId) {
        int restrictedPhoneId = Resources.getSystem().getInteger(134807567);
        log("restrictedPhoneId =" + restrictedPhoneId + ",phoneId=" + phoneId);
        return SubscriptionManager.isValidPhoneId(restrictedPhoneId) ? restrictedPhoneId : phoneId;
    }

    private boolean isReadyToReevaluate() {
        if (this.mSubInfoInitialized && isCarrierConfigLoadedForAllSub()) {
            return DBG;
        }
        return false;
    }

    public boolean isCarrierConfigLoadedForAllSub() {
        int[] activeSubIds = this.mSubController.getActiveSubIdList(false);
        for (int activeSubId : activeSubIds) {
            boolean isLoaded = false;
            for (int configLoadedSub : this.mCarrierConfigLoadedSubIds) {
                if (configLoadedSub == activeSubId) {
                    isLoaded = DBG;
                    break;
                }
            }
            if (!isLoaded) {
                log("Carrier config subId " + activeSubId + " is not loaded.");
                return false;
            }
        }
        return DBG;
    }

    protected void disableDataForNonDefaultNonOpportunisticSubscriptions() {
        if (this.mSubInfoInitialized) {
            int defaultDataSub = SystemProperties.getInt("persist.radio.data.subid", this.mSubController.getDefaultDataSubId());
            for (Phone phone : PhoneFactory.getPhones()) {
                if (phone.getSubId() != defaultDataSub && SubscriptionManager.isValidSubscriptionId(phone.getSubId()) && SubscriptionManager.isValidSubscriptionId(defaultDataSub) && !this.mSubController.isOpportunistic(phone.getSubId()) && phone.isUserDataEnabled() && !areSubscriptionsInSameGroup(defaultDataSub, phone.getSubId())) {
                    log("setting data to false on " + phone.getSubId());
                    if (phone != null) {
                        if (phone.isUsingNewDataStack()) {
                            phone.getDataSettingsManager().setDataEnabled(0, false, this.mContext.getOpPackageName());
                        } else {
                            phone.getDataEnabledSettings().setUserDataEnabled(false, DBG);
                        }
                        SystemProperties.set(DATA_ENABLED_STATE_PROP, "false");
                    }
                }
            }
        }
    }

    private void deactivateGroupedOpportunisticSubscriptionIfNeeded() {
        if (SubscriptionInfoUpdater.isSubInfoInitialized()) {
            List<SubscriptionInfo> opptSubList = this.mSubController.getOpportunisticSubscriptions(this.mContext.getOpPackageName(), this.mContext.getAttributionTag());
            if (ArrayUtils.isEmpty(opptSubList)) {
                return;
            }
            for (SubscriptionInfo info : opptSubList) {
                if (info.isGroupDisabled() && this.mSubController.isActiveSubId(info.getSubscriptionId())) {
                    log("[deactivateGroupedOpptSubIfNeeded] Deactivating grouped opportunistic subscription " + info.getSubscriptionId());
                    deactivateSubscription(info);
                }
            }
        }
    }

    private List<SubscriptionInfo> getActiveSubInfoList() {
        List<SubscriptionInfo> availableSubInfoList = this.mSubController.getActiveSubscriptionInfoList(this.mContext.getBasePackageName());
        if (availableSubInfoList == null) {
            return new ArrayList();
        }
        Iterator<SubscriptionInfo> iterator = availableSubInfoList.iterator();
        while (iterator.hasNext()) {
            SubscriptionInfo subInfo = iterator.next();
            int phoneId = subInfo.getSimSlotIndex();
            boolean isSimReady = TelephonyManager.from(this.mContext).getSimState(phoneId) == 5 ? DBG : false;
            boolean isSimEnable = this.mSubController.isSubscriptionEnabled(subInfo.getSubscriptionId());
            if (!isSimReady || !isSimEnable || subInfo.isOpportunistic()) {
                iterator.remove();
            }
        }
        return availableSubInfoList;
    }

    private void deactivateSubscription(SubscriptionInfo info) {
        if (info.isEmbedded()) {
            log("[deactivateSubscription] eSIM profile " + info.getSubscriptionId());
            EuiccManager euiccManager = (EuiccManager) this.mContext.getSystemService("euicc");
            euiccManager.switchToSubscription(-1, info.getPortIndex(), PendingIntent.getService(this.mContext, 0, new Intent(), 0));
        }
    }

    private boolean areSubscriptionsInSameGroup(int subId1, int subId2) {
        if (!SubscriptionManager.isUsableSubscriptionId(subId1) || !SubscriptionManager.isUsableSubscriptionId(subId2)) {
            return false;
        }
        if (subId1 == subId2) {
            return DBG;
        }
        ParcelUuid groupUuid1 = this.mSubController.getGroupUuid(subId1);
        ParcelUuid groupUuid2 = this.mSubController.getGroupUuid(subId2);
        if (groupUuid1 == null || !groupUuid1.equals(groupUuid2)) {
            return false;
        }
        return DBG;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isDeviceProvisioned() {
        if (Settings.Global.getInt(this.mContext.getContentResolver(), "device_provisioned", 0) != 0) {
            return DBG;
        }
        return false;
    }

    public void onSimHotSwaped(int phoneId) {
        log("onSimHotSwaped.");
        this.mIsIccChanged = DBG;
        reEvaluateAll();
    }

    public void onAllSimDetected(boolean isIccChanged) {
        log("onAllSimDetected. isIccChanged = " + isIccChanged);
        this.mIsIccChanged = isIccChanged;
        if (this.mContext.getResources().getBoolean(134414381) && !this.mPrimarySubManager.supportSimLockV4()) {
            updateDefaults();
            setRestrictedNetworkTypeForSimLock();
        } else if (this.mContext.getResources().getBoolean(134414382)) {
            setRestrictedNetworkTypeForSimLock();
        } else if (isIccChanged) {
            reEvaluateAll();
        }
    }

    private void registerDataSettingsControllerCallbackAsNeeded() {
        Phone[] phones = PhoneFactory.getPhones();
        for (int i = this.mCallbacksCount; i < phones.length; i++) {
            if (phones[i] != null && phones[i].isUsingNewDataStack()) {
                phones[i].getDataSettingsManager().registerCallback(new DataSettingsControllerCallback(phones[i], new Executor() { // from class: com.android.internal.telephony.UniMultiSimSettingController$$ExternalSyntheticLambda6
                    @Override // java.util.concurrent.Executor
                    public final void execute(Runnable runnable) {
                        this.f$0.post(runnable);
                    }
                }));
            }
        }
        int i2 = phones.length;
        this.mCallbacksCount = i2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(String msg) {
        Log.d(LOG_TAG, msg);
    }
}
