package com.android.internal.telephony.uicc;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Message;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.UniTeleUtils;
import com.android.telephony.Rlog;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\uni-telephony-common\classes.dex */
public class UniSIMFileHandler extends IccFileHandler implements UniIccConstants {
    protected static final int EVENT_READ_EF_LINEAR_RECORD_DONE = 1001;
    private static final int FILE_HANDLER_EVENT_BASE = 1000;
    protected static final int READ_RECORD_MODE_CYCLIC = 3;
    protected static final byte RESPONSE_DATA_FCP_FLAG = 0;
    protected static final byte RESPONSE_DATA_FILE_DES_FLAG = 2;
    protected static final byte RESPONSE_DATA_FILE_DES_LEN_FLAG = 3;
    protected static final byte RESPONSE_DATA_FILE_RECORD_COUNT_FLAG = 8;
    protected static final byte RESPONSE_DATA_FILE_RECORD_LEN_1 = 6;
    protected static final byte RESPONSE_DATA_FILE_RECORD_LEN_2 = 7;
    protected static final String TAG = "UniSIMFileHandler";
    protected static final byte TYPE_FCP = 98;
    protected static final byte TYPE_FCP_SIZE = -128;
    protected static final byte TYPE_FILE_DES = -126;
    protected static final byte TYPE_FILE_DES_LEN = 5;
    private static final int USIM_DATA_OFFSET_2 = 2;
    private static final int USIM_DATA_OFFSET_3 = 3;
    private Context mContext;
    private final int[] mDualMapFile;
    private Map<Integer, String> mDualMapFileList;
    private ArrayList<Integer> mFileList;

    static class IccIoContext {
        int mCountRecords;
        int mEfid;
        boolean mLoadAll;
        Message mOnLoaded;
        String mPath;
        int mRecordNum;
        int mRecordSize;
        ArrayList<byte[]> results;

        IccIoContext(int efid, String path, Message onLoaded) {
            this.mEfid = efid;
            this.mPath = path;
            this.mOnLoaded = onLoaded;
            this.mRecordNum = 1;
            this.mLoadAll = true;
        }

        IccIoContext(int efid, int recordNum, Message onLoaded) {
            this.mEfid = efid;
            this.mRecordNum = recordNum;
            this.mOnLoaded = onLoaded;
            this.mLoadAll = false;
            this.mPath = null;
        }

        IccIoContext(int efid, int recordNum, String path, Message onLoaded) {
            this.mEfid = efid;
            this.mRecordNum = recordNum;
            this.mPath = path;
            this.mOnLoaded = onLoaded;
            this.mLoadAll = false;
        }

        public String toString() {
            return "IccIoContext:  mEfid" + this.mEfid + " mRecordNum=" + this.mRecordNum + " mOnLoaded=" + this.mOnLoaded + " mPath=" + this.mPath;
        }
    }

    public UniSIMFileHandler(UiccCardApplication app, String aid, CommandsInterface ci, Context c) {
        super(app, aid, ci);
        this.mDualMapFile = new int[]{28476, 20272};
        this.mContext = c;
        initDualMapFileSet();
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.android.internal.telephony.uicc.IccFileTypeMismatch */
    /* JADX WARN: Not initialized variable reg: 18, insn: 0x010f: MOVE (r1 I:??[OBJECT, ARRAY]) = (r18 I:??[OBJECT, ARRAY] A[D('response' android.os.Message)]), block:B:43:0x010f */
    /* JADX WARN: Not initialized variable reg: 24, insn: 0x046f: MOVE (r13 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY] A[D('response' android.os.Message)]) = (r24 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY] A[D('index' int)]), block:B:152:0x046e */
    /* JADX WARN: Not initialized variable reg: 24, insn: 0x05a4: MOVE (r13 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r24 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY] A[D('index' int)]), block:B:210:0x05a4 */
    public void handleMessage(Message msg) throws IccFileTypeMismatch {
        int size;
        int index;
        int index2;
        int index3;
        Message response;
        Message response2;
        int i;
        Message response3;
        Message response4 = null;
        int pathNum = msg.arg2;
        try {
            try {
                try {
                    try {
                        switch (msg.what) {
                            case 4:
                                AsyncResult ar = (AsyncResult) msg.obj;
                                Message response5 = (Message) ar.userObj;
                                try {
                                    IccIoResult result = (IccIoResult) ar.result;
                                    if (ar.exception != null) {
                                        sendResult(response5, null, ar.exception);
                                        int efid = msg.arg1;
                                        String path = getEFPath(efid);
                                        sendErrReport(192, efid, path, 0, 0, 15, null, null, ar.exception.toString());
                                    } else {
                                        Throwable iccException = result.getException();
                                        if (iccException == null) {
                                            byte[] data = result.payload;
                                            logbyte(data);
                                            int fileid = msg.arg1;
                                            if (98 == data[0]) {
                                                Rlog.i(TAG, "EVENT_GET_BINARY_SIZE_DONE fileid " + Integer.toHexString(fileid));
                                                int i2 = 0;
                                                while (true) {
                                                    if (i2 >= data.length) {
                                                        index2 = 0;
                                                    } else if (data[i2] == -126) {
                                                        index2 = i2;
                                                    } else {
                                                        i2++;
                                                    }
                                                }
                                                int i3 = index2 + 2;
                                                try {
                                                    if ((data[i3] & 1) != 1) {
                                                        Rlog.i(TAG, "EVENT_GET_BINARY_SIZE_DONE the efid " + Integer.toHexString(fileid) + " is not transparent file");
                                                        throw new IccFileTypeMismatch();
                                                    }
                                                    int i4 = index2;
                                                    while (true) {
                                                        if (i4 >= data.length) {
                                                            index = index2;
                                                        } else if (data[i4] == -128) {
                                                            index = i4;
                                                        } else {
                                                            int index4 = i4 + 1;
                                                            i4 += data[index4] + RESPONSE_DATA_FILE_DES_FLAG;
                                                        }
                                                    }
                                                    int i5 = index + 2;
                                                    try {
                                                        size = ((data[i5] & 255) << 8) + (data[index + 3] & 255);
                                                    } catch (Exception e) {
                                                        exc = e;
                                                        response4 = response5;
                                                    }
                                                } catch (Exception e2) {
                                                    exc = e2;
                                                    response4 = response5;
                                                }
                                                break;
                                            } else {
                                                if (4 != data[6]) {
                                                    throw new IccFileTypeMismatch();
                                                }
                                                if (data[13] != 0) {
                                                    throw new IccFileTypeMismatch();
                                                }
                                                size = ((data[2] & 255) << 8) + (data[3] & 255);
                                                index = 0;
                                            }
                                            String path2 = getEFPath(fileid);
                                            this.mCi.iccIO(176, fileid, path2, 0, 0, size, (String) null, (String) null, obtainMessage(5, fileid, pathNum, response5));
                                            return;
                                        }
                                        loge("EVENT_GET_BINARY_SIZE_DONE iccException");
                                        sendResult(response5, null, iccException);
                                    }
                                    return;
                                } catch (Exception e3) {
                                    exc = e3;
                                    response4 = response5;
                                }
                                break;
                            case 5:
                                index3 = 0;
                                AsyncResult ar2 = (AsyncResult) msg.obj;
                                response = (Message) ar2.userObj;
                                IccIoResult result2 = (IccIoResult) ar2.result;
                                if (ar2.exception != null) {
                                    sendResult(response, null, ar2.exception);
                                    int efid2 = msg.arg1;
                                    String path3 = getEFPath(efid2);
                                    sendErrReport(176, efid2, path3, 0, 0, msg.arg2, null, null, ar2.exception.toString());
                                } else {
                                    Throwable iccException2 = result2.getException();
                                    if (iccException2 != null) {
                                        sendResult(response, null, iccException2);
                                    } else {
                                        sendResult(response, result2.payload, null);
                                    }
                                }
                                return;
                            case 6:
                            case 11:
                                AsyncResult ar3 = (AsyncResult) msg.obj;
                                IccIoContext iccIoContext = (IccIoContext) ar3.userObj;
                                IccIoResult result3 = (IccIoResult) ar3.result;
                                Message response6 = iccIoContext.mOnLoaded;
                                try {
                                    if (ar3.exception == null) {
                                        try {
                                            byte[] data2 = result3.payload;
                                            int fileid2 = iccIoContext.mEfid;
                                            int i6 = iccIoContext.mRecordNum;
                                            Throwable iccException3 = result3.getException();
                                            if (iccException3 != null) {
                                                loge("EVENT_GET_RECORD_SIZE_DONE iccException");
                                                response2 = response6;
                                                sendResult(response2, null, iccException3);
                                            } else {
                                                response2 = response6;
                                                logd("EVENT_GET_RECORD_SIZE_DONE, fileid:" + fileid2 + "(" + Integer.toHexString(fileid2) + ")");
                                                logbyte(data2);
                                                logd("FCP:" + Integer.toHexString(data2[0]) + " DES:" + Integer.toHexString(data2[2]) + " DES_LEN:" + Integer.toHexString(data2[3]));
                                                if (98 == data2[0]) {
                                                    int i7 = data2[2] & 255;
                                                    if (-126 != data2[2]) {
                                                        loge("TYPE_FILE_DES exception");
                                                        throw new IccFileTypeMismatch();
                                                    }
                                                    if (5 != data2[3]) {
                                                        loge("TYPE_FILE_DES_LEN exception");
                                                        throw new IccFileTypeMismatch();
                                                    }
                                                    iccIoContext.mRecordSize = ((data2[6] & 255) << 8) + (data2[7] & 255);
                                                    iccIoContext.mCountRecords = data2[8] & 255;
                                                } else {
                                                    int fcp_size = data2[6];
                                                    if (4 != fcp_size) {
                                                        loge("GSM: TYPE_EF exception");
                                                        throw new IccFileTypeMismatch();
                                                    }
                                                    if (1 != data2[13] && 3 != data2[13]) {
                                                        loge("GSM: EF_TYPE_LINEAR_FIXED exception");
                                                        throw new IccFileTypeMismatch();
                                                    }
                                                    iccIoContext.mRecordSize = data2[14] & 255;
                                                    int size2 = ((data2[2] & 255) << 8) + (data2[3] & 255);
                                                    iccIoContext.mCountRecords = size2 / iccIoContext.mRecordSize;
                                                }
                                                loge("recordsize:" + iccIoContext.mRecordSize + " counts:" + iccIoContext.mCountRecords);
                                                if (iccIoContext.mLoadAll) {
                                                    iccIoContext.results = new ArrayList<>(iccIoContext.mCountRecords);
                                                }
                                                String path4 = getEFPath(iccIoContext.mEfid);
                                                this.mCi.iccIO(178, iccIoContext.mEfid, path4, iccIoContext.mRecordNum, 4, iccIoContext.mRecordSize, (String) null, (String) null, obtainMessage(7, 0, pathNum, iccIoContext));
                                            }
                                            return;
                                        } catch (Exception e4) {
                                            exc = e4;
                                            response4 = response6;
                                        }
                                    } else {
                                        try {
                                            loge("EVENT_GET_RECORD_SIZE_DONE ar.exception");
                                            sendResult(response6, null, ar3.exception);
                                            try {
                                                sendErrReport(192, iccIoContext.mEfid, iccIoContext.mPath, 0, 0, 15, null, null, ar3.exception.toString());
                                                response2 = response6;
                                                return;
                                            } catch (Exception e5) {
                                                exc = e5;
                                                response4 = response6;
                                            }
                                        } catch (Exception e6) {
                                            exc = e6;
                                            response4 = response6;
                                        }
                                    }
                                } catch (Exception e7) {
                                    exc = e7;
                                    response4 = response6;
                                }
                                break;
                            case 7:
                                AsyncResult ar4 = (AsyncResult) msg.obj;
                                IccIoContext iccIoContext2 = (IccIoContext) ar4.userObj;
                                IccIoResult result4 = (IccIoResult) ar4.result;
                                Message response7 = iccIoContext2.mOnLoaded;
                                if (ar4.exception != null) {
                                    sendResult(response7, null, ar4.exception);
                                } else {
                                    Throwable iccException4 = result4.getException();
                                    if (iccException4 != null) {
                                        sendResult(response7, null, iccException4);
                                    } else if (iccIoContext2.mLoadAll) {
                                        iccIoContext2.results.add(result4.payload);
                                        iccIoContext2.mRecordNum++;
                                        if (iccIoContext2.mRecordNum > iccIoContext2.mCountRecords) {
                                            sendResult(response7, iccIoContext2.results, null);
                                        } else {
                                            String path5 = getEFPath(iccIoContext2.mEfid);
                                            this.mCi.iccIO(178, iccIoContext2.mEfid, path5, iccIoContext2.mRecordNum, 4, iccIoContext2.mRecordSize, (String) null, (String) null, obtainMessage(7, 0, pathNum, iccIoContext2));
                                        }
                                    } else {
                                        sendResult(response7, result4.payload, null);
                                    }
                                }
                                return;
                            case 8:
                                AsyncResult ar5 = (AsyncResult) msg.obj;
                                IccIoContext iccIoContext3 = (IccIoContext) ar5.userObj;
                                IccIoResult result5 = (IccIoResult) ar5.result;
                                Message response8 = iccIoContext3.mOnLoaded;
                                try {
                                    byte[] data3 = result5.payload;
                                    if (ar5.exception != null) {
                                        logd("EVENT_GET_EF_LINEAR_RECORD_SIZE_DONE exception ");
                                        sendResult(response8, null, ar5.exception);
                                        index3 = 0;
                                        response = response8;
                                        sendErrReport(192, iccIoContext3.mEfid, iccIoContext3.mPath, 0, 0, 15, null, null, ar5.exception.toString());
                                    } else {
                                        index3 = 0;
                                        response = response8;
                                        if (data3 != null) {
                                            logbyte(data3);
                                            Throwable iccException5 = result5.getException();
                                            if (iccException5 == null) {
                                                if (4 == data3[6]) {
                                                    if (1 != data3[13]) {
                                                        i = 3;
                                                        if (3 == data3[13]) {
                                                        }
                                                    } else {
                                                        i = 3;
                                                    }
                                                    int[] recordSize = new int[i];
                                                    recordSize[0] = data3[14] & 255;
                                                    recordSize[1] = ((data3[2] & 255) << 8) + (data3[3] & 255);
                                                    recordSize[2] = recordSize[1] / recordSize[0];
                                                    sendResult(response, recordSize, null);
                                                }
                                                throw new IccFileTypeMismatch();
                                            }
                                            sendResult(response, null, iccException5);
                                        } else {
                                            logd("EVENT_GET_EF_LINEAR_RECORD_SIZE_DONE exception result.payload is null");
                                            sendResult(response, null, new NullPointerException());
                                        }
                                    }
                                    return;
                                } catch (Exception e8) {
                                    exc = e8;
                                    response4 = response8;
                                }
                                break;
                            case 9:
                                AsyncResult ar6 = (AsyncResult) msg.obj;
                                IccIoContext iccIoContext4 = (IccIoContext) ar6.userObj;
                                IccIoResult result6 = (IccIoResult) ar6.result;
                                response4 = iccIoContext4.mOnLoaded;
                                try {
                                    if (ar6.exception != null) {
                                        logd("EVENT_READ_IMG_DONE ar fail");
                                        sendResult(response4, null, ar6.exception);
                                    } else {
                                        Throwable iccException6 = result6.getException();
                                        if (iccException6 == null) {
                                            byte[] data4 = result6.payload;
                                            int i8 = iccIoContext4.mEfid;
                                            int i9 = iccIoContext4.mRecordNum;
                                            try {
                                                if (4 != data4[6]) {
                                                    throw new IccFileTypeMismatch();
                                                }
                                                if (1 != data4[13]) {
                                                    throw new IccFileTypeMismatch();
                                                }
                                                iccIoContext4.mRecordSize = data4[14] & 255;
                                                int size3 = ((data4[2] & 255) << 8) + (data4[3] & 255);
                                                iccIoContext4.mCountRecords = size3 / iccIoContext4.mRecordSize;
                                                if (iccIoContext4.mLoadAll) {
                                                    iccIoContext4.results = new ArrayList<>(iccIoContext4.mCountRecords);
                                                }
                                                this.mCi.iccIO(178, iccIoContext4.mEfid, getEFPath(iccIoContext4.mEfid), iccIoContext4.mRecordNum, 4, iccIoContext4.mRecordSize, (String) null, (String) null, obtainMessage(7, iccIoContext4));
                                            } catch (Exception e9) {
                                                exc = e9;
                                                response4 = response3;
                                            }
                                            exc.printStackTrace();
                                            if (response4 == null || response4.getTarget() == null) {
                                                loge("uncaught exception" + exc);
                                                return;
                                            } else {
                                                sendResult(response4, null, exc);
                                                return;
                                            }
                                        }
                                        logd("EVENT_READ_IMG_DONE icc fail");
                                        sendResult(response4, null, iccException6);
                                    }
                                    return;
                                } catch (Exception e10) {
                                    exc = e10;
                                }
                                break;
                            case 10:
                                AsyncResult ar7 = (AsyncResult) msg.obj;
                                Message response9 = (Message) ar7.userObj;
                                IccIoResult result7 = (IccIoResult) ar7.result;
                                if (result7.getException() != null) {
                                    sendResult(response9, result7.payload, ar7.exception);
                                    return;
                                } else {
                                    sendResult(response9, result7.payload, null);
                                    return;
                                }
                            case EVENT_READ_EF_LINEAR_RECORD_DONE /* 1001 */:
                                AsyncResult ar8 = (AsyncResult) msg.obj;
                                IccIoResult result8 = (IccIoResult) ar8.result;
                                Message response10 = (Message) ar8.userObj;
                                if (processException(response10, (AsyncResult) msg.obj)) {
                                    return;
                                }
                                sendResult(response10, result8.payload, null);
                                return;
                            default:
                                super.handleMessage(msg);
                                return;
                        }
                    } catch (Exception e11) {
                        exc = e11;
                        response4 = null;
                    }
                } catch (Exception e12) {
                    exc = e12;
                }
            } catch (Exception e13) {
                exc = e13;
            }
        } catch (Exception e14) {
            exc = e14;
        }
    }

    public boolean loadFileAgain(int fileId, int pathNum, int event, Object obj) {
        return false;
    }

    public void loadEFLinearFixed(int fileid, int recordNum, Message onLoaded) {
        loadEFLinearFixed(fileid, getEFPath(fileid), recordNum, onLoaded);
    }

    public void loadEFLinearFixed(int fileid, String path, int recordNum, Message onLoaded) {
        String efPath = path == null ? getEFPath(fileid) : path;
        Message response = obtainMessage(6, new IccIoContext(fileid, recordNum, efPath, onLoaded));
        this.mCi.iccIOForApp(192, fileid, efPath, 0, 0, 15, (String) null, (String) null, this.mAid, response);
    }

    public void loadEFLinearFixed(int fileid, int recordNum, int recordSize, Message onLoaded) {
        Message response = obtainMessage(EVENT_READ_EF_LINEAR_RECORD_DONE, fileid, recordNum, onLoaded);
        this.mCi.iccIOForApp(178, fileid, getEFPath(fileid), recordNum, 4, recordSize, (String) null, (String) null, this.mAid, response);
    }

    public void loadEFLinearFixedAll(int fileid, Message onLoaded) {
        loadEFLinearFixedAll(fileid, getEFPath(fileid), onLoaded);
    }

    public void loadEFLinearFixedAll(int fileid, String path, Message onLoaded) {
        String efPath = path == null ? getEFPath(fileid) : path;
        Message response = obtainMessage(6, new IccIoContext(fileid, efPath, onLoaded));
        this.mCi.iccIOForApp(192, fileid, efPath, 0, 0, 15, (String) null, (String) null, this.mAid, response);
    }

    public void loadEFImgLinearFixed(int recordNum, Message onLoaded) {
        Message response = obtainMessage(11, new IccIoContext(20256, recordNum, onLoaded));
        this.mCi.iccIOForApp(192, 20256, getEFPath(20256), recordNum, 4, 10, (String) null, (String) null, this.mAid, response);
    }

    public void loadEFTransparent(int fileid, Message onLoaded) {
        Message response = obtainMessage(4, fileid, 0, onLoaded);
        this.mCi.iccIO(192, fileid, getEFPath(fileid), 0, 0, 15, (String) null, (String) null, response);
    }

    public void getEFLinearRecordSize(int fileid, Message onLoaded) {
        getEFLinearRecordSize(fileid, getEFPath(fileid), onLoaded);
    }

    public void getEFLinearRecordSize(int fileid, String path, Message onLoaded) {
        String efPath = path == null ? getEFPath(fileid) : path;
        Message response = obtainMessage(8, new IccIoContext(fileid, efPath, onLoaded));
        this.mCi.iccIOForApp(192, fileid, efPath, 0, 0, 15, (String) null, (String) null, this.mAid, response);
    }

    public void updateEFCYCLICLinearFixed(int fileid, int recordNum, byte[] data, String pin2, Message onComplete) {
        this.mCi.iccIO(220, fileid, getEFPath(fileid), recordNum, 3, data.length, IccUtils.bytesToHexString(data), pin2, onComplete);
    }

    public void sendErrReport(int command, int efid, String path, int p1, int p2, int p3, String data, String pin, String exception) {
        UniTeleUtils.sendErrReport(this.mContext, this.mParentApp.getPhoneId(), command, efid, path, p1, p2, p3, data, pin, this.mAid, exception);
    }

    public void dispose() {
        super.dispose();
        clearDualMapFileSet();
    }

    protected String getEFPath(int efid) {
        switch (efid) {
            case UniIccConstants.EF_DIR /* 12032 */:
                return "3F00";
            case 20272:
                return this.mDualMapFileList.get(20272);
            case 28433:
            case 28435:
            case 28436:
            case 28437:
            case 28438:
            case 28439:
            case 28440:
            case UniIccConstants.EF_PLMN_SEL /* 28464 */:
                return "3F007F20";
            case UniIccConstants.EF_ESNME /* 28472 */:
            case 28486:
            case 28589:
            case UniIccConstants.EF_ECC /* 28599 */:
            case 28613:
            case 28614:
            case 28615:
            case 28616:
            case 28617:
            case 28618:
            case 28619:
            case 28621:
                return "3F007F20";
            case 28475:
            default:
                String path = getCommonIccEFPath(efid);
                if (path == null) {
                    loge("Error: EF Path being returned in null");
                }
                return path;
            case 28476:
                return "3F007F10";
            case 28478:
            case 28479:
                return "3F007F20";
            case 28480:
                return "3F007F10";
        }
    }

    protected void finalize() throws Throwable {
        super.finalize();
        logd("UniSIMFileHandler finalized");
    }

    protected String getEFPathofUsim(int efid) {
        return null;
    }

    protected String getCommonIccEFPath(int efid) {
        switch (efid) {
            case 12037:
            case 12258:
                return "3F00";
            case 20256:
                return "3F007F105F50";
            case 20272:
                return "3F007F105F3A";
            case 28474:
            case 28475:
            case 28480:
            case UniIccConstants.EF_LND /* 28484 */:
            case 28489:
            case 28490:
            case 28491:
            case 28492:
            case 28645:
                return "3F007F10";
            default:
                return null;
        }
    }

    private void initDualMapFileSet() {
        this.mDualMapFileList = new HashMap();
        this.mFileList = new ArrayList<>();
        this.mDualMapFileList.put(Integer.valueOf(this.mDualMapFile[0]), "3F007FFF");
        this.mDualMapFileList.put(Integer.valueOf(this.mDualMapFile[1]), "3F007F105F3A");
    }

    private void clearDualMapFileSet() {
        if (this.mFileList != null) {
            this.mFileList = null;
        }
        Map<Integer, String> map = this.mDualMapFileList;
        if (map != null) {
            map.clear();
            this.mDualMapFileList = null;
        }
    }

    private String getCommonIccEFPathOfUsim(int efid) {
        switch (efid) {
            case 12258:
                return "3F00";
            case 20256:
                return "3F007F105F50";
            case 28474:
            case 28475:
            case 28480:
            case UniIccConstants.EF_LND /* 28484 */:
            case 28489:
            case 28490:
            case 28491:
            case 28492:
                return "3F007F10";
            default:
                return null;
        }
    }

    protected void logbyte(byte[] data) {
        new String();
        for (byte b : data) {
            String test = Integer.toHexString(b & 255);
            if (test.length() == 1) {
                String str = '0' + test;
            }
        }
    }

    protected boolean isDataValid(byte[] data) {
        for (byte b : data) {
            if (b != 255) {
                return true;
            }
        }
        return false;
    }

    protected void logd(String msg) {
        Rlog.d(TAG, msg);
    }

    protected void loge(String msg) {
        Rlog.e(TAG, msg);
    }

    private void sendResult(Message response, Object result, Throwable ex) {
        if (response == null) {
            return;
        }
        AsyncResult.forMessage(response, result, ex);
        response.sendToTarget();
    }

    private boolean processException(Message response, AsyncResult ar) {
        IccIoResult result = (IccIoResult) ar.result;
        if (ar.exception != null) {
            sendResult(response, null, ar.exception);
            return true;
        }
        IccException iccException = result.getException();
        if (iccException == null) {
            return false;
        }
        sendResult(response, null, iccException);
        return true;
    }
}
