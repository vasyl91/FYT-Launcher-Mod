package com.unisoc.smartlink.sdk.entity;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Objects;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\smartlink_sdk\classes.dex */
public class LTEInfo implements Parcelable {
    public static final Parcelable.Creator<LTEInfo> CREATOR = new Parcelable.Creator<LTEInfo>() { // from class: com.unisoc.smartlink.sdk.entity.LTEInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LTEInfo createFromParcel(Parcel in) {
            return new LTEInfo(in);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LTEInfo[] newArray(int size) {
            return new LTEInfo[size];
        }
    };
    private int mRsrp;
    private int mRxSpeed;
    private int mSnr;
    private int mTxSpeed;

    public LTEInfo() {
    }

    public LTEInfo(int txSpeed, int rxSpeed, int snr, int rsrp) {
        this.mTxSpeed = txSpeed;
        this.mRxSpeed = rxSpeed;
        this.mSnr = snr;
        this.mRsrp = rsrp;
    }

    public int getTxSpeed() {
        return this.mTxSpeed;
    }

    public int getRxSpeed() {
        return this.mRxSpeed;
    }

    public int getSnr() {
        return this.mSnr;
    }

    public int getRsrp() {
        return this.mRsrp;
    }

    public void setTxSpeed(int txSpeed) {
        this.mTxSpeed = txSpeed;
    }

    public void setRxSpeed(int rxSpeed) {
        this.mRxSpeed = rxSpeed;
    }

    public void setSnr(int snr) {
        this.mSnr = snr;
    }

    public void setRsrp(int rsrp) {
        this.mRsrp = rsrp;
    }

    private LTEInfo(Parcel in) {
        this.mTxSpeed = in.readInt();
        this.mRxSpeed = in.readInt();
        this.mSnr = in.readInt();
        this.mRsrp = in.readInt();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.mTxSpeed);
        dest.writeInt(this.mRxSpeed);
        dest.writeInt(this.mSnr);
        dest.writeInt(this.mRsrp);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        LTEInfo that = (LTEInfo) obj;
        if (this.mTxSpeed == that.mTxSpeed && this.mRxSpeed == that.mRxSpeed && this.mSnr == that.mSnr && this.mRsrp == that.mRsrp) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return Objects.hash(Integer.valueOf(this.mTxSpeed), Integer.valueOf(this.mRxSpeed), Integer.valueOf(this.mSnr), Integer.valueOf(this.mRsrp));
    }

    public String toString() {
        return "LTEInfo (mTxSpeed=" + this.mTxSpeed + ", mRxSpeed=" + this.mRxSpeed + ", mSnr=" + this.mSnr + ", mRsrp=" + this.mRsrp + ")";
    }
}
