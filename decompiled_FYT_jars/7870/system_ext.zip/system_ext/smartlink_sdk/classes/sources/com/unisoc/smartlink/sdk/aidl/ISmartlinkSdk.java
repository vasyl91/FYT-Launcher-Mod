package com.unisoc.smartlink.sdk.aidl;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.unisoc.smartlink.sdk.entity.LTEInfo;
import com.unisoc.smartlink.sdk.entity.WifiInfo;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\smartlink_sdk\classes.dex */
public interface ISmartlinkSdk extends IInterface {
    public static final String DESCRIPTOR = "com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk";

    void checkPackageUpdate() throws RemoteException;

    void disableIPA() throws RemoteException;

    int disableMPHTTP() throws RemoteException;

    int disableMPTCP() throws RemoteException;

    void disableMultipathPolicy() throws RemoteException;

    int disablePackageMultiPath(String str) throws RemoteException;

    void disableQuic() throws RemoteException;

    void enableIPA() throws RemoteException;

    int enableMPHTTP() throws RemoteException;

    int enableMPTCP() throws RemoteException;

    void enableMultipathPolicy() throws RemoteException;

    int enablePackageMultiPath(String str) throws RemoteException;

    void enableQuic() throws RemoteException;

    double getAccumulatedTrafficConsumption() throws RemoteException;

    boolean getMultipathEnabled() throws RemoteException;

    boolean getMultipathSupported() throws RemoteException;

    void getMultipathSwitch() throws RemoteException;

    LTEInfo getMultipathTcpLTEInfo() throws RemoteException;

    WifiInfo getMultipathTcpWIFIInfo() throws RemoteException;

    boolean isIPASupported() throws RemoteException;

    boolean isMPHTTPEnabled() throws RemoteException;

    boolean isMPTCPEnabled() throws RemoteException;

    boolean isQuicSupported() throws RemoteException;

    void updateMultipathAppBandWidth(int i) throws RemoteException;

    void updateMultipathAppReconnectTimes(int i) throws RemoteException;

    void updateMultipathAppRtt(int i) throws RemoteException;

    public static class Default implements ISmartlinkSdk {
        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public void enableQuic() throws RemoteException {
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public void disableQuic() throws RemoteException {
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public boolean isQuicSupported() throws RemoteException {
            return false;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public void disableMultipathPolicy() throws RemoteException {
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public void enableMultipathPolicy() throws RemoteException {
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public boolean getMultipathEnabled() throws RemoteException {
            return false;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public boolean getMultipathSupported() throws RemoteException {
            return false;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public void getMultipathSwitch() throws RemoteException {
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public LTEInfo getMultipathTcpLTEInfo() throws RemoteException {
            return null;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public WifiInfo getMultipathTcpWIFIInfo() throws RemoteException {
            return null;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public void updateMultipathAppBandWidth(int bandwidth) throws RemoteException {
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public void updateMultipathAppReconnectTimes(int times) throws RemoteException {
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public void updateMultipathAppRtt(int rtt) throws RemoteException {
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public void checkPackageUpdate() throws RemoteException {
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public int enablePackageMultiPath(String packageName) throws RemoteException {
            return 0;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public int disablePackageMultiPath(String packageName) throws RemoteException {
            return 0;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public double getAccumulatedTrafficConsumption() throws RemoteException {
            return 0.0d;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public void enableIPA() throws RemoteException {
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public void disableIPA() throws RemoteException {
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public boolean isIPASupported() throws RemoteException {
            return false;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public int enableMPHTTP() throws RemoteException {
            return 0;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public int disableMPHTTP() throws RemoteException {
            return 0;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public boolean isMPHTTPEnabled() throws RemoteException {
            return false;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public int enableMPTCP() throws RemoteException {
            return 0;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public int disableMPTCP() throws RemoteException {
            return 0;
        }

        @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
        public boolean isMPTCPEnabled() throws RemoteException {
            return false;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }
    }

    public static abstract class Stub extends Binder implements ISmartlinkSdk {
        static final int TRANSACTION_checkPackageUpdate = 14;
        static final int TRANSACTION_disableIPA = 19;
        static final int TRANSACTION_disableMPHTTP = 22;
        static final int TRANSACTION_disableMPTCP = 25;
        static final int TRANSACTION_disableMultipathPolicy = 4;
        static final int TRANSACTION_disablePackageMultiPath = 16;
        static final int TRANSACTION_disableQuic = 2;
        static final int TRANSACTION_enableIPA = 18;
        static final int TRANSACTION_enableMPHTTP = 21;
        static final int TRANSACTION_enableMPTCP = 24;
        static final int TRANSACTION_enableMultipathPolicy = 5;
        static final int TRANSACTION_enablePackageMultiPath = 15;
        static final int TRANSACTION_enableQuic = 1;
        static final int TRANSACTION_getAccumulatedTrafficConsumption = 17;
        static final int TRANSACTION_getMultipathEnabled = 6;
        static final int TRANSACTION_getMultipathSupported = 7;
        static final int TRANSACTION_getMultipathSwitch = 8;
        static final int TRANSACTION_getMultipathTcpLTEInfo = 9;
        static final int TRANSACTION_getMultipathTcpWIFIInfo = 10;
        static final int TRANSACTION_isIPASupported = 20;
        static final int TRANSACTION_isMPHTTPEnabled = 23;
        static final int TRANSACTION_isMPTCPEnabled = 26;
        static final int TRANSACTION_isQuicSupported = 3;
        static final int TRANSACTION_updateMultipathAppBandWidth = 11;
        static final int TRANSACTION_updateMultipathAppReconnectTimes = 12;
        static final int TRANSACTION_updateMultipathAppRtt = 13;

        public Stub() {
            attachInterface(this, ISmartlinkSdk.DESCRIPTOR);
        }

        public static ISmartlinkSdk asInterface(IBinder obj) {
            if (obj == null) {
                return null;
            }
            IInterface iin = obj.queryLocalInterface(ISmartlinkSdk.DESCRIPTOR);
            if (iin != null && (iin instanceof ISmartlinkSdk)) {
                return (ISmartlinkSdk) iin;
            }
            return new Proxy(obj);
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            if (code >= TRANSACTION_enableQuic && code <= 16777215) {
                data.enforceInterface(ISmartlinkSdk.DESCRIPTOR);
            }
            switch (code) {
                case 1598968902:
                    reply.writeString(ISmartlinkSdk.DESCRIPTOR);
                    return true;
                default:
                    switch (code) {
                        case TRANSACTION_enableQuic /* 1 */:
                            enableQuic();
                            reply.writeNoException();
                            return true;
                        case TRANSACTION_disableQuic /* 2 */:
                            disableQuic();
                            reply.writeNoException();
                            return true;
                        case TRANSACTION_isQuicSupported /* 3 */:
                            boolean _result = isQuicSupported();
                            reply.writeNoException();
                            reply.writeBoolean(_result);
                            return true;
                        case TRANSACTION_disableMultipathPolicy /* 4 */:
                            disableMultipathPolicy();
                            reply.writeNoException();
                            return true;
                        case TRANSACTION_enableMultipathPolicy /* 5 */:
                            enableMultipathPolicy();
                            reply.writeNoException();
                            return true;
                        case TRANSACTION_getMultipathEnabled /* 6 */:
                            boolean _result2 = getMultipathEnabled();
                            reply.writeNoException();
                            reply.writeBoolean(_result2);
                            return true;
                        case TRANSACTION_getMultipathSupported /* 7 */:
                            boolean _result3 = getMultipathSupported();
                            reply.writeNoException();
                            reply.writeBoolean(_result3);
                            return true;
                        case TRANSACTION_getMultipathSwitch /* 8 */:
                            getMultipathSwitch();
                            reply.writeNoException();
                            return true;
                        case TRANSACTION_getMultipathTcpLTEInfo /* 9 */:
                            LTEInfo _result4 = getMultipathTcpLTEInfo();
                            reply.writeNoException();
                            reply.writeTypedObject(_result4, TRANSACTION_enableQuic);
                            return true;
                        case TRANSACTION_getMultipathTcpWIFIInfo /* 10 */:
                            WifiInfo _result5 = getMultipathTcpWIFIInfo();
                            reply.writeNoException();
                            reply.writeTypedObject(_result5, TRANSACTION_enableQuic);
                            return true;
                        case TRANSACTION_updateMultipathAppBandWidth /* 11 */:
                            int _arg0 = data.readInt();
                            data.enforceNoDataAvail();
                            updateMultipathAppBandWidth(_arg0);
                            reply.writeNoException();
                            return true;
                        case TRANSACTION_updateMultipathAppReconnectTimes /* 12 */:
                            int _arg1 = data.readInt();
                            data.enforceNoDataAvail();
                            updateMultipathAppReconnectTimes(_arg1);
                            reply.writeNoException();
                            return true;
                        case TRANSACTION_updateMultipathAppRtt /* 13 */:
                            int _arg2 = data.readInt();
                            data.enforceNoDataAvail();
                            updateMultipathAppRtt(_arg2);
                            reply.writeNoException();
                            return true;
                        case TRANSACTION_checkPackageUpdate /* 14 */:
                            checkPackageUpdate();
                            reply.writeNoException();
                            return true;
                        case TRANSACTION_enablePackageMultiPath /* 15 */:
                            String _arg3 = data.readString();
                            data.enforceNoDataAvail();
                            int _result6 = enablePackageMultiPath(_arg3);
                            reply.writeNoException();
                            reply.writeInt(_result6);
                            return true;
                        case TRANSACTION_disablePackageMultiPath /* 16 */:
                            String _arg4 = data.readString();
                            data.enforceNoDataAvail();
                            int _result7 = disablePackageMultiPath(_arg4);
                            reply.writeNoException();
                            reply.writeInt(_result7);
                            return true;
                        case TRANSACTION_getAccumulatedTrafficConsumption /* 17 */:
                            double _result8 = getAccumulatedTrafficConsumption();
                            reply.writeNoException();
                            reply.writeDouble(_result8);
                            return true;
                        case TRANSACTION_enableIPA /* 18 */:
                            enableIPA();
                            reply.writeNoException();
                            return true;
                        case TRANSACTION_disableIPA /* 19 */:
                            disableIPA();
                            reply.writeNoException();
                            return true;
                        case TRANSACTION_isIPASupported /* 20 */:
                            boolean _result9 = isIPASupported();
                            reply.writeNoException();
                            reply.writeBoolean(_result9);
                            return true;
                        case TRANSACTION_enableMPHTTP /* 21 */:
                            int _result10 = enableMPHTTP();
                            reply.writeNoException();
                            reply.writeInt(_result10);
                            return true;
                        case TRANSACTION_disableMPHTTP /* 22 */:
                            int _result11 = disableMPHTTP();
                            reply.writeNoException();
                            reply.writeInt(_result11);
                            return true;
                        case TRANSACTION_isMPHTTPEnabled /* 23 */:
                            boolean _result12 = isMPHTTPEnabled();
                            reply.writeNoException();
                            reply.writeBoolean(_result12);
                            return true;
                        case TRANSACTION_enableMPTCP /* 24 */:
                            int _result13 = enableMPTCP();
                            reply.writeNoException();
                            reply.writeInt(_result13);
                            return true;
                        case TRANSACTION_disableMPTCP /* 25 */:
                            int _result14 = disableMPTCP();
                            reply.writeNoException();
                            reply.writeInt(_result14);
                            return true;
                        case TRANSACTION_isMPTCPEnabled /* 26 */:
                            boolean _result15 = isMPTCPEnabled();
                            reply.writeNoException();
                            reply.writeBoolean(_result15);
                            return true;
                        default:
                            return super.onTransact(code, data, reply, flags);
                    }
            }
        }

        private static class Proxy implements ISmartlinkSdk {
            private IBinder mRemote;

            Proxy(IBinder remote) {
                this.mRemote = remote;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return ISmartlinkSdk.DESCRIPTOR;
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public void enableQuic() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_enableQuic, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public void disableQuic() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_disableQuic, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public boolean isQuicSupported() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_isQuicSupported, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public void disableMultipathPolicy() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_disableMultipathPolicy, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public void enableMultipathPolicy() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_enableMultipathPolicy, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public boolean getMultipathEnabled() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_getMultipathEnabled, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public boolean getMultipathSupported() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_getMultipathSupported, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public void getMultipathSwitch() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_getMultipathSwitch, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public LTEInfo getMultipathTcpLTEInfo() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_getMultipathTcpLTEInfo, _data, _reply, 0);
                    _reply.readException();
                    LTEInfo _result = (LTEInfo) _reply.readTypedObject(LTEInfo.CREATOR);
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public WifiInfo getMultipathTcpWIFIInfo() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_getMultipathTcpWIFIInfo, _data, _reply, 0);
                    _reply.readException();
                    WifiInfo _result = (WifiInfo) _reply.readTypedObject(WifiInfo.CREATOR);
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public void updateMultipathAppBandWidth(int bandwidth) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    _data.writeInt(bandwidth);
                    this.mRemote.transact(Stub.TRANSACTION_updateMultipathAppBandWidth, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public void updateMultipathAppReconnectTimes(int times) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    _data.writeInt(times);
                    this.mRemote.transact(Stub.TRANSACTION_updateMultipathAppReconnectTimes, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public void updateMultipathAppRtt(int rtt) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    _data.writeInt(rtt);
                    this.mRemote.transact(Stub.TRANSACTION_updateMultipathAppRtt, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public void checkPackageUpdate() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_checkPackageUpdate, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public int enablePackageMultiPath(String packageName) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    _data.writeString(packageName);
                    this.mRemote.transact(Stub.TRANSACTION_enablePackageMultiPath, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public int disablePackageMultiPath(String packageName) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    _data.writeString(packageName);
                    this.mRemote.transact(Stub.TRANSACTION_disablePackageMultiPath, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public double getAccumulatedTrafficConsumption() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_getAccumulatedTrafficConsumption, _data, _reply, 0);
                    _reply.readException();
                    double _result = _reply.readDouble();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public void enableIPA() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_enableIPA, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public void disableIPA() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_disableIPA, _data, _reply, 0);
                    _reply.readException();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public boolean isIPASupported() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_isIPASupported, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public int enableMPHTTP() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_enableMPHTTP, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public int disableMPHTTP() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_disableMPHTTP, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public boolean isMPHTTPEnabled() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_isMPHTTPEnabled, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public int enableMPTCP() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_enableMPTCP, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public int disableMPTCP() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_disableMPTCP, _data, _reply, 0);
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk
            public boolean isMPTCPEnabled() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(ISmartlinkSdk.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_isMPTCPEnabled, _data, _reply, 0);
                    _reply.readException();
                    boolean _result = _reply.readBoolean();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }
        }
    }
}
