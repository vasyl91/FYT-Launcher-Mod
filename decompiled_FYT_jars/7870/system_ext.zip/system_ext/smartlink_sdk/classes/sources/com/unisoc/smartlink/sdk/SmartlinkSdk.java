package com.unisoc.smartlink.sdk;

import android.content.Context;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.util.Log;
import com.unisoc.smartlink.sdk.aidl.ISmartlinkSdk;
import com.unisoc.smartlink.sdk.entity.LTEInfo;
import com.unisoc.smartlink.sdk.entity.WifiInfo;
import java.util.function.Supplier;

/* JADX INFO: loaded from: C:\payload\7870_jars\system_ext\smartlink_sdk\classes.dex */
public class SmartlinkSdk {
    private static String SMARTLINK_SERVER = "SmartlinkSdkService";
    private static final Supplier<ISmartlinkSdk> SMARTLINK_SUPPLIER = new Supplier() { // from class: com.unisoc.smartlink.sdk.SmartlinkSdk$$ExternalSyntheticLambda0
        @Override // java.util.function.Supplier
        public final Object get() {
            return ISmartlinkSdk.Stub.asInterface(ServiceManager.getService(SmartlinkSdk.SMARTLINK_SERVER));
        }
    };
    private static final String TAG = "SmartlinkSdk";
    private Context mContext;

    public SmartlinkSdk(Context context) {
        this.mContext = context;
    }

    public void enableQuic() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.enableQuic();
            }
        } catch (RemoteException e) {
            Log.e(TAG, "enableQuic exception", e);
        }
    }

    public void disableQuic() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.disableQuic();
            }
        } catch (RemoteException e) {
            Log.e(TAG, "disableQuic exception", e);
        }
    }

    public boolean isQuicSupported() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                return smartlinkSdk.isQuicSupported();
            }
            return false;
        } catch (RemoteException e) {
            Log.e(TAG, "isQuicSupported exception", e);
            return false;
        }
    }

    public void disableMultipathPolicy() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.disableMultipathPolicy();
            }
        } catch (RemoteException e) {
            Log.e(TAG, "disableMultipathPolicy exception", e);
        }
    }

    public void enableMultipathPolicy() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.enableMultipathPolicy();
            }
        } catch (RemoteException e) {
            Log.e(TAG, "enableMultipathPolicy exception", e);
        }
    }

    public boolean getMultipathEnabled() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                return smartlinkSdk.getMultipathEnabled();
            }
            return false;
        } catch (RemoteException e) {
            Log.e(TAG, "getMultipathEnabled exception", e);
            return false;
        }
    }

    public boolean getMultipathSupported() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                return smartlinkSdk.getMultipathSupported();
            }
            return false;
        } catch (RemoteException e) {
            Log.e(TAG, "getMultipathSupported exception", e);
            return false;
        }
    }

    public void getMultipathSwitch() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.getMultipathSwitch();
            }
        } catch (RemoteException e) {
            Log.e(TAG, "getMultipathSwitch exception", e);
        }
    }

    public LTEInfo getMultipathTcpLTEInfo() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                return smartlinkSdk.getMultipathTcpLTEInfo();
            }
            return null;
        } catch (RemoteException e) {
            Log.e(TAG, "getMultipathTcpLTEInfo exception", e);
            return null;
        }
    }

    public WifiInfo getMultipathTcpWIFIInfo() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                return smartlinkSdk.getMultipathTcpWIFIInfo();
            }
            return null;
        } catch (RemoteException e) {
            Log.e(TAG, "getMultipathTcpWIFIInfo exception", e);
            return null;
        }
    }

    public void updateMultipathAppBandWidth(int bandwidth) {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.updateMultipathAppBandWidth(bandwidth);
            }
        } catch (RemoteException e) {
            Log.e(TAG, "updateMultipathAppBandWidth exception", e);
        }
    }

    public void updateMultipathAppReconnectTimes(int times) {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.updateMultipathAppReconnectTimes(times);
            }
        } catch (RemoteException e) {
            Log.e(TAG, "updateMultipathAppReconnectTimes exception", e);
        }
    }

    public void updateMultipathAppRtt(int rtt) {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.updateMultipathAppRtt(rtt);
            }
        } catch (RemoteException e) {
            Log.e(TAG, "updateMultipathAppRtt exception", e);
        }
    }

    public void enableIPA() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.enableIPA();
            }
        } catch (RemoteException e) {
            Log.e(TAG, "enableIPA exception", e);
        }
    }

    public void disableIPA() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.disableIPA();
            }
        } catch (RemoteException e) {
            Log.e(TAG, "disableIPA exception", e);
        }
    }

    public boolean isIPASupported() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                return smartlinkSdk.isIPASupported();
            }
            return false;
        } catch (RemoteException e) {
            Log.e(TAG, "isIPASupported exception", e);
            return false;
        }
    }

    public void enableMPHTTP() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.enableMPHTTP();
            }
        } catch (RemoteException e) {
            Log.e(TAG, "enableMPHTTP exception", e);
        }
    }

    public void disableMPHTTP() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                smartlinkSdk.disableMPHTTP();
            }
        } catch (RemoteException e) {
            Log.e(TAG, "disableMPHTTP exception", e);
        }
    }

    public boolean isMPHTTPEnabled() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk != null) {
                return smartlinkSdk.isMPHTTPEnabled();
            }
            return false;
        } catch (RemoteException e) {
            Log.e(TAG, "isMPHTTPEnabled exception", e);
            return false;
        }
    }

    public void enableMPTCP() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk == null) {
                Log.e(TAG, "smartlinkSdk is null");
            }
            if (smartlinkSdk != null) {
                smartlinkSdk.enableMPTCP();
            }
        } catch (RemoteException e) {
            Log.e(TAG, "enableMPTCP exception", e);
        }
    }

    public void disableMPTCP() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk == null) {
                Log.e(TAG, "smartlinkSdk is null");
            }
            if (smartlinkSdk != null) {
                smartlinkSdk.disableMPTCP();
            }
        } catch (RemoteException e) {
            Log.e(TAG, "disableMPTCP exception", e);
        }
    }

    public boolean isMPTCPEnabled() {
        try {
            ISmartlinkSdk smartlinkSdk = SMARTLINK_SUPPLIER.get();
            if (smartlinkSdk == null) {
                Log.e(TAG, "smartlinkSdk is null");
            }
            if (smartlinkSdk != null) {
                return smartlinkSdk.isMPTCPEnabled();
            }
            return false;
        } catch (RemoteException e) {
            Log.e(TAG, "isMPTCPEnabled exception", e);
            return false;
        }
    }
}
