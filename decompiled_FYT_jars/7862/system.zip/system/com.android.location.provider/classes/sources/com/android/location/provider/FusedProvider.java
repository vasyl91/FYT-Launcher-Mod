package com.android.location.provider;

import android.os.IBinder;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\com.android.location.provider\classes.dex */
@Deprecated
public abstract class FusedProvider {
    public IBinder getBinder() {
        return null;
    }
}
