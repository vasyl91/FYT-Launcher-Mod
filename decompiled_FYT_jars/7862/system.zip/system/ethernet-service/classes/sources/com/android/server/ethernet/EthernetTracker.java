package com.android.server.ethernet;

import android.R;
import android.content.Context;
import android.net.IEthernetServiceListener;
import android.net.InterfaceConfiguration;
import android.net.IpConfiguration;
import android.net.LinkAddress;
import android.net.NetworkCapabilities;
import android.net.StaticIpConfiguration;
import android.os.Handler;
import android.os.IBinder;
import android.os.INetworkManagementService;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.Log;
import com.android.internal.annotations.VisibleForTesting;
import com.android.internal.util.IndentingPrintWriter;
import com.android.server.net.BaseNetworkObserver;
import java.io.FileDescriptor;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ethernet-service\classes.dex */
final class EthernetTracker {
    private static final boolean DBG = true;
    private static final String TAG = EthernetTracker.class.getSimpleName();
    private final EthernetConfigStore mConfigStore;
    private final EthernetNetworkFactory mFactory;
    private final Handler mHandler;
    private final String mIfaceMatch;
    private volatile IpConfiguration mIpConfigForDefaultInterface;
    private final INetworkManagementService mNMService;
    private final ConcurrentHashMap<String, NetworkCapabilities> mNetworkCapabilities = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, IpConfiguration> mIpConfigurations = new ConcurrentHashMap<>();
    private final RemoteCallbackList<IEthernetServiceListener> mListeners = new RemoteCallbackList<>();

    EthernetTracker(Context context, Handler handler) {
        this.mHandler = handler;
        IBinder b = ServiceManager.getService("network_management");
        this.mNMService = INetworkManagementService.Stub.asInterface(b);
        this.mIfaceMatch = context.getResources().getString(R.string.auto_data_switch_content);
        String[] interfaceConfigs = context.getResources().getStringArray(R.array.config_convert_to_emergency_number_map);
        for (String strConfig : interfaceConfigs) {
            parseEthernetConfig(strConfig);
        }
        this.mConfigStore = new EthernetConfigStore();
        NetworkCapabilities nc = createNetworkCapabilities(DBG);
        this.mFactory = new EthernetNetworkFactory(handler, context, nc);
        this.mFactory.register();
    }

    void start() {
        this.mConfigStore.read();
        this.mIpConfigForDefaultInterface = this.mConfigStore.getIpConfigurationForDefaultInterface();
        ArrayMap<String, IpConfiguration> configs = this.mConfigStore.getIpConfigurations();
        for (int i = 0; i < configs.size(); i++) {
            this.mIpConfigurations.put(configs.keyAt(i), configs.valueAt(i));
        }
        try {
            this.mNMService.registerObserver(new InterfaceObserver());
        } catch (RemoteException e) {
            Log.e(TAG, "Could not register InterfaceObserver " + e);
        }
        this.mHandler.post(new Runnable() { // from class: com.android.server.ethernet.-$$Lambda$EthernetTracker$7ZSuSvoSqcExye5DLwv_gyq6gyM
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.trackAvailableInterfaces();
            }
        });
    }

    void updateIpConfiguration(final String iface, final IpConfiguration ipConfiguration) {
        Log.i(TAG, "updateIpConfiguration, iface: " + iface + ", cfg: " + ipConfiguration);
        this.mConfigStore.write(iface, ipConfiguration);
        this.mIpConfigurations.put(iface, ipConfiguration);
        this.mHandler.post(new Runnable() { // from class: com.android.server.ethernet.-$$Lambda$EthernetTracker$WrfGoZ0jmrS_2ZYW4ZE33ZnJcBI
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$updateIpConfiguration$0$EthernetTracker(iface, ipConfiguration);
            }
        });
    }

    public /* synthetic */ void lambda$updateIpConfiguration$0$EthernetTracker(String iface, IpConfiguration ipConfiguration) {
        this.mFactory.updateIpConfiguration(iface, ipConfiguration);
    }

    IpConfiguration getIpConfiguration(String iface) {
        return this.mIpConfigurations.get(iface);
    }

    boolean isTrackingInterface(String iface) {
        return this.mFactory.hasInterface(iface);
    }

    String[] getInterfaces(boolean includeRestricted) {
        return this.mFactory.getAvailableInterfaces(includeRestricted);
    }

    boolean isRestrictedInterface(String iface) {
        NetworkCapabilities nc = this.mNetworkCapabilities.get(iface);
        if (nc == null || nc.hasCapability(13)) {
            return false;
        }
        return DBG;
    }

    void addListener(IEthernetServiceListener listener, boolean canUseRestrictedNetworks) {
        this.mListeners.register(listener, new ListenerInfo(canUseRestrictedNetworks));
    }

    void removeListener(IEthernetServiceListener listener) {
        this.mListeners.unregister(listener);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void removeInterface(String iface) {
        this.mFactory.removeInterface(iface);
    }

    private void addInterface(String iface) {
        InterfaceConfiguration config = null;
        try {
            this.mNMService.setInterfaceUp(iface);
            config = this.mNMService.getInterfaceConfig(iface);
        } catch (RemoteException | IllegalStateException e) {
            Log.e(TAG, "Error upping interface " + iface, e);
        }
        if (config == null) {
            Log.e(TAG, "Null interface config for " + iface + ". Bailing out.");
            return;
        }
        String hwAddress = config.getHardwareAddress();
        NetworkCapabilities nc = this.mNetworkCapabilities.get(iface);
        if (nc == null && (nc = this.mNetworkCapabilities.get(hwAddress)) == null) {
            nc = createDefaultNetworkCapabilities();
        }
        IpConfiguration ipConfiguration = this.mIpConfigurations.get(iface);
        if (ipConfiguration == null) {
            ipConfiguration = createDefaultIpConfiguration();
        }
        Log.d(TAG, "Started tracking interface " + iface);
        this.mFactory.addInterface(iface, hwAddress, nc, ipConfiguration);
        if (config.hasFlag("running")) {
            updateInterfaceState(iface, DBG);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:10:0x0024 A[Catch: RemoteException -> 0x0030, TRY_LEAVE, TryCatch #0 {RemoteException -> 0x0030, blocks: (B:7:0x0017, B:10:0x0024), top: B:16:0x0017 }] */
    public void updateInterfaceState(String iface, boolean up) {
        boolean modified = this.mFactory.updateInterfaceLinkState(iface, up);
        if (modified) {
            boolean restricted = isRestrictedInterface(iface);
            int n = this.mListeners.beginBroadcast();
            for (int i = 0; i < n; i++) {
                if (restricted) {
                    try {
                        ListenerInfo listenerInfo = (ListenerInfo) this.mListeners.getBroadcastCookie(i);
                        if (listenerInfo.canUseRestrictedNetworks) {
                            this.mListeners.getBroadcastItem(i).onAvailabilityChanged(iface, up);
                        }
                    } catch (RemoteException e) {
                    }
                } else {
                    this.mListeners.getBroadcastItem(i).onAvailabilityChanged(iface, up);
                }
            }
            this.mListeners.finishBroadcast();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void maybeTrackInterface(String iface) {
        Log.i(TAG, "maybeTrackInterface " + iface);
        if (!iface.matches(this.mIfaceMatch) || this.mFactory.hasInterface(iface)) {
            return;
        }
        if (this.mIpConfigForDefaultInterface != null) {
            updateIpConfiguration(iface, this.mIpConfigForDefaultInterface);
            this.mIpConfigForDefaultInterface = null;
        }
        addInterface(iface);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void trackAvailableInterfaces() {
        try {
            String[] ifaces = this.mNMService.listInterfaces();
            for (String iface : ifaces) {
                maybeTrackInterface(iface);
            }
        } catch (RemoteException | IllegalStateException e) {
            Log.e(TAG, "Could not get list of interfaces " + e);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    class InterfaceObserver extends BaseNetworkObserver {
        private InterfaceObserver() {
        }

        public void interfaceLinkStateChanged(final String iface, final boolean up) {
            Log.i(EthernetTracker.TAG, "interfaceLinkStateChanged, iface: " + iface + ", up: " + up);
            EthernetTracker.this.mHandler.post(new Runnable() { // from class: com.android.server.ethernet.-$$Lambda$EthernetTracker$InterfaceObserver$RwJV-Ek3mzxwZq-yoQwiconpRi8
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$interfaceLinkStateChanged$0$EthernetTracker$InterfaceObserver(iface, up);
                }
            });
        }

        public /* synthetic */ void lambda$interfaceLinkStateChanged$0$EthernetTracker$InterfaceObserver(String iface, boolean up) {
            EthernetTracker.this.updateInterfaceState(iface, up);
        }

        public void interfaceAdded(final String iface) {
            EthernetTracker.this.mHandler.post(new Runnable() { // from class: com.android.server.ethernet.-$$Lambda$EthernetTracker$InterfaceObserver$d1ixKZZuAxwm1Dz_AX3HmL4JVLA
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$interfaceAdded$1$EthernetTracker$InterfaceObserver(iface);
                }
            });
        }

        public /* synthetic */ void lambda$interfaceAdded$1$EthernetTracker$InterfaceObserver(String iface) {
            EthernetTracker.this.maybeTrackInterface(iface);
        }

        public void interfaceRemoved(final String iface) {
            EthernetTracker.this.mHandler.post(new Runnable() { // from class: com.android.server.ethernet.-$$Lambda$EthernetTracker$InterfaceObserver$N47vO7QrVbS59gsxVAc8Mt2Opco
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$interfaceRemoved$2$EthernetTracker$InterfaceObserver(iface);
                }
            });
        }

        public /* synthetic */ void lambda$interfaceRemoved$2$EthernetTracker$InterfaceObserver(String iface) {
            EthernetTracker.this.removeInterface(iface);
        }
    }

    private static class ListenerInfo {
        boolean canUseRestrictedNetworks;

        ListenerInfo(boolean canUseRestrictedNetworks) {
            this.canUseRestrictedNetworks = false;
            this.canUseRestrictedNetworks = canUseRestrictedNetworks;
        }
    }

    private void parseEthernetConfig(String configString) {
        String[] tokens = configString.split(";", 4);
        String name = tokens[0];
        String capabilities = tokens.length > 1 ? tokens[1] : null;
        String transport = tokens.length > 3 ? tokens[3] : null;
        NetworkCapabilities nc = createNetworkCapabilities(true ^ TextUtils.isEmpty(capabilities), capabilities, transport);
        this.mNetworkCapabilities.put(name, nc);
        if (tokens.length > 2 && !TextUtils.isEmpty(tokens[2])) {
            IpConfiguration ipConfig = parseStaticIpConfiguration(tokens[2]);
            this.mIpConfigurations.put(name, ipConfig);
        }
    }

    private static NetworkCapabilities createDefaultNetworkCapabilities() {
        NetworkCapabilities nc = createNetworkCapabilities(false);
        nc.addCapability(12);
        nc.addCapability(13);
        nc.addCapability(11);
        nc.addCapability(18);
        nc.addCapability(20);
        return nc;
    }

    private static NetworkCapabilities createNetworkCapabilities(boolean clearDefaultCapabilities) {
        return createNetworkCapabilities(clearDefaultCapabilities, null, null);
    }

    @VisibleForTesting
    static NetworkCapabilities createNetworkCapabilities(boolean clearDefaultCapabilities, String commaSeparatedCapabilities, String overrideTransport) {
        NetworkCapabilities nc = new NetworkCapabilities();
        if (clearDefaultCapabilities) {
            nc.clearAll();
        }
        int transport = 3;
        if (!TextUtils.isEmpty(overrideTransport)) {
            try {
                int parsedTransport = Integer.valueOf(overrideTransport).intValue();
                if (parsedTransport == 4 || parsedTransport == 5 || parsedTransport == 6) {
                    Log.e(TAG, "Override transport '" + parsedTransport + "' is not supported. Defaulting to TRANSPORT_ETHERNET");
                } else {
                    transport = parsedTransport;
                }
            } catch (NumberFormatException e) {
                Log.e(TAG, "Override transport type '" + overrideTransport + "' could not be parsed. Defaulting to TRANSPORT_ETHERNET");
            }
        }
        try {
            nc.addTransportType(transport);
        } catch (IllegalArgumentException e2) {
            Log.e(TAG, transport + " is not a valid NetworkCapability.TRANSPORT_* value. Defaulting to TRANSPORT_ETHERNET");
            nc.addTransportType(3);
        }
        nc.setLinkUpstreamBandwidthKbps(100000);
        nc.setLinkDownstreamBandwidthKbps(100000);
        if (!TextUtils.isEmpty(commaSeparatedCapabilities)) {
            for (String strNetworkCapability : commaSeparatedCapabilities.split(",")) {
                if (!TextUtils.isEmpty(strNetworkCapability)) {
                    try {
                        nc.addCapability(Integer.valueOf(strNetworkCapability).intValue());
                    } catch (NumberFormatException e3) {
                        Log.e(TAG, "Capability '" + strNetworkCapability + "' could not be parsed");
                    } catch (IllegalArgumentException e4) {
                        Log.e(TAG, strNetworkCapability + " is not a valid NetworkCapability.NET_CAPABILITY_* value");
                    }
                }
            }
        }
        return nc;
    }

    @VisibleForTesting
    static IpConfiguration parseStaticIpConfiguration(String staticIpConfig) {
        StaticIpConfiguration ipConfig = new StaticIpConfiguration();
        String[] strArrSplit = staticIpConfig.trim().split(" ");
        int length = strArrSplit.length;
        char c = 0;
        int i = 0;
        while (i < length) {
            String keyValueAsString = strArrSplit[i];
            if (!TextUtils.isEmpty(keyValueAsString)) {
                String[] pair = keyValueAsString.split("=");
                if (pair.length != 2) {
                    throw new IllegalArgumentException("Unexpected token: " + keyValueAsString + " in " + staticIpConfig);
                }
                String key = pair[c];
                String value = pair[1];
                byte b = -1;
                int iHashCode = key.hashCode();
                if (iHashCode != -189118908) {
                    if (iHashCode != 3367) {
                        if (iHashCode != 99625) {
                            if (iHashCode == 1837548591 && key.equals("domains")) {
                                b = 1;
                            }
                        } else if (key.equals("dns")) {
                            b = 3;
                        }
                    } else if (key.equals("ip")) {
                        b = 0;
                    }
                } else if (key.equals("gateway")) {
                    b = 2;
                }
                if (b != 0) {
                    if (b == 1) {
                        ipConfig.domains = value;
                    } else if (b == 2) {
                        ipConfig.gateway = InetAddress.parseNumericAddress(value);
                    } else {
                        if (b != 3) {
                            throw new IllegalArgumentException("Unexpected key: " + key + " in " + staticIpConfig);
                        }
                        ArrayList<InetAddress> dnsAddresses = new ArrayList<>();
                        for (String address : value.split(",")) {
                            dnsAddresses.add(InetAddress.parseNumericAddress(address));
                        }
                        ipConfig.dnsServers.addAll(dnsAddresses);
                    }
                } else {
                    ipConfig.ipAddress = new LinkAddress(value);
                }
            }
            i++;
            c = 0;
        }
        return new IpConfiguration(IpConfiguration.IpAssignment.STATIC, IpConfiguration.ProxySettings.NONE, ipConfig, null);
    }

    private static IpConfiguration createDefaultIpConfiguration() {
        return new IpConfiguration(IpConfiguration.IpAssignment.DHCP, IpConfiguration.ProxySettings.NONE, null, null);
    }

    private void postAndWaitForRunnable(Runnable r) {
        this.mHandler.runWithScissors(r, 2000L);
    }

    void dump(final FileDescriptor fd, final IndentingPrintWriter pw, final String[] args) {
        postAndWaitForRunnable(new Runnable() { // from class: com.android.server.ethernet.-$$Lambda$EthernetTracker$rMvwcG7iXM6tWTHAeE-h6PlZCT8
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$dump$1$EthernetTracker(pw, fd, args);
            }
        });
    }

    public /* synthetic */ void lambda$dump$1$EthernetTracker(IndentingPrintWriter pw, FileDescriptor fd, String[] args) {
        pw.println(getClass().getSimpleName());
        pw.println("Ethernet interface name filter: " + this.mIfaceMatch);
        pw.println("Listeners: " + this.mListeners.getRegisteredCallbackCount());
        pw.println("IP Configurations:");
        pw.increaseIndent();
        for (String iface : this.mIpConfigurations.keySet()) {
            pw.println(iface + ": " + this.mIpConfigurations.get(iface));
        }
        pw.decreaseIndent();
        pw.println();
        pw.println("Network Capabilities:");
        pw.increaseIndent();
        for (String iface2 : this.mNetworkCapabilities.keySet()) {
            pw.println(iface2 + ": " + this.mNetworkCapabilities.get(iface2));
        }
        pw.decreaseIndent();
        pw.println();
        this.mFactory.dump(fd, pw, args);
    }
}
