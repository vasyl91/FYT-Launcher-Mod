package com.android.server.ethernet;

import android.net.IpConfiguration;
import android.os.Environment;
import android.util.ArrayMap;
import com.android.server.net.IpConfigStore;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ethernet-service\classes.dex */
public class EthernetConfigStore {
    private static final String ipConfigFile = Environment.getDataDirectory() + "/misc/ethernet/ipconfig.txt";
    private IpConfiguration mIpConfigurationForDefaultInterface;
    private IpConfigStore mStore = new IpConfigStore();
    private final Object mSync = new Object();
    private ArrayMap<String, IpConfiguration> mIpConfigurations = new ArrayMap<>(0);

    public void read() {
        synchronized (this.mSync) {
            ArrayMap<String, IpConfiguration> configs = IpConfigStore.readIpConfigurations(ipConfigFile);
            if (configs.containsKey("0")) {
                this.mIpConfigurationForDefaultInterface = configs.remove("0");
            }
            this.mIpConfigurations = configs;
        }
    }

    public void write(String iface, IpConfiguration config) {
        synchronized (this.mSync) {
            boolean modified = true;
            try {
                if (config == null) {
                    if (this.mIpConfigurations.remove(iface) == null) {
                        modified = false;
                    }
                } else {
                    IpConfiguration oldConfig = this.mIpConfigurations.put(iface, config);
                    modified = true ^ config.equals(oldConfig);
                }
                if (modified) {
                    this.mStore.writeIpConfigurations(ipConfigFile, this.mIpConfigurations);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public ArrayMap<String, IpConfiguration> getIpConfigurations() {
        ArrayMap<String, IpConfiguration> arrayMap;
        synchronized (this.mSync) {
            arrayMap = new ArrayMap<>(this.mIpConfigurations);
        }
        return arrayMap;
    }

    public IpConfiguration getIpConfigurationForDefaultInterface() {
        IpConfiguration ipConfiguration;
        synchronized (this.mSync) {
            ipConfiguration = this.mIpConfigurationForDefaultInterface == null ? null : new IpConfiguration(this.mIpConfigurationForDefaultInterface);
        }
        return ipConfiguration;
    }
}
