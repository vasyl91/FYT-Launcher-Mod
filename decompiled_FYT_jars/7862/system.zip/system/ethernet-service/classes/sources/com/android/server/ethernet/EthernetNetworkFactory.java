package com.android.server.ethernet;

import android.R;
import android.content.Context;
import android.net.IpConfiguration;
import android.net.LinkProperties;
import android.net.NetworkAgent;
import android.net.NetworkCapabilities;
import android.net.NetworkFactory;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.net.StringNetworkSpecifier;
import android.net.ip.IIpClient;
import android.net.ip.IpClientCallbacks;
import android.net.ip.IpClientUtil;
import android.net.shared.LinkPropertiesParcelableUtil;
import android.net.shared.ProvisioningConfiguration;
import android.net.util.InterfaceParams;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.Log;
import android.util.SparseArray;
import com.android.internal.util.IndentingPrintWriter;
import com.android.internal.util.Preconditions;
import java.io.FileDescriptor;
import java.util.Comparator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.Predicate;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ethernet-service\classes.dex */
public class EthernetNetworkFactory extends NetworkFactory {
    static final boolean DBG = true;
    private static final int NETWORK_SCORE = 70;
    private static final String NETWORK_TYPE = "Ethernet";
    private static final String TAG = EthernetNetworkFactory.class.getSimpleName();
    private final Context mContext;
    private final Handler mHandler;
    private final ConcurrentHashMap<String, NetworkInterfaceState> mTrackingInterfaces;

    public static class ConfigurationException extends AndroidRuntimeException {
        public ConfigurationException(String msg) {
            super(msg);
        }
    }

    public EthernetNetworkFactory(Handler handler, Context context, NetworkCapabilities filter) {
        super(handler.getLooper(), context, NETWORK_TYPE, filter);
        this.mTrackingInterfaces = new ConcurrentHashMap<>();
        this.mHandler = handler;
        this.mContext = context;
        setScoreFilter(NETWORK_SCORE);
    }

    public boolean acceptRequest(NetworkRequest request, int score) {
        if (request.type == NetworkRequest.Type.TRACK_DEFAULT) {
            return false;
        }
        Log.d(TAG, "acceptRequest, request: " + request + ", score: " + score);
        if (networkForRequest(request) != null) {
            return DBG;
        }
        return false;
    }

    protected void needNetworkFor(NetworkRequest networkRequest, int score) {
        NetworkInterfaceState network = networkForRequest(networkRequest);
        if (network == null) {
            Log.e(TAG, "needNetworkFor, failed to get a network for " + networkRequest);
            return;
        }
        long j = network.refCount + 1;
        network.refCount = j;
        if (j != 1) {
            return;
        }
        network.start();
    }

    protected void releaseNetworkFor(NetworkRequest networkRequest) {
        NetworkInterfaceState network = networkForRequest(networkRequest);
        if (network == null) {
            Log.e(TAG, "needNetworkFor, failed to get a network for " + networkRequest);
            return;
        }
        long j = network.refCount - 1;
        network.refCount = j;
        if (j == 1) {
            network.stop();
        }
    }

    String[] getAvailableInterfaces(final boolean includeRestricted) {
        return (String[]) this.mTrackingInterfaces.values().stream().filter(new Predicate() { // from class: com.android.server.ethernet.-$$Lambda$EthernetNetworkFactory$b1ndnzBiSX1ihvZw7GtATwTUsto
            @Override // java.util.function.Predicate
            public final boolean test(Object obj) {
                return EthernetNetworkFactory.lambda$getAvailableInterfaces$0(includeRestricted, (EthernetNetworkFactory.NetworkInterfaceState) obj);
            }
        }).sorted(new Comparator() { // from class: com.android.server.ethernet.-$$Lambda$EthernetNetworkFactory$EmftAjIay22czoGb8k_mrRGmnzg
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                return EthernetNetworkFactory.lambda$getAvailableInterfaces$1((EthernetNetworkFactory.NetworkInterfaceState) obj, (EthernetNetworkFactory.NetworkInterfaceState) obj2);
            }
        }).map(new Function() { // from class: com.android.server.ethernet.-$$Lambda$EthernetNetworkFactory$KXwxO15KBNVyyYS-UjD-Flm1vQ0
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return ((EthernetNetworkFactory.NetworkInterfaceState) obj).name;
            }
        }).toArray(new IntFunction() { // from class: com.android.server.ethernet.-$$Lambda$EthernetNetworkFactory$TVQUJVMLGgbguTOK63vgn0fV1JA
            @Override // java.util.function.IntFunction
            public final Object apply(int i) {
                return EthernetNetworkFactory.lambda$getAvailableInterfaces$3(i);
            }
        });
    }

    static /* synthetic */ boolean lambda$getAvailableInterfaces$0(boolean includeRestricted, NetworkInterfaceState iface) {
        if (!iface.isRestricted() || includeRestricted) {
            return DBG;
        }
        return false;
    }

    static /* synthetic */ int lambda$getAvailableInterfaces$1(NetworkInterfaceState iface1, NetworkInterfaceState iface2) {
        int r = Boolean.compare(iface1.isRestricted(), iface2.isRestricted());
        return r == 0 ? iface1.name.compareTo(iface2.name) : r;
    }

    static /* synthetic */ String[] lambda$getAvailableInterfaces$3(int x$0) {
        return new String[x$0];
    }

    void addInterface(String ifaceName, String hwAddress, NetworkCapabilities capabilities, IpConfiguration ipConfiguration) {
        if (this.mTrackingInterfaces.containsKey(ifaceName)) {
            Log.e(TAG, "Interface with name " + ifaceName + " already exists.");
            return;
        }
        Log.d(TAG, "addInterface, iface: " + ifaceName + ", capabilities: " + capabilities);
        NetworkInterfaceState iface = new NetworkInterfaceState(ifaceName, hwAddress, this.mHandler, this.mContext, capabilities);
        iface.setIpConfig(ipConfiguration);
        this.mTrackingInterfaces.put(ifaceName, iface);
        updateCapabilityFilter();
    }

    private void updateCapabilityFilter() {
        NetworkCapabilities capabilitiesFilter = new NetworkCapabilities();
        capabilitiesFilter.clearAll();
        for (NetworkInterfaceState iface : this.mTrackingInterfaces.values()) {
            capabilitiesFilter.combineCapabilities(iface.mCapabilities);
        }
        Log.d(TAG, "updateCapabilityFilter: " + capabilitiesFilter);
        setCapabilityFilter(capabilitiesFilter);
    }

    void removeInterface(String interfaceName) {
        NetworkInterfaceState iface = this.mTrackingInterfaces.remove(interfaceName);
        if (iface != null) {
            iface.stop();
        }
        updateCapabilityFilter();
    }

    boolean updateInterfaceLinkState(String ifaceName, boolean up) {
        if (!this.mTrackingInterfaces.containsKey(ifaceName)) {
            return false;
        }
        Log.d(TAG, "updateInterfaceLinkState, iface: " + ifaceName + ", up: " + up);
        NetworkInterfaceState iface = this.mTrackingInterfaces.get(ifaceName);
        return iface.updateLinkState(up);
    }

    boolean hasInterface(String interfacName) {
        return this.mTrackingInterfaces.containsKey(interfacName);
    }

    void updateIpConfiguration(String iface, IpConfiguration ipConfiguration) {
        NetworkInterfaceState network = this.mTrackingInterfaces.get(iface);
        if (network != null) {
            network.setIpConfig(ipConfiguration);
        }
    }

    private NetworkInterfaceState networkForRequest(NetworkRequest request) {
        String requestedIface = null;
        StringNetworkSpecifier networkSpecifier = request.networkCapabilities.getNetworkSpecifier();
        if (networkSpecifier instanceof StringNetworkSpecifier) {
            requestedIface = networkSpecifier.specifier;
        }
        NetworkInterfaceState network = null;
        if (!TextUtils.isEmpty(requestedIface)) {
            NetworkInterfaceState n = this.mTrackingInterfaces.get(requestedIface);
            if (n != null && n.statisified(request.networkCapabilities)) {
                network = n;
            }
        } else {
            for (NetworkInterfaceState n2 : this.mTrackingInterfaces.values()) {
                if (n2.statisified(request.networkCapabilities)) {
                    network = n2;
                    break;
                }
            }
        }
        Log.i(TAG, "networkForRequest, request: " + request + ", network: " + network);
        return network;
    }

    /* JADX INFO: Access modifiers changed from: private */
    static class NetworkInterfaceState {
        private static String sTcpBufferSizes = null;
        private static final SparseArray<TransportInfo> sTransports = new SparseArray<>();
        private final NetworkCapabilities mCapabilities;
        private final Context mContext;
        private final Handler mHandler;
        private final String mHwAddress;
        private volatile IIpClient mIpClient;
        private IpClientCallbacksImpl mIpClientCallback;
        private IpConfiguration mIpConfig;
        private boolean mLinkUp;
        private NetworkAgent mNetworkAgent;
        private final NetworkInfo mNetworkInfo;
        final String name;
        private LinkProperties mLinkProperties = new LinkProperties();
        long refCount = 0;

        static {
            int i = -1;
            sTransports.put(6, new TransportInfo(i, 30));
            int i2 = 1;
            sTransports.put(5, new TransportInfo(i, i2));
            sTransports.put(3, new TransportInfo(9, EthernetNetworkFactory.NETWORK_SCORE));
            sTransports.put(2, new TransportInfo(7, 69));
            sTransports.put(1, new TransportInfo(i2, 60));
            sTransports.put(0, new TransportInfo(0, 50));
        }

        private static class TransportInfo {
            final int mLegacyType;
            final int mScore;

            private TransportInfo(int legacyType, int score) {
                this.mLegacyType = legacyType;
                this.mScore = score;
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        class IpClientCallbacksImpl extends IpClientCallbacks {
            private final ConditionVariable mIpClientShutdownCv;
            private final ConditionVariable mIpClientStartCv;

            private IpClientCallbacksImpl() {
                this.mIpClientStartCv = new ConditionVariable(false);
                this.mIpClientShutdownCv = new ConditionVariable(false);
            }

            public void onIpClientCreated(IIpClient ipClient) {
                NetworkInterfaceState.this.mIpClient = ipClient;
                this.mIpClientStartCv.open();
            }

            /* JADX INFO: Access modifiers changed from: private */
            public void awaitIpClientStart() {
                this.mIpClientStartCv.block();
            }

            /* JADX INFO: Access modifiers changed from: private */
            public void awaitIpClientShutdown() {
                this.mIpClientShutdownCv.block();
            }

            public /* synthetic */ void lambda$onProvisioningSuccess$0$EthernetNetworkFactory$NetworkInterfaceState$IpClientCallbacksImpl(LinkProperties newLp) {
                NetworkInterfaceState.this.onIpLayerStarted(newLp);
            }

            public void onProvisioningSuccess(final LinkProperties newLp) {
                NetworkInterfaceState.this.mHandler.post(new Runnable() { // from class: com.android.server.ethernet.-$$Lambda$EthernetNetworkFactory$NetworkInterfaceState$IpClientCallbacksImpl$tMv_9FjFsYD4UnoWCCV1V3NZ6z8
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$onProvisioningSuccess$0$EthernetNetworkFactory$NetworkInterfaceState$IpClientCallbacksImpl(newLp);
                    }
                });
            }

            public /* synthetic */ void lambda$onProvisioningFailure$1$EthernetNetworkFactory$NetworkInterfaceState$IpClientCallbacksImpl(LinkProperties newLp) {
                NetworkInterfaceState.this.onIpLayerStopped(newLp);
            }

            public void onProvisioningFailure(final LinkProperties newLp) {
                NetworkInterfaceState.this.mHandler.post(new Runnable() { // from class: com.android.server.ethernet.-$$Lambda$EthernetNetworkFactory$NetworkInterfaceState$IpClientCallbacksImpl$FZif1d4H4R7Ocud9hpc5Sbf6o7k
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$onProvisioningFailure$1$EthernetNetworkFactory$NetworkInterfaceState$IpClientCallbacksImpl(newLp);
                    }
                });
            }

            public /* synthetic */ void lambda$onLinkPropertiesChange$2$EthernetNetworkFactory$NetworkInterfaceState$IpClientCallbacksImpl(LinkProperties newLp) {
                NetworkInterfaceState.this.updateLinkProperties(newLp);
            }

            public void onLinkPropertiesChange(final LinkProperties newLp) {
                NetworkInterfaceState.this.mHandler.post(new Runnable() { // from class: com.android.server.ethernet.-$$Lambda$EthernetNetworkFactory$NetworkInterfaceState$IpClientCallbacksImpl$Ijv9vAtt3O7tCPOHIl8QUewI09g
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.lambda$onLinkPropertiesChange$2$EthernetNetworkFactory$NetworkInterfaceState$IpClientCallbacksImpl(newLp);
                    }
                });
            }

            public void onQuit() {
                NetworkInterfaceState.this.mIpClient = null;
                this.mIpClientShutdownCv.open();
            }
        }

        private static void shutdownIpClient(IIpClient ipClient) {
            try {
                ipClient.shutdown();
            } catch (RemoteException e) {
                Log.e(EthernetNetworkFactory.TAG, "Error stopping IpClient", e);
            }
        }

        NetworkInterfaceState(String ifaceName, String hwAddress, Handler handler, Context context, NetworkCapabilities capabilities) {
            this.name = ifaceName;
            this.mCapabilities = (NetworkCapabilities) Preconditions.checkNotNull(capabilities);
            this.mHandler = handler;
            this.mContext = context;
            int[] transportTypes = this.mCapabilities.getTransportTypes();
            if (transportTypes.length > 0) {
                int legacyType = getLegacyType(transportTypes[0]);
                this.mHwAddress = hwAddress;
                this.mNetworkInfo = new NetworkInfo(legacyType, 0, EthernetNetworkFactory.NETWORK_TYPE, "");
                this.mNetworkInfo.setExtraInfo(this.mHwAddress);
                this.mNetworkInfo.setIsAvailable(EthernetNetworkFactory.DBG);
                return;
            }
            throw new ConfigurationException("Network Capabilities do not have an associated transport type.");
        }

        void setIpConfig(IpConfiguration ipConfig) {
            this.mIpConfig = ipConfig;
        }

        boolean statisified(NetworkCapabilities requestedCapabilities) {
            return requestedCapabilities.satisfiedByNetworkCapabilities(this.mCapabilities);
        }

        boolean isRestricted() {
            return this.mCapabilities.hasCapability(13);
        }

        private static int getLegacyType(int transport) {
            TransportInfo transportInfo = sTransports.get(transport, null);
            if (transportInfo != null) {
                return transportInfo.mLegacyType;
            }
            return -1;
        }

        private int getNetworkScore() {
            if (!this.mLinkUp) {
                return 0;
            }
            int[] transportTypes = this.mCapabilities.getTransportTypes();
            if (transportTypes.length < 1) {
                Log.w(EthernetNetworkFactory.TAG, "Network interface '" + this.mLinkProperties.getInterfaceName() + "' has no transport type associated with it. Score set to zero");
                return 0;
            }
            TransportInfo transportInfo = sTransports.get(transportTypes[0], null);
            if (transportInfo != null) {
                return transportInfo.mScore;
            }
            return 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void start() {
            if (this.mIpClient != null) {
                Log.d(EthernetNetworkFactory.TAG, "IpClient already started");
                return;
            }
            Log.d(EthernetNetworkFactory.TAG, String.format("starting IpClient(%s): mNetworkInfo=%s", this.name, this.mNetworkInfo));
            this.mNetworkInfo.setDetailedState(NetworkInfo.DetailedState.OBTAINING_IPADDR, null, this.mHwAddress);
            this.mIpClientCallback = new IpClientCallbacksImpl();
            IpClientUtil.makeIpClient(this.mContext, this.name, this.mIpClientCallback);
            this.mIpClientCallback.awaitIpClientStart();
            if (sTcpBufferSizes == null) {
                sTcpBufferSizes = this.mContext.getResources().getString(R.string.auto_data_switch_title);
            }
            provisionIpClient(this.mIpClient, this.mIpConfig, sTcpBufferSizes);
        }

        void onIpLayerStarted(LinkProperties linkProperties) {
            if (this.mNetworkAgent != null) {
                Log.e(EthernetNetworkFactory.TAG, "Already have a NetworkAgent - aborting new request");
                stop();
                return;
            }
            this.mLinkProperties = linkProperties;
            this.mNetworkInfo.setDetailedState(NetworkInfo.DetailedState.CONNECTED, null, this.mHwAddress);
            this.mNetworkInfo.setIsAvailable(EthernetNetworkFactory.DBG);
            this.mNetworkAgent = new NetworkAgent(this.mHandler.getLooper(), this.mContext, EthernetNetworkFactory.NETWORK_TYPE, this.mNetworkInfo, this.mCapabilities, this.mLinkProperties, getNetworkScore()) { // from class: com.android.server.ethernet.EthernetNetworkFactory.NetworkInterfaceState.1
                public void unwanted() {
                    if (this != NetworkInterfaceState.this.mNetworkAgent) {
                        if (NetworkInterfaceState.this.mNetworkAgent != null) {
                            Log.d(EthernetNetworkFactory.TAG, "Ignoring unwanted as we have a more modern instance");
                            return;
                        }
                        return;
                    }
                    NetworkInterfaceState.this.stop();
                }
            };
        }

        void onIpLayerStopped(LinkProperties linkProperties) {
            stop();
            if (InterfaceParams.getByName(this.name) != null) {
                start();
            }
        }

        void updateLinkProperties(LinkProperties linkProperties) {
            this.mLinkProperties = linkProperties;
            NetworkAgent networkAgent = this.mNetworkAgent;
            if (networkAgent != null) {
                networkAgent.sendLinkProperties(linkProperties);
            }
        }

        boolean updateLinkState(boolean up) {
            if (this.mLinkUp == up) {
                return false;
            }
            this.mLinkUp = up;
            stop();
            if (up) {
                start();
                return EthernetNetworkFactory.DBG;
            }
            return EthernetNetworkFactory.DBG;
        }

        void stop() {
            if (this.mIpClient != null) {
                shutdownIpClient(this.mIpClient);
                this.mIpClientCallback.awaitIpClientShutdown();
                this.mIpClient = null;
            }
            this.mIpClientCallback = null;
            this.mNetworkInfo.setDetailedState(NetworkInfo.DetailedState.DISCONNECTED, null, this.mHwAddress);
            if (this.mNetworkAgent != null) {
                updateAgent();
                this.mNetworkAgent = null;
            }
            clear();
        }

        private void updateAgent() {
            if (this.mNetworkAgent == null) {
                return;
            }
            Log.i(EthernetNetworkFactory.TAG, "Updating mNetworkAgent with: " + this.mCapabilities + ", " + this.mNetworkInfo + ", " + this.mLinkProperties);
            this.mNetworkAgent.sendNetworkCapabilities(this.mCapabilities);
            this.mNetworkAgent.sendNetworkInfo(this.mNetworkInfo);
            this.mNetworkAgent.sendLinkProperties(this.mLinkProperties);
            this.mNetworkAgent.sendNetworkScore(getNetworkScore());
        }

        private void clear() {
            this.mLinkProperties.clear();
            this.mNetworkInfo.setDetailedState(NetworkInfo.DetailedState.IDLE, null, null);
            this.mNetworkInfo.setIsAvailable(false);
        }

        private static void provisionIpClient(IIpClient ipClient, IpConfiguration config, String tcpBufferSizes) {
            ProvisioningConfiguration provisioningConfiguration;
            if (config.getProxySettings() == IpConfiguration.ProxySettings.STATIC || config.getProxySettings() == IpConfiguration.ProxySettings.PAC) {
                try {
                    ipClient.setHttpProxy(LinkPropertiesParcelableUtil.toStableParcelable(config.getHttpProxy()));
                } catch (RemoteException e) {
                    e.rethrowFromSystemServer();
                }
            }
            if (!TextUtils.isEmpty(tcpBufferSizes)) {
                try {
                    ipClient.setTcpBufferSizes(tcpBufferSizes);
                } catch (RemoteException e2) {
                    e2.rethrowFromSystemServer();
                }
            }
            if (config.getIpAssignment() == IpConfiguration.IpAssignment.STATIC) {
                provisioningConfiguration = new ProvisioningConfiguration.Builder().withStaticConfiguration(config.getStaticIpConfiguration()).build();
            } else {
                provisioningConfiguration = new ProvisioningConfiguration.Builder().withProvisioningTimeoutMs(0).build();
            }
            try {
                ipClient.startProvisioning(provisioningConfiguration.toStableParcelable());
            } catch (RemoteException e3) {
                e3.rethrowFromSystemServer();
            }
        }

        public String toString() {
            return getClass().getSimpleName() + "{ refCount: " + this.refCount + ", iface: " + this.name + ", up: " + this.mLinkUp + ", hwAddress: " + this.mHwAddress + ", networkInfo: " + this.mNetworkInfo + ", networkCapabilities: " + this.mCapabilities + ", networkAgent: " + this.mNetworkAgent + ", score: " + getNetworkScore() + ", ipClient: " + this.mIpClient + ",linkProperties: " + this.mLinkProperties + "}";
        }
    }

    void dump(FileDescriptor fd, IndentingPrintWriter pw, String[] args) {
        super.dump(fd, pw, args);
        pw.println(getClass().getSimpleName());
        pw.println("Tracking interfaces:");
        pw.increaseIndent();
        for (String iface : this.mTrackingInterfaces.keySet()) {
            NetworkInterfaceState ifaceState = this.mTrackingInterfaces.get(iface);
            pw.println(iface + ":" + ifaceState);
            pw.increaseIndent();
            IIpClient ipClient = ifaceState.mIpClient;
            if (ipClient != null) {
                IpClientUtil.dumpIpClient(ipClient, fd, pw, args);
            } else {
                pw.println("IpClient is null");
            }
            pw.decreaseIndent();
        }
        pw.decreaseIndent();
    }
}
