package junit.framework;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\android.test.base\classes.dex */
public interface Protectable {
    void protect() throws Throwable;
}
