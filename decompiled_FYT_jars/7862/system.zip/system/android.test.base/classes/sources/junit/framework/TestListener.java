package junit.framework;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\android.test.base\classes.dex */
public interface TestListener {
    void addError(Test test, Throwable th);

    void addFailure(Test test, AssertionFailedError assertionFailedError);

    void endTest(Test test);

    void startTest(Test test);
}
