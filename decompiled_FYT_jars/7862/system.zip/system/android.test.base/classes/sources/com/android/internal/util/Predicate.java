package com.android.internal.util;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\android.test.base\classes.dex */
@Deprecated
public interface Predicate<T> {
    boolean apply(T t);
}
