package android.test;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\android.test.base\classes.dex */
@Deprecated
public interface PerformanceTestCase {

    public interface Intermediates {
        void addIntermediate(String str);

        void addIntermediate(String str, long j);

        void finishTiming(boolean z);

        void setInternalIterations(int i);

        void startTiming(boolean z);
    }

    boolean isPerformanceOnly();

    int startPerformance(Intermediates intermediates);
}
