package gov.nist.core;

import java.text.ParseException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class HostNameParser extends ParserCore {
    private static LexerCore Lexer;
    private static final char[] VALID_DOMAIN_LABEL_CHAR = {65533, '-', '.'};
    private boolean stripAddressScopeZones;

    public HostNameParser(String hname) {
        this.stripAddressScopeZones = false;
        this.lexer = new LexerCore("charLexer", hname);
        this.stripAddressScopeZones = Boolean.getBoolean("gov.nist.core.STRIP_ADDR_SCOPES");
    }

    public HostNameParser(LexerCore lexer) {
        this.stripAddressScopeZones = false;
        this.lexer = lexer;
        lexer.selectLexer("charLexer");
        this.stripAddressScopeZones = Boolean.getBoolean("gov.nist.core.STRIP_ADDR_SCOPES");
    }

    protected void consumeDomainLabel() throws ParseException {
        if (debug) {
            dbg_enter("domainLabel");
        }
        try {
            this.lexer.consumeValidChars(VALID_DOMAIN_LABEL_CHAR);
        } finally {
            if (debug) {
                dbg_leave("domainLabel");
            }
        }
    }

    protected String ipv6Reference() throws ParseException {
        int stripLen;
        StringBuffer retval = new StringBuffer();
        if (debug) {
            dbg_enter("ipv6Reference");
        }
        try {
            if (this.stripAddressScopeZones) {
                while (this.lexer.hasMoreChars()) {
                    char la = this.lexer.lookAhead(0);
                    if (!LexerCore.isHexDigit(la) && la != '.' && la != ':' && la != '[') {
                        if (la != ']') {
                            if (la != '%') {
                                break;
                            }
                            this.lexer.consume(1);
                            String rest = this.lexer.getRest();
                            if (rest == null || rest.length() == 0 || (stripLen = rest.indexOf(93)) == -1) {
                                break;
                                break;
                                break;
                            }
                            this.lexer.consume(stripLen + 1);
                            retval.append("]");
                            String string = retval.toString();
                            if (debug) {
                                dbg_leave("ipv6Reference");
                            }
                            return string;
                        }
                        this.lexer.consume(1);
                        retval.append(la);
                        String string2 = retval.toString();
                        if (debug) {
                            dbg_leave("ipv6Reference");
                        }
                        return string2;
                    }
                    this.lexer.consume(1);
                    retval.append(la);
                }
            } else {
                while (this.lexer.hasMoreChars()) {
                    char la2 = this.lexer.lookAhead(0);
                    if (!LexerCore.isHexDigit(la2) && la2 != '.' && la2 != ':' && la2 != '[') {
                        if (la2 != ']') {
                            break;
                        }
                        this.lexer.consume(1);
                        retval.append(la2);
                        String string3 = retval.toString();
                        if (debug) {
                            dbg_leave("ipv6Reference");
                        }
                        return string3;
                    }
                    this.lexer.consume(1);
                    retval.append(la2);
                }
            }
            throw new ParseException(this.lexer.getBuffer() + ": Illegal Host name ", this.lexer.getPtr());
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("ipv6Reference");
            }
            throw th;
        }
    }

    public Host host() throws ParseException {
        String hostname;
        if (debug) {
            dbg_enter("host");
        }
        try {
            if (this.lexer.lookAhead(0) == '[') {
                hostname = ipv6Reference();
            } else if (isIPv6Address(this.lexer.getRest())) {
                int startPtr = this.lexer.getPtr();
                this.lexer.consumeValidChars(new char[]{65533, ':'});
                StringBuffer stringBuffer = new StringBuffer("[");
                stringBuffer.append(this.lexer.getBuffer().substring(startPtr, this.lexer.getPtr()));
                stringBuffer.append("]");
                hostname = stringBuffer.toString();
            } else {
                int startPtr2 = this.lexer.getPtr();
                consumeDomainLabel();
                hostname = this.lexer.getBuffer().substring(startPtr2, this.lexer.getPtr());
            }
            if (hostname.length() == 0) {
                throw new ParseException(this.lexer.getBuffer() + ": Missing host name", this.lexer.getPtr());
            }
            Host host = new Host(hostname);
            if (debug) {
                dbg_leave("host");
            }
            return host;
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("host");
            }
            throw th;
        }
    }

    private boolean isIPv6Address(String uriHeader) {
        LexerCore lexerCore = Lexer;
        int hostEnd = uriHeader.indexOf(63);
        LexerCore lexerCore2 = Lexer;
        int semiColonIndex = uriHeader.indexOf(59);
        if (hostEnd == -1 || (semiColonIndex != -1 && hostEnd > semiColonIndex)) {
            hostEnd = semiColonIndex;
        }
        if (hostEnd == -1) {
            hostEnd = uriHeader.length();
        }
        String host = uriHeader.substring(0, hostEnd);
        LexerCore lexerCore3 = Lexer;
        int firstColonIndex = host.indexOf(58);
        if (firstColonIndex == -1) {
            return false;
        }
        LexerCore lexerCore4 = Lexer;
        int secondColonIndex = host.indexOf(58, firstColonIndex + 1);
        if (secondColonIndex == -1) {
            return false;
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:45:0x009e  */
    /* JADX WARN: Code duplicated, block: B:46:0x009f A[Catch: all -> 0x00d4, TryCatch #0 {all -> 0x00d4, blocks: (B:5:0x0009, B:7:0x0017, B:8:0x001c, B:10:0x0024, B:46:0x009f, B:47:0x00ca, B:33:0x0058, B:35:0x0060, B:36:0x0065, B:39:0x0074, B:40:0x0096, B:41:0x0097), top: B:57:0x0009, inners: #1 }] */
    /* JADX WARN: Instruction removed from duplicated block: B:46:0x009f, please report this as an issue */
    public HostPort hostPort(boolean allowWS) throws ParseException {
        char la;
        if (debug) {
            dbg_enter("hostPort");
        }
        try {
            Host host = host();
            HostPort hp = new HostPort();
            hp.setHost(host);
            if (allowWS) {
                this.lexer.SPorHT();
            }
            if (this.lexer.hasMoreChars() && (la = this.lexer.lookAhead(0)) != '\t' && la != '\n' && la != '\r' && la != ' ') {
                if (la != '%') {
                    if (la != ',' && la != '/') {
                        if (la == ':') {
                            this.lexer.consume(1);
                            if (allowWS) {
                                this.lexer.SPorHT();
                            }
                            try {
                                String port = this.lexer.number();
                                hp.setPort(Integer.parseInt(port));
                            } catch (NumberFormatException e) {
                                throw new ParseException(this.lexer.getBuffer() + " :Error parsing port ", this.lexer.getPtr());
                            }
                        } else if (la != ';' && la != '>' && la != '?') {
                            if (allowWS) {
                                throw new ParseException(this.lexer.getBuffer() + " Illegal character in hostname:" + this.lexer.lookAhead(0), this.lexer.getPtr());
                            }
                        }
                    }
                } else if (!this.stripAddressScopeZones) {
                    if (allowWS) {
                        throw new ParseException(this.lexer.getBuffer() + " Illegal character in hostname:" + this.lexer.lookAhead(0), this.lexer.getPtr());
                    }
                }
            }
            if (debug) {
                dbg_leave("hostPort");
            }
            return hp;
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("hostPort");
            }
            throw th;
        }
    }

    public static void main(String[] args) throws ParseException {
        String[] hostNames = {"foo.bar.com:1234", "proxima.chaplin.bt.co.uk", "129.6.55.181:2345", ":1234", "foo.bar.com:         1234", "foo.bar.com     :      1234   ", "MIK_S:1234"};
        for (String str : hostNames) {
            try {
                HostNameParser hnp = new HostNameParser(str);
                HostPort hp = hnp.hostPort(true);
                System.out.println("[" + hp.encode() + "]");
            } catch (ParseException ex) {
                System.out.println("exception text = " + ex.getMessage());
            }
        }
    }
}
