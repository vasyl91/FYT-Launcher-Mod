package gov.nist.core;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface Match {
    boolean match(String str);
}
