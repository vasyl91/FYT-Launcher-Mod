package gov.nist.javax.sip.parser.ims;

import gov.nist.core.Token;
import gov.nist.javax.sip.header.SIPHeader;
import gov.nist.javax.sip.header.ims.PMediaAuthorization;
import gov.nist.javax.sip.header.ims.PMediaAuthorizationList;
import gov.nist.javax.sip.parser.HeaderParser;
import gov.nist.javax.sip.parser.Lexer;
import gov.nist.javax.sip.parser.TokenTypes;
import java.text.ParseException;
import javax.sip.InvalidArgumentException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class PMediaAuthorizationParser extends HeaderParser implements TokenTypes {
    public PMediaAuthorizationParser(String mediaAuthorization) {
        super(mediaAuthorization);
    }

    public PMediaAuthorizationParser(Lexer lexer) {
        super(lexer);
    }

    @Override // gov.nist.javax.sip.parser.HeaderParser
    public SIPHeader parse() throws ParseException {
        PMediaAuthorizationList mediaAuthorizationList = new PMediaAuthorizationList();
        if (debug) {
            dbg_enter("MediaAuthorizationParser.parse");
        }
        try {
            headerName(TokenTypes.P_MEDIA_AUTHORIZATION);
            PMediaAuthorization mediaAuthorization = new PMediaAuthorization();
            mediaAuthorization.setHeaderName("P-Media-Authorization");
            while (this.lexer.lookAhead(0) != '\n') {
                this.lexer.match(4095);
                Token token = this.lexer.getNextToken();
                try {
                    mediaAuthorization.setMediaAuthorizationToken(token.getTokenValue());
                    mediaAuthorizationList.add(mediaAuthorization);
                    this.lexer.SPorHT();
                    if (this.lexer.lookAhead(0) == ',') {
                        this.lexer.match(44);
                        mediaAuthorization = new PMediaAuthorization();
                    }
                    this.lexer.SPorHT();
                } catch (InvalidArgumentException e) {
                    throw createParseException(e.getMessage());
                }
            }
            if (debug) {
                dbg_leave("MediaAuthorizationParser.parse");
            }
            return mediaAuthorizationList;
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("MediaAuthorizationParser.parse");
            }
            throw th;
        }
    }
}
