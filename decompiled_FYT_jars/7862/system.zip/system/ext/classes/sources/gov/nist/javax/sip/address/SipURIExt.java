package gov.nist.javax.sip.address;

import javax.sip.address.SipURI;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface SipURIExt extends SipURI {
    boolean hasGrParam();

    void removeHeader(String str);

    void removeHeaders();

    void setGrParam(String str);
}
