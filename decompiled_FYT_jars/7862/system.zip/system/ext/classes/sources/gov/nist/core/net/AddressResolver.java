package gov.nist.core.net;

import javax.sip.address.Hop;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface AddressResolver {
    Hop resolveAddress(Hop hop);
}
