package gov.nist.javax.sip.parser;

import gov.nist.javax.sip.header.Organization;
import gov.nist.javax.sip.header.SIPHeader;
import java.text.ParseException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class OrganizationParser extends HeaderParser {
    public OrganizationParser(String organization) {
        super(organization);
    }

    protected OrganizationParser(Lexer lexer) {
        super(lexer);
    }

    @Override // gov.nist.javax.sip.parser.HeaderParser
    public SIPHeader parse() throws ParseException {
        if (debug) {
            dbg_enter("OrganizationParser.parse");
        }
        Organization organization = new Organization();
        try {
            headerName(TokenTypes.ORGANIZATION);
            organization.setHeaderName("Organization");
            this.lexer.SPorHT();
            String value = this.lexer.getRest();
            organization.setOrganization(value.trim());
            return organization;
        } finally {
            if (debug) {
                dbg_leave("OrganizationParser.parse");
            }
        }
    }
}
