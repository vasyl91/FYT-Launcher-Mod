package gov.nist.javax.sip;

import javax.sip.ClientTransaction;
import javax.sip.address.Hop;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface ClientTransactionExt extends ClientTransaction, TransactionExt {
    @Override // javax.sip.ClientTransaction
    void alertIfStillInCallingStateBy(int i);

    @Override // javax.sip.ClientTransaction
    Hop getNextHop();

    boolean isSecure();

    @Override // javax.sip.ClientTransaction
    void setNotifyOnRetransmit(boolean z);
}
