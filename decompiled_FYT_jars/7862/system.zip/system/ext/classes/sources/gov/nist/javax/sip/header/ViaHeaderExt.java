package gov.nist.javax.sip.header;

import javax.sip.header.ViaHeader;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface ViaHeaderExt extends ViaHeader {
    String getSentByField();

    String getSentProtocolField();
}
