package gov.nist.javax.sip.parser;

import gov.nist.javax.sip.address.GenericURI;
import gov.nist.javax.sip.header.ErrorInfo;
import gov.nist.javax.sip.header.ErrorInfoList;
import gov.nist.javax.sip.header.SIPHeader;
import java.text.ParseException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class ErrorInfoParser extends ParametersParser {
    public ErrorInfoParser(String errorInfo) {
        super(errorInfo);
    }

    protected ErrorInfoParser(Lexer lexer) {
        super(lexer);
    }

    @Override // gov.nist.javax.sip.parser.HeaderParser
    public SIPHeader parse() throws ParseException {
        if (debug) {
            dbg_enter("ErrorInfoParser.parse");
        }
        ErrorInfoList list = new ErrorInfoList();
        try {
            headerName(TokenTypes.ERROR_INFO);
            while (this.lexer.lookAhead(0) != '\n') {
                while (true) {
                    ErrorInfo errorInfo = new ErrorInfo();
                    errorInfo.setHeaderName("Error-Info");
                    this.lexer.SPorHT();
                    this.lexer.match(60);
                    URLParser urlParser = new URLParser((Lexer) this.lexer);
                    GenericURI uri = urlParser.uriReference(true);
                    errorInfo.setErrorInfo(uri);
                    this.lexer.match(62);
                    this.lexer.SPorHT();
                    super.parse(errorInfo);
                    list.add(errorInfo);
                    if (this.lexer.lookAhead(0) == ',') {
                        this.lexer.match(44);
                    }
                }
            }
            if (debug) {
                dbg_leave("ErrorInfoParser.parse");
            }
            return list;
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("ErrorInfoParser.parse");
            }
            throw th;
        }
    }
}
