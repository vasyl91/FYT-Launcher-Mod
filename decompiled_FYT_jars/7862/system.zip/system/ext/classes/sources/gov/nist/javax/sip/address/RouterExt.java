package gov.nist.javax.sip.address;

import javax.sip.address.Hop;
import javax.sip.address.Router;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface RouterExt extends Router {
    void transactionTimeout(Hop hop);
}
