package gov.nist.javax.sip.parser;

import gov.nist.javax.sip.message.SIPMessage;
import java.text.ParseException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface ParseExceptionListener {
    void handleException(ParseException parseException, SIPMessage sIPMessage, Class cls, String str, String str2) throws ParseException;
}
