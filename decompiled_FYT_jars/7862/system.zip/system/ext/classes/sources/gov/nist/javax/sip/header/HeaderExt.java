package gov.nist.javax.sip.header;

import javax.sip.header.Header;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface HeaderExt extends Header {
    String getValue();
}
