package gov.nist.core;

import java.net.InetAddress;
import java.net.UnknownHostException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public final class HostPort extends GenericObject {
    private static final long serialVersionUID = -7103412227431884523L;
    protected Host host = null;
    protected int port = -1;

    @Override // gov.nist.core.GenericObject
    public String encode() {
        return encode(new StringBuffer()).toString();
    }

    @Override // gov.nist.core.GenericObject
    public StringBuffer encode(StringBuffer buffer) {
        this.host.encode(buffer);
        if (this.port != -1) {
            buffer.append(Separators.COLON);
            buffer.append(this.port);
        }
        return buffer;
    }

    @Override // gov.nist.core.GenericObject
    public boolean equals(Object other) {
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        HostPort that = (HostPort) other;
        return this.port == that.port && this.host.equals(that.host);
    }

    public Host getHost() {
        return this.host;
    }

    public int getPort() {
        return this.port;
    }

    public boolean hasPort() {
        return this.port != -1;
    }

    public void removePort() {
        this.port = -1;
    }

    public void setHost(Host h) {
        this.host = h;
    }

    public void setPort(int p) {
        this.port = p;
    }

    public InetAddress getInetAddress() throws UnknownHostException {
        Host host = this.host;
        if (host == null) {
            return null;
        }
        return host.getInetAddress();
    }

    @Override // gov.nist.core.GenericObject
    public void merge(Object mergeObject) {
        super.merge(mergeObject);
        if (this.port == -1) {
            this.port = ((HostPort) mergeObject).port;
        }
    }

    @Override // gov.nist.core.GenericObject
    public Object clone() {
        HostPort retval = (HostPort) super.clone();
        Host host = this.host;
        if (host != null) {
            retval.host = (Host) host.clone();
        }
        return retval;
    }

    public String toString() {
        return encode();
    }

    public int hashCode() {
        return this.host.hashCode() + this.port;
    }
}
