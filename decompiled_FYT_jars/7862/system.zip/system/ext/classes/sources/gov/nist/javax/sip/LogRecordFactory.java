package gov.nist.javax.sip;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface LogRecordFactory {
    LogRecord createLogRecord(String str, String str2, String str3, long j, boolean z, String str4, String str5, String str6, long j2);
}
