package gov.nist.javax.sip;

import javax.sip.Dialog;
import javax.sip.SipProvider;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface DialogExt extends Dialog {
    void disableSequenceNumberValidation();

    @Override // javax.sip.Dialog
    SipProvider getSipProvider();

    @Override // javax.sip.Dialog
    void setBackToBackUserAgent();
}
