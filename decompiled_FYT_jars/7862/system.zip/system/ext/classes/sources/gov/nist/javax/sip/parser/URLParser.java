package gov.nist.javax.sip.parser;

import gov.nist.core.HostNameParser;
import gov.nist.core.HostPort;
import gov.nist.core.NameValue;
import gov.nist.core.NameValueList;
import gov.nist.core.Separators;
import gov.nist.core.Token;
import gov.nist.javax.sip.address.GenericURI;
import gov.nist.javax.sip.address.SipUri;
import gov.nist.javax.sip.address.TelURLImpl;
import gov.nist.javax.sip.address.TelephoneNumber;
import java.text.ParseException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class URLParser extends Parser {
    public URLParser(String url) {
        this.lexer = new Lexer("sip_urlLexer", url);
    }

    public URLParser(Lexer lexer) {
        this.lexer = lexer;
        this.lexer.selectLexer("sip_urlLexer");
    }

    protected static boolean isMark(char next) {
        if (next == '!' || next == '_' || next == '~' || next == '-' || next == '.') {
            return true;
        }
        switch (next) {
            case '\'':
            case '(':
            case ')':
            case '*':
                return true;
            default:
                return false;
        }
    }

    protected static boolean isUnreserved(char next) {
        return Lexer.isAlphaDigit(next) || isMark(next);
    }

    protected static boolean isReservedNoSlash(char next) {
        if (next == '$' || next == '&' || next == '+' || next == ',' || next == ':' || next == ';' || next == '?' || next == '@') {
            return true;
        }
        return false;
    }

    protected static boolean isUserUnreserved(char la) {
        if (la == '#' || la == '$' || la == '&' || la == '/' || la == ';' || la == '=' || la == '?' || la == '+' || la == ',') {
            return true;
        }
        return false;
    }

    protected String unreserved() throws ParseException {
        char next = this.lexer.lookAhead(0);
        if (isUnreserved(next)) {
            this.lexer.consume(1);
            return String.valueOf(next);
        }
        throw createParseException("unreserved");
    }

    protected String paramNameOrValue() throws ParseException {
        int startIdx = this.lexer.getPtr();
        while (this.lexer.hasMoreChars()) {
            char next = this.lexer.lookAhead(0);
            boolean isValidChar = false;
            if (next == '$' || next == '&' || next == '+' || next == '/' || next == ':' || next == '[' || next == ']') {
                isValidChar = true;
            }
            if (isValidChar || isUnreserved(next)) {
                this.lexer.consume(1);
            } else {
                if (!isEscaped()) {
                    break;
                }
                this.lexer.consume(3);
            }
        }
        return this.lexer.getBuffer().substring(startIdx, this.lexer.getPtr());
    }

    private NameValue uriParam() throws ParseException {
        if (debug) {
            dbg_enter("uriParam");
        }
        try {
            String pvalue = "";
            String pname = paramNameOrValue();
            char next = this.lexer.lookAhead(0);
            boolean isFlagParam = true;
            if (next == '=') {
                this.lexer.consume(1);
                pvalue = paramNameOrValue();
                isFlagParam = false;
            }
            if (pname.length() != 0 || (pvalue != null && pvalue.length() != 0)) {
                return new NameValue(pname, pvalue, isFlagParam);
            }
            return null;
        } finally {
            if (debug) {
                dbg_leave("uriParam");
            }
        }
    }

    protected static boolean isReserved(char next) {
        if (next == '$' || next == '&' || next == '/' || next == '=' || next == '+' || next == ',' || next == ':' || next == ';' || next == '?' || next == '@') {
            return true;
        }
        return false;
    }

    protected String reserved() throws ParseException {
        char next = this.lexer.lookAhead(0);
        if (isReserved(next)) {
            this.lexer.consume(1);
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(next);
            return stringBuffer.toString();
        }
        throw createParseException("reserved");
    }

    protected boolean isEscaped() {
        try {
            return this.lexer.lookAhead(0) == '%' && Lexer.isHexDigit(this.lexer.lookAhead(1)) && Lexer.isHexDigit(this.lexer.lookAhead(2));
        } catch (Exception e) {
            return false;
        }
    }

    protected String escaped() throws ParseException {
        if (debug) {
            dbg_enter("escaped");
        }
        try {
            StringBuffer retval = new StringBuffer();
            char next = this.lexer.lookAhead(0);
            char next1 = this.lexer.lookAhead(1);
            char next2 = this.lexer.lookAhead(2);
            if (next == '%' && Lexer.isHexDigit(next1) && Lexer.isHexDigit(next2)) {
                this.lexer.consume(3);
                retval.append(next);
                retval.append(next1);
                retval.append(next2);
                String string = retval.toString();
                if (debug) {
                    dbg_leave("escaped");
                }
                return string;
            }
            throw createParseException("escaped");
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("escaped");
            }
            throw th;
        }
    }

    protected String mark() throws ParseException {
        if (debug) {
            dbg_enter("mark");
        }
        try {
            char next = this.lexer.lookAhead(0);
            if (isMark(next)) {
                this.lexer.consume(1);
                String str = new String(new char[]{next});
                if (debug) {
                    dbg_leave("mark");
                }
                return str;
            }
            throw createParseException("mark");
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("mark");
            }
            throw th;
        }
    }

    protected String uric() {
        if (debug) {
            dbg_enter("uric");
        }
        try {
            char la = this.lexer.lookAhead(0);
            if (isUnreserved(la)) {
                this.lexer.consume(1);
                return Lexer.charAsString(la);
            }
            if (isReserved(la)) {
                this.lexer.consume(1);
                return Lexer.charAsString(la);
            }
            if (!isEscaped()) {
                return null;
            }
            String retval = this.lexer.charAsString(3);
            this.lexer.consume(3);
            return retval;
        } catch (Exception e) {
            return null;
        } finally {
            if (debug) {
                dbg_leave("uric");
            }
        }
    }

    protected String uricNoSlash() {
        if (debug) {
            dbg_enter("uricNoSlash");
        }
        try {
            char la = this.lexer.lookAhead(0);
            if (isEscaped()) {
                String retval = this.lexer.charAsString(3);
                this.lexer.consume(3);
                return retval;
            }
            if (isUnreserved(la)) {
                this.lexer.consume(1);
                return Lexer.charAsString(la);
            }
            if (!isReservedNoSlash(la)) {
                return null;
            }
            this.lexer.consume(1);
            return Lexer.charAsString(la);
        } catch (ParseException e) {
            return null;
        } finally {
            if (debug) {
                dbg_leave("uricNoSlash");
            }
        }
    }

    protected String uricString() throws ParseException {
        StringBuffer retval = new StringBuffer();
        while (true) {
            String next = uric();
            if (next == null) {
                char la = this.lexer.lookAhead(0);
                if (la == '[') {
                    HostNameParser hnp = new HostNameParser(getLexer());
                    HostPort hp = hnp.hostPort(false);
                    retval.append(hp.toString());
                } else {
                    return retval.toString();
                }
            } else {
                retval.append(next);
            }
        }
    }

    public GenericURI uriReference(boolean inBrackets) throws ParseException {
        GenericURI retval;
        if (debug) {
            dbg_enter("uriReference");
        }
        Token[] tokens = this.lexer.peekNextToken(2);
        Token t1 = tokens[0];
        Token t2 = tokens[1];
        try {
            if (t1.getTokenType() == 2051 || t1.getTokenType() == 2136) {
                if (t2.getTokenType() == 58) {
                    retval = sipURL(inBrackets);
                } else {
                    throw createParseException("Expecting ':'");
                }
            } else if (t1.getTokenType() == 2105) {
                if (t2.getTokenType() == 58) {
                    retval = telURL(inBrackets);
                } else {
                    throw createParseException("Expecting ':'");
                }
            } else {
                String urlString = uricString();
                try {
                    retval = new GenericURI(urlString);
                } catch (ParseException ex) {
                    throw createParseException(ex.getMessage());
                }
            }
            if (debug) {
                dbg_leave("uriReference");
            }
            return retval;
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("uriReference");
            }
            throw th;
        }
    }

    private String base_phone_number() throws ParseException {
        StringBuffer s = new StringBuffer();
        if (debug) {
            dbg_enter("base_phone_number");
        }
        int lc = 0;
        while (this.lexer.hasMoreChars()) {
            try {
                char w = this.lexer.lookAhead(0);
                if (!Lexer.isDigit(w) && w != '-' && w != '.' && w != '(' && w != ')') {
                    if (lc > 0) {
                        break;
                    }
                    throw createParseException("unexpected " + w);
                }
                this.lexer.consume(1);
                s.append(w);
                lc++;
            } catch (Throwable th) {
                if (debug) {
                    dbg_leave("base_phone_number");
                }
                throw th;
            }
        }
        String string = s.toString();
        if (debug) {
            dbg_leave("base_phone_number");
        }
        return string;
    }

    private String local_number() throws ParseException {
        StringBuffer s = new StringBuffer();
        if (debug) {
            dbg_enter("local_number");
        }
        int lc = 0;
        while (this.lexer.hasMoreChars()) {
            try {
                char la = this.lexer.lookAhead(0);
                if (la != '*' && la != '#' && la != '-' && la != '.' && la != '(' && la != ')' && !Lexer.isHexDigit(la)) {
                    if (lc > 0) {
                        break;
                    }
                    throw createParseException("unexepcted " + la);
                }
                this.lexer.consume(1);
                s.append(la);
                lc++;
            } catch (Throwable th) {
                if (debug) {
                    dbg_leave("local_number");
                }
                throw th;
            }
        }
        String string = s.toString();
        if (debug) {
            dbg_leave("local_number");
        }
        return string;
    }

    public final TelephoneNumber parseTelephoneNumber(boolean inBrackets) throws ParseException {
        TelephoneNumber tn;
        if (debug) {
            dbg_enter("telephone_subscriber");
        }
        this.lexer.selectLexer("charLexer");
        try {
            char c = this.lexer.lookAhead(0);
            if (c == '+') {
                tn = global_phone_number(inBrackets);
            } else {
                if (!Lexer.isHexDigit(c) && c != '#' && c != '*' && c != '-' && c != '.' && c != '(' && c != ')') {
                    throw createParseException("unexpected char " + c);
                }
                tn = local_phone_number(inBrackets);
            }
            if (debug) {
                dbg_leave("telephone_subscriber");
            }
            return tn;
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("telephone_subscriber");
            }
            throw th;
        }
    }

    private final TelephoneNumber global_phone_number(boolean inBrackets) throws ParseException {
        if (debug) {
            dbg_enter("global_phone_number");
        }
        try {
            TelephoneNumber tn = new TelephoneNumber();
            tn.setGlobal(true);
            this.lexer.match(43);
            String b = base_phone_number();
            tn.setPhoneNumber(b);
            if (this.lexer.hasMoreChars()) {
                char tok = this.lexer.lookAhead(0);
                if (tok == ';' && inBrackets) {
                    this.lexer.consume(1);
                    NameValueList nv = tel_parameters();
                    tn.setParameters(nv);
                }
            }
            return tn;
        } finally {
            if (debug) {
                dbg_leave("global_phone_number");
            }
        }
    }

    private TelephoneNumber local_phone_number(boolean inBrackets) throws ParseException {
        if (debug) {
            dbg_enter("local_phone_number");
        }
        TelephoneNumber tn = new TelephoneNumber();
        tn.setGlobal(false);
        try {
            String b = local_number();
            tn.setPhoneNumber(b);
            if (this.lexer.hasMoreChars()) {
                Token tok = this.lexer.peekNextToken();
                if (tok.getTokenType() == 59 && inBrackets) {
                    this.lexer.consume(1);
                    NameValueList nv = tel_parameters();
                    tn.setParameters(nv);
                }
            }
            return tn;
        } finally {
            if (debug) {
                dbg_leave("local_phone_number");
            }
        }
    }

    private NameValueList tel_parameters() throws ParseException {
        NameValue nv;
        NameValueList nvList = new NameValueList();
        while (true) {
            String pname = paramNameOrValue();
            if (pname.equalsIgnoreCase("phone-context")) {
                nv = phone_context();
            } else if (this.lexer.lookAhead(0) == '=') {
                this.lexer.consume(1);
                String value = paramNameOrValue();
                nv = new NameValue(pname, value, false);
            } else {
                nv = new NameValue(pname, "", true);
            }
            nvList.set(nv);
            if (this.lexer.lookAhead(0) == ';') {
                this.lexer.consume(1);
            } else {
                return nvList;
            }
        }
    }

    private NameValue phone_context() throws ParseException {
        Object value;
        this.lexer.match(61);
        char la = this.lexer.lookAhead(0);
        if (la == '+') {
            this.lexer.consume(1);
            value = "+" + base_phone_number();
        } else if (Lexer.isAlphaDigit(la)) {
            Token t = this.lexer.match(4095);
            value = t.getTokenValue();
        } else {
            throw new ParseException("Invalid phone-context:" + la, -1);
        }
        return new NameValue("phone-context", value, false);
    }

    public TelURLImpl telURL(boolean inBrackets) throws ParseException {
        this.lexer.match(TokenTypes.TEL);
        this.lexer.match(58);
        TelephoneNumber tn = parseTelephoneNumber(inBrackets);
        TelURLImpl telUrl = new TelURLImpl();
        telUrl.setTelephoneNumber(tn);
        return telUrl;
    }

    public SipUri sipURL(boolean inBrackets) throws ParseException {
        String scheme;
        int sipOrSips;
        if (debug) {
            dbg_enter("sipURL");
        }
        SipUri retval = new SipUri();
        Token nextToken = this.lexer.peekNextToken();
        if (nextToken.getTokenType() != 2136) {
            scheme = "sip";
            sipOrSips = 2051;
        } else {
            scheme = "sips";
            sipOrSips = 2136;
        }
        try {
            try {
                this.lexer.match(sipOrSips);
                this.lexer.match(58);
                retval.setScheme(scheme);
                int startOfUser = this.lexer.markInputPosition();
                String userOrHost = user();
                String passOrPort = null;
                if (this.lexer.lookAhead() == ':') {
                    this.lexer.consume(1);
                    passOrPort = password();
                }
                if (this.lexer.lookAhead() == '@') {
                    this.lexer.consume(1);
                    retval.setUser(userOrHost);
                    if (passOrPort != null) {
                        retval.setUserPassword(passOrPort);
                    }
                } else {
                    this.lexer.rewindInputPosition(startOfUser);
                }
                HostNameParser hnp = new HostNameParser(getLexer());
                HostPort hp = hnp.hostPort(false);
                retval.setHostPort(hp);
                this.lexer.selectLexer("charLexer");
                while (this.lexer.hasMoreChars() && this.lexer.lookAhead(0) == ';' && inBrackets) {
                    this.lexer.consume(1);
                    NameValue parms = uriParam();
                    if (parms != null) {
                        retval.setUriParameter(parms);
                    }
                }
                if (this.lexer.hasMoreChars() && this.lexer.lookAhead(0) == '?') {
                    this.lexer.consume(1);
                    while (this.lexer.hasMoreChars()) {
                        retval.setQHeader(qheader());
                        if (this.lexer.hasMoreChars() && this.lexer.lookAhead(0) != '&') {
                            break;
                        }
                        this.lexer.consume(1);
                    }
                }
                if (debug) {
                    dbg_leave("sipURL");
                }
                return retval;
            } catch (RuntimeException e) {
                throw new ParseException("Invalid URL: " + this.lexer.getBuffer(), -1);
            }
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("sipURL");
            }
            throw th;
        }
    }

    public String peekScheme() throws ParseException {
        Token[] tokens = this.lexer.peekNextToken(1);
        if (tokens.length == 0) {
            return null;
        }
        String scheme = tokens[0].getTokenValue();
        return scheme;
    }

    protected NameValue qheader() throws ParseException {
        String name = this.lexer.getNextToken('=');
        this.lexer.consume(1);
        String value = hvalue();
        return new NameValue(name, value, false);
    }

    /* JADX WARN: Code duplicated, block: B:26:0x0040 A[FALL_THROUGH] */
    /*  JADX ERROR: UnsupportedOperationException in pass: RegionMakerVisitor
        java.lang.UnsupportedOperationException
        	at java.base/java.util.Collections$UnmodifiableCollection.add(Collections.java:1092)
        	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker$1.leaveRegion(SwitchRegionMaker.java:419)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseInternal(DepthRegionTraversal.java:91)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverse(DepthRegionTraversal.java:31)
        	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker.insertBreaksForCase(SwitchRegionMaker.java:399)
        	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker.insertBreaks(SwitchRegionMaker.java:89)
        	at jadx.core.dex.visitors.regions.PostProcessRegions.leaveRegion(PostProcessRegions.java:31)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseInternal(DepthRegionTraversal.java:91)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverse(DepthRegionTraversal.java:27)
        	at jadx.core.dex.visitors.regions.PostProcessRegions.process(PostProcessRegions.java:21)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:31)
        */
    protected java.lang.String hvalue() throws java.text.ParseException {
        /*
            r5 = this;
            java.lang.StringBuffer r0 = new java.lang.StringBuffer
            r0.<init>()
        L5:
            gov.nist.core.LexerCore r1 = r5.lexer
            boolean r1 = r1.hasMoreChars()
            if (r1 == 0) goto L60
            gov.nist.core.LexerCore r1 = r5.lexer
            r2 = 0
            char r1 = r1.lookAhead(r2)
            r2 = 0
            r3 = 33
            if (r1 == r3) goto L40
            r3 = 34
            if (r1 == r3) goto L40
            r3 = 36
            if (r1 == r3) goto L40
            r3 = 58
            if (r1 == r3) goto L40
            r3 = 63
            if (r1 == r3) goto L40
            r3 = 91
            if (r1 == r3) goto L40
            r3 = 93
            if (r1 == r3) goto L40
            r3 = 95
            if (r1 == r3) goto L40
            r3 = 126(0x7e, float:1.77E-43)
            if (r1 == r3) goto L40
            switch(r1) {
                case 40: goto L40;
                case 41: goto L40;
                case 42: goto L40;
                case 43: goto L40;
                default: goto L3c;
            }
        L3c:
            switch(r1) {
                case 45: goto L40;
                case 46: goto L40;
                case 47: goto L40;
                default: goto L3f;
            }
        L3f:
            goto L41
        L40:
            r2 = 1
        L41:
            if (r2 != 0) goto L56
            boolean r3 = gov.nist.javax.sip.parser.Lexer.isAlphaDigit(r1)
            if (r3 == 0) goto L4a
            goto L56
        L4a:
            r3 = 37
            if (r1 != r3) goto L60
            java.lang.String r3 = r5.escaped()
            r0.append(r3)
            goto L5f
        L56:
            gov.nist.core.LexerCore r3 = r5.lexer
            r4 = 1
            r3.consume(r4)
            r0.append(r1)
        L5f:
            goto L5
        L60:
            java.lang.String r1 = r0.toString()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: gov.nist.javax.sip.parser.URLParser.hvalue():java.lang.String");
    }

    protected String urlString() throws ParseException {
        char la;
        StringBuffer retval = new StringBuffer();
        this.lexer.selectLexer("charLexer");
        while (this.lexer.hasMoreChars() && (la = this.lexer.lookAhead(0)) != ' ' && la != '\t' && la != '\n' && la != '>' && la != '<') {
            this.lexer.consume(0);
            retval.append(la);
        }
        return retval.toString();
    }

    protected String user() throws ParseException {
        if (debug) {
            dbg_enter("user");
        }
        try {
            int startIdx = this.lexer.getPtr();
            while (this.lexer.hasMoreChars()) {
                char la = this.lexer.lookAhead(0);
                if (isUnreserved(la) || isUserUnreserved(la)) {
                    this.lexer.consume(1);
                } else {
                    if (!isEscaped()) {
                        break;
                    }
                    this.lexer.consume(3);
                }
            }
            return this.lexer.getBuffer().substring(startIdx, this.lexer.getPtr());
        } finally {
            if (debug) {
                dbg_leave("user");
            }
        }
    }

    protected String password() throws ParseException {
        int startIdx = this.lexer.getPtr();
        while (true) {
            char la = this.lexer.lookAhead(0);
            boolean isValidChar = false;
            if (la == '$' || la == '&' || la == '=' || la == '+' || la == ',') {
                isValidChar = true;
            }
            if (isValidChar || isUnreserved(la)) {
                this.lexer.consume(1);
            } else if (isEscaped()) {
                this.lexer.consume(3);
            } else {
                return this.lexer.getBuffer().substring(startIdx, this.lexer.getPtr());
            }
        }
    }

    public GenericURI parse() throws ParseException {
        return uriReference(true);
    }

    public static void main(String[] args) throws ParseException {
        String[] test = {"sip:alice@example.com", "sips:alice@examples.com", "sip:3Zqkv5dajqaaas0tCjCxT0xH2ZEuEMsFl0xoasip%3A%2B3519116786244%40siplab.domain.com@213.0.115.163:7070"};
        for (int i = 0; i < test.length; i++) {
            URLParser p = new URLParser(test[i]);
            GenericURI uri = p.parse();
            System.out.println("uri type returned " + uri.getClass().getName());
            System.out.println(test[i] + " is SipUri? " + uri.isSipURI() + Separators.GREATER_THAN + uri.encode());
        }
    }
}
