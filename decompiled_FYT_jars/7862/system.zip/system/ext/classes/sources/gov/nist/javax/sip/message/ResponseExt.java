package gov.nist.javax.sip.message;

import javax.sip.message.Response;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface ResponseExt extends Response, MessageExt {
}
