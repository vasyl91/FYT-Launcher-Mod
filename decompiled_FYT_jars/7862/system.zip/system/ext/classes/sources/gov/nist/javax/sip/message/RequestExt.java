package gov.nist.javax.sip.message;

import javax.sip.message.Request;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface RequestExt extends Request, MessageExt {
}
