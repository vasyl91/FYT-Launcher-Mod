package gov.nist.javax.sip.header;

import gov.nist.core.Separators;
import gov.nist.javax.sip.address.GenericURI;
import java.text.ParseException;
import javax.sip.address.URI;
import javax.sip.header.ErrorInfoHeader;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public final class ErrorInfo extends ParametersHeader implements ErrorInfoHeader {
    private static final long serialVersionUID = -6347702901964436362L;
    protected GenericURI errorInfo;

    public ErrorInfo() {
        super("Error-Info");
    }

    public ErrorInfo(GenericURI errorInfo) {
        this();
        this.errorInfo = errorInfo;
    }

    @Override // gov.nist.javax.sip.header.ParametersHeader, gov.nist.javax.sip.header.SIPHeader
    public String encodeBody() {
        StringBuffer stringBuffer = new StringBuffer(Separators.LESS_THAN);
        stringBuffer.append(this.errorInfo.toString());
        StringBuffer retval = stringBuffer.append(Separators.GREATER_THAN);
        if (!this.parameters.isEmpty()) {
            retval.append(Separators.SEMICOLON);
            retval.append(this.parameters.encode());
        }
        return retval.toString();
    }

    @Override // javax.sip.header.ErrorInfoHeader
    public void setErrorInfo(URI errorInfo) {
        this.errorInfo = (GenericURI) errorInfo;
    }

    @Override // javax.sip.header.ErrorInfoHeader
    public URI getErrorInfo() {
        return this.errorInfo;
    }

    @Override // javax.sip.header.ErrorInfoHeader
    public void setErrorMessage(String message) throws ParseException {
        if (message == null) {
            throw new NullPointerException("JAIN-SIP Exception , ErrorInfoHeader, setErrorMessage(), the message parameter is null");
        }
        setParameter("message", message);
    }

    @Override // javax.sip.header.ErrorInfoHeader
    public String getErrorMessage() {
        return getParameter("message");
    }

    @Override // gov.nist.javax.sip.header.ParametersHeader, gov.nist.core.GenericObject
    public Object clone() {
        ErrorInfo retval = (ErrorInfo) super.clone();
        GenericURI genericURI = this.errorInfo;
        if (genericURI != null) {
            retval.errorInfo = (GenericURI) genericURI.clone();
        }
        return retval;
    }
}
