package gov.nist.javax.sip.parser;

import gov.nist.core.Token;
import gov.nist.javax.sip.header.SIPHeader;
import gov.nist.javax.sip.header.Unsupported;
import gov.nist.javax.sip.header.UnsupportedList;
import java.text.ParseException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class UnsupportedParser extends HeaderParser {
    public UnsupportedParser(String unsupported) {
        super(unsupported);
    }

    protected UnsupportedParser(Lexer lexer) {
        super(lexer);
    }

    @Override // gov.nist.javax.sip.parser.HeaderParser
    public SIPHeader parse() throws ParseException {
        UnsupportedList unsupportedList = new UnsupportedList();
        if (debug) {
            dbg_enter("UnsupportedParser.parse");
        }
        try {
            headerName(TokenTypes.UNSUPPORTED);
            while (this.lexer.lookAhead(0) != '\n') {
                this.lexer.SPorHT();
                Unsupported unsupported = new Unsupported();
                unsupported.setHeaderName("Unsupported");
                this.lexer.match(4095);
                Token token = this.lexer.getNextToken();
                unsupported.setOptionTag(token.getTokenValue());
                this.lexer.SPorHT();
                unsupportedList.add(unsupported);
                while (this.lexer.lookAhead(0) == ',') {
                    this.lexer.match(44);
                    this.lexer.SPorHT();
                    Unsupported unsupported2 = new Unsupported();
                    this.lexer.match(4095);
                    Token token2 = this.lexer.getNextToken();
                    unsupported2.setOptionTag(token2.getTokenValue());
                    this.lexer.SPorHT();
                    unsupportedList.add(unsupported2);
                }
            }
            if (debug) {
                dbg_leave("UnsupportedParser.parse");
            }
            return unsupportedList;
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("UnsupportedParser.parse");
            }
            throw th;
        }
    }
}
