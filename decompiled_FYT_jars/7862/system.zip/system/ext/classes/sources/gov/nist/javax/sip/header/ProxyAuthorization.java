package gov.nist.javax.sip.header;

import javax.sip.header.ProxyAuthorizationHeader;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class ProxyAuthorization extends AuthenticationHeader implements ProxyAuthorizationHeader {
    private static final long serialVersionUID = -6374966905199799098L;

    public ProxyAuthorization() {
        super("Proxy-Authorization");
    }
}
