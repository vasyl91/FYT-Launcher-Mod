package gov.nist.javax.sip.message;

import javax.sip.header.ContentTypeHeader;
import javax.sip.header.ServerHeader;
import javax.sip.header.UserAgentHeader;
import javax.sip.message.MessageFactory;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface MessageFactoryExt extends MessageFactory {
    MultipartMimeContent createMultipartMimeContent(ContentTypeHeader contentTypeHeader, String[] strArr, String[] strArr2, String[] strArr3);

    @Override // javax.sip.message.MessageFactory
    void setDefaultContentEncodingCharset(String str) throws IllegalArgumentException, NullPointerException;

    @Override // javax.sip.message.MessageFactory
    void setDefaultServerHeader(ServerHeader serverHeader);

    @Override // javax.sip.message.MessageFactory
    void setDefaultUserAgentHeader(UserAgentHeader userAgentHeader);
}
