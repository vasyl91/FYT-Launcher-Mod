package gov.nist.javax.sip.parser;

import gov.nist.javax.sip.header.ContentLength;
import gov.nist.javax.sip.header.SIPHeader;
import java.text.ParseException;
import javax.sip.InvalidArgumentException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class ContentLengthParser extends HeaderParser {
    public ContentLengthParser(String contentLength) {
        super(contentLength);
    }

    protected ContentLengthParser(Lexer lexer) {
        super(lexer);
    }

    @Override // gov.nist.javax.sip.parser.HeaderParser
    public SIPHeader parse() throws ParseException {
        if (debug) {
            dbg_enter("ContentLengthParser.enter");
        }
        try {
            try {
                try {
                    ContentLength contentLength = new ContentLength();
                    headerName(TokenTypes.CONTENT_LENGTH);
                    String number = this.lexer.number();
                    contentLength.setContentLength(Integer.parseInt(number));
                    this.lexer.SPorHT();
                    this.lexer.match(10);
                    if (debug) {
                        dbg_leave("ContentLengthParser.leave");
                    }
                    return contentLength;
                } catch (InvalidArgumentException ex) {
                    throw createParseException(ex.getMessage());
                }
            } catch (NumberFormatException ex2) {
                throw createParseException(ex2.getMessage());
            }
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("ContentLengthParser.leave");
            }
            throw th;
        }
    }
}
