package gov.nist.javax.sip.header;

import javax.sip.InvalidArgumentException;
import javax.sip.header.RSeqHeader;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class RSeq extends SIPHeader implements RSeqHeader {
    private static final long serialVersionUID = 8765762413224043394L;
    protected long sequenceNumber;

    public RSeq() {
        super("RSeq");
    }

    @Override // javax.sip.header.RSeqHeader
    public int getSequenceNumber() {
        return (int) this.sequenceNumber;
    }

    @Override // gov.nist.javax.sip.header.SIPHeader
    protected String encodeBody() {
        return Long.toString(this.sequenceNumber);
    }

    @Override // javax.sip.header.RSeqHeader
    public long getSeqNumber() {
        return this.sequenceNumber;
    }

    @Override // javax.sip.header.RSeqHeader
    public void setSeqNumber(long sequenceNumber) throws InvalidArgumentException {
        if (sequenceNumber <= 0 || sequenceNumber > 2147483648L) {
            throw new InvalidArgumentException("Bad seq number " + sequenceNumber);
        }
        this.sequenceNumber = sequenceNumber;
    }

    @Override // javax.sip.header.RSeqHeader
    public void setSequenceNumber(int sequenceNumber) throws InvalidArgumentException {
        setSeqNumber(sequenceNumber);
    }
}
