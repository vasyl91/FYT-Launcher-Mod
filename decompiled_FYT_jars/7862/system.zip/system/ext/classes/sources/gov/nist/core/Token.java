package gov.nist.core;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class Token {
    protected int tokenType;
    protected String tokenValue;

    public String getTokenValue() {
        return this.tokenValue;
    }

    public int getTokenType() {
        return this.tokenType;
    }

    public String toString() {
        return "tokenValue = " + this.tokenValue + "/tokenType = " + this.tokenType;
    }
}
