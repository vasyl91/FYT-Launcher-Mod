package gov.nist.javax.sip.header.ims;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface SecurityClientHeader extends SecurityServerHeader {
    public static final String NAME = "Security-Client";
}
