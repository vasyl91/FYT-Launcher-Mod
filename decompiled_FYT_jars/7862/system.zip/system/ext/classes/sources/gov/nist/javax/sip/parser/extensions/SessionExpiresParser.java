package gov.nist.javax.sip.parser.extensions;

import gov.nist.javax.sip.header.SIPHeader;
import gov.nist.javax.sip.header.extensions.SessionExpires;
import gov.nist.javax.sip.parser.Lexer;
import gov.nist.javax.sip.parser.ParametersParser;
import gov.nist.javax.sip.parser.TokenTypes;
import java.text.ParseException;
import javax.sip.InvalidArgumentException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class SessionExpiresParser extends ParametersParser {
    public SessionExpiresParser(String text) {
        super(text);
    }

    protected SessionExpiresParser(Lexer lexer) {
        super(lexer);
    }

    @Override // gov.nist.javax.sip.parser.HeaderParser
    public SIPHeader parse() throws ParseException {
        SessionExpires se = new SessionExpires();
        if (debug) {
            dbg_enter("parse");
        }
        try {
            headerName(TokenTypes.SESSIONEXPIRES_TO);
            String nextId = this.lexer.getNextId();
            try {
                try {
                    int delta = Integer.parseInt(nextId);
                    se.setExpires(delta);
                    this.lexer.SPorHT();
                    super.parse(se);
                    if (debug) {
                        dbg_leave("parse");
                    }
                    return se;
                } catch (InvalidArgumentException ex) {
                    throw createParseException(ex.getMessage());
                }
            } catch (NumberFormatException e) {
                throw createParseException("bad integer format");
            }
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("parse");
            }
            throw th;
        }
    }

    public static void main(String[] args) throws ParseException {
        String[] to = {"Session-Expires: 30\n", "Session-Expires: 45;refresher=uac\n"};
        for (String str : to) {
            SessionExpiresParser tp = new SessionExpiresParser(str);
            SessionExpires t = (SessionExpires) tp.parse();
            System.out.println("encoded = " + t.encode());
            System.out.println("\ntime=" + t.getExpires());
            if (t.getParameter(SessionExpires.REFRESHER) != null) {
                System.out.println("refresher=" + t.getParameter(SessionExpires.REFRESHER));
            }
        }
    }
}
