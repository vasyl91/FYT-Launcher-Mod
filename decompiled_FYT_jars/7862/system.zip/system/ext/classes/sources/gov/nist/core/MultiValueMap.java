package gov.nist.core;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface MultiValueMap<K, V> extends Map<K, List<V>>, Serializable {
}
