package gov.nist.javax.sip.header.ims;

import javax.sip.header.Header;
import javax.sip.header.HeaderAddress;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface PPreferredIdentityHeader extends HeaderAddress, Header {
    public static final String NAME = "P-Preferred-Identity";
}
