package gov.nist.core;

import java.text.ParseException;
import java.util.Hashtable;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class LexerCore extends StringTokenizer {
    public static final int ALPHA = 4099;
    static final char ALPHADIGIT_VALID_CHARS = 65533;
    static final char ALPHA_VALID_CHARS = 65535;
    public static final int AND = 38;
    public static final int AT = 64;
    public static final int BACKSLASH = 92;
    public static final int BACK_QUOTE = 96;
    public static final int BAR = 124;
    public static final int COLON = 58;
    public static final int DIGIT = 4098;
    static final char DIGIT_VALID_CHARS = 65534;
    public static final int DOLLAR = 36;
    public static final int DOT = 46;
    public static final int DOUBLEQUOTE = 34;
    public static final int END = 4096;
    public static final int EQUALS = 61;
    public static final int EXCLAMATION = 33;
    public static final int GREATER_THAN = 62;
    public static final int HAT = 94;
    public static final int HT = 9;
    public static final int ID = 4095;
    public static final int LESS_THAN = 60;
    public static final int LPAREN = 40;
    public static final int L_CURLY = 123;
    public static final int L_SQUARE_BRACKET = 91;
    public static final int MINUS = 45;
    public static final int NULL = 0;
    public static final int PERCENT = 37;
    public static final int PLUS = 43;
    public static final int POUND = 35;
    public static final int QUESTION = 63;
    public static final int QUOTE = 39;
    public static final int RPAREN = 41;
    public static final int R_CURLY = 125;
    public static final int R_SQUARE_BRACKET = 93;
    public static final int SAFE = 4094;
    public static final int SEMICOLON = 59;
    public static final int SLASH = 47;
    public static final int SP = 32;
    public static final int STAR = 42;
    public static final int START = 2048;
    public static final int TILDE = 126;
    public static final int UNDERSCORE = 95;
    public static final int WHITESPACE = 4097;
    protected static final Hashtable globalSymbolTable = new Hashtable();
    protected static final Hashtable lexerTables = new Hashtable();
    protected Hashtable currentLexer;
    protected String currentLexerName;
    protected Token currentMatch;

    protected void addKeyword(String name, int value) {
        Integer val = Integer.valueOf(value);
        this.currentLexer.put(name, val);
        if (!globalSymbolTable.containsKey(val)) {
            globalSymbolTable.put(val, name);
        }
    }

    public String lookupToken(int value) {
        if (value > 2048) {
            return (String) globalSymbolTable.get(Integer.valueOf(value));
        }
        Character ch = Character.valueOf((char) value);
        return ch.toString();
    }

    protected Hashtable addLexer(String lexerName) {
        this.currentLexer = (Hashtable) lexerTables.get(lexerName);
        if (this.currentLexer == null) {
            this.currentLexer = new Hashtable();
            lexerTables.put(lexerName, this.currentLexer);
        }
        return this.currentLexer;
    }

    public void selectLexer(String lexerName) {
        this.currentLexerName = lexerName;
    }

    protected LexerCore() {
        this.currentLexer = new Hashtable();
        this.currentLexerName = "charLexer";
    }

    public LexerCore(String lexerName, String buffer) {
        super(buffer);
        this.currentLexerName = lexerName;
    }

    public String peekNextId() {
        int oldPtr = this.ptr;
        String retval = ttoken();
        this.savedPtr = this.ptr;
        this.ptr = oldPtr;
        return retval;
    }

    public String getNextId() {
        return ttoken();
    }

    public Token getNextToken() {
        return this.currentMatch;
    }

    public Token peekNextToken() throws ParseException {
        return peekNextToken(1)[0];
    }

    public Token[] peekNextToken(int ntokens) throws ParseException {
        int old = this.ptr;
        Token[] retval = new Token[ntokens];
        for (int i = 0; i < ntokens; i++) {
            Token tok = new Token();
            if (startsId()) {
                String id = ttoken();
                tok.tokenValue = id;
                String idUppercase = id.toUpperCase();
                if (this.currentLexer.containsKey(idUppercase)) {
                    Integer type = (Integer) this.currentLexer.get(idUppercase);
                    tok.tokenType = type.intValue();
                } else {
                    tok.tokenType = 4095;
                }
            } else {
                char nextChar = getNextChar();
                tok.tokenValue = String.valueOf(nextChar);
                if (isAlpha(nextChar)) {
                    tok.tokenType = 4099;
                } else if (isDigit(nextChar)) {
                    tok.tokenType = 4098;
                } else {
                    tok.tokenType = nextChar;
                }
            }
            retval[i] = tok;
        }
        int i2 = this.ptr;
        this.savedPtr = i2;
        this.ptr = old;
        return retval;
    }

    public Token match(int tok) throws ParseException {
        if (Debug.parserDebug) {
            Debug.println("match " + tok);
        }
        if (tok <= 2048 || tok >= 4096) {
            if (tok > 4096) {
                char next = lookAhead(0);
                if (tok == 4098) {
                    if (!isDigit(next)) {
                        throw new ParseException(this.buffer + "\nExpecting DIGIT", this.ptr);
                    }
                    this.currentMatch = new Token();
                    this.currentMatch.tokenValue = String.valueOf(next);
                    this.currentMatch.tokenType = tok;
                    consume(1);
                } else if (tok == 4099) {
                    if (!isAlpha(next)) {
                        throw new ParseException(this.buffer + "\nExpecting ALPHA", this.ptr);
                    }
                    this.currentMatch = new Token();
                    this.currentMatch.tokenValue = String.valueOf(next);
                    this.currentMatch.tokenType = tok;
                    consume(1);
                }
            } else {
                char ch = (char) tok;
                char next2 = lookAhead(0);
                if (next2 == ch) {
                    consume(1);
                } else {
                    throw new ParseException(this.buffer + "\nExpecting  >>>" + ch + "<<< got >>>" + next2 + "<<<", this.ptr);
                }
            }
        } else if (tok == 4095) {
            if (!startsId()) {
                throw new ParseException(this.buffer + "\nID expected", this.ptr);
            }
            String id = getNextId();
            this.currentMatch = new Token();
            Token token = this.currentMatch;
            token.tokenValue = id;
            token.tokenType = 4095;
        } else if (tok == 4094) {
            if (!startsSafeToken()) {
                throw new ParseException(this.buffer + "\nID expected", this.ptr);
            }
            String id2 = ttokenSafe();
            this.currentMatch = new Token();
            Token token2 = this.currentMatch;
            token2.tokenValue = id2;
            token2.tokenType = SAFE;
        } else {
            String nexttok = getNextId();
            Integer cur = (Integer) this.currentLexer.get(nexttok.toUpperCase());
            if (cur == null || cur.intValue() != tok) {
                throw new ParseException(this.buffer + "\nUnexpected Token : " + nexttok, this.ptr);
            }
            this.currentMatch = new Token();
            Token token3 = this.currentMatch;
            token3.tokenValue = nexttok;
            token3.tokenType = tok;
        }
        return this.currentMatch;
    }

    public void SPorHT() {
        try {
            char c = lookAhead(0);
            while (true) {
                if (c != ' ' && c != '\t') {
                    return;
                }
                consume(1);
                c = lookAhead(0);
            }
        } catch (ParseException e) {
        }
    }

    public static final boolean isTokenChar(char c) {
        return isAlphaDigit(c) || c == '!' || c == '%' || c == '\'' || c == '~' || c == '*' || c == '+' || c == '-' || c == '.' || c == '_' || c == '`';
    }

    public boolean startsId() {
        try {
            char nextChar = lookAhead(0);
            return isTokenChar(nextChar);
        } catch (ParseException e) {
            return false;
        }
    }

    /* JADX WARN: Code duplicated, block: B:30:0x003e A[FALL_THROUGH, RETURN] */
    public boolean startsSafeToken() {
        try {
            char nextChar = lookAhead(0);
            if (!isAlphaDigit(nextChar) && nextChar != '\'' && nextChar != '=' && nextChar != '[' && nextChar != '*' && nextChar != '+' && nextChar != ':' && nextChar != ';' && nextChar != '?' && nextChar != '@') {
                switch (nextChar) {
                    default:
                        switch (nextChar) {
                            default:
                                switch (nextChar) {
                                    default:
                                        switch (nextChar) {
                                            case '{':
                                            case '|':
                                            case '}':
                                            case '~':
                                                break;
                                            default:
                                                return false;
                                        }
                                    case ']':
                                    case '^':
                                    case '_':
                                    case '`':
                                        return true;
                                }
                            case '-':
                            case '.':
                            case '/':
                                return true;
                        }
                    case '!':
                    case '\"':
                    case '#':
                    case '$':
                    case '%':
                        return true;
                }
            }
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    public String ttoken() {
        int startIdx = this.ptr;
        while (hasMoreChars()) {
            try {
                char nextChar = lookAhead(0);
                if (!isTokenChar(nextChar)) {
                    break;
                }
                consume(1);
            } catch (ParseException e) {
                return null;
            }
        }
        return this.buffer.substring(startIdx, this.ptr);
    }

    /* JADX WARN: Code duplicated, block: B:29:0x0046 A[FALL_THROUGH] */
    /*  JADX ERROR: UnsupportedOperationException in pass: RegionMakerVisitor
        java.lang.UnsupportedOperationException
        	at java.base/java.util.Collections$UnmodifiableCollection.add(Collections.java:1092)
        	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker$1.leaveRegion(SwitchRegionMaker.java:419)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseInternal(DepthRegionTraversal.java:91)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverse(DepthRegionTraversal.java:31)
        	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker.insertBreaksForCase(SwitchRegionMaker.java:399)
        	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker.insertBreaks(SwitchRegionMaker.java:89)
        	at jadx.core.dex.visitors.regions.PostProcessRegions.leaveRegion(PostProcessRegions.java:31)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseInternal(DepthRegionTraversal.java:91)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverse(DepthRegionTraversal.java:27)
        	at jadx.core.dex.visitors.regions.PostProcessRegions.process(PostProcessRegions.java:21)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:31)
        */
    public java.lang.String ttokenSafe() {
        /*
            r5 = this;
            int r0 = r5.ptr
        L2:
            boolean r1 = r5.hasMoreChars()     // Catch: java.text.ParseException -> L56
            if (r1 == 0) goto L4d
            r1 = 0
            char r1 = r5.lookAhead(r1)     // Catch: java.text.ParseException -> L56
            boolean r2 = isAlphaDigit(r1)     // Catch: java.text.ParseException -> L56
            r3 = 1
            if (r2 == 0) goto L18
            r5.consume(r3)     // Catch: java.text.ParseException -> L56
            goto L4c
        L18:
            r2 = 0
            r4 = 39
            if (r1 == r4) goto L46
            r4 = 91
            if (r1 == r4) goto L46
            r4 = 42
            if (r1 == r4) goto L46
            r4 = 43
            if (r1 == r4) goto L46
            r4 = 58
            if (r1 == r4) goto L46
            r4 = 59
            if (r1 == r4) goto L46
            r4 = 63
            if (r1 == r4) goto L46
            r4 = 64
            if (r1 == r4) goto L46
            switch(r1) {
                case 33: goto L46;
                case 34: goto L46;
                case 35: goto L46;
                case 36: goto L46;
                case 37: goto L46;
                default: goto L3c;
            }     // Catch: java.text.ParseException -> L56
        L3c:
            switch(r1) {
                case 45: goto L46;
                case 46: goto L46;
                case 47: goto L46;
                default: goto L3f;
            }     // Catch: java.text.ParseException -> L56
        L3f:
            switch(r1) {
                case 93: goto L46;
                case 94: goto L46;
                case 95: goto L46;
                case 96: goto L46;
                default: goto L42;
            }     // Catch: java.text.ParseException -> L56
        L42:
            switch(r1) {
                case 123: goto L46;
                case 124: goto L46;
                case 125: goto L46;
                case 126: goto L46;
                default: goto L45;
            }     // Catch: java.text.ParseException -> L56
        L45:
            goto L47
        L46:
            r2 = 1
        L47:
            if (r2 == 0) goto L4d
            r5.consume(r3)     // Catch: java.text.ParseException -> L56
        L4c:
            goto L2
        L4d:
            java.lang.String r1 = r5.buffer     // Catch: java.text.ParseException -> L56
            int r2 = r5.ptr     // Catch: java.text.ParseException -> L56
            java.lang.String r1 = r1.substring(r0, r2)     // Catch: java.text.ParseException -> L56
            return r1
        L56:
            r1 = move-exception
            r2 = 0
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: gov.nist.core.LexerCore.ttokenSafe():java.lang.String");
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0036 A[Catch: ParseException -> 0x003b, LOOP:0: B:26:0x0001->B:21:0x0036, LOOP_END, TRY_LEAVE, TryCatch #0 {ParseException -> 0x003b, blocks: (B:3:0x0001, B:5:0x0007, B:8:0x0011, B:9:0x0013, B:19:0x0031, B:12:0x001a, B:13:0x0020, B:14:0x0026, B:21:0x0036), top: B:26:0x0001 }] */
    /* JADX WARN: Code duplicated, block: B:29:0x003c A[SYNTHETIC] */
    public void consumeValidChars(char[] validChars) {
        int validCharsLength = validChars.length;
        while (hasMoreChars()) {
            try {
                char nextChar = lookAhead(0);
                boolean isValid = false;
                for (int i = 0; i < validCharsLength; i++) {
                    char validChar = validChars[i];
                    switch (validChar) {
                        case 65533:
                            isValid = isAlphaDigit(nextChar);
                            break;
                        case 65534:
                            isValid = isDigit(nextChar);
                            break;
                        case 65535:
                            isValid = isAlpha(nextChar);
                            break;
                        default:
                            isValid = nextChar == validChar;
                            break;
                    }
                    if (isValid) {
                        if (isValid) {
                            consume(1);
                        } else {
                            return;
                        }
                    }
                }
                if (isValid) {
                    consume(1);
                } else {
                    return;
                }
            } catch (ParseException e) {
                return;
            }
        }
    }

    public String quotedString() throws ParseException {
        int startIdx = this.ptr + 1;
        if (lookAhead(0) != '\"') {
            return null;
        }
        consume(1);
        while (true) {
            char next = getNextChar();
            if (next != '\"') {
                if (next == 0) {
                    throw new ParseException(this.buffer + " :unexpected EOL", this.ptr);
                }
                if (next == '\\') {
                    consume(1);
                }
            } else {
                return this.buffer.substring(startIdx, this.ptr - 1);
            }
        }
    }

    public String comment() throws ParseException {
        StringBuffer retval = new StringBuffer();
        if (lookAhead(0) != '(') {
            return null;
        }
        consume(1);
        while (true) {
            char next = getNextChar();
            if (next != ')') {
                if (next == 0) {
                    throw new ParseException(this.buffer + " :unexpected EOL", this.ptr);
                }
                if (next == '\\') {
                    retval.append(next);
                    char next2 = getNextChar();
                    if (next2 == 0) {
                        throw new ParseException(this.buffer + " : unexpected EOL", this.ptr);
                    }
                    retval.append(next2);
                } else {
                    retval.append(next);
                }
            } else {
                return retval.toString();
            }
        }
    }

    public String byteStringNoSemicolon() {
        StringBuffer retval = new StringBuffer();
        while (true) {
            try {
                char next = lookAhead(0);
                if (next == 0 || next == '\n' || next == ';' || next == ',') {
                    break;
                    break;
                    break;
                    break;
                }
                consume(1);
                retval.append(next);
            } catch (ParseException e) {
                return retval.toString();
            }
        }
        return retval.toString();
    }

    public String byteStringNoSlash() {
        StringBuffer retval = new StringBuffer();
        while (true) {
            try {
                char next = lookAhead(0);
                if (next == 0 || next == '\n' || next == '/') {
                    break;
                    break;
                    break;
                }
                consume(1);
                retval.append(next);
            } catch (ParseException e) {
                return retval.toString();
            }
        }
        return retval.toString();
    }

    public String byteStringNoComma() {
        StringBuffer retval = new StringBuffer();
        while (true) {
            try {
                char next = lookAhead(0);
                if (next == '\n' || next == ',') {
                    break;
                    break;
                }
                consume(1);
                retval.append(next);
            } catch (ParseException e) {
            }
        }
        return retval.toString();
    }

    public static String charAsString(char ch) {
        return String.valueOf(ch);
    }

    public String charAsString(int nchars) {
        return this.buffer.substring(this.ptr, this.ptr + nchars);
    }

    public String number() throws ParseException {
        int startIdx = this.ptr;
        try {
            if (!isDigit(lookAhead(0))) {
                throw new ParseException(this.buffer + ": Unexpected token at " + lookAhead(0), this.ptr);
            }
            consume(1);
            while (isDigit(next)) {
                consume(1);
            }
            return this.buffer.substring(startIdx, this.ptr);
        } catch (ParseException e) {
            return this.buffer.substring(startIdx, this.ptr);
        }
    }

    public int markInputPosition() {
        return this.ptr;
    }

    public void rewindInputPosition(int position) {
        this.ptr = position;
    }

    public String getRest() {
        if (this.ptr >= this.buffer.length()) {
            return null;
        }
        return this.buffer.substring(this.ptr);
    }

    public String getString(char c) throws ParseException {
        StringBuffer retval = new StringBuffer();
        while (true) {
            char next = lookAhead(0);
            if (next == 0) {
                throw new ParseException(this.buffer + "unexpected EOL", this.ptr);
            }
            if (next == c) {
                consume(1);
                return retval.toString();
            }
            if (next == '\\') {
                consume(1);
                char nextchar = lookAhead(0);
                if (nextchar == 0) {
                    throw new ParseException(this.buffer + "unexpected EOL", this.ptr);
                }
                consume(1);
                retval.append(nextchar);
            } else {
                consume(1);
                retval.append(next);
            }
        }
    }

    public int getPtr() {
        return this.ptr;
    }

    public String getBuffer() {
        return this.buffer;
    }

    public ParseException createParseException() {
        return new ParseException(this.buffer, this.ptr);
    }
}
