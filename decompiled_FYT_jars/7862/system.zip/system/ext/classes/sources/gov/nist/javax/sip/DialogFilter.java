package gov.nist.javax.sip;

import gov.nist.core.InternalErrorHandler;
import gov.nist.core.Separators;
import gov.nist.javax.sip.address.ParameterNames;
import gov.nist.javax.sip.address.SipUri;
import gov.nist.javax.sip.header.Contact;
import gov.nist.javax.sip.header.Event;
import gov.nist.javax.sip.header.RetryAfter;
import gov.nist.javax.sip.header.Route;
import gov.nist.javax.sip.header.RouteList;
import gov.nist.javax.sip.message.MessageFactoryImpl;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;
import gov.nist.javax.sip.stack.MessageChannel;
import gov.nist.javax.sip.stack.SIPClientTransaction;
import gov.nist.javax.sip.stack.SIPDialog;
import gov.nist.javax.sip.stack.SIPServerTransaction;
import gov.nist.javax.sip.stack.SIPTransaction;
import gov.nist.javax.sip.stack.ServerRequestInterface;
import gov.nist.javax.sip.stack.ServerResponseInterface;
import java.io.IOException;
import java.util.EventObject;
import javax.sip.ClientTransaction;
import javax.sip.DialogState;
import javax.sip.ListeningPoint;
import javax.sip.RequestEvent;
import javax.sip.ServerTransaction;
import javax.sip.SipException;
import javax.sip.TransactionState;
import javax.sip.header.CSeqHeader;
import javax.sip.header.ReferToHeader;
import javax.sip.header.ServerHeader;
import javax.sip.message.Request;
import javax.sip.message.Response;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
class DialogFilter implements ServerRequestInterface, ServerResponseInterface {
    protected ListeningPointImpl listeningPoint;
    private SipStackImpl sipStack;
    protected SIPTransaction transactionChannel;

    public DialogFilter(SipStackImpl sipStack) {
        this.sipStack = sipStack;
    }

    private void sendRequestPendingResponse(SIPRequest sipRequest, SIPServerTransaction transaction) {
        SIPResponse sipResponse = sipRequest.createResponse(Response.REQUEST_PENDING);
        ServerHeader serverHeader = MessageFactoryImpl.getDefaultServerHeader();
        if (serverHeader != null) {
            sipResponse.setHeader(serverHeader);
        }
        try {
            RetryAfter retryAfter = new RetryAfter();
            retryAfter.setRetryAfter(1);
            sipResponse.setHeader(retryAfter);
            if (sipRequest.getMethod().equals("INVITE")) {
                this.sipStack.addTransactionPendingAck(transaction);
            }
            transaction.sendResponse((Response) sipResponse);
            transaction.releaseSem();
        } catch (Exception ex) {
            this.sipStack.getStackLogger().logError("Problem sending error response", ex);
            transaction.releaseSem();
            this.sipStack.removeTransaction(transaction);
        }
    }

    private void sendBadRequestResponse(SIPRequest sipRequest, SIPServerTransaction transaction, String reasonPhrase) {
        SIPResponse sipResponse = sipRequest.createResponse(Response.BAD_REQUEST);
        if (reasonPhrase != null) {
            sipResponse.setReasonPhrase(reasonPhrase);
        }
        ServerHeader serverHeader = MessageFactoryImpl.getDefaultServerHeader();
        if (serverHeader != null) {
            sipResponse.setHeader(serverHeader);
        }
        try {
            if (sipRequest.getMethod().equals("INVITE")) {
                this.sipStack.addTransactionPendingAck(transaction);
            }
            transaction.sendResponse((Response) sipResponse);
            transaction.releaseSem();
        } catch (Exception ex) {
            this.sipStack.getStackLogger().logError("Problem sending error response", ex);
            transaction.releaseSem();
            this.sipStack.removeTransaction(transaction);
        }
    }

    private void sendCallOrTransactionDoesNotExistResponse(SIPRequest sipRequest, SIPServerTransaction transaction) {
        SIPResponse sipResponse = sipRequest.createResponse(Response.CALL_OR_TRANSACTION_DOES_NOT_EXIST);
        ServerHeader serverHeader = MessageFactoryImpl.getDefaultServerHeader();
        if (serverHeader != null) {
            sipResponse.setHeader(serverHeader);
        }
        try {
            if (sipRequest.getMethod().equals("INVITE")) {
                this.sipStack.addTransactionPendingAck(transaction);
            }
            transaction.sendResponse((Response) sipResponse);
            transaction.releaseSem();
        } catch (Exception ex) {
            this.sipStack.getStackLogger().logError("Problem sending error response", ex);
            transaction.releaseSem();
            this.sipStack.removeTransaction(transaction);
        }
    }

    private void sendLoopDetectedResponse(SIPRequest sipRequest, SIPServerTransaction transaction) {
        SIPResponse sipResponse = sipRequest.createResponse(Response.LOOP_DETECTED);
        ServerHeader serverHeader = MessageFactoryImpl.getDefaultServerHeader();
        if (serverHeader != null) {
            sipResponse.setHeader(serverHeader);
        }
        try {
            this.sipStack.addTransactionPendingAck(transaction);
            transaction.sendResponse((Response) sipResponse);
            transaction.releaseSem();
        } catch (Exception ex) {
            this.sipStack.getStackLogger().logError("Problem sending error response", ex);
            transaction.releaseSem();
            this.sipStack.removeTransaction(transaction);
        }
    }

    private void sendServerInternalErrorResponse(SIPRequest sipRequest, SIPServerTransaction transaction) {
        if (this.sipStack.isLoggingEnabled()) {
            this.sipStack.getStackLogger().logDebug("Sending 500 response for out of sequence message");
        }
        SIPResponse sipResponse = sipRequest.createResponse(500);
        sipResponse.setReasonPhrase("Request out of order");
        if (MessageFactoryImpl.getDefaultServerHeader() != null) {
            ServerHeader serverHeader = MessageFactoryImpl.getDefaultServerHeader();
            sipResponse.setHeader(serverHeader);
        }
        try {
            RetryAfter retryAfter = new RetryAfter();
            retryAfter.setRetryAfter(10);
            sipResponse.setHeader(retryAfter);
            this.sipStack.addTransactionPendingAck(transaction);
            transaction.sendResponse((Response) sipResponse);
            transaction.releaseSem();
        } catch (Exception ex) {
            this.sipStack.getStackLogger().logError("Problem sending response", ex);
            transaction.releaseSem();
            this.sipStack.removeTransaction(transaction);
        }
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // gov.nist.javax.sip.stack.ServerRequestInterface
    public void processRequest(SIPRequest sIPRequest, MessageChannel messageChannel) {
        Object obj;
        EventObject requestEvent;
        Object obj2;
        int port;
        Contact myContactHeader;
        if (this.sipStack.isLoggingEnabled()) {
            this.sipStack.getStackLogger().logDebug("PROCESSING INCOMING REQUEST " + sIPRequest + " transactionChannel = " + this.transactionChannel + " listening point = " + this.listeningPoint.getIPAddress() + Separators.COLON + this.listeningPoint.getPort());
        }
        if (this.listeningPoint == null) {
            if (this.sipStack.isLoggingEnabled()) {
                this.sipStack.getStackLogger().logDebug("Dropping message: No listening point registered!");
                return;
            }
            return;
        }
        SipStackImpl sipStackImpl = (SipStackImpl) this.transactionChannel.getSIPStack();
        SipProviderImpl provider = this.listeningPoint.getProvider();
        if (provider == null) {
            if (sipStackImpl.isLoggingEnabled()) {
                sipStackImpl.getStackLogger().logDebug("No provider - dropping !!");
                return;
            }
            return;
        }
        if (sipStackImpl == null) {
            InternalErrorHandler.handleException("Egads! no sip stack!");
        }
        SIPServerTransaction sIPServerTransaction = (SIPServerTransaction) this.transactionChannel;
        if (sIPServerTransaction != null && sipStackImpl.isLoggingEnabled()) {
            sipStackImpl.getStackLogger().logDebug("transaction state = " + sIPServerTransaction.getState());
        }
        String dialogId = sIPRequest.getDialogId(true);
        SIPDialog dialog = sipStackImpl.getDialog(dialogId);
        if (dialog != null && provider != dialog.getSipProvider() && (myContactHeader = dialog.getMyContactHeader()) != null) {
            SipUri sipUri = (SipUri) myContactHeader.getAddress().getURI();
            String host = sipUri.getHost();
            int port2 = sipUri.getPort();
            String transportParam = sipUri.getTransportParam();
            if (transportParam == null) {
                transportParam = ParameterNames.UDP;
            }
            if (port2 == -1) {
                if (transportParam.equals(ParameterNames.UDP) || transportParam.equals(ParameterNames.TCP)) {
                    port2 = 5060;
                } else {
                    port2 = 5061;
                }
            }
            if (host != null && (!host.equals(this.listeningPoint.getIPAddress()) || port2 != this.listeningPoint.getPort())) {
                if (sipStackImpl.isLoggingEnabled()) {
                    sipStackImpl.getStackLogger().logDebug("nulling dialog -- listening point mismatch!  " + port2 + "  lp port = " + this.listeningPoint.getPort());
                }
                dialog = null;
            }
        }
        if (provider.isAutomaticDialogSupportEnabled() && provider.isDialogErrorsAutomaticallyHandled() && sIPRequest.getToTag() == null && sipStackImpl.findMergedTransaction(sIPRequest) != null) {
            sendLoopDetectedResponse(sIPRequest, sIPServerTransaction);
            return;
        }
        if (sipStackImpl.isLoggingEnabled()) {
            sipStackImpl.getStackLogger().logDebug("dialogId = " + dialogId);
            sipStackImpl.getStackLogger().logDebug("dialog = " + dialog);
        }
        if (sIPRequest.getHeader("Route") != null && sIPServerTransaction.getDialog() != null) {
            RouteList routeHeaders = sIPRequest.getRouteHeaders();
            SipUri sipUri2 = (SipUri) ((Route) routeHeaders.getFirst()).getAddress().getURI();
            if (sipUri2.getHostPort().hasPort()) {
                port = sipUri2.getHostPort().getPort();
            } else if (this.listeningPoint.getTransport().equalsIgnoreCase(ListeningPoint.TLS)) {
                port = 5061;
            } else {
                port = 5060;
            }
            String host2 = sipUri2.getHost();
            if ((host2.equals(this.listeningPoint.getIPAddress()) || host2.equalsIgnoreCase(this.listeningPoint.getSentBy())) && port == this.listeningPoint.getPort()) {
                if (routeHeaders.size() == 1) {
                    sIPRequest.removeHeader("Route");
                } else {
                    routeHeaders.removeFirst();
                }
            }
        }
        String str = "ACK";
        if (sIPRequest.getMethod().equals(Request.REFER) && dialog != null && provider.isDialogErrorsAutomaticallyHandled()) {
            if (((ReferToHeader) sIPRequest.getHeader(ReferToHeader.NAME)) == null) {
                sendBadRequestResponse(sIPRequest, sIPServerTransaction, "Refer-To header is missing");
                return;
            }
            SIPTransaction lastTransaction = dialog.getLastTransaction();
            if (lastTransaction == null || !provider.isDialogErrorsAutomaticallyHandled()) {
                obj2 = Request.CANCEL;
            } else {
                SIPRequest sIPRequest2 = (SIPRequest) lastTransaction.getRequest();
                if (lastTransaction instanceof SIPServerTransaction) {
                    if (dialog.isAckSeen() || !sIPRequest2.getMethod().equals("INVITE")) {
                        obj2 = Request.CANCEL;
                    } else {
                        sendRequestPendingResponse(sIPRequest, sIPServerTransaction);
                        return;
                    }
                } else if (lastTransaction instanceof SIPClientTransaction) {
                    CSeqHeader cSeqHeader = sIPRequest2.getCSeqHeader();
                    obj2 = Request.CANCEL;
                    long seqNumber = cSeqHeader.getSeqNumber();
                    if (sIPRequest2.getMethod().equals("INVITE") && !dialog.isAckSent(seqNumber)) {
                        sendRequestPendingResponse(sIPRequest, sIPServerTransaction);
                        return;
                    }
                } else {
                    obj2 = Request.CANCEL;
                }
            }
            str = "ACK";
            obj = obj2;
        } else if (sIPRequest.getMethod().equals(Request.UPDATE)) {
            if (!provider.isAutomaticDialogSupportEnabled() || dialog != null) {
                str = "ACK";
                obj = Request.CANCEL;
            } else {
                sendCallOrTransactionDoesNotExistResponse(sIPRequest, sIPServerTransaction);
                return;
            }
        } else if (sIPRequest.getMethod().equals("ACK")) {
            if (sIPServerTransaction != null && sIPServerTransaction.isInviteTransaction()) {
                if (!sipStackImpl.isLoggingEnabled()) {
                    str = "ACK";
                    obj = r13;
                } else {
                    sipStackImpl.getStackLogger().logDebug("Processing ACK for INVITE Tx ");
                    str = "ACK";
                    obj = r13;
                }
            } else {
                if (sipStackImpl.isLoggingEnabled()) {
                    sipStackImpl.getStackLogger().logDebug("Processing ACK for dialog " + dialog);
                }
                if (dialog == null) {
                    if (sipStackImpl.isLoggingEnabled()) {
                        sipStackImpl.getStackLogger().logDebug("Dialog does not exist " + sIPRequest.getFirstLine() + " isServerTransaction = true");
                    }
                    SIPServerTransaction retransmissionAlertTransaction = sipStackImpl.getRetransmissionAlertTransaction(dialogId);
                    if (retransmissionAlertTransaction != null && retransmissionAlertTransaction.isRetransmissionAlertEnabled()) {
                        retransmissionAlertTransaction.disableRetransmissionAlerts();
                    }
                    SIPServerTransaction sIPServerTransactionFindTransactionPendingAck = sipStackImpl.findTransactionPendingAck(sIPRequest);
                    if (sIPServerTransactionFindTransactionPendingAck != null) {
                        if (sipStackImpl.isLoggingEnabled()) {
                            sipStackImpl.getStackLogger().logDebug("Found Tx pending ACK");
                        }
                        try {
                            sIPServerTransactionFindTransactionPendingAck.setAckSeen();
                            sipStackImpl.removeTransaction(sIPServerTransactionFindTransactionPendingAck);
                            sipStackImpl.removeTransactionPendingAck(sIPServerTransactionFindTransactionPendingAck);
                            return;
                        } catch (Exception e) {
                            if (sipStackImpl.isLoggingEnabled()) {
                                sipStackImpl.getStackLogger().logError("Problem terminating transaction", e);
                                return;
                            }
                            return;
                        }
                    }
                    obj = r13;
                } else if (!dialog.handleAck(sIPServerTransaction)) {
                    if (!dialog.isSequnceNumberValidation()) {
                        if (sipStackImpl.isLoggingEnabled()) {
                            sipStackImpl.getStackLogger().logDebug("Dialog exists with loose dialog validation " + sIPRequest.getFirstLine() + " isServerTransaction = true dialog = " + dialog.getDialogId());
                        }
                        SIPServerTransaction retransmissionAlertTransaction2 = sipStackImpl.getRetransmissionAlertTransaction(dialogId);
                        if (retransmissionAlertTransaction2 != null && retransmissionAlertTransaction2.isRetransmissionAlertEnabled()) {
                            retransmissionAlertTransaction2.disableRetransmissionAlerts();
                        }
                        obj = r13;
                    } else {
                        if (sipStackImpl.isLoggingEnabled()) {
                            sipStackImpl.getStackLogger().logDebug("Dropping ACK - cannot find a transaction or dialog");
                        }
                        SIPServerTransaction sIPServerTransactionFindTransactionPendingAck2 = sipStackImpl.findTransactionPendingAck(sIPRequest);
                        if (sIPServerTransactionFindTransactionPendingAck2 != null) {
                            if (sipStackImpl.isLoggingEnabled()) {
                                sipStackImpl.getStackLogger().logDebug("Found Tx pending ACK");
                            }
                            try {
                                sIPServerTransactionFindTransactionPendingAck2.setAckSeen();
                                sipStackImpl.removeTransaction(sIPServerTransactionFindTransactionPendingAck2);
                                sipStackImpl.removeTransactionPendingAck(sIPServerTransactionFindTransactionPendingAck2);
                                return;
                            } catch (Exception e2) {
                                if (sipStackImpl.isLoggingEnabled()) {
                                    sipStackImpl.getStackLogger().logError("Problem terminating transaction", e2);
                                    return;
                                }
                                return;
                            }
                        }
                        return;
                    }
                } else {
                    sIPServerTransaction.passToListener();
                    dialog.addTransaction(sIPServerTransaction);
                    dialog.addRoute(sIPRequest);
                    sIPServerTransaction.setDialog(dialog, dialogId);
                    if (sIPRequest.getMethod().equals("INVITE") && provider.isDialogErrorsAutomaticallyHandled()) {
                        sipStackImpl.putInMergeTable(sIPServerTransaction, sIPRequest);
                    }
                    if (sipStackImpl.deliverTerminatedEventForAck) {
                        try {
                            sipStackImpl.addTransaction(sIPServerTransaction);
                            sIPServerTransaction.scheduleAckRemoval();
                        } catch (IOException e3) {
                        }
                        obj = r13;
                    } else {
                        sIPServerTransaction.setMapped(true);
                        obj = r13;
                    }
                }
            }
        } else {
            str = "ACK";
            if (sIPRequest.getMethod().equals(Request.PRACK)) {
                if (sipStackImpl.isLoggingEnabled()) {
                    sipStackImpl.getStackLogger().logDebug("Processing PRACK for dialog " + dialog);
                }
                if (dialog == null && provider.isAutomaticDialogSupportEnabled()) {
                    if (sipStackImpl.isLoggingEnabled()) {
                        sipStackImpl.getStackLogger().logDebug("Dialog does not exist " + sIPRequest.getFirstLine() + " isServerTransaction = true");
                    }
                    if (sipStackImpl.isLoggingEnabled()) {
                        sipStackImpl.getStackLogger().logDebug("Sending 481 for PRACK - automatic dialog support is enabled -- cant find dialog!");
                    }
                    try {
                        provider.sendResponse(sIPRequest.createResponse(Response.CALL_OR_TRANSACTION_DOES_NOT_EXIST));
                    } catch (SipException e4) {
                        sipStackImpl.getStackLogger().logError("error sending response", e4);
                    }
                    if (sIPServerTransaction != null) {
                        sipStackImpl.removeTransaction(sIPServerTransaction);
                        sIPServerTransaction.releaseSem();
                        return;
                    }
                    return;
                }
                if (dialog != null) {
                    if (!dialog.handlePrack(sIPRequest)) {
                        if (sipStackImpl.isLoggingEnabled()) {
                            sipStackImpl.getStackLogger().logDebug("Dropping out of sequence PRACK ");
                        }
                        if (sIPServerTransaction != null) {
                            sipStackImpl.removeTransaction(sIPServerTransaction);
                            sIPServerTransaction.releaseSem();
                            return;
                        }
                        return;
                    }
                    try {
                        sipStackImpl.addTransaction(sIPServerTransaction);
                        dialog.addTransaction(sIPServerTransaction);
                        dialog.addRoute(sIPRequest);
                        sIPServerTransaction.setDialog(dialog, dialogId);
                    } catch (Exception e5) {
                        InternalErrorHandler.handleException(e5);
                    }
                    obj = r13;
                } else if (!sipStackImpl.isLoggingEnabled()) {
                    obj = r13;
                } else {
                    sipStackImpl.getStackLogger().logDebug("Processing PRACK without a DIALOG -- this must be a proxy element");
                    obj = r13;
                }
            } else if (sIPRequest.getMethod().equals("BYE")) {
                if (dialog != null && !dialog.isRequestConsumable(sIPRequest)) {
                    if (sipStackImpl.isLoggingEnabled()) {
                        sipStackImpl.getStackLogger().logDebug("Dropping out of sequence BYE " + dialog.getRemoteSeqNumber() + Separators.SP + sIPRequest.getCSeq().getSeqNumber());
                    }
                    if (dialog.getRemoteSeqNumber() >= sIPRequest.getCSeq().getSeqNumber() && sIPServerTransaction.getState() == TransactionState.TRYING) {
                        sendServerInternalErrorResponse(sIPRequest, sIPServerTransaction);
                    }
                    if (sIPServerTransaction != null) {
                        sipStackImpl.removeTransaction(sIPServerTransaction);
                        return;
                    }
                    return;
                }
                if (dialog == null && provider.isAutomaticDialogSupportEnabled()) {
                    Response responseCreateResponse = sIPRequest.createResponse(Response.CALL_OR_TRANSACTION_DOES_NOT_EXIST);
                    responseCreateResponse.setReasonPhrase("Dialog Not Found");
                    if (sipStackImpl.isLoggingEnabled()) {
                        sipStackImpl.getStackLogger().logDebug("dropping request -- automatic dialog support enabled and dialog does not exist!");
                    }
                    try {
                        sIPServerTransaction.sendResponse(responseCreateResponse);
                    } catch (SipException e6) {
                        sipStackImpl.getStackLogger().logError("Error in sending response", e6);
                    }
                    if (sIPServerTransaction != null) {
                        sipStackImpl.removeTransaction(sIPServerTransaction);
                        sIPServerTransaction.releaseSem();
                        return;
                    }
                    return;
                }
                if (sIPServerTransaction != null && dialog != null) {
                    try {
                        if (provider == dialog.getSipProvider()) {
                            sipStackImpl.addTransaction(sIPServerTransaction);
                            dialog.addTransaction(sIPServerTransaction);
                            sIPServerTransaction.setDialog(dialog, dialogId);
                        }
                    } catch (IOException e7) {
                        InternalErrorHandler.handleException(e7);
                    }
                }
                if (!sipStackImpl.isLoggingEnabled()) {
                    obj = r13;
                } else {
                    sipStackImpl.getStackLogger().logDebug("BYE Tx = " + sIPServerTransaction + " isMapped =" + sIPServerTransaction.isTransactionMapped());
                    obj = r13;
                }
            } else {
                obj = r13;
                if (sIPRequest.getMethod().equals(obj)) {
                    SIPServerTransaction sIPServerTransaction2 = (SIPServerTransaction) sipStackImpl.findCancelTransaction(sIPRequest, true);
                    if (sipStackImpl.isLoggingEnabled()) {
                        sipStackImpl.getStackLogger().logDebug("Got a CANCEL, InviteServerTx = " + sIPServerTransaction2 + " cancel Server Tx ID = " + sIPServerTransaction + " isMapped = " + sIPServerTransaction.isTransactionMapped());
                    }
                    if (sIPRequest.getMethod().equals(obj)) {
                        if (sIPServerTransaction2 != null && sIPServerTransaction2.getState() == SIPTransaction.TERMINATED_STATE) {
                            if (sipStackImpl.isLoggingEnabled()) {
                                sipStackImpl.getStackLogger().logDebug("Too late to cancel Transaction");
                            }
                            try {
                                sIPServerTransaction.sendResponse(sIPRequest.createResponse(Response.OK));
                                return;
                            } catch (Exception e8) {
                                if (e8.getCause() != null && (e8.getCause() instanceof IOException)) {
                                    sIPServerTransaction2.raiseIOExceptionEvent();
                                    return;
                                }
                                return;
                            }
                        }
                        if (sipStackImpl.isLoggingEnabled()) {
                            sipStackImpl.getStackLogger().logDebug("Cancel transaction = " + sIPServerTransaction2);
                        }
                    }
                    if (sIPServerTransaction != null && sIPServerTransaction2 != null && sIPServerTransaction2.getDialog() != null) {
                        sIPServerTransaction.setDialog((SIPDialog) sIPServerTransaction2.getDialog(), dialogId);
                        dialog = (SIPDialog) sIPServerTransaction2.getDialog();
                    } else if (sIPServerTransaction2 == null && provider.isAutomaticDialogSupportEnabled() && sIPServerTransaction != null) {
                        Response responseCreateResponse2 = sIPRequest.createResponse(Response.CALL_OR_TRANSACTION_DOES_NOT_EXIST);
                        if (sipStackImpl.isLoggingEnabled()) {
                            sipStackImpl.getStackLogger().logDebug("dropping request -- automatic dialog support enabled and INVITE ST does not exist!");
                        }
                        try {
                            provider.sendResponse(responseCreateResponse2);
                        } catch (SipException e9) {
                            InternalErrorHandler.handleException(e9);
                        }
                        sipStackImpl.removeTransaction(sIPServerTransaction);
                        sIPServerTransaction.releaseSem();
                        return;
                    }
                    if (sIPServerTransaction2 != null && sIPServerTransaction != null) {
                        try {
                            sipStackImpl.addTransaction(sIPServerTransaction);
                            sIPServerTransaction.setPassToListener();
                            sIPServerTransaction.setInviteTransaction(sIPServerTransaction2);
                            sIPServerTransaction2.acquireSem();
                        } catch (Exception e10) {
                            InternalErrorHandler.handleException(e10);
                        }
                    }
                } else if (sIPRequest.getMethod().equals("INVITE")) {
                    SIPTransaction inviteTransaction = dialog == null ? null : dialog.getInviteTransaction();
                    if (dialog != null && sIPServerTransaction != null && inviteTransaction != null && sIPRequest.getCSeq().getSeqNumber() > dialog.getRemoteSeqNumber() && (inviteTransaction instanceof SIPServerTransaction) && provider.isDialogErrorsAutomaticallyHandled() && dialog.isSequnceNumberValidation() && inviteTransaction.isInviteTransaction() && inviteTransaction.getState() != TransactionState.COMPLETED && inviteTransaction.getState() != TransactionState.TERMINATED && inviteTransaction.getState() != TransactionState.CONFIRMED) {
                        if (sipStackImpl.isLoggingEnabled()) {
                            sipStackImpl.getStackLogger().logDebug("Sending 500 response for out of sequence message");
                        }
                        sendServerInternalErrorResponse(sIPRequest, sIPServerTransaction);
                        return;
                    }
                    SIPTransaction lastTransaction2 = dialog == null ? null : dialog.getLastTransaction();
                    if (dialog != null && provider.isDialogErrorsAutomaticallyHandled() && lastTransaction2 != null && lastTransaction2.isInviteTransaction() && (lastTransaction2 instanceof ClientTransaction) && lastTransaction2.getLastResponse() != null && lastTransaction2.getLastResponse().getStatusCode() == 200 && !dialog.isAckSent(lastTransaction2.getLastResponse().getCSeq().getSeqNumber())) {
                        if (sipStackImpl.isLoggingEnabled()) {
                            sipStackImpl.getStackLogger().logDebug("Sending 491 response for client Dialog ACK not sent.");
                        }
                        sendRequestPendingResponse(sIPRequest, sIPServerTransaction);
                        return;
                    } else if (dialog != null && lastTransaction2 != null && provider.isDialogErrorsAutomaticallyHandled() && lastTransaction2.isInviteTransaction() && (lastTransaction2 instanceof ServerTransaction) && !dialog.isAckSeen()) {
                        if (sipStackImpl.isLoggingEnabled()) {
                            sipStackImpl.getStackLogger().logDebug("Sending 491 response for server Dialog ACK not seen.");
                        }
                        sendRequestPendingResponse(sIPRequest, sIPServerTransaction);
                        return;
                    }
                }
            }
        }
        if (sipStackImpl.isLoggingEnabled()) {
            sipStackImpl.getStackLogger().logDebug("CHECK FOR OUT OF SEQ MESSAGE " + dialog + " transaction " + sIPServerTransaction);
        }
        if (dialog != null && sIPServerTransaction != null && !sIPRequest.getMethod().equals("BYE") && !sIPRequest.getMethod().equals(obj) && !sIPRequest.getMethod().equals(str) && !sIPRequest.getMethod().equals(Request.PRACK)) {
            if (!dialog.isRequestConsumable(sIPRequest)) {
                if (sipStackImpl.isLoggingEnabled()) {
                    sipStackImpl.getStackLogger().logDebug("Dropping out of sequence message " + dialog.getRemoteSeqNumber() + Separators.SP + sIPRequest.getCSeq());
                }
                if (dialog.getRemoteSeqNumber() >= sIPRequest.getCSeq().getSeqNumber() && provider.isDialogErrorsAutomaticallyHandled()) {
                    if (sIPServerTransaction.getState() == TransactionState.TRYING || sIPServerTransaction.getState() == TransactionState.PROCEEDING) {
                        sendServerInternalErrorResponse(sIPRequest, sIPServerTransaction);
                        return;
                    }
                    return;
                }
                return;
            }
            try {
                if (provider == dialog.getSipProvider()) {
                    sipStackImpl.addTransaction(sIPServerTransaction);
                    dialog.addTransaction(sIPServerTransaction);
                    dialog.addRoute(sIPRequest);
                    sIPServerTransaction.setDialog(dialog, dialogId);
                }
            } catch (IOException e11) {
                sIPServerTransaction.raiseIOExceptionEvent();
                sipStackImpl.removeTransaction(sIPServerTransaction);
                return;
            }
        }
        if (sipStackImpl.isLoggingEnabled()) {
            sipStackImpl.getStackLogger().logDebug(sIPRequest.getMethod() + " transaction.isMapped = " + sIPServerTransaction.isTransactionMapped());
        }
        if (dialog == null && sIPRequest.getMethod().equals("NOTIFY")) {
            SIPClientTransaction sIPClientTransactionFindSubscribeTransaction = sipStackImpl.findSubscribeTransaction(sIPRequest, this.listeningPoint);
            if (sipStackImpl.isLoggingEnabled()) {
                sipStackImpl.getStackLogger().logDebug("PROCESSING NOTIFY  DIALOG == null " + sIPClientTransactionFindSubscribeTransaction);
            }
            if (provider.isAutomaticDialogSupportEnabled() && sIPClientTransactionFindSubscribeTransaction == null && !sipStackImpl.deliverUnsolicitedNotify) {
                try {
                    if (sipStackImpl.isLoggingEnabled()) {
                        sipStackImpl.getStackLogger().logDebug("Could not find Subscription for Notify Tx.");
                    }
                    Response responseCreateResponse3 = sIPRequest.createResponse(Response.CALL_OR_TRANSACTION_DOES_NOT_EXIST);
                    responseCreateResponse3.setReasonPhrase("Subscription does not exist");
                    provider.sendResponse(responseCreateResponse3);
                    return;
                } catch (Exception e12) {
                    sipStackImpl.getStackLogger().logError("Exception while sending error response statelessly", e12);
                    return;
                }
            }
            if (sIPClientTransactionFindSubscribeTransaction != null) {
                sIPServerTransaction.setPendingSubscribe(sIPClientTransactionFindSubscribeTransaction);
                SIPDialog defaultDialog = sIPClientTransactionFindSubscribeTransaction.getDefaultDialog();
                if (defaultDialog == null || defaultDialog.getDialogId() == null || !defaultDialog.getDialogId().equals(dialogId)) {
                    if (defaultDialog != null && defaultDialog.getDialogId() == null) {
                        defaultDialog.setDialogId(dialogId);
                        defaultDialog = defaultDialog;
                    } else {
                        defaultDialog = sIPClientTransactionFindSubscribeTransaction.getDialog(dialogId);
                    }
                    if (sipStackImpl.isLoggingEnabled()) {
                        sipStackImpl.getStackLogger().logDebug("PROCESSING NOTIFY Subscribe DIALOG " + defaultDialog);
                    }
                    if (defaultDialog == null && ((provider.isAutomaticDialogSupportEnabled() || sIPClientTransactionFindSubscribeTransaction.getDefaultDialog() != null) && sipStackImpl.isEventForked(((Event) sIPRequest.getHeader("Event")).getEventType()))) {
                        defaultDialog = SIPDialog.createFromNOTIFY(sIPClientTransactionFindSubscribeTransaction, sIPServerTransaction);
                    }
                    if (defaultDialog != null) {
                        sIPServerTransaction.setDialog(defaultDialog, dialogId);
                        defaultDialog.setState(DialogState.CONFIRMED.getValue());
                        sipStackImpl.putDialog(defaultDialog);
                        sIPClientTransactionFindSubscribeTransaction.setDialog(defaultDialog, dialogId);
                        if (!sIPServerTransaction.isTransactionMapped()) {
                            this.sipStack.mapTransaction(sIPServerTransaction);
                            sIPServerTransaction.setPassToListener();
                            try {
                                this.sipStack.addTransaction(sIPServerTransaction);
                            } catch (Exception e13) {
                            }
                        }
                    }
                } else {
                    sIPServerTransaction.setDialog(defaultDialog, dialogId);
                    if (!sIPServerTransaction.isTransactionMapped()) {
                        this.sipStack.mapTransaction(sIPServerTransaction);
                        sIPServerTransaction.setPassToListener();
                        try {
                            this.sipStack.addTransaction(sIPServerTransaction);
                        } catch (Exception e14) {
                        }
                    }
                    sipStackImpl.putDialog(defaultDialog);
                    defaultDialog.addTransaction(sIPClientTransactionFindSubscribeTransaction);
                    sIPClientTransactionFindSubscribeTransaction.setDialog(defaultDialog, dialogId);
                }
                if (sIPServerTransaction.isTransactionMapped()) {
                    requestEvent = new RequestEvent(provider, sIPServerTransaction, defaultDialog, sIPRequest);
                } else {
                    requestEvent = new RequestEvent(provider, null, defaultDialog, sIPRequest);
                }
            } else {
                if (sipStackImpl.isLoggingEnabled()) {
                    sipStackImpl.getStackLogger().logDebug("could not find subscribe tx");
                }
                requestEvent = new RequestEvent(provider, null, null, sIPRequest);
            }
        } else if (sIPServerTransaction != null && sIPServerTransaction.isTransactionMapped()) {
            requestEvent = new RequestEvent(provider, sIPServerTransaction, dialog, sIPRequest);
        } else {
            requestEvent = new RequestEvent(provider, null, dialog, sIPRequest);
        }
        provider.handleEvent(requestEvent, sIPServerTransaction);
    }

    @Override // gov.nist.javax.sip.stack.ServerResponseInterface
    public void processResponse(SIPResponse response, MessageChannel incomingMessageChannel, SIPDialog dialog) {
        if (this.sipStack.isLoggingEnabled()) {
            this.sipStack.getStackLogger().logDebug("PROCESSING INCOMING RESPONSE" + response.encodeMessage());
        }
        if (this.listeningPoint == null) {
            if (this.sipStack.isLoggingEnabled()) {
                this.sipStack.getStackLogger().logError("Dropping message: No listening point registered!");
                return;
            }
            return;
        }
        if (this.sipStack.checkBranchId() && !Utils.getInstance().responseBelongsToUs(response)) {
            if (this.sipStack.isLoggingEnabled()) {
                this.sipStack.getStackLogger().logError("Dropping response - topmost VIA header does not originate from this stack");
                return;
            }
            return;
        }
        SipProviderImpl sipProvider = this.listeningPoint.getProvider();
        if (sipProvider == null) {
            if (this.sipStack.isLoggingEnabled()) {
                this.sipStack.getStackLogger().logError("Dropping message:  no provider");
                return;
            }
            return;
        }
        if (sipProvider.getSipListener() == null) {
            if (this.sipStack.isLoggingEnabled()) {
                this.sipStack.getStackLogger().logError("No listener -- dropping response!");
                return;
            }
            return;
        }
        SIPClientTransaction transaction = (SIPClientTransaction) this.transactionChannel;
        SipStackImpl sipStackImpl = sipProvider.sipStack;
        if (this.sipStack.isLoggingEnabled()) {
            sipStackImpl.getStackLogger().logDebug("Transaction = " + transaction);
        }
        if (transaction == null) {
            if (dialog != null) {
                if (response.getStatusCode() / 100 != 2) {
                    if (this.sipStack.isLoggingEnabled()) {
                        this.sipStack.getStackLogger().logDebug("Response is not a final response and dialog is found for response -- dropping response!");
                        return;
                    }
                    return;
                }
                if (dialog.getState() == DialogState.TERMINATED) {
                    if (this.sipStack.isLoggingEnabled()) {
                        this.sipStack.getStackLogger().logDebug("Dialog is terminated -- dropping response!");
                        return;
                    }
                    return;
                }
                boolean ackAlreadySent = false;
                if (dialog.isAckSeen() && dialog.getLastAckSent() != null && dialog.getLastAckSent().getCSeq().getSeqNumber() == response.getCSeq().getSeqNumber()) {
                    ackAlreadySent = true;
                }
                if (ackAlreadySent && response.getCSeq().getMethod().equals(dialog.getMethod())) {
                    try {
                        if (this.sipStack.isLoggingEnabled()) {
                            this.sipStack.getStackLogger().logDebug("Retransmission of OK detected: Resending last ACK");
                        }
                        dialog.resendAck();
                        return;
                    } catch (SipException ex) {
                        this.sipStack.getStackLogger().logError("could not resend ack", ex);
                    }
                }
            }
            if (this.sipStack.isLoggingEnabled()) {
                this.sipStack.getStackLogger().logDebug("could not find tx, handling statelessly Dialog =  " + dialog);
            }
            ResponseEventExt sipEvent = new ResponseEventExt(sipProvider, transaction, dialog, response);
            if (response.getCSeqHeader().getMethod().equals("INVITE")) {
                SIPClientTransaction forked = this.sipStack.getForkedTransaction(response.getTransactionId());
                sipEvent.setOriginalTransaction(forked);
            }
            sipProvider.handleEvent(sipEvent, transaction);
            return;
        }
        ResponseEventExt responseEvent = new ResponseEventExt(sipProvider, transaction, dialog, response);
        if (response.getCSeqHeader().getMethod().equals("INVITE")) {
            SIPClientTransaction forked2 = this.sipStack.getForkedTransaction(response.getTransactionId());
            responseEvent.setOriginalTransaction(forked2);
        }
        if (dialog != null && response.getStatusCode() != 100) {
            dialog.setLastResponse(transaction, response);
            transaction.setDialog(dialog, dialog.getDialogId());
        }
        sipProvider.handleEvent(responseEvent, transaction);
    }

    public String getProcessingInfo() {
        return null;
    }

    @Override // gov.nist.javax.sip.stack.ServerResponseInterface
    public void processResponse(SIPResponse sipResponse, MessageChannel incomingChannel) {
        boolean z;
        String dialogID = sipResponse.getDialogId(false);
        SIPDialog sipDialog = this.sipStack.getDialog(dialogID);
        String method = sipResponse.getCSeq().getMethod();
        if (this.sipStack.isLoggingEnabled()) {
            this.sipStack.getStackLogger().logDebug("PROCESSING INCOMING RESPONSE: " + sipResponse.encodeMessage());
        }
        if (this.sipStack.checkBranchId() && !Utils.getInstance().responseBelongsToUs(sipResponse)) {
            if (this.sipStack.isLoggingEnabled()) {
                this.sipStack.getStackLogger().logError("Detected stray response -- dropping");
                return;
            }
            return;
        }
        ListeningPointImpl listeningPointImpl = this.listeningPoint;
        if (listeningPointImpl == null) {
            if (this.sipStack.isLoggingEnabled()) {
                this.sipStack.getStackLogger().logDebug("Dropping message: No listening point registered!");
                return;
            }
            return;
        }
        SipProviderImpl sipProvider = listeningPointImpl.getProvider();
        if (sipProvider == null) {
            if (this.sipStack.isLoggingEnabled()) {
                this.sipStack.getStackLogger().logDebug("Dropping message:  no provider");
                return;
            }
            return;
        }
        if (sipProvider.getSipListener() == null) {
            if (this.sipStack.isLoggingEnabled()) {
                this.sipStack.getStackLogger().logDebug("Dropping message:  no sipListener registered!");
                return;
            }
            return;
        }
        SIPClientTransaction transaction = (SIPClientTransaction) this.transactionChannel;
        if (sipDialog == null && transaction != null && (sipDialog = transaction.getDialog(dialogID)) != null && sipDialog.getState() == DialogState.TERMINATED) {
            sipDialog = null;
        }
        if (this.sipStack.isLoggingEnabled()) {
            this.sipStack.getStackLogger().logDebug("Transaction = " + transaction + " sipDialog = " + sipDialog);
        }
        SIPTransaction sIPTransaction = this.transactionChannel;
        if (sIPTransaction != null) {
            String originalFrom = ((SIPRequest) sIPTransaction.getRequest()).getFromTag();
            boolean z2 = true;
            if (originalFrom != null) {
                z = false;
            } else {
                z = true;
            }
            if (sipResponse.getFrom().getTag() != null) {
                z2 = false;
            }
            if (z2 ^ z) {
                if (this.sipStack.isLoggingEnabled()) {
                    this.sipStack.getStackLogger().logDebug("From tag mismatch -- dropping response");
                    return;
                }
                return;
            } else if (originalFrom != null && !originalFrom.equalsIgnoreCase(sipResponse.getFrom().getTag())) {
                if (this.sipStack.isLoggingEnabled()) {
                    this.sipStack.getStackLogger().logDebug("From tag mismatch -- dropping response");
                    return;
                }
                return;
            }
        }
        SipStackImpl sipStackImpl = this.sipStack;
        if (SipStackImpl.isDialogCreated(method) && sipResponse.getStatusCode() != 100 && sipResponse.getFrom().getTag() != null && sipResponse.getTo().getTag() != null && sipDialog == null) {
            if (sipProvider.isAutomaticDialogSupportEnabled()) {
                SIPTransaction sIPTransaction2 = this.transactionChannel;
                if (sIPTransaction2 != null) {
                    if (sipDialog == null) {
                        sipDialog = this.sipStack.createDialog((SIPClientTransaction) sIPTransaction2, sipResponse);
                        this.transactionChannel.setDialog(sipDialog, sipResponse.getDialogId(false));
                    }
                } else {
                    sipDialog = this.sipStack.createDialog(sipProvider, sipResponse);
                }
            }
        } else if (sipDialog != null && transaction == null && sipDialog.getState() != DialogState.TERMINATED) {
            if (sipResponse.getStatusCode() / 100 != 2) {
                if (this.sipStack.isLoggingEnabled()) {
                    this.sipStack.getStackLogger().logDebug("status code != 200 ; statusCode = " + sipResponse.getStatusCode());
                }
            } else {
                if (sipDialog.getState() == DialogState.TERMINATED) {
                    if (this.sipStack.isLoggingEnabled()) {
                        this.sipStack.getStackLogger().logDebug("Dialog is terminated -- dropping response!");
                    }
                    if (sipResponse.getStatusCode() / 100 == 2 && sipResponse.getCSeq().getMethod().equals("INVITE")) {
                        try {
                            Request ackRequest = sipDialog.createAck(sipResponse.getCSeq().getSeqNumber());
                            sipDialog.sendAck(ackRequest);
                            return;
                        } catch (Exception ex) {
                            this.sipStack.getStackLogger().logError("Error creating ack", ex);
                            return;
                        }
                    }
                    return;
                }
                boolean ackAlreadySent = false;
                if (sipDialog.isAckSeen() && sipDialog.getLastAckSent() != null && sipDialog.getLastAckSent().getCSeq().getSeqNumber() == sipResponse.getCSeq().getSeqNumber() && sipResponse.getDialogId(false).equals(sipDialog.getLastAckSent().getDialogId(false))) {
                    ackAlreadySent = true;
                }
                if (ackAlreadySent && sipResponse.getCSeq().getMethod().equals(sipDialog.getMethod())) {
                    try {
                        if (this.sipStack.isLoggingEnabled()) {
                            this.sipStack.getStackLogger().logDebug("resending ACK");
                        }
                        sipDialog.resendAck();
                        return;
                    } catch (SipException e) {
                    }
                }
            }
        }
        if (this.sipStack.isLoggingEnabled()) {
            this.sipStack.getStackLogger().logDebug("sending response to TU for processing ");
        }
        if (sipDialog != null && sipResponse.getStatusCode() != 100 && sipResponse.getTo().getTag() != null) {
            sipDialog.setLastResponse(transaction, sipResponse);
        }
        ResponseEventExt responseEvent = new ResponseEventExt(sipProvider, transaction, sipDialog, sipResponse);
        if (sipResponse.getCSeq().getMethod().equals("INVITE")) {
            ClientTransactionExt originalTx = this.sipStack.getForkedTransaction(sipResponse.getTransactionId());
            responseEvent.setOriginalTransaction(originalTx);
        }
        sipProvider.handleEvent(responseEvent, transaction);
    }
}
