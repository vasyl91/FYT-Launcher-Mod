package gov.nist.javax.sip.header.ims;

import gov.nist.core.Token;
import javax.sip.header.Header;
import javax.sip.header.Parameters;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface PVisitedNetworkIDHeader extends Parameters, Header {
    public static final String NAME = "P-Visited-Network-ID";

    String getVisitedNetworkID();

    void setVisitedNetworkID(Token token);

    void setVisitedNetworkID(String str);
}
