package gov.nist.javax.sip.header.extensions;

import javax.sip.header.Header;
import javax.sip.header.HeaderAddress;
import javax.sip.header.Parameters;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface ReferredByHeader extends Header, HeaderAddress, Parameters {
    public static final String NAME = "Referred-By";
}
