package gov.nist.javax.sip.header;

import gov.nist.core.Separators;
import javax.sip.InvalidArgumentException;
import javax.sip.header.AcceptHeader;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public final class Accept extends ParametersHeader implements AcceptHeader {
    private static final long serialVersionUID = -7866187924308658151L;
    protected MediaRange mediaRange;

    public Accept() {
        super("Accept");
    }

    @Override // javax.sip.header.AcceptHeader
    public boolean allowsAllContentTypes() {
        MediaRange mediaRange = this.mediaRange;
        return mediaRange != null && mediaRange.type.compareTo(Separators.STAR) == 0;
    }

    @Override // javax.sip.header.AcceptHeader
    public boolean allowsAllContentSubTypes() {
        MediaRange mediaRange = this.mediaRange;
        return mediaRange != null && mediaRange.getSubtype().compareTo(Separators.STAR) == 0;
    }

    @Override // gov.nist.javax.sip.header.ParametersHeader, gov.nist.javax.sip.header.SIPHeader
    protected String encodeBody() {
        return encodeBody(new StringBuffer()).toString();
    }

    @Override // gov.nist.javax.sip.header.SIPHeader
    protected StringBuffer encodeBody(StringBuffer buffer) {
        MediaRange mediaRange = this.mediaRange;
        if (mediaRange != null) {
            mediaRange.encode(buffer);
        }
        if (this.parameters != null && !this.parameters.isEmpty()) {
            buffer.append(';');
            this.parameters.encode(buffer);
        }
        return buffer;
    }

    public MediaRange getMediaRange() {
        return this.mediaRange;
    }

    @Override // javax.sip.header.MediaType
    public String getContentType() {
        MediaRange mediaRange = this.mediaRange;
        if (mediaRange == null) {
            return null;
        }
        return mediaRange.getType();
    }

    @Override // javax.sip.header.MediaType
    public String getContentSubType() {
        MediaRange mediaRange = this.mediaRange;
        if (mediaRange == null) {
            return null;
        }
        return mediaRange.getSubtype();
    }

    @Override // javax.sip.header.AcceptHeader
    public float getQValue() {
        return getParameterAsFloat("q");
    }

    @Override // javax.sip.header.AcceptHeader
    public boolean hasQValue() {
        return super.hasParameter("q");
    }

    @Override // javax.sip.header.AcceptHeader
    public void removeQValue() {
        super.removeParameter("q");
    }

    @Override // javax.sip.header.MediaType
    public void setContentSubType(String subtype) {
        if (this.mediaRange == null) {
            this.mediaRange = new MediaRange();
        }
        this.mediaRange.setSubtype(subtype);
    }

    @Override // javax.sip.header.MediaType
    public void setContentType(String type) {
        if (this.mediaRange == null) {
            this.mediaRange = new MediaRange();
        }
        this.mediaRange.setType(type);
    }

    @Override // javax.sip.header.AcceptHeader
    public void setQValue(float qValue) throws InvalidArgumentException {
        if (qValue == -1.0f) {
            super.removeParameter("q");
        }
        super.setParameter("q", qValue);
    }

    public void setMediaRange(MediaRange m) {
        this.mediaRange = m;
    }

    @Override // gov.nist.javax.sip.header.ParametersHeader, gov.nist.core.GenericObject
    public Object clone() {
        Accept retval = (Accept) super.clone();
        MediaRange mediaRange = this.mediaRange;
        if (mediaRange != null) {
            retval.mediaRange = (MediaRange) mediaRange.clone();
        }
        return retval;
    }
}
