package gov.nist.javax.sip.parser.ims;

import gov.nist.javax.sip.address.AddressImpl;
import gov.nist.javax.sip.header.ims.AddressHeaderIms;
import gov.nist.javax.sip.parser.AddressParser;
import gov.nist.javax.sip.parser.HeaderParser;
import gov.nist.javax.sip.parser.Lexer;
import java.text.ParseException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
abstract class AddressHeaderParser extends HeaderParser {
    protected AddressHeaderParser(Lexer lexer) {
        super(lexer);
    }

    protected AddressHeaderParser(String buffer) {
        super(buffer);
    }

    protected void parse(AddressHeaderIms addressHeader) throws ParseException {
        dbg_enter("AddressHeaderParser.parse");
        try {
            try {
                AddressParser addressParser = new AddressParser(getLexer());
                AddressImpl addr = addressParser.address(true);
                addressHeader.setAddress(addr);
                dbg_leave("AddressParametersParser.parse");
            } catch (ParseException ex) {
                throw ex;
            }
        } catch (Throwable th) {
            dbg_leave("AddressParametersParser.parse");
            throw th;
        }
    }
}
