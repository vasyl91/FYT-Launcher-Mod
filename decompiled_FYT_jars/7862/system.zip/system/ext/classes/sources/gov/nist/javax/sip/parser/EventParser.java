package gov.nist.javax.sip.parser;

import gov.nist.core.Token;
import gov.nist.javax.sip.header.Event;
import gov.nist.javax.sip.header.SIPHeader;
import java.text.ParseException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class EventParser extends ParametersParser {
    public EventParser(String event) {
        super(event);
    }

    protected EventParser(Lexer lexer) {
        super(lexer);
    }

    @Override // gov.nist.javax.sip.parser.HeaderParser
    public SIPHeader parse() throws ParseException {
        if (debug) {
            dbg_enter("EventParser.parse");
        }
        try {
            try {
                headerName(TokenTypes.EVENT);
                this.lexer.SPorHT();
                Event event = new Event();
                this.lexer.match(4095);
                Token token = this.lexer.getNextToken();
                String value = token.getTokenValue();
                event.setEventType(value);
                super.parse(event);
                this.lexer.SPorHT();
                this.lexer.match(10);
                if (debug) {
                    dbg_leave("EventParser.parse");
                }
                return event;
            } catch (ParseException ex) {
                throw createParseException(ex.getMessage());
            }
        } catch (Throwable th) {
            if (debug) {
                dbg_leave("EventParser.parse");
            }
            throw th;
        }
    }
}
