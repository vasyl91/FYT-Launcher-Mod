package gov.nist.javax.sip.header;

import gov.nist.core.Separators;
import gov.nist.javax.sip.address.GenericURI;
import java.text.ParseException;
import javax.sip.address.URI;
import javax.sip.header.AlertInfoHeader;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public final class AlertInfo extends ParametersHeader implements AlertInfoHeader {
    private static final long serialVersionUID = 4159657362051508719L;
    protected String string;
    protected GenericURI uri;

    public AlertInfo() {
        super("Alert-Info");
    }

    @Override // gov.nist.javax.sip.header.ParametersHeader, gov.nist.javax.sip.header.SIPHeader
    protected String encodeBody() {
        StringBuffer encoding = new StringBuffer();
        if (this.uri != null) {
            encoding.append(Separators.LESS_THAN);
            encoding.append(this.uri.encode());
            encoding.append(Separators.GREATER_THAN);
        } else {
            String str = this.string;
            if (str != null) {
                encoding.append(str);
            }
        }
        if (!this.parameters.isEmpty()) {
            encoding.append(Separators.SEMICOLON);
            encoding.append(this.parameters.encode());
        }
        return encoding.toString();
    }

    @Override // javax.sip.header.AlertInfoHeader
    public void setAlertInfo(URI uri) {
        this.uri = (GenericURI) uri;
    }

    @Override // javax.sip.header.AlertInfoHeader
    public void setAlertInfo(String string) {
        this.string = string;
    }

    @Override // javax.sip.header.AlertInfoHeader
    public URI getAlertInfo() {
        if (this.uri != null) {
            URI alertInfoUri = this.uri;
            return alertInfoUri;
        }
        try {
            URI alertInfoUri2 = new GenericURI(this.string);
            return alertInfoUri2;
        } catch (ParseException e) {
            return null;
        }
    }

    @Override // gov.nist.javax.sip.header.ParametersHeader, gov.nist.core.GenericObject
    public Object clone() {
        AlertInfo retval = (AlertInfo) super.clone();
        GenericURI genericURI = this.uri;
        if (genericURI != null) {
            retval.uri = (GenericURI) genericURI.clone();
        } else {
            String str = this.string;
            if (str != null) {
                retval.string = str;
            }
        }
        return retval;
    }
}
