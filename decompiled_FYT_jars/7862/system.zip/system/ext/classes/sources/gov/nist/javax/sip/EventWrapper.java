package gov.nist.javax.sip;

import gov.nist.javax.sip.stack.SIPTransaction;
import java.util.EventObject;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
class EventWrapper {
    protected EventObject sipEvent;
    protected SIPTransaction transaction;

    EventWrapper(EventObject sipEvent, SIPTransaction transaction) {
        this.sipEvent = sipEvent;
        this.transaction = transaction;
    }
}
