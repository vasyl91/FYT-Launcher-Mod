package gov.nist.core;

import gov.nist.javax.sip.message.SIPMessage;
import java.util.Properties;
import javax.sip.SipStack;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface ServerLogger extends LogLevels {
    void closeLogFile();

    void logException(Exception exc);

    void logMessage(SIPMessage sIPMessage, String str, String str2, String str3, boolean z);

    void logMessage(SIPMessage sIPMessage, String str, String str2, String str3, boolean z, long j);

    void logMessage(SIPMessage sIPMessage, String str, String str2, boolean z, long j);

    void setSipStack(SipStack sipStack);

    void setStackProperties(Properties properties);
}
