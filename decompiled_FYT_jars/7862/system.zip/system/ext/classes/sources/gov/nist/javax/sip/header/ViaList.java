package gov.nist.javax.sip.header;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public final class ViaList extends SIPHeaderList<Via> {
    private static final long serialVersionUID = 3899679374556152313L;

    @Override // gov.nist.javax.sip.header.SIPHeaderList, gov.nist.core.GenericObject
    public Object clone() {
        ViaList retval = new ViaList();
        return retval.clonehlist(this.hlist);
    }

    public ViaList() {
        super(Via.class, "Via");
    }
}
