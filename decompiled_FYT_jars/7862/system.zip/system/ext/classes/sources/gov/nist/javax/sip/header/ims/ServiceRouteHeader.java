package gov.nist.javax.sip.header.ims;

import javax.sip.header.Header;
import javax.sip.header.HeaderAddress;
import javax.sip.header.Parameters;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface ServiceRouteHeader extends HeaderAddress, Parameters, Header {
    public static final String NAME = "Service-Route";
}
