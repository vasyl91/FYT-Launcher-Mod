package gov.nist.javax.sip.clientauthutils;

import javax.sip.ClientTransaction;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface AccountManager {
    UserCredentials getCredentials(ClientTransaction clientTransaction, String str);
}
