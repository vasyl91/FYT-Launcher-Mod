package gov.nist.javax.sip.parser.ims;

import gov.nist.javax.sip.header.SIPHeader;
import gov.nist.javax.sip.header.ims.PPreferredService;
import gov.nist.javax.sip.header.ims.ParameterNamesIms;
import gov.nist.javax.sip.parser.HeaderParser;
import gov.nist.javax.sip.parser.Lexer;
import gov.nist.javax.sip.parser.TokenTypes;
import java.text.ParseException;
import javax.sip.InvalidArgumentException;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class PPreferredServiceParser extends HeaderParser implements TokenTypes {
    protected PPreferredServiceParser(Lexer lexer) {
        super(lexer);
    }

    public PPreferredServiceParser(String pps) {
        super(pps);
    }

    /* JADX WARN: Code duplicated, block: B:42:0x00aa  */
    @Override // gov.nist.javax.sip.parser.HeaderParser
    public SIPHeader parse() throws ParseException {
        if (debug) {
            dbg_enter("PPreferredServiceParser.parse");
        }
        try {
            this.lexer.match(TokenTypes.P_PREFERRED_SERVICE);
            this.lexer.SPorHT();
            this.lexer.match(58);
            this.lexer.SPorHT();
            PPreferredService pps = new PPreferredService();
            String urn = this.lexer.getBuffer();
            if (urn.contains(ParameterNamesIms.SERVICE_ID)) {
                if (urn.contains(ParameterNamesIms.SERVICE_ID_LABEL)) {
                    String serviceID = urn.split("3gpp-service.")[1];
                    if (serviceID.trim().equals("")) {
                        try {
                            throw new InvalidArgumentException("URN should atleast have one sub-service");
                        } catch (InvalidArgumentException e) {
                            e.printStackTrace();
                        }
                    } else {
                        pps.setSubserviceIdentifiers(serviceID);
                    }
                } else {
                    if (urn.contains(ParameterNamesIms.APPLICATION_ID_LABEL)) {
                        String appID = urn.split(ParameterNamesIms.APPLICATION_ID_LABEL)[1];
                        if (appID.trim().equals("")) {
                            try {
                                throw new InvalidArgumentException("URN should atleast have one sub-application");
                            } catch (InvalidArgumentException e2) {
                                e2.printStackTrace();
                            }
                        } else {
                            pps.setApplicationIdentifiers(appID);
                        }
                    } else {
                        try {
                            throw new InvalidArgumentException("URN is not well formed");
                        } catch (InvalidArgumentException e3) {
                            e3.printStackTrace();
                        }
                    }
                    if (debug) {
                        dbg_enter("PPreferredServiceParser.parse");
                    }
                    throw th;
                }
            }
            super.parse();
            if (debug) {
                dbg_enter("PPreferredServiceParser.parse");
            }
            return pps;
        } catch (Throwable th) {
            if (debug) {
                dbg_enter("PPreferredServiceParser.parse");
            }
            throw th;
        }
    }
}
