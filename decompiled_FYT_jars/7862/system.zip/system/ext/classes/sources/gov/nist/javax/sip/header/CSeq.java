package gov.nist.javax.sip.header;

import gov.nist.core.Separators;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import javax.sip.InvalidArgumentException;
import javax.sip.header.CSeqHeader;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class CSeq extends SIPHeader implements CSeqHeader {
    private static final long serialVersionUID = -5405798080040422910L;
    protected String method;
    protected Long seqno;

    public CSeq() {
        super("CSeq");
    }

    public CSeq(long seqno, String method) {
        this();
        this.seqno = Long.valueOf(seqno);
        this.method = SIPRequest.getCannonicalName(method);
    }

    @Override // gov.nist.javax.sip.header.SIPObject, gov.nist.core.GenericObject
    public boolean equals(Object other) {
        if (!(other instanceof CSeqHeader)) {
            return false;
        }
        CSeqHeader o = (CSeqHeader) other;
        return getSeqNumber() == o.getSeqNumber() && getMethod().equals(o.getMethod());
    }

    @Override // gov.nist.javax.sip.header.SIPHeader, gov.nist.javax.sip.header.SIPObject, gov.nist.core.GenericObject
    public String encode() {
        return this.headerName + Separators.COLON + Separators.SP + encodeBody() + Separators.NEWLINE;
    }

    @Override // gov.nist.javax.sip.header.SIPHeader
    public String encodeBody() {
        return encodeBody(new StringBuffer()).toString();
    }

    @Override // gov.nist.javax.sip.header.SIPHeader
    protected StringBuffer encodeBody(StringBuffer buffer) {
        buffer.append(this.seqno);
        buffer.append(Separators.SP);
        buffer.append(this.method.toUpperCase());
        return buffer;
    }

    @Override // javax.sip.header.AllowHeader
    public String getMethod() {
        return this.method;
    }

    @Override // javax.sip.header.RSeqHeader
    public void setSeqNumber(long sequenceNumber) throws InvalidArgumentException {
        if (sequenceNumber < 0) {
            throw new InvalidArgumentException("JAIN-SIP Exception, CSeq, setSequenceNumber(), the sequence number parameter is < 0 : " + sequenceNumber);
        }
        if (sequenceNumber > 2147483648L) {
            throw new InvalidArgumentException("JAIN-SIP Exception, CSeq, setSequenceNumber(), the sequence number parameter is too large : " + sequenceNumber);
        }
        this.seqno = Long.valueOf(sequenceNumber);
    }

    @Override // javax.sip.header.RSeqHeader
    public void setSequenceNumber(int sequenceNumber) throws InvalidArgumentException {
        setSeqNumber(sequenceNumber);
    }

    @Override // javax.sip.header.AllowHeader
    public void setMethod(String meth) throws ParseException {
        if (meth == null) {
            throw new NullPointerException("JAIN-SIP Exception, CSeq, setMethod(), the meth parameter is null");
        }
        this.method = SIPRequest.getCannonicalName(meth);
    }

    @Override // javax.sip.header.RSeqHeader
    public int getSequenceNumber() {
        Long l = this.seqno;
        if (l == null) {
            return 0;
        }
        return l.intValue();
    }

    @Override // javax.sip.header.RSeqHeader
    public long getSeqNumber() {
        return this.seqno.longValue();
    }
}
