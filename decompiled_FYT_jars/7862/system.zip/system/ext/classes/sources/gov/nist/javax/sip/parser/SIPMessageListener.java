package gov.nist.javax.sip.parser;

import gov.nist.javax.sip.message.SIPMessage;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface SIPMessageListener extends ParseExceptionListener {
    void processMessage(SIPMessage sIPMessage) throws Exception;
}
