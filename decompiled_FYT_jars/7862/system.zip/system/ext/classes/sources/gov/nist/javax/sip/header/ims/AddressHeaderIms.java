package gov.nist.javax.sip.header.ims;

import gov.nist.javax.sip.address.AddressImpl;
import gov.nist.javax.sip.header.SIPHeader;
import javax.sip.address.Address;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public abstract class AddressHeaderIms extends SIPHeader {
    protected AddressImpl address;

    @Override // gov.nist.javax.sip.header.SIPHeader
    public abstract String encodeBody();

    public Address getAddress() {
        return this.address;
    }

    public void setAddress(Address address) {
        this.address = (AddressImpl) address;
    }

    public AddressHeaderIms(String name) {
        super(name);
    }

    @Override // gov.nist.core.GenericObject
    public Object clone() {
        AddressHeaderIms retval = (AddressHeaderIms) super.clone();
        AddressImpl addressImpl = this.address;
        if (addressImpl != null) {
            retval.address = (AddressImpl) addressImpl.clone();
        }
        return retval;
    }
}
