package gov.nist.javax.sip.header.ims;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface PServedUserHeader {
    public static final String NAME = "P-Served-User";

    String getRegistrationState();

    String getSessionCase();

    void setRegistrationState(String str);

    void setSessionCase(String str);
}
