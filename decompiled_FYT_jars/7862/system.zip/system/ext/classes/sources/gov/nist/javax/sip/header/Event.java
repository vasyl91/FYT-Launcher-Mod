package gov.nist.javax.sip.header;

import gov.nist.core.Separators;
import java.text.ParseException;
import javax.sip.header.EventHeader;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class Event extends ParametersHeader implements EventHeader {
    private static final long serialVersionUID = -6458387810431874841L;
    protected String eventType;

    public Event() {
        super("Event");
    }

    @Override // javax.sip.header.EventHeader
    public void setEventType(String eventType) throws ParseException {
        if (eventType == null) {
            throw new NullPointerException(" the eventType is null");
        }
        this.eventType = eventType;
    }

    @Override // javax.sip.header.EventHeader
    public String getEventType() {
        return this.eventType;
    }

    @Override // javax.sip.header.EventHeader
    public void setEventId(String eventId) throws ParseException {
        if (eventId == null) {
            throw new NullPointerException(" the eventId parameter is null");
        }
        setParameter(ParameterNames.ID, eventId);
    }

    @Override // javax.sip.header.EventHeader
    public String getEventId() {
        return getParameter(ParameterNames.ID);
    }

    @Override // gov.nist.javax.sip.header.ParametersHeader, gov.nist.javax.sip.header.SIPHeader
    public String encodeBody() {
        return encodeBody(new StringBuffer()).toString();
    }

    @Override // gov.nist.javax.sip.header.SIPHeader
    protected StringBuffer encodeBody(StringBuffer buffer) {
        String str = this.eventType;
        if (str != null) {
            buffer.append(str);
        }
        if (!this.parameters.isEmpty()) {
            buffer.append(Separators.SEMICOLON);
            this.parameters.encode(buffer);
        }
        return buffer;
    }

    public boolean match(Event matchTarget) {
        if (matchTarget.eventType == null && this.eventType != null) {
            return false;
        }
        if (matchTarget.eventType != null && this.eventType == null) {
            return false;
        }
        if (this.eventType == null && matchTarget.eventType == null) {
            return false;
        }
        if (getEventId() == null && matchTarget.getEventId() != null) {
            return false;
        }
        if ((getEventId() == null || matchTarget.getEventId() != null) && matchTarget.eventType.equalsIgnoreCase(this.eventType)) {
            return getEventId() == matchTarget.getEventId() || getEventId().equalsIgnoreCase(matchTarget.getEventId());
        }
        return false;
    }
}
