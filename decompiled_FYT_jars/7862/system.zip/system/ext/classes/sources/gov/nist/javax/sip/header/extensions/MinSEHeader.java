package gov.nist.javax.sip.header.extensions;

import javax.sip.header.Header;
import javax.sip.header.Parameters;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface MinSEHeader extends Parameters, Header {
    public static final String NAME = "Min-SE";
}
