package gov.nist.javax.sip.header;

import java.text.ParseException;
import javax.sip.header.SubjectHeader;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class Subject extends SIPHeader implements SubjectHeader {
    private static final long serialVersionUID = -6479220126758862528L;
    protected String subject;

    public Subject() {
        super("Subject");
    }

    @Override // gov.nist.javax.sip.header.SIPHeader
    public String encodeBody() {
        String str = this.subject;
        if (str != null) {
            return str;
        }
        return "";
    }

    @Override // javax.sip.header.SubjectHeader
    public void setSubject(String subject) throws ParseException {
        if (subject == null) {
            throw new NullPointerException("JAIN-SIP Exception,  Subject, setSubject(), the subject parameter is null");
        }
        this.subject = subject;
    }

    @Override // javax.sip.header.SubjectHeader
    public String getSubject() {
        return this.subject;
    }
}
