package gov.nist.javax.sip.message;

import javax.sip.header.ContentDispositionHeader;
import javax.sip.header.ContentTypeHeader;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface Content {
    Object getContent();

    ContentDispositionHeader getContentDispositionHeader();

    ContentTypeHeader getContentTypeHeader();

    void setContent(Object obj);

    String toString();
}
