package gov.nist.javax.sip;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface LogRecord {
    boolean equals(Object obj);

    String toString();
}
