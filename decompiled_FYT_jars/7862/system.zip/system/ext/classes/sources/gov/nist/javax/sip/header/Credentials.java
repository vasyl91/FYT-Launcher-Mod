package gov.nist.javax.sip.header;

import gov.nist.core.NameValueList;
import gov.nist.core.Separators;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class Credentials extends SIPObject {
    private static final long serialVersionUID = -6335592791505451524L;
    protected NameValueList parameters = new NameValueList();
    protected String scheme;
    private static String DOMAIN = "domain";
    private static String REALM = "realm";
    private static String OPAQUE = "opaque";
    private static String RESPONSE = "response";
    private static String URI = "uri";
    private static String NONCE = "nonce";
    private static String CNONCE = "cnonce";
    private static String USERNAME = "username";

    public Credentials() {
        this.parameters.setSeparator(Separators.COMMA);
    }

    public NameValueList getCredentials() {
        return this.parameters;
    }

    public String getScheme() {
        return this.scheme;
    }

    public void setScheme(String s) {
        this.scheme = s;
    }

    public void setCredentials(NameValueList c) {
        this.parameters = c;
    }

    @Override // gov.nist.javax.sip.header.SIPObject, gov.nist.core.GenericObject
    public String encode() {
        String retval = this.scheme;
        if (!this.parameters.isEmpty()) {
            return retval + Separators.SP + this.parameters.encode();
        }
        return retval;
    }

    @Override // gov.nist.core.GenericObject
    public Object clone() {
        Credentials retval = (Credentials) super.clone();
        NameValueList nameValueList = this.parameters;
        if (nameValueList != null) {
            retval.parameters = (NameValueList) nameValueList.clone();
        }
        return retval;
    }
}
