package gov.nist.javax.sip.header;

import gov.nist.javax.sip.header.ims.AuthorizationHeaderIms;
import javax.sip.header.AuthorizationHeader;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class Authorization extends AuthenticationHeader implements AuthorizationHeader, AuthorizationHeaderIms {
    private static final long serialVersionUID = -8897770321892281348L;

    public Authorization() {
        super("Authorization");
    }
}
