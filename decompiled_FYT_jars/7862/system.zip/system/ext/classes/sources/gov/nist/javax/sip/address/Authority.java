package gov.nist.javax.sip.address;

import gov.nist.core.Host;
import gov.nist.core.HostPort;
import gov.nist.core.Separators;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class Authority extends NetObject {
    private static final long serialVersionUID = -3570349777347017894L;
    protected HostPort hostPort;
    protected UserInfo userInfo;

    @Override // gov.nist.core.GenericObject
    public String encode() {
        return encode(new StringBuffer()).toString();
    }

    @Override // gov.nist.core.GenericObject
    public StringBuffer encode(StringBuffer buffer) {
        UserInfo userInfo = this.userInfo;
        if (userInfo != null) {
            userInfo.encode(buffer);
            buffer.append(Separators.AT);
            this.hostPort.encode(buffer);
        } else {
            this.hostPort.encode(buffer);
        }
        return buffer;
    }

    @Override // gov.nist.javax.sip.address.NetObject, gov.nist.core.GenericObject
    public boolean equals(Object other) {
        UserInfo userInfo;
        if (other == null || other.getClass() != getClass()) {
            return false;
        }
        Authority otherAuth = (Authority) other;
        if (!this.hostPort.equals(otherAuth.hostPort)) {
            return false;
        }
        UserInfo userInfo2 = this.userInfo;
        if (userInfo2 != null && (userInfo = otherAuth.userInfo) != null && !userInfo2.equals(userInfo)) {
            return false;
        }
        return true;
    }

    public HostPort getHostPort() {
        return this.hostPort;
    }

    public UserInfo getUserInfo() {
        return this.userInfo;
    }

    public String getPassword() {
        UserInfo userInfo = this.userInfo;
        if (userInfo == null) {
            return null;
        }
        return userInfo.password;
    }

    public String getUser() {
        UserInfo userInfo = this.userInfo;
        if (userInfo != null) {
            return userInfo.user;
        }
        return null;
    }

    public Host getHost() {
        HostPort hostPort = this.hostPort;
        if (hostPort == null) {
            return null;
        }
        return hostPort.getHost();
    }

    public int getPort() {
        HostPort hostPort = this.hostPort;
        if (hostPort == null) {
            return -1;
        }
        return hostPort.getPort();
    }

    public void removePort() {
        HostPort hostPort = this.hostPort;
        if (hostPort != null) {
            hostPort.removePort();
        }
    }

    public void setPassword(String passwd) {
        if (this.userInfo == null) {
            this.userInfo = new UserInfo();
        }
        this.userInfo.setPassword(passwd);
    }

    public void setUser(String user) {
        if (this.userInfo == null) {
            this.userInfo = new UserInfo();
        }
        this.userInfo.setUser(user);
    }

    public void setHost(Host host) {
        if (this.hostPort == null) {
            this.hostPort = new HostPort();
        }
        this.hostPort.setHost(host);
    }

    public void setPort(int port) {
        if (this.hostPort == null) {
            this.hostPort = new HostPort();
        }
        this.hostPort.setPort(port);
    }

    public void setHostPort(HostPort h) {
        this.hostPort = h;
    }

    public void setUserInfo(UserInfo u) {
        this.userInfo = u;
    }

    public void removeUserInfo() {
        this.userInfo = null;
    }

    @Override // gov.nist.core.GenericObject
    public Object clone() {
        Authority retval = (Authority) super.clone();
        HostPort hostPort = this.hostPort;
        if (hostPort != null) {
            retval.hostPort = (HostPort) hostPort.clone();
        }
        UserInfo userInfo = this.userInfo;
        if (userInfo != null) {
            retval.userInfo = (UserInfo) userInfo.clone();
        }
        return retval;
    }

    public int hashCode() {
        HostPort hostPort = this.hostPort;
        if (hostPort == null) {
            throw new UnsupportedOperationException("Null hostPort cannot compute hashcode");
        }
        return hostPort.encode().hashCode();
    }
}
