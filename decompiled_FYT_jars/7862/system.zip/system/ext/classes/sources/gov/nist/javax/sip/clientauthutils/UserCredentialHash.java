package gov.nist.javax.sip.clientauthutils;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface UserCredentialHash {
    String getHashUserDomainPassword();

    String getSipDomain();

    String getUserName();
}
