package gov.nist.javax.sip.header.ims;

import javax.sip.InvalidArgumentException;
import javax.sip.header.Header;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface PMediaAuthorizationHeader extends Header {
    public static final String NAME = "P-Media-Authorization";

    String getToken();

    void setMediaAuthorizationToken(String str) throws InvalidArgumentException;
}
