package gov.nist.javax.sip.header;

import gov.nist.core.Separators;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public class MediaRange extends SIPObject {
    private static final long serialVersionUID = -6297125815438079210L;
    protected String subtype;
    protected String type;

    public String getType() {
        return this.type;
    }

    public String getSubtype() {
        return this.subtype;
    }

    public void setType(String t) {
        this.type = t;
    }

    public void setSubtype(String s) {
        this.subtype = s;
    }

    @Override // gov.nist.javax.sip.header.SIPObject, gov.nist.core.GenericObject
    public String encode() {
        return encode(new StringBuffer()).toString();
    }

    @Override // gov.nist.javax.sip.header.SIPObject, gov.nist.core.GenericObject
    public StringBuffer encode(StringBuffer buffer) {
        buffer.append(this.type);
        buffer.append(Separators.SLASH);
        buffer.append(this.subtype);
        return buffer;
    }
}
