package gov.nist.javax.sip.parser.ims;

import gov.nist.javax.sip.parser.TokenNames;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface TokenNamesIms extends TokenNames {
    public static final String GGGPP_CDMA2000 = "3GPP-CDMA2000";
    public static final String GGGPP_GERAN = "3GPP-GERAN";
    public static final String GGGPP_UTRAN_FDD = "3GPP-UTRAN-FDD";
    public static final String GGGPP_UTRAN_TDD = "3GPP-UTRAN-TDD";
    public static final String IEEE_802_11A = "IEEE-802.11a";
    public static final String IEEE_802_11B = "IEEE-802.11b";
}
