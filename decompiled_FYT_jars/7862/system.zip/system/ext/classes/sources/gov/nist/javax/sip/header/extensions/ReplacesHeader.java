package gov.nist.javax.sip.header.extensions;

import java.text.ParseException;
import javax.sip.header.Header;
import javax.sip.header.Parameters;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface ReplacesHeader extends Header, Parameters {
    public static final String NAME = "Replaces";

    String getCallId();

    String getFromTag();

    String getToTag();

    void setCallId(String str) throws ParseException;

    void setFromTag(String str) throws ParseException;

    void setToTag(String str) throws ParseException;
}
