package com.android.i18n.phonenumbers.internal;

import com.android.i18n.phonenumbers.Phonemetadata;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface MatcherApi {
    boolean matchNationalNumber(CharSequence charSequence, Phonemetadata.PhoneNumberDesc phoneNumberDesc, boolean z);
}
