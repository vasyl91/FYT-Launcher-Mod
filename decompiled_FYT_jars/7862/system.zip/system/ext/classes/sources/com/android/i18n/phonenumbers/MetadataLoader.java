package com.android.i18n.phonenumbers;

import java.io.InputStream;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public interface MetadataLoader {
    InputStream loadMetadata(String str);
}
