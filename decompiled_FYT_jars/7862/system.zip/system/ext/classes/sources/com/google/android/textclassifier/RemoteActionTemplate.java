package com.google.android.textclassifier;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\ext\classes.dex */
public final class RemoteActionTemplate {
    public final String action;
    public final String[] category;
    public final String data;
    public final String description;
    public final String descriptionWithAppName;
    public final NamedVariant[] extras;
    public final Integer flags;
    public final String packageName;
    public final Integer requestCode;
    public final String titleWithEntity;
    public final String titleWithoutEntity;
    public final String type;

    public RemoteActionTemplate(String titleWithoutEntity, String titleWithEntity, String description, String descriptionWithAppName, String action, String data, String type, Integer flags, String[] category, String packageName, NamedVariant[] extras, Integer requestCode) {
        this.titleWithoutEntity = titleWithoutEntity;
        this.titleWithEntity = titleWithEntity;
        this.description = description;
        this.descriptionWithAppName = descriptionWithAppName;
        this.action = action;
        this.data = data;
        this.type = type;
        this.flags = flags;
        this.category = category;
        this.packageName = packageName;
        this.extras = extras;
        this.requestCode = requestCode;
    }
}
