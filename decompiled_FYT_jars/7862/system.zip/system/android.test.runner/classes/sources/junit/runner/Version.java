package junit.runner;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\android.test.runner\classes.dex */
public class Version {
    private Version() {
    }

    public static String id() {
        return "4.10";
    }

    public static void main(String[] args) {
        System.out.println(id());
    }
}
