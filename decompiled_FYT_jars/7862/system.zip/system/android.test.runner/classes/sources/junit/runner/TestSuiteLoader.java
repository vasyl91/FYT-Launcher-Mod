package junit.runner;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\android.test.runner\classes.dex */
public interface TestSuiteLoader {
    Class load(String str) throws ClassNotFoundException;

    Class reload(Class cls) throws ClassNotFoundException;
}
