package android.test;

import android.app.Instrumentation;
import android.content.Intent;
import android.os.Bundle;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\android.test.runner\classes.dex */
@Deprecated
public class LaunchPerformanceBase extends Instrumentation {
    public static final String LOG_TAG = "Launch Performance";
    protected Bundle mResults = new Bundle();
    protected Intent mIntent = new Intent("android.intent.action.MAIN");

    public LaunchPerformanceBase() {
        this.mIntent.setFlags(268435456);
        setAutomaticPerformanceSnapshots();
    }

    protected void LaunchApp() {
        startActivitySync(this.mIntent);
        waitForIdleSync();
    }
}
