package android.test;

import android.app.Activity;
import android.util.Log;
import java.lang.reflect.Field;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\android.test.runner\classes.dex */
@Deprecated
public abstract class ActivityTestCase extends InstrumentationTestCase {
    private Activity mActivity;

    protected Activity getActivity() {
        return this.mActivity;
    }

    protected void setActivity(Activity testActivity) {
        this.mActivity = testActivity;
    }

    protected void scrubClass(Class<?> testCaseClass) throws IllegalAccessException {
        Field[] fields = getClass().getDeclaredFields();
        for (Field field : fields) {
            Class<?> fieldClass = field.getDeclaringClass();
            if (testCaseClass.isAssignableFrom(fieldClass) && !field.getType().isPrimitive() && (field.getModifiers() & 16) == 0) {
                try {
                    field.setAccessible(true);
                    field.set(this, null);
                } catch (Exception e) {
                    Log.d("TestCase", "Error: Could not nullify field!");
                }
                if (field.get(this) != null) {
                    Log.d("TestCase", "Error: Could not nullify field!");
                }
            }
        }
    }
}
