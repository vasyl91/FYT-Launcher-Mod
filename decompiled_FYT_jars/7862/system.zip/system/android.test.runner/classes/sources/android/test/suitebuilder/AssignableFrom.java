package android.test.suitebuilder;

import com.android.internal.util.Predicate;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\android.test.runner\classes.dex */
class AssignableFrom implements Predicate<TestMethod> {
    private final Class<?> root;

    AssignableFrom(Class<?> root) {
        this.root = root;
    }

    public boolean apply(TestMethod testMethod) {
        return this.root.isAssignableFrom(testMethod.getEnclosingClass());
    }
}
