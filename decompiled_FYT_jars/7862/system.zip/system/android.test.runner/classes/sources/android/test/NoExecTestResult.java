package android.test;

import junit.framework.TestCase;
import junit.framework.TestResult;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\android.test.runner\classes.dex */
@Deprecated
class NoExecTestResult extends TestResult {
    NoExecTestResult() {
    }

    protected void run(TestCase test) {
        startTest(test);
        endTest(test);
    }
}
