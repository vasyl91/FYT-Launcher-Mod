package com.android.future.usb;

/* JADX INFO: loaded from: C:\payload\7862_jars\system\com.android.future.usb.accessory\classes.dex */
public class UsbAccessory {
    private final String mDescription;
    private final String mManufacturer;
    private final String mModel;
    private final String mSerial;
    private final String mUri;
    private final String mVersion;

    UsbAccessory(android.hardware.usb.UsbAccessory accessory) {
        this.mManufacturer = accessory.getManufacturer();
        this.mModel = accessory.getModel();
        this.mDescription = accessory.getDescription();
        this.mVersion = accessory.getVersion();
        this.mUri = accessory.getUri();
        this.mSerial = accessory.getSerial();
    }

    public String getManufacturer() {
        return this.mManufacturer;
    }

    public String getModel() {
        return this.mModel;
    }

    public String getDescription() {
        return this.mDescription;
    }

    public String getVersion() {
        return this.mVersion;
    }

    public String getUri() {
        return this.mUri;
    }

    public String getSerial() {
        return this.mSerial;
    }

    private static boolean compare(String s1, String s2) {
        if (s1 == null) {
            return s2 == null;
        }
        return s1.equals(s2);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof UsbAccessory)) {
            return false;
        }
        UsbAccessory accessory = (UsbAccessory) obj;
        return compare(this.mManufacturer, accessory.getManufacturer()) && compare(this.mModel, accessory.getModel()) && compare(this.mDescription, accessory.getDescription()) && compare(this.mVersion, accessory.getVersion()) && compare(this.mUri, accessory.getUri()) && compare(this.mSerial, accessory.getSerial());
    }

    public int hashCode() {
        String str = this.mManufacturer;
        int iHashCode = str == null ? 0 : str.hashCode();
        String str2 = this.mModel;
        int iHashCode2 = iHashCode ^ (str2 == null ? 0 : str2.hashCode());
        String str3 = this.mDescription;
        int iHashCode3 = iHashCode2 ^ (str3 == null ? 0 : str3.hashCode());
        String str4 = this.mVersion;
        int iHashCode4 = iHashCode3 ^ (str4 == null ? 0 : str4.hashCode());
        String str5 = this.mUri;
        int iHashCode5 = iHashCode4 ^ (str5 == null ? 0 : str5.hashCode());
        String str6 = this.mSerial;
        return iHashCode5 ^ (str6 != null ? str6.hashCode() : 0);
    }

    public String toString() {
        return "UsbAccessory[mManufacturer=" + this.mManufacturer + ", mModel=" + this.mModel + ", mDescription=" + this.mDescription + ", mVersion=" + this.mVersion + ", mUri=" + this.mUri + ", mSerial=" + this.mSerial + "]";
    }
}
