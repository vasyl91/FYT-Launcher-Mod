package android.accounts;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public interface AccountManagerCallback<V> {
    void run(AccountManagerFuture<V> accountManagerFuture);
}
