package android.accounts;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public interface OnAccountsUpdateListener {
    void onAccountsUpdated(Account[] accountArr);
}
