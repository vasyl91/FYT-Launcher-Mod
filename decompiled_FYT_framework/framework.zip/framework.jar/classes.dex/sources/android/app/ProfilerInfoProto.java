package android.app;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public final class ProfilerInfoProto {
    public static final long AGENT = 1138166333446L;
    public static final long AUTO_STOP_PROFILER = 1133871366148L;
    public static final long PROFILE_FD = 1120986464258L;
    public static final long PROFILE_FILE = 1138166333441L;
    public static final long SAMPLING_INTERVAL = 1120986464259L;
    public static final long STREAMING_OUTPUT = 1133871366149L;
}
