package android.app.sprdpower;

import android.content.Context;
import android.util.Log;
import java.lang.reflect.Constructor;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class PowerGuruFactory {
    private static final String TAG = "PowerGuruFactory";
    private static PowerGuruFactory sInstance;

    public static synchronized PowerGuruFactory getInstance() {
        synchronized (PowerGuruFactory.class) {
            if (sInstance != null) {
                return sInstance;
            }
            Class clazz = null;
            try {
                clazz = Class.forName("android.app.sprdpower.PowerGuruFactoryEx");
            } catch (Throwable th) {
                Log.d(TAG, "Can't find specific PowerGuruFactoryEx");
            }
            if (clazz != null) {
                try {
                    Constructor ctor = clazz.getDeclaredConstructor(new Class[0]);
                    if (ctor != null) {
                        sInstance = (PowerGuruFactory) ctor.newInstance(new Object[0]);
                    }
                } catch (Throwable th2) {
                    Log.e(TAG, "Can't create specific ObjectFactory");
                }
            }
            if (sInstance == null) {
                sInstance = new PowerGuruFactory();
            }
            return sInstance;
        }
    }

    public AbsPowerGuru createExtraPowerGuru(IPowerGuru service, Context context) {
        return new AbsPowerGuru(service, context) { // from class: android.app.sprdpower.PowerGuruFactory.1
        };
    }
}
