package android.app.sprdpower;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.WorkSource;
import java.util.List;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public interface IPowerGuru extends IInterface {
    boolean addConstrainedListAppBySystem(String str) throws RemoteException;

    boolean addWhiteAppfromList(String str) throws RemoteException;

    boolean delWhiteAppfromList(String str) throws RemoteException;

    List<PowerGuruAlarmInfo> getBeatList() throws RemoteException;

    int getOrignalAlignInterval() throws RemoteException;

    int getWakeupAlarmCount(String str) throws RemoteException;

    List<String> getWhiteCandicateList() throws RemoteException;

    List<String> getWhiteList() throws RemoteException;

    void noteWakeupAlarm(String str, int i) throws RemoteException;

    boolean notifyAlarm(int i, long j, long j2, long j3, long j4, long j5, PendingIntent pendingIntent, int i2, WorkSource workSource, AlarmManager.AlarmClockInfo alarmClockInfo, int i3, String str) throws RemoteException;

    void notifyDozeStateChanged() throws RemoteException;

    boolean notifyPowerguruAlarm(int i, long j, long j2, long j3, long j4, long j5, PendingIntent pendingIntent) throws RemoteException;

    boolean removeConstrainedListAppBySystem(String str) throws RemoteException;

    boolean setAlignInterval(int i) throws RemoteException;

    void testHello() throws RemoteException;

    public static class Default implements IPowerGuru {
        @Override // android.app.sprdpower.IPowerGuru
        public void testHello() throws RemoteException {
        }

        @Override // android.app.sprdpower.IPowerGuru
        public boolean notifyPowerguruAlarm(int type, long when, long whenElapsed, long windowLength, long maxWhen, long interval, PendingIntent operation) throws RemoteException {
            return false;
        }

        @Override // android.app.sprdpower.IPowerGuru
        public boolean notifyAlarm(int type, long when, long whenElapsed, long windowLength, long maxWhen, long interval, PendingIntent operation, int flags, WorkSource workSource, AlarmManager.AlarmClockInfo alarmClock, int uid, String pkgName) throws RemoteException {
            return false;
        }

        @Override // android.app.sprdpower.IPowerGuru
        public List<PowerGuruAlarmInfo> getBeatList() throws RemoteException {
            return null;
        }

        @Override // android.app.sprdpower.IPowerGuru
        public List<String> getWhiteList() throws RemoteException {
            return null;
        }

        @Override // android.app.sprdpower.IPowerGuru
        public boolean delWhiteAppfromList(String appname) throws RemoteException {
            return false;
        }

        @Override // android.app.sprdpower.IPowerGuru
        public List<String> getWhiteCandicateList() throws RemoteException {
            return null;
        }

        @Override // android.app.sprdpower.IPowerGuru
        public boolean addWhiteAppfromList(String appname) throws RemoteException {
            return false;
        }

        @Override // android.app.sprdpower.IPowerGuru
        public boolean addConstrainedListAppBySystem(String name) throws RemoteException {
            return false;
        }

        @Override // android.app.sprdpower.IPowerGuru
        public boolean removeConstrainedListAppBySystem(String name) throws RemoteException {
            return false;
        }

        @Override // android.app.sprdpower.IPowerGuru
        public int getOrignalAlignInterval() throws RemoteException {
            return 0;
        }

        @Override // android.app.sprdpower.IPowerGuru
        public boolean setAlignInterval(int interval) throws RemoteException {
            return false;
        }

        @Override // android.app.sprdpower.IPowerGuru
        public void notifyDozeStateChanged() throws RemoteException {
        }

        @Override // android.app.sprdpower.IPowerGuru
        public void noteWakeupAlarm(String sourcePkg, int sourceUid) throws RemoteException {
        }

        @Override // android.app.sprdpower.IPowerGuru
        public int getWakeupAlarmCount(String pkgName) throws RemoteException {
            return 0;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }
    }

    public static abstract class Stub extends Binder implements IPowerGuru {
        private static final String DESCRIPTOR = "android.app.sprdpower.IPowerGuru";
        static final int TRANSACTION_addConstrainedListAppBySystem = 9;
        static final int TRANSACTION_addWhiteAppfromList = 8;
        static final int TRANSACTION_delWhiteAppfromList = 6;
        static final int TRANSACTION_getBeatList = 4;
        static final int TRANSACTION_getOrignalAlignInterval = 11;
        static final int TRANSACTION_getWakeupAlarmCount = 15;
        static final int TRANSACTION_getWhiteCandicateList = 7;
        static final int TRANSACTION_getWhiteList = 5;
        static final int TRANSACTION_noteWakeupAlarm = 14;
        static final int TRANSACTION_notifyAlarm = 3;
        static final int TRANSACTION_notifyDozeStateChanged = 13;
        static final int TRANSACTION_notifyPowerguruAlarm = 2;
        static final int TRANSACTION_removeConstrainedListAppBySystem = 10;
        static final int TRANSACTION_setAlignInterval = 12;
        static final int TRANSACTION_testHello = 1;

        public Stub() {
            attachInterface(this, DESCRIPTOR);
        }

        public static IPowerGuru asInterface(IBinder obj) {
            if (obj == null) {
                return null;
            }
            IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
            if (iin != null && (iin instanceof IPowerGuru)) {
                return (IPowerGuru) iin;
            }
            return new Proxy(obj);
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        public static String getDefaultTransactionName(int transactionCode) {
            switch (transactionCode) {
                case 1:
                    return "testHello";
                case 2:
                    return "notifyPowerguruAlarm";
                case 3:
                    return "notifyAlarm";
                case 4:
                    return "getBeatList";
                case 5:
                    return "getWhiteList";
                case 6:
                    return "delWhiteAppfromList";
                case 7:
                    return "getWhiteCandicateList";
                case 8:
                    return "addWhiteAppfromList";
                case 9:
                    return "addConstrainedListAppBySystem";
                case 10:
                    return "removeConstrainedListAppBySystem";
                case 11:
                    return "getOrignalAlignInterval";
                case 12:
                    return "setAlignInterval";
                case 13:
                    return "notifyDozeStateChanged";
                case 14:
                    return "noteWakeupAlarm";
                case 15:
                    return "getWakeupAlarmCount";
                default:
                    return null;
            }
        }

        public String getTransactionName(int transactionCode) {
            return getDefaultTransactionName(transactionCode);
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            PendingIntent pendingIntent;
            PendingIntent pendingIntent2;
            WorkSource workSource;
            AlarmManager.AlarmClockInfo alarmClockInfo;
            if (i == 1598968902) {
                parcel2.writeString(DESCRIPTOR);
                return true;
            }
            switch (i) {
                case 1:
                    parcel.enforceInterface(DESCRIPTOR);
                    testHello();
                    parcel2.writeNoException();
                    return true;
                case 2:
                    parcel.enforceInterface(DESCRIPTOR);
                    int readInt = parcel.readInt();
                    long readLong = parcel.readLong();
                    long readLong2 = parcel.readLong();
                    long readLong3 = parcel.readLong();
                    long readLong4 = parcel.readLong();
                    long readLong5 = parcel.readLong();
                    if (parcel.readInt() != 0) {
                        pendingIntent = PendingIntent.CREATOR.createFromParcel(parcel);
                    } else {
                        pendingIntent = null;
                    }
                    boolean notifyPowerguruAlarm = notifyPowerguruAlarm(readInt, readLong, readLong2, readLong3, readLong4, readLong5, pendingIntent);
                    parcel2.writeNoException();
                    parcel2.writeInt(notifyPowerguruAlarm ? 1 : 0);
                    return true;
                case 3:
                    parcel.enforceInterface(DESCRIPTOR);
                    int readInt2 = parcel.readInt();
                    long readLong6 = parcel.readLong();
                    long readLong7 = parcel.readLong();
                    long readLong8 = parcel.readLong();
                    long readLong9 = parcel.readLong();
                    long readLong10 = parcel.readLong();
                    if (parcel.readInt() != 0) {
                        pendingIntent2 = PendingIntent.CREATOR.createFromParcel(parcel);
                    } else {
                        pendingIntent2 = null;
                    }
                    int readInt3 = parcel.readInt();
                    if (parcel.readInt() != 0) {
                        workSource = (WorkSource) WorkSource.CREATOR.createFromParcel(parcel);
                    } else {
                        workSource = null;
                    }
                    if (parcel.readInt() != 0) {
                        alarmClockInfo = AlarmManager.AlarmClockInfo.CREATOR.createFromParcel(parcel);
                    } else {
                        alarmClockInfo = null;
                    }
                    boolean notifyAlarm = notifyAlarm(readInt2, readLong6, readLong7, readLong8, readLong9, readLong10, pendingIntent2, readInt3, workSource, alarmClockInfo, parcel.readInt(), parcel.readString());
                    parcel2.writeNoException();
                    parcel2.writeInt(notifyAlarm ? 1 : 0);
                    return true;
                case 4:
                    parcel.enforceInterface(DESCRIPTOR);
                    List<PowerGuruAlarmInfo> beatList = getBeatList();
                    parcel2.writeNoException();
                    parcel2.writeTypedList(beatList);
                    return true;
                case 5:
                    parcel.enforceInterface(DESCRIPTOR);
                    List<String> whiteList = getWhiteList();
                    parcel2.writeNoException();
                    parcel2.writeStringList(whiteList);
                    return true;
                case 6:
                    parcel.enforceInterface(DESCRIPTOR);
                    boolean delWhiteAppfromList = delWhiteAppfromList(parcel.readString());
                    parcel2.writeNoException();
                    parcel2.writeInt(delWhiteAppfromList ? 1 : 0);
                    return true;
                case 7:
                    parcel.enforceInterface(DESCRIPTOR);
                    List<String> whiteCandicateList = getWhiteCandicateList();
                    parcel2.writeNoException();
                    parcel2.writeStringList(whiteCandicateList);
                    return true;
                case 8:
                    parcel.enforceInterface(DESCRIPTOR);
                    boolean addWhiteAppfromList = addWhiteAppfromList(parcel.readString());
                    parcel2.writeNoException();
                    parcel2.writeInt(addWhiteAppfromList ? 1 : 0);
                    return true;
                case 9:
                    parcel.enforceInterface(DESCRIPTOR);
                    boolean addConstrainedListAppBySystem = addConstrainedListAppBySystem(parcel.readString());
                    parcel2.writeNoException();
                    parcel2.writeInt(addConstrainedListAppBySystem ? 1 : 0);
                    return true;
                case 10:
                    parcel.enforceInterface(DESCRIPTOR);
                    boolean removeConstrainedListAppBySystem = removeConstrainedListAppBySystem(parcel.readString());
                    parcel2.writeNoException();
                    parcel2.writeInt(removeConstrainedListAppBySystem ? 1 : 0);
                    return true;
                case 11:
                    parcel.enforceInterface(DESCRIPTOR);
                    int orignalAlignInterval = getOrignalAlignInterval();
                    parcel2.writeNoException();
                    parcel2.writeInt(orignalAlignInterval);
                    return true;
                case 12:
                    parcel.enforceInterface(DESCRIPTOR);
                    boolean alignInterval = setAlignInterval(parcel.readInt());
                    parcel2.writeNoException();
                    parcel2.writeInt(alignInterval ? 1 : 0);
                    return true;
                case 13:
                    parcel.enforceInterface(DESCRIPTOR);
                    notifyDozeStateChanged();
                    parcel2.writeNoException();
                    return true;
                case 14:
                    parcel.enforceInterface(DESCRIPTOR);
                    noteWakeupAlarm(parcel.readString(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 15:
                    parcel.enforceInterface(DESCRIPTOR);
                    int wakeupAlarmCount = getWakeupAlarmCount(parcel.readString());
                    parcel2.writeNoException();
                    parcel2.writeInt(wakeupAlarmCount);
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }

        private static class Proxy implements IPowerGuru {
            public static IPowerGuru sDefaultImpl;
            private IBinder mRemote;

            Proxy(IBinder remote) {
                this.mRemote = remote;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return Stub.DESCRIPTOR;
            }

            @Override // android.app.sprdpower.IPowerGuru
            public void testHello() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    boolean _status = this.mRemote.transact(1, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().testHello();
                    } else {
                        _reply.readException();
                    }
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public boolean notifyPowerguruAlarm(int type, long when, long whenElapsed, long windowLength, long maxWhen, long interval, PendingIntent operation) throws RemoteException {
                Parcel _reply;
                Parcel _data = Parcel.obtain();
                Parcel _reply2 = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeInt(type);
                    _data.writeLong(when);
                    _data.writeLong(whenElapsed);
                    _data.writeLong(windowLength);
                    _data.writeLong(maxWhen);
                    _data.writeLong(interval);
                    if (operation != null) {
                        try {
                            _data.writeInt(1);
                            operation.writeToParcel(_data, 0);
                        } catch (Throwable th) {
                            th = th;
                            _reply = _reply2;
                            _reply.recycle();
                            _data.recycle();
                            throw th;
                        }
                    } else {
                        _data.writeInt(0);
                    }
                    boolean _status = this.mRemote.transact(2, _data, _reply2, 0);
                    try {
                        if (!_status && Stub.getDefaultImpl() != null) {
                            boolean notifyPowerguruAlarm = Stub.getDefaultImpl().notifyPowerguruAlarm(type, when, whenElapsed, windowLength, maxWhen, interval, operation);
                            _reply2.recycle();
                            _data.recycle();
                            return notifyPowerguruAlarm;
                        }
                        _reply2.readException();
                        boolean _status2 = _reply2.readInt() != 0;
                        _reply2.recycle();
                        _data.recycle();
                        return _status2;
                    } catch (Throwable th2) {
                        th = th2;
                        _reply.recycle();
                        _data.recycle();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    _reply = _reply2;
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public boolean notifyAlarm(int type, long when, long whenElapsed, long windowLength, long maxWhen, long interval, PendingIntent operation, int flags, WorkSource workSource, AlarmManager.AlarmClockInfo alarmClock, int uid, String pkgName) throws RemoteException {
                Parcel _data;
                Parcel _reply;
                int i;
                Parcel _data2 = Parcel.obtain();
                Parcel _reply2 = Parcel.obtain();
                try {
                    _data2.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data2.writeInt(type);
                    _data2.writeLong(when);
                    _data2.writeLong(whenElapsed);
                    _data2.writeLong(windowLength);
                    _data2.writeLong(maxWhen);
                    _data2.writeLong(interval);
                    if (operation != null) {
                        try {
                            _data2.writeInt(1);
                            operation.writeToParcel(_data2, 0);
                        } catch (Throwable th) {
                            th = th;
                            _data = _data2;
                            _reply = _reply2;
                            _reply.recycle();
                            _data.recycle();
                            throw th;
                        }
                    } else {
                        _data2.writeInt(0);
                    }
                    _data2.writeInt(flags);
                    if (workSource != null) {
                        _data2.writeInt(1);
                        i = 0;
                        workSource.writeToParcel(_data2, 0);
                    } else {
                        i = 0;
                        _data2.writeInt(0);
                    }
                    if (alarmClock != null) {
                        _data2.writeInt(1);
                        alarmClock.writeToParcel(_data2, 0);
                    } else {
                        _data2.writeInt(i);
                    }
                    _data2.writeInt(uid);
                    _data2.writeString(pkgName);
                    boolean _status = this.mRemote.transact(3, _data2, _reply2, 0);
                    try {
                        if (!_status && Stub.getDefaultImpl() != null) {
                            boolean notifyAlarm = Stub.getDefaultImpl().notifyAlarm(type, when, whenElapsed, windowLength, maxWhen, interval, operation, flags, workSource, alarmClock, uid, pkgName);
                            _reply2.recycle();
                            _data2.recycle();
                            return notifyAlarm;
                        }
                        _reply2.readException();
                        boolean _status2 = _reply2.readInt() != 0;
                        _reply2.recycle();
                        _data2.recycle();
                        return _status2;
                    } catch (Throwable th2) {
                        th = th2;
                        _reply.recycle();
                        _data.recycle();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    _data = _data2;
                    _reply = _reply2;
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public List<PowerGuruAlarmInfo> getBeatList() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    boolean _status = this.mRemote.transact(4, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getBeatList();
                    }
                    _reply.readException();
                    List<PowerGuruAlarmInfo> _result = _reply.createTypedArrayList(PowerGuruAlarmInfo.CREATOR);
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public List<String> getWhiteList() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    boolean _status = this.mRemote.transact(5, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getWhiteList();
                    }
                    _reply.readException();
                    List<String> _result = _reply.createStringArrayList();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public boolean delWhiteAppfromList(String appname) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(appname);
                    boolean _status = this.mRemote.transact(6, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().delWhiteAppfromList(appname);
                    }
                    _reply.readException();
                    boolean _status2 = _reply.readInt() != 0;
                    return _status2;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public List<String> getWhiteCandicateList() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    boolean _status = this.mRemote.transact(7, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getWhiteCandicateList();
                    }
                    _reply.readException();
                    List<String> _result = _reply.createStringArrayList();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public boolean addWhiteAppfromList(String appname) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(appname);
                    boolean _status = this.mRemote.transact(8, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().addWhiteAppfromList(appname);
                    }
                    _reply.readException();
                    boolean _status2 = _reply.readInt() != 0;
                    return _status2;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public boolean addConstrainedListAppBySystem(String name) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(name);
                    boolean _status = this.mRemote.transact(9, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().addConstrainedListAppBySystem(name);
                    }
                    _reply.readException();
                    boolean _status2 = _reply.readInt() != 0;
                    return _status2;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public boolean removeConstrainedListAppBySystem(String name) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(name);
                    boolean _status = this.mRemote.transact(10, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().removeConstrainedListAppBySystem(name);
                    }
                    _reply.readException();
                    boolean _status2 = _reply.readInt() != 0;
                    return _status2;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public int getOrignalAlignInterval() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    boolean _status = this.mRemote.transact(11, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getOrignalAlignInterval();
                    }
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public boolean setAlignInterval(int interval) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeInt(interval);
                    boolean _status = this.mRemote.transact(12, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().setAlignInterval(interval);
                    }
                    _reply.readException();
                    boolean _status2 = _reply.readInt() != 0;
                    return _status2;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public void notifyDozeStateChanged() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    boolean _status = this.mRemote.transact(13, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().notifyDozeStateChanged();
                    } else {
                        _reply.readException();
                    }
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public void noteWakeupAlarm(String sourcePkg, int sourceUid) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(sourcePkg);
                    _data.writeInt(sourceUid);
                    boolean _status = this.mRemote.transact(14, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().noteWakeupAlarm(sourcePkg, sourceUid);
                    } else {
                        _reply.readException();
                    }
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.sprdpower.IPowerGuru
            public int getWakeupAlarmCount(String pkgName) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(pkgName);
                    boolean _status = this.mRemote.transact(15, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getWakeupAlarmCount(pkgName);
                    }
                    _reply.readException();
                    int _result = _reply.readInt();
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }
        }

        public static boolean setDefaultImpl(IPowerGuru impl) {
            if (Proxy.sDefaultImpl == null && impl != null) {
                Proxy.sDefaultImpl = impl;
                return true;
            }
            return false;
        }

        public static IPowerGuru getDefaultImpl() {
            return Proxy.sDefaultImpl;
        }
    }
}
