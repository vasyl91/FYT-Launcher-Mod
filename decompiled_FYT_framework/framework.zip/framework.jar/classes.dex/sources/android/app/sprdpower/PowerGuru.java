package android.app.sprdpower;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.os.RemoteException;
import android.os.WorkSource;
import android.util.Slog;
import java.util.List;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class PowerGuru extends AbsPowerGuru {
    private static final String TAG = "PowerGuru";
    private final IPowerGuru mService;

    PowerGuru(IPowerGuru service, Context ctx) {
        super(service, ctx);
        this.mService = service;
    }

    @Override // android.app.sprdpower.AbsPowerGuru
    public void testHello() {
        try {
            this.mService.testHello();
        } catch (RemoteException ex) {
            loge("remote err:" + ex);
        }
    }

    @Override // android.app.sprdpower.AbsPowerGuru
    public boolean notifyPowerguruAlarm(int type, long when, long whenElapsed, long windowLength, long maxWhen, long interval, PendingIntent operation) {
        try {
            return this.mService.notifyPowerguruAlarm(type, when, whenElapsed, windowLength, maxWhen, interval, operation);
        } catch (RemoteException ex) {
            loge("remote err:" + ex);
            return false;
        }
    }

    @Override // android.app.sprdpower.AbsPowerGuru
    public boolean notifyAlarm(int type, long when, long whenElapsed, long windowLength, long maxWhen, long interval, PendingIntent operation, int flags, WorkSource workSource, AlarmManager.AlarmClockInfo alarmClock, int uid, String pkgName) {
        try {
            return this.mService.notifyAlarm(type, when, whenElapsed, windowLength, maxWhen, interval, operation, flags, workSource, alarmClock, uid, pkgName);
        } catch (RemoteException ex) {
            loge("remote err:" + ex);
            return false;
        }
    }

    @Override // android.app.sprdpower.AbsPowerGuru
    public List<PowerGuruAlarmInfo> getBeatList() {
        try {
            return this.mService.getBeatList();
        } catch (RemoteException ex) {
            loge("remote err:" + ex);
            return null;
        }
    }

    @Override // android.app.sprdpower.AbsPowerGuru
    public List<String> getWhiteList() {
        try {
            return this.mService.getWhiteList();
        } catch (RemoteException ex) {
            loge("remote err:" + ex);
            return null;
        }
    }

    @Override // android.app.sprdpower.AbsPowerGuru
    public boolean delWhiteAppfromList(String appname) {
        try {
            return this.mService.delWhiteAppfromList(appname);
        } catch (RemoteException ex) {
            loge("remote err:" + ex);
            return false;
        }
    }

    @Override // android.app.sprdpower.AbsPowerGuru
    public List<String> getWhiteCandicateList() {
        try {
            return this.mService.getWhiteCandicateList();
        } catch (RemoteException ex) {
            loge("remote err:" + ex);
            return null;
        }
    }

    @Override // android.app.sprdpower.AbsPowerGuru
    public boolean addWhiteAppfromList(String appname) {
        try {
            return this.mService.addWhiteAppfromList(appname);
        } catch (RemoteException ex) {
            loge("remote err:" + ex);
            return false;
        }
    }

    @Override // android.app.sprdpower.AbsPowerGuru
    public void noteWakeupAlarm(String sourcePkg, int sourceUid) {
        try {
            this.mService.noteWakeupAlarm(sourcePkg, sourceUid);
        } catch (RemoteException ex) {
            loge("remote err:" + ex);
        }
    }

    private void loge(String info) {
        Slog.e(TAG, info);
    }

    private void logd(String info) {
        Slog.d(TAG, info);
    }
}
