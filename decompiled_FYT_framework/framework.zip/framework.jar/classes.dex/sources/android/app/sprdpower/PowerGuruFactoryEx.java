package android.app.sprdpower;

import android.content.Context;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class PowerGuruFactoryEx extends PowerGuruFactory {
    @Override // android.app.sprdpower.PowerGuruFactory
    public AbsPowerGuru createExtraPowerGuru(IPowerGuru service, Context context) {
        return new PowerGuru(service, context);
    }
}
