package android.app;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public final class ActivityManagerProto {
    public static final int UID_OBSERVER_FLAG_ACTIVE = 4;
    public static final int UID_OBSERVER_FLAG_CACHED = 5;
    public static final int UID_OBSERVER_FLAG_GONE = 2;
    public static final int UID_OBSERVER_FLAG_IDLE = 3;
    public static final int UID_OBSERVER_FLAG_PROCSTATE = 1;
}
