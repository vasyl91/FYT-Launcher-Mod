package android.app;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

/* compiled from: PerformanceManagerNative.java */
/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
class PerformanceManagerProxy implements IPerformanceManager {
    private IBinder mRemote;

    public PerformanceManagerProxy(IBinder remote) {
        this.mRemote = remote;
    }

    @Override // android.os.IInterface
    public IBinder asBinder() {
        return this.mRemote;
    }

    @Override // android.app.IPerformanceManager
    public String reclaimProcess(int pid, String type) throws RemoteException {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        data.writeInterfaceToken(IPerformanceManager.descriptor);
        data.writeInt(pid);
        data.writeString(type);
        this.mRemote.transact(1, data, reply, 0);
        String result = reply.readString();
        data.recycle();
        reply.recycle();
        return result;
    }

    @Override // android.app.IPerformanceManager
    public void enableBoostKill(int enable) throws RemoteException {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        data.writeInterfaceToken(IPerformanceManager.descriptor);
        data.writeInt(enable);
        this.mRemote.transact(2, data, reply, 0);
        data.recycle();
        reply.recycle();
    }

    @Override // android.app.IPerformanceManager
    public boolean reclaimProcessEnabled() throws RemoteException {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        data.writeInterfaceToken(IPerformanceManager.descriptor);
        this.mRemote.transact(3, data, reply, 0);
        boolean enable = reply.readInt() == 1;
        data.recycle();
        reply.recycle();
        return enable;
    }

    @Override // android.app.IPerformanceManager
    public String readProcFile(String file) throws RemoteException {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        data.writeInterfaceToken(IPerformanceManager.descriptor);
        data.writeString(file);
        this.mRemote.transact(4, data, reply, 0);
        String result = reply.readString();
        data.recycle();
        reply.recycle();
        return result;
    }

    @Override // android.app.IPerformanceManager
    public void writeProcFile(String file, String value) throws RemoteException {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        data.writeInterfaceToken(IPerformanceManager.descriptor);
        data.writeString(file);
        data.writeString(value);
        this.mRemote.transact(5, data, reply, 0);
        data.recycle();
        reply.recycle();
    }

    @Override // android.app.IPerformanceManager
    public long fetchIfCacheMiss(String str, long[] jArr, int[] iArr, boolean z, boolean z2) throws RemoteException {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        obtain.writeInterfaceToken(IPerformanceManager.descriptor);
        obtain.writeString(str);
        obtain.writeLongArray(jArr);
        obtain.writeIntArray(iArr);
        obtain.writeInt(z ? 1 : 0);
        obtain.writeInt(z2 ? 1 : 0);
        this.mRemote.transact(6, obtain, obtain2, 0);
        long readLong = obtain2.readLong();
        obtain.recycle();
        obtain2.recycle();
        return readLong;
    }

    @Override // android.app.IPerformanceManager
    public void freeFetchData(long addr, int length) throws RemoteException {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        data.writeInterfaceToken(IPerformanceManager.descriptor);
        data.writeLong(addr);
        data.writeInt(length);
        this.mRemote.transact(7, data, reply, 0);
        data.recycle();
        reply.recycle();
    }

    @Override // android.app.IPerformanceManager
    public String getBlockDevName(String dirName) throws RemoteException {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        data.writeInterfaceToken(IPerformanceManager.descriptor);
        data.writeString(dirName);
        this.mRemote.transact(8, data, reply, 0);
        String result = reply.readString();
        data.recycle();
        reply.recycle();
        return result;
    }
}
