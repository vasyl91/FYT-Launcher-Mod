package android.app;

import android.util.Log;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class UserHabit {
    private static final String ATTR_LAST_FG_TIME = "lastFgTime";
    private static final String ATTR_LAST_USE_Time = "lastUseTime";
    private static final String ATTR_LAUNCH_COUNT = "launchCount";
    private static final String ATTR_PKG = "pkgName";
    private static final String ATTR_RECENT_LAUNCH_TIME = "recentLaunchTime";
    private static final String ATTR_TOTAL_FG_TIME = "totalForegroundTime";
    private static final String ATTR_USERID = "userid";
    private static final int RECENT_LAUNCH_TIME_COUNT = 10;
    private static final String TAG = "UserHabit";
    public long lastForegroundTime;
    public long lastUseTime;
    public long launchCount;
    public int mLastEvent;
    private ArrayList<String> mLaunchTime;
    public Integer mUserId;
    public String packageName;
    public long totalForegroundTime;

    public UserHabit(String packageName, Integer userId) {
        this.mLaunchTime = new ArrayList<>();
        this.packageName = packageName;
        this.launchCount = 0L;
        this.totalForegroundTime = 0L;
        this.mLastEvent = -1;
        this.lastForegroundTime = 0L;
        this.lastUseTime = 0L;
        this.mUserId = userId;
    }

    public UserHabit(String packageName, int launchCount, long totalForegroundTime, long lastForegroundTime, long lastUseTime, int mUserId) {
        this.mLaunchTime = new ArrayList<>();
        this.packageName = packageName;
        this.launchCount = launchCount;
        this.totalForegroundTime = totalForegroundTime;
        this.mLastEvent = -1;
        this.lastForegroundTime = lastForegroundTime;
        this.lastUseTime = lastUseTime;
        this.mUserId = Integer.valueOf(mUserId);
    }

    public UserHabit() {
        this.mLaunchTime = new ArrayList<>();
        this.mLastEvent = -1;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("");
        synchronized (this.mLaunchTime) {
            Iterator<String> it = this.mLaunchTime.iterator();
            while (it.hasNext()) {
                String s = it.next();
                sb.append(s);
                sb.append(";");
            }
        }
        String tmp = sb.toString();
        return "UID:" + this.mUserId + "|pkg:" + this.packageName + "|count:" + this.launchCount + "|LastUsed:" + this.lastUseTime + "|totalForegroundTime" + this.totalForegroundTime + "|launchTime:" + tmp;
    }

    public void updateLaunchTime(String newVal) {
        synchronized (this.mLaunchTime) {
            this.mLaunchTime.add(newVal);
            if (this.mLaunchTime.size() >= 10) {
                this.mLaunchTime.remove(0);
            }
        }
    }

    public void writeToFile(String pkg, XmlSerializer serializer) throws IOException, XmlPullParserException {
        serializer.attribute(null, ATTR_USERID, String.valueOf(this.mUserId));
        serializer.attribute(null, ATTR_PKG, this.packageName);
        serializer.attribute(null, ATTR_LAUNCH_COUNT, String.valueOf(this.launchCount));
        serializer.attribute(null, ATTR_TOTAL_FG_TIME, String.valueOf(this.totalForegroundTime));
        serializer.attribute(null, ATTR_LAST_FG_TIME, String.valueOf(this.lastForegroundTime));
        serializer.attribute(null, ATTR_LAST_USE_Time, String.valueOf(this.lastUseTime));
        StringBuilder sb = new StringBuilder("");
        synchronized (this.mLaunchTime) {
            Iterator<String> it = this.mLaunchTime.iterator();
            while (it.hasNext()) {
                String s = it.next();
                sb.append(s);
                sb.append(";");
            }
        }
        String tmp = sb.toString();
        serializer.attribute(null, ATTR_RECENT_LAUNCH_TIME, tmp);
    }

    public static UserHabit restoreFromFile(XmlPullParser in) throws IOException, XmlPullParserException {
        UserHabit habit = new UserHabit();
        for (int attrNdx = in.getAttributeCount() - 1; attrNdx >= 0; attrNdx--) {
            String attrName = in.getAttributeName(attrNdx);
            String attrValue = in.getAttributeValue(attrNdx);
            if (ATTR_USERID.equals(attrName)) {
                habit.mUserId = Integer.valueOf(attrValue);
            } else if (ATTR_PKG.equals(attrName)) {
                habit.packageName = attrValue;
            } else if (ATTR_LAUNCH_COUNT.equals(attrName)) {
                habit.launchCount = Long.valueOf(attrValue).longValue();
            } else if (ATTR_TOTAL_FG_TIME.equals(attrName)) {
                habit.totalForegroundTime = Long.valueOf(attrValue).longValue();
            } else if (ATTR_LAST_FG_TIME.equals(attrName)) {
                habit.lastForegroundTime = Long.valueOf(attrValue).longValue();
            } else if (ATTR_LAST_USE_Time.equals(attrName)) {
                habit.lastUseTime = Long.valueOf(attrValue).longValue();
            } else if (ATTR_RECENT_LAUNCH_TIME.equals(attrName)) {
                String[] tmp = attrValue.split(";");
                for (String s : tmp) {
                    habit.mLaunchTime.add(s);
                }
            } else {
                Log.e(TAG, "error attr name....:" + attrName);
            }
        }
        return habit;
    }

    /* renamed from: clone, reason: merged with bridge method [inline-methods] */
    public UserHabit m18clone() {
        UserHabit out = new UserHabit();
        out.packageName = this.packageName;
        out.launchCount = this.launchCount;
        out.totalForegroundTime = this.totalForegroundTime;
        out.mLastEvent = this.mLastEvent;
        out.lastForegroundTime = this.lastForegroundTime;
        out.lastUseTime = this.lastUseTime;
        out.mUserId = this.mUserId;
        out.mLaunchTime = (ArrayList) this.mLaunchTime.clone();
        return out;
    }

    public long getTotalTimeInForeground() {
        return this.totalForegroundTime;
    }

    public String getPackageName() {
        return this.packageName;
    }

    public long getLastTimeUsed() {
        return this.lastUseTime;
    }

    public long getLastForegroundTime() {
        return this.lastForegroundTime;
    }

    public ArrayList<String> getRecentLaunchTime() {
        ArrayList<String> list;
        synchronized (this.mLaunchTime) {
            list = (ArrayList) this.mLaunchTime.clone();
        }
        return list;
    }
}
