package android.app;

import android.os.IInterface;
import android.os.RemoteException;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public interface IPerformanceManager extends IInterface {
    public static final int ENALBE_BOOSTKILL = 2;
    public static final int EXTRA_FETCH = 6;
    public static final int EXTRA_FETCH_FREE_DATA = 7;
    public static final int GET_BLOCKDEV_NAME = 8;
    public static final int PROCESS_RECLAIM_ENABLED = 3;
    public static final int READ_PROC_FILE = 4;
    public static final int RECLAIM_PROCESS = 1;
    public static final int WRITE_PROC_FILE = 5;
    public static final String descriptor = "com.android.server.performance";

    void enableBoostKill(int i) throws RemoteException;

    long fetchIfCacheMiss(String str, long[] jArr, int[] iArr, boolean z, boolean z2) throws RemoteException;

    void freeFetchData(long j, int i) throws RemoteException;

    String getBlockDevName(String str) throws RemoteException;

    String readProcFile(String str) throws RemoteException;

    String reclaimProcess(int i, String str) throws RemoteException;

    boolean reclaimProcessEnabled() throws RemoteException;

    void writeProcFile(String str, String str2) throws RemoteException;
}
