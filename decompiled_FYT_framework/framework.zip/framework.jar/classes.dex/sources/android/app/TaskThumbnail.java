package android.app;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import java.io.IOException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class TaskThumbnail implements Parcelable {
    public static final Parcelable.Creator<TaskThumbnail> CREATOR = new Parcelable.Creator<TaskThumbnail>() { // from class: android.app.TaskThumbnail.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public TaskThumbnail createFromParcel(Parcel source) {
            return new TaskThumbnail(source);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public TaskThumbnail[] newArray(int size) {
            return new TaskThumbnail[size];
        }
    };
    public Bitmap mainThumbnail;
    public ParcelFileDescriptor thumbnailFileDescriptor;
    public TaskThumbnailInfo thumbnailInfo;

    public TaskThumbnail() {
    }

    private TaskThumbnail(Parcel source) {
        readFromParcel(source);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        ParcelFileDescriptor parcelFileDescriptor = this.thumbnailFileDescriptor;
        if (parcelFileDescriptor != null) {
            return parcelFileDescriptor.describeContents();
        }
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        if (this.mainThumbnail != null) {
            dest.writeInt(1);
            this.mainThumbnail.writeToParcel(dest, flags);
        } else {
            dest.writeInt(0);
        }
        if (this.thumbnailFileDescriptor != null) {
            dest.writeInt(1);
            this.thumbnailFileDescriptor.writeToParcel(dest, flags);
        } else {
            dest.writeInt(0);
        }
        if (this.thumbnailInfo != null) {
            dest.writeInt(1);
            this.thumbnailInfo.writeToParcel(dest, flags);
        } else {
            dest.writeInt(0);
        }
    }

    public void readFromParcel(Parcel source) {
        if (source.readInt() != 0) {
            this.mainThumbnail = Bitmap.CREATOR.createFromParcel(source);
        } else {
            this.mainThumbnail = null;
        }
        if (source.readInt() != 0) {
            this.thumbnailFileDescriptor = (ParcelFileDescriptor) ParcelFileDescriptor.CREATOR.createFromParcel(source);
        } else {
            this.thumbnailFileDescriptor = null;
        }
        if (source.readInt() != 0) {
            this.thumbnailInfo = TaskThumbnailInfo.CREATOR.createFromParcel(source);
        } else {
            this.thumbnailInfo = null;
        }
    }

    public static class TaskThumbnailInfo implements Parcelable {
        private static final String ATTR_SCREEN_ORIENTATION = "task_thumbnailinfo_screen_orientation";
        private static final String ATTR_TASK_HEIGHT = "task_thumbnailinfo_task_height";
        public static final String ATTR_TASK_THUMBNAILINFO_PREFIX = "task_thumbnailinfo_";
        private static final String ATTR_TASK_WIDTH = "task_thumbnailinfo_task_width";
        public static final Parcelable.Creator<TaskThumbnailInfo> CREATOR = new Parcelable.Creator<TaskThumbnailInfo>() { // from class: android.app.TaskThumbnail.TaskThumbnailInfo.1
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public TaskThumbnailInfo createFromParcel(Parcel source) {
                return new TaskThumbnailInfo(source);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public TaskThumbnailInfo[] newArray(int size) {
                return new TaskThumbnailInfo[size];
            }
        };
        public int screenOrientation;
        public int taskHeight;
        public int taskWidth;

        public TaskThumbnailInfo() {
            this.screenOrientation = 0;
        }

        private TaskThumbnailInfo(Parcel source) {
            this.screenOrientation = 0;
            readFromParcel(source);
        }

        public void reset() {
            this.taskWidth = 0;
            this.taskHeight = 0;
            this.screenOrientation = 0;
        }

        public void copyFrom(TaskThumbnailInfo o) {
            this.taskWidth = o.taskWidth;
            this.taskHeight = o.taskHeight;
            this.screenOrientation = o.screenOrientation;
        }

        public void saveToXml(XmlSerializer out) throws IOException {
            out.attribute(null, ATTR_TASK_WIDTH, Integer.toString(this.taskWidth));
            out.attribute(null, ATTR_TASK_HEIGHT, Integer.toString(this.taskHeight));
            out.attribute(null, ATTR_SCREEN_ORIENTATION, Integer.toString(this.screenOrientation));
        }

        public void restoreFromXml(String attrName, String attrValue) {
            if (ATTR_TASK_WIDTH.equals(attrName)) {
                this.taskWidth = Integer.parseInt(attrValue);
            } else if (ATTR_TASK_HEIGHT.equals(attrName)) {
                this.taskHeight = Integer.parseInt(attrValue);
            } else if (ATTR_SCREEN_ORIENTATION.equals(attrName)) {
                this.screenOrientation = Integer.parseInt(attrValue);
            }
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(this.taskWidth);
            dest.writeInt(this.taskHeight);
            dest.writeInt(this.screenOrientation);
        }

        public void readFromParcel(Parcel source) {
            this.taskWidth = source.readInt();
            this.taskHeight = source.readInt();
            this.screenOrientation = source.readInt();
        }
    }
}
