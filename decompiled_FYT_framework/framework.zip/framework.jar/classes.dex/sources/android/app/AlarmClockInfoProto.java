package android.app;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public final class AlarmClockInfoProto {
    public static final long SHOW_INTENT = 1146756268034L;
    public static final long TRIGGER_TIME_MS = 1112396529665L;
}
