package android.app;

import android.app.IAddonManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.ServiceManager;
import android.util.ArrayMap;
import android.util.CheckTime;
import android.util.Log;
import android.util.SparseArray;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class AddonManager {
    private static final boolean DEBUG = true;
    private static final String LOGTAG = "AddonManager";
    private static final String NO_PLUGIN = "";
    private static IAddonManager sAddonManagerService;
    private static AddonManager sInstance;
    private Context mContext;
    private List<PackageInfo> mManagedList;
    private IBinder mService;
    private static ArrayMap<String, WeakReference<Object>> sFeatureCache = new ArrayMap<>();
    private static ArrayMap<String, WeakReference<Class>> sClassCache = new ArrayMap<>();
    private static SparseArray<String> sIdMap = new SparseArray<>();

    public interface InitialCallback {
        Class onCreateAddon(Context context, Class cls);
    }

    static void attachApplication(Context context) {
    }

    public static AddonManager getDefault() {
        AddonManager addonManager = sInstance;
        if (addonManager != null) {
            return addonManager;
        }
        sInstance = new AddonManager(ActivityThread.currentApplication());
        return sInstance;
    }

    AddonManager(ContextImpl context, IBinder binder) {
        this(context);
        this.mContext = context;
        this.mService = binder;
    }

    public AddonManager(Context context) {
        this.mContext = context;
        if (sAddonManagerService == null) {
            sAddonManagerService = IAddonManager.Stub.asInterface(ServiceManager.getService("addon"));
        }
        if (this.mManagedList == null) {
            this.mManagedList = manageFeatureListS(context);
        }
    }

    private static List<PackageInfo> manageFeatureListS(Context context) {
        long startTime = CheckTime.getTime();
        List<PackageInfo> addonPackageList = null;
        String pkgName = context.getPackageName();
        IAddonManager iAddonManager = sAddonManagerService;
        if (iAddonManager != null) {
            try {
                addonPackageList = iAddonManager.getAppAddonFeatureList(pkgName);
                printCostTime(true, startTime, addonPackageList, pkgName);
                return addonPackageList;
            } catch (Exception e) {
                Log.d(LOGTAG, "manageFeatureListS occur error:" + e);
                return addonPackageList;
            }
        }
        List<PackageInfo> addonPackageList2 = manageFeatureList(context);
        printCostTime(false, startTime, addonPackageList2, pkgName);
        return addonPackageList2;
    }

    private static void printCostTime(boolean fromAddonService, long startTime, List list, String pkgName) {
        StringBuilder sb = new StringBuilder();
        sb.append("get addon packages");
        sb.append(fromAddonService ? " from AddonManagerService" : " by scan all installed packages");
        sb.append(" for app:");
        sb.append(pkgName);
        sb.append("-->");
        sb.append(list);
        sb.append(" cost ");
        sb.append(CheckTime.getTime() - startTime);
        sb.append("ms");
        Log.i(LOGTAG, sb.toString());
    }

    private static List<PackageInfo> manageFeatureList(Context context) {
        PackageManager pms = context.getPackageManager();
        List<PackageInfo> infoList = new ArrayList<>();
        List<PackageInfo> installedList = pms.getInstalledPackages(128);
        if (installedList != null && !installedList.isEmpty()) {
            String currentPackageName = context.getPackageName();
            for (PackageInfo pkg : installedList) {
                if (pkg != null && pkg.applicationInfo != null && pkg.applicationInfo.enabled && pkg.applicationInfo.metaData != null) {
                    Bundle metaData = pkg.applicationInfo.metaData;
                    if (metaData.containsKey("isFeatureAddon")) {
                        Set<String> metaKeys = metaData.keySet();
                        boolean foundTargetPackages = false;
                        for (String key : metaKeys) {
                            if (key.startsWith("targetPackages") && metaData.getString(key, NO_PLUGIN).contains(currentPackageName)) {
                                Log.d(LOGTAG, "-> manageFeatureList: The Plugin of <" + currentPackageName + "> is <" + pkg + "> .");
                                infoList.add(pkg);
                                foundTargetPackages = true;
                            }
                        }
                        if (!foundTargetPackages) {
                            if (pkg.installLocation == 1) {
                                Log.d(LOGTAG, "-> manageFeatureList: The Plugin of <" + currentPackageName + "> is <" + pkg + "> .");
                                infoList.add(pkg);
                            } else {
                                Log.w(LOGTAG, "-> manageFeatureList: no target package and not install internal only, drop " + pkg);
                            }
                        }
                    }
                }
            }
        }
        return infoList;
    }

    private static String getCachedId(int featureId, Context context) {
        String value = sIdMap.get(featureId);
        if (value == null) {
            String value2 = context.getString(featureId, NO_PLUGIN);
            sIdMap.put(featureId, value2);
            return value2;
        }
        return value;
    }

    private static Object getCachedFeature(String featureName) {
        if (featureName == null || NO_PLUGIN.equals(featureName)) {
            return null;
        }
        WeakReference<Object> feature = sFeatureCache.get(featureName);
        if (feature != null && feature.get() != null) {
            return feature.get();
        }
        sFeatureCache.remove(featureName);
        return null;
    }

    private Object createDefaultObject(Class defClazz) {
        try {
            return defClazz.newInstance();
        } catch (Exception e) {
            Log.e(LOGTAG, "Terrible, create default instance of class failed!", e);
            return null;
        }
    }

    public Object getAddon(Class defClazz) {
        return getAddon(0, defClazz);
    }

    public Object getAddon(int featureId, Class defClazz) {
        if (featureId > 0) {
            return getAddon(this.mContext.getString(featureId, NO_PLUGIN), defClazz);
        }
        String[] classNameSuffixes = getClassNameSuffix();
        if (classNameSuffixes != null && classNameSuffixes.length >= 0) {
            Object result = null;
            String featureClassName = defClazz.getName();
            for (String classNameSuffix : classNameSuffixes) {
                result = getAddon(featureClassName + classNameSuffix, defClazz);
                if (!result.getClass().equals(defClazz)) {
                    break;
                }
            }
            return result;
        }
        return createDefaultObject(defClazz);
    }

    String[] getClassNameSuffix() {
        return new String[]{"Impl"};
    }

    public Object getAddon(String featureClassName, Class defClazz) {
        ApplicationInfo applicationInfo;
        Object featureObject;
        Log.d(LOGTAG, "-> getAddon: featureClassName:" + featureClassName);
        if (defClazz != null) {
            Log.i(LOGTAG, "-> getAddon,The classloader of defClazz is " + defClazz.getClassLoader());
        }
        ApplicationInfo applicationInfo2 = this.mContext.getApplicationInfo();
        if (NO_PLUGIN.equals(featureClassName)) {
            featureObject = createDefaultObject(defClazz);
        } else {
            ClassLoader loader = defClazz.getClassLoader();
            if (!this.mManagedList.isEmpty()) {
                Iterator<PackageInfo> it = this.mManagedList.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        applicationInfo = applicationInfo2;
                        break;
                    }
                    PackageInfo pkg = it.next();
                    Bundle metaData = pkg.applicationInfo.metaData;
                    boolean hasDefinedFeatureClass = false;
                    Set<String> metaKeys = metaData.keySet();
                    Iterator<String> it2 = metaKeys.iterator();
                    while (true) {
                        if (!it2.hasNext()) {
                            break;
                        }
                        String key = it2.next();
                        if (key.startsWith("featureClassNames") && metaData.getString(key, NO_PLUGIN).contains(featureClassName)) {
                            hasDefinedFeatureClass = true;
                            applicationInfo2 = pkg.applicationInfo;
                            break;
                        }
                    }
                    if (hasDefinedFeatureClass) {
                        loader = ApplicationLoaders.getDefault().getClassLoader(pkg.applicationInfo.sourceDir, Build.VERSION.SDK_INT, false, null, null, this.mContext.getClassLoader(), null);
                        applicationInfo = applicationInfo2;
                        break;
                    }
                }
            } else {
                applicationInfo = applicationInfo2;
            }
            Class<?> clazz = null;
            try {
                clazz = loader.loadClass(featureClassName);
            } catch (ClassNotFoundException e) {
                Log.w(LOGTAG, "Load class " + featureClassName + " failed, have you installed the plugin apk ? " + e.getMessage());
            }
            Log.d(LOGTAG, "->getAddon, createAddon app: " + applicationInfo + ", clazz: " + clazz + ", classloader:" + loader);
            featureObject = createAddon(applicationInfo, clazz);
        }
        if (featureObject == null) {
            try {
                Log.d(LOGTAG, "->getAddon: Create feature <" + featureClassName + "> object Failed, AddonManager will return <" + defClazz + "> object.");
                if (defClazz != null) {
                    Object featureObject2 = createDefaultObject(defClazz);
                    return featureObject2;
                }
                return featureObject;
            } catch (Exception e2) {
                Log.e(LOGTAG, "Create default instance failed", e2);
                return featureObject;
            }
        }
        return featureObject;
    }

    private Object createAddon(ApplicationInfo applicationInfo, Class clazz) {
        Object featureObject = null;
        if (clazz == null) {
            return null;
        }
        try {
            featureObject = clazz.newInstance();
            if (featureObject instanceof InitialCallback) {
                InitialCallback callback = (InitialCallback) featureObject;
                Context pluginContext = null;
                try {
                    pluginContext = this.mContext.getApplicationContext().createPackageContext(applicationInfo.packageName, 3);
                } catch (Exception e) {
                    Log.e(LOGTAG, "Create addon context failed");
                }
                Class wantedClass = callback.onCreateAddon(pluginContext, clazz);
                Log.d(LOGTAG, "->createAddon, wantedClass <" + wantedClass + ">, pluginContext: " + pluginContext);
                if (wantedClass != null && !wantedClass.equals(clazz)) {
                    Object featureObject2 = createAddon(applicationInfo, wantedClass);
                    return featureObject2;
                }
                return featureObject;
            }
            return featureObject;
        } catch (Exception e2) {
            Log.e(LOGTAG, "Createing addon failed", e2);
            return featureObject;
        }
    }

    @Deprecated
    public boolean isFeatureEnabled(int featureId) {
        return true;
    }

    @Deprecated
    public boolean setFeatureEnabled(boolean enabled, int featureId) {
        return true;
    }
}
