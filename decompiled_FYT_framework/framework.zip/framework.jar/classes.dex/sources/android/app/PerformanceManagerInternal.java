package android.app;

import android.app.IPerformanceManagerInternal;
import android.content.Intent;
import android.os.IBinder;
import android.os.ServiceManager;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class PerformanceManagerInternal {
    private static PerformanceManagerInternal sInstance;
    private static IPerformanceManagerInternal sPerformanceManagerService;

    public static PerformanceManagerInternal getDefault() {
        PerformanceManagerInternal performanceManagerInternal = sInstance;
        if (performanceManagerInternal != null) {
            return performanceManagerInternal;
        }
        sInstance = new PerformanceManagerInternal();
        return sInstance;
    }

    public PerformanceManagerInternal() {
        if (sPerformanceManagerService == null) {
            sPerformanceManagerService = IPerformanceManagerInternal.Stub.asInterface(ServiceManager.getService("performance_fw"));
        }
    }

    public IPerformanceManagerInternal getService() {
        IPerformanceManagerInternal iPerformanceManagerInternal = sPerformanceManagerService;
        if (iPerformanceManagerInternal != null) {
            return iPerformanceManagerInternal;
        }
        return null;
    }

    public TaskThumbnail getTaskThumbnail(Intent intent) {
        IPerformanceManagerInternal iPerformanceManagerInternal = sPerformanceManagerService;
        if (iPerformanceManagerInternal == null) {
            return null;
        }
        try {
            TaskThumbnail thumb = iPerformanceManagerInternal.getTaskThumbnail(intent);
            return thumb;
        } catch (Exception e) {
            return null;
        }
    }

    public void windowReallyDrawnDone(String pkgName) {
        IPerformanceManagerInternal iPerformanceManagerInternal = sPerformanceManagerService;
        if (iPerformanceManagerInternal != null) {
            try {
                iPerformanceManagerInternal.windowReallyDrawnDone(pkgName);
            } catch (Exception e) {
            }
        }
    }

    public boolean pkgSupportRecentThumbnail(String pkgName) {
        IPerformanceManagerInternal iPerformanceManagerInternal = sPerformanceManagerService;
        if (iPerformanceManagerInternal == null) {
            return false;
        }
        try {
            boolean support = iPerformanceManagerInternal.pkgSupportRecentThumbnail(pkgName);
            return support;
        } catch (Exception e) {
            return false;
        }
    }

    public void removePendingUpdateThumbTask() {
        IPerformanceManagerInternal iPerformanceManagerInternal = sPerformanceManagerService;
        if (iPerformanceManagerInternal != null) {
            try {
                iPerformanceManagerInternal.removePendingUpdateThumbTask();
            } catch (Exception e) {
            }
        }
    }

    public void removeApplcationSnapShot(String pkgName) {
        IPerformanceManagerInternal iPerformanceManagerInternal = sPerformanceManagerService;
        if (iPerformanceManagerInternal != null) {
            try {
                iPerformanceManagerInternal.removeApplcationSnapShot(pkgName);
            } catch (Exception e) {
            }
        }
    }

    public void scheduleBoostRRForApp(boolean boost) {
        IPerformanceManagerInternal iPerformanceManagerInternal = sPerformanceManagerService;
        if (iPerformanceManagerInternal != null) {
            try {
                iPerformanceManagerInternal.scheduleBoostRRForApp(boost);
            } catch (Exception e) {
            }
        }
    }

    public void scheduleBoostRRForAppName(boolean boost, String pkgName, int type) {
        IPerformanceManagerInternal iPerformanceManagerInternal = sPerformanceManagerService;
        if (iPerformanceManagerInternal != null) {
            try {
                iPerformanceManagerInternal.scheduleBoostRRForAppName(boost, pkgName, type);
            } catch (Exception e) {
            }
        }
    }

    public void scheduleBoostWhenTouch() {
        IPerformanceManagerInternal iPerformanceManagerInternal = sPerformanceManagerService;
        if (iPerformanceManagerInternal != null) {
            try {
                iPerformanceManagerInternal.scheduleBoostWhenTouch();
            } catch (Exception e) {
            }
        }
    }

    public void attachPreforkApplication(int userId, IBinder app, String procName) {
        IPerformanceManagerInternal iPerformanceManagerInternal = sPerformanceManagerService;
        if (iPerformanceManagerInternal != null) {
            try {
                iPerformanceManagerInternal.attachPreforkApplication(userId, app, procName);
            } catch (Exception e) {
            }
        }
    }

    public boolean isUserAMonkeyNoCheck() {
        IPerformanceManagerInternal iPerformanceManagerInternal = sPerformanceManagerService;
        if (iPerformanceManagerInternal != null) {
            try {
                return iPerformanceManagerInternal.isUserAMonkeyNoCheck();
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }
}
