package android.app;

import android.util.Log;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class ProcState {
    private static final String ATTR_PKG = "pkgName";
    private static final String ATTR_PROC = "procName";
    private static final String ATTR_TOP_PSS = "topPss";
    private static final String ATTR_TOP_PSS_SAMPLE_COUNT = "topPssCount";
    private static final String ATTR_USERID = "userid";
    private static final String TAG = "ProcState";
    public long avgTopPss;
    public Integer mUserId;
    public String packageName;
    public String processName;
    public long topPssSampleCount;

    public ProcState(String processName, Integer userId) {
        this.packageName = processName;
        this.processName = processName;
        this.avgTopPss = 0L;
        this.topPssSampleCount = 0L;
        this.mUserId = userId;
    }

    public ProcState(String packageName, String processName, long avgTopPss, long topPssSampleCount, int mUserId) {
        this.packageName = packageName;
        this.processName = processName;
        this.avgTopPss = avgTopPss;
        this.topPssSampleCount = topPssSampleCount;
        this.mUserId = Integer.valueOf(mUserId);
    }

    public ProcState() {
    }

    public String toString() {
        return "UID:" + this.mUserId + "|pkg:" + this.packageName + "|proc:" + this.processName + "|pss:" + this.avgTopPss + "|cou t" + this.topPssSampleCount;
    }

    public void writeToFile(XmlSerializer serializer) throws IOException, XmlPullParserException {
        serializer.attribute(null, ATTR_USERID, String.valueOf(this.mUserId));
        serializer.attribute(null, ATTR_PKG, this.packageName);
        serializer.attribute(null, ATTR_PROC, this.processName);
        serializer.attribute(null, ATTR_TOP_PSS, String.valueOf(this.avgTopPss));
        serializer.attribute(null, ATTR_TOP_PSS_SAMPLE_COUNT, String.valueOf(this.topPssSampleCount));
    }

    public static ProcState restoreFromFile(XmlPullParser in) throws IOException, XmlPullParserException {
        ProcState procState = new ProcState();
        for (int attrNdx = in.getAttributeCount() - 1; attrNdx >= 0; attrNdx--) {
            String attrName = in.getAttributeName(attrNdx);
            String attrValue = in.getAttributeValue(attrNdx);
            if (ATTR_USERID.equals(attrName)) {
                procState.mUserId = Integer.valueOf(attrValue);
            } else if (ATTR_PKG.equals(attrName)) {
                procState.packageName = attrValue;
            } else if (ATTR_PROC.equals(attrName)) {
                procState.processName = attrValue;
            } else if (ATTR_TOP_PSS.equals(attrName)) {
                procState.avgTopPss = Long.valueOf(attrValue).longValue();
            } else if (ATTR_TOP_PSS_SAMPLE_COUNT.equals(attrName)) {
                procState.topPssSampleCount = Long.valueOf(attrValue).longValue();
            } else {
                Log.e(TAG, "error attr name....:" + attrName);
            }
        }
        return procState;
    }
}
