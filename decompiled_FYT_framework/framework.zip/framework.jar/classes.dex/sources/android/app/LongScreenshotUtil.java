package android.app;

import android.app.LongScreenshotUtil;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.AbsListView;
import android.widget.ListView;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class LongScreenshotUtil {
    private static final boolean DEBUG_LONG_SCREENSHOT = true;
    private static final int ENABLE_VIEW_TIME_DELAY = 1500;
    private static final int LISTVIEW = 1;
    private static final int LONGSCREENSHOT_ONE_STEP_DISTANCE = 20;
    private static final int LONGSCREENSHOT_SCROLL_DISTANCE = 500;
    private static final int LONGSCREENSHOT_WEBVIEW_BOTTOM_MARGIN = 200;
    public static final int LONG_SCREENSHOT_START = 1;
    public static final int LONG_SCREENSHOT_STOP = 3;
    public static final int LONG_SCREENSHOT_STOPPING = 2;
    public static final int MSG_COMPLETE_LONG_SCREENSHOT = 5;
    public static final int MSG_START_LONG_SCREENSHOT = 8;
    public static final int MSG_STOPPING_LONG_SCREENSHOT = 9;
    public static final int MSG_STOP_LONG_SCREENSHOT = 7;
    public static final int MSG_UPDATE_LONG_SCREENSHOT = 4;
    public static final int MSG_UPDATE_LONG_SCREENSHOT_MODE = 6;
    private static final int RECYCLEVIEW = 3;
    private static final int SCROLLVIEW = 2;
    private static final int SELF_DEFINED_LISTVIEW = 5;
    private static final int SELF_WEBVIEW = 6;
    private static final int START_LONGSCREENSHOT_TIME_DELAY = 1000;
    public static final String TAG = "LongScreenshotUtil";
    private static final int WEBVIEW = 4;
    private Context mContext;
    private static final String[] FORCE_USE_NEW_MODE_LIST = {"com.android.providers.media.RingtonePickerActivity"};
    private static final String[] FORCE_USE_OLD_MODE_LIST = {"com.android.launcher3.Launcher"};
    private static final String[] FORCE_USE_NEW_MODE_VIEW_LIST = {"ContactsFPSPinnedHeaderExpandableListView"};
    private int mScreenOrientation = -1;
    private boolean mScreenshotServiceBinded = false;
    private int mScrollType = 0;
    private List<Bitmap> mBitmaps = new ArrayList();
    private int mSecondBitmapHeight = 0;
    private Rect mScrollViewRect = new Rect();
    private boolean mScrollCompleted = false;
    private ScrollController mScrollController = null;
    private ViewGroup mScrollableView = null;
    private boolean mUseOldMode = false;
    private ViewGroup mAncestorView = null;
    private Class mRecyclerViewClass = null;
    private boolean mIsSelfRecyclerView = true;
    private int mLongScreenshotState = 3;
    private Handler mReceiveFromServiceHandler = new Handler() { // from class: android.app.LongScreenshotUtil.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            Log.d(LongScreenshotUtil.TAG, "receiveFromService: what=" + msg.what);
            int i = msg.what;
            if (i == 7) {
                LongScreenshotUtil.this.mLongScreenshotState = 3;
                LongScreenshotUtil.this.unbindScreenshotService();
            } else if (i == 8) {
                LongScreenshotUtil.this.mLongScreenshotState = 1;
                LongScreenshotUtil.this.takeLongscreenshot();
            } else if (i == 9) {
                LongScreenshotUtil.this.mLongScreenshotState = 2;
                ScrollUtils.setStopScrolling(true);
            } else {
                Log.e(LongScreenshotUtil.TAG, "unknown message");
            }
        }
    };
    private final Object mScreenshotLock = new Object();
    private Messenger mScreenshotMessenger = null;
    private ServiceConnection mServiceConnection = new ServiceConnection() { // from class: android.app.LongScreenshotUtil.2
        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName name, IBinder service) {
            synchronized (LongScreenshotUtil.this.mScreenshotLock) {
                LongScreenshotUtil.this.mScreenshotServiceBinded = true;
                LongScreenshotUtil.this.mScreenshotMessenger = new Messenger(service);
                Log.d(LongScreenshotUtil.TAG, "connected to screenshot service");
                LongScreenshotUtil.this.resetData();
                LongScreenshotUtil.this.mScreenOrientation = ((Activity) LongScreenshotUtil.this.mContext).getRequestedOrientation();
                ((Activity) LongScreenshotUtil.this.mContext).setRequestedOrientation(1);
                LongScreenshotUtil.this.updateLongScreenshotMode();
            }
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName name) {
            LongScreenshotUtil.this.mScreenshotServiceBinded = false;
            LongScreenshotUtil.this.mScreenshotMessenger = null;
            ((Activity) LongScreenshotUtil.this.mContext).setRequestedOrientation(LongScreenshotUtil.this.mScreenOrientation);
        }
    };
    private Messenger receiveMessenger = new Messenger(this.mReceiveFromServiceHandler);

    public void bindScreenshotService() {
        Log.d(TAG, "bindScreenshotService");
        synchronized (this.mScreenshotLock) {
            ComponentName cn = new ComponentName("com.android.systemui", "com.android.systemui.screenshot.TakeScreenshotService");
            Intent intent = new Intent();
            intent.setComponent(cn);
            ((Activity) this.mContext).getApplicationContext().bindService(intent, this.mServiceConnection, 1);
        }
    }

    public void unbindScreenshotService() {
        if (!this.mScreenshotServiceBinded) {
            Log.d(TAG, "ScreenshotService already unbind, return");
            return;
        }
        Log.d(TAG, "unbindScreenshotService");
        ((Activity) this.mContext).getApplicationContext().unbindService(this.mServiceConnection);
        this.mScreenshotServiceBinded = false;
        ((Activity) this.mContext).setRequestedOrientation(this.mScreenOrientation);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateLongScreenshotMode() {
        boolean isInMultiWindowMode = ((Activity) this.mContext).isInMultiWindowMode();
        this.mUseOldMode = false;
        boolean z = this.mUseOldMode;
        sendMessageToService(Message.obtain(null, 6, z ? 1 : 0, isInMultiWindowMode ? 1 : 0));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void notifyUpdateLongScreenshot(int scrollDistance) {
        Log.d(TAG, "notifyUpdateLongScreenshot: scrollDistance = " + scrollDistance);
        Message msg = Message.obtain(null, 4, scrollDistance, 0);
        sendMessageToService(msg);
        ScrollController scrollController = this.mScrollController;
        if (scrollController == null || scrollDistance <= 0) {
            return;
        }
        scrollController.notifyDoScrollDelay();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void scrollComplete(String reason) {
        if (this.mScrollCompleted) {
            Log.d(TAG, "mScrollCompleted, return");
            return;
        }
        Log.d(TAG, "scrollComplete: reason = " + reason);
        Message msg = Message.obtain(null, 5, this.mSecondBitmapHeight, 0);
        sendMessageToService(msg);
        this.mScrollCompleted = true;
    }

    private void startScroll() {
        Log.d(TAG, "startScroll");
        ViewGroup viewGroup = this.mScrollableView;
        if (viewGroup != null && viewGroup.getScrollBarStyle() != 16777216) {
            this.mScrollableView.setVerticalScrollBarEnabled(false);
        }
        this.mScrollController.startScroll();
    }

    public LongScreenshotUtil(Context context) {
        this.mContext = context;
    }

    public boolean isScreenshotServiceBinded() {
        return this.mScreenshotServiceBinded;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void resetData() {
        Log.d(TAG, "resetData");
        this.mBitmaps.clear();
        this.mSecondBitmapHeight = 0;
        this.mScrollableView = null;
        this.mScrollType = 0;
        this.mScrollController = null;
        this.mUseOldMode = false;
        this.mScrollCompleted = false;
        this.mScreenOrientation = -1;
    }

    private void sendMessageToService(Message msg) {
        Log.d(TAG, "sendMessageToService what = " + msg.what);
        msg.replyTo = this.receiveMessenger;
        try {
            this.mScreenshotMessenger.send(msg);
        } catch (RemoteException e) {
            e.printStackTrace();
            Log.d(TAG, "mScreenshotMessenger send message fail! what = " + msg.what);
        }
    }

    private ViewGroup getScrollableView(ViewGroup viewGroup) {
        int childCount = viewGroup.getChildCount();
        Log.d(TAG, "getScrollView1:viewGroup = " + viewGroup.getClass().getName() + " childCount = " + childCount);
        for (int i = childCount + (-1); i >= 0; i--) {
            View childView = viewGroup.getChildAt(i);
            if (childView.getVisibility() == 0 && childView.getLocalVisibleRect(new Rect()) && childView.isAttachedToWindow() && (childView instanceof ViewGroup)) {
                if (isScrollableView((ViewGroup) childView)) {
                    return (ViewGroup) childView;
                }
                View view = getScrollableView((ViewGroup) childView);
                if (view != null) {
                    return (ViewGroup) view;
                }
            }
        }
        return null;
    }

    public int getLongScreenshotState() {
        return this.mLongScreenshotState;
    }

    public void notifyStopScreenshot() {
        if (this.mLongScreenshotState != 1) {
            Log.d(TAG, "notifyStopScreenshot mLongScreenshotState=" + this.mLongScreenshotState);
            return;
        }
        this.mLongScreenshotState = 2;
        ScrollUtils.setStopScrolling(true);
        if (!this.mUseOldMode) {
            scrollComplete("stop by user");
        }
    }

    private boolean useOldMode() {
        synchronized (this.mScreenshotLock) {
            this.mScrollableView = getScrollableView((ViewGroup) ((Activity) this.mContext).getWindow().getDecorView());
            if (this.mScrollableView == null) {
                Log.d(TAG, "use_new_reason: mScrollableView is null");
                return false;
            }
            if (isForceUseNewMode()) {
                Log.d(TAG, "use_new_reason: force use new mode");
                return false;
            }
            if (isForceUseOldMode()) {
                Log.d(TAG, "use_old_reason: force use old mode");
                return true;
            }
            this.mScrollableView.getGlobalVisibleRect(this.mScrollViewRect);
            Log.d(TAG, "getGlobalVisibleRect : mScrollViewRect=" + this.mScrollViewRect + " mScrollableView=" + this.mScrollableView.getClass().getName());
            int width = getScreenWidth();
            int height = getScreenHeight();
            if (this.mScrollViewRect.width() >= width / 2 && this.mScrollViewRect.height() >= height / 2) {
                if (isNotSupportForExcellentApps(width, height)) {
                    Log.d(TAG, "use_new_reason: not support for excellent apps");
                    return false;
                }
                if (this.mScrollType != 6 && this.mScrollType != 3) {
                    return true;
                }
                Log.d(TAG, "use_new_reason: mScrollType is SELF_WEBVIEW or RECYCLEVIEW");
                return false;
            }
            Log.d(TAG, "use_new_reason: view is not big enough");
            return false;
        }
    }

    private boolean isForceUseNewMode() {
        for (String name : FORCE_USE_NEW_MODE_LIST) {
            if (name.equals(((Activity) this.mContext).getClass().getName())) {
                return true;
            }
        }
        for (String view : FORCE_USE_NEW_MODE_VIEW_LIST) {
            if (this.mScrollableView.getClass().getName().contains(view)) {
                return true;
            }
        }
        return false;
    }

    private boolean isForceUseOldMode() {
        for (String name : FORCE_USE_OLD_MODE_LIST) {
            if (name.equals(((Activity) this.mContext).getClass().getName())) {
                return true;
            }
        }
        return false;
    }

    private boolean isNotSupportForExcellentApps(int width, int height) {
        ViewGroup viewGroup = this.mScrollableView;
        if (viewGroup == null) {
            return true;
        }
        if (viewGroup.getClass().getName().contains("BottomSheetRecyclerView")) {
            Log.d(TAG, "use_new_reason: bottom sheet recycler layout view");
            return true;
        }
        if (this.mScrollableView.getClass().getName().startsWith("com.tencent.mm.plugin.appbrand.page")) {
            Log.d(TAG, "use_new_reason: wechat brand application");
            return true;
        }
        if (this.mScrollableView.getClass().getName().startsWith("com.tencent.widget.ARMapHongBaoListView")) {
            Log.d(TAG, "use_new_reason: qq brand application");
            return true;
        }
        if (isChildNestScrollableLayout()) {
            Log.d(TAG, "use_new_reason: nest scrollable view count limit");
            return true;
        }
        if (!scrrolableViewVisiableToUser((ViewGroup) ((Activity) this.mContext).getWindow().getDecorView(), width, height)) {
            Log.d(TAG, "use_new_reason: scrollable view is invisiable to user");
            return true;
        }
        return false;
    }

    private boolean isChildNestScrollableLayout() {
        ViewGroup viewGroup = this.mScrollableView;
        if (viewGroup != null && (viewGroup instanceof AbsListView)) {
            List<View> list = getAllChildViews(viewGroup);
            int scrollableViewVisibleCount = 0;
            int fullScrennChildVisibleCount = 0;
            for (View view : list) {
                if (view instanceof ViewGroup) {
                    if (checkWhetherScrollableView((ViewGroup) view) != 0 && view.isVisibleToUser()) {
                        scrollableViewVisibleCount++;
                    } else if (view.isVisibleToUser() && view.getWidth() == this.mScrollableView.getWidth() && view.getHeight() > (this.mScrollableView.getHeight() * 3) / 4) {
                        fullScrennChildVisibleCount++;
                    }
                }
            }
            if (scrollableViewVisibleCount > 1 || fullScrennChildVisibleCount > 0) {
                Log.d(TAG, "fullScrennChildVisibleCount:" + fullScrennChildVisibleCount + " scrollableViewVisibleCount:" + scrollableViewVisibleCount);
                return true;
            }
            return false;
        }
        return false;
    }

    private List<View> getAllChildViews(View view) {
        List<View> allchildren = new ArrayList<>();
        if (view instanceof ViewGroup) {
            ViewGroup vp = (ViewGroup) view;
            for (int i = 0; i < vp.getChildCount(); i++) {
                View viewchild = vp.getChildAt(i);
                allchildren.add(viewchild);
                allchildren.addAll(getAllChildViews(viewchild));
            }
        }
        return allchildren;
    }

    private List<View> getVisiableChildViews(View view, int width, int height) {
        List<View> children = new ArrayList<>();
        if (view instanceof ViewGroup) {
            ViewGroup vp = (ViewGroup) view;
            Rect visiableRect = new Rect();
            for (int i = 0; i < vp.getChildCount(); i++) {
                View viewchild = vp.getChildAt(i);
                if (viewchild.getVisibility() != 0 || !viewchild.getLocalVisibleRect(visiableRect) || !viewchild.isAttachedToWindow() || (visiableRect.width() > width / 2 && visiableRect.height() > height / 2)) {
                    if (viewchild.getElevation() > this.mScrollableView.getElevation()) {
                        this.mAncestorView = vp;
                    }
                    children.add(viewchild);
                    children.addAll(getVisiableChildViews(viewchild, width, height));
                }
            }
        }
        return children;
    }

    private boolean scrrolableViewVisiableToUser(ViewGroup viewGroup, int width, int height) {
        getVisiableChildViews(viewGroup, width, height);
        int i = 0;
        while (true) {
            ViewGroup viewGroup2 = this.mAncestorView;
            if (viewGroup2 != null && i < viewGroup2.getChildCount()) {
                View view = this.mAncestorView.getChildAt(i);
                Rect rect = new Rect();
                view.getLocalVisibleRect(rect);
                if (view.getVisibility() != 0 || ((rect.width() >= this.mScrollViewRect.width() && rect.height() >= this.mScrollViewRect.height()) || rect.width() <= this.mScrollViewRect.width() / 2 || rect.height() <= this.mScrollViewRect.height() / 2 || rect.right <= this.mScrollViewRect.width() / 2 || rect.left >= this.mScrollViewRect.width() / 2 || rect.top < 0)) {
                    i++;
                } else {
                    Log.d(TAG, "scrrolableViewVisiableToUser view:" + view + " rect:" + rect);
                    return false;
                }
            } else {
                return true;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void takeLongscreenshot() {
        if (this.mUseOldMode) {
            this.mScrollController = getScrollController();
            startScroll();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getScreenWidth() {
        return this.mContext.getResources().getDisplayMetrics().widthPixels;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getScreenHeight() {
        return this.mContext.getResources().getDisplayMetrics().heightPixels;
    }

    private ScrollController getScrollController() {
        Log.d(TAG, "getScrollController:scrollState = " + this.mScrollType);
        switch (this.mScrollType) {
            case 1:
                ScrollController sc = new ListViewController(this.mScrollableView);
                return sc;
            case 2:
                ScrollController sc2 = new ScrollViewController(this.mScrollableView);
                return sc2;
            case 3:
                ScrollController sc3 = new RecyclerViewController(this.mScrollableView, this.mRecyclerViewClass, this.mIsSelfRecyclerView);
                return sc3;
            case 4:
                ScrollController sc4 = new WebViewController(this.mScrollableView);
                return sc4;
            case 5:
                ScrollController sc5 = new ListViewController(this.mScrollableView, true);
                return sc5;
            case 6:
                int maxHeight = 0;
                for (int i = 0; i < this.mScrollableView.getChildCount(); i++) {
                    View child = this.mScrollableView.getChildAt(i);
                    Log.d(TAG, "child's height = " + child.getMeasuredHeight());
                    int height = child.getHeight();
                    if (height > maxHeight && (child instanceof ViewGroup) && child.getVisibility() == 0 && child.getLocalVisibleRect(new Rect())) {
                        maxHeight = height;
                    }
                }
                ViewGroup viewGroup = this.mScrollableView;
                ScrollController sc6 = new WebViewController(viewGroup, viewGroup.getChildCount() > 0 ? (ViewGroup) this.mScrollableView.getChildAt(0) : this.mScrollableView);
                return sc6;
            default:
                return null;
        }
    }

    /* JADX WARN: Incorrect condition in loop: B:29:0x0134 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private boolean isScrollableView(android.view.ViewGroup r21) {
        /*
            Method dump skipped, instructions count: 1086
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.app.LongScreenshotUtil.isScrollableView(android.view.ViewGroup):boolean");
    }

    private int checkWhetherScrollableView(ViewGroup viewGroup) {
        if (!viewGroup.getClass().getName().toLowerCase().contains("listview") && !viewGroup.getClass().getSuperclass().getName().toLowerCase().contains("listview") && !viewGroup.getClass().getSuperclass().getSuperclass().getName().toLowerCase().contains("listview") && !viewGroup.getClass().getName().toLowerCase().contains("recyclerview") && !viewGroup.getClass().getSuperclass().getName().toLowerCase().contains("recyclerview") && !viewGroup.getClass().getSuperclass().getSuperclass().getName().toLowerCase().contains("recyclerview") && !viewGroup.getClass().getName().toLowerCase().contains("webview") && !viewGroup.getClass().getSuperclass().getName().toLowerCase().contains("webview") && !viewGroup.getClass().getSuperclass().getSuperclass().getName().toLowerCase().contains("webview") && !viewGroup.getClass().getName().toLowerCase().contains("scrollview") && !viewGroup.getClass().getSuperclass().getName().toLowerCase().contains("scrollview") && !viewGroup.getClass().getSuperclass().getSuperclass().getName().toLowerCase().contains("scrollview")) {
            return 0;
        }
        Class clazz = viewGroup.getClass();
        while (true) {
            String classNamepath = clazz.getName().toLowerCase();
            int index = classNamepath.lastIndexOf(".");
            Log.d(TAG, "className = " + classNamepath + " index = " + classNamepath.lastIndexOf("."));
            String className = classNamepath.substring(index + 1);
            StringBuilder sb = new StringBuilder();
            sb.append("className = ");
            sb.append(className);
            Log.d(TAG, sb.toString());
            if (className.equals("listview") || className.equals("abslistview")) {
                return 1;
            }
            if (className.equals("viewgroup")) {
                return 0;
            }
            if (className.equals("adapterview")) {
                return 1;
            }
            if (className.equals("recyclerview")) {
                this.mRecyclerViewClass = clazz;
                if (!classNamepath.equals("android.support.v7.widget.recyclerview")) {
                    return 2;
                }
                this.mIsSelfRecyclerView = false;
                return 2;
            }
            if (className.equals("webview")) {
                return 3;
            }
            if (className.equals("scrollview")) {
                return 4;
            }
            clazz = clazz.getSuperclass();
        }
    }

    abstract class ScrollController {
        protected static final int SCROLL_DISTANCE = 500;
        protected static final int SCROLL_DURATION = 50;
        protected boolean scrollBarEnabled;
        protected ViewGroup view;
        protected int onceScrollDistance = 500;
        protected int maxScrollDistance = 0;
        protected int leftScrollDistance = 0;
        protected int scrolltimes = 0;
        protected int startScrollY = 0;
        protected int lastItemPreBottom = 0;
        protected View lastItemView = null;

        abstract boolean canScrollDown();

        abstract int countMaxScrollDistance();

        public ScrollController(ViewGroup view) {
            this.scrollBarEnabled = true;
            this.view = view;
            this.scrollBarEnabled = view.isVerticalScrollBarEnabled();
        }

        public void setOnceScrollDistance(int distance) {
            Log.d(LongScreenshotUtil.TAG, "setOnceScrollDistance:onceScrollDistance=" + distance);
            this.onceScrollDistance = distance;
        }

        protected void startScroll() {
            this.maxScrollDistance = countMaxScrollDistance();
            Log.d(LongScreenshotUtil.TAG, "startScroll:maxScrollDistance = " + this.maxScrollDistance);
            ScrollUtils.setStopScrolling(false);
            this.view.postDelayed(new Runnable() { // from class: android.app.-$$Lambda$LongScreenshotUtil$ScrollController$sXtj26HoaaIZLWLLr9bOmv86Wtw
                @Override // java.lang.Runnable
                public final void run() {
                    LongScreenshotUtil.ScrollController.this.lambda$startScroll$0$LongScreenshotUtil$ScrollController();
                }
            }, 500L);
        }

        protected void notifyDoScrollDelay() {
            this.view.postDelayed(new Runnable() { // from class: android.app.-$$Lambda$LongScreenshotUtil$ScrollController$b2A1iA1k6yev81iX4lQuhNX1Hy4
                @Override // java.lang.Runnable
                public final void run() {
                    LongScreenshotUtil.ScrollController.this.lambda$notifyDoScrollDelay$1$LongScreenshotUtil$ScrollController();
                }
            }, 500L);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        /* renamed from: doScroll, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public void lambda$startScroll$0$LongScreenshotUtil$ScrollController() {
            Log.d(LongScreenshotUtil.TAG, "doScroll");
            if (!canScrollDown() || LongScreenshotUtil.this.mLongScreenshotState != 1) {
                sendScrollMessage(0);
                return;
            }
            this.scrolltimes++;
            this.startScrollY = computeCurrentScrollY();
            Log.d(LongScreenshotUtil.TAG, "ScrollController doScroll startScrollY:" + this.startScrollY + " scrolltimes:" + this.scrolltimes);
            ViewGroup viewGroup = this.view;
            this.lastItemView = viewGroup.getChildAt(viewGroup.getChildCount() - 1);
            View view = this.lastItemView;
            if (view != null) {
                this.lastItemPreBottom = view.getBottom();
            }
            Log.d(LongScreenshotUtil.TAG, "ScrollController doScroll lastItemPreBottom = " + this.lastItemPreBottom);
            int width = LongScreenshotUtil.this.getScreenWidth();
            int height = LongScreenshotUtil.this.getScreenHeight();
            ScrollUtils.notifyScrollOnce(width / 2, width / 2, (height / 2) + 250, (height / 2) + (-250), 20);
            this.view.postDelayed(new Runnable() { // from class: android.app.-$$Lambda$LongScreenshotUtil$ScrollController$-VOn8EseU83PmL5cgwaK1eAmcHc
                @Override // java.lang.Runnable
                public final void run() {
                    LongScreenshotUtil.ScrollController.this.lambda$doScroll$2$LongScreenshotUtil$ScrollController();
                }
            }, 1000L);
        }

        public /* synthetic */ void lambda$doScroll$2$LongScreenshotUtil$ScrollController() {
            int scrollDistance = computeScrollDistance();
            if (this.lastItemView != null) {
                Log.d(LongScreenshotUtil.TAG, "run: lastItemPreBottom = " + this.lastItemView.getBottom());
                if (this.lastItemPreBottom - this.lastItemView.getBottom() > 0) {
                    scrollDistance = this.lastItemPreBottom - this.lastItemView.getBottom();
                }
            }
            Log.d(LongScreenshotUtil.TAG, "scrollDistance = " + scrollDistance);
            sendScrollMessage(scrollDistance);
        }

        protected void sendScrollMessage(int scrollDistance) {
            Log.d(LongScreenshotUtil.TAG, "sendScrollMessage: scrollDistance=" + scrollDistance, new Throwable());
            if (scrollDistance > 0) {
                Log.d(LongScreenshotUtil.TAG, "----> scrollDistance:" + scrollDistance);
                LongScreenshotUtil.this.notifyUpdateLongScreenshot(scrollDistance);
                return;
            }
            setScrollComplete("scroll to bottom");
            LongScreenshotUtil.this.notifyUpdateLongScreenshot(0);
        }

        protected int computeCurrentScrollY() {
            return this.view.getScrollY();
        }

        protected int computeScrollDistance() {
            return computeCurrentScrollY() - this.startScrollY;
        }

        protected void setScrollComplete(String reason) {
            this.view.setVerticalScrollBarEnabled(this.scrollBarEnabled);
            LongScreenshotUtil.this.scrollComplete(reason);
        }

        protected int fitScrollDistance(int scrollDistance) {
            if (canScrollDown()) {
                return this.onceScrollDistance;
            }
            if (this.lastItemView != null) {
                Log.d(LongScreenshotUtil.TAG, "fitScrollDistance: lastItemPreBottom = " + this.lastItemView.getBottom());
                return this.lastItemPreBottom - this.lastItemView.getBottom();
            }
            return scrollDistance;
        }
    }

    class RecyclerViewController extends ScrollController {
        private int leftMaxScrollDistance;
        private Method m1;
        private Method m2;
        private Method m3;
        private int preLeftMaxScrollDistance;
        private boolean selfRecyclerView;

        public RecyclerViewController(ViewGroup view, Class clazz, boolean selfRecyclerView) {
            super(view);
            this.leftMaxScrollDistance = 0;
            this.selfRecyclerView = false;
            this.selfRecyclerView = selfRecyclerView;
            createMethods(clazz);
        }

        private void createMethods(Class clazz) {
            try {
                this.m1 = clazz.getDeclaredMethod("computeVerticalScrollRange", new Class[0]);
                this.m2 = clazz.getDeclaredMethod("computeVerticalScrollExtent", new Class[0]);
                this.m3 = clazz.getDeclaredMethod("computeVerticalScrollOffset", new Class[0]);
                this.m1.setAccessible(true);
                this.m2.setAccessible(true);
                this.m3.setAccessible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        protected int computeCurrentScrollY() {
            int result = 0;
            try {
                result = ((Integer) this.m3.invoke(this.view, new Object[0])).intValue();
            } catch (Exception e) {
                e.printStackTrace();
            }
            Log.d(LongScreenshotUtil.TAG, "computeStartScrollY:result = " + result + " selfRecyclerView?" + this.selfRecyclerView);
            return result;
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        protected boolean canScrollDown() {
            boolean result = true;
            try {
                int verticalScrollRange = ((Integer) this.m1.invoke(this.view, new Object[0])).intValue();
                int verticalScrollExtent = ((Integer) this.m2.invoke(this.view, new Object[0])).intValue();
                int maxDistance = verticalScrollRange - verticalScrollExtent;
                int currentScrollDistance = ((Integer) this.m3.invoke(this.view, new Object[0])).intValue();
                this.leftMaxScrollDistance = maxDistance - currentScrollDistance;
                Log.d(LongScreenshotUtil.TAG, "maxDistance = " + maxDistance + ", leftMaxScrollDistance = " + this.leftMaxScrollDistance + " scrollY = " + this.view.getScrollY());
                if (currentScrollDistance >= maxDistance || this.preLeftMaxScrollDistance == this.leftMaxScrollDistance) {
                    result = false;
                    Log.d(LongScreenshotUtil.TAG, "RecyclerView has reached bottom");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            Log.d(LongScreenshotUtil.TAG, "canScrollDown:result = " + result);
            return result;
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        protected int countMaxScrollDistance() {
            try {
                int verticalScrollRange = ((Integer) this.m1.invoke(this.view, new Object[0])).intValue();
                int verticalScrollExtent = ((Integer) this.m2.invoke(this.view, new Object[0])).intValue();
                int currentScrollDistance = ((Integer) this.m3.invoke(this.view, new Object[0])).intValue();
                this.maxScrollDistance = verticalScrollRange - verticalScrollExtent;
                this.leftMaxScrollDistance = this.maxScrollDistance - currentScrollDistance;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.leftMaxScrollDistance;
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        protected int fitScrollDistance(int scrollDistance) {
            return super.fitScrollDistance(scrollDistance);
        }
    }

    class ListViewController extends ScrollController {
        private Method mGetCount;
        private Method mGetLastVisiblePosition;
        private AbsListView sListView;
        private boolean selfDefinedListView;

        public ListViewController(ViewGroup view, boolean selfDefinedListView) {
            super(view);
            int itemViewHeight;
            this.selfDefinedListView = false;
            this.selfDefinedListView = selfDefinedListView;
            try {
                this.mGetLastVisiblePosition = view.getClass().getMethod("getLastVisiblePosition", new Class[0]);
                this.mGetCount = view.getClass().getMethod("getCount", new Class[0]);
                int index = 0;
                do {
                    itemViewHeight = view.getChildAt(index).getHeight();
                    index++;
                } while (itemViewHeight == 0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public ListViewController(ViewGroup view) {
            super(view);
            int itemViewHeight;
            int itemViewHeight2;
            this.selfDefinedListView = false;
            this.sListView = (AbsListView) view;
            int index = 0;
            if (this.sListView instanceof ListView) {
                do {
                    itemViewHeight2 = view.getChildAt(index).getHeight();
                    index++;
                } while (itemViewHeight2 == 0);
            } else {
                do {
                    itemViewHeight = view.getChildAt(index).getHeight();
                    index++;
                } while (itemViewHeight == 0);
            }
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        public int computeCurrentScrollY() {
            ListView listView;
            View item;
            AbsListView absListView = this.sListView;
            if (!(absListView instanceof ListView) || (item = (listView = (ListView) absListView).getChildAt(0)) == null) {
                return 0;
            }
            int firstVisiblePosition = listView.getFirstVisiblePosition();
            int top = item.getTop();
            return (-top) + (item.getHeight() * firstVisiblePosition);
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        boolean canScrollDown() {
            boolean result;
            Log.d(LongScreenshotUtil.TAG, "viewGroup is ListView");
            int count = 0;
            int lastVisiblePosition = 0;
            if (this.selfDefinedListView) {
                try {
                    count = ((Integer) this.mGetCount.invoke(this.view, new Object[0])).intValue();
                    lastVisiblePosition = ((Integer) this.mGetLastVisiblePosition.invoke(this.view, new Object[0])).intValue();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                count = this.sListView.getCount();
                lastVisiblePosition = this.sListView.getLastVisiblePosition();
            }
            Log.d(LongScreenshotUtil.TAG, "count = " + count + " getChildCount = " + this.view.getChildCount() + " scrollY = " + this.view.getScrollY());
            StringBuilder sb = new StringBuilder();
            sb.append("LastVisiblePosition = ");
            sb.append(lastVisiblePosition);
            Log.d(LongScreenshotUtil.TAG, sb.toString());
            if (count > 0 && count - 1 >= lastVisiblePosition) {
                result = true;
            } else {
                result = false;
            }
            if (lastVisiblePosition >= count - 1 && count > 0) {
                int lastItemBottom = this.view.getChildAt(this.view.getChildCount() - 1).getBottom();
                int listViewheight = this.view.getHeight();
                Log.d(LongScreenshotUtil.TAG, "lastItemBottom = " + lastItemBottom + " listViewheight = " + listViewheight);
                if (lastItemBottom <= listViewheight) {
                    result = false;
                    Log.d(LongScreenshotUtil.TAG, "ListView has reached bottom");
                }
            }
            Log.d(LongScreenshotUtil.TAG, "canScrollDown: result = " + result);
            return result;
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        protected int countMaxScrollDistance() {
            return this.maxScrollDistance;
        }
    }

    class ScrollViewController extends ScrollController {
        public ScrollViewController(ViewGroup view) {
            super(view);
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        boolean canScrollDown() {
            boolean result = true;
            View child = this.view.getChildAt(0);
            if (child.getMeasuredHeight() <= this.view.getScrollY() + this.view.getHeight()) {
                result = false;
                Log.d(LongScreenshotUtil.TAG, "ScrollView has reached bottom");
            }
            Log.d(LongScreenshotUtil.TAG, "canScrollDown result = " + result);
            return result;
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        protected int countMaxScrollDistance() {
            View child = this.view.getChildAt(0);
            this.maxScrollDistance = child.getMeasuredHeight() - this.view.getHeight();
            this.leftScrollDistance = this.maxScrollDistance;
            return this.maxScrollDistance;
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        protected int fitScrollDistance(int scrollDistance) {
            int lastScrollDistance = countMaxScrollDistance() % this.onceScrollDistance;
            if (canScrollDown()) {
                return this.onceScrollDistance;
            }
            return lastScrollDistance;
        }
    }

    class WebViewController extends ScrollController {
        private ViewGroup childView;
        private boolean isSelfWebView;
        private ViewGroup selfWebView;

        public WebViewController(ViewGroup view) {
            super(view);
            this.isSelfWebView = false;
            this.selfWebView = null;
            this.childView = null;
        }

        public WebViewController(ViewGroup selfWebView, ViewGroup childView) {
            super(childView);
            this.isSelfWebView = false;
            this.selfWebView = null;
            this.childView = null;
            this.selfWebView = selfWebView;
            this.childView = childView;
            this.isSelfWebView = true;
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        protected int fitScrollDistance(int scrollDistance) {
            int result;
            if (this.maxScrollDistance > this.onceScrollDistance) {
                result = this.onceScrollDistance;
            } else {
                result = this.maxScrollDistance % this.onceScrollDistance;
            }
            this.maxScrollDistance -= result;
            Log.d(LongScreenshotUtil.TAG, "fitScrollDistance: result = " + result);
            return result;
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        boolean canScrollDown() {
            boolean result = this.maxScrollDistance > 0;
            Log.d(LongScreenshotUtil.TAG, "canScrollDown: result = " + result);
            return result;
        }

        @Override // android.app.LongScreenshotUtil.ScrollController
        protected int countMaxScrollDistance() {
            int result = 0;
            if (this.isSelfWebView) {
                try {
                    Method m1 = this.selfWebView.getClass().getMethod("getContentHeight", new Class[0]);
                    Method m2 = this.selfWebView.getClass().getMethod("getScale", new Class[0]);
                    m1.setAccessible(true);
                    m2.setAccessible(true);
                    int contentHeight = ((Integer) m1.invoke(this.selfWebView, new Object[0])).intValue();
                    float scale = ((Float) m2.invoke(this.selfWebView, new Object[0])).floatValue();
                    int currentScrollDistance = (this.selfWebView.getScrollY() != 0 ? this.selfWebView : this.childView).getScrollY();
                    result = (int) (((contentHeight * scale) - this.selfWebView.getHeight()) - currentScrollDistance);
                    Log.d(LongScreenshotUtil.TAG, "leftScrollDistance = " + this.leftScrollDistance + " currentScrollDistance = " + currentScrollDistance);
                    return result;
                } catch (Exception e) {
                    e.printStackTrace();
                    return result;
                }
            }
            WebView webView = (WebView) this.view;
            int result2 = (int) (((webView.getContentHeight() * webView.getScale()) - webView.getHeight()) - webView.getScrollY());
            return result2;
        }
    }
}
