package android.app;

import android.content.pm.ApplicationInfo;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public interface ZygotePreload {
    void doPreload(ApplicationInfo applicationInfo);
}
