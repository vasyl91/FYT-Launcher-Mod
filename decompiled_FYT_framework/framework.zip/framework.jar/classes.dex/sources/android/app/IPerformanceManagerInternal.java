package android.app;

import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public interface IPerformanceManagerInternal extends IInterface {
    void attachPreforkApplication(int i, IBinder iBinder, String str) throws RemoteException;

    TaskThumbnail getTaskThumbnail(Intent intent) throws RemoteException;

    boolean isUserAMonkeyNoCheck() throws RemoteException;

    boolean pkgSupportRecentThumbnail(String str) throws RemoteException;

    void removeApplcationSnapShot(String str) throws RemoteException;

    void removePendingUpdateThumbTask() throws RemoteException;

    void scheduleBoostRRForApp(boolean z) throws RemoteException;

    void scheduleBoostRRForAppName(boolean z, String str, int i) throws RemoteException;

    void scheduleBoostWhenTouch() throws RemoteException;

    void windowReallyDrawnDone(String str) throws RemoteException;

    public static class Default implements IPerformanceManagerInternal {
        @Override // android.app.IPerformanceManagerInternal
        public void windowReallyDrawnDone(String pkgName) throws RemoteException {
        }

        @Override // android.app.IPerformanceManagerInternal
        public TaskThumbnail getTaskThumbnail(Intent intent) throws RemoteException {
            return null;
        }

        @Override // android.app.IPerformanceManagerInternal
        public void removePendingUpdateThumbTask() throws RemoteException {
        }

        @Override // android.app.IPerformanceManagerInternal
        public boolean pkgSupportRecentThumbnail(String pkgName) throws RemoteException {
            return false;
        }

        @Override // android.app.IPerformanceManagerInternal
        public void removeApplcationSnapShot(String pkgName) throws RemoteException {
        }

        @Override // android.app.IPerformanceManagerInternal
        public void scheduleBoostRRForApp(boolean boost) throws RemoteException {
        }

        @Override // android.app.IPerformanceManagerInternal
        public void scheduleBoostRRForAppName(boolean boost, String pkgName, int type) throws RemoteException {
        }

        @Override // android.app.IPerformanceManagerInternal
        public void scheduleBoostWhenTouch() throws RemoteException {
        }

        @Override // android.app.IPerformanceManagerInternal
        public void attachPreforkApplication(int userId, IBinder app, String procName) throws RemoteException {
        }

        @Override // android.app.IPerformanceManagerInternal
        public boolean isUserAMonkeyNoCheck() throws RemoteException {
            return false;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }
    }

    public static abstract class Stub extends Binder implements IPerformanceManagerInternal {
        private static final String DESCRIPTOR = "android.app.IPerformanceManagerInternal";
        static final int TRANSACTION_attachPreforkApplication = 9;
        static final int TRANSACTION_getTaskThumbnail = 2;
        static final int TRANSACTION_isUserAMonkeyNoCheck = 10;
        static final int TRANSACTION_pkgSupportRecentThumbnail = 4;
        static final int TRANSACTION_removeApplcationSnapShot = 5;
        static final int TRANSACTION_removePendingUpdateThumbTask = 3;
        static final int TRANSACTION_scheduleBoostRRForApp = 6;
        static final int TRANSACTION_scheduleBoostRRForAppName = 7;
        static final int TRANSACTION_scheduleBoostWhenTouch = 8;
        static final int TRANSACTION_windowReallyDrawnDone = 1;

        public Stub() {
            attachInterface(this, DESCRIPTOR);
        }

        public static IPerformanceManagerInternal asInterface(IBinder obj) {
            if (obj == null) {
                return null;
            }
            IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
            if (iin != null && (iin instanceof IPerformanceManagerInternal)) {
                return (IPerformanceManagerInternal) iin;
            }
            return new Proxy(obj);
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        public static String getDefaultTransactionName(int transactionCode) {
            switch (transactionCode) {
                case 1:
                    return "windowReallyDrawnDone";
                case 2:
                    return "getTaskThumbnail";
                case 3:
                    return "removePendingUpdateThumbTask";
                case 4:
                    return "pkgSupportRecentThumbnail";
                case 5:
                    return "removeApplcationSnapShot";
                case 6:
                    return "scheduleBoostRRForApp";
                case 7:
                    return "scheduleBoostRRForAppName";
                case 8:
                    return "scheduleBoostWhenTouch";
                case 9:
                    return "attachPreforkApplication";
                case 10:
                    return "isUserAMonkeyNoCheck";
                default:
                    return null;
            }
        }

        public String getTransactionName(int transactionCode) {
            return getDefaultTransactionName(transactionCode);
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            Intent intent;
            if (i == 1598968902) {
                parcel2.writeString(DESCRIPTOR);
                return true;
            }
            switch (i) {
                case 1:
                    parcel.enforceInterface(DESCRIPTOR);
                    windowReallyDrawnDone(parcel.readString());
                    parcel2.writeNoException();
                    return true;
                case 2:
                    parcel.enforceInterface(DESCRIPTOR);
                    if (parcel.readInt() != 0) {
                        intent = Intent.CREATOR.createFromParcel(parcel);
                    } else {
                        intent = null;
                    }
                    TaskThumbnail taskThumbnail = getTaskThumbnail(intent);
                    parcel2.writeNoException();
                    if (taskThumbnail != null) {
                        parcel2.writeInt(1);
                        taskThumbnail.writeToParcel(parcel2, 1);
                    } else {
                        parcel2.writeInt(0);
                    }
                    return true;
                case 3:
                    parcel.enforceInterface(DESCRIPTOR);
                    removePendingUpdateThumbTask();
                    parcel2.writeNoException();
                    return true;
                case 4:
                    parcel.enforceInterface(DESCRIPTOR);
                    boolean pkgSupportRecentThumbnail = pkgSupportRecentThumbnail(parcel.readString());
                    parcel2.writeNoException();
                    parcel2.writeInt(pkgSupportRecentThumbnail ? 1 : 0);
                    return true;
                case 5:
                    parcel.enforceInterface(DESCRIPTOR);
                    removeApplcationSnapShot(parcel.readString());
                    parcel2.writeNoException();
                    return true;
                case 6:
                    parcel.enforceInterface(DESCRIPTOR);
                    scheduleBoostRRForApp(parcel.readInt() != 0);
                    parcel2.writeNoException();
                    return true;
                case 7:
                    parcel.enforceInterface(DESCRIPTOR);
                    scheduleBoostRRForAppName(parcel.readInt() != 0, parcel.readString(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 8:
                    parcel.enforceInterface(DESCRIPTOR);
                    scheduleBoostWhenTouch();
                    parcel2.writeNoException();
                    return true;
                case 9:
                    parcel.enforceInterface(DESCRIPTOR);
                    attachPreforkApplication(parcel.readInt(), parcel.readStrongBinder(), parcel.readString());
                    parcel2.writeNoException();
                    return true;
                case 10:
                    parcel.enforceInterface(DESCRIPTOR);
                    boolean isUserAMonkeyNoCheck = isUserAMonkeyNoCheck();
                    parcel2.writeNoException();
                    parcel2.writeInt(isUserAMonkeyNoCheck ? 1 : 0);
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }

        private static class Proxy implements IPerformanceManagerInternal {
            public static IPerformanceManagerInternal sDefaultImpl;
            private IBinder mRemote;

            Proxy(IBinder remote) {
                this.mRemote = remote;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return Stub.DESCRIPTOR;
            }

            @Override // android.app.IPerformanceManagerInternal
            public void windowReallyDrawnDone(String pkgName) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(pkgName);
                    boolean _status = this.mRemote.transact(1, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().windowReallyDrawnDone(pkgName);
                    } else {
                        _reply.readException();
                    }
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.IPerformanceManagerInternal
            public TaskThumbnail getTaskThumbnail(Intent intent) throws RemoteException {
                TaskThumbnail _result;
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (intent != null) {
                        _data.writeInt(1);
                        intent.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    boolean _status = this.mRemote.transact(2, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getTaskThumbnail(intent);
                    }
                    _reply.readException();
                    if (_reply.readInt() != 0) {
                        _result = TaskThumbnail.CREATOR.createFromParcel(_reply);
                    } else {
                        _result = null;
                    }
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.IPerformanceManagerInternal
            public void removePendingUpdateThumbTask() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    boolean _status = this.mRemote.transact(3, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().removePendingUpdateThumbTask();
                    } else {
                        _reply.readException();
                    }
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.IPerformanceManagerInternal
            public boolean pkgSupportRecentThumbnail(String pkgName) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(pkgName);
                    boolean _status = this.mRemote.transact(4, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().pkgSupportRecentThumbnail(pkgName);
                    }
                    _reply.readException();
                    boolean _status2 = _reply.readInt() != 0;
                    return _status2;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.IPerformanceManagerInternal
            public void removeApplcationSnapShot(String pkgName) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(pkgName);
                    boolean _status = this.mRemote.transact(5, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().removeApplcationSnapShot(pkgName);
                    } else {
                        _reply.readException();
                    }
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.IPerformanceManagerInternal
            public void scheduleBoostRRForApp(boolean boost) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeInt(boost ? 1 : 0);
                    boolean _status = this.mRemote.transact(6, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().scheduleBoostRRForApp(boost);
                    } else {
                        _reply.readException();
                    }
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.IPerformanceManagerInternal
            public void scheduleBoostRRForAppName(boolean boost, String pkgName, int type) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeInt(boost ? 1 : 0);
                    _data.writeString(pkgName);
                    _data.writeInt(type);
                    boolean _status = this.mRemote.transact(7, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().scheduleBoostRRForAppName(boost, pkgName, type);
                    } else {
                        _reply.readException();
                    }
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.IPerformanceManagerInternal
            public void scheduleBoostWhenTouch() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    boolean _status = this.mRemote.transact(8, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().scheduleBoostWhenTouch();
                    } else {
                        _reply.readException();
                    }
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.IPerformanceManagerInternal
            public void attachPreforkApplication(int userId, IBinder app, String procName) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeInt(userId);
                    _data.writeStrongBinder(app);
                    _data.writeString(procName);
                    boolean _status = this.mRemote.transact(9, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().attachPreforkApplication(userId, app, procName);
                    } else {
                        _reply.readException();
                    }
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            @Override // android.app.IPerformanceManagerInternal
            public boolean isUserAMonkeyNoCheck() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    boolean _status = this.mRemote.transact(10, _data, _reply, 0);
                    if (!_status && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().isUserAMonkeyNoCheck();
                    }
                    _reply.readException();
                    boolean _status2 = _reply.readInt() != 0;
                    return _status2;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }
        }

        public static boolean setDefaultImpl(IPerformanceManagerInternal impl) {
            if (Proxy.sDefaultImpl == null && impl != null) {
                Proxy.sDefaultImpl = impl;
                return true;
            }
            return false;
        }

        public static IPerformanceManagerInternal getDefaultImpl() {
            return Proxy.sDefaultImpl;
        }
    }
}
