package android.app;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class PreForkArgs {
    private static final String TAG = "PreforkArgs";
    public String abi;
    public String appDataDir;
    public String entryPoint;
    public int gid;
    public int[] gids;
    public String instructionSet;
    public String invokeWith;
    public int mountExternal;
    public String niceName;
    public String pkgName;
    public int runtimeFlags;
    public String seInfo;
    public int targetSdkVersion;
    public int uid;
    public String[] zygoteArgs;

    public PreForkArgs(String entryPoint, String niceName, int uid, int gid, int[] gids, int runtimeFlags, int mountExternal, int targetSdkVersion, String seInfo, String abi, String instructionSet, String appDataDir, String invokeWith, String pkgName, String[] zygoteArgs) {
        this.entryPoint = entryPoint;
        this.niceName = niceName;
        this.uid = uid;
        this.gid = gid;
        this.gids = gids;
        this.runtimeFlags = runtimeFlags;
        this.mountExternal = mountExternal;
        this.targetSdkVersion = targetSdkVersion;
        this.seInfo = seInfo;
        this.abi = abi;
        this.instructionSet = instructionSet;
        this.appDataDir = appDataDir;
        this.invokeWith = invokeWith;
        this.pkgName = pkgName;
        this.zygoteArgs = zygoteArgs;
    }

    private String argsToString(String[] zygoteArgs) {
        StringBuilder sb = new StringBuilder();
        for (String arg : zygoteArgs) {
            sb.append(arg);
        }
        return sb.toString();
    }

    public String toString() {
        return "PreForkArgs entryPoint= " + this.entryPoint + " ,niceName = " + this.niceName + " ,uid = " + this.uid + " ,gid = " + this.gid + " ,gids = " + this.gids + " ,runtimeFlags = " + this.runtimeFlags + " ,mountExternal = " + this.mountExternal + " ,targetSdkVersion = " + this.targetSdkVersion + " ,seInfo = " + this.seInfo + " ,abi = " + this.abi + " ,instructionSet = " + this.instructionSet + " ,appDataDir = " + this.appDataDir + " ,invokeWith = " + this.invokeWith + " ,pkgName = " + this.pkgName + " ,zygoteArgs = " + argsToString(this.zygoteArgs);
    }

    private boolean objectMatch(Object a, Object b) {
        if (a == null && b == null) {
            return true;
        }
        if (a != null && b != null && a.equals(b)) {
            return true;
        }
        return false;
    }

    private boolean arrayMatch(Object[] a, Object[] b) {
        if (a == null && b == null) {
            return true;
        }
        if (a == null || b == null || a.length != b.length) {
            return false;
        }
        for (int i = 0; i < a.length; i++) {
            if (!objectMatch(a[i], b[i])) {
                return false;
            }
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0051  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0093  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean match(java.lang.String r17, java.lang.String r18, int r19, int r20, int[] r21, int r22, int r23, int r24, java.lang.String r25, java.lang.String r26, java.lang.String r27, java.lang.String r28, java.lang.String r29, java.lang.String r30, java.lang.String[] r31) {
        /*
            r16 = this;
            r0 = r16
            java.lang.String r1 = r0.entryPoint
            r2 = r17
            boolean r1 = r2.equals(r1)
            if (r1 == 0) goto L40
            java.lang.String r1 = r0.niceName
            r5 = r18
            boolean r1 = r5.equals(r1)
            if (r1 == 0) goto L42
            int r1 = r0.uid
            r6 = r19
            if (r6 != r1) goto L44
            int r1 = r0.gid
            r7 = r20
            if (r7 != r1) goto L46
            int r1 = r0.runtimeFlags
            r8 = r22
            if (r8 != r1) goto L48
            int r1 = r0.mountExternal
            r9 = r23
            if (r9 != r1) goto L4a
            int r1 = r0.targetSdkVersion
            r10 = r24
            if (r10 != r1) goto L4c
            java.lang.String r1 = r0.pkgName
            r11 = r30
            boolean r1 = r11.equals(r1)
            if (r1 == 0) goto L4e
            r1 = 1
            goto L4f
        L40:
            r5 = r18
        L42:
            r6 = r19
        L44:
            r7 = r20
        L46:
            r8 = r22
        L48:
            r9 = r23
        L4a:
            r10 = r24
        L4c:
            r11 = r30
        L4e:
            r1 = 0
        L4f:
            if (r1 == 0) goto L93
            java.lang.String r12 = r0.seInfo
            r13 = r25
            boolean r12 = r0.objectMatch(r13, r12)
            if (r12 == 0) goto L8a
            java.lang.String r12 = r0.abi
            r14 = r26
            boolean r12 = r0.objectMatch(r14, r12)
            if (r12 == 0) goto L8c
            java.lang.String r12 = r0.instructionSet
            r15 = r27
            boolean r12 = r0.objectMatch(r15, r12)
            if (r12 == 0) goto L85
            java.lang.String r12 = r0.appDataDir
            r4 = r28
            boolean r12 = r0.objectMatch(r4, r12)
            if (r12 == 0) goto L87
            java.lang.String r12 = r0.invokeWith
            r3 = r29
            boolean r12 = r0.objectMatch(r3, r12)
            if (r12 == 0) goto L9d
            r12 = 1
            return r12
        L85:
            r4 = r28
        L87:
            r3 = r29
            goto L9d
        L8a:
            r14 = r26
        L8c:
            r15 = r27
            r4 = r28
            r3 = r29
            goto L9d
        L93:
            r13 = r25
            r14 = r26
            r15 = r27
            r4 = r28
            r3 = r29
        L9d:
            r12 = 0
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: android.app.PreForkArgs.match(java.lang.String, java.lang.String, int, int, int[], int, int, int, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String[]):boolean");
    }

    public boolean match(PreForkArgs save) {
        return match(save.entryPoint, save.niceName, save.uid, save.gid, save.gids, save.runtimeFlags, save.mountExternal, save.targetSdkVersion, save.seInfo, save.abi, save.instructionSet, save.appDataDir, save.invokeWith, save.pkgName, save.zygoteArgs);
    }
}
