package android.app;

import android.app.IUserSwitchObserver;
import android.os.Bundle;
import android.os.IRemoteCallback;
import android.os.RemoteException;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class UserSwitchObserver extends IUserSwitchObserver.Stub {
    public void onUserSwitching(int newUserId, IRemoteCallback reply) throws RemoteException {
        if (reply != null) {
            reply.sendResult((Bundle) null);
        }
    }

    @Override // android.app.IUserSwitchObserver
    public void onUserSwitchComplete(int newUserId) throws RemoteException {
    }

    @Override // android.app.IUserSwitchObserver
    public void onForegroundProfileSwitch(int newProfileId) throws RemoteException {
    }

    @Override // android.app.IUserSwitchObserver
    public void onLockedBootComplete(int newUserId) throws RemoteException {
    }
}
