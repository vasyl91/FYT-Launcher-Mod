package android.app;

import android.annotation.SystemApi;

@SystemApi
/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public abstract class VrStateCallback {
    public void onPersistentVrStateChanged(boolean enabled) {
    }

    public void onVrStateChanged(boolean enabled) {
    }
}
