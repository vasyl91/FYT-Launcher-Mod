package android.app.slice;

import android.app.settings.SettingsEnums;
import android.content.Context;
import android.metrics.LogMaker;
import android.net.Uri;
import com.android.internal.logging.MetricsLogger;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class SliceMetrics {
    private static final String TAG = "SliceMetrics";
    private MetricsLogger mMetricsLogger = new MetricsLogger();
    private LogMaker mLogMaker = new LogMaker(0);

    public SliceMetrics(Context context, Uri uri) {
        this.mLogMaker.addTaggedData(1402, uri.getAuthority());
        this.mLogMaker.addTaggedData(1403, uri.getPath());
    }

    public void logVisible() {
        synchronized (this.mLogMaker) {
            this.mLogMaker.setCategory(SettingsEnums.SLICE).setType(1);
            this.mMetricsLogger.write(this.mLogMaker);
        }
    }

    public void logHidden() {
        synchronized (this.mLogMaker) {
            this.mLogMaker.setCategory(SettingsEnums.SLICE).setType(2);
            this.mMetricsLogger.write(this.mLogMaker);
        }
    }

    public void logTouch(int actionType, Uri subSlice) {
        synchronized (this.mLogMaker) {
            this.mLogMaker.setCategory(SettingsEnums.SLICE).setType(4).addTaggedData(1404, subSlice.getAuthority()).addTaggedData(1405, subSlice.getPath());
            this.mMetricsLogger.write(this.mLogMaker);
        }
    }
}
