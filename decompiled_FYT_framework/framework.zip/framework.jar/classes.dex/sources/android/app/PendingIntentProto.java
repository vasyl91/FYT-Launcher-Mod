package android.app;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public final class PendingIntentProto {
    public static final long TARGET = 1138166333441L;
}
