package android.app.servertransaction;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public interface ObjectPoolItem {
    void recycle();
}
