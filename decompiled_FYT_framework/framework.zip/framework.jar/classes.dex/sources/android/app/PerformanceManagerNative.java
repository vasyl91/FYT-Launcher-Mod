package android.app;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.util.Log;
import android.util.Singleton;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class PerformanceManagerNative extends Binder implements IPerformanceManager {
    private static final Singleton<IPerformanceManager> gDefault = new Singleton<IPerformanceManager>() { // from class: android.app.PerformanceManagerNative.1
        /* JADX INFO: Access modifiers changed from: protected */
        /* renamed from: create, reason: merged with bridge method [inline-methods] */
        public IPerformanceManager m15create() {
            IBinder b = ServiceManager.getService("performancemanager");
            IPerformanceManager pm = PerformanceManagerNative.asInterface(b);
            return pm;
        }
    };

    public static IPerformanceManager asInterface(IBinder obj) {
        if (obj == null) {
            return null;
        }
        IPerformanceManager in = (IPerformanceManager) obj.queryLocalInterface(IPerformanceManager.descriptor);
        if (in != null) {
            return in;
        }
        return new PerformanceManagerProxy(obj);
    }

    public static IPerformanceManager getDefault() {
        return (IPerformanceManager) gDefault.get();
    }

    public PerformanceManagerNative() {
        attachInterface(this, IPerformanceManager.descriptor);
    }

    @Override // android.os.IInterface
    public IBinder asBinder() {
        return this;
    }

    @Override // android.os.Binder
    public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
        switch (code) {
            case 1:
                return true;
            case 2:
                return true;
            case 3:
                return true;
            case 4:
                return true;
            case 5:
                return true;
            case 6:
                return true;
            case 7:
                return true;
            case 8:
                return true;
            default:
                return super.onTransact(code, data, reply, flags);
        }
    }

    @Override // android.app.IPerformanceManager
    public String reclaimProcess(int pid, String type) throws RemoteException {
        Log.d("PerformanceManager", "dummy");
        return "";
    }

    @Override // android.app.IPerformanceManager
    public void enableBoostKill(int enable) throws RemoteException {
        Log.d("PerformanceManager", "dummy");
    }

    @Override // android.app.IPerformanceManager
    public boolean reclaimProcessEnabled() throws RemoteException {
        Log.d("PerformanceManager", "dummy");
        return false;
    }

    @Override // android.app.IPerformanceManager
    public String readProcFile(String path) throws RemoteException {
        Log.d("PerformanceManager", "dummy");
        return "";
    }

    @Override // android.app.IPerformanceManager
    public void writeProcFile(String path, String value) throws RemoteException {
        Log.d("PerformanceManager", "dummy");
    }

    @Override // android.app.IPerformanceManager
    public long fetchIfCacheMiss(String path, long[] offset, int[] length, boolean fetch, boolean lock) {
        return 0L;
    }

    @Override // android.app.IPerformanceManager
    public void freeFetchData(long addr, int length) {
    }

    @Override // android.app.IPerformanceManager
    public String getBlockDevName(String dirName) {
        return "";
    }
}
