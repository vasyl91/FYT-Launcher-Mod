package android.app;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public final class NotificationChannelGroupProto {
    public static final long ALLOW_APP_OVERLAY = 1133871366150L;
    public static final long CHANNELS = 2246267895813L;
    public static final long DESCRIPTION = 1138166333443L;
    public static final long ID = 1138166333441L;
    public static final long IS_BLOCKED = 1133871366148L;
    public static final long NAME = 1138166333442L;
}
