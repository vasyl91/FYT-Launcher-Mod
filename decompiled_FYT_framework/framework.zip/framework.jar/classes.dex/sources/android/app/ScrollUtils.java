package android.app;

import android.os.SystemClock;
import android.util.Log;
import android.view.MotionEvent;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class ScrollUtils {
    private static final String TAG = "FW-ScrollUtils";
    private static boolean mIsStopScrolling = false;

    /* JADX WARN: Type inference failed for: r6v0, types: [android.app.ScrollUtils$1] */
    public static void notifyScrollOnce(final int fromX, final int toX, final int fromY, final int toY, final int step) {
        new Thread() { // from class: android.app.ScrollUtils.1
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                ScrollUtils.doScrollOnce(fromX, toX, fromY, toY, step);
            }
        }.start();
    }

    public static void setStopScrolling(boolean stop) {
        mIsStopScrolling = stop;
    }

    public static boolean isStopScrolling() {
        return mIsStopScrolling;
    }

    public static synchronized void doScrollOnce(int fromX, int toX, int fromY, int toY, int step) {
        Instrumentation inst;
        synchronized (ScrollUtils.class) {
            if (mIsStopScrolling) {
                return;
            }
            MotionEvent event = null;
            int y = fromY;
            try {
                inst = new Instrumentation();
                try {
                    MotionEvent event2 = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), 0, fromX, fromY, 0);
                    inst.sendPointerSync(event2);
                    event2.recycle();
                    int stepCount = (fromY - toY) / step;
                    for (int i = 0; i < stepCount && !mIsStopScrolling; i++) {
                        y -= step;
                        MotionEvent event3 = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), 2, toX, y, 0);
                        inst.sendPointerSync(event3);
                        event3.recycle();
                    }
                } catch (Exception e) {
                    e = e;
                    Log.e(TAG, "doScrollOnce error", e);
                    if (event != null) {
                        event.recycle();
                    }
                }
            } catch (Exception e2) {
                e = e2;
            }
            if (mIsStopScrolling) {
                return;
            }
            event = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), 1, toX, y, 0);
            inst.sendPointerSync(event);
            event.recycle();
        }
    }
}
