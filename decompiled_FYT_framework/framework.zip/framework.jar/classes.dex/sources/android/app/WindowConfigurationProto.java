package android.app;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public final class WindowConfigurationProto {
    public static final long ACTIVITY_TYPE = 1120986464259L;
    public static final long APP_BOUNDS = 1146756268033L;
    public static final long BOUNDS = 1146756268036L;
    public static final long WINDOWING_MODE = 1120986464258L;
}
