package android.app;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public final class NotificationProto {
    public static final long ACTION_LENGTH = 1120986464264L;
    public static final long CATEGORY = 1138166333445L;
    public static final long CHANNEL_ID = 1138166333441L;
    public static final long COLOR = 1120986464260L;
    public static final long FLAGS = 1120986464259L;
    public static final long GROUP_KEY = 1138166333446L;
    public static final long HAS_TICKER_TEXT = 1133871366146L;
    public static final long PUBLIC_VERSION = 1146756268042L;
    public static final long SORT_KEY = 1138166333447L;
    public static final long VISIBILITY = 1159641169929L;
    public static final int VISIBILITY_PRIVATE = 0;
    public static final int VISIBILITY_PUBLIC = 1;
    public static final int VISIBILITY_SECRET = -1;
}
