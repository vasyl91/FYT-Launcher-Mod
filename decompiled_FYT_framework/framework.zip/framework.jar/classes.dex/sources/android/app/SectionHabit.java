package android.app;

import android.app.job.JobInfo;
import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class SectionHabit implements Serializable {
    public static final String ATTR_AR_TYPE = "type";
    public static final String ATTR_FGTIME = "fgtime";
    public static final String ATTR_FGTIME_INDEX = "fgtime_index";
    public static final String ATTR_LAUNCHCOUNT = "launchcount";
    public static final String ATTR_LAUNCHCOUNT_INDEX = "launchcount_index";
    public static final String ATTR_NAME = "name";
    public static final String CONF_TAG_APP_DATA = "appdata";
    public static final String CONF_TAG_PKG = "pkg";
    public static final String CONF_TAG_SECTIONHABIT = "sectionhabit";
    public static final long DATA_DURATION = 604800000;
    public static final long DURATION_15MIN = 900000;
    public static final long DURATION_1MIN = 60000;
    public static final long DURATION_2MIN = 120000;
    public static final long DURATION_30MIN = 1800000;
    public static final long DURATION_5MIN = 300000;
    private static final String SECTION_HABIT_TAG_CURRENT = "current";
    private static final String SECTION_HABIT_TAG_HISTORY = "history";
    private static final String TAG = "SectionHabit";
    public static final int TYPE_AFTERNOON = 3;
    public static final int TYPE_COUNT = 6;
    public static final int TYPE_MORNING = 1;
    public static final int TYPE_NIGHT = 5;
    public static final int TYPE_NOON = 2;
    public static final int TYPE_NOT_CARE = -1;
    public static final int TYPE_SUNRISE = 0;
    public static final int TYPE_SUNSET = 4;
    private static Object mDataLock = new Object();
    public long mStartTime = 0;
    private HashMap<Integer, SectionInfo> mCurrentData = new HashMap<>();
    private HashMap<Integer, SectionInfo> mHistoryData = new HashMap<>();

    public static class HabitDate implements Serializable {
        public long fgtime;
        public long fgtimeIndex;
        public long lastUsedTime;
        public long launchCount;
        public long launchCountIndex;
        public String packageName;

        public String toString() {
            return "package:" + this.packageName + " ,count :" + this.launchCount + ",launchCountIndex:" + this.launchCountIndex + ",fgtime:" + this.fgtime + ",fgtimeIndex:" + this.fgtimeIndex;
        }

        public static HabitDate createFromXml(String packageName, XmlPullParser in) {
            if (in == null) {
                return null;
            }
            HabitDate tmp = new HabitDate();
            tmp.packageName = packageName;
            if (SectionHabit.getAttrValue(in, SectionHabit.ATTR_LAUNCHCOUNT) != null) {
                tmp.launchCount = Long.valueOf(SectionHabit.getAttrValue(in, SectionHabit.ATTR_LAUNCHCOUNT)).longValue();
            }
            if (SectionHabit.getAttrValue(in, SectionHabit.ATTR_FGTIME) != null) {
                tmp.fgtime = Long.valueOf(SectionHabit.getAttrValue(in, SectionHabit.ATTR_FGTIME)).longValue();
            }
            if (SectionHabit.getAttrValue(in, SectionHabit.ATTR_LAUNCHCOUNT_INDEX) != null) {
                tmp.launchCountIndex = Long.valueOf(SectionHabit.getAttrValue(in, SectionHabit.ATTR_LAUNCHCOUNT_INDEX)).longValue();
            }
            if (SectionHabit.getAttrValue(in, SectionHabit.ATTR_FGTIME_INDEX) != null) {
                tmp.fgtimeIndex = Long.valueOf(SectionHabit.getAttrValue(in, SectionHabit.ATTR_FGTIME_INDEX)).longValue();
            }
            return tmp;
        }

        public void writeToFile(XmlSerializer serializer) throws IOException, XmlPullParserException {
            serializer.attribute(null, SectionHabit.ATTR_LAUNCHCOUNT, String.valueOf(this.launchCount));
            serializer.attribute(null, SectionHabit.ATTR_FGTIME, String.valueOf(this.fgtime));
            serializer.attribute(null, SectionHabit.ATTR_LAUNCHCOUNT_INDEX, String.valueOf(this.launchCountIndex));
            serializer.attribute(null, SectionHabit.ATTR_FGTIME_INDEX, String.valueOf(this.fgtimeIndex));
        }
    }

    public static class SectionInfo implements Serializable {
        public long endTime;
        public HashMap<String, HabitDate> sections = new HashMap<>();
        public long startTime;

        public String toString() {
            StringBuilder sb = new StringBuilder("");
            synchronized (SectionHabit.mDataLock) {
                if (this.sections != null) {
                    for (Map.Entry<String, HabitDate> entry : this.sections.entrySet()) {
                        HabitDate data = entry.getValue();
                        sb.append("key:");
                        sb.append(entry.getKey());
                        sb.append(",data:");
                        sb.append(data);
                    }
                }
            }
            String tmp = sb.toString();
            return "SectionInfo, startTime:" + this.startTime + " ,endTime :" + this.endTime + ",sections:" + tmp;
        }

        public SectionInfo(int type) {
            if (type == 0) {
                this.startTime = 0L;
                this.endTime = JobInfo.MAX_BACKOFF_DELAY_MILLIS;
                return;
            }
            if (type == 1) {
                this.startTime = 18001000L;
                this.endTime = 39600000L;
                return;
            }
            if (type == 2) {
                this.startTime = 39601000L;
                this.endTime = 54000000L;
                return;
            }
            if (type == 3) {
                this.startTime = 54001000L;
                this.endTime = 61200000L;
            } else if (type == 4) {
                this.startTime = 61201000L;
                this.endTime = 68400000L;
            } else if (type == 5) {
                this.startTime = 68401000L;
                this.endTime = AlarmManager.INTERVAL_DAY;
            }
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("");
        synchronized (mDataLock) {
            for (Map.Entry<Integer, SectionInfo> entry : this.mCurrentData.entrySet()) {
                SectionInfo data = entry.getValue();
                sb.append("key:");
                sb.append(entry.getKey());
                sb.append(",data:");
                sb.append(data);
            }
            for (Map.Entry<Integer, SectionInfo> entry2 : this.mHistoryData.entrySet()) {
                SectionInfo data2 = entry2.getValue();
                sb.append("key:");
                sb.append(entry2.getKey());
                sb.append(",data:");
                sb.append(data2);
            }
        }
        String tmp = sb.toString();
        return "data:" + tmp;
    }

    public SectionHabit() {
        for (int i = 0; i < 6; i++) {
            this.mCurrentData.put(Integer.valueOf(i), new SectionInfo(i));
            this.mHistoryData.put(Integer.valueOf(i), new SectionInfo(i));
        }
    }

    public void updateSectionInfo(String pkgName, long startTime, boolean isFg) {
        synchronized (mDataLock) {
            long now = System.currentTimeMillis();
            if (now > this.mStartTime + DATA_DURATION) {
                this.mHistoryData.clear();
                this.mHistoryData = (HashMap) CloneUtils.clone(this.mCurrentData);
                Log.d(TAG, "updateSectionInfo: mHistoryData" + this.mHistoryData);
                this.mCurrentData.clear();
                for (int i = 0; i < 6; i++) {
                    this.mCurrentData.put(Integer.valueOf(i), new SectionInfo(i));
                }
                this.mStartTime = now;
            }
        }
        if (isFg) {
            updateFoucusChangesCounts(pkgName);
        } else {
            updateFgTime(pkgName, startTime);
        }
    }

    private void updateFoucusChangesCounts(String pkgName) {
        int type = getTypeForTime(System.currentTimeMillis());
        synchronized (mDataLock) {
            if (type >= 0 && type < 6) {
                HabitDate data = getHabitDate(this.mCurrentData, type, pkgName);
                Log.d(TAG, "update pkgName:" + pkgName + ",type:" + type + ",data:" + data);
                if (data == null) {
                    data = new HabitDate();
                    this.mCurrentData.get(Integer.valueOf(type)).sections.put(pkgName, data);
                }
                data.packageName = pkgName;
                data.launchCount++;
                updateLaunchCountIndexLmd(type);
            }
        }
    }

    void updateLaunchCountIndexLmd(int type) {
        ArrayList<HabitDate> habitDates = new ArrayList<>();
        HashMap<String, HabitDate> map = this.mCurrentData.get(Integer.valueOf(type)).sections;
        if (map != null) {
            for (Map.Entry<String, HabitDate> entry : map.entrySet()) {
                habitDates.add(entry.getValue());
            }
            Collections.sort(habitDates, new Comparator<HabitDate>() { // from class: android.app.SectionHabit.1
                @Override // java.util.Comparator
                public int compare(HabitDate lhs, HabitDate rhs) {
                    return lhs.launchCount >= rhs.launchCount ? -1 : 1;
                }
            });
            Iterator<HabitDate> it = habitDates.iterator();
            while (it.hasNext()) {
                HabitDate data = it.next();
                data.launchCountIndex = habitDates.indexOf(data);
            }
        }
    }

    public void updateFgTime(String pkgName, long startTime) {
        long startMins;
        int startType = getTypeForTime(startTime);
        int type = getTypeForTime(System.currentTimeMillis());
        Calendar c = Calendar.getInstance();
        long endMins = (c.get(11) * 60) + c.get(12);
        c.setTimeInMillis(startTime);
        long startMins2 = (c.get(11) * 60) + c.get(12);
        synchronized (mDataLock) {
            try {
                if (type >= 0 && type < 6 && startType >= 0 && startType < 6) {
                    if (startType != type) {
                        int i = startType;
                        while (i <= type) {
                            if (i == startType) {
                                try {
                                    startMins = startMins2;
                                    updateFgTimeInner(pkgName, type, 60 * startMins2 * 1000, this.mCurrentData.get(Integer.valueOf(type)).endTime);
                                } catch (Throwable th) {
                                    th = th;
                                    throw th;
                                }
                            } else {
                                startMins = startMins2;
                                if (i == type) {
                                    updateFgTimeInner(pkgName, type, this.mCurrentData.get(Integer.valueOf(type)).startTime, 60 * endMins * 1000);
                                } else {
                                    updateFgTimeInner(pkgName, type, this.mCurrentData.get(Integer.valueOf(type)).startTime, this.mCurrentData.get(Integer.valueOf(type)).endTime);
                                }
                            }
                            i++;
                            startMins2 = startMins;
                        }
                    } else {
                        long startMins3 = System.currentTimeMillis();
                        updateFgTimeInner(pkgName, type, startTime, startMins3);
                    }
                }
            } catch (Throwable th2) {
                th = th2;
            }
        }
    }

    private void updateFgTimeInner(String pkgName, int type, long startTime, long endTime) {
        HabitDate data = getHabitDate(this.mCurrentData, type, pkgName);
        Log.d(TAG, "updateFgTimeInner pkgName:" + pkgName + ",type:" + type + ",data:" + data);
        if (data == null) {
            data = new HabitDate();
            this.mCurrentData.get(Integer.valueOf(type)).sections.put(pkgName, data);
        }
        data.packageName = pkgName;
        data.fgtime = endTime - startTime;
        data.lastUsedTime = endTime;
        updateFgTimeIndexLmd(type);
    }

    void updateFgTimeIndexLmd(int type) {
        ArrayList<HabitDate> habitDates = new ArrayList<>();
        HashMap<String, HabitDate> map = this.mCurrentData.get(Integer.valueOf(type)).sections;
        if (map != null) {
            for (Map.Entry<String, HabitDate> entry : map.entrySet()) {
                habitDates.add(entry.getValue());
            }
            Collections.sort(habitDates, new Comparator<HabitDate>() { // from class: android.app.SectionHabit.2
                @Override // java.util.Comparator
                public int compare(HabitDate lhs, HabitDate rhs) {
                    return lhs.fgtime >= rhs.fgtime ? -1 : 1;
                }
            });
            Iterator<HabitDate> it = habitDates.iterator();
            while (it.hasNext()) {
                HabitDate data = it.next();
                data.fgtimeIndex = habitDates.indexOf(data);
            }
        }
    }

    private int getTypeForTime(long time) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(time);
        int minutes = (c.get(11) * 60) + c.get(12);
        if (minutes <= 300 || minutes > 660) {
            if (minutes <= 660 || minutes > 900) {
                if (minutes > 900 && minutes <= 1020) {
                    return 3;
                }
                if (minutes > 1020 && minutes <= 1140) {
                    return 4;
                }
                return 5;
            }
            return 2;
        }
        return 1;
    }

    public static String getAttrValue(XmlPullParser in, String name) {
        for (int attrNdx = in.getAttributeCount() - 1; attrNdx >= 0; attrNdx--) {
            String attrName = in.getAttributeName(attrNdx);
            String attrValue = in.getAttributeValue(attrNdx);
            if (name.equals(attrName)) {
                return attrValue;
            }
        }
        return null;
    }

    public HabitDate getHistoryHabitDate(String pkgName) {
        HabitDate habitDate;
        int type = getTypeForTime(System.currentTimeMillis());
        if (ActivityDebugConfigs.DEBUG_SERVICE) {
            dumpSectionHabits();
        }
        synchronized (mDataLock) {
            habitDate = getHabitDate(this.mHistoryData, type, pkgName);
            if (habitDate == null) {
                habitDate = getHabitDate(this.mCurrentData, type, pkgName);
            }
        }
        return habitDate;
    }

    private HabitDate getHabitDate(HashMap<Integer, SectionInfo> data, int type, String pkgName) {
        HabitDate habitDate = null;
        synchronized (mDataLock) {
            if (type >= 0 && type < 6) {
                if (data.get(Integer.valueOf(type)) != null) {
                    habitDate = data.get(Integer.valueOf(type)).sections.get(pkgName);
                }
            }
        }
        return habitDate;
    }

    public void writeToFile(XmlSerializer serializer) throws IOException, XmlPullParserException {
        serializer.startTag(null, CONF_TAG_SECTIONHABIT);
        synchronized (mDataLock) {
            HashMap<Integer, SectionInfo> temp = (HashMap) this.mCurrentData.clone();
            HashMap<Integer, SectionInfo> historytemp = (HashMap) this.mHistoryData.clone();
            writeToFileLocked(serializer, temp, true);
            writeToFileLocked(serializer, historytemp, false);
        }
        serializer.endTag(null, CONF_TAG_SECTIONHABIT);
    }

    private void writeToFileLocked(XmlSerializer serializer, HashMap<Integer, SectionInfo> temp, boolean isNew) throws IOException, XmlPullParserException {
        if (isNew) {
            serializer.startTag(null, SECTION_HABIT_TAG_CURRENT);
        } else {
            serializer.startTag(null, SECTION_HABIT_TAG_HISTORY);
        }
        for (Map.Entry<Integer, SectionInfo> entry : temp.entrySet()) {
            HashMap<String, HabitDate> map = entry.getValue().sections;
            serializer.startTag(null, CONF_TAG_APP_DATA);
            serializer.attribute(null, ATTR_AR_TYPE, String.valueOf(entry.getKey()));
            for (Map.Entry<String, HabitDate> entry1 : map.entrySet()) {
                serializer.startTag(null, "pkg");
                serializer.attribute(null, ATTR_NAME, entry1.getKey());
                HabitDate data = entry1.getValue();
                if (data != null) {
                    data.writeToFile(serializer);
                }
                serializer.endTag(null, "pkg");
            }
            serializer.endTag(null, CONF_TAG_APP_DATA);
        }
        if (isNew) {
            serializer.endTag(null, SECTION_HABIT_TAG_CURRENT);
        } else {
            serializer.endTag(null, SECTION_HABIT_TAG_HISTORY);
        }
    }

    public static SectionHabit restoreFromFile(XmlPullParser in) throws IOException, XmlPullParserException {
        SectionHabit sectionHabit = new SectionHabit();
        HashMap<Integer, SectionInfo> temp = new HashMap<>();
        HashMap<String, HabitDate> tempDate = new HashMap<>();
        HabitDate habit = null;
        String pkgName = "";
        Integer.valueOf(0);
        while (true) {
            int event = in.next();
            if (event != 1) {
                String name = in.getName();
                synchronized (mDataLock) {
                    if (event == 2) {
                        try {
                            if (SECTION_HABIT_TAG_CURRENT.equals(name)) {
                                temp = sectionHabit.mCurrentData;
                            } else if (SECTION_HABIT_TAG_HISTORY.equals(name)) {
                                temp = sectionHabit.mHistoryData;
                            } else if (CONF_TAG_APP_DATA.equals(name)) {
                                Integer type = Integer.valueOf(getAttrValue(in, ATTR_AR_TYPE));
                                tempDate = temp.get(type).sections;
                            } else if ("pkg".equals(name)) {
                                pkgName = getAttrValue(in, ATTR_NAME);
                                habit = HabitDate.createFromXml(pkgName, in);
                            }
                        } finally {
                        }
                    } else if (event == 3) {
                        if ("pkg".equals(name)) {
                            if (temp != null && habit != null) {
                                tempDate.put(pkgName, habit);
                            }
                        } else if (CONF_TAG_SECTIONHABIT.equals(name)) {
                            return sectionHabit;
                        }
                    }
                }
            } else {
                return null;
            }
        }
    }

    public static class CloneUtils {
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r5v1, types: [java.io.Serializable] */
        public static <T extends Serializable> T clone(T obj) {
            T out = null;
            try {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ObjectOutputStream oos = new ObjectOutputStream(baos);
                oos.writeObject(obj);
                oos.close();
                ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
                ObjectInputStream ois = new ObjectInputStream(bais);
                out = (Serializable) ois.readObject();
                ois.close();
                return out;
            } catch (Exception e) {
                e.printStackTrace();
                return out;
            }
        }
    }

    public void dumpSectionHabits() {
        synchronized (mDataLock) {
            HashMap<Integer, SectionInfo> temp = (HashMap) this.mCurrentData.clone();
            Log.d(TAG, "dumpNewSectionHabits-> mCurrentData");
            dumpSectionHabitsDateLocked(temp);
            HashMap<Integer, SectionInfo> temp2 = (HashMap) this.mHistoryData.clone();
            Log.d(TAG, "dumpOldSectionHabits-> mHistoryData");
            dumpSectionHabitsDateLocked(temp2);
        }
    }

    private void dumpSectionHabitsDateLocked(HashMap<Integer, SectionInfo> temp) {
        for (Map.Entry<Integer, SectionInfo> entry : temp.entrySet()) {
            HashMap<String, HabitDate> map = entry.getValue().sections;
            for (Map.Entry<String, HabitDate> entry1 : map.entrySet()) {
                HabitDate data = entry1.getValue();
                Log.d(TAG, "dumpSectionHabits->" + entry1.getKey() + ",data:" + data);
            }
        }
    }

    public void dump(FileDescriptor fd, PrintWriter pw) {
        synchronized (mDataLock) {
            HashMap<Integer, SectionInfo> temp = (HashMap) this.mCurrentData.clone();
            pw.println("dump  New SectionHabit:");
            dumpDateLocked(pw, temp);
            HashMap<Integer, SectionInfo> temp2 = (HashMap) this.mHistoryData.clone();
            pw.println("dump  Old SectionHabit:");
            dumpDateLocked(pw, temp2);
        }
    }

    private void dumpDateLocked(PrintWriter pw, HashMap<Integer, SectionInfo> temp) {
        for (Map.Entry<Integer, SectionInfo> entry : temp.entrySet()) {
            HashMap<String, HabitDate> map = entry.getValue().sections;
            pw.println("---type " + entry.getKey() + "---");
            for (Map.Entry<String, HabitDate> entry1 : map.entrySet()) {
                HabitDate data = entry1.getValue();
                pw.println(entry1.getKey() + " " + data);
            }
        }
    }
}
