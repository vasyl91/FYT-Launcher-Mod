package android.app;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public final class PowerGuruAlarmInfo implements Parcelable {
    public static final Parcelable.Creator<PowerGuruAlarmInfo> CREATOR = new Parcelable.Creator<PowerGuruAlarmInfo>() { // from class: android.app.PowerGuruAlarmInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public PowerGuruAlarmInfo createFromParcel(Parcel in) {
            return new PowerGuruAlarmInfo(in);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public PowerGuruAlarmInfo[] newArray(int size) {
            return new PowerGuruAlarmInfo[size];
        }
    };
    public String actionName;
    public int alarmType;
    public String componentName;
    public boolean isAvailable;
    public boolean isFromGMS;
    public String packageName;

    public PowerGuruAlarmInfo(String _packageName, String _actionName, String _componentName, int _alarmType, boolean _isGms, boolean _isAvailable) {
        this.packageName = _packageName;
        this.actionName = _actionName;
        this.componentName = _componentName;
        this.alarmType = _alarmType;
        this.isFromGMS = _isGms;
        this.isAvailable = _isAvailable;
    }

    public PowerGuruAlarmInfo() {
    }

    public PowerGuruAlarmInfo(Parcel in) {
        readFromParcel(in);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String getPkg() {
        return this.packageName;
    }

    public String getAction() {
        return this.actionName;
    }

    public String getCpnt() {
        return this.componentName;
    }

    public int getAlarmType() {
        return this.alarmType;
    }

    public boolean getFromGMS() {
        return this.isFromGMS;
    }

    public boolean getAvailable() {
        return this.isAvailable;
    }

    public String setPkg(String pkg) {
        this.packageName = pkg;
        return pkg;
    }

    public String setAction(String action) {
        this.actionName = action;
        return action;
    }

    public String setCpnt(String cpnt) {
        this.componentName = cpnt;
        return cpnt;
    }

    public int setAlarmType(int type) {
        this.alarmType = type;
        return type;
    }

    public void setFromGMS(boolean fromGms) {
        this.isFromGMS = fromGms;
    }

    public void setAvailable(boolean avail) {
        this.isAvailable = avail;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.packageName);
        dest.writeString(this.actionName);
        dest.writeString(this.componentName);
        dest.writeInt(this.alarmType);
        if (this.isFromGMS) {
            dest.writeInt(1);
        } else {
            dest.writeInt(0);
        }
        if (this.isAvailable) {
            dest.writeInt(1);
        } else {
            dest.writeInt(0);
        }
    }

    public void readFromParcel(Parcel in) {
        this.packageName = in.readString();
        this.actionName = in.readString();
        this.componentName = in.readString();
        this.alarmType = in.readInt();
        this.isFromGMS = in.readInt() == 1;
        this.isAvailable = in.readInt() == 1;
    }

    public String toString() {
        return "p: " + this.packageName + " a: " + this.actionName + " c: " + this.componentName + " t: " + this.alarmType + " gms: " + this.isFromGMS + " ava: " + this.isAvailable;
    }
}
