package android.app;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public interface OnActivityPausedListener {
    void onPaused(Activity activity);
}
