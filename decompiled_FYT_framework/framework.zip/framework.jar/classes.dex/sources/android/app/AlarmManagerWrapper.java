package android.app;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class AlarmManagerWrapper {
    public static final int POWER_OFF_ALARM = 6;
    public static final int POWER_OFF_WAKEUP = 4;
    public static final int POWER_ON_WAKEUP = 5;

    public static void cancelAlarm(AlarmManager am, PendingIntent op, IAlarmListener listener) {
        am.removeExtraAlarm(op, listener);
    }
}
