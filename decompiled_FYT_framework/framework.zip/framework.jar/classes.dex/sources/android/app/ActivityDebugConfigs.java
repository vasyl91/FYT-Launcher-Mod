package android.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.ArrayMap;
import android.util.Log;
import android.util.SparseArray;
import com.android.internal.util.GrowingArrayUtils;
import java.io.PrintWriter;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public class ActivityDebugConfigs implements Parcelable {

    @DebugControl
    public static final int CONTROL_DEBUG_ACTIVITY = 104;

    @DebugControl
    public static final int CONTROL_DEBUG_BACKUP = 13;

    @DebugControl
    public static final int CONTROL_DEBUG_BLOCKMONITOR = 102;

    @DebugControl
    public static final int CONTROL_DEBUG_BROADCAST = 11;

    @DebugControl
    public static final int CONTROL_DEBUG_COMPONENTS = 19;

    @DebugControl
    public static final int CONTROL_DEBUG_CONFIGURATION = 14;

    @DebugControl
    public static final int CONTROL_DEBUG_LOADEDAPK = 101;

    @DebugControl
    public static final int CONTROL_DEBUG_MEMORY_TRIM = 16;

    @DebugControl
    public static final int CONTROL_DEBUG_MESSAGES = 10;

    @DebugControl
    public static final int CONTROL_DEBUG_ORDER = 18;

    @DebugControl
    public static final int CONTROL_DEBUG_PROVIDER = 17;

    @DebugControl
    public static final int CONTROL_DEBUG_RESULTS = 12;

    @DebugControl
    public static final int CONTROL_DEBUG_SERVICE = 15;

    @DebugControl
    public static final int CONTROL_DEBUG_SLOW_OPS = 103;
    private static final String CONTROL_PREFIX = "CONTROL_";
    public static final boolean DEBUG = false;

    @ControlledBy({104, 19})
    public static boolean DEBUG_ACTIVITY = false;

    @ControlledBy({13})
    public static boolean DEBUG_BACKUP = false;

    @ControlledBy({102})
    public static boolean DEBUG_BLOCKMONITOR = false;

    @ControlledBy({11, 19})
    public static boolean DEBUG_BROADCAST = false;

    @ControlledBy({14})
    public static boolean DEBUG_CONFIGURATION = false;

    @ControlledBy({101})
    public static boolean DEBUG_LOADEDAPK = false;

    @ControlledBy({16})
    public static boolean DEBUG_MEMORY_TRIM = false;

    @ControlledBy({10})
    public static boolean DEBUG_MESSAGES = false;

    @ControlledBy({18})
    public static boolean DEBUG_ORDER = false;

    @ControlledBy({17, 19})
    public static boolean DEBUG_PROVIDER = false;

    @ControlledBy({12})
    public static boolean DEBUG_RESULTS = false;

    @ControlledBy({15, 19})
    public static boolean DEBUG_SERVICE = false;

    @ControlledBy({103})
    public static boolean DEBUG_SLOW_OPS = false;
    private static final String TAG = "ActivityDebugConfigs";
    private static ActivityDebugConfigs sCurrent;
    private final int[] mEnabledConfigs;
    protected final Bundle mExtras;
    public final String packageName;
    public final int userId;
    private static SparseArray<Set<Field>> sSearchedFields = null;
    private static List<WeakReference<ConfigChangedListener>> sListeners = new ArrayList();
    public static final Parcelable.Creator<ActivityDebugConfigs> CREATOR = new Parcelable.Creator<ActivityDebugConfigs>() { // from class: android.app.ActivityDebugConfigs.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ActivityDebugConfigs createFromParcel(Parcel in) {
            return new ActivityDebugConfigs(in);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ActivityDebugConfigs[] newArray(int size) {
            return new ActivityDebugConfigs[size];
        }
    };

    public interface ConfigChangedListener {
        void onDebugConfigChanged(ActivityDebugConfigs activityDebugConfigs);
    }

    @Target({ElementType.FIELD})
    @Retention(RetentionPolicy.RUNTIME)
    @interface ControlledBy {
        int[] value();
    }

    @Target({ElementType.FIELD})
    @Retention(RetentionPolicy.RUNTIME)
    @interface DebugControl {
    }

    private ActivityDebugConfigs(int[] enabledConfigs, String packageName, int userId, Bundle extras) {
        this.mEnabledConfigs = enabledConfigs;
        this.packageName = packageName;
        this.userId = userId;
        this.mExtras = extras;
    }

    protected ActivityDebugConfigs(Parcel in) {
        int size = in.readInt();
        if (size > 0) {
            int[] enabledConfigs = new int[size];
            in.readIntArray(enabledConfigs);
            this.mEnabledConfigs = enabledConfigs;
        } else {
            this.mEnabledConfigs = null;
        }
        this.packageName = in.readString();
        this.userId = in.readInt();
        if (in.readInt() != 0) {
            this.mExtras = in.readBundle();
        } else {
            this.mExtras = null;
        }
    }

    public static void addConfigChangedListener(ConfigChangedListener listener) {
        listener.onDebugConfigChanged(sCurrent);
        sListeners.add(new WeakReference<>(listener));
    }

    public static void removeConfigChangedListener(ConfigChangedListener listener) {
        for (WeakReference<ConfigChangedListener> ref : sListeners) {
            ConfigChangedListener l = ref.get();
            if (l != null && l.equals(listener)) {
                sListeners.remove(ref);
                return;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int binarySearch(int[] array, int size, int value) {
        int lo = 0;
        int hi = size - 1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            int midVal = array[mid];
            if (midVal < value) {
                lo = mid + 1;
            } else if (midVal > value) {
                hi = mid - 1;
            } else {
                return mid;
            }
        }
        return ~lo;
    }

    private static void reset() {
        ensureDebugFieldsIfNeeded();
        for (int i = 0; i < sSearchedFields.size(); i++) {
            Set<Field> fields = sSearchedFields.valueAt(i);
            for (Field field : fields) {
                setStaticBooleanFieldSilently(field, false);
            }
        }
    }

    private static void setFieldEnabled(int flag, boolean enabled) {
        ensureDebugFieldsIfNeeded();
        Set<Field> fields = sSearchedFields.get(flag);
        if (fields == null) {
            Log.d(TAG, "Can not apply for flag " + flag + ", not found or not declared with @ControlledBy");
            return;
        }
        for (Field field : fields) {
            setStaticBooleanFieldSilently(field, enabled);
        }
    }

    private static void ensureDebugFieldsIfNeeded() {
        if (sSearchedFields == null) {
            SparseArray<Set<Field>> array = new SparseArray<>();
            Field[] fields = ActivityDebugConfigs.class.getDeclaredFields();
            if (fields != null) {
                for (Field field : fields) {
                    ControlledBy annotation = (ControlledBy) field.getAnnotation(ControlledBy.class);
                    if (annotation != null) {
                        int[] flags = annotation.value();
                        for (int flag : flags) {
                            Set<Field> targets = array.get(flag);
                            if (targets == null) {
                                targets = new HashSet();
                            }
                            targets.add(field);
                            array.put(flag, targets);
                        }
                    }
                }
            }
            sSearchedFields = array;
        }
    }

    public void apply() {
        doApply();
    }

    public Bundle getExtras() {
        Bundle bundle = this.mExtras;
        return bundle == null ? Bundle.EMPTY : bundle;
    }

    private void doApply() {
        reset();
        sCurrent = this;
        for (WeakReference<ConfigChangedListener> ref : sListeners) {
            ConfigChangedListener l = ref.get();
            if (l != null) {
                l.onDebugConfigChanged(this);
            }
        }
        int[] iArr = this.mEnabledConfigs;
        if (iArr == null || iArr.length == 0) {
            return;
        }
        for (int config : iArr) {
            setFieldEnabled(config, true);
        }
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ActivityDebugConfigs { ");
        builder.append("0x");
        builder.append(Integer.toHexString(System.identityHashCode(this)));
        int[] iArr = this.mEnabledConfigs;
        if (iArr != null && iArr.length > 0) {
            builder.append("[");
            for (int config : this.mEnabledConfigs) {
                builder.append(Builder.nameForFlag(config));
                builder.append(",");
            }
            builder.append("]");
        }
        if (this.mExtras != null) {
            builder.append(" extras: [");
            for (String key : this.mExtras.keySet()) {
                builder.append(key);
                builder.append("=");
                builder.append(String.valueOf(this.mExtras.get(key)));
                builder.append(",");
            }
            builder.append(" ]");
        }
        builder.append(" }");
        return builder.toString();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int flags) {
        int[] iArr = this.mEnabledConfigs;
        int length = iArr == null ? 0 : iArr.length;
        dest.writeInt(length);
        if (length > 0) {
            dest.writeIntArray(this.mEnabledConfigs);
        }
        dest.writeString(this.packageName);
        dest.writeInt(this.userId);
        if (this.mExtras == null) {
            dest.writeInt(0);
        } else {
            dest.writeInt(1);
            dest.writeBundle(this.mExtras);
        }
    }

    public static class Builder {
        private static SparseArray<Field> sFieldsByInt = null;
        private static ArrayMap<String, Field> sFieldsByString = null;
        private static Builder sGlobal;
        private int[] mEnabledConfigs;
        private Bundle mExtras;
        private String mPackageName;
        private int mSize;
        private int mUserId;

        private Builder(Builder other) {
            this();
            if (other == null) {
                return;
            }
            synchronized (other) {
                this.mEnabledConfigs = new int[other.mEnabledConfigs.length];
                int[] iArr = other.mEnabledConfigs;
                System.arraycopy(iArr, 0, this.mEnabledConfigs, 0, iArr.length);
                this.mSize = other.mSize;
                this.mPackageName = other.mPackageName;
                this.mUserId = other.mUserId;
                Bundle bundle = other.mExtras;
                this.mExtras = bundle == null ? null : new Bundle(bundle);
            }
        }

        public Builder() {
            this.mEnabledConfigs = new int[0];
            this.mSize = 0;
            this.mPackageName = "";
            this.mUserId = -1;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static String nameForFlag(int flag) {
            ensureConfigMaps();
            Field f = sFieldsByInt.get(flag);
            if (f == null) {
                return "[NOT_SUPPORTED]";
            }
            return f.getName().replace(ActivityDebugConfigs.CONTROL_PREFIX, "");
        }

        private static SparseArray<Field> getSupportedDebugConfigs() {
            ensureConfigMaps();
            return sFieldsByInt;
        }

        public static void dumpAllSupportedFlags(PrintWriter pw) {
            SparseArray<Field> map = getSupportedDebugConfigs();
            ActivityDebugConfigs.printOrLog(pw, "Supported flags for ActivityDebugConfigs:");
            for (int i = 0; i < map.size(); i++) {
                ActivityDebugConfigs.printOrLog(pw, map.valueAt(i).getName().replace(ActivityDebugConfigs.CONTROL_PREFIX, ""));
            }
        }

        public static boolean isControlSupported(String control) {
            ensureConfigMaps();
            return sFieldsByString.containsKey(convertControlName(control));
        }

        public static synchronized Builder getOrCreateGlobal() {
            Builder builder;
            synchronized (Builder.class) {
                if (sGlobal == null) {
                    sGlobal = new Builder();
                    sGlobal.setPackage("all");
                }
                builder = sGlobal;
            }
            return builder;
        }

        public static synchronized Builder getGlobal() {
            Builder builder;
            synchronized (Builder.class) {
                builder = sGlobal;
            }
            return builder;
        }

        public static synchronized void clearGlobal() {
            synchronized (Builder.class) {
                sGlobal = null;
            }
        }

        private static void ensureConfigMaps() {
            if (sFieldsByInt == null) {
                SparseArray<Field> intMap = new SparseArray<>();
                ArrayMap<String, Field> stringMap = new ArrayMap<>();
                Field[] fields = ActivityDebugConfigs.class.getDeclaredFields();
                for (Field field : fields) {
                    if (field.getAnnotation(DebugControl.class) != null) {
                        try {
                            int flag = field.getInt(null);
                            intMap.put(flag, field);
                            stringMap.put(field.getName(), field);
                        } catch (IllegalAccessException e) {
                            Log.w(ActivityDebugConfigs.TAG, "Can not access field for " + field, e);
                        }
                    }
                }
                sFieldsByInt = intMap;
                sFieldsByString = stringMap;
            }
        }

        private static String convertControlName(String input) {
            if (input == null) {
                return null;
            }
            String prefix = "";
            if (input.startsWith("DEBUG_")) {
                prefix = ActivityDebugConfigs.CONTROL_PREFIX;
            }
            return prefix + input;
        }

        public Builder setPackage(String pkgName) {
            this.mPackageName = pkgName;
            return this;
        }

        public String getPackageName() {
            return this.mPackageName;
        }

        public Builder setUserId(int userId) {
            this.mUserId = userId;
            return this;
        }

        public int getUserId() {
            return this.mUserId;
        }

        public Bundle getExtras() {
            return this.mExtras;
        }

        public void setExtras(Bundle extras) {
            if (this.mExtras == null) {
                this.mExtras = new Bundle();
            }
            if (extras != null) {
                this.mExtras.putAll(extras);
            }
        }

        public void setEnabled(String control, boolean enabled) {
            String control2 = convertControlName(control);
            ensureConfigMaps();
            try {
                Field f = sFieldsByString.get(control2);
                if (f != null) {
                    setEnabled(f.getInt(null), enabled);
                } else {
                    Log.w(ActivityDebugConfigs.TAG, "Can not find " + control2 + ", have it declared @DebugControl?");
                }
            } catch (Exception e) {
                Log.d("debug", "failed to setEnabled for " + control2, e);
            }
        }

        private void setEnabled(int flag, boolean enabled) {
            if (enabled) {
                insertFlag(flag);
            } else {
                removeFlag(flag);
            }
        }

        private synchronized void insertFlag(int flag) {
            int index = ActivityDebugConfigs.binarySearch(this.mEnabledConfigs, this.mSize, flag);
            if (index >= 0) {
                return;
            }
            this.mEnabledConfigs = GrowingArrayUtils.insert(this.mEnabledConfigs, this.mSize, ~index, flag);
            this.mSize++;
        }

        private synchronized void removeFlag(int flag) {
            int index = ActivityDebugConfigs.binarySearch(this.mEnabledConfigs, this.mSize, flag);
            if (index < 0) {
                return;
            }
            System.arraycopy(this.mEnabledConfigs, index + 1, this.mEnabledConfigs, index, this.mSize - index);
            this.mSize--;
        }

        public ActivityDebugConfigs build() {
            Builder merged;
            Bundle mergedExtras = getExtras();
            Builder global = getGlobal();
            if (global != null && this != global) {
                merged = new Builder(this);
                synchronized (global) {
                    for (int i = 0; i < global.mSize; i++) {
                        merged.setEnabled(global.mEnabledConfigs[i], true);
                    }
                }
                Bundle bundle = global.mExtras;
                if (bundle != null) {
                    mergedExtras = new Bundle(bundle);
                    if (getExtras() != null) {
                        mergedExtras.putAll(getExtras());
                    }
                }
            } else {
                merged = this;
            }
            int i2 = merged.mSize;
            int[] out = new int[i2];
            System.arraycopy(merged.mEnabledConfigs, 0, out, 0, i2);
            return new ActivityDebugConfigs(out, this.mPackageName, this.mUserId, mergedExtras);
        }

        public void dump(PrintWriter pw) {
            if (this.mSize == 0) {
                ActivityDebugConfigs.printOrLog(pw, "\tNo controls currently");
            }
            for (int i = 0; i < this.mSize; i++) {
                ActivityDebugConfigs.printOrLog(pw, nameForFlag(this.mEnabledConfigs[i]) + " = true");
            }
            Bundle bundle = this.mExtras;
            if (bundle == null || bundle.isEmpty()) {
                ActivityDebugConfigs.printOrLog(pw, "\tNo extras");
                return;
            }
            ActivityDebugConfigs.printOrLog(pw, "\tExtras:");
            for (String key : this.mExtras.keySet()) {
                ActivityDebugConfigs.printOrLog(pw, "\t\t" + key + ":" + String.valueOf(this.mExtras.get(key)));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void printOrLog(PrintWriter pw, String message) {
        if (pw != null) {
            pw.println(message);
        } else {
            Log.v(TAG, message);
        }
    }

    private static void setStaticBooleanFieldSilently(Field f, boolean value) {
        if (f == null) {
            Log.w(TAG, "Can not set boolean with " + value + ", because f is null", new RuntimeException());
            return;
        }
        try {
            f.setBoolean(null, value);
        } catch (IllegalAccessException | IllegalArgumentException e) {
            Log.d(TAG, "Can not set field " + f + " as true", e);
        }
    }
}
