package android.animation;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public interface TypeEvaluator<T> {
    T evaluate(float f, T t, T t2);
}
