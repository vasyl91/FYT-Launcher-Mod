package android.animation;

/* loaded from: D:\APK\APKRepatcher\Projects\framework.jar\dexFile\classes.dex */
public interface TimeInterpolator {
    float getInterpolation(float f);
}
